; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%0 = type { ptr, [2 x i32], %struct.PhysicalCoordinates.705 }
%struct.RuntimeContext.692 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }
%struct.ListManager = type { [256 x ptr], i64, i64, i32, i32, i32, ptr }
%struct.PhysicalCoordinates.705 = type { [12 x i32] }
%struct.cpu_block_task_helper_context = type { ptr, ptr, ptr, i32, i32, i64 }
%class.anon = type { ptr, ptr, ptr, ptr }

@.str = private unnamed_addr constant [28 x i8] c"Out of pre-allocated memory\00", align 1
@.str.2 = private unnamed_addr constant [28 x i8] c"List manager out of chunks.\00", align 1

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @live_hierarchy_force_31_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 25
  %2 = load double, ptr %1, align 8
  %3 = getelementptr inbounds %struct.RuntimeContext.692, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  store double %2, ptr %6, align 8
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @live_hierarchy_force_31_kernel_1_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.692, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 27
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @live_hierarchy_force_31_kernel_2_listgen_S27pointer(ptr %context) local_unnamed_addr #1 {
.lr.ph.i:
  %.sroa.2.i = alloca { [2 x i32], %struct.PhysicalCoordinates.705 }, align 8
  %0 = alloca %0, align 8
  %1 = getelementptr inbounds %struct.RuntimeContext.692, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 26
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %4, i64 27
  %8 = load ptr, ptr %7, align 8
  %9 = load atomic i64, ptr %6 acquire, align 8
  %.not.i.i.i.i = icmp ne i64 %9, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i)
  %10 = inttoptr i64 %9 to ptr
  %11 = load atomic i64, ptr %10 acquire, align 8
  %12 = inttoptr i64 %11 to ptr
  %.sroa.0.0.copyload.i = load ptr, ptr %12, align 8
  %.sroa.2.0..sroa_idx.i = getelementptr inbounds i8, ptr %12, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.i, ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.0..sroa_idx.i, i64 56, i1 false)
  %13 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %.sroa.2.16.sroa_idx.i = getelementptr inbounds i8, ptr %.sroa.2.i, i64 8
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %16 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 4
  %17 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 6
  %18 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 2
  %19 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  store ptr %.sroa.0.0.copyload.i, ptr %0, align 8
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %0, i64 8
  store <2 x i32> <i32 0, i32 4>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %13, ptr noundef nonnull align 8 dereferenceable(48) %.sroa.2.16.sroa_idx.i, i64 48, i1 false)
  %20 = atomicrmw volatile add ptr %14, i32 1 seq_cst, align 4
  %21 = load i32, ptr %15, align 8
  %22 = ashr i32 %20, %21
  %23 = icmp ugt i32 %22, 131071
  br i1 %23, label %24, label %26

24:                                               ; preds = %.lr.ph.i
  %25 = load ptr, ptr %17, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %25, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

26:                                               ; preds = %.lr.ph.i
  %27 = zext i32 %22 to i64
  %28 = lshr i64 %27, 9
  %29 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %28
  %30 = load atomic i64, ptr %29 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %30, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %26
  %31 = inttoptr i64 %30 to ptr
  %32 = and i64 %27, 511
  %33 = getelementptr inbounds ptr, ptr %31, i64 %32
  %34 = load atomic i64, ptr %33 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %26
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %35 = atomicrmw volatile xchg ptr %16, i32 1 seq_cst, align 4
  %36 = icmp eq i32 %35, 1
  br i1 %36, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %37 = load atomic i64, ptr %29 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %37, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %39, label %73

39:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %40 = load ptr, ptr %17, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1
  %42 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 28
  %43 = atomicrmw volatile add ptr %42, i64 4096 seq_cst, align 8
  %44 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 2
  %45 = load i64, ptr %44, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %45, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %66, label %46

46:                                               ; preds = %39
  %47 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 26
  br label %48

48:                                               ; preds = %48, %46
  %49 = atomicrmw volatile xchg ptr %47, i32 1 seq_cst, align 4
  %50 = icmp eq i32 %49, 1
  br i1 %50, label %48, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %48
  %51 = load ptr, ptr %41, align 8
  %52 = ptrtoint ptr %51 to i64
  %53 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 1
  %54 = load ptr, ptr %53, align 8
  %55 = ptrtoint ptr %54 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %52
  %56 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %57 = or i64 %56, 4096
  %58 = add i64 %57, %52
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %58, %55
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %59

59:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %60 = add i64 %56, %52
  %61 = inttoptr i64 %60 to ptr
  %62 = getelementptr i8, ptr %51, i64 %56
  %63 = getelementptr inbounds i8, ptr %62, i64 4096
  store ptr %63, ptr %41, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %59, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %61, %59 ]
  %64 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %65 = atomicrmw volatile xchg ptr %47, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %40, i1 noundef zeroext %64, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

66:                                               ; preds = %39
  %67 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 2
  %68 = load ptr, ptr %67, align 8
  %69 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 6
  %70 = load ptr, ptr %69, align 8
  %71 = tail call noundef ptr %68(ptr noundef %70, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %66, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %71, %66 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %72 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %72, ptr %29 release, align 8
  br label %73

73:                                               ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %38, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %74 = and i32 %22, 511
  %75 = zext i32 %74 to i64
  %76 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %75
  %77 = load atomic i64, ptr %76 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %77, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %78, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

78:                                               ; preds = %73
  %79 = load ptr, ptr %17, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1
  %81 = load i64, ptr %18, align 8
  %82 = load i64, ptr %19, align 8
  %83 = mul i64 %82, %81
  %84 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 28
  %85 = atomicrmw volatile add ptr %84, i64 %83 seq_cst, align 8
  %86 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 2
  %87 = load i64, ptr %86, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %87, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %107, label %88

88:                                               ; preds = %78
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 26
  br label %90

90:                                               ; preds = %90, %88
  %91 = atomicrmw volatile xchg ptr %89, i32 1 seq_cst, align 4
  %92 = icmp eq i32 %91, 1
  br i1 %92, label %90, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %90
  %93 = load ptr, ptr %80, align 8
  %94 = ptrtoint ptr %93 to i64
  %95 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 1
  %96 = load ptr, ptr %95, align 8
  %97 = ptrtoint ptr %96 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %94
  %98 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %99 = add i64 %98, %83
  %100 = add i64 %99, %94
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %100, %97
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %101

101:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %102 = add i64 %98, %94
  %103 = inttoptr i64 %102 to ptr
  %104 = getelementptr inbounds i8, ptr %93, i64 %99
  store ptr %104, ptr %80, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %101, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %103, %101 ]
  %105 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %106 = atomicrmw volatile xchg ptr %89, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %79, i1 noundef zeroext %105, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

107:                                              ; preds = %78
  %108 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 2
  %109 = load ptr, ptr %108, align 8
  %110 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 6
  %111 = load ptr, ptr %110, align 8
  %112 = tail call noundef ptr %109(ptr noundef %111, i64 noundef %83, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %107, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %112, %107 ]
  %113 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %113, ptr %76 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %73
  %114 = atomicrmw volatile xchg ptr %16, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %24
  %115 = load i32, ptr %15, align 8
  %116 = ashr i32 %20, %115
  %117 = sext i32 %116 to i64
  %118 = lshr i64 %117, 9
  %119 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %118
  %120 = load atomic i64, ptr %119 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %120, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %121

121:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %122 = inttoptr i64 %120 to ptr
  %123 = and i64 %117, 511
  %124 = getelementptr inbounds ptr, ptr %122, i64 %123
  %125 = load atomic i64, ptr %124 acquire, align 8
  %126 = inttoptr i64 %125 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %121, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %127 = phi ptr [ %126, %121 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %128 = load i64, ptr %19, align 8
  %129 = load i32, ptr %15, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %129
  %130 = xor i32 %notmask.i.i.i.i, -1
  %131 = and i32 %20, %130
  %132 = sext i32 %131 to i64
  %133 = mul i64 %128, %132
  %134 = getelementptr inbounds i8, ptr %127, i64 %133
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %134, ptr nonnull align 8 %0, i64 %128, i1 false)
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @live_hierarchy_force_31_kernel_3_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.692, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 28
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @live_hierarchy_force_31_kernel_4_listgen_S28bitmasked(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %0, align 8
  %1 = alloca %struct.PhysicalCoordinates.705, align 4
  %2 = alloca %0, align 8
  %3 = getelementptr inbounds %struct.RuntimeContext.692, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %2)
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 13
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %6, i64 27
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %10 = load i32, ptr %9, align 8
  %11 = getelementptr inbounds ptr, ptr %6, i64 28
  %12 = load ptr, ptr %11, align 8
  %13 = icmp sgt i32 %10, 0
  br i1 %13, label %.lr.ph61.i, label %element_listgen_nonroot.exit

.lr.ph61.i:                                       ; preds = %entry
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  %16 = getelementptr inbounds %0, ptr %0, i64 0, i32 1
  %17 = getelementptr inbounds %0, ptr %0, i64 0, i32 1, i64 1
  %18 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %19 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %20 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 5
  %21 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %22 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 4
  %23 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 6
  %24 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 2
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %2, i64 8
  br label %26

26:                                               ; preds = %._crit_edge.i, %.lr.ph61.i
  %.04359.i = phi i32 [ 0, %.lr.ph61.i ], [ %172, %._crit_edge.i ]
  %27 = load i32, ptr %14, align 8
  %28 = lshr i32 %.04359.i, %27
  %29 = sext i32 %28 to i64
  %30 = lshr i64 %29, 9
  %31 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %30
  %32 = load atomic i64, ptr %31 acquire, align 8
  %.not.i.i.i.i = icmp eq i64 %32, 0
  br i1 %.not.i.i.i.i, label %_ZN11ListManager3getI7ElementEERT_i.exit.i, label %33

33:                                               ; preds = %26
  %34 = inttoptr i64 %32 to ptr
  %35 = and i64 %29, 511
  %36 = getelementptr inbounds ptr, ptr %34, i64 %35
  %37 = load atomic i64, ptr %36 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit.i

_ZN11ListManager3getI7ElementEERT_i.exit.i:       ; preds = %33, %26
  %39 = phi ptr [ %38, %33 ], [ null, %26 ]
  %40 = load i64, ptr %15, align 8
  %41 = load i32, ptr %14, align 8
  %notmask.i.i.i = shl nsw i32 -1, %41
  %42 = xor i32 %notmask.i.i.i, -1
  %43 = and i32 %.04359.i, %42
  %44 = zext i32 %43 to i64
  %45 = mul i64 %40, %44
  %46 = getelementptr inbounds i8, ptr %39, i64 %45
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %0, ptr noundef nonnull align 8 dereferenceable(64) %46, i64 64, i1 false)
  %47 = load i32, ptr %16, align 8
  %48 = load i32, ptr %17, align 4
  %49 = icmp slt i32 %47, %48
  br i1 %49, label %.lr.ph58.i.preheader, label %._crit_edge.i

.lr.ph58.i.preheader:                             ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit.i
  br label %.lr.ph58.i

.lr.ph58.i:                                       ; preds = %.loopexit.i, %.lr.ph58.i.preheader
  %.04457.i = phi i32 [ %171, %.loopexit.i ], [ %47, %.lr.ph58.i.preheader ]
  call fastcc void @S27_refine_coordinates(ptr noundef nonnull %18, ptr noundef nonnull %1, i32 noundef %.04457.i) #1
  %50 = load ptr, ptr %0, align 8
  %51 = shl i32 %.04457.i, 3
  %52 = sext i32 %51 to i64
  %53 = getelementptr i8, ptr %50, i64 %52
  %54 = getelementptr inbounds i8, ptr %53, i64 32
  %55 = load ptr, ptr %54, align 8
  %.not = icmp eq ptr %55, null
  br i1 %.not, label %.loopexit.i, label %.lr.ph.i

.lr.ph.i:                                         ; preds = %.lr.ph58.i
  store ptr %55, ptr %2, align 8
  store <2 x i32> <i32 0, i32 32>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %19, ptr noundef nonnull align 4 dereferenceable(48) %1, i64 48, i1 false)
  %56 = atomicrmw volatile add ptr %20, i32 1 seq_cst, align 4
  %57 = load i32, ptr %21, align 8
  %58 = ashr i32 %56, %57
  %59 = icmp ugt i32 %58, 131071
  br i1 %59, label %60, label %62

60:                                               ; preds = %.lr.ph.i
  %61 = load ptr, ptr %23, align 8
  call fastcc void @taichi_assert_format(ptr noundef %61, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

62:                                               ; preds = %.lr.ph.i
  %63 = zext i32 %58 to i64
  %64 = lshr i64 %63, 9
  %65 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %64
  %66 = load atomic i64, ptr %65 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %66, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %62
  %67 = inttoptr i64 %66 to ptr
  %68 = and i64 %63, 511
  %69 = getelementptr inbounds ptr, ptr %67, i64 %68
  %70 = load atomic i64, ptr %69 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %70, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %62
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %71 = atomicrmw volatile xchg ptr %22, i32 1 seq_cst, align 4
  %72 = icmp eq i32 %71, 1
  br i1 %72, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %73 = load atomic i64, ptr %65 acquire, align 8
  %74 = inttoptr i64 %73 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %73, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %75, label %109

75:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %76 = load ptr, ptr %23, align 8
  %77 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1
  %78 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 28
  %79 = atomicrmw volatile add ptr %78, i64 4096 seq_cst, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 2
  %81 = load i64, ptr %80, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %81, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %102, label %82

82:                                               ; preds = %75
  %83 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 26
  br label %84

84:                                               ; preds = %84, %82
  %85 = atomicrmw volatile xchg ptr %83, i32 1 seq_cst, align 4
  %86 = icmp eq i32 %85, 1
  br i1 %86, label %84, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %84
  %87 = load ptr, ptr %77, align 8
  %88 = ptrtoint ptr %87 to i64
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 1
  %90 = load ptr, ptr %89, align 8
  %91 = ptrtoint ptr %90 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %88
  %92 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %93 = or i64 %92, 4096
  %94 = add i64 %93, %88
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %94, %91
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %95

95:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %96 = add i64 %92, %88
  %97 = inttoptr i64 %96 to ptr
  %98 = getelementptr i8, ptr %87, i64 %92
  %99 = getelementptr inbounds i8, ptr %98, i64 4096
  store ptr %99, ptr %77, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %95, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %97, %95 ]
  %100 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %101 = atomicrmw volatile xchg ptr %83, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %76, i1 noundef zeroext %100, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

102:                                              ; preds = %75
  %103 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 2
  %104 = load ptr, ptr %103, align 8
  %105 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 6
  %106 = load ptr, ptr %105, align 8
  %107 = call noundef ptr %104(ptr noundef %106, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %102, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %107, %102 ]
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %108 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %108, ptr %65 release, align 8
  br label %109

109:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %74, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %110 = and i32 %58, 511
  %111 = zext i32 %110 to i64
  %112 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %111
  %113 = load atomic i64, ptr %112 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %113, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %114, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

114:                                              ; preds = %109
  %115 = load ptr, ptr %23, align 8
  %116 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1
  %117 = load i64, ptr %24, align 8
  %118 = load i64, ptr %25, align 8
  %119 = mul i64 %118, %117
  %120 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 28
  %121 = atomicrmw volatile add ptr %120, i64 %119 seq_cst, align 8
  %122 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 2
  %123 = load i64, ptr %122, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %123, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %143, label %124

124:                                              ; preds = %114
  %125 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 26
  br label %126

126:                                              ; preds = %126, %124
  %127 = atomicrmw volatile xchg ptr %125, i32 1 seq_cst, align 4
  %128 = icmp eq i32 %127, 1
  br i1 %128, label %126, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %126
  %129 = load ptr, ptr %116, align 8
  %130 = ptrtoint ptr %129 to i64
  %131 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 1
  %132 = load ptr, ptr %131, align 8
  %133 = ptrtoint ptr %132 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %130
  %134 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %135 = add i64 %134, %119
  %136 = add i64 %135, %130
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %136, %133
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %137

137:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %138 = add i64 %134, %130
  %139 = inttoptr i64 %138 to ptr
  %140 = getelementptr inbounds i8, ptr %129, i64 %135
  store ptr %140, ptr %116, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %137, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %139, %137 ]
  %141 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %142 = atomicrmw volatile xchg ptr %125, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %115, i1 noundef zeroext %141, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

143:                                              ; preds = %114
  %144 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 2
  %145 = load ptr, ptr %144, align 8
  %146 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 6
  %147 = load ptr, ptr %146, align 8
  %148 = call noundef ptr %145(ptr noundef %147, i64 noundef %119, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %143, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %148, %143 ]
  %149 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %149, ptr %112 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %109
  %150 = atomicrmw volatile xchg ptr %22, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %60
  %151 = load i32, ptr %21, align 8
  %152 = ashr i32 %56, %151
  %153 = sext i32 %152 to i64
  %154 = lshr i64 %153, 9
  %155 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %154
  %156 = load atomic i64, ptr %155 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %156, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %157

157:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %158 = inttoptr i64 %156 to ptr
  %159 = and i64 %153, 511
  %160 = getelementptr inbounds ptr, ptr %158, i64 %159
  %161 = load atomic i64, ptr %160 acquire, align 8
  %162 = inttoptr i64 %161 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %157, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %163 = phi ptr [ %162, %157 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %164 = load i64, ptr %25, align 8
  %165 = load i32, ptr %21, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %165
  %166 = xor i32 %notmask.i.i.i.i, -1
  %167 = and i32 %56, %166
  %168 = sext i32 %167 to i64
  %169 = mul i64 %164, %168
  %170 = getelementptr inbounds i8, ptr %163, i64 %169
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %170, ptr nonnull align 8 %2, i64 %164, i1 false)
  br label %.loopexit.i, !llvm.loop !8

.loopexit.i:                                      ; preds = %_ZN11ListManager6appendEPv.exit.i, %.lr.ph58.i
  %171 = add i32 %.04457.i, 1
  %exitcond.not.i = icmp eq i32 %171, %48
  br i1 %exitcond.not.i, label %._crit_edge.i.loopexit, label %.lr.ph58.i, !llvm.loop !9

._crit_edge.i.loopexit:                           ; preds = %.loopexit.i
  br label %._crit_edge.i

._crit_edge.i:                                    ; preds = %._crit_edge.i.loopexit, %_ZN11ListManager3getI7ElementEERT_i.exit.i
  %172 = add nuw nsw i32 %.04359.i, 1
  %exitcond63.not.i = icmp eq i32 %172, %10
  br i1 %exitcond63.not.i, label %element_listgen_nonroot.exit.loopexit, label %26, !llvm.loop !10

element_listgen_nonroot.exit.loopexit:            ; preds = %._crit_edge.i
  br label %element_listgen_nonroot.exit

element_listgen_nonroot.exit:                     ; preds = %element_listgen_nonroot.exit.loopexit, %entry
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %2)
  ret void
}

; Function Attrs: nounwind
define void @live_hierarchy_force_31_kernel_5_struct_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.cpu_block_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.RuntimeContext.692, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 28
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds %struct.ListManager, ptr %6, i64 0, i32 5
  %8 = load i32, ptr %7, align 8
  store ptr %context, ptr %0, align 8
  %9 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  store ptr @function_body, ptr %9, align 8
  %10 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  store ptr %6, ptr %10, align 8
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  store <2 x i32> <i32 32, i32 8>, ptr %11, align 8
  %12 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  store i64 1, ptr %12, align 8
  %13 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 12
  %14 = load ptr, ptr %13, align 8
  %15 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 11
  %16 = load ptr, ptr %15, align 8
  %17 = shl nsw i32 %8, 3
  call void %14(ptr noundef %16, i32 noundef %17, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_struct_for_block_helper) #1
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body(ptr %0, ptr nocapture readnone %1, ptr nocapture readonly %2, i32 %3, i32 %4) #2 {
allocs:
  %5 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %6 = icmp slt i32 %3, %4
  br i1 %6, label %loop_body.lr.ph, label %func_exit

loop_body.lr.ph:                                  ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.692, ptr %0, i64 0, i32 1
  br label %loop_body

loop_body:                                        ; preds = %loop_body_tail, %loop_body.lr.ph
  %.02150 = phi i32 [ %3, %loop_body.lr.ph ], [ %18, %loop_body_tail ]
  %8 = load ptr, ptr %2, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 32
  %10 = sdiv i32 %.02150, 8
  %11 = sext i32 %10 to i64
  %12 = getelementptr inbounds i8, ptr %9, i64 %11
  %13 = load i8, ptr %12, align 1
  %14 = zext i8 %13 to i32
  %15 = and i32 %.02150, 7
  %16 = shl nuw nsw i32 1, %15
  %17 = and i32 %16, %14
  %.not43 = icmp eq i32 %17, 0
  br i1 %.not43, label %loop_body_tail, label %struct_for_body_body

loop_body_tail:                                   ; preds = %after_for, %loop_body
  %18 = add nsw i32 %.02150, 1
  %exitcond54.not = icmp eq i32 %18, %4
  br i1 %exitcond54.not, label %func_exit.loopexit, label %loop_body

func_exit.loopexit:                               ; preds = %loop_body_tail
  br label %func_exit

func_exit:                                        ; preds = %func_exit.loopexit, %allocs
  ret void

struct_for_body_body:                             ; preds = %loop_body
  %19 = load i32, ptr %5, align 4
  %20 = shl i32 %19, 5
  %21 = and i32 %.02150, 31
  %22 = or i32 %20, %21
  %23 = load ptr, ptr %0, align 8
  %24 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %23, i64 0, i32 12, i32 1
  %25 = load ptr, ptr %24, align 8
  %26 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %23, i64 0, i32 12, i32 0, i32 1
  %27 = load i32, ptr %26, align 4
  %28 = sext i32 %27 to i64
  %29 = sext i32 %22 to i64
  %30 = getelementptr i32, ptr %25, i64 %29
  %31 = load i32, ptr %30, align 4
  %32 = add nsw i64 %28, %29
  %33 = getelementptr i32, ptr %25, i64 %32
  %34 = load i32, ptr %33, align 4
  %35 = load ptr, ptr %7, align 8
  %36 = getelementptr inbounds %struct.LLVMRuntime, ptr %35, i64 0, i32 16
  %37 = load ptr, ptr %36, align 8
  %38 = load double, ptr %37, align 8
  %39 = fcmp one double %38, 0.000000e+00
  %40 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %23, i64 0, i32 14, i32 1
  %41 = load ptr, ptr %40, align 8
  %42 = getelementptr i64, ptr %41, i64 5
  %43 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %23, i64 0, i32 15, i32 1
  %44 = load ptr, ptr %43, align 8
  %45 = getelementptr i64, ptr %44, i64 1
  %46 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %23, i64 0, i32 7, i32 1
  %47 = load ptr, ptr %46, align 8
  %48 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %23, i64 0, i32 7, i32 0, i32 1
  %49 = load i32, ptr %48, align 4
  %50 = sext i32 %49 to i64
  %51 = shl nsw i64 %50, 3
  %52 = add nsw i64 %51, %29
  %53 = getelementptr double, ptr %47, i64 %52
  %54 = mul nsw i64 %50, 9
  %55 = add nsw i64 %54, %29
  %56 = getelementptr double, ptr %47, i64 %55
  %57 = mul nsw i64 %50, 10
  %58 = add nsw i64 %57, %29
  %59 = getelementptr double, ptr %47, i64 %58
  %60 = load double, ptr %53, align 8
  %61 = load double, ptr %56, align 8
  %62 = load double, ptr %59, align 8
  %63 = icmp slt i32 %31, %34
  br i1 %63, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %struct_for_body_body
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %23, i64 0, i32 10, i32 1
  %65 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %23, i64 0, i32 10, i32 0, i32 1
  %66 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %23, i64 0, i32 1, i32 1
  %67 = getelementptr { { i32, i32 }, ptr }, ptr %23, i64 0, i32 1
  %68 = getelementptr { { i32, i32 }, ptr }, ptr %23, i64 0, i32 0, i32 1
  %69 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %23, i64 0, i32 2, i32 1
  %70 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %23, i64 0, i32 2, i32 0, i32 1
  %71 = sext i32 %31 to i64
  %wide.trip.count = sext i32 %34 to i64
  %72 = sub nsw i64 %wide.trip.count, %71
  %73 = xor i64 %71, -1
  %xtraiter = and i64 %72, 1
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.lr.ph
  %74 = load ptr, ptr %64, align 8
  %75 = load i32, ptr %65, align 4
  %76 = sext i32 %75 to i64
  %77 = add nsw i64 %71, %76
  %78 = getelementptr i32, ptr %74, i64 %77
  %79 = load i32, ptr %78, align 4
  %80 = load ptr, ptr %66, align 8
  %81 = sext i32 %79 to i64
  %82 = getelementptr i32, ptr %80, i64 %81
  %83 = atomicrmw or ptr %82, i32 0 seq_cst, align 4
  %84 = shl i32 %83, 2
  %85 = load ptr, ptr %67, align 8
  %86 = load i32, ptr %68, align 4
  %87 = sext i32 %84 to i64
  %88 = sext i32 %86 to i64
  %89 = mul nsw i64 %88, %87
  %90 = add nsw i64 %89, %81
  %91 = getelementptr double, ptr %85, i64 %90
  %92 = load double, ptr %91, align 8
  %93 = or i32 %84, 1
  %94 = sext i32 %93 to i64
  %95 = mul nsw i64 %94, %88
  %96 = add nsw i64 %95, %81
  %97 = getelementptr double, ptr %85, i64 %96
  %98 = load double, ptr %97, align 8
  %99 = or i32 %84, 2
  %100 = sext i32 %99 to i64
  %101 = mul nsw i64 %100, %88
  %102 = add nsw i64 %101, %81
  %103 = getelementptr double, ptr %85, i64 %102
  %104 = load double, ptr %103, align 8
  %105 = or i32 %84, 3
  %106 = sext i32 %105 to i64
  %107 = mul nsw i64 %106, %88
  %108 = add nsw i64 %107, %81
  %109 = getelementptr double, ptr %85, i64 %108
  %110 = load double, ptr %109, align 8
  %111 = load ptr, ptr %64, align 8
  %112 = load i32, ptr %65, align 4
  %113 = sext i32 %112 to i64
  %114 = shl nsw i64 %113, 1
  %115 = add nsw i64 %114, %71
  %116 = getelementptr i32, ptr %111, i64 %115
  %117 = load i32, ptr %116, align 4
  %118 = load ptr, ptr %66, align 8
  %119 = sext i32 %117 to i64
  %120 = getelementptr i32, ptr %118, i64 %119
  %121 = atomicrmw or ptr %120, i32 0 seq_cst, align 4
  %122 = shl i32 %121, 2
  %123 = load ptr, ptr %67, align 8
  %124 = load i32, ptr %68, align 4
  %125 = sext i32 %124 to i64
  %126 = or i32 %122, 3
  %127 = sext i32 %126 to i64
  %128 = mul nsw i64 %127, %125
  %129 = add nsw i64 %128, %119
  %130 = getelementptr double, ptr %123, i64 %129
  %131 = load double, ptr %130, align 8
  %132 = load ptr, ptr %64, align 8
  %133 = load i32, ptr %65, align 4
  %134 = sext i32 %133 to i64
  %135 = mul nsw i64 %134, 3
  %136 = add nsw i64 %135, %71
  %137 = getelementptr i32, ptr %132, i64 %136
  %138 = load i32, ptr %137, align 4
  %.not.prol = icmp eq i32 %138, 0
  %139 = select i1 %.not.prol, i32 %79, i32 %117
  %140 = load ptr, ptr %69, align 8
  %141 = load i32, ptr %70, align 4
  %142 = sext i32 %141 to i64
  %143 = shl nsw i64 %142, 3
  %144 = sext i32 %139 to i64
  %145 = add nsw i64 %143, %144
  %146 = getelementptr i32, ptr %140, i64 %145
  %147 = load i32, ptr %146, align 4
  %148 = mul nsw i64 %142, 9
  %149 = add nsw i64 %148, %81
  %150 = getelementptr i32, ptr %140, i64 %149
  %151 = load i32, ptr %150, align 4
  %152 = icmp ne i32 %151, 0
  %153 = or i1 %.not.prol, %152
  %154 = icmp ne i32 %147, 0
  %155 = and i1 %154, %153
  %156 = and i1 %39, %155
  br i1 %156, label %true_block.prol, label %after_if.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %157 = or i32 %122, 2
  %158 = sext i32 %157 to i64
  %159 = mul nsw i64 %158, %125
  %160 = add nsw i64 %159, %119
  %161 = getelementptr double, ptr %123, i64 %160
  %162 = load double, ptr %161, align 8
  %163 = or i32 %122, 1
  %164 = sext i32 %163 to i64
  %165 = mul nsw i64 %164, %125
  %166 = add nsw i64 %165, %119
  %167 = getelementptr double, ptr %123, i64 %166
  %168 = load double, ptr %167, align 8
  %169 = sext i32 %122 to i64
  %170 = mul nsw i64 %125, %169
  %171 = add nsw i64 %170, %119
  %172 = getelementptr double, ptr %123, i64 %171
  %173 = load double, ptr %172, align 8
  %174 = load ptr, ptr %43, align 8
  %175 = getelementptr i64, ptr %174, i64 2
  %176 = atomicrmw add ptr %175, i64 1 seq_cst, align 8
  %177 = fsub double %173, %92
  %178 = load ptr, ptr %46, align 8
  %179 = load i32, ptr %48, align 4
  %180 = sext i32 %179 to i64
  %181 = getelementptr double, ptr %178, i64 %29
  %182 = load double, ptr %181, align 8
  %183 = fsub double %92, %182
  %184 = select i1 %.not.prol, double %183, double %177
  %185 = fmul double %184, %184
  %186 = fsub double %168, %98
  %187 = add nsw i64 %180, %29
  %188 = getelementptr double, ptr %178, i64 %187
  %189 = load double, ptr %188, align 8
  %190 = fsub double %98, %189
  %191 = select i1 %.not.prol, double %190, double %186
  %192 = fmul double %191, %191
  %193 = fadd double %185, %192
  %194 = fsub double %162, %104
  %195 = shl nsw i64 %180, 1
  %196 = add nsw i64 %195, %29
  %197 = getelementptr double, ptr %178, i64 %196
  %198 = load double, ptr %197, align 8
  %199 = fsub double %104, %198
  %200 = select i1 %.not.prol, double %199, double %194
  %201 = fmul double %200, %200
  %202 = fadd double %193, %201
  %203 = fcmp ogt double %202, 0.000000e+00
  br i1 %203, label %true_block1.prol, label %after_if.prol

true_block1.prol:                                 ; preds = %true_block.prol
  %sqrt.prol = tail call double @llvm.sqrt.f64(double %202)
  %204 = fdiv double 1.000000e+00, %sqrt.prol
  %205 = mul nsw i64 %180, 6
  %206 = add nsw i64 %205, %29
  %207 = getelementptr double, ptr %178, i64 %206
  %208 = load double, ptr %207, align 8
  %209 = load ptr, ptr %0, align 8
  %210 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %209, i64 0, i32 11, i32 1
  %211 = load ptr, ptr %210, align 8
  %212 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %209, i64 0, i32 11, i32 0, i32 1
  %213 = load i32, ptr %212, align 4
  %214 = sext i32 %213 to i64
  %215 = getelementptr i64, ptr %211, i64 %71
  %216 = load i64, ptr %215, align 8
  %217 = uitofp i64 %216 to double
  %218 = add nsw i64 %71, %214
  %219 = getelementptr i64, ptr %211, i64 %218
  %220 = load i64, ptr %219, align 8
  %221 = uitofp i64 %220 to double
  %222 = fdiv double %217, %221
  %223 = fmul double %208, %222
  %224 = select i1 %.not.prol, double %110, double %131
  %225 = load double, ptr %37, align 8
  %226 = fmul double %225, %223
  %227 = fmul double %204, %204
  %228 = fmul double %204, %227
  %229 = fmul double %224, %228
  %230 = fmul double %229, %226
  %231 = bitcast double %202 to i64
  %232 = and i64 %231, 9223372036854775807
  %233 = and i64 %231, 9218868437227405312
  %234 = icmp eq i64 %232, 0
  %235 = icmp ne i64 %233, 0
  %236 = icmp ne i64 %233, 9218868437227405312
  %237 = and i1 %235, %236
  %238 = or i1 %234, %237
  br i1 %238, label %after_if6.prol, label %true_block4.prol

true_block4.prol:                                 ; preds = %true_block1.prol
  %239 = load ptr, ptr %40, align 8
  %240 = atomicrmw add ptr %239, i64 1 seq_cst, align 8
  br label %after_if6.prol

after_if6.prol:                                   ; preds = %true_block4.prol, %true_block1.prol
  %241 = bitcast double %204 to i64
  %242 = and i64 %241, 9223372036854775807
  %243 = and i64 %241, 9218868437227405312
  %244 = icmp eq i64 %242, 0
  %245 = icmp ne i64 %243, 0
  %246 = icmp ne i64 %243, 9218868437227405312
  %247 = and i1 %245, %246
  %248 = or i1 %244, %247
  br i1 %248, label %after_if9.prol, label %true_block7.prol

true_block7.prol:                                 ; preds = %after_if6.prol
  %249 = load ptr, ptr %40, align 8
  %250 = atomicrmw add ptr %249, i64 1 seq_cst, align 8
  br label %after_if9.prol

after_if9.prol:                                   ; preds = %true_block7.prol, %after_if6.prol
  %251 = bitcast double %223 to i64
  %252 = and i64 %251, 9223372036854775807
  %253 = and i64 %251, 9218868437227405312
  %254 = icmp eq i64 %252, 0
  %255 = icmp ne i64 %253, 0
  %256 = icmp ne i64 %253, 9218868437227405312
  %257 = and i1 %255, %256
  %258 = or i1 %254, %257
  br i1 %258, label %after_if12.prol, label %true_block10.prol

true_block10.prol:                                ; preds = %after_if9.prol
  %259 = load ptr, ptr %40, align 8
  %260 = atomicrmw add ptr %259, i64 1 seq_cst, align 8
  br label %after_if12.prol

after_if12.prol:                                  ; preds = %true_block10.prol, %after_if9.prol
  %261 = bitcast double %224 to i64
  %262 = and i64 %261, 9223372036854775807
  %263 = and i64 %261, 9218868437227405312
  %264 = icmp eq i64 %262, 0
  %265 = icmp ne i64 %263, 0
  %266 = icmp ne i64 %263, 9218868437227405312
  %267 = and i1 %265, %266
  %268 = or i1 %264, %267
  br i1 %268, label %after_if15.prol, label %true_block13.prol

true_block13.prol:                                ; preds = %after_if12.prol
  %269 = load ptr, ptr %40, align 8
  %270 = atomicrmw add ptr %269, i64 1 seq_cst, align 8
  br label %after_if15.prol

after_if15.prol:                                  ; preds = %true_block13.prol, %after_if12.prol
  %271 = bitcast double %230 to i64
  %272 = and i64 %271, 9223372036854775807
  %273 = and i64 %271, 9218868437227405312
  %274 = icmp eq i64 %272, 0
  %275 = icmp ne i64 %273, 0
  %276 = icmp ne i64 %273, 9218868437227405312
  %277 = and i1 %275, %276
  %278 = or i1 %274, %277
  br i1 %278, label %after_if18.prol, label %true_block16.prol

true_block16.prol:                                ; preds = %after_if15.prol
  %279 = load ptr, ptr %40, align 8
  %280 = atomicrmw add ptr %279, i64 1 seq_cst, align 8
  br label %after_if18.prol

after_if18.prol:                                  ; preds = %true_block16.prol, %after_if15.prol
  %281 = fmul double %184, %230
  %282 = bitcast double %281 to i64
  %283 = and i64 %282, 9223372036854775807
  %284 = and i64 %282, 9218868437227405312
  %285 = icmp eq i64 %283, 0
  %286 = icmp ne i64 %284, 0
  %287 = icmp ne i64 %284, 9218868437227405312
  %288 = and i1 %286, %287
  %289 = or i1 %285, %288
  br i1 %289, label %after_if21.prol, label %true_block19.prol

true_block19.prol:                                ; preds = %after_if18.prol
  %290 = load ptr, ptr %40, align 8
  %291 = atomicrmw add ptr %290, i64 1 seq_cst, align 8
  br label %after_if21.prol

after_if21.prol:                                  ; preds = %true_block19.prol, %after_if18.prol
  %292 = fmul double %191, %230
  %293 = bitcast double %292 to i64
  %294 = and i64 %293, 9223372036854775807
  %295 = and i64 %293, 9218868437227405312
  %296 = icmp eq i64 %294, 0
  %297 = icmp ne i64 %295, 0
  %298 = icmp ne i64 %295, 9218868437227405312
  %299 = and i1 %297, %298
  %300 = or i1 %296, %299
  br i1 %300, label %after_if24.prol, label %true_block22.prol

true_block22.prol:                                ; preds = %after_if21.prol
  %301 = load ptr, ptr %40, align 8
  %302 = atomicrmw add ptr %301, i64 1 seq_cst, align 8
  br label %after_if24.prol

after_if24.prol:                                  ; preds = %true_block22.prol, %after_if21.prol
  %303 = fmul double %200, %230
  %304 = bitcast double %303 to i64
  %305 = and i64 %304, 9223372036854775807
  %306 = and i64 %304, 9218868437227405312
  %307 = icmp eq i64 %305, 0
  %308 = icmp ne i64 %306, 0
  %309 = icmp ne i64 %306, 9218868437227405312
  %310 = and i1 %308, %309
  %311 = or i1 %307, %310
  br i1 %311, label %after_if.prol, label %true_block25.prol

true_block25.prol:                                ; preds = %after_if24.prol
  %312 = load ptr, ptr %40, align 8
  %313 = atomicrmw add ptr %312, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block25.prol, %after_if24.prol, %true_block.prol, %for_loop_body.prol
  %.016.prol = phi double [ 0.000000e+00, %true_block.prol ], [ 0.000000e+00, %for_loop_body.prol ], [ %281, %after_if24.prol ], [ %281, %true_block25.prol ]
  %.015.prol = phi double [ 0.000000e+00, %true_block.prol ], [ 0.000000e+00, %for_loop_body.prol ], [ %292, %after_if24.prol ], [ %292, %true_block25.prol ]
  %.0.prol = phi double [ 0.000000e+00, %true_block.prol ], [ 0.000000e+00, %for_loop_body.prol ], [ %303, %after_if24.prol ], [ %303, %true_block25.prol ]
  %314 = atomicrmw add ptr %42, i64 1 seq_cst, align 8
  %315 = atomicrmw add ptr %45, i64 1 seq_cst, align 8
  %316 = fadd double %60, %.016.prol
  %317 = fadd double %61, %.015.prol
  %318 = fadd double %62, %.0.prol
  %indvars.iv.next.prol = add nsw i64 %71, 1
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %after_if.prol, %for_loop_body.lr.ph
  %.lcssa60.unr = phi double [ undef, %for_loop_body.lr.ph ], [ %316, %after_if.prol ]
  %.lcssa59.unr = phi double [ undef, %for_loop_body.lr.ph ], [ %317, %after_if.prol ]
  %.lcssa.unr = phi double [ undef, %for_loop_body.lr.ph ], [ %318, %after_if.prol ]
  %indvars.iv.unr = phi i64 [ %71, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %after_if.prol ]
  %.01846.unr = phi double [ %62, %for_loop_body.lr.ph ], [ %318, %after_if.prol ]
  %.01945.unr = phi double [ %61, %for_loop_body.lr.ph ], [ %317, %after_if.prol ]
  %.02044.unr = phi double [ %60, %for_loop_body.lr.ph ], [ %316, %after_if.prol ]
  %319 = sub nsw i64 0, %wide.trip.count
  %320 = icmp eq i64 %73, %319
  br i1 %320, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.1, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.1, %after_if.1 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %.01846 = phi double [ %695, %after_if.1 ], [ %.01846.unr, %for_loop_body.preheader ]
  %.01945 = phi double [ %694, %after_if.1 ], [ %.01945.unr, %for_loop_body.preheader ]
  %.02044 = phi double [ %693, %after_if.1 ], [ %.02044.unr, %for_loop_body.preheader ]
  %321 = load ptr, ptr %64, align 8
  %322 = load i32, ptr %65, align 4
  %323 = sext i32 %322 to i64
  %324 = add nsw i64 %indvars.iv, %323
  %325 = getelementptr i32, ptr %321, i64 %324
  %326 = load i32, ptr %325, align 4
  %327 = load ptr, ptr %66, align 8
  %328 = sext i32 %326 to i64
  %329 = getelementptr i32, ptr %327, i64 %328
  %330 = atomicrmw or ptr %329, i32 0 seq_cst, align 4
  %331 = shl i32 %330, 2
  %332 = load ptr, ptr %67, align 8
  %333 = load i32, ptr %68, align 4
  %334 = sext i32 %331 to i64
  %335 = sext i32 %333 to i64
  %336 = mul nsw i64 %335, %334
  %337 = add nsw i64 %336, %328
  %338 = getelementptr double, ptr %332, i64 %337
  %339 = load double, ptr %338, align 8
  %340 = or i32 %331, 1
  %341 = sext i32 %340 to i64
  %342 = mul nsw i64 %341, %335
  %343 = add nsw i64 %342, %328
  %344 = getelementptr double, ptr %332, i64 %343
  %345 = load double, ptr %344, align 8
  %346 = or i32 %331, 2
  %347 = sext i32 %346 to i64
  %348 = mul nsw i64 %347, %335
  %349 = add nsw i64 %348, %328
  %350 = getelementptr double, ptr %332, i64 %349
  %351 = load double, ptr %350, align 8
  %352 = or i32 %331, 3
  %353 = sext i32 %352 to i64
  %354 = mul nsw i64 %353, %335
  %355 = add nsw i64 %354, %328
  %356 = getelementptr double, ptr %332, i64 %355
  %357 = load double, ptr %356, align 8
  %358 = load ptr, ptr %64, align 8
  %359 = load i32, ptr %65, align 4
  %360 = sext i32 %359 to i64
  %361 = shl nsw i64 %360, 3
  %uglygep = getelementptr i8, ptr %358, i64 %361
  %362 = shl i64 %indvars.iv, 2
  %uglygep64 = getelementptr i8, ptr %uglygep, i64 %362
  %363 = load i32, ptr %uglygep64, align 4
  %364 = load ptr, ptr %66, align 8
  %365 = sext i32 %363 to i64
  %366 = getelementptr i32, ptr %364, i64 %365
  %367 = atomicrmw or ptr %366, i32 0 seq_cst, align 4
  %368 = shl i32 %367, 2
  %369 = load ptr, ptr %67, align 8
  %370 = load i32, ptr %68, align 4
  %371 = sext i32 %370 to i64
  %372 = or i32 %368, 3
  %373 = sext i32 %372 to i64
  %374 = mul nsw i64 %373, %371
  %375 = add nsw i64 %374, %365
  %376 = getelementptr double, ptr %369, i64 %375
  %377 = load double, ptr %376, align 8
  %378 = load ptr, ptr %64, align 8
  %379 = load i32, ptr %65, align 4
  %380 = sext i32 %379 to i64
  %381 = mul nsw i64 %380, 12
  %uglygep65 = getelementptr i8, ptr %378, i64 %381
  %uglygep66 = getelementptr i8, ptr %uglygep65, i64 %362
  %382 = load i32, ptr %uglygep66, align 4
  %.not = icmp eq i32 %382, 0
  %383 = select i1 %.not, i32 %326, i32 %363
  %384 = load ptr, ptr %69, align 8
  %385 = load i32, ptr %70, align 4
  %386 = sext i32 %385 to i64
  %387 = shl nsw i64 %386, 3
  %388 = sext i32 %383 to i64
  %389 = add nsw i64 %387, %388
  %390 = getelementptr i32, ptr %384, i64 %389
  %391 = load i32, ptr %390, align 4
  %392 = mul nsw i64 %386, 9
  %393 = add nsw i64 %392, %328
  %394 = getelementptr i32, ptr %384, i64 %393
  %395 = load i32, ptr %394, align 4
  %396 = icmp ne i32 %395, 0
  %397 = or i1 %.not, %396
  %398 = icmp ne i32 %391, 0
  %399 = and i1 %398, %397
  %400 = and i1 %39, %399
  br i1 %400, label %true_block, label %after_if

after_for.loopexit:                               ; preds = %after_if.1
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %struct_for_body_body
  %.020.lcssa = phi double [ %60, %struct_for_body_body ], [ %.lcssa60.unr, %for_loop_body.prol.loopexit ], [ %693, %after_for.loopexit ]
  %.019.lcssa = phi double [ %61, %struct_for_body_body ], [ %.lcssa59.unr, %for_loop_body.prol.loopexit ], [ %694, %after_for.loopexit ]
  %.018.lcssa = phi double [ %62, %struct_for_body_body ], [ %.lcssa.unr, %for_loop_body.prol.loopexit ], [ %695, %after_for.loopexit ]
  store double %.018.lcssa, ptr %59, align 8
  store double %.019.lcssa, ptr %56, align 8
  store double %.020.lcssa, ptr %53, align 8
  br label %loop_body_tail

true_block:                                       ; preds = %for_loop_body
  %401 = or i32 %368, 2
  %402 = sext i32 %401 to i64
  %403 = mul nsw i64 %402, %371
  %404 = add nsw i64 %403, %365
  %405 = getelementptr double, ptr %369, i64 %404
  %406 = load double, ptr %405, align 8
  %407 = or i32 %368, 1
  %408 = sext i32 %407 to i64
  %409 = mul nsw i64 %408, %371
  %410 = add nsw i64 %409, %365
  %411 = getelementptr double, ptr %369, i64 %410
  %412 = load double, ptr %411, align 8
  %413 = sext i32 %368 to i64
  %414 = mul nsw i64 %371, %413
  %415 = add nsw i64 %414, %365
  %416 = getelementptr double, ptr %369, i64 %415
  %417 = load double, ptr %416, align 8
  %418 = load ptr, ptr %43, align 8
  %419 = getelementptr i64, ptr %418, i64 2
  %420 = atomicrmw add ptr %419, i64 1 seq_cst, align 8
  %421 = fsub double %417, %339
  %422 = load ptr, ptr %46, align 8
  %423 = load i32, ptr %48, align 4
  %424 = sext i32 %423 to i64
  %425 = getelementptr double, ptr %422, i64 %29
  %426 = load double, ptr %425, align 8
  %427 = fsub double %339, %426
  %428 = select i1 %.not, double %427, double %421
  %429 = fmul double %428, %428
  %430 = fsub double %412, %345
  %431 = add nsw i64 %424, %29
  %432 = getelementptr double, ptr %422, i64 %431
  %433 = load double, ptr %432, align 8
  %434 = fsub double %345, %433
  %435 = select i1 %.not, double %434, double %430
  %436 = fmul double %435, %435
  %437 = fadd double %429, %436
  %438 = fsub double %406, %351
  %439 = shl nsw i64 %424, 1
  %440 = add nsw i64 %439, %29
  %441 = getelementptr double, ptr %422, i64 %440
  %442 = load double, ptr %441, align 8
  %443 = fsub double %351, %442
  %444 = select i1 %.not, double %443, double %438
  %445 = fmul double %444, %444
  %446 = fadd double %437, %445
  %447 = fcmp ogt double %446, 0.000000e+00
  br i1 %447, label %true_block1, label %after_if

after_if:                                         ; preds = %true_block25, %after_if24, %true_block, %for_loop_body
  %.016 = phi double [ 0.000000e+00, %true_block ], [ 0.000000e+00, %for_loop_body ], [ %773, %after_if24 ], [ %773, %true_block25 ]
  %.015 = phi double [ 0.000000e+00, %true_block ], [ 0.000000e+00, %for_loop_body ], [ %784, %after_if24 ], [ %784, %true_block25 ]
  %.0 = phi double [ 0.000000e+00, %true_block ], [ 0.000000e+00, %for_loop_body ], [ %795, %after_if24 ], [ %795, %true_block25 ]
  %448 = atomicrmw add ptr %42, i64 1 seq_cst, align 8
  %449 = atomicrmw add ptr %45, i64 1 seq_cst, align 8
  %450 = fadd double %.02044, %.016
  %451 = fadd double %.01945, %.015
  %452 = fadd double %.01846, %.0
  %453 = load ptr, ptr %64, align 8
  %454 = load i32, ptr %65, align 4
  %455 = sext i32 %454 to i64
  %456 = add i64 %indvars.iv, %455
  %457 = getelementptr i32, ptr %453, i64 %456
  %458 = getelementptr i32, ptr %457, i64 1
  %459 = load i32, ptr %458, align 4
  %460 = load ptr, ptr %66, align 8
  %461 = sext i32 %459 to i64
  %462 = getelementptr i32, ptr %460, i64 %461
  %463 = atomicrmw or ptr %462, i32 0 seq_cst, align 4
  %464 = shl i32 %463, 2
  %465 = load ptr, ptr %67, align 8
  %466 = load i32, ptr %68, align 4
  %467 = sext i32 %464 to i64
  %468 = sext i32 %466 to i64
  %469 = mul nsw i64 %468, %467
  %470 = add nsw i64 %469, %461
  %471 = getelementptr double, ptr %465, i64 %470
  %472 = load double, ptr %471, align 8
  %473 = or i32 %464, 1
  %474 = sext i32 %473 to i64
  %475 = mul nsw i64 %474, %468
  %476 = add nsw i64 %475, %461
  %477 = getelementptr double, ptr %465, i64 %476
  %478 = load double, ptr %477, align 8
  %479 = or i32 %464, 2
  %480 = sext i32 %479 to i64
  %481 = mul nsw i64 %480, %468
  %482 = add nsw i64 %481, %461
  %483 = getelementptr double, ptr %465, i64 %482
  %484 = load double, ptr %483, align 8
  %485 = or i32 %464, 3
  %486 = sext i32 %485 to i64
  %487 = mul nsw i64 %486, %468
  %488 = add nsw i64 %487, %461
  %489 = getelementptr double, ptr %465, i64 %488
  %490 = load double, ptr %489, align 8
  %491 = load ptr, ptr %64, align 8
  %492 = load i32, ptr %65, align 4
  %493 = sext i32 %492 to i64
  %494 = shl nsw i64 %493, 3
  %uglygep73 = getelementptr i8, ptr %491, i64 %494
  %uglygep74 = getelementptr i8, ptr %uglygep73, i64 %362
  %uglygep75 = getelementptr i8, ptr %uglygep74, i64 4
  %495 = load i32, ptr %uglygep75, align 4
  %496 = load ptr, ptr %66, align 8
  %497 = sext i32 %495 to i64
  %498 = getelementptr i32, ptr %496, i64 %497
  %499 = atomicrmw or ptr %498, i32 0 seq_cst, align 4
  %500 = shl i32 %499, 2
  %501 = load ptr, ptr %67, align 8
  %502 = load i32, ptr %68, align 4
  %503 = sext i32 %502 to i64
  %504 = or i32 %500, 3
  %505 = sext i32 %504 to i64
  %506 = mul nsw i64 %505, %503
  %507 = add nsw i64 %506, %497
  %508 = getelementptr double, ptr %501, i64 %507
  %509 = load double, ptr %508, align 8
  %510 = load ptr, ptr %64, align 8
  %511 = load i32, ptr %65, align 4
  %512 = sext i32 %511 to i64
  %513 = mul nsw i64 %512, 12
  %uglygep70 = getelementptr i8, ptr %510, i64 %513
  %uglygep71 = getelementptr i8, ptr %uglygep70, i64 %362
  %uglygep72 = getelementptr i8, ptr %uglygep71, i64 4
  %514 = load i32, ptr %uglygep72, align 4
  %.not.1 = icmp eq i32 %514, 0
  %515 = select i1 %.not.1, i32 %459, i32 %495
  %516 = load ptr, ptr %69, align 8
  %517 = load i32, ptr %70, align 4
  %518 = sext i32 %517 to i64
  %519 = shl nsw i64 %518, 3
  %520 = sext i32 %515 to i64
  %521 = add nsw i64 %519, %520
  %522 = getelementptr i32, ptr %516, i64 %521
  %523 = load i32, ptr %522, align 4
  %524 = mul nsw i64 %518, 9
  %525 = add nsw i64 %524, %461
  %526 = getelementptr i32, ptr %516, i64 %525
  %527 = load i32, ptr %526, align 4
  %528 = icmp ne i32 %527, 0
  %529 = or i1 %.not.1, %528
  %530 = icmp ne i32 %523, 0
  %531 = and i1 %530, %529
  %532 = and i1 %39, %531
  br i1 %532, label %true_block.1, label %after_if.1

true_block.1:                                     ; preds = %after_if
  %533 = or i32 %500, 2
  %534 = sext i32 %533 to i64
  %535 = mul nsw i64 %534, %503
  %536 = add nsw i64 %535, %497
  %537 = getelementptr double, ptr %501, i64 %536
  %538 = load double, ptr %537, align 8
  %539 = or i32 %500, 1
  %540 = sext i32 %539 to i64
  %541 = mul nsw i64 %540, %503
  %542 = add nsw i64 %541, %497
  %543 = getelementptr double, ptr %501, i64 %542
  %544 = load double, ptr %543, align 8
  %545 = sext i32 %500 to i64
  %546 = mul nsw i64 %503, %545
  %547 = add nsw i64 %546, %497
  %548 = getelementptr double, ptr %501, i64 %547
  %549 = load double, ptr %548, align 8
  %550 = load ptr, ptr %43, align 8
  %551 = getelementptr i64, ptr %550, i64 2
  %552 = atomicrmw add ptr %551, i64 1 seq_cst, align 8
  %553 = fsub double %549, %472
  %554 = load ptr, ptr %46, align 8
  %555 = load i32, ptr %48, align 4
  %556 = sext i32 %555 to i64
  %557 = getelementptr double, ptr %554, i64 %29
  %558 = load double, ptr %557, align 8
  %559 = fsub double %472, %558
  %560 = select i1 %.not.1, double %559, double %553
  %561 = fmul double %560, %560
  %562 = fsub double %544, %478
  %563 = add nsw i64 %556, %29
  %564 = getelementptr double, ptr %554, i64 %563
  %565 = load double, ptr %564, align 8
  %566 = fsub double %478, %565
  %567 = select i1 %.not.1, double %566, double %562
  %568 = fmul double %567, %567
  %569 = fadd double %561, %568
  %570 = fsub double %538, %484
  %571 = shl nsw i64 %556, 1
  %572 = add nsw i64 %571, %29
  %573 = getelementptr double, ptr %554, i64 %572
  %574 = load double, ptr %573, align 8
  %575 = fsub double %484, %574
  %576 = select i1 %.not.1, double %575, double %570
  %577 = fmul double %576, %576
  %578 = fadd double %569, %577
  %579 = fcmp ogt double %578, 0.000000e+00
  br i1 %579, label %true_block1.1, label %after_if.1

true_block1.1:                                    ; preds = %true_block.1
  %sqrt.1 = tail call double @llvm.sqrt.f64(double %578)
  %580 = fdiv double 1.000000e+00, %sqrt.1
  %581 = mul nsw i64 %556, 6
  %582 = add nsw i64 %581, %29
  %583 = getelementptr double, ptr %554, i64 %582
  %584 = load double, ptr %583, align 8
  %585 = load ptr, ptr %0, align 8
  %586 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %585, i64 0, i32 11, i32 1
  %587 = load ptr, ptr %586, align 8
  %588 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %585, i64 0, i32 11, i32 0, i32 1
  %589 = load i32, ptr %588, align 4
  %590 = sext i32 %589 to i64
  %uglygep68 = getelementptr i8, ptr %587, i64 8
  %591 = shl i64 %indvars.iv, 3
  %uglygep69 = getelementptr i8, ptr %uglygep68, i64 %591
  %592 = load i64, ptr %uglygep69, align 8
  %593 = uitofp i64 %592 to double
  %594 = add i64 %indvars.iv, %590
  %595 = getelementptr i64, ptr %587, i64 %594
  %596 = getelementptr i64, ptr %595, i64 1
  %597 = load i64, ptr %596, align 8
  %598 = uitofp i64 %597 to double
  %599 = fdiv double %593, %598
  %600 = fmul double %584, %599
  %601 = select i1 %.not.1, double %490, double %509
  %602 = load double, ptr %37, align 8
  %603 = fmul double %602, %600
  %604 = fmul double %580, %580
  %605 = fmul double %580, %604
  %606 = fmul double %601, %605
  %607 = fmul double %606, %603
  %608 = bitcast double %578 to i64
  %609 = and i64 %608, 9223372036854775807
  %610 = and i64 %608, 9218868437227405312
  %611 = icmp eq i64 %609, 0
  %612 = icmp ne i64 %610, 0
  %613 = icmp ne i64 %610, 9218868437227405312
  %614 = and i1 %612, %613
  %615 = or i1 %611, %614
  br i1 %615, label %after_if6.1, label %true_block4.1

true_block4.1:                                    ; preds = %true_block1.1
  %616 = load ptr, ptr %40, align 8
  %617 = atomicrmw add ptr %616, i64 1 seq_cst, align 8
  br label %after_if6.1

after_if6.1:                                      ; preds = %true_block4.1, %true_block1.1
  %618 = bitcast double %580 to i64
  %619 = and i64 %618, 9223372036854775807
  %620 = and i64 %618, 9218868437227405312
  %621 = icmp eq i64 %619, 0
  %622 = icmp ne i64 %620, 0
  %623 = icmp ne i64 %620, 9218868437227405312
  %624 = and i1 %622, %623
  %625 = or i1 %621, %624
  br i1 %625, label %after_if9.1, label %true_block7.1

true_block7.1:                                    ; preds = %after_if6.1
  %626 = load ptr, ptr %40, align 8
  %627 = atomicrmw add ptr %626, i64 1 seq_cst, align 8
  br label %after_if9.1

after_if9.1:                                      ; preds = %true_block7.1, %after_if6.1
  %628 = bitcast double %600 to i64
  %629 = and i64 %628, 9223372036854775807
  %630 = and i64 %628, 9218868437227405312
  %631 = icmp eq i64 %629, 0
  %632 = icmp ne i64 %630, 0
  %633 = icmp ne i64 %630, 9218868437227405312
  %634 = and i1 %632, %633
  %635 = or i1 %631, %634
  br i1 %635, label %after_if12.1, label %true_block10.1

true_block10.1:                                   ; preds = %after_if9.1
  %636 = load ptr, ptr %40, align 8
  %637 = atomicrmw add ptr %636, i64 1 seq_cst, align 8
  br label %after_if12.1

after_if12.1:                                     ; preds = %true_block10.1, %after_if9.1
  %638 = bitcast double %601 to i64
  %639 = and i64 %638, 9223372036854775807
  %640 = and i64 %638, 9218868437227405312
  %641 = icmp eq i64 %639, 0
  %642 = icmp ne i64 %640, 0
  %643 = icmp ne i64 %640, 9218868437227405312
  %644 = and i1 %642, %643
  %645 = or i1 %641, %644
  br i1 %645, label %after_if15.1, label %true_block13.1

true_block13.1:                                   ; preds = %after_if12.1
  %646 = load ptr, ptr %40, align 8
  %647 = atomicrmw add ptr %646, i64 1 seq_cst, align 8
  br label %after_if15.1

after_if15.1:                                     ; preds = %true_block13.1, %after_if12.1
  %648 = bitcast double %607 to i64
  %649 = and i64 %648, 9223372036854775807
  %650 = and i64 %648, 9218868437227405312
  %651 = icmp eq i64 %649, 0
  %652 = icmp ne i64 %650, 0
  %653 = icmp ne i64 %650, 9218868437227405312
  %654 = and i1 %652, %653
  %655 = or i1 %651, %654
  br i1 %655, label %after_if18.1, label %true_block16.1

true_block16.1:                                   ; preds = %after_if15.1
  %656 = load ptr, ptr %40, align 8
  %657 = atomicrmw add ptr %656, i64 1 seq_cst, align 8
  br label %after_if18.1

after_if18.1:                                     ; preds = %true_block16.1, %after_if15.1
  %658 = fmul double %560, %607
  %659 = bitcast double %658 to i64
  %660 = and i64 %659, 9223372036854775807
  %661 = and i64 %659, 9218868437227405312
  %662 = icmp eq i64 %660, 0
  %663 = icmp ne i64 %661, 0
  %664 = icmp ne i64 %661, 9218868437227405312
  %665 = and i1 %663, %664
  %666 = or i1 %662, %665
  br i1 %666, label %after_if21.1, label %true_block19.1

true_block19.1:                                   ; preds = %after_if18.1
  %667 = load ptr, ptr %40, align 8
  %668 = atomicrmw add ptr %667, i64 1 seq_cst, align 8
  br label %after_if21.1

after_if21.1:                                     ; preds = %true_block19.1, %after_if18.1
  %669 = fmul double %567, %607
  %670 = bitcast double %669 to i64
  %671 = and i64 %670, 9223372036854775807
  %672 = and i64 %670, 9218868437227405312
  %673 = icmp eq i64 %671, 0
  %674 = icmp ne i64 %672, 0
  %675 = icmp ne i64 %672, 9218868437227405312
  %676 = and i1 %674, %675
  %677 = or i1 %673, %676
  br i1 %677, label %after_if24.1, label %true_block22.1

true_block22.1:                                   ; preds = %after_if21.1
  %678 = load ptr, ptr %40, align 8
  %679 = atomicrmw add ptr %678, i64 1 seq_cst, align 8
  br label %after_if24.1

after_if24.1:                                     ; preds = %true_block22.1, %after_if21.1
  %680 = fmul double %576, %607
  %681 = bitcast double %680 to i64
  %682 = and i64 %681, 9223372036854775807
  %683 = and i64 %681, 9218868437227405312
  %684 = icmp eq i64 %682, 0
  %685 = icmp ne i64 %683, 0
  %686 = icmp ne i64 %683, 9218868437227405312
  %687 = and i1 %685, %686
  %688 = or i1 %684, %687
  br i1 %688, label %after_if.1, label %true_block25.1

true_block25.1:                                   ; preds = %after_if24.1
  %689 = load ptr, ptr %40, align 8
  %690 = atomicrmw add ptr %689, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block25.1, %after_if24.1, %true_block.1, %after_if
  %.016.1 = phi double [ 0.000000e+00, %true_block.1 ], [ 0.000000e+00, %after_if ], [ %658, %after_if24.1 ], [ %658, %true_block25.1 ]
  %.015.1 = phi double [ 0.000000e+00, %true_block.1 ], [ 0.000000e+00, %after_if ], [ %669, %after_if24.1 ], [ %669, %true_block25.1 ]
  %.0.1 = phi double [ 0.000000e+00, %true_block.1 ], [ 0.000000e+00, %after_if ], [ %680, %after_if24.1 ], [ %680, %true_block25.1 ]
  %691 = atomicrmw add ptr %42, i64 1 seq_cst, align 8
  %692 = atomicrmw add ptr %45, i64 1 seq_cst, align 8
  %693 = fadd double %450, %.016.1
  %694 = fadd double %451, %.015.1
  %695 = fadd double %452, %.0.1
  %indvars.iv.next.1 = add nsw i64 %indvars.iv, 2
  %exitcond.not.1 = icmp eq i64 %wide.trip.count, %indvars.iv.next.1
  br i1 %exitcond.not.1, label %after_for.loopexit, label %for_loop_body

true_block1:                                      ; preds = %true_block
  %sqrt = tail call double @llvm.sqrt.f64(double %446)
  %696 = fdiv double 1.000000e+00, %sqrt
  %697 = mul nsw i64 %424, 6
  %698 = add nsw i64 %697, %29
  %699 = getelementptr double, ptr %422, i64 %698
  %700 = load double, ptr %699, align 8
  %701 = load ptr, ptr %0, align 8
  %702 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %701, i64 0, i32 11, i32 1
  %703 = load ptr, ptr %702, align 8
  %704 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %701, i64 0, i32 11, i32 0, i32 1
  %705 = load i32, ptr %704, align 4
  %706 = sext i32 %705 to i64
  %707 = shl i64 %indvars.iv, 3
  %uglygep67 = getelementptr i8, ptr %703, i64 %707
  %708 = load i64, ptr %uglygep67, align 8
  %709 = uitofp i64 %708 to double
  %710 = add nsw i64 %indvars.iv, %706
  %711 = getelementptr i64, ptr %703, i64 %710
  %712 = load i64, ptr %711, align 8
  %713 = uitofp i64 %712 to double
  %714 = fdiv double %709, %713
  %715 = fmul double %700, %714
  %716 = select i1 %.not, double %357, double %377
  %717 = load double, ptr %37, align 8
  %718 = fmul double %717, %715
  %719 = fmul double %696, %696
  %720 = fmul double %696, %719
  %721 = fmul double %716, %720
  %722 = fmul double %721, %718
  %723 = bitcast double %446 to i64
  %724 = and i64 %723, 9223372036854775807
  %725 = and i64 %723, 9218868437227405312
  %726 = icmp eq i64 %724, 0
  %727 = icmp ne i64 %725, 0
  %728 = icmp ne i64 %725, 9218868437227405312
  %729 = and i1 %727, %728
  %730 = or i1 %726, %729
  br i1 %730, label %after_if6, label %true_block4

true_block4:                                      ; preds = %true_block1
  %731 = load ptr, ptr %40, align 8
  %732 = atomicrmw add ptr %731, i64 1 seq_cst, align 8
  br label %after_if6

after_if6:                                        ; preds = %true_block4, %true_block1
  %733 = bitcast double %696 to i64
  %734 = and i64 %733, 9223372036854775807
  %735 = and i64 %733, 9218868437227405312
  %736 = icmp eq i64 %734, 0
  %737 = icmp ne i64 %735, 0
  %738 = icmp ne i64 %735, 9218868437227405312
  %739 = and i1 %737, %738
  %740 = or i1 %736, %739
  br i1 %740, label %after_if9, label %true_block7

true_block7:                                      ; preds = %after_if6
  %741 = load ptr, ptr %40, align 8
  %742 = atomicrmw add ptr %741, i64 1 seq_cst, align 8
  br label %after_if9

after_if9:                                        ; preds = %true_block7, %after_if6
  %743 = bitcast double %715 to i64
  %744 = and i64 %743, 9223372036854775807
  %745 = and i64 %743, 9218868437227405312
  %746 = icmp eq i64 %744, 0
  %747 = icmp ne i64 %745, 0
  %748 = icmp ne i64 %745, 9218868437227405312
  %749 = and i1 %747, %748
  %750 = or i1 %746, %749
  br i1 %750, label %after_if12, label %true_block10

true_block10:                                     ; preds = %after_if9
  %751 = load ptr, ptr %40, align 8
  %752 = atomicrmw add ptr %751, i64 1 seq_cst, align 8
  br label %after_if12

after_if12:                                       ; preds = %true_block10, %after_if9
  %753 = bitcast double %716 to i64
  %754 = and i64 %753, 9223372036854775807
  %755 = and i64 %753, 9218868437227405312
  %756 = icmp eq i64 %754, 0
  %757 = icmp ne i64 %755, 0
  %758 = icmp ne i64 %755, 9218868437227405312
  %759 = and i1 %757, %758
  %760 = or i1 %756, %759
  br i1 %760, label %after_if15, label %true_block13

true_block13:                                     ; preds = %after_if12
  %761 = load ptr, ptr %40, align 8
  %762 = atomicrmw add ptr %761, i64 1 seq_cst, align 8
  br label %after_if15

after_if15:                                       ; preds = %true_block13, %after_if12
  %763 = bitcast double %722 to i64
  %764 = and i64 %763, 9223372036854775807
  %765 = and i64 %763, 9218868437227405312
  %766 = icmp eq i64 %764, 0
  %767 = icmp ne i64 %765, 0
  %768 = icmp ne i64 %765, 9218868437227405312
  %769 = and i1 %767, %768
  %770 = or i1 %766, %769
  br i1 %770, label %after_if18, label %true_block16

true_block16:                                     ; preds = %after_if15
  %771 = load ptr, ptr %40, align 8
  %772 = atomicrmw add ptr %771, i64 1 seq_cst, align 8
  br label %after_if18

after_if18:                                       ; preds = %true_block16, %after_if15
  %773 = fmul double %428, %722
  %774 = bitcast double %773 to i64
  %775 = and i64 %774, 9223372036854775807
  %776 = and i64 %774, 9218868437227405312
  %777 = icmp eq i64 %775, 0
  %778 = icmp ne i64 %776, 0
  %779 = icmp ne i64 %776, 9218868437227405312
  %780 = and i1 %778, %779
  %781 = or i1 %777, %780
  br i1 %781, label %after_if21, label %true_block19

true_block19:                                     ; preds = %after_if18
  %782 = load ptr, ptr %40, align 8
  %783 = atomicrmw add ptr %782, i64 1 seq_cst, align 8
  br label %after_if21

after_if21:                                       ; preds = %true_block19, %after_if18
  %784 = fmul double %435, %722
  %785 = bitcast double %784 to i64
  %786 = and i64 %785, 9223372036854775807
  %787 = and i64 %785, 9218868437227405312
  %788 = icmp eq i64 %786, 0
  %789 = icmp ne i64 %787, 0
  %790 = icmp ne i64 %787, 9218868437227405312
  %791 = and i1 %789, %790
  %792 = or i1 %788, %791
  br i1 %792, label %after_if24, label %true_block22

true_block22:                                     ; preds = %after_if21
  %793 = load ptr, ptr %40, align 8
  %794 = atomicrmw add ptr %793, i64 1 seq_cst, align 8
  br label %after_if24

after_if24:                                       ; preds = %true_block22, %after_if21
  %795 = fmul double %444, %722
  %796 = bitcast double %795 to i64
  %797 = and i64 %796, 9223372036854775807
  %798 = and i64 %796, 9218868437227405312
  %799 = icmp eq i64 %797, 0
  %800 = icmp ne i64 %798, 0
  %801 = icmp ne i64 %798, 9218868437227405312
  %802 = and i1 %800, %801
  %803 = or i1 %799, %802
  br i1 %803, label %after_if, label %true_block25

true_block25:                                     ; preds = %after_if24
  %804 = load ptr, ptr %40, align 8
  %805 = atomicrmw add ptr %804, i64 1 seq_cst, align 8
  br label %after_if
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.sqrt.f64(double) #3

; Function Attrs: argmemonly mustprogress nofree norecurse nosync nounwind willreturn
define internal fastcc void @S27_refine_coordinates(ptr nocapture readonly %0, ptr nocapture writeonly %1, i32 %2) unnamed_addr #4 {
entry:
  %3 = and i32 %2, 3
  %4 = load i32, ptr %0, align 4
  %5 = shl i32 %4, 2
  %6 = or i32 %5, %3
  store i32 %6, ptr %1, align 4
  %7 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 1
  %8 = load i32, ptr %7, align 4
  %9 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 1
  store i32 %8, ptr %9, align 4
  %10 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 2
  %11 = load i32, ptr %10, align 4
  %12 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 2
  store i32 %11, ptr %12, align 4
  %13 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 3
  %14 = load i32, ptr %13, align 4
  %15 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 3
  store i32 %14, ptr %15, align 4
  %16 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 4
  %17 = load i32, ptr %16, align 4
  %18 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 4
  store i32 %17, ptr %18, align 4
  %19 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 5
  %20 = load i32, ptr %19, align 4
  %21 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 5
  store i32 %20, ptr %21, align 4
  %22 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 6
  %23 = load i32, ptr %22, align 4
  %24 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 6
  store i32 %23, ptr %24, align 4
  %25 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 7
  %26 = load i32, ptr %25, align 4
  %27 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 7
  store i32 %26, ptr %27, align 4
  %28 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 8
  %29 = load i32, ptr %28, align 4
  %30 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 8
  store i32 %29, ptr %30, align 4
  %31 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 9
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 9
  store i32 %32, ptr %33, align 4
  %34 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 10
  %35 = load i32, ptr %34, align 4
  %36 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 10
  store i32 %35, ptr %36, align 4
  %37 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 11
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 11
  store i32 %38, ptr %39, align 4
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #5

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn writeonly
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #6

; Function Attrs: noinline nounwind optnone uwtable
define internal fastcc void @taichi_assert_format(ptr noundef %0, i1 noundef zeroext %1, ptr noundef %2) unnamed_addr #7 {
  %4 = alloca ptr, align 8
  %5 = alloca i8, align 1
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca ptr, align 8
  %9 = alloca %class.anon, align 8
  store ptr %0, ptr %4, align 8
  %10 = zext i1 %1 to i8
  store i8 %10, ptr %5, align 1
  store ptr %2, ptr %6, align 8
  store i32 0, ptr %7, align 4
  store ptr null, ptr %8, align 8
  %11 = load i8, ptr %5, align 1
  %12 = trunc i8 %11 to i1
  %13 = zext i1 %12 to i32
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %15, label %16

15:                                               ; preds = %3
  br label %69

16:                                               ; preds = %3
  %17 = load ptr, ptr %4, align 8
  %18 = getelementptr inbounds %struct.LLVMRuntime, ptr %17, i32 0, i32 24
  %19 = load i64, ptr %18, align 8
  %20 = icmp ne i64 %19, 0
  br i1 %20, label %69, label %21

21:                                               ; preds = %16
  %22 = load ptr, ptr %4, align 8
  %23 = getelementptr inbounds %struct.LLVMRuntime, ptr %22, i32 0, i32 23
  %24 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 0
  store ptr %4, ptr %24, align 8
  %25 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 1
  store ptr %6, ptr %25, align 8
  %26 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 2
  store ptr %7, ptr %26, align 8
  %27 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 3
  store ptr %8, ptr %27, align 8
  br label %28

28:                                               ; preds = %28, %21
  %29 = atomicrmw volatile xchg ptr %23, i32 1 seq_cst, align 4
  %30 = icmp eq i32 %29, 1
  br i1 %30, label %28, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i:                        ; preds = %28
  %31 = load ptr, ptr %9, align 8
  %32 = load ptr, ptr %31, align 8
  %33 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 24
  %34 = load i64, ptr %33, align 8
  %.not.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i, label %35, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

35:                                               ; preds = %mutex_lock_i32.exit.i.i.i
  store i64 1, ptr %33, align 8
  %36 = load ptr, ptr %9, align 8
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr inbounds %struct.LLVMRuntime, ptr %37, i64 0, i32 21
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %38, i8 0, i64 2048, i1 false)
  %39 = load ptr, ptr %9, align 8
  %40 = load ptr, ptr %39, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 21
  %42 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 1
  %43 = load ptr, ptr %42, align 8
  %44 = load ptr, ptr %43, align 8
  %45 = load i8, ptr %44, align 1
  %.not5.i.i.i.i.i = icmp eq i8 %45, 0
  br i1 %.not5.i.i.i.i.i, label %taichi_strlen.exit.thread.i.i.i.i, label %.lr.ph.i.i.i.i.i.preheader

.lr.ph.i.i.i.i.i.preheader:                       ; preds = %35
  br label %.lr.ph.i.i.i.i.i

.lr.ph.i.i.i.i.i:                                 ; preds = %.lr.ph.i.i.i.i.i, %.lr.ph.i.i.i.i.i.preheader
  %.07.i.i.i.i.i = phi ptr [ %47, %.lr.ph.i.i.i.i.i ], [ %44, %.lr.ph.i.i.i.i.i.preheader ]
  %.046.i.i.i.i.i = phi i64 [ %46, %.lr.ph.i.i.i.i.i ], [ 0, %.lr.ph.i.i.i.i.i.preheader ]
  %46 = add i64 %.046.i.i.i.i.i, 1
  %47 = getelementptr inbounds i8, ptr %.07.i.i.i.i.i, i64 1
  %48 = load i8, ptr %47, align 1
  %.not.i.i.i.i.i = icmp eq i8 %48, 0
  br i1 %.not.i.i.i.i.i, label %taichi_strlen.exit.i.i.i.i, label %.lr.ph.i.i.i.i.i, !llvm.loop !11

taichi_strlen.exit.i.i.i.i:                       ; preds = %.lr.ph.i.i.i.i.i
  %.lcssa = phi i64 [ %46, %.lr.ph.i.i.i.i.i ]
  %49 = call i64 @llvm.umin.i64(i64 %.lcssa, i64 2047)
  br label %taichi_strlen.exit.thread.i.i.i.i

taichi_strlen.exit.thread.i.i.i.i:                ; preds = %taichi_strlen.exit.i.i.i.i, %35
  %50 = phi i64 [ 0, %35 ], [ %49, %taichi_strlen.exit.i.i.i.i ]
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %41, ptr nonnull align 1 %44, i64 %50, i1 false)
  %51 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 2
  %52 = load ptr, ptr %51, align 8
  %53 = load i32, ptr %52, align 4
  %54 = icmp sgt i32 %53, 0
  br i1 %54, label %.lr.ph.i.i.i.i, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

.lr.ph.i.i.i.i:                                   ; preds = %taichi_strlen.exit.thread.i.i.i.i
  %55 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 3
  br label %56

56:                                               ; preds = %56, %.lr.ph.i.i.i.i
  %indvars.iv.i.i.i.i = phi i64 [ 0, %.lr.ph.i.i.i.i ], [ %indvars.iv.next.i.i.i.i, %56 ]
  %57 = load ptr, ptr %55, align 8
  %58 = load ptr, ptr %57, align 8
  %59 = getelementptr inbounds i64, ptr %58, i64 %indvars.iv.i.i.i.i
  %60 = load i64, ptr %59, align 8
  %61 = load ptr, ptr %9, align 8
  %62 = load ptr, ptr %61, align 8
  %63 = getelementptr inbounds %struct.LLVMRuntime, ptr %62, i64 0, i32 22, i64 %indvars.iv.i.i.i.i
  store i64 %60, ptr %63, align 8
  %indvars.iv.next.i.i.i.i = add nuw nsw i64 %indvars.iv.i.i.i.i, 1
  %64 = load ptr, ptr %51, align 8
  %65 = load i32, ptr %64, align 4
  %66 = sext i32 %65 to i64
  %67 = icmp slt i64 %indvars.iv.next.i.i.i.i, %66
  br i1 %67, label %56, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", !llvm.loop !12

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit": ; preds = %56
  br label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit": ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", %taichi_strlen.exit.thread.i.i.i.i, %mutex_lock_i32.exit.i.i.i
  %68 = atomicrmw volatile xchg ptr %23, i32 0 seq_cst, align 4
  br label %69

69:                                               ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit", %16, %15
  ret void
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_struct_for_block_helper(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #8 {
_ZN11ListManager3getI7ElementEERT_i.exit:
  %3 = alloca %struct.RuntimeContext.692, align 8
  %4 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 4
  %5 = load i32, ptr %4, align 4
  %6 = sdiv i32 %2, %5
  %7 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  %8 = load i32, ptr %7, align 8
  %9 = sdiv i32 %8, %5
  %10 = srem i32 %2, %5
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  %12 = load ptr, ptr %11, align 8
  %13 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %14 = load i32, ptr %13, align 8
  %15 = ashr i32 %6, %14
  %16 = sext i32 %15 to i64
  %17 = lshr i64 %16, 9
  %18 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %17
  %19 = load atomic i64, ptr %18 acquire, align 8
  %.not.i.i.i = icmp ne i64 %19, 0
  tail call void @llvm.assume(i1 %.not.i.i.i)
  %20 = inttoptr i64 %19 to ptr
  %21 = and i64 %16, 511
  %22 = getelementptr inbounds ptr, ptr %20, i64 %21
  %23 = load atomic i64, ptr %22 acquire, align 8
  %24 = inttoptr i64 %23 to ptr
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %26 = load i64, ptr %25, align 8
  %27 = load i32, ptr %13, align 8
  %notmask.i.i = shl nsw i32 -1, %27
  %28 = xor i32 %notmask.i.i, -1
  %29 = and i32 %6, %28
  %30 = sext i32 %29 to i64
  %31 = mul i64 %26, %30
  %32 = getelementptr inbounds i8, ptr %24, i64 %31
  %33 = getelementptr inbounds %0, ptr %32, i64 0, i32 1
  %34 = load i32, ptr %33, align 8
  %35 = mul nsw i32 %10, %9
  %36 = add nsw i32 %34, %35
  %37 = add nsw i32 %10, 1
  %38 = mul nsw i32 %37, %9
  %39 = add nsw i32 %34, %38
  %40 = getelementptr inbounds %0, ptr %32, i64 0, i32 1, i64 1
  %41 = load i32, ptr %40, align 4
  %42 = tail call i32 @llvm.smin.i32(i32 %41, i32 %39)
  %43 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  %44 = load i64, ptr %43, align 8
  %45 = alloca i8, i64 %44, align 8
  %46 = load ptr, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %3, ptr noundef nonnull align 8 dereferenceable(32) %46, i64 32, i1 false)
  %47 = getelementptr inbounds %struct.RuntimeContext.692, ptr %3, i64 0, i32 2
  store i32 %1, ptr %47, align 8
  %48 = icmp slt i32 %36, %42
  br i1 %48, label %49, label %75

49:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit
  %50 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = load ptr, ptr %11, align 8
  %53 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 3
  %54 = load i32, ptr %53, align 8
  %55 = ashr i32 %6, %54
  %56 = sext i32 %55 to i64
  %57 = lshr i64 %56, 9
  %58 = getelementptr inbounds [256 x ptr], ptr %52, i64 0, i64 %57
  %59 = load atomic i64, ptr %58 acquire, align 8
  %.not.i.i.i24 = icmp eq i64 %59, 0
  br i1 %.not.i.i.i24, label %_ZN11ListManager3getI7ElementEERT_i.exit26, label %60

60:                                               ; preds = %49
  %61 = inttoptr i64 %59 to ptr
  %62 = and i64 %56, 511
  %63 = getelementptr inbounds ptr, ptr %61, i64 %62
  %64 = load atomic i64, ptr %63 acquire, align 8
  %65 = inttoptr i64 %64 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit26

_ZN11ListManager3getI7ElementEERT_i.exit26:       ; preds = %60, %49
  %66 = phi ptr [ %65, %60 ], [ null, %49 ]
  %67 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 1
  %68 = load i64, ptr %67, align 8
  %69 = load i32, ptr %53, align 8
  %notmask.i.i25 = shl nsw i32 -1, %69
  %70 = xor i32 %notmask.i.i25, -1
  %71 = and i32 %6, %70
  %72 = sext i32 %71 to i64
  %73 = mul i64 %68, %72
  %74 = getelementptr inbounds i8, ptr %66, i64 %73
  call void %51(ptr noundef nonnull %3, ptr noundef nonnull %45, ptr noundef nonnull %74, i32 noundef %36, i32 noundef %42) #1
  br label %75

75:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit26, %_ZN11ListManager3getI7ElementEERT_i.exit
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i64 @llvm.umin.i64(i64, i64) #9

; Function Attrs: inaccessiblememonly nocallback nofree nosync nounwind willreturn
declare void @llvm.assume(i1 noundef) #10

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #9

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #11

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #11

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { nofree nounwind }
attributes #3 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #4 = { argmemonly mustprogress nofree norecurse nosync nounwind willreturn }
attributes #5 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #6 = { argmemonly mustprogress nocallback nofree nounwind willreturn writeonly }
attributes #7 = { noinline nounwind optnone uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #10 = { inaccessiblememonly nocallback nofree nosync nounwind willreturn }
attributes #11 = { argmemonly nocallback nofree nosync nounwind willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
