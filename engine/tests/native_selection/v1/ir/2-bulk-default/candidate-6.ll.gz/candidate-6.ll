; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct.RuntimeContext.727 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }
%struct.range_task_helper_context = type { ptr, ptr, ptr, ptr, i64, i32, i32, i32, i32 }

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @selection_numeric_stage_28_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 20
  %2 = load i32, ptr %1, align 4
  %3 = getelementptr inbounds %struct.RuntimeContext.727, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  store i32 %2, ptr %6, align 4
  ret void
}

; Function Attrs: nounwind
define void @selection_numeric_stage_28_kernel_1_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.727, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 560)
  %6 = icmp sgt i32 %5, %3
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.727, ptr %0, i64 0, i32 1
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.LLVMRuntime, ptr %8, i64 0, i32 16
  %10 = load ptr, ptr %9, align 8
  %11 = load i32, ptr %10, align 4
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.lr.ph
  %13 = add nuw nsw i32 %3, 7
  %14 = sub i32 0, %5
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %lsr.iv = phi i32 [ %13, %for_loop_body.preheader ], [ %lsr.iv.next, %after_if.7 ]
  %15 = add nsw i32 %lsr.iv, -7
  %16 = load ptr, ptr %7, align 8
  %17 = getelementptr inbounds %struct.LLVMRuntime, ptr %16, i64 0, i32 16
  %18 = load ptr, ptr %17, align 8
  %19 = load i32, ptr %18, align 4
  %.not = icmp eq i32 %19, 0
  br i1 %.not, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.lr.ph, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %20 = sdiv i32 %15, 70
  %21 = srem i32 %15, 70
  %22 = load ptr, ptr %0, align 8
  %23 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %22, i64 0, i32 1, i32 1
  %24 = load ptr, ptr %23, align 8
  %25 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %22, i64 0, i32 1, i32 0, i32 1
  %26 = load i32, ptr %25, align 4
  %27 = sext i32 %20 to i64
  %28 = sext i32 %26 to i64
  %29 = mul nsw i64 %28, %27
  %30 = sext i32 %21 to i64
  %31 = add nsw i64 %29, %30
  %32 = getelementptr double, ptr %24, i64 %31
  %33 = getelementptr { { i32, i32 }, ptr }, ptr %22, i64 0, i32 1
  %34 = load ptr, ptr %33, align 8
  %35 = getelementptr { { i32, i32 }, ptr }, ptr %22, i64 0, i32 0, i32 1
  %36 = load i32, ptr %35, align 4
  %37 = sext i32 %36 to i64
  %38 = mul nsw i64 %37, %27
  %39 = add nsw i64 %38, %30
  %40 = getelementptr double, ptr %34, i64 %39
  %41 = load double, ptr %40, align 8
  store double %41, ptr %32, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %42 = load ptr, ptr %7, align 8
  %43 = getelementptr inbounds %struct.LLVMRuntime, ptr %42, i64 0, i32 16
  %44 = load ptr, ptr %43, align 8
  %45 = load i32, ptr %44, align 4
  %.not.1 = icmp eq i32 %45, 0
  br i1 %.not.1, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %46 = add nsw i32 %lsr.iv, -6
  %47 = sdiv i32 %46, 70
  %48 = srem i32 %46, 70
  %49 = load ptr, ptr %0, align 8
  %50 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %49, i64 0, i32 1, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %49, i64 0, i32 1, i32 0, i32 1
  %53 = load i32, ptr %52, align 4
  %54 = sext i32 %47 to i64
  %55 = sext i32 %53 to i64
  %56 = mul nsw i64 %55, %54
  %57 = sext i32 %48 to i64
  %58 = add nsw i64 %56, %57
  %59 = getelementptr double, ptr %51, i64 %58
  %60 = getelementptr { { i32, i32 }, ptr }, ptr %49, i64 0, i32 1
  %61 = load ptr, ptr %60, align 8
  %62 = getelementptr { { i32, i32 }, ptr }, ptr %49, i64 0, i32 0, i32 1
  %63 = load i32, ptr %62, align 4
  %64 = sext i32 %63 to i64
  %65 = mul nsw i64 %64, %54
  %66 = add nsw i64 %65, %57
  %67 = getelementptr double, ptr %61, i64 %66
  %68 = load double, ptr %67, align 8
  store double %68, ptr %59, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %69 = load ptr, ptr %7, align 8
  %70 = getelementptr inbounds %struct.LLVMRuntime, ptr %69, i64 0, i32 16
  %71 = load ptr, ptr %70, align 8
  %72 = load i32, ptr %71, align 4
  %.not.2 = icmp eq i32 %72, 0
  br i1 %.not.2, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %73 = add nsw i32 %lsr.iv, -5
  %74 = sdiv i32 %73, 70
  %75 = srem i32 %73, 70
  %76 = load ptr, ptr %0, align 8
  %77 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %76, i64 0, i32 1, i32 1
  %78 = load ptr, ptr %77, align 8
  %79 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %76, i64 0, i32 1, i32 0, i32 1
  %80 = load i32, ptr %79, align 4
  %81 = sext i32 %74 to i64
  %82 = sext i32 %80 to i64
  %83 = mul nsw i64 %82, %81
  %84 = sext i32 %75 to i64
  %85 = add nsw i64 %83, %84
  %86 = getelementptr double, ptr %78, i64 %85
  %87 = getelementptr { { i32, i32 }, ptr }, ptr %76, i64 0, i32 1
  %88 = load ptr, ptr %87, align 8
  %89 = getelementptr { { i32, i32 }, ptr }, ptr %76, i64 0, i32 0, i32 1
  %90 = load i32, ptr %89, align 4
  %91 = sext i32 %90 to i64
  %92 = mul nsw i64 %91, %81
  %93 = add nsw i64 %92, %84
  %94 = getelementptr double, ptr %88, i64 %93
  %95 = load double, ptr %94, align 8
  store double %95, ptr %86, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %96 = load ptr, ptr %7, align 8
  %97 = getelementptr inbounds %struct.LLVMRuntime, ptr %96, i64 0, i32 16
  %98 = load ptr, ptr %97, align 8
  %99 = load i32, ptr %98, align 4
  %.not.3 = icmp eq i32 %99, 0
  br i1 %.not.3, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %100 = add nsw i32 %lsr.iv, -4
  %101 = sdiv i32 %100, 70
  %102 = srem i32 %100, 70
  %103 = load ptr, ptr %0, align 8
  %104 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %103, i64 0, i32 1, i32 1
  %105 = load ptr, ptr %104, align 8
  %106 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %103, i64 0, i32 1, i32 0, i32 1
  %107 = load i32, ptr %106, align 4
  %108 = sext i32 %101 to i64
  %109 = sext i32 %107 to i64
  %110 = mul nsw i64 %109, %108
  %111 = sext i32 %102 to i64
  %112 = add nsw i64 %110, %111
  %113 = getelementptr double, ptr %105, i64 %112
  %114 = getelementptr { { i32, i32 }, ptr }, ptr %103, i64 0, i32 1
  %115 = load ptr, ptr %114, align 8
  %116 = getelementptr { { i32, i32 }, ptr }, ptr %103, i64 0, i32 0, i32 1
  %117 = load i32, ptr %116, align 4
  %118 = sext i32 %117 to i64
  %119 = mul nsw i64 %118, %108
  %120 = add nsw i64 %119, %111
  %121 = getelementptr double, ptr %115, i64 %120
  %122 = load double, ptr %121, align 8
  store double %122, ptr %113, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %123 = load ptr, ptr %7, align 8
  %124 = getelementptr inbounds %struct.LLVMRuntime, ptr %123, i64 0, i32 16
  %125 = load ptr, ptr %124, align 8
  %126 = load i32, ptr %125, align 4
  %.not.4 = icmp eq i32 %126, 0
  br i1 %.not.4, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %127 = add nsw i32 %lsr.iv, -3
  %128 = sdiv i32 %127, 70
  %129 = srem i32 %127, 70
  %130 = load ptr, ptr %0, align 8
  %131 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %130, i64 0, i32 1, i32 1
  %132 = load ptr, ptr %131, align 8
  %133 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %130, i64 0, i32 1, i32 0, i32 1
  %134 = load i32, ptr %133, align 4
  %135 = sext i32 %128 to i64
  %136 = sext i32 %134 to i64
  %137 = mul nsw i64 %136, %135
  %138 = sext i32 %129 to i64
  %139 = add nsw i64 %137, %138
  %140 = getelementptr double, ptr %132, i64 %139
  %141 = getelementptr { { i32, i32 }, ptr }, ptr %130, i64 0, i32 1
  %142 = load ptr, ptr %141, align 8
  %143 = getelementptr { { i32, i32 }, ptr }, ptr %130, i64 0, i32 0, i32 1
  %144 = load i32, ptr %143, align 4
  %145 = sext i32 %144 to i64
  %146 = mul nsw i64 %145, %135
  %147 = add nsw i64 %146, %138
  %148 = getelementptr double, ptr %142, i64 %147
  %149 = load double, ptr %148, align 8
  store double %149, ptr %140, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %150 = load ptr, ptr %7, align 8
  %151 = getelementptr inbounds %struct.LLVMRuntime, ptr %150, i64 0, i32 16
  %152 = load ptr, ptr %151, align 8
  %153 = load i32, ptr %152, align 4
  %.not.5 = icmp eq i32 %153, 0
  br i1 %.not.5, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %154 = add nsw i32 %lsr.iv, -2
  %155 = sdiv i32 %154, 70
  %156 = srem i32 %154, 70
  %157 = load ptr, ptr %0, align 8
  %158 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %157, i64 0, i32 1, i32 1
  %159 = load ptr, ptr %158, align 8
  %160 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %157, i64 0, i32 1, i32 0, i32 1
  %161 = load i32, ptr %160, align 4
  %162 = sext i32 %155 to i64
  %163 = sext i32 %161 to i64
  %164 = mul nsw i64 %163, %162
  %165 = sext i32 %156 to i64
  %166 = add nsw i64 %164, %165
  %167 = getelementptr double, ptr %159, i64 %166
  %168 = getelementptr { { i32, i32 }, ptr }, ptr %157, i64 0, i32 1
  %169 = load ptr, ptr %168, align 8
  %170 = getelementptr { { i32, i32 }, ptr }, ptr %157, i64 0, i32 0, i32 1
  %171 = load i32, ptr %170, align 4
  %172 = sext i32 %171 to i64
  %173 = mul nsw i64 %172, %162
  %174 = add nsw i64 %173, %165
  %175 = getelementptr double, ptr %169, i64 %174
  %176 = load double, ptr %175, align 8
  store double %176, ptr %167, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %177 = load ptr, ptr %7, align 8
  %178 = getelementptr inbounds %struct.LLVMRuntime, ptr %177, i64 0, i32 16
  %179 = load ptr, ptr %178, align 8
  %180 = load i32, ptr %179, align 4
  %.not.6 = icmp eq i32 %180, 0
  br i1 %.not.6, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %181 = add nsw i32 %lsr.iv, -1
  %182 = sdiv i32 %181, 70
  %183 = srem i32 %181, 70
  %184 = load ptr, ptr %0, align 8
  %185 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %184, i64 0, i32 1, i32 1
  %186 = load ptr, ptr %185, align 8
  %187 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %184, i64 0, i32 1, i32 0, i32 1
  %188 = load i32, ptr %187, align 4
  %189 = sext i32 %182 to i64
  %190 = sext i32 %188 to i64
  %191 = mul nsw i64 %190, %189
  %192 = sext i32 %183 to i64
  %193 = add nsw i64 %191, %192
  %194 = getelementptr double, ptr %186, i64 %193
  %195 = getelementptr { { i32, i32 }, ptr }, ptr %184, i64 0, i32 1
  %196 = load ptr, ptr %195, align 8
  %197 = getelementptr { { i32, i32 }, ptr }, ptr %184, i64 0, i32 0, i32 1
  %198 = load i32, ptr %197, align 4
  %199 = sext i32 %198 to i64
  %200 = mul nsw i64 %199, %189
  %201 = add nsw i64 %200, %192
  %202 = getelementptr double, ptr %196, i64 %201
  %203 = load double, ptr %202, align 8
  store double %203, ptr %194, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %204 = load ptr, ptr %7, align 8
  %205 = getelementptr inbounds %struct.LLVMRuntime, ptr %204, i64 0, i32 16
  %206 = load ptr, ptr %205, align 8
  %207 = load i32, ptr %206, align 4
  %.not.7 = icmp eq i32 %207, 0
  br i1 %.not.7, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %208 = sdiv i32 %lsr.iv, 70
  %209 = srem i32 %lsr.iv, 70
  %210 = load ptr, ptr %0, align 8
  %211 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %210, i64 0, i32 1, i32 1
  %212 = load ptr, ptr %211, align 8
  %213 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %210, i64 0, i32 1, i32 0, i32 1
  %214 = load i32, ptr %213, align 4
  %215 = sext i32 %208 to i64
  %216 = sext i32 %214 to i64
  %217 = mul nsw i64 %216, %215
  %218 = sext i32 %209 to i64
  %219 = add nsw i64 %217, %218
  %220 = getelementptr double, ptr %212, i64 %219
  %221 = getelementptr { { i32, i32 }, ptr }, ptr %210, i64 0, i32 1
  %222 = load ptr, ptr %221, align 8
  %223 = getelementptr { { i32, i32 }, ptr }, ptr %210, i64 0, i32 0, i32 1
  %224 = load i32, ptr %223, align 4
  %225 = sext i32 %224 to i64
  %226 = mul nsw i64 %225, %215
  %227 = add nsw i64 %226, %218
  %228 = getelementptr double, ptr %222, i64 %227
  %229 = load double, ptr %228, align 8
  store double %229, ptr %220, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %lsr.iv.next = add i32 %lsr.iv, 8
  %230 = add i32 %14, %lsr.iv.next
  %exitcond.not.7 = icmp eq i32 %230, 7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @selection_numeric_stage_28_kernel_2_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.1, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.727, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.1(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.727, ptr %0, i64 0, i32 1
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.LLVMRuntime, ptr %8, i64 0, i32 16
  %10 = load ptr, ptr %9, align 8
  %11 = load i32, ptr %10, align 4
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.lr.ph
  %13 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %14 = xor i64 %13, -1
  %15 = add nsw i64 %14, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.preheader
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %13, %for_loop_body.prol.preheader ]
  %16 = load ptr, ptr %7, align 8
  %17 = getelementptr inbounds %struct.LLVMRuntime, ptr %16, i64 0, i32 16
  %18 = load ptr, ptr %17, align 8
  %19 = load i32, ptr %18, align 4
  %.not.prol = icmp eq i32 %19, 0
  br i1 %.not.prol, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %20 = load ptr, ptr %0, align 8
  %21 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %20, i64 0, i32 3, i32 1
  %22 = load ptr, ptr %21, align 8
  %23 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep38 = getelementptr i8, ptr %22, i64 %23
  %24 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %20, i64 0, i32 2, i32 1
  %25 = load ptr, ptr %24, align 8
  %uglygep37 = getelementptr i8, ptr %25, i64 %23
  %26 = load i32, ptr %uglygep37, align 4
  store i32 %26, ptr %uglygep38, align 4
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !6

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.preheader
  %indvars.iv.unr = phi i64 [ %13, %for_loop_body.preheader ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %27 = icmp ult i64 %15, 7
  br i1 %27, label %after_for, label %for_loop_body.preheader7

for_loop_body.preheader7:                         ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader7
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader7 ]
  %28 = load ptr, ptr %7, align 8
  %29 = getelementptr inbounds %struct.LLVMRuntime, ptr %28, i64 0, i32 16
  %30 = load ptr, ptr %29, align 8
  %31 = load i32, ptr %30, align 4
  %.not = icmp eq i32 %31, 0
  br i1 %.not, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %for_loop_body.lr.ph, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %32 = load ptr, ptr %0, align 8
  %33 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %32, i64 0, i32 3, i32 1
  %34 = load ptr, ptr %33, align 8
  %35 = shl i64 %indvars.iv, 2
  %uglygep31 = getelementptr i8, ptr %34, i64 %35
  %36 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %32, i64 0, i32 2, i32 1
  %37 = load ptr, ptr %36, align 8
  %uglygep32 = getelementptr i8, ptr %37, i64 %35
  %38 = load i32, ptr %uglygep32, align 4
  store i32 %38, ptr %uglygep31, align 4
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %39 = load ptr, ptr %7, align 8
  %40 = getelementptr inbounds %struct.LLVMRuntime, ptr %39, i64 0, i32 16
  %41 = load ptr, ptr %40, align 8
  %42 = load i32, ptr %41, align 4
  %.not.1 = icmp eq i32 %42, 0
  br i1 %.not.1, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %43 = load ptr, ptr %0, align 8
  %44 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %43, i64 0, i32 3, i32 1
  %45 = load ptr, ptr %44, align 8
  %uglygep35 = getelementptr i8, ptr %45, i64 4
  %46 = shl i64 %indvars.iv, 2
  %uglygep36 = getelementptr i8, ptr %uglygep35, i64 %46
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %43, i64 0, i32 2, i32 1
  %48 = load ptr, ptr %47, align 8
  %uglygep33 = getelementptr i8, ptr %48, i64 4
  %uglygep34 = getelementptr i8, ptr %uglygep33, i64 %46
  %49 = load i32, ptr %uglygep34, align 4
  store i32 %49, ptr %uglygep36, align 4
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %50 = load ptr, ptr %7, align 8
  %51 = getelementptr inbounds %struct.LLVMRuntime, ptr %50, i64 0, i32 16
  %52 = load ptr, ptr %51, align 8
  %53 = load i32, ptr %52, align 4
  %.not.2 = icmp eq i32 %53, 0
  br i1 %.not.2, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %54 = load ptr, ptr %0, align 8
  %55 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %54, i64 0, i32 3, i32 1
  %56 = load ptr, ptr %55, align 8
  %uglygep29 = getelementptr i8, ptr %56, i64 8
  %57 = shl i64 %indvars.iv, 2
  %uglygep30 = getelementptr i8, ptr %uglygep29, i64 %57
  %58 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %54, i64 0, i32 2, i32 1
  %59 = load ptr, ptr %58, align 8
  %uglygep27 = getelementptr i8, ptr %59, i64 8
  %uglygep28 = getelementptr i8, ptr %uglygep27, i64 %57
  %60 = load i32, ptr %uglygep28, align 4
  store i32 %60, ptr %uglygep30, align 4
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %61 = load ptr, ptr %7, align 8
  %62 = getelementptr inbounds %struct.LLVMRuntime, ptr %61, i64 0, i32 16
  %63 = load ptr, ptr %62, align 8
  %64 = load i32, ptr %63, align 4
  %.not.3 = icmp eq i32 %64, 0
  br i1 %.not.3, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %65 = load ptr, ptr %0, align 8
  %66 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %65, i64 0, i32 3, i32 1
  %67 = load ptr, ptr %66, align 8
  %uglygep25 = getelementptr i8, ptr %67, i64 12
  %68 = shl i64 %indvars.iv, 2
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %68
  %69 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %65, i64 0, i32 2, i32 1
  %70 = load ptr, ptr %69, align 8
  %uglygep23 = getelementptr i8, ptr %70, i64 12
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %68
  %71 = load i32, ptr %uglygep24, align 4
  store i32 %71, ptr %uglygep26, align 4
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %72 = load ptr, ptr %7, align 8
  %73 = getelementptr inbounds %struct.LLVMRuntime, ptr %72, i64 0, i32 16
  %74 = load ptr, ptr %73, align 8
  %75 = load i32, ptr %74, align 4
  %.not.4 = icmp eq i32 %75, 0
  br i1 %.not.4, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %76 = load ptr, ptr %0, align 8
  %77 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %76, i64 0, i32 3, i32 1
  %78 = load ptr, ptr %77, align 8
  %uglygep21 = getelementptr i8, ptr %78, i64 16
  %79 = shl i64 %indvars.iv, 2
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 %79
  %80 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %76, i64 0, i32 2, i32 1
  %81 = load ptr, ptr %80, align 8
  %uglygep19 = getelementptr i8, ptr %81, i64 16
  %uglygep20 = getelementptr i8, ptr %uglygep19, i64 %79
  %82 = load i32, ptr %uglygep20, align 4
  store i32 %82, ptr %uglygep22, align 4
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %83 = load ptr, ptr %7, align 8
  %84 = getelementptr inbounds %struct.LLVMRuntime, ptr %83, i64 0, i32 16
  %85 = load ptr, ptr %84, align 8
  %86 = load i32, ptr %85, align 4
  %.not.5 = icmp eq i32 %86, 0
  br i1 %.not.5, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %87 = load ptr, ptr %0, align 8
  %88 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %87, i64 0, i32 3, i32 1
  %89 = load ptr, ptr %88, align 8
  %uglygep17 = getelementptr i8, ptr %89, i64 20
  %90 = shl i64 %indvars.iv, 2
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %90
  %91 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %87, i64 0, i32 2, i32 1
  %92 = load ptr, ptr %91, align 8
  %uglygep15 = getelementptr i8, ptr %92, i64 20
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %90
  %93 = load i32, ptr %uglygep16, align 4
  store i32 %93, ptr %uglygep18, align 4
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %94 = load ptr, ptr %7, align 8
  %95 = getelementptr inbounds %struct.LLVMRuntime, ptr %94, i64 0, i32 16
  %96 = load ptr, ptr %95, align 8
  %97 = load i32, ptr %96, align 4
  %.not.6 = icmp eq i32 %97, 0
  br i1 %.not.6, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %98 = load ptr, ptr %0, align 8
  %99 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %98, i64 0, i32 3, i32 1
  %100 = load ptr, ptr %99, align 8
  %uglygep13 = getelementptr i8, ptr %100, i64 24
  %101 = shl i64 %indvars.iv, 2
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %101
  %102 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %98, i64 0, i32 2, i32 1
  %103 = load ptr, ptr %102, align 8
  %uglygep11 = getelementptr i8, ptr %103, i64 24
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %101
  %104 = load i32, ptr %uglygep12, align 4
  store i32 %104, ptr %uglygep14, align 4
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %105 = load ptr, ptr %7, align 8
  %106 = getelementptr inbounds %struct.LLVMRuntime, ptr %105, i64 0, i32 16
  %107 = load ptr, ptr %106, align 8
  %108 = load i32, ptr %107, align 4
  %.not.7 = icmp eq i32 %108, 0
  br i1 %.not.7, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %109 = load ptr, ptr %0, align 8
  %110 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %109, i64 0, i32 3, i32 1
  %111 = load ptr, ptr %110, align 8
  %uglygep9 = getelementptr i8, ptr %111, i64 28
  %112 = shl i64 %indvars.iv, 2
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %112
  %113 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %109, i64 0, i32 2, i32 1
  %114 = load ptr, ptr %113, align 8
  %uglygep = getelementptr i8, ptr %114, i64 28
  %uglygep8 = getelementptr i8, ptr %uglygep, i64 %112
  %115 = load i32, ptr %uglygep8, align 4
  store i32 %115, ptr %uglygep10, align 4
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @selection_numeric_stage_28_kernel_3_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.2, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.727, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.2(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 770)
  %6 = icmp sgt i32 %5, %3
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.727, ptr %0, i64 0, i32 1
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.LLVMRuntime, ptr %8, i64 0, i32 16
  %10 = load ptr, ptr %9, align 8
  %11 = load i32, ptr %10, align 4
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.lr.ph
  %13 = xor i32 %3, -1
  %14 = add i32 %5, %13
  %xtraiter = and i32 %5, 2
  %lcmp.mod.not = icmp eq i32 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.preheader
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv7 = phi i32 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next8, %after_if.prol ]
  %.04.prol = phi i32 [ %41, %after_if.prol ], [ %3, %for_loop_body.prol.preheader ]
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds %struct.LLVMRuntime, ptr %15, i64 0, i32 16
  %17 = load ptr, ptr %16, align 8
  %18 = load i32, ptr %17, align 4
  %.not.prol = icmp eq i32 %18, 0
  br i1 %.not.prol, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %19 = sdiv i32 %.04.prol, 70
  %20 = srem i32 %.04.prol, 70
  %21 = load ptr, ptr %0, align 8
  %22 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %21, i64 0, i32 5, i32 1
  %23 = load ptr, ptr %22, align 8
  %24 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %21, i64 0, i32 5, i32 0, i32 1
  %25 = load i32, ptr %24, align 4
  %26 = sext i32 %19 to i64
  %27 = sext i32 %25 to i64
  %28 = mul nsw i64 %27, %26
  %29 = sext i32 %20 to i64
  %30 = add nsw i64 %28, %29
  %31 = getelementptr double, ptr %23, i64 %30
  %32 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %21, i64 0, i32 4, i32 1
  %33 = load ptr, ptr %32, align 8
  %34 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %21, i64 0, i32 4, i32 0, i32 1
  %35 = load i32, ptr %34, align 4
  %36 = sext i32 %35 to i64
  %37 = mul nsw i64 %36, %26
  %38 = add nsw i64 %37, %29
  %39 = getelementptr double, ptr %33, i64 %38
  %40 = load double, ptr %39, align 8
  store double %40, ptr %31, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %41 = add nuw nsw i32 %.04.prol, 1
  %lsr.iv.next8 = add nsw i32 %lsr.iv7, -1
  %prol.iter.cmp.not = icmp eq i32 %lsr.iv.next8, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !8

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.preheader
  %.04.unr = phi i32 [ %3, %for_loop_body.preheader ], [ %41, %for_loop_body.prol.loopexit.loopexit ]
  %42 = icmp ult i32 %14, 7
  br i1 %42, label %after_for, label %for_loop_body.preheader6

for_loop_body.preheader6:                         ; preds = %for_loop_body.prol.loopexit
  %43 = sub i32 0, %5
  %44 = add nuw i32 %.04.unr, 7
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader6
  %lsr.iv = phi i32 [ %44, %for_loop_body.preheader6 ], [ %lsr.iv.next, %after_if.7 ]
  %45 = add i32 %lsr.iv, -7
  %46 = load ptr, ptr %7, align 8
  %47 = getelementptr inbounds %struct.LLVMRuntime, ptr %46, i64 0, i32 16
  %48 = load ptr, ptr %47, align 8
  %49 = load i32, ptr %48, align 4
  %.not = icmp eq i32 %49, 0
  br i1 %.not, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %for_loop_body.lr.ph, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %50 = sdiv i32 %45, 70
  %51 = srem i32 %45, 70
  %52 = load ptr, ptr %0, align 8
  %53 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %52, i64 0, i32 5, i32 1
  %54 = load ptr, ptr %53, align 8
  %55 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %52, i64 0, i32 5, i32 0, i32 1
  %56 = load i32, ptr %55, align 4
  %57 = sext i32 %50 to i64
  %58 = sext i32 %56 to i64
  %59 = mul nsw i64 %58, %57
  %60 = sext i32 %51 to i64
  %61 = add nsw i64 %59, %60
  %62 = getelementptr double, ptr %54, i64 %61
  %63 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %52, i64 0, i32 4, i32 1
  %64 = load ptr, ptr %63, align 8
  %65 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %52, i64 0, i32 4, i32 0, i32 1
  %66 = load i32, ptr %65, align 4
  %67 = sext i32 %66 to i64
  %68 = mul nsw i64 %67, %57
  %69 = add nsw i64 %68, %60
  %70 = getelementptr double, ptr %64, i64 %69
  %71 = load double, ptr %70, align 8
  store double %71, ptr %62, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %72 = load ptr, ptr %7, align 8
  %73 = getelementptr inbounds %struct.LLVMRuntime, ptr %72, i64 0, i32 16
  %74 = load ptr, ptr %73, align 8
  %75 = load i32, ptr %74, align 4
  %.not.1 = icmp eq i32 %75, 0
  br i1 %.not.1, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %76 = add i32 %lsr.iv, -6
  %77 = sdiv i32 %76, 70
  %78 = srem i32 %76, 70
  %79 = load ptr, ptr %0, align 8
  %80 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %79, i64 0, i32 5, i32 1
  %81 = load ptr, ptr %80, align 8
  %82 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %79, i64 0, i32 5, i32 0, i32 1
  %83 = load i32, ptr %82, align 4
  %84 = sext i32 %77 to i64
  %85 = sext i32 %83 to i64
  %86 = mul nsw i64 %85, %84
  %87 = sext i32 %78 to i64
  %88 = add nsw i64 %86, %87
  %89 = getelementptr double, ptr %81, i64 %88
  %90 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %79, i64 0, i32 4, i32 1
  %91 = load ptr, ptr %90, align 8
  %92 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %79, i64 0, i32 4, i32 0, i32 1
  %93 = load i32, ptr %92, align 4
  %94 = sext i32 %93 to i64
  %95 = mul nsw i64 %94, %84
  %96 = add nsw i64 %95, %87
  %97 = getelementptr double, ptr %91, i64 %96
  %98 = load double, ptr %97, align 8
  store double %98, ptr %89, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %99 = load ptr, ptr %7, align 8
  %100 = getelementptr inbounds %struct.LLVMRuntime, ptr %99, i64 0, i32 16
  %101 = load ptr, ptr %100, align 8
  %102 = load i32, ptr %101, align 4
  %.not.2 = icmp eq i32 %102, 0
  br i1 %.not.2, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %103 = add i32 %lsr.iv, -5
  %104 = sdiv i32 %103, 70
  %105 = srem i32 %103, 70
  %106 = load ptr, ptr %0, align 8
  %107 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %106, i64 0, i32 5, i32 1
  %108 = load ptr, ptr %107, align 8
  %109 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %106, i64 0, i32 5, i32 0, i32 1
  %110 = load i32, ptr %109, align 4
  %111 = sext i32 %104 to i64
  %112 = sext i32 %110 to i64
  %113 = mul nsw i64 %112, %111
  %114 = sext i32 %105 to i64
  %115 = add nsw i64 %113, %114
  %116 = getelementptr double, ptr %108, i64 %115
  %117 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %106, i64 0, i32 4, i32 1
  %118 = load ptr, ptr %117, align 8
  %119 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %106, i64 0, i32 4, i32 0, i32 1
  %120 = load i32, ptr %119, align 4
  %121 = sext i32 %120 to i64
  %122 = mul nsw i64 %121, %111
  %123 = add nsw i64 %122, %114
  %124 = getelementptr double, ptr %118, i64 %123
  %125 = load double, ptr %124, align 8
  store double %125, ptr %116, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %126 = load ptr, ptr %7, align 8
  %127 = getelementptr inbounds %struct.LLVMRuntime, ptr %126, i64 0, i32 16
  %128 = load ptr, ptr %127, align 8
  %129 = load i32, ptr %128, align 4
  %.not.3 = icmp eq i32 %129, 0
  br i1 %.not.3, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %130 = add i32 %lsr.iv, -4
  %131 = sdiv i32 %130, 70
  %132 = srem i32 %130, 70
  %133 = load ptr, ptr %0, align 8
  %134 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %133, i64 0, i32 5, i32 1
  %135 = load ptr, ptr %134, align 8
  %136 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %133, i64 0, i32 5, i32 0, i32 1
  %137 = load i32, ptr %136, align 4
  %138 = sext i32 %131 to i64
  %139 = sext i32 %137 to i64
  %140 = mul nsw i64 %139, %138
  %141 = sext i32 %132 to i64
  %142 = add nsw i64 %140, %141
  %143 = getelementptr double, ptr %135, i64 %142
  %144 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %133, i64 0, i32 4, i32 1
  %145 = load ptr, ptr %144, align 8
  %146 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %133, i64 0, i32 4, i32 0, i32 1
  %147 = load i32, ptr %146, align 4
  %148 = sext i32 %147 to i64
  %149 = mul nsw i64 %148, %138
  %150 = add nsw i64 %149, %141
  %151 = getelementptr double, ptr %145, i64 %150
  %152 = load double, ptr %151, align 8
  store double %152, ptr %143, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %153 = load ptr, ptr %7, align 8
  %154 = getelementptr inbounds %struct.LLVMRuntime, ptr %153, i64 0, i32 16
  %155 = load ptr, ptr %154, align 8
  %156 = load i32, ptr %155, align 4
  %.not.4 = icmp eq i32 %156, 0
  br i1 %.not.4, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %157 = add i32 %lsr.iv, -3
  %158 = sdiv i32 %157, 70
  %159 = srem i32 %157, 70
  %160 = load ptr, ptr %0, align 8
  %161 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %160, i64 0, i32 5, i32 1
  %162 = load ptr, ptr %161, align 8
  %163 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %160, i64 0, i32 5, i32 0, i32 1
  %164 = load i32, ptr %163, align 4
  %165 = sext i32 %158 to i64
  %166 = sext i32 %164 to i64
  %167 = mul nsw i64 %166, %165
  %168 = sext i32 %159 to i64
  %169 = add nsw i64 %167, %168
  %170 = getelementptr double, ptr %162, i64 %169
  %171 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %160, i64 0, i32 4, i32 1
  %172 = load ptr, ptr %171, align 8
  %173 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %160, i64 0, i32 4, i32 0, i32 1
  %174 = load i32, ptr %173, align 4
  %175 = sext i32 %174 to i64
  %176 = mul nsw i64 %175, %165
  %177 = add nsw i64 %176, %168
  %178 = getelementptr double, ptr %172, i64 %177
  %179 = load double, ptr %178, align 8
  store double %179, ptr %170, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %180 = load ptr, ptr %7, align 8
  %181 = getelementptr inbounds %struct.LLVMRuntime, ptr %180, i64 0, i32 16
  %182 = load ptr, ptr %181, align 8
  %183 = load i32, ptr %182, align 4
  %.not.5 = icmp eq i32 %183, 0
  br i1 %.not.5, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %184 = add i32 %lsr.iv, -2
  %185 = sdiv i32 %184, 70
  %186 = srem i32 %184, 70
  %187 = load ptr, ptr %0, align 8
  %188 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %187, i64 0, i32 5, i32 1
  %189 = load ptr, ptr %188, align 8
  %190 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %187, i64 0, i32 5, i32 0, i32 1
  %191 = load i32, ptr %190, align 4
  %192 = sext i32 %185 to i64
  %193 = sext i32 %191 to i64
  %194 = mul nsw i64 %193, %192
  %195 = sext i32 %186 to i64
  %196 = add nsw i64 %194, %195
  %197 = getelementptr double, ptr %189, i64 %196
  %198 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %187, i64 0, i32 4, i32 1
  %199 = load ptr, ptr %198, align 8
  %200 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %187, i64 0, i32 4, i32 0, i32 1
  %201 = load i32, ptr %200, align 4
  %202 = sext i32 %201 to i64
  %203 = mul nsw i64 %202, %192
  %204 = add nsw i64 %203, %195
  %205 = getelementptr double, ptr %199, i64 %204
  %206 = load double, ptr %205, align 8
  store double %206, ptr %197, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %207 = load ptr, ptr %7, align 8
  %208 = getelementptr inbounds %struct.LLVMRuntime, ptr %207, i64 0, i32 16
  %209 = load ptr, ptr %208, align 8
  %210 = load i32, ptr %209, align 4
  %.not.6 = icmp eq i32 %210, 0
  br i1 %.not.6, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %211 = add i32 %lsr.iv, -1
  %212 = sdiv i32 %211, 70
  %213 = srem i32 %211, 70
  %214 = load ptr, ptr %0, align 8
  %215 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %214, i64 0, i32 5, i32 1
  %216 = load ptr, ptr %215, align 8
  %217 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %214, i64 0, i32 5, i32 0, i32 1
  %218 = load i32, ptr %217, align 4
  %219 = sext i32 %212 to i64
  %220 = sext i32 %218 to i64
  %221 = mul nsw i64 %220, %219
  %222 = sext i32 %213 to i64
  %223 = add nsw i64 %221, %222
  %224 = getelementptr double, ptr %216, i64 %223
  %225 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %214, i64 0, i32 4, i32 1
  %226 = load ptr, ptr %225, align 8
  %227 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %214, i64 0, i32 4, i32 0, i32 1
  %228 = load i32, ptr %227, align 4
  %229 = sext i32 %228 to i64
  %230 = mul nsw i64 %229, %219
  %231 = add nsw i64 %230, %222
  %232 = getelementptr double, ptr %226, i64 %231
  %233 = load double, ptr %232, align 8
  store double %233, ptr %224, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %234 = load ptr, ptr %7, align 8
  %235 = getelementptr inbounds %struct.LLVMRuntime, ptr %234, i64 0, i32 16
  %236 = load ptr, ptr %235, align 8
  %237 = load i32, ptr %236, align 4
  %.not.7 = icmp eq i32 %237, 0
  br i1 %.not.7, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %238 = sdiv i32 %lsr.iv, 70
  %239 = srem i32 %lsr.iv, 70
  %240 = load ptr, ptr %0, align 8
  %241 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %240, i64 0, i32 5, i32 1
  %242 = load ptr, ptr %241, align 8
  %243 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %240, i64 0, i32 5, i32 0, i32 1
  %244 = load i32, ptr %243, align 4
  %245 = sext i32 %238 to i64
  %246 = sext i32 %244 to i64
  %247 = mul nsw i64 %246, %245
  %248 = sext i32 %239 to i64
  %249 = add nsw i64 %247, %248
  %250 = getelementptr double, ptr %242, i64 %249
  %251 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %240, i64 0, i32 4, i32 1
  %252 = load ptr, ptr %251, align 8
  %253 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %240, i64 0, i32 4, i32 0, i32 1
  %254 = load i32, ptr %253, align 4
  %255 = sext i32 %254 to i64
  %256 = mul nsw i64 %255, %245
  %257 = add nsw i64 %256, %248
  %258 = getelementptr double, ptr %252, i64 %257
  %259 = load double, ptr %258, align 8
  store double %259, ptr %250, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %lsr.iv.next = add i32 %lsr.iv, 8
  %260 = add i32 %43, %lsr.iv.next
  %exitcond.not.7 = icmp eq i32 %260, 7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @selection_numeric_stage_28_kernel_4_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.3, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.727, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.3(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 560)
  %6 = icmp sgt i32 %5, %3
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.727, ptr %0, i64 0, i32 1
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.LLVMRuntime, ptr %8, i64 0, i32 16
  %10 = load ptr, ptr %9, align 8
  %11 = load i32, ptr %10, align 4
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.lr.ph
  %13 = add nuw nsw i32 %3, 7
  %14 = sub i32 0, %5
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %lsr.iv = phi i32 [ %13, %for_loop_body.preheader ], [ %lsr.iv.next, %after_if.7 ]
  %15 = add nsw i32 %lsr.iv, -7
  %16 = load ptr, ptr %7, align 8
  %17 = getelementptr inbounds %struct.LLVMRuntime, ptr %16, i64 0, i32 16
  %18 = load ptr, ptr %17, align 8
  %19 = load i32, ptr %18, align 4
  %.not = icmp eq i32 %19, 0
  br i1 %.not, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.lr.ph, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %20 = sdiv i32 %15, 70
  %21 = srem i32 %15, 70
  %22 = load ptr, ptr %0, align 8
  %23 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %22, i64 0, i32 7, i32 1
  %24 = load ptr, ptr %23, align 8
  %25 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %22, i64 0, i32 7, i32 0, i32 1
  %26 = load i32, ptr %25, align 4
  %27 = sext i32 %20 to i64
  %28 = sext i32 %26 to i64
  %29 = mul nsw i64 %28, %27
  %30 = sext i32 %21 to i64
  %31 = add nsw i64 %29, %30
  %32 = getelementptr double, ptr %24, i64 %31
  %33 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %22, i64 0, i32 6, i32 1
  %34 = load ptr, ptr %33, align 8
  %35 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %22, i64 0, i32 6, i32 0, i32 1
  %36 = load i32, ptr %35, align 4
  %37 = sext i32 %36 to i64
  %38 = mul nsw i64 %37, %27
  %39 = add nsw i64 %38, %30
  %40 = getelementptr double, ptr %34, i64 %39
  %41 = load double, ptr %40, align 8
  store double %41, ptr %32, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %42 = load ptr, ptr %7, align 8
  %43 = getelementptr inbounds %struct.LLVMRuntime, ptr %42, i64 0, i32 16
  %44 = load ptr, ptr %43, align 8
  %45 = load i32, ptr %44, align 4
  %.not.1 = icmp eq i32 %45, 0
  br i1 %.not.1, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %46 = add nsw i32 %lsr.iv, -6
  %47 = sdiv i32 %46, 70
  %48 = srem i32 %46, 70
  %49 = load ptr, ptr %0, align 8
  %50 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %49, i64 0, i32 7, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %49, i64 0, i32 7, i32 0, i32 1
  %53 = load i32, ptr %52, align 4
  %54 = sext i32 %47 to i64
  %55 = sext i32 %53 to i64
  %56 = mul nsw i64 %55, %54
  %57 = sext i32 %48 to i64
  %58 = add nsw i64 %56, %57
  %59 = getelementptr double, ptr %51, i64 %58
  %60 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %49, i64 0, i32 6, i32 1
  %61 = load ptr, ptr %60, align 8
  %62 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %49, i64 0, i32 6, i32 0, i32 1
  %63 = load i32, ptr %62, align 4
  %64 = sext i32 %63 to i64
  %65 = mul nsw i64 %64, %54
  %66 = add nsw i64 %65, %57
  %67 = getelementptr double, ptr %61, i64 %66
  %68 = load double, ptr %67, align 8
  store double %68, ptr %59, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %69 = load ptr, ptr %7, align 8
  %70 = getelementptr inbounds %struct.LLVMRuntime, ptr %69, i64 0, i32 16
  %71 = load ptr, ptr %70, align 8
  %72 = load i32, ptr %71, align 4
  %.not.2 = icmp eq i32 %72, 0
  br i1 %.not.2, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %73 = add nsw i32 %lsr.iv, -5
  %74 = sdiv i32 %73, 70
  %75 = srem i32 %73, 70
  %76 = load ptr, ptr %0, align 8
  %77 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %76, i64 0, i32 7, i32 1
  %78 = load ptr, ptr %77, align 8
  %79 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %76, i64 0, i32 7, i32 0, i32 1
  %80 = load i32, ptr %79, align 4
  %81 = sext i32 %74 to i64
  %82 = sext i32 %80 to i64
  %83 = mul nsw i64 %82, %81
  %84 = sext i32 %75 to i64
  %85 = add nsw i64 %83, %84
  %86 = getelementptr double, ptr %78, i64 %85
  %87 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %76, i64 0, i32 6, i32 1
  %88 = load ptr, ptr %87, align 8
  %89 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %76, i64 0, i32 6, i32 0, i32 1
  %90 = load i32, ptr %89, align 4
  %91 = sext i32 %90 to i64
  %92 = mul nsw i64 %91, %81
  %93 = add nsw i64 %92, %84
  %94 = getelementptr double, ptr %88, i64 %93
  %95 = load double, ptr %94, align 8
  store double %95, ptr %86, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %96 = load ptr, ptr %7, align 8
  %97 = getelementptr inbounds %struct.LLVMRuntime, ptr %96, i64 0, i32 16
  %98 = load ptr, ptr %97, align 8
  %99 = load i32, ptr %98, align 4
  %.not.3 = icmp eq i32 %99, 0
  br i1 %.not.3, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %100 = add nsw i32 %lsr.iv, -4
  %101 = sdiv i32 %100, 70
  %102 = srem i32 %100, 70
  %103 = load ptr, ptr %0, align 8
  %104 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %103, i64 0, i32 7, i32 1
  %105 = load ptr, ptr %104, align 8
  %106 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %103, i64 0, i32 7, i32 0, i32 1
  %107 = load i32, ptr %106, align 4
  %108 = sext i32 %101 to i64
  %109 = sext i32 %107 to i64
  %110 = mul nsw i64 %109, %108
  %111 = sext i32 %102 to i64
  %112 = add nsw i64 %110, %111
  %113 = getelementptr double, ptr %105, i64 %112
  %114 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %103, i64 0, i32 6, i32 1
  %115 = load ptr, ptr %114, align 8
  %116 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %103, i64 0, i32 6, i32 0, i32 1
  %117 = load i32, ptr %116, align 4
  %118 = sext i32 %117 to i64
  %119 = mul nsw i64 %118, %108
  %120 = add nsw i64 %119, %111
  %121 = getelementptr double, ptr %115, i64 %120
  %122 = load double, ptr %121, align 8
  store double %122, ptr %113, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %123 = load ptr, ptr %7, align 8
  %124 = getelementptr inbounds %struct.LLVMRuntime, ptr %123, i64 0, i32 16
  %125 = load ptr, ptr %124, align 8
  %126 = load i32, ptr %125, align 4
  %.not.4 = icmp eq i32 %126, 0
  br i1 %.not.4, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %127 = add nsw i32 %lsr.iv, -3
  %128 = sdiv i32 %127, 70
  %129 = srem i32 %127, 70
  %130 = load ptr, ptr %0, align 8
  %131 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %130, i64 0, i32 7, i32 1
  %132 = load ptr, ptr %131, align 8
  %133 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %130, i64 0, i32 7, i32 0, i32 1
  %134 = load i32, ptr %133, align 4
  %135 = sext i32 %128 to i64
  %136 = sext i32 %134 to i64
  %137 = mul nsw i64 %136, %135
  %138 = sext i32 %129 to i64
  %139 = add nsw i64 %137, %138
  %140 = getelementptr double, ptr %132, i64 %139
  %141 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %130, i64 0, i32 6, i32 1
  %142 = load ptr, ptr %141, align 8
  %143 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %130, i64 0, i32 6, i32 0, i32 1
  %144 = load i32, ptr %143, align 4
  %145 = sext i32 %144 to i64
  %146 = mul nsw i64 %145, %135
  %147 = add nsw i64 %146, %138
  %148 = getelementptr double, ptr %142, i64 %147
  %149 = load double, ptr %148, align 8
  store double %149, ptr %140, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %150 = load ptr, ptr %7, align 8
  %151 = getelementptr inbounds %struct.LLVMRuntime, ptr %150, i64 0, i32 16
  %152 = load ptr, ptr %151, align 8
  %153 = load i32, ptr %152, align 4
  %.not.5 = icmp eq i32 %153, 0
  br i1 %.not.5, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %154 = add nsw i32 %lsr.iv, -2
  %155 = sdiv i32 %154, 70
  %156 = srem i32 %154, 70
  %157 = load ptr, ptr %0, align 8
  %158 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %157, i64 0, i32 7, i32 1
  %159 = load ptr, ptr %158, align 8
  %160 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %157, i64 0, i32 7, i32 0, i32 1
  %161 = load i32, ptr %160, align 4
  %162 = sext i32 %155 to i64
  %163 = sext i32 %161 to i64
  %164 = mul nsw i64 %163, %162
  %165 = sext i32 %156 to i64
  %166 = add nsw i64 %164, %165
  %167 = getelementptr double, ptr %159, i64 %166
  %168 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %157, i64 0, i32 6, i32 1
  %169 = load ptr, ptr %168, align 8
  %170 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %157, i64 0, i32 6, i32 0, i32 1
  %171 = load i32, ptr %170, align 4
  %172 = sext i32 %171 to i64
  %173 = mul nsw i64 %172, %162
  %174 = add nsw i64 %173, %165
  %175 = getelementptr double, ptr %169, i64 %174
  %176 = load double, ptr %175, align 8
  store double %176, ptr %167, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %177 = load ptr, ptr %7, align 8
  %178 = getelementptr inbounds %struct.LLVMRuntime, ptr %177, i64 0, i32 16
  %179 = load ptr, ptr %178, align 8
  %180 = load i32, ptr %179, align 4
  %.not.6 = icmp eq i32 %180, 0
  br i1 %.not.6, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %181 = add nsw i32 %lsr.iv, -1
  %182 = sdiv i32 %181, 70
  %183 = srem i32 %181, 70
  %184 = load ptr, ptr %0, align 8
  %185 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %184, i64 0, i32 7, i32 1
  %186 = load ptr, ptr %185, align 8
  %187 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %184, i64 0, i32 7, i32 0, i32 1
  %188 = load i32, ptr %187, align 4
  %189 = sext i32 %182 to i64
  %190 = sext i32 %188 to i64
  %191 = mul nsw i64 %190, %189
  %192 = sext i32 %183 to i64
  %193 = add nsw i64 %191, %192
  %194 = getelementptr double, ptr %186, i64 %193
  %195 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %184, i64 0, i32 6, i32 1
  %196 = load ptr, ptr %195, align 8
  %197 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %184, i64 0, i32 6, i32 0, i32 1
  %198 = load i32, ptr %197, align 4
  %199 = sext i32 %198 to i64
  %200 = mul nsw i64 %199, %189
  %201 = add nsw i64 %200, %192
  %202 = getelementptr double, ptr %196, i64 %201
  %203 = load double, ptr %202, align 8
  store double %203, ptr %194, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %204 = load ptr, ptr %7, align 8
  %205 = getelementptr inbounds %struct.LLVMRuntime, ptr %204, i64 0, i32 16
  %206 = load ptr, ptr %205, align 8
  %207 = load i32, ptr %206, align 4
  %.not.7 = icmp eq i32 %207, 0
  br i1 %.not.7, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %208 = sdiv i32 %lsr.iv, 70
  %209 = srem i32 %lsr.iv, 70
  %210 = load ptr, ptr %0, align 8
  %211 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %210, i64 0, i32 7, i32 1
  %212 = load ptr, ptr %211, align 8
  %213 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %210, i64 0, i32 7, i32 0, i32 1
  %214 = load i32, ptr %213, align 4
  %215 = sext i32 %208 to i64
  %216 = sext i32 %214 to i64
  %217 = mul nsw i64 %216, %215
  %218 = sext i32 %209 to i64
  %219 = add nsw i64 %217, %218
  %220 = getelementptr double, ptr %212, i64 %219
  %221 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %210, i64 0, i32 6, i32 1
  %222 = load ptr, ptr %221, align 8
  %223 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %210, i64 0, i32 6, i32 0, i32 1
  %224 = load i32, ptr %223, align 4
  %225 = sext i32 %224 to i64
  %226 = mul nsw i64 %225, %215
  %227 = add nsw i64 %226, %218
  %228 = getelementptr double, ptr %222, i64 %227
  %229 = load double, ptr %228, align 8
  store double %229, ptr %220, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %lsr.iv.next = add i32 %lsr.iv, 8
  %230 = add i32 %14, %lsr.iv.next
  %exitcond.not.7 = icmp eq i32 %230, 7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @selection_numeric_stage_28_kernel_5_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.4, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.727, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.4(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 280)
  %6 = icmp sgt i32 %5, %3
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.727, ptr %0, i64 0, i32 1
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.LLVMRuntime, ptr %8, i64 0, i32 16
  %10 = load ptr, ptr %9, align 8
  %11 = load i32, ptr %10, align 4
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.lr.ph
  %13 = add nuw nsw i32 %3, 7
  %14 = sub i32 0, %5
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %lsr.iv = phi i32 [ %13, %for_loop_body.preheader ], [ %lsr.iv.next, %after_if.7 ]
  %15 = add nsw i32 %lsr.iv, -7
  %16 = load ptr, ptr %7, align 8
  %17 = getelementptr inbounds %struct.LLVMRuntime, ptr %16, i64 0, i32 16
  %18 = load ptr, ptr %17, align 8
  %19 = load i32, ptr %18, align 4
  %.not = icmp eq i32 %19, 0
  br i1 %.not, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.lr.ph, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %20 = sdiv i32 %15, 70
  %21 = srem i32 %15, 70
  %22 = load ptr, ptr %0, align 8
  %23 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %22, i64 0, i32 9, i32 1
  %24 = load ptr, ptr %23, align 8
  %25 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %22, i64 0, i32 9, i32 0, i32 1
  %26 = load i32, ptr %25, align 4
  %27 = sext i32 %20 to i64
  %28 = sext i32 %26 to i64
  %29 = mul nsw i64 %28, %27
  %30 = sext i32 %21 to i64
  %31 = add nsw i64 %29, %30
  %32 = getelementptr double, ptr %24, i64 %31
  %33 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %22, i64 0, i32 8, i32 1
  %34 = load ptr, ptr %33, align 8
  %35 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %22, i64 0, i32 8, i32 0, i32 1
  %36 = load i32, ptr %35, align 4
  %37 = sext i32 %36 to i64
  %38 = mul nsw i64 %37, %27
  %39 = add nsw i64 %38, %30
  %40 = getelementptr double, ptr %34, i64 %39
  %41 = load double, ptr %40, align 8
  store double %41, ptr %32, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %42 = load ptr, ptr %7, align 8
  %43 = getelementptr inbounds %struct.LLVMRuntime, ptr %42, i64 0, i32 16
  %44 = load ptr, ptr %43, align 8
  %45 = load i32, ptr %44, align 4
  %.not.1 = icmp eq i32 %45, 0
  br i1 %.not.1, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %46 = add nsw i32 %lsr.iv, -6
  %47 = sdiv i32 %46, 70
  %48 = srem i32 %46, 70
  %49 = load ptr, ptr %0, align 8
  %50 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %49, i64 0, i32 9, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %49, i64 0, i32 9, i32 0, i32 1
  %53 = load i32, ptr %52, align 4
  %54 = sext i32 %47 to i64
  %55 = sext i32 %53 to i64
  %56 = mul nsw i64 %55, %54
  %57 = sext i32 %48 to i64
  %58 = add nsw i64 %56, %57
  %59 = getelementptr double, ptr %51, i64 %58
  %60 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %49, i64 0, i32 8, i32 1
  %61 = load ptr, ptr %60, align 8
  %62 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %49, i64 0, i32 8, i32 0, i32 1
  %63 = load i32, ptr %62, align 4
  %64 = sext i32 %63 to i64
  %65 = mul nsw i64 %64, %54
  %66 = add nsw i64 %65, %57
  %67 = getelementptr double, ptr %61, i64 %66
  %68 = load double, ptr %67, align 8
  store double %68, ptr %59, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %69 = load ptr, ptr %7, align 8
  %70 = getelementptr inbounds %struct.LLVMRuntime, ptr %69, i64 0, i32 16
  %71 = load ptr, ptr %70, align 8
  %72 = load i32, ptr %71, align 4
  %.not.2 = icmp eq i32 %72, 0
  br i1 %.not.2, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %73 = add nsw i32 %lsr.iv, -5
  %74 = sdiv i32 %73, 70
  %75 = srem i32 %73, 70
  %76 = load ptr, ptr %0, align 8
  %77 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %76, i64 0, i32 9, i32 1
  %78 = load ptr, ptr %77, align 8
  %79 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %76, i64 0, i32 9, i32 0, i32 1
  %80 = load i32, ptr %79, align 4
  %81 = sext i32 %74 to i64
  %82 = sext i32 %80 to i64
  %83 = mul nsw i64 %82, %81
  %84 = sext i32 %75 to i64
  %85 = add nsw i64 %83, %84
  %86 = getelementptr double, ptr %78, i64 %85
  %87 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %76, i64 0, i32 8, i32 1
  %88 = load ptr, ptr %87, align 8
  %89 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %76, i64 0, i32 8, i32 0, i32 1
  %90 = load i32, ptr %89, align 4
  %91 = sext i32 %90 to i64
  %92 = mul nsw i64 %91, %81
  %93 = add nsw i64 %92, %84
  %94 = getelementptr double, ptr %88, i64 %93
  %95 = load double, ptr %94, align 8
  store double %95, ptr %86, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %96 = load ptr, ptr %7, align 8
  %97 = getelementptr inbounds %struct.LLVMRuntime, ptr %96, i64 0, i32 16
  %98 = load ptr, ptr %97, align 8
  %99 = load i32, ptr %98, align 4
  %.not.3 = icmp eq i32 %99, 0
  br i1 %.not.3, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %100 = add nsw i32 %lsr.iv, -4
  %101 = sdiv i32 %100, 70
  %102 = srem i32 %100, 70
  %103 = load ptr, ptr %0, align 8
  %104 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %103, i64 0, i32 9, i32 1
  %105 = load ptr, ptr %104, align 8
  %106 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %103, i64 0, i32 9, i32 0, i32 1
  %107 = load i32, ptr %106, align 4
  %108 = sext i32 %101 to i64
  %109 = sext i32 %107 to i64
  %110 = mul nsw i64 %109, %108
  %111 = sext i32 %102 to i64
  %112 = add nsw i64 %110, %111
  %113 = getelementptr double, ptr %105, i64 %112
  %114 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %103, i64 0, i32 8, i32 1
  %115 = load ptr, ptr %114, align 8
  %116 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %103, i64 0, i32 8, i32 0, i32 1
  %117 = load i32, ptr %116, align 4
  %118 = sext i32 %117 to i64
  %119 = mul nsw i64 %118, %108
  %120 = add nsw i64 %119, %111
  %121 = getelementptr double, ptr %115, i64 %120
  %122 = load double, ptr %121, align 8
  store double %122, ptr %113, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %123 = load ptr, ptr %7, align 8
  %124 = getelementptr inbounds %struct.LLVMRuntime, ptr %123, i64 0, i32 16
  %125 = load ptr, ptr %124, align 8
  %126 = load i32, ptr %125, align 4
  %.not.4 = icmp eq i32 %126, 0
  br i1 %.not.4, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %127 = add nsw i32 %lsr.iv, -3
  %128 = sdiv i32 %127, 70
  %129 = srem i32 %127, 70
  %130 = load ptr, ptr %0, align 8
  %131 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %130, i64 0, i32 9, i32 1
  %132 = load ptr, ptr %131, align 8
  %133 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %130, i64 0, i32 9, i32 0, i32 1
  %134 = load i32, ptr %133, align 4
  %135 = sext i32 %128 to i64
  %136 = sext i32 %134 to i64
  %137 = mul nsw i64 %136, %135
  %138 = sext i32 %129 to i64
  %139 = add nsw i64 %137, %138
  %140 = getelementptr double, ptr %132, i64 %139
  %141 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %130, i64 0, i32 8, i32 1
  %142 = load ptr, ptr %141, align 8
  %143 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %130, i64 0, i32 8, i32 0, i32 1
  %144 = load i32, ptr %143, align 4
  %145 = sext i32 %144 to i64
  %146 = mul nsw i64 %145, %135
  %147 = add nsw i64 %146, %138
  %148 = getelementptr double, ptr %142, i64 %147
  %149 = load double, ptr %148, align 8
  store double %149, ptr %140, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %150 = load ptr, ptr %7, align 8
  %151 = getelementptr inbounds %struct.LLVMRuntime, ptr %150, i64 0, i32 16
  %152 = load ptr, ptr %151, align 8
  %153 = load i32, ptr %152, align 4
  %.not.5 = icmp eq i32 %153, 0
  br i1 %.not.5, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %154 = add nsw i32 %lsr.iv, -2
  %155 = sdiv i32 %154, 70
  %156 = srem i32 %154, 70
  %157 = load ptr, ptr %0, align 8
  %158 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %157, i64 0, i32 9, i32 1
  %159 = load ptr, ptr %158, align 8
  %160 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %157, i64 0, i32 9, i32 0, i32 1
  %161 = load i32, ptr %160, align 4
  %162 = sext i32 %155 to i64
  %163 = sext i32 %161 to i64
  %164 = mul nsw i64 %163, %162
  %165 = sext i32 %156 to i64
  %166 = add nsw i64 %164, %165
  %167 = getelementptr double, ptr %159, i64 %166
  %168 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %157, i64 0, i32 8, i32 1
  %169 = load ptr, ptr %168, align 8
  %170 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %157, i64 0, i32 8, i32 0, i32 1
  %171 = load i32, ptr %170, align 4
  %172 = sext i32 %171 to i64
  %173 = mul nsw i64 %172, %162
  %174 = add nsw i64 %173, %165
  %175 = getelementptr double, ptr %169, i64 %174
  %176 = load double, ptr %175, align 8
  store double %176, ptr %167, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %177 = load ptr, ptr %7, align 8
  %178 = getelementptr inbounds %struct.LLVMRuntime, ptr %177, i64 0, i32 16
  %179 = load ptr, ptr %178, align 8
  %180 = load i32, ptr %179, align 4
  %.not.6 = icmp eq i32 %180, 0
  br i1 %.not.6, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %181 = add nsw i32 %lsr.iv, -1
  %182 = sdiv i32 %181, 70
  %183 = srem i32 %181, 70
  %184 = load ptr, ptr %0, align 8
  %185 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %184, i64 0, i32 9, i32 1
  %186 = load ptr, ptr %185, align 8
  %187 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %184, i64 0, i32 9, i32 0, i32 1
  %188 = load i32, ptr %187, align 4
  %189 = sext i32 %182 to i64
  %190 = sext i32 %188 to i64
  %191 = mul nsw i64 %190, %189
  %192 = sext i32 %183 to i64
  %193 = add nsw i64 %191, %192
  %194 = getelementptr double, ptr %186, i64 %193
  %195 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %184, i64 0, i32 8, i32 1
  %196 = load ptr, ptr %195, align 8
  %197 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %184, i64 0, i32 8, i32 0, i32 1
  %198 = load i32, ptr %197, align 4
  %199 = sext i32 %198 to i64
  %200 = mul nsw i64 %199, %189
  %201 = add nsw i64 %200, %192
  %202 = getelementptr double, ptr %196, i64 %201
  %203 = load double, ptr %202, align 8
  store double %203, ptr %194, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %204 = load ptr, ptr %7, align 8
  %205 = getelementptr inbounds %struct.LLVMRuntime, ptr %204, i64 0, i32 16
  %206 = load ptr, ptr %205, align 8
  %207 = load i32, ptr %206, align 4
  %.not.7 = icmp eq i32 %207, 0
  br i1 %.not.7, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %208 = sdiv i32 %lsr.iv, 70
  %209 = srem i32 %lsr.iv, 70
  %210 = load ptr, ptr %0, align 8
  %211 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %210, i64 0, i32 9, i32 1
  %212 = load ptr, ptr %211, align 8
  %213 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %210, i64 0, i32 9, i32 0, i32 1
  %214 = load i32, ptr %213, align 4
  %215 = sext i32 %208 to i64
  %216 = sext i32 %214 to i64
  %217 = mul nsw i64 %216, %215
  %218 = sext i32 %209 to i64
  %219 = add nsw i64 %217, %218
  %220 = getelementptr double, ptr %212, i64 %219
  %221 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %210, i64 0, i32 8, i32 1
  %222 = load ptr, ptr %221, align 8
  %223 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %210, i64 0, i32 8, i32 0, i32 1
  %224 = load i32, ptr %223, align 4
  %225 = sext i32 %224 to i64
  %226 = mul nsw i64 %225, %215
  %227 = add nsw i64 %226, %218
  %228 = getelementptr double, ptr %222, i64 %227
  %229 = load double, ptr %228, align 8
  store double %229, ptr %220, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %lsr.iv.next = add i32 %lsr.iv, 8
  %230 = add i32 %14, %lsr.iv.next
  %exitcond.not.7 = icmp eq i32 %230, 7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @selection_numeric_stage_28_kernel_6_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.5, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.727, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.5(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 10)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.727, ptr %0, i64 0, i32 1
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.LLVMRuntime, ptr %8, i64 0, i32 16
  %10 = load ptr, ptr %9, align 8
  %11 = load i32, ptr %10, align 4
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.lr.ph
  %13 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %14 = xor i64 %13, -1
  %15 = add nsw i64 %14, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 2
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.preheader
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %13, %for_loop_body.prol.preheader ]
  %16 = load ptr, ptr %7, align 8
  %17 = getelementptr inbounds %struct.LLVMRuntime, ptr %16, i64 0, i32 16
  %18 = load ptr, ptr %17, align 8
  %19 = load i32, ptr %18, align 4
  %.not.prol = icmp eq i32 %19, 0
  br i1 %.not.prol, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %20 = load ptr, ptr %0, align 8
  %21 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %20, i64 0, i32 11, i32 1
  %22 = load ptr, ptr %21, align 8
  %23 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep38 = getelementptr i8, ptr %22, i64 %23
  %24 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %20, i64 0, i32 10, i32 1
  %25 = load ptr, ptr %24, align 8
  %uglygep37 = getelementptr i8, ptr %25, i64 %23
  %26 = load i64, ptr %uglygep37, align 8
  store i64 %26, ptr %uglygep38, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !9

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.preheader
  %indvars.iv.unr = phi i64 [ %13, %for_loop_body.preheader ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %27 = icmp ult i64 %15, 7
  br i1 %27, label %after_for, label %for_loop_body.preheader7

for_loop_body.preheader7:                         ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader7
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader7 ]
  %28 = load ptr, ptr %7, align 8
  %29 = getelementptr inbounds %struct.LLVMRuntime, ptr %28, i64 0, i32 16
  %30 = load ptr, ptr %29, align 8
  %31 = load i32, ptr %30, align 4
  %.not = icmp eq i32 %31, 0
  br i1 %.not, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %for_loop_body.lr.ph, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %32 = load ptr, ptr %0, align 8
  %33 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %32, i64 0, i32 11, i32 1
  %34 = load ptr, ptr %33, align 8
  %35 = shl i64 %indvars.iv, 3
  %uglygep31 = getelementptr i8, ptr %34, i64 %35
  %36 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %32, i64 0, i32 10, i32 1
  %37 = load ptr, ptr %36, align 8
  %uglygep32 = getelementptr i8, ptr %37, i64 %35
  %38 = load i64, ptr %uglygep32, align 8
  store i64 %38, ptr %uglygep31, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %39 = load ptr, ptr %7, align 8
  %40 = getelementptr inbounds %struct.LLVMRuntime, ptr %39, i64 0, i32 16
  %41 = load ptr, ptr %40, align 8
  %42 = load i32, ptr %41, align 4
  %.not.1 = icmp eq i32 %42, 0
  br i1 %.not.1, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %43 = load ptr, ptr %0, align 8
  %44 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %43, i64 0, i32 11, i32 1
  %45 = load ptr, ptr %44, align 8
  %uglygep35 = getelementptr i8, ptr %45, i64 8
  %46 = shl i64 %indvars.iv, 3
  %uglygep36 = getelementptr i8, ptr %uglygep35, i64 %46
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %43, i64 0, i32 10, i32 1
  %48 = load ptr, ptr %47, align 8
  %uglygep33 = getelementptr i8, ptr %48, i64 8
  %uglygep34 = getelementptr i8, ptr %uglygep33, i64 %46
  %49 = load i64, ptr %uglygep34, align 8
  store i64 %49, ptr %uglygep36, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %50 = load ptr, ptr %7, align 8
  %51 = getelementptr inbounds %struct.LLVMRuntime, ptr %50, i64 0, i32 16
  %52 = load ptr, ptr %51, align 8
  %53 = load i32, ptr %52, align 4
  %.not.2 = icmp eq i32 %53, 0
  br i1 %.not.2, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %54 = load ptr, ptr %0, align 8
  %55 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %54, i64 0, i32 11, i32 1
  %56 = load ptr, ptr %55, align 8
  %uglygep29 = getelementptr i8, ptr %56, i64 16
  %57 = shl i64 %indvars.iv, 3
  %uglygep30 = getelementptr i8, ptr %uglygep29, i64 %57
  %58 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %54, i64 0, i32 10, i32 1
  %59 = load ptr, ptr %58, align 8
  %uglygep27 = getelementptr i8, ptr %59, i64 16
  %uglygep28 = getelementptr i8, ptr %uglygep27, i64 %57
  %60 = load i64, ptr %uglygep28, align 8
  store i64 %60, ptr %uglygep30, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %61 = load ptr, ptr %7, align 8
  %62 = getelementptr inbounds %struct.LLVMRuntime, ptr %61, i64 0, i32 16
  %63 = load ptr, ptr %62, align 8
  %64 = load i32, ptr %63, align 4
  %.not.3 = icmp eq i32 %64, 0
  br i1 %.not.3, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %65 = load ptr, ptr %0, align 8
  %66 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %65, i64 0, i32 11, i32 1
  %67 = load ptr, ptr %66, align 8
  %uglygep25 = getelementptr i8, ptr %67, i64 24
  %68 = shl i64 %indvars.iv, 3
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %68
  %69 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %65, i64 0, i32 10, i32 1
  %70 = load ptr, ptr %69, align 8
  %uglygep23 = getelementptr i8, ptr %70, i64 24
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %68
  %71 = load i64, ptr %uglygep24, align 8
  store i64 %71, ptr %uglygep26, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %72 = load ptr, ptr %7, align 8
  %73 = getelementptr inbounds %struct.LLVMRuntime, ptr %72, i64 0, i32 16
  %74 = load ptr, ptr %73, align 8
  %75 = load i32, ptr %74, align 4
  %.not.4 = icmp eq i32 %75, 0
  br i1 %.not.4, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %76 = load ptr, ptr %0, align 8
  %77 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %76, i64 0, i32 11, i32 1
  %78 = load ptr, ptr %77, align 8
  %uglygep21 = getelementptr i8, ptr %78, i64 32
  %79 = shl i64 %indvars.iv, 3
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 %79
  %80 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %76, i64 0, i32 10, i32 1
  %81 = load ptr, ptr %80, align 8
  %uglygep19 = getelementptr i8, ptr %81, i64 32
  %uglygep20 = getelementptr i8, ptr %uglygep19, i64 %79
  %82 = load i64, ptr %uglygep20, align 8
  store i64 %82, ptr %uglygep22, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %83 = load ptr, ptr %7, align 8
  %84 = getelementptr inbounds %struct.LLVMRuntime, ptr %83, i64 0, i32 16
  %85 = load ptr, ptr %84, align 8
  %86 = load i32, ptr %85, align 4
  %.not.5 = icmp eq i32 %86, 0
  br i1 %.not.5, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %87 = load ptr, ptr %0, align 8
  %88 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %87, i64 0, i32 11, i32 1
  %89 = load ptr, ptr %88, align 8
  %uglygep17 = getelementptr i8, ptr %89, i64 40
  %90 = shl i64 %indvars.iv, 3
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %90
  %91 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %87, i64 0, i32 10, i32 1
  %92 = load ptr, ptr %91, align 8
  %uglygep15 = getelementptr i8, ptr %92, i64 40
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %90
  %93 = load i64, ptr %uglygep16, align 8
  store i64 %93, ptr %uglygep18, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %94 = load ptr, ptr %7, align 8
  %95 = getelementptr inbounds %struct.LLVMRuntime, ptr %94, i64 0, i32 16
  %96 = load ptr, ptr %95, align 8
  %97 = load i32, ptr %96, align 4
  %.not.6 = icmp eq i32 %97, 0
  br i1 %.not.6, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %98 = load ptr, ptr %0, align 8
  %99 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %98, i64 0, i32 11, i32 1
  %100 = load ptr, ptr %99, align 8
  %uglygep13 = getelementptr i8, ptr %100, i64 48
  %101 = shl i64 %indvars.iv, 3
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %101
  %102 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %98, i64 0, i32 10, i32 1
  %103 = load ptr, ptr %102, align 8
  %uglygep11 = getelementptr i8, ptr %103, i64 48
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %101
  %104 = load i64, ptr %uglygep12, align 8
  store i64 %104, ptr %uglygep14, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %105 = load ptr, ptr %7, align 8
  %106 = getelementptr inbounds %struct.LLVMRuntime, ptr %105, i64 0, i32 16
  %107 = load ptr, ptr %106, align 8
  %108 = load i32, ptr %107, align 4
  %.not.7 = icmp eq i32 %108, 0
  br i1 %.not.7, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %109 = load ptr, ptr %0, align 8
  %110 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %109, i64 0, i32 11, i32 1
  %111 = load ptr, ptr %110, align 8
  %uglygep9 = getelementptr i8, ptr %111, i64 56
  %112 = shl i64 %indvars.iv, 3
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %112
  %113 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %109, i64 0, i32 10, i32 1
  %114 = load ptr, ptr %113, align 8
  %uglygep = getelementptr i8, ptr %114, i64 56
  %uglygep8 = getelementptr i8, ptr %uglygep, i64 %112
  %115 = load i64, ptr %uglygep8, align 8
  store i64 %115, ptr %uglygep10, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @selection_numeric_stage_28_kernel_7_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.6, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.727, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.6(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 20)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.727, ptr %0, i64 0, i32 1
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.LLVMRuntime, ptr %8, i64 0, i32 16
  %10 = load ptr, ptr %9, align 8
  %11 = load i32, ptr %10, align 4
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.lr.ph
  %13 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %14 = xor i64 %13, -1
  %15 = add nsw i64 %14, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 4
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.preheader
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %13, %for_loop_body.prol.preheader ]
  %16 = load ptr, ptr %7, align 8
  %17 = getelementptr inbounds %struct.LLVMRuntime, ptr %16, i64 0, i32 16
  %18 = load ptr, ptr %17, align 8
  %19 = load i32, ptr %18, align 4
  %.not.prol = icmp eq i32 %19, 0
  br i1 %.not.prol, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %20 = load ptr, ptr %0, align 8
  %21 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %20, i64 0, i32 13, i32 1
  %22 = load ptr, ptr %21, align 8
  %23 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep38 = getelementptr i8, ptr %22, i64 %23
  %24 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %20, i64 0, i32 12, i32 1
  %25 = load ptr, ptr %24, align 8
  %uglygep37 = getelementptr i8, ptr %25, i64 %23
  %26 = load i64, ptr %uglygep37, align 8
  store i64 %26, ptr %uglygep38, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !10

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.preheader
  %indvars.iv.unr = phi i64 [ %13, %for_loop_body.preheader ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %27 = icmp ult i64 %15, 7
  br i1 %27, label %after_for, label %for_loop_body.preheader7

for_loop_body.preheader7:                         ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader7
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader7 ]
  %28 = load ptr, ptr %7, align 8
  %29 = getelementptr inbounds %struct.LLVMRuntime, ptr %28, i64 0, i32 16
  %30 = load ptr, ptr %29, align 8
  %31 = load i32, ptr %30, align 4
  %.not = icmp eq i32 %31, 0
  br i1 %.not, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %for_loop_body.lr.ph, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %32 = load ptr, ptr %0, align 8
  %33 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %32, i64 0, i32 13, i32 1
  %34 = load ptr, ptr %33, align 8
  %35 = shl i64 %indvars.iv, 3
  %uglygep31 = getelementptr i8, ptr %34, i64 %35
  %36 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %32, i64 0, i32 12, i32 1
  %37 = load ptr, ptr %36, align 8
  %uglygep32 = getelementptr i8, ptr %37, i64 %35
  %38 = load i64, ptr %uglygep32, align 8
  store i64 %38, ptr %uglygep31, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %39 = load ptr, ptr %7, align 8
  %40 = getelementptr inbounds %struct.LLVMRuntime, ptr %39, i64 0, i32 16
  %41 = load ptr, ptr %40, align 8
  %42 = load i32, ptr %41, align 4
  %.not.1 = icmp eq i32 %42, 0
  br i1 %.not.1, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %43 = load ptr, ptr %0, align 8
  %44 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %43, i64 0, i32 13, i32 1
  %45 = load ptr, ptr %44, align 8
  %uglygep35 = getelementptr i8, ptr %45, i64 8
  %46 = shl i64 %indvars.iv, 3
  %uglygep36 = getelementptr i8, ptr %uglygep35, i64 %46
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %43, i64 0, i32 12, i32 1
  %48 = load ptr, ptr %47, align 8
  %uglygep33 = getelementptr i8, ptr %48, i64 8
  %uglygep34 = getelementptr i8, ptr %uglygep33, i64 %46
  %49 = load i64, ptr %uglygep34, align 8
  store i64 %49, ptr %uglygep36, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %50 = load ptr, ptr %7, align 8
  %51 = getelementptr inbounds %struct.LLVMRuntime, ptr %50, i64 0, i32 16
  %52 = load ptr, ptr %51, align 8
  %53 = load i32, ptr %52, align 4
  %.not.2 = icmp eq i32 %53, 0
  br i1 %.not.2, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %54 = load ptr, ptr %0, align 8
  %55 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %54, i64 0, i32 13, i32 1
  %56 = load ptr, ptr %55, align 8
  %uglygep29 = getelementptr i8, ptr %56, i64 16
  %57 = shl i64 %indvars.iv, 3
  %uglygep30 = getelementptr i8, ptr %uglygep29, i64 %57
  %58 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %54, i64 0, i32 12, i32 1
  %59 = load ptr, ptr %58, align 8
  %uglygep27 = getelementptr i8, ptr %59, i64 16
  %uglygep28 = getelementptr i8, ptr %uglygep27, i64 %57
  %60 = load i64, ptr %uglygep28, align 8
  store i64 %60, ptr %uglygep30, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %61 = load ptr, ptr %7, align 8
  %62 = getelementptr inbounds %struct.LLVMRuntime, ptr %61, i64 0, i32 16
  %63 = load ptr, ptr %62, align 8
  %64 = load i32, ptr %63, align 4
  %.not.3 = icmp eq i32 %64, 0
  br i1 %.not.3, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %65 = load ptr, ptr %0, align 8
  %66 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %65, i64 0, i32 13, i32 1
  %67 = load ptr, ptr %66, align 8
  %uglygep25 = getelementptr i8, ptr %67, i64 24
  %68 = shl i64 %indvars.iv, 3
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %68
  %69 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %65, i64 0, i32 12, i32 1
  %70 = load ptr, ptr %69, align 8
  %uglygep23 = getelementptr i8, ptr %70, i64 24
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %68
  %71 = load i64, ptr %uglygep24, align 8
  store i64 %71, ptr %uglygep26, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %72 = load ptr, ptr %7, align 8
  %73 = getelementptr inbounds %struct.LLVMRuntime, ptr %72, i64 0, i32 16
  %74 = load ptr, ptr %73, align 8
  %75 = load i32, ptr %74, align 4
  %.not.4 = icmp eq i32 %75, 0
  br i1 %.not.4, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %76 = load ptr, ptr %0, align 8
  %77 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %76, i64 0, i32 13, i32 1
  %78 = load ptr, ptr %77, align 8
  %uglygep21 = getelementptr i8, ptr %78, i64 32
  %79 = shl i64 %indvars.iv, 3
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 %79
  %80 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %76, i64 0, i32 12, i32 1
  %81 = load ptr, ptr %80, align 8
  %uglygep19 = getelementptr i8, ptr %81, i64 32
  %uglygep20 = getelementptr i8, ptr %uglygep19, i64 %79
  %82 = load i64, ptr %uglygep20, align 8
  store i64 %82, ptr %uglygep22, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %83 = load ptr, ptr %7, align 8
  %84 = getelementptr inbounds %struct.LLVMRuntime, ptr %83, i64 0, i32 16
  %85 = load ptr, ptr %84, align 8
  %86 = load i32, ptr %85, align 4
  %.not.5 = icmp eq i32 %86, 0
  br i1 %.not.5, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %87 = load ptr, ptr %0, align 8
  %88 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %87, i64 0, i32 13, i32 1
  %89 = load ptr, ptr %88, align 8
  %uglygep17 = getelementptr i8, ptr %89, i64 40
  %90 = shl i64 %indvars.iv, 3
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %90
  %91 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %87, i64 0, i32 12, i32 1
  %92 = load ptr, ptr %91, align 8
  %uglygep15 = getelementptr i8, ptr %92, i64 40
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %90
  %93 = load i64, ptr %uglygep16, align 8
  store i64 %93, ptr %uglygep18, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %94 = load ptr, ptr %7, align 8
  %95 = getelementptr inbounds %struct.LLVMRuntime, ptr %94, i64 0, i32 16
  %96 = load ptr, ptr %95, align 8
  %97 = load i32, ptr %96, align 4
  %.not.6 = icmp eq i32 %97, 0
  br i1 %.not.6, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %98 = load ptr, ptr %0, align 8
  %99 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %98, i64 0, i32 13, i32 1
  %100 = load ptr, ptr %99, align 8
  %uglygep13 = getelementptr i8, ptr %100, i64 48
  %101 = shl i64 %indvars.iv, 3
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %101
  %102 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %98, i64 0, i32 12, i32 1
  %103 = load ptr, ptr %102, align 8
  %uglygep11 = getelementptr i8, ptr %103, i64 48
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %101
  %104 = load i64, ptr %uglygep12, align 8
  store i64 %104, ptr %uglygep14, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %105 = load ptr, ptr %7, align 8
  %106 = getelementptr inbounds %struct.LLVMRuntime, ptr %105, i64 0, i32 16
  %107 = load ptr, ptr %106, align 8
  %108 = load i32, ptr %107, align 4
  %.not.7 = icmp eq i32 %108, 0
  br i1 %.not.7, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %109 = load ptr, ptr %0, align 8
  %110 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %109, i64 0, i32 13, i32 1
  %111 = load ptr, ptr %110, align 8
  %uglygep9 = getelementptr i8, ptr %111, i64 56
  %112 = shl i64 %indvars.iv, 3
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %112
  %113 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %109, i64 0, i32 12, i32 1
  %114 = load ptr, ptr %113, align 8
  %uglygep = getelementptr i8, ptr %114, i64 56
  %uglygep8 = getelementptr i8, ptr %uglygep, i64 %112
  %115 = load i64, ptr %uglygep8, align 8
  store i64 %115, ptr %uglygep10, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @selection_numeric_stage_28_kernel_8_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.7, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.727, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.7(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 420)
  %6 = icmp sgt i32 %5, %3
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.727, ptr %0, i64 0, i32 1
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.LLVMRuntime, ptr %8, i64 0, i32 16
  %10 = load ptr, ptr %9, align 8
  %11 = load i32, ptr %10, align 4
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.lr.ph
  %13 = xor i32 %3, -1
  %14 = add i32 %5, %13
  %xtraiter = and i32 %5, 4
  %lcmp.mod.not = icmp eq i32 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.preheader
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv7 = phi i32 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next8, %after_if.prol ]
  %.04.prol = phi i32 [ %41, %after_if.prol ], [ %3, %for_loop_body.prol.preheader ]
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds %struct.LLVMRuntime, ptr %15, i64 0, i32 16
  %17 = load ptr, ptr %16, align 8
  %18 = load i32, ptr %17, align 4
  %.not.prol = icmp eq i32 %18, 0
  br i1 %.not.prol, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %19 = sdiv i32 %.04.prol, 70
  %20 = srem i32 %.04.prol, 70
  %21 = load ptr, ptr %0, align 8
  %22 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %21, i64 0, i32 15, i32 1
  %23 = load ptr, ptr %22, align 8
  %24 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %21, i64 0, i32 15, i32 0, i32 1
  %25 = load i32, ptr %24, align 4
  %26 = sext i32 %19 to i64
  %27 = sext i32 %25 to i64
  %28 = mul nsw i64 %27, %26
  %29 = sext i32 %20 to i64
  %30 = add nsw i64 %28, %29
  %31 = getelementptr double, ptr %23, i64 %30
  %32 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %21, i64 0, i32 14, i32 1
  %33 = load ptr, ptr %32, align 8
  %34 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %21, i64 0, i32 14, i32 0, i32 1
  %35 = load i32, ptr %34, align 4
  %36 = sext i32 %35 to i64
  %37 = mul nsw i64 %36, %26
  %38 = add nsw i64 %37, %29
  %39 = getelementptr double, ptr %33, i64 %38
  %40 = load double, ptr %39, align 8
  store double %40, ptr %31, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %41 = add nuw nsw i32 %.04.prol, 1
  %lsr.iv.next8 = add nsw i32 %lsr.iv7, -1
  %prol.iter.cmp.not = icmp eq i32 %lsr.iv.next8, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !11

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.preheader
  %.04.unr = phi i32 [ %3, %for_loop_body.preheader ], [ %41, %for_loop_body.prol.loopexit.loopexit ]
  %42 = icmp ult i32 %14, 7
  br i1 %42, label %after_for, label %for_loop_body.preheader6

for_loop_body.preheader6:                         ; preds = %for_loop_body.prol.loopexit
  %43 = sub i32 0, %5
  %44 = add nuw i32 %.04.unr, 7
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader6
  %lsr.iv = phi i32 [ %44, %for_loop_body.preheader6 ], [ %lsr.iv.next, %after_if.7 ]
  %45 = add i32 %lsr.iv, -7
  %46 = load ptr, ptr %7, align 8
  %47 = getelementptr inbounds %struct.LLVMRuntime, ptr %46, i64 0, i32 16
  %48 = load ptr, ptr %47, align 8
  %49 = load i32, ptr %48, align 4
  %.not = icmp eq i32 %49, 0
  br i1 %.not, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %for_loop_body.lr.ph, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %50 = sdiv i32 %45, 70
  %51 = srem i32 %45, 70
  %52 = load ptr, ptr %0, align 8
  %53 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %52, i64 0, i32 15, i32 1
  %54 = load ptr, ptr %53, align 8
  %55 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %52, i64 0, i32 15, i32 0, i32 1
  %56 = load i32, ptr %55, align 4
  %57 = sext i32 %50 to i64
  %58 = sext i32 %56 to i64
  %59 = mul nsw i64 %58, %57
  %60 = sext i32 %51 to i64
  %61 = add nsw i64 %59, %60
  %62 = getelementptr double, ptr %54, i64 %61
  %63 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %52, i64 0, i32 14, i32 1
  %64 = load ptr, ptr %63, align 8
  %65 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %52, i64 0, i32 14, i32 0, i32 1
  %66 = load i32, ptr %65, align 4
  %67 = sext i32 %66 to i64
  %68 = mul nsw i64 %67, %57
  %69 = add nsw i64 %68, %60
  %70 = getelementptr double, ptr %64, i64 %69
  %71 = load double, ptr %70, align 8
  store double %71, ptr %62, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %72 = load ptr, ptr %7, align 8
  %73 = getelementptr inbounds %struct.LLVMRuntime, ptr %72, i64 0, i32 16
  %74 = load ptr, ptr %73, align 8
  %75 = load i32, ptr %74, align 4
  %.not.1 = icmp eq i32 %75, 0
  br i1 %.not.1, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %76 = add i32 %lsr.iv, -6
  %77 = sdiv i32 %76, 70
  %78 = srem i32 %76, 70
  %79 = load ptr, ptr %0, align 8
  %80 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %79, i64 0, i32 15, i32 1
  %81 = load ptr, ptr %80, align 8
  %82 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %79, i64 0, i32 15, i32 0, i32 1
  %83 = load i32, ptr %82, align 4
  %84 = sext i32 %77 to i64
  %85 = sext i32 %83 to i64
  %86 = mul nsw i64 %85, %84
  %87 = sext i32 %78 to i64
  %88 = add nsw i64 %86, %87
  %89 = getelementptr double, ptr %81, i64 %88
  %90 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %79, i64 0, i32 14, i32 1
  %91 = load ptr, ptr %90, align 8
  %92 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %79, i64 0, i32 14, i32 0, i32 1
  %93 = load i32, ptr %92, align 4
  %94 = sext i32 %93 to i64
  %95 = mul nsw i64 %94, %84
  %96 = add nsw i64 %95, %87
  %97 = getelementptr double, ptr %91, i64 %96
  %98 = load double, ptr %97, align 8
  store double %98, ptr %89, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %99 = load ptr, ptr %7, align 8
  %100 = getelementptr inbounds %struct.LLVMRuntime, ptr %99, i64 0, i32 16
  %101 = load ptr, ptr %100, align 8
  %102 = load i32, ptr %101, align 4
  %.not.2 = icmp eq i32 %102, 0
  br i1 %.not.2, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %103 = add i32 %lsr.iv, -5
  %104 = sdiv i32 %103, 70
  %105 = srem i32 %103, 70
  %106 = load ptr, ptr %0, align 8
  %107 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %106, i64 0, i32 15, i32 1
  %108 = load ptr, ptr %107, align 8
  %109 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %106, i64 0, i32 15, i32 0, i32 1
  %110 = load i32, ptr %109, align 4
  %111 = sext i32 %104 to i64
  %112 = sext i32 %110 to i64
  %113 = mul nsw i64 %112, %111
  %114 = sext i32 %105 to i64
  %115 = add nsw i64 %113, %114
  %116 = getelementptr double, ptr %108, i64 %115
  %117 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %106, i64 0, i32 14, i32 1
  %118 = load ptr, ptr %117, align 8
  %119 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %106, i64 0, i32 14, i32 0, i32 1
  %120 = load i32, ptr %119, align 4
  %121 = sext i32 %120 to i64
  %122 = mul nsw i64 %121, %111
  %123 = add nsw i64 %122, %114
  %124 = getelementptr double, ptr %118, i64 %123
  %125 = load double, ptr %124, align 8
  store double %125, ptr %116, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %126 = load ptr, ptr %7, align 8
  %127 = getelementptr inbounds %struct.LLVMRuntime, ptr %126, i64 0, i32 16
  %128 = load ptr, ptr %127, align 8
  %129 = load i32, ptr %128, align 4
  %.not.3 = icmp eq i32 %129, 0
  br i1 %.not.3, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %130 = add i32 %lsr.iv, -4
  %131 = sdiv i32 %130, 70
  %132 = srem i32 %130, 70
  %133 = load ptr, ptr %0, align 8
  %134 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %133, i64 0, i32 15, i32 1
  %135 = load ptr, ptr %134, align 8
  %136 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %133, i64 0, i32 15, i32 0, i32 1
  %137 = load i32, ptr %136, align 4
  %138 = sext i32 %131 to i64
  %139 = sext i32 %137 to i64
  %140 = mul nsw i64 %139, %138
  %141 = sext i32 %132 to i64
  %142 = add nsw i64 %140, %141
  %143 = getelementptr double, ptr %135, i64 %142
  %144 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %133, i64 0, i32 14, i32 1
  %145 = load ptr, ptr %144, align 8
  %146 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %133, i64 0, i32 14, i32 0, i32 1
  %147 = load i32, ptr %146, align 4
  %148 = sext i32 %147 to i64
  %149 = mul nsw i64 %148, %138
  %150 = add nsw i64 %149, %141
  %151 = getelementptr double, ptr %145, i64 %150
  %152 = load double, ptr %151, align 8
  store double %152, ptr %143, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %153 = load ptr, ptr %7, align 8
  %154 = getelementptr inbounds %struct.LLVMRuntime, ptr %153, i64 0, i32 16
  %155 = load ptr, ptr %154, align 8
  %156 = load i32, ptr %155, align 4
  %.not.4 = icmp eq i32 %156, 0
  br i1 %.not.4, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %157 = add i32 %lsr.iv, -3
  %158 = sdiv i32 %157, 70
  %159 = srem i32 %157, 70
  %160 = load ptr, ptr %0, align 8
  %161 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %160, i64 0, i32 15, i32 1
  %162 = load ptr, ptr %161, align 8
  %163 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %160, i64 0, i32 15, i32 0, i32 1
  %164 = load i32, ptr %163, align 4
  %165 = sext i32 %158 to i64
  %166 = sext i32 %164 to i64
  %167 = mul nsw i64 %166, %165
  %168 = sext i32 %159 to i64
  %169 = add nsw i64 %167, %168
  %170 = getelementptr double, ptr %162, i64 %169
  %171 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %160, i64 0, i32 14, i32 1
  %172 = load ptr, ptr %171, align 8
  %173 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %160, i64 0, i32 14, i32 0, i32 1
  %174 = load i32, ptr %173, align 4
  %175 = sext i32 %174 to i64
  %176 = mul nsw i64 %175, %165
  %177 = add nsw i64 %176, %168
  %178 = getelementptr double, ptr %172, i64 %177
  %179 = load double, ptr %178, align 8
  store double %179, ptr %170, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %180 = load ptr, ptr %7, align 8
  %181 = getelementptr inbounds %struct.LLVMRuntime, ptr %180, i64 0, i32 16
  %182 = load ptr, ptr %181, align 8
  %183 = load i32, ptr %182, align 4
  %.not.5 = icmp eq i32 %183, 0
  br i1 %.not.5, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %184 = add i32 %lsr.iv, -2
  %185 = sdiv i32 %184, 70
  %186 = srem i32 %184, 70
  %187 = load ptr, ptr %0, align 8
  %188 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %187, i64 0, i32 15, i32 1
  %189 = load ptr, ptr %188, align 8
  %190 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %187, i64 0, i32 15, i32 0, i32 1
  %191 = load i32, ptr %190, align 4
  %192 = sext i32 %185 to i64
  %193 = sext i32 %191 to i64
  %194 = mul nsw i64 %193, %192
  %195 = sext i32 %186 to i64
  %196 = add nsw i64 %194, %195
  %197 = getelementptr double, ptr %189, i64 %196
  %198 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %187, i64 0, i32 14, i32 1
  %199 = load ptr, ptr %198, align 8
  %200 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %187, i64 0, i32 14, i32 0, i32 1
  %201 = load i32, ptr %200, align 4
  %202 = sext i32 %201 to i64
  %203 = mul nsw i64 %202, %192
  %204 = add nsw i64 %203, %195
  %205 = getelementptr double, ptr %199, i64 %204
  %206 = load double, ptr %205, align 8
  store double %206, ptr %197, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %207 = load ptr, ptr %7, align 8
  %208 = getelementptr inbounds %struct.LLVMRuntime, ptr %207, i64 0, i32 16
  %209 = load ptr, ptr %208, align 8
  %210 = load i32, ptr %209, align 4
  %.not.6 = icmp eq i32 %210, 0
  br i1 %.not.6, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %211 = add i32 %lsr.iv, -1
  %212 = sdiv i32 %211, 70
  %213 = srem i32 %211, 70
  %214 = load ptr, ptr %0, align 8
  %215 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %214, i64 0, i32 15, i32 1
  %216 = load ptr, ptr %215, align 8
  %217 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %214, i64 0, i32 15, i32 0, i32 1
  %218 = load i32, ptr %217, align 4
  %219 = sext i32 %212 to i64
  %220 = sext i32 %218 to i64
  %221 = mul nsw i64 %220, %219
  %222 = sext i32 %213 to i64
  %223 = add nsw i64 %221, %222
  %224 = getelementptr double, ptr %216, i64 %223
  %225 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %214, i64 0, i32 14, i32 1
  %226 = load ptr, ptr %225, align 8
  %227 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %214, i64 0, i32 14, i32 0, i32 1
  %228 = load i32, ptr %227, align 4
  %229 = sext i32 %228 to i64
  %230 = mul nsw i64 %229, %219
  %231 = add nsw i64 %230, %222
  %232 = getelementptr double, ptr %226, i64 %231
  %233 = load double, ptr %232, align 8
  store double %233, ptr %224, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %234 = load ptr, ptr %7, align 8
  %235 = getelementptr inbounds %struct.LLVMRuntime, ptr %234, i64 0, i32 16
  %236 = load ptr, ptr %235, align 8
  %237 = load i32, ptr %236, align 4
  %.not.7 = icmp eq i32 %237, 0
  br i1 %.not.7, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %238 = sdiv i32 %lsr.iv, 70
  %239 = srem i32 %lsr.iv, 70
  %240 = load ptr, ptr %0, align 8
  %241 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %240, i64 0, i32 15, i32 1
  %242 = load ptr, ptr %241, align 8
  %243 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %240, i64 0, i32 15, i32 0, i32 1
  %244 = load i32, ptr %243, align 4
  %245 = sext i32 %238 to i64
  %246 = sext i32 %244 to i64
  %247 = mul nsw i64 %246, %245
  %248 = sext i32 %239 to i64
  %249 = add nsw i64 %247, %248
  %250 = getelementptr double, ptr %242, i64 %249
  %251 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %240, i64 0, i32 14, i32 1
  %252 = load ptr, ptr %251, align 8
  %253 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %240, i64 0, i32 14, i32 0, i32 1
  %254 = load i32, ptr %253, align 4
  %255 = sext i32 %254 to i64
  %256 = mul nsw i64 %255, %245
  %257 = add nsw i64 %256, %248
  %258 = getelementptr double, ptr %252, i64 %257
  %259 = load double, ptr %258, align 8
  store double %259, ptr %250, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %lsr.iv.next = add i32 %lsr.iv, 8
  %260 = add i32 %43, %lsr.iv.next
  %exitcond.not.7 = icmp eq i32 %260, 7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @selection_numeric_stage_28_kernel_9_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.8, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.727, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.8(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 140)
  %6 = icmp sgt i32 %5, %3
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.727, ptr %0, i64 0, i32 1
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.LLVMRuntime, ptr %8, i64 0, i32 16
  %10 = load ptr, ptr %9, align 8
  %11 = load i32, ptr %10, align 4
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.lr.ph
  %13 = xor i32 %3, -1
  %14 = add i32 %5, %13
  %xtraiter = and i32 %5, 4
  %lcmp.mod.not = icmp eq i32 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.preheader
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv7 = phi i32 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next8, %after_if.prol ]
  %.04.prol = phi i32 [ %41, %after_if.prol ], [ %3, %for_loop_body.prol.preheader ]
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds %struct.LLVMRuntime, ptr %15, i64 0, i32 16
  %17 = load ptr, ptr %16, align 8
  %18 = load i32, ptr %17, align 4
  %.not.prol = icmp eq i32 %18, 0
  br i1 %.not.prol, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %19 = sdiv i32 %.04.prol, 70
  %20 = srem i32 %.04.prol, 70
  %21 = load ptr, ptr %0, align 8
  %22 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %21, i64 0, i32 17, i32 1
  %23 = load ptr, ptr %22, align 8
  %24 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %21, i64 0, i32 17, i32 0, i32 1
  %25 = load i32, ptr %24, align 4
  %26 = sext i32 %19 to i64
  %27 = sext i32 %25 to i64
  %28 = mul nsw i64 %27, %26
  %29 = sext i32 %20 to i64
  %30 = add nsw i64 %28, %29
  %31 = getelementptr i64, ptr %23, i64 %30
  %32 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %21, i64 0, i32 16, i32 1
  %33 = load ptr, ptr %32, align 8
  %34 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %21, i64 0, i32 16, i32 0, i32 1
  %35 = load i32, ptr %34, align 4
  %36 = sext i32 %35 to i64
  %37 = mul nsw i64 %36, %26
  %38 = add nsw i64 %37, %29
  %39 = getelementptr i64, ptr %33, i64 %38
  %40 = load i64, ptr %39, align 8
  store i64 %40, ptr %31, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %41 = add nuw nsw i32 %.04.prol, 1
  %lsr.iv.next8 = add nsw i32 %lsr.iv7, -1
  %prol.iter.cmp.not = icmp eq i32 %lsr.iv.next8, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !12

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.preheader
  %.04.unr = phi i32 [ %3, %for_loop_body.preheader ], [ %41, %for_loop_body.prol.loopexit.loopexit ]
  %42 = icmp ult i32 %14, 7
  br i1 %42, label %after_for, label %for_loop_body.preheader6

for_loop_body.preheader6:                         ; preds = %for_loop_body.prol.loopexit
  %43 = sub i32 0, %5
  %44 = add nuw i32 %.04.unr, 7
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader6
  %lsr.iv = phi i32 [ %44, %for_loop_body.preheader6 ], [ %lsr.iv.next, %after_if.7 ]
  %45 = add i32 %lsr.iv, -7
  %46 = load ptr, ptr %7, align 8
  %47 = getelementptr inbounds %struct.LLVMRuntime, ptr %46, i64 0, i32 16
  %48 = load ptr, ptr %47, align 8
  %49 = load i32, ptr %48, align 4
  %.not = icmp eq i32 %49, 0
  br i1 %.not, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %for_loop_body.lr.ph, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %50 = sdiv i32 %45, 70
  %51 = srem i32 %45, 70
  %52 = load ptr, ptr %0, align 8
  %53 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %52, i64 0, i32 17, i32 1
  %54 = load ptr, ptr %53, align 8
  %55 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %52, i64 0, i32 17, i32 0, i32 1
  %56 = load i32, ptr %55, align 4
  %57 = sext i32 %50 to i64
  %58 = sext i32 %56 to i64
  %59 = mul nsw i64 %58, %57
  %60 = sext i32 %51 to i64
  %61 = add nsw i64 %59, %60
  %62 = getelementptr i64, ptr %54, i64 %61
  %63 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %52, i64 0, i32 16, i32 1
  %64 = load ptr, ptr %63, align 8
  %65 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %52, i64 0, i32 16, i32 0, i32 1
  %66 = load i32, ptr %65, align 4
  %67 = sext i32 %66 to i64
  %68 = mul nsw i64 %67, %57
  %69 = add nsw i64 %68, %60
  %70 = getelementptr i64, ptr %64, i64 %69
  %71 = load i64, ptr %70, align 8
  store i64 %71, ptr %62, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %72 = load ptr, ptr %7, align 8
  %73 = getelementptr inbounds %struct.LLVMRuntime, ptr %72, i64 0, i32 16
  %74 = load ptr, ptr %73, align 8
  %75 = load i32, ptr %74, align 4
  %.not.1 = icmp eq i32 %75, 0
  br i1 %.not.1, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %76 = add i32 %lsr.iv, -6
  %77 = sdiv i32 %76, 70
  %78 = srem i32 %76, 70
  %79 = load ptr, ptr %0, align 8
  %80 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %79, i64 0, i32 17, i32 1
  %81 = load ptr, ptr %80, align 8
  %82 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %79, i64 0, i32 17, i32 0, i32 1
  %83 = load i32, ptr %82, align 4
  %84 = sext i32 %77 to i64
  %85 = sext i32 %83 to i64
  %86 = mul nsw i64 %85, %84
  %87 = sext i32 %78 to i64
  %88 = add nsw i64 %86, %87
  %89 = getelementptr i64, ptr %81, i64 %88
  %90 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %79, i64 0, i32 16, i32 1
  %91 = load ptr, ptr %90, align 8
  %92 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %79, i64 0, i32 16, i32 0, i32 1
  %93 = load i32, ptr %92, align 4
  %94 = sext i32 %93 to i64
  %95 = mul nsw i64 %94, %84
  %96 = add nsw i64 %95, %87
  %97 = getelementptr i64, ptr %91, i64 %96
  %98 = load i64, ptr %97, align 8
  store i64 %98, ptr %89, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %99 = load ptr, ptr %7, align 8
  %100 = getelementptr inbounds %struct.LLVMRuntime, ptr %99, i64 0, i32 16
  %101 = load ptr, ptr %100, align 8
  %102 = load i32, ptr %101, align 4
  %.not.2 = icmp eq i32 %102, 0
  br i1 %.not.2, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %103 = add i32 %lsr.iv, -5
  %104 = sdiv i32 %103, 70
  %105 = srem i32 %103, 70
  %106 = load ptr, ptr %0, align 8
  %107 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %106, i64 0, i32 17, i32 1
  %108 = load ptr, ptr %107, align 8
  %109 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %106, i64 0, i32 17, i32 0, i32 1
  %110 = load i32, ptr %109, align 4
  %111 = sext i32 %104 to i64
  %112 = sext i32 %110 to i64
  %113 = mul nsw i64 %112, %111
  %114 = sext i32 %105 to i64
  %115 = add nsw i64 %113, %114
  %116 = getelementptr i64, ptr %108, i64 %115
  %117 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %106, i64 0, i32 16, i32 1
  %118 = load ptr, ptr %117, align 8
  %119 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %106, i64 0, i32 16, i32 0, i32 1
  %120 = load i32, ptr %119, align 4
  %121 = sext i32 %120 to i64
  %122 = mul nsw i64 %121, %111
  %123 = add nsw i64 %122, %114
  %124 = getelementptr i64, ptr %118, i64 %123
  %125 = load i64, ptr %124, align 8
  store i64 %125, ptr %116, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %126 = load ptr, ptr %7, align 8
  %127 = getelementptr inbounds %struct.LLVMRuntime, ptr %126, i64 0, i32 16
  %128 = load ptr, ptr %127, align 8
  %129 = load i32, ptr %128, align 4
  %.not.3 = icmp eq i32 %129, 0
  br i1 %.not.3, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %130 = add i32 %lsr.iv, -4
  %131 = sdiv i32 %130, 70
  %132 = srem i32 %130, 70
  %133 = load ptr, ptr %0, align 8
  %134 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %133, i64 0, i32 17, i32 1
  %135 = load ptr, ptr %134, align 8
  %136 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %133, i64 0, i32 17, i32 0, i32 1
  %137 = load i32, ptr %136, align 4
  %138 = sext i32 %131 to i64
  %139 = sext i32 %137 to i64
  %140 = mul nsw i64 %139, %138
  %141 = sext i32 %132 to i64
  %142 = add nsw i64 %140, %141
  %143 = getelementptr i64, ptr %135, i64 %142
  %144 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %133, i64 0, i32 16, i32 1
  %145 = load ptr, ptr %144, align 8
  %146 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %133, i64 0, i32 16, i32 0, i32 1
  %147 = load i32, ptr %146, align 4
  %148 = sext i32 %147 to i64
  %149 = mul nsw i64 %148, %138
  %150 = add nsw i64 %149, %141
  %151 = getelementptr i64, ptr %145, i64 %150
  %152 = load i64, ptr %151, align 8
  store i64 %152, ptr %143, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %153 = load ptr, ptr %7, align 8
  %154 = getelementptr inbounds %struct.LLVMRuntime, ptr %153, i64 0, i32 16
  %155 = load ptr, ptr %154, align 8
  %156 = load i32, ptr %155, align 4
  %.not.4 = icmp eq i32 %156, 0
  br i1 %.not.4, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %157 = add i32 %lsr.iv, -3
  %158 = sdiv i32 %157, 70
  %159 = srem i32 %157, 70
  %160 = load ptr, ptr %0, align 8
  %161 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %160, i64 0, i32 17, i32 1
  %162 = load ptr, ptr %161, align 8
  %163 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %160, i64 0, i32 17, i32 0, i32 1
  %164 = load i32, ptr %163, align 4
  %165 = sext i32 %158 to i64
  %166 = sext i32 %164 to i64
  %167 = mul nsw i64 %166, %165
  %168 = sext i32 %159 to i64
  %169 = add nsw i64 %167, %168
  %170 = getelementptr i64, ptr %162, i64 %169
  %171 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %160, i64 0, i32 16, i32 1
  %172 = load ptr, ptr %171, align 8
  %173 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %160, i64 0, i32 16, i32 0, i32 1
  %174 = load i32, ptr %173, align 4
  %175 = sext i32 %174 to i64
  %176 = mul nsw i64 %175, %165
  %177 = add nsw i64 %176, %168
  %178 = getelementptr i64, ptr %172, i64 %177
  %179 = load i64, ptr %178, align 8
  store i64 %179, ptr %170, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %180 = load ptr, ptr %7, align 8
  %181 = getelementptr inbounds %struct.LLVMRuntime, ptr %180, i64 0, i32 16
  %182 = load ptr, ptr %181, align 8
  %183 = load i32, ptr %182, align 4
  %.not.5 = icmp eq i32 %183, 0
  br i1 %.not.5, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %184 = add i32 %lsr.iv, -2
  %185 = sdiv i32 %184, 70
  %186 = srem i32 %184, 70
  %187 = load ptr, ptr %0, align 8
  %188 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %187, i64 0, i32 17, i32 1
  %189 = load ptr, ptr %188, align 8
  %190 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %187, i64 0, i32 17, i32 0, i32 1
  %191 = load i32, ptr %190, align 4
  %192 = sext i32 %185 to i64
  %193 = sext i32 %191 to i64
  %194 = mul nsw i64 %193, %192
  %195 = sext i32 %186 to i64
  %196 = add nsw i64 %194, %195
  %197 = getelementptr i64, ptr %189, i64 %196
  %198 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %187, i64 0, i32 16, i32 1
  %199 = load ptr, ptr %198, align 8
  %200 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %187, i64 0, i32 16, i32 0, i32 1
  %201 = load i32, ptr %200, align 4
  %202 = sext i32 %201 to i64
  %203 = mul nsw i64 %202, %192
  %204 = add nsw i64 %203, %195
  %205 = getelementptr i64, ptr %199, i64 %204
  %206 = load i64, ptr %205, align 8
  store i64 %206, ptr %197, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %207 = load ptr, ptr %7, align 8
  %208 = getelementptr inbounds %struct.LLVMRuntime, ptr %207, i64 0, i32 16
  %209 = load ptr, ptr %208, align 8
  %210 = load i32, ptr %209, align 4
  %.not.6 = icmp eq i32 %210, 0
  br i1 %.not.6, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %211 = add i32 %lsr.iv, -1
  %212 = sdiv i32 %211, 70
  %213 = srem i32 %211, 70
  %214 = load ptr, ptr %0, align 8
  %215 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %214, i64 0, i32 17, i32 1
  %216 = load ptr, ptr %215, align 8
  %217 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %214, i64 0, i32 17, i32 0, i32 1
  %218 = load i32, ptr %217, align 4
  %219 = sext i32 %212 to i64
  %220 = sext i32 %218 to i64
  %221 = mul nsw i64 %220, %219
  %222 = sext i32 %213 to i64
  %223 = add nsw i64 %221, %222
  %224 = getelementptr i64, ptr %216, i64 %223
  %225 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %214, i64 0, i32 16, i32 1
  %226 = load ptr, ptr %225, align 8
  %227 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %214, i64 0, i32 16, i32 0, i32 1
  %228 = load i32, ptr %227, align 4
  %229 = sext i32 %228 to i64
  %230 = mul nsw i64 %229, %219
  %231 = add nsw i64 %230, %222
  %232 = getelementptr i64, ptr %226, i64 %231
  %233 = load i64, ptr %232, align 8
  store i64 %233, ptr %224, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %234 = load ptr, ptr %7, align 8
  %235 = getelementptr inbounds %struct.LLVMRuntime, ptr %234, i64 0, i32 16
  %236 = load ptr, ptr %235, align 8
  %237 = load i32, ptr %236, align 4
  %.not.7 = icmp eq i32 %237, 0
  br i1 %.not.7, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %238 = sdiv i32 %lsr.iv, 70
  %239 = srem i32 %lsr.iv, 70
  %240 = load ptr, ptr %0, align 8
  %241 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %240, i64 0, i32 17, i32 1
  %242 = load ptr, ptr %241, align 8
  %243 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %240, i64 0, i32 17, i32 0, i32 1
  %244 = load i32, ptr %243, align 4
  %245 = sext i32 %238 to i64
  %246 = sext i32 %244 to i64
  %247 = mul nsw i64 %246, %245
  %248 = sext i32 %239 to i64
  %249 = add nsw i64 %247, %248
  %250 = getelementptr i64, ptr %242, i64 %249
  %251 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %240, i64 0, i32 16, i32 1
  %252 = load ptr, ptr %251, align 8
  %253 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %240, i64 0, i32 16, i32 0, i32 1
  %254 = load i32, ptr %253, align 4
  %255 = sext i32 %254 to i64
  %256 = mul nsw i64 %255, %245
  %257 = add nsw i64 %256, %248
  %258 = getelementptr i64, ptr %252, i64 %257
  %259 = load i64, ptr %258, align 8
  store i64 %259, ptr %250, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %lsr.iv.next = add i32 %lsr.iv, 8
  %260 = add i32 %43, %lsr.iv.next
  %exitcond.not.7 = icmp eq i32 %260, 7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @selection_numeric_stage_28_kernel_10_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.9, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.727, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.9(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 140)
  %6 = icmp sgt i32 %5, %3
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.727, ptr %0, i64 0, i32 1
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.LLVMRuntime, ptr %8, i64 0, i32 16
  %10 = load ptr, ptr %9, align 8
  %11 = load i32, ptr %10, align 4
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.lr.ph
  %13 = xor i32 %3, -1
  %14 = add i32 %5, %13
  %xtraiter = and i32 %5, 4
  %lcmp.mod.not = icmp eq i32 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.preheader
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv7 = phi i32 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next8, %after_if.prol ]
  %.04.prol = phi i32 [ %41, %after_if.prol ], [ %3, %for_loop_body.prol.preheader ]
  %15 = load ptr, ptr %7, align 8
  %16 = getelementptr inbounds %struct.LLVMRuntime, ptr %15, i64 0, i32 16
  %17 = load ptr, ptr %16, align 8
  %18 = load i32, ptr %17, align 4
  %.not.prol = icmp eq i32 %18, 0
  br i1 %.not.prol, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %19 = sdiv i32 %.04.prol, 70
  %20 = srem i32 %.04.prol, 70
  %21 = load ptr, ptr %0, align 8
  %22 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %21, i64 0, i32 19, i32 1
  %23 = load ptr, ptr %22, align 8
  %24 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %21, i64 0, i32 19, i32 0, i32 1
  %25 = load i32, ptr %24, align 4
  %26 = sext i32 %19 to i64
  %27 = sext i32 %25 to i64
  %28 = mul nsw i64 %27, %26
  %29 = sext i32 %20 to i64
  %30 = add nsw i64 %28, %29
  %31 = getelementptr i32, ptr %23, i64 %30
  %32 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %21, i64 0, i32 18, i32 1
  %33 = load ptr, ptr %32, align 8
  %34 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %21, i64 0, i32 18, i32 0, i32 1
  %35 = load i32, ptr %34, align 4
  %36 = sext i32 %35 to i64
  %37 = mul nsw i64 %36, %26
  %38 = add nsw i64 %37, %29
  %39 = getelementptr i32, ptr %33, i64 %38
  %40 = load i32, ptr %39, align 4
  store i32 %40, ptr %31, align 4
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %41 = add nuw nsw i32 %.04.prol, 1
  %lsr.iv.next8 = add nsw i32 %lsr.iv7, -1
  %prol.iter.cmp.not = icmp eq i32 %lsr.iv.next8, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !13

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.preheader
  %.04.unr = phi i32 [ %3, %for_loop_body.preheader ], [ %41, %for_loop_body.prol.loopexit.loopexit ]
  %42 = icmp ult i32 %14, 7
  br i1 %42, label %after_for, label %for_loop_body.preheader6

for_loop_body.preheader6:                         ; preds = %for_loop_body.prol.loopexit
  %43 = sub i32 0, %5
  %44 = add nuw i32 %.04.unr, 7
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader6
  %lsr.iv = phi i32 [ %44, %for_loop_body.preheader6 ], [ %lsr.iv.next, %after_if.7 ]
  %45 = add i32 %lsr.iv, -7
  %46 = load ptr, ptr %7, align 8
  %47 = getelementptr inbounds %struct.LLVMRuntime, ptr %46, i64 0, i32 16
  %48 = load ptr, ptr %47, align 8
  %49 = load i32, ptr %48, align 4
  %.not = icmp eq i32 %49, 0
  br i1 %.not, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %for_loop_body.lr.ph, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %50 = sdiv i32 %45, 70
  %51 = srem i32 %45, 70
  %52 = load ptr, ptr %0, align 8
  %53 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %52, i64 0, i32 19, i32 1
  %54 = load ptr, ptr %53, align 8
  %55 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %52, i64 0, i32 19, i32 0, i32 1
  %56 = load i32, ptr %55, align 4
  %57 = sext i32 %50 to i64
  %58 = sext i32 %56 to i64
  %59 = mul nsw i64 %58, %57
  %60 = sext i32 %51 to i64
  %61 = add nsw i64 %59, %60
  %62 = getelementptr i32, ptr %54, i64 %61
  %63 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %52, i64 0, i32 18, i32 1
  %64 = load ptr, ptr %63, align 8
  %65 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %52, i64 0, i32 18, i32 0, i32 1
  %66 = load i32, ptr %65, align 4
  %67 = sext i32 %66 to i64
  %68 = mul nsw i64 %67, %57
  %69 = add nsw i64 %68, %60
  %70 = getelementptr i32, ptr %64, i64 %69
  %71 = load i32, ptr %70, align 4
  store i32 %71, ptr %62, align 4
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %72 = load ptr, ptr %7, align 8
  %73 = getelementptr inbounds %struct.LLVMRuntime, ptr %72, i64 0, i32 16
  %74 = load ptr, ptr %73, align 8
  %75 = load i32, ptr %74, align 4
  %.not.1 = icmp eq i32 %75, 0
  br i1 %.not.1, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %76 = add i32 %lsr.iv, -6
  %77 = sdiv i32 %76, 70
  %78 = srem i32 %76, 70
  %79 = load ptr, ptr %0, align 8
  %80 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %79, i64 0, i32 19, i32 1
  %81 = load ptr, ptr %80, align 8
  %82 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %79, i64 0, i32 19, i32 0, i32 1
  %83 = load i32, ptr %82, align 4
  %84 = sext i32 %77 to i64
  %85 = sext i32 %83 to i64
  %86 = mul nsw i64 %85, %84
  %87 = sext i32 %78 to i64
  %88 = add nsw i64 %86, %87
  %89 = getelementptr i32, ptr %81, i64 %88
  %90 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %79, i64 0, i32 18, i32 1
  %91 = load ptr, ptr %90, align 8
  %92 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %79, i64 0, i32 18, i32 0, i32 1
  %93 = load i32, ptr %92, align 4
  %94 = sext i32 %93 to i64
  %95 = mul nsw i64 %94, %84
  %96 = add nsw i64 %95, %87
  %97 = getelementptr i32, ptr %91, i64 %96
  %98 = load i32, ptr %97, align 4
  store i32 %98, ptr %89, align 4
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %99 = load ptr, ptr %7, align 8
  %100 = getelementptr inbounds %struct.LLVMRuntime, ptr %99, i64 0, i32 16
  %101 = load ptr, ptr %100, align 8
  %102 = load i32, ptr %101, align 4
  %.not.2 = icmp eq i32 %102, 0
  br i1 %.not.2, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %103 = add i32 %lsr.iv, -5
  %104 = sdiv i32 %103, 70
  %105 = srem i32 %103, 70
  %106 = load ptr, ptr %0, align 8
  %107 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %106, i64 0, i32 19, i32 1
  %108 = load ptr, ptr %107, align 8
  %109 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %106, i64 0, i32 19, i32 0, i32 1
  %110 = load i32, ptr %109, align 4
  %111 = sext i32 %104 to i64
  %112 = sext i32 %110 to i64
  %113 = mul nsw i64 %112, %111
  %114 = sext i32 %105 to i64
  %115 = add nsw i64 %113, %114
  %116 = getelementptr i32, ptr %108, i64 %115
  %117 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %106, i64 0, i32 18, i32 1
  %118 = load ptr, ptr %117, align 8
  %119 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %106, i64 0, i32 18, i32 0, i32 1
  %120 = load i32, ptr %119, align 4
  %121 = sext i32 %120 to i64
  %122 = mul nsw i64 %121, %111
  %123 = add nsw i64 %122, %114
  %124 = getelementptr i32, ptr %118, i64 %123
  %125 = load i32, ptr %124, align 4
  store i32 %125, ptr %116, align 4
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %126 = load ptr, ptr %7, align 8
  %127 = getelementptr inbounds %struct.LLVMRuntime, ptr %126, i64 0, i32 16
  %128 = load ptr, ptr %127, align 8
  %129 = load i32, ptr %128, align 4
  %.not.3 = icmp eq i32 %129, 0
  br i1 %.not.3, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %130 = add i32 %lsr.iv, -4
  %131 = sdiv i32 %130, 70
  %132 = srem i32 %130, 70
  %133 = load ptr, ptr %0, align 8
  %134 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %133, i64 0, i32 19, i32 1
  %135 = load ptr, ptr %134, align 8
  %136 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %133, i64 0, i32 19, i32 0, i32 1
  %137 = load i32, ptr %136, align 4
  %138 = sext i32 %131 to i64
  %139 = sext i32 %137 to i64
  %140 = mul nsw i64 %139, %138
  %141 = sext i32 %132 to i64
  %142 = add nsw i64 %140, %141
  %143 = getelementptr i32, ptr %135, i64 %142
  %144 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %133, i64 0, i32 18, i32 1
  %145 = load ptr, ptr %144, align 8
  %146 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %133, i64 0, i32 18, i32 0, i32 1
  %147 = load i32, ptr %146, align 4
  %148 = sext i32 %147 to i64
  %149 = mul nsw i64 %148, %138
  %150 = add nsw i64 %149, %141
  %151 = getelementptr i32, ptr %145, i64 %150
  %152 = load i32, ptr %151, align 4
  store i32 %152, ptr %143, align 4
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %153 = load ptr, ptr %7, align 8
  %154 = getelementptr inbounds %struct.LLVMRuntime, ptr %153, i64 0, i32 16
  %155 = load ptr, ptr %154, align 8
  %156 = load i32, ptr %155, align 4
  %.not.4 = icmp eq i32 %156, 0
  br i1 %.not.4, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %157 = add i32 %lsr.iv, -3
  %158 = sdiv i32 %157, 70
  %159 = srem i32 %157, 70
  %160 = load ptr, ptr %0, align 8
  %161 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %160, i64 0, i32 19, i32 1
  %162 = load ptr, ptr %161, align 8
  %163 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %160, i64 0, i32 19, i32 0, i32 1
  %164 = load i32, ptr %163, align 4
  %165 = sext i32 %158 to i64
  %166 = sext i32 %164 to i64
  %167 = mul nsw i64 %166, %165
  %168 = sext i32 %159 to i64
  %169 = add nsw i64 %167, %168
  %170 = getelementptr i32, ptr %162, i64 %169
  %171 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %160, i64 0, i32 18, i32 1
  %172 = load ptr, ptr %171, align 8
  %173 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %160, i64 0, i32 18, i32 0, i32 1
  %174 = load i32, ptr %173, align 4
  %175 = sext i32 %174 to i64
  %176 = mul nsw i64 %175, %165
  %177 = add nsw i64 %176, %168
  %178 = getelementptr i32, ptr %172, i64 %177
  %179 = load i32, ptr %178, align 4
  store i32 %179, ptr %170, align 4
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %180 = load ptr, ptr %7, align 8
  %181 = getelementptr inbounds %struct.LLVMRuntime, ptr %180, i64 0, i32 16
  %182 = load ptr, ptr %181, align 8
  %183 = load i32, ptr %182, align 4
  %.not.5 = icmp eq i32 %183, 0
  br i1 %.not.5, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %184 = add i32 %lsr.iv, -2
  %185 = sdiv i32 %184, 70
  %186 = srem i32 %184, 70
  %187 = load ptr, ptr %0, align 8
  %188 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %187, i64 0, i32 19, i32 1
  %189 = load ptr, ptr %188, align 8
  %190 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %187, i64 0, i32 19, i32 0, i32 1
  %191 = load i32, ptr %190, align 4
  %192 = sext i32 %185 to i64
  %193 = sext i32 %191 to i64
  %194 = mul nsw i64 %193, %192
  %195 = sext i32 %186 to i64
  %196 = add nsw i64 %194, %195
  %197 = getelementptr i32, ptr %189, i64 %196
  %198 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %187, i64 0, i32 18, i32 1
  %199 = load ptr, ptr %198, align 8
  %200 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %187, i64 0, i32 18, i32 0, i32 1
  %201 = load i32, ptr %200, align 4
  %202 = sext i32 %201 to i64
  %203 = mul nsw i64 %202, %192
  %204 = add nsw i64 %203, %195
  %205 = getelementptr i32, ptr %199, i64 %204
  %206 = load i32, ptr %205, align 4
  store i32 %206, ptr %197, align 4
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %207 = load ptr, ptr %7, align 8
  %208 = getelementptr inbounds %struct.LLVMRuntime, ptr %207, i64 0, i32 16
  %209 = load ptr, ptr %208, align 8
  %210 = load i32, ptr %209, align 4
  %.not.6 = icmp eq i32 %210, 0
  br i1 %.not.6, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %211 = add i32 %lsr.iv, -1
  %212 = sdiv i32 %211, 70
  %213 = srem i32 %211, 70
  %214 = load ptr, ptr %0, align 8
  %215 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %214, i64 0, i32 19, i32 1
  %216 = load ptr, ptr %215, align 8
  %217 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %214, i64 0, i32 19, i32 0, i32 1
  %218 = load i32, ptr %217, align 4
  %219 = sext i32 %212 to i64
  %220 = sext i32 %218 to i64
  %221 = mul nsw i64 %220, %219
  %222 = sext i32 %213 to i64
  %223 = add nsw i64 %221, %222
  %224 = getelementptr i32, ptr %216, i64 %223
  %225 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %214, i64 0, i32 18, i32 1
  %226 = load ptr, ptr %225, align 8
  %227 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %214, i64 0, i32 18, i32 0, i32 1
  %228 = load i32, ptr %227, align 4
  %229 = sext i32 %228 to i64
  %230 = mul nsw i64 %229, %219
  %231 = add nsw i64 %230, %222
  %232 = getelementptr i32, ptr %226, i64 %231
  %233 = load i32, ptr %232, align 4
  store i32 %233, ptr %224, align 4
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %234 = load ptr, ptr %7, align 8
  %235 = getelementptr inbounds %struct.LLVMRuntime, ptr %234, i64 0, i32 16
  %236 = load ptr, ptr %235, align 8
  %237 = load i32, ptr %236, align 4
  %.not.7 = icmp eq i32 %237, 0
  br i1 %.not.7, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %238 = sdiv i32 %lsr.iv, 70
  %239 = srem i32 %lsr.iv, 70
  %240 = load ptr, ptr %0, align 8
  %241 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %240, i64 0, i32 19, i32 1
  %242 = load ptr, ptr %241, align 8
  %243 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %240, i64 0, i32 19, i32 0, i32 1
  %244 = load i32, ptr %243, align 4
  %245 = sext i32 %238 to i64
  %246 = sext i32 %244 to i64
  %247 = mul nsw i64 %246, %245
  %248 = sext i32 %239 to i64
  %249 = add nsw i64 %247, %248
  %250 = getelementptr i32, ptr %242, i64 %249
  %251 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %240, i64 0, i32 18, i32 1
  %252 = load ptr, ptr %251, align 8
  %253 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %240, i64 0, i32 18, i32 0, i32 1
  %254 = load i32, ptr %253, align 4
  %255 = sext i32 %254 to i64
  %256 = mul nsw i64 %255, %245
  %257 = add nsw i64 %256, %248
  %258 = getelementptr i32, ptr %252, i64 %257
  %259 = load i32, ptr %258, align 4
  store i32 %259, ptr %250, align 4
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %lsr.iv.next = add i32 %lsr.iv, 8
  %260 = add i32 %43, %lsr.iv.next
  %exitcond.not.7 = icmp eq i32 %260, 7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_parallel_range_for_task(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #3 {
  %4 = alloca %struct.RuntimeContext.727, align 8
  %.sroa.0.0.copyload = load ptr, ptr %0, align 8
  %.sroa.4.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 8
  %.sroa.4.0.copyload = load ptr, ptr %.sroa.4.0..sroa_idx, align 8
  %.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 16
  %.sroa.5.0.copyload = load ptr, ptr %.sroa.5.0..sroa_idx, align 8
  %.sroa.7.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 24
  %.sroa.7.0.copyload = load ptr, ptr %.sroa.7.0..sroa_idx, align 8
  %.sroa.8.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 32
  %.sroa.8.0.copyload = load i64, ptr %.sroa.8.0..sroa_idx, align 8
  %.sroa.9.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 40
  %.sroa.9.0.copyload = load i32, ptr %.sroa.9.0..sroa_idx, align 8
  %.sroa.12.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 44
  %.sroa.12.0.copyload = load i32, ptr %.sroa.12.0..sroa_idx, align 4
  %.sroa.15.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 48
  %.sroa.15.0.copyload = load i32, ptr %.sroa.15.0..sroa_idx, align 8
  %.sroa.17.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 52
  %.sroa.17.0.copyload = load i32, ptr %.sroa.17.0..sroa_idx, align 4
  %5 = alloca i8, i64 %.sroa.8.0.copyload, align 8
  %.not = icmp eq ptr %.sroa.4.0.copyload, null
  br i1 %.not, label %7, label %6

6:                                                ; preds = %3
  call void %.sroa.4.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %7

7:                                                ; preds = %6, %3
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %4, ptr noundef nonnull align 8 dereferenceable(32) %.sroa.0.0.copyload, i64 32, i1 false)
  %8 = getelementptr inbounds %struct.RuntimeContext.727, ptr %4, i64 0, i32 2
  store i32 %1, ptr %8, align 8
  switch i32 %.sroa.17.0.copyload, label %.loopexit [
    i32 1, label %9
    i32 -1, label %17
  ]

9:                                                ; preds = %7
  %10 = mul nsw i32 %.sroa.15.0.copyload, %2
  %11 = add nsw i32 %10, %.sroa.9.0.copyload
  %12 = add nsw i32 %11, %.sroa.15.0.copyload
  %13 = call i32 @llvm.smin.i32(i32 %.sroa.12.0.copyload, i32 %12)
  %14 = icmp slt i32 %11, %13
  br i1 %14, label %.lr.ph.preheader, label %.loopexit

.lr.ph.preheader:                                 ; preds = %9
  br label %.lr.ph

.lr.ph:                                           ; preds = %.lr.ph, %.lr.ph.preheader
  %.02039 = phi i32 [ %15, %.lr.ph ], [ %11, %.lr.ph.preheader ]
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.02039) #1
  %15 = add nsw i32 %.02039, 1
  %16 = icmp slt i32 %15, %13
  br i1 %16, label %.lr.ph, label %.loopexit.loopexit, !llvm.loop !14

17:                                               ; preds = %7
  %18 = mul nsw i32 %.sroa.15.0.copyload, %2
  %19 = sub nsw i32 %.sroa.12.0.copyload, %18
  %20 = mul nsw i32 %19, %.sroa.15.0.copyload
  %21 = call i32 @llvm.smax.i32(i32 %.sroa.9.0.copyload, i32 %20)
  %.not25.not40 = icmp sgt i32 %19, %21
  br i1 %.not25.not40, label %.lr.ph42.preheader, label %.loopexit

.lr.ph42.preheader:                               ; preds = %17
  br label %.lr.ph42

.lr.ph42:                                         ; preds = %.lr.ph42, %.lr.ph42.preheader
  %.0.in41 = phi i32 [ %.0, %.lr.ph42 ], [ %19, %.lr.ph42.preheader ]
  %.0 = add nsw i32 %.0.in41, -1
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.0) #1
  %.not25.not = icmp sgt i32 %.0, %21
  br i1 %.not25.not, label %.lr.ph42, label %.loopexit.loopexit47, !llvm.loop !16

.loopexit.loopexit:                               ; preds = %.lr.ph
  br label %.loopexit

.loopexit.loopexit47:                             ; preds = %.lr.ph42
  br label %.loopexit

.loopexit:                                        ; preds = %.loopexit.loopexit47, %.loopexit.loopexit, %17, %9, %7
  %.not24 = icmp eq ptr %.sroa.7.0.copyload, null
  br i1 %.not24, label %23, label %22

22:                                               ; preds = %.loopexit
  call void %.sroa.7.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %23

23:                                               ; preds = %22, %.loopexit
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #5

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #6

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #6

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smax.i32(i32, i32) #7

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { nofree nosync nounwind }
attributes #3 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #5 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #6 = { argmemonly nocallback nofree nosync nounwind willreturn }
attributes #7 = { nocallback nofree nosync nounwind readnone speculatable willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.unroll.disable"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
!13 = distinct !{!13, !7}
!14 = distinct !{!14, !15}
!15 = !{!"llvm.loop.mustprogress"}
!16 = distinct !{!16, !15}
