; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%0 = type { ptr, [2 x i32], %struct.PhysicalCoordinates.937 }
%1 = type { %2, %2 }
%2 = type { [1 x i64], [1 x ptr] }
%struct.RuntimeContext.924 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }
%struct.ListManager = type { [256 x ptr], i64, i64, i32, i32, i32, ptr }
%struct.PhysicalCoordinates.937 = type { [12 x i32] }
%struct.cpu_block_task_helper_context = type { ptr, ptr, ptr, i32, i32, i64 }
%class.anon = type { ptr, ptr, ptr, ptr }

@.str = private unnamed_addr constant [28 x i8] c"Out of pre-allocated memory\00", align 1
@.str.2 = private unnamed_addr constant [28 x i8] c"List manager out of chunks.\00", align 1

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @selection_abandon_42_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = load i32, ptr %0, align 4
  %2 = getelementptr inbounds %struct.RuntimeContext.924, ptr %context, i64 0, i32 1
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds %struct.LLVMRuntime, ptr %3, i64 0, i32 16
  %5 = load ptr, ptr %4, align 8
  store i32 %1, ptr %5, align 4
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @selection_abandon_42_kernel_1_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.924, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 41
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @selection_abandon_42_kernel_2_listgen_S41pointer(ptr %context) local_unnamed_addr #1 {
  %.sroa.2.i = alloca { [2 x i32], %struct.PhysicalCoordinates.937 }, align 8
  %1 = alloca %0, align 8
  %2 = getelementptr inbounds %struct.RuntimeContext.924, ptr %context, i64 0, i32 1
  %3 = load ptr, ptr %2, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %1)
  %4 = getelementptr inbounds %struct.LLVMRuntime, ptr %3, i64 0, i32 13
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds ptr, ptr %5, i64 40
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds ptr, ptr %5, i64 41
  %9 = load ptr, ptr %8, align 8
  %10 = load atomic i64, ptr %7 acquire, align 8
  %.not.i.i.i.i = icmp ne i64 %10, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i)
  %11 = inttoptr i64 %10 to ptr
  %12 = load atomic i64, ptr %11 acquire, align 8
  %13 = inttoptr i64 %12 to ptr
  %.sroa.0.0.copyload.i = load ptr, ptr %13, align 8
  %.sroa.2.0..sroa_idx.i = getelementptr inbounds i8, ptr %13, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.i, ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.0..sroa_idx.i, i64 56, i1 false)
  %14 = getelementptr inbounds %0, ptr %1, i64 0, i32 2
  %.sroa.2.16.sroa_idx.i = getelementptr inbounds i8, ptr %.sroa.2.i, i64 8
  %15 = getelementptr inbounds %struct.ListManager, ptr %9, i64 0, i32 5
  %16 = getelementptr inbounds %struct.ListManager, ptr %9, i64 0, i32 3
  %17 = getelementptr inbounds %struct.ListManager, ptr %9, i64 0, i32 4
  %18 = getelementptr inbounds %struct.ListManager, ptr %9, i64 0, i32 6
  %19 = getelementptr inbounds %struct.ListManager, ptr %9, i64 0, i32 2
  %20 = getelementptr inbounds %struct.ListManager, ptr %9, i64 0, i32 1
  store ptr %.sroa.0.0.copyload.i, ptr %1, align 8
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %1, i64 8
  store <2 x i32> <i32 0, i32 1>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %14, ptr noundef nonnull align 8 dereferenceable(48) %.sroa.2.16.sroa_idx.i, i64 48, i1 false)
  %21 = atomicrmw volatile add ptr %15, i32 1 seq_cst, align 4
  %22 = load i32, ptr %16, align 8
  %23 = ashr i32 %21, %22
  %24 = icmp ugt i32 %23, 131071
  br i1 %24, label %25, label %27

25:                                               ; preds = %0
  %26 = load ptr, ptr %18, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %26, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

27:                                               ; preds = %0
  %28 = zext i32 %23 to i64
  %29 = lshr i64 %28, 9
  %30 = getelementptr inbounds [256 x ptr], ptr %9, i64 0, i64 %29
  %31 = load atomic i64, ptr %30 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %31, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %27
  %32 = inttoptr i64 %31 to ptr
  %33 = and i64 %28, 511
  %34 = getelementptr inbounds ptr, ptr %32, i64 %33
  %35 = load atomic i64, ptr %34 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %35, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %27
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %36 = atomicrmw volatile xchg ptr %17, i32 1 seq_cst, align 4
  %37 = icmp eq i32 %36, 1
  br i1 %37, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %38 = load atomic i64, ptr %30 acquire, align 8
  %39 = inttoptr i64 %38 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %38, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %40, label %74

40:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %41 = load ptr, ptr %18, align 8
  %42 = getelementptr inbounds %struct.LLVMRuntime, ptr %41, i64 0, i32 1
  %43 = getelementptr inbounds %struct.LLVMRuntime, ptr %41, i64 0, i32 28
  %44 = atomicrmw volatile add ptr %43, i64 4096 seq_cst, align 8
  %45 = getelementptr inbounds %struct.LLVMRuntime, ptr %41, i64 0, i32 1, i32 2
  %46 = load i64, ptr %45, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %46, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %67, label %47

47:                                               ; preds = %40
  %48 = getelementptr inbounds %struct.LLVMRuntime, ptr %41, i64 0, i32 26
  br label %49

49:                                               ; preds = %49, %47
  %50 = atomicrmw volatile xchg ptr %48, i32 1 seq_cst, align 4
  %51 = icmp eq i32 %50, 1
  br i1 %51, label %49, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %49
  %52 = load ptr, ptr %42, align 8
  %53 = ptrtoint ptr %52 to i64
  %54 = getelementptr inbounds %struct.LLVMRuntime, ptr %41, i64 0, i32 1, i32 1
  %55 = load ptr, ptr %54, align 8
  %56 = ptrtoint ptr %55 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %53
  %57 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %58 = or i64 %57, 4096
  %59 = add i64 %58, %53
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %59, %56
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %60

60:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %61 = add i64 %57, %53
  %62 = inttoptr i64 %61 to ptr
  %63 = getelementptr i8, ptr %52, i64 %57
  %64 = getelementptr inbounds i8, ptr %63, i64 4096
  store ptr %64, ptr %42, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %60, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %62, %60 ]
  %65 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %66 = atomicrmw volatile xchg ptr %48, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %41, i1 noundef zeroext %65, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

67:                                               ; preds = %40
  %68 = getelementptr inbounds %struct.LLVMRuntime, ptr %41, i64 0, i32 2
  %69 = load ptr, ptr %68, align 8
  %70 = getelementptr inbounds %struct.LLVMRuntime, ptr %41, i64 0, i32 6
  %71 = load ptr, ptr %70, align 8
  %72 = tail call noundef ptr %69(ptr noundef %71, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %67, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %72, %67 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %73 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %73, ptr %30 release, align 8
  br label %74

74:                                               ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %39, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %75 = and i32 %23, 511
  %76 = zext i32 %75 to i64
  %77 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %76
  %78 = load atomic i64, ptr %77 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %78, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %79, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

79:                                               ; preds = %74
  %80 = load ptr, ptr %18, align 8
  %81 = getelementptr inbounds %struct.LLVMRuntime, ptr %80, i64 0, i32 1
  %82 = load i64, ptr %19, align 8
  %83 = load i64, ptr %20, align 8
  %84 = mul i64 %83, %82
  %85 = getelementptr inbounds %struct.LLVMRuntime, ptr %80, i64 0, i32 28
  %86 = atomicrmw volatile add ptr %85, i64 %84 seq_cst, align 8
  %87 = getelementptr inbounds %struct.LLVMRuntime, ptr %80, i64 0, i32 1, i32 2
  %88 = load i64, ptr %87, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %88, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %108, label %89

89:                                               ; preds = %79
  %90 = getelementptr inbounds %struct.LLVMRuntime, ptr %80, i64 0, i32 26
  br label %91

91:                                               ; preds = %91, %89
  %92 = atomicrmw volatile xchg ptr %90, i32 1 seq_cst, align 4
  %93 = icmp eq i32 %92, 1
  br i1 %93, label %91, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %91
  %94 = load ptr, ptr %81, align 8
  %95 = ptrtoint ptr %94 to i64
  %96 = getelementptr inbounds %struct.LLVMRuntime, ptr %80, i64 0, i32 1, i32 1
  %97 = load ptr, ptr %96, align 8
  %98 = ptrtoint ptr %97 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %95
  %99 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %100 = add i64 %99, %84
  %101 = add i64 %100, %95
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %101, %98
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %102

102:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %103 = add i64 %99, %95
  %104 = inttoptr i64 %103 to ptr
  %105 = getelementptr inbounds i8, ptr %94, i64 %100
  store ptr %105, ptr %81, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %102, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %104, %102 ]
  %106 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %107 = atomicrmw volatile xchg ptr %90, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %80, i1 noundef zeroext %106, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

108:                                              ; preds = %79
  %109 = getelementptr inbounds %struct.LLVMRuntime, ptr %80, i64 0, i32 2
  %110 = load ptr, ptr %109, align 8
  %111 = getelementptr inbounds %struct.LLVMRuntime, ptr %80, i64 0, i32 6
  %112 = load ptr, ptr %111, align 8
  %113 = tail call noundef ptr %110(ptr noundef %112, i64 noundef %84, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %108, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %113, %108 ]
  %114 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %114, ptr %77 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %74
  %115 = atomicrmw volatile xchg ptr %17, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %25
  %116 = load i32, ptr %16, align 8
  %117 = ashr i32 %21, %116
  %118 = sext i32 %117 to i64
  %119 = lshr i64 %118, 9
  %120 = getelementptr inbounds [256 x ptr], ptr %9, i64 0, i64 %119
  %121 = load atomic i64, ptr %120 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %121, 0
  br i1 %.not.i.i1.i.i.i, label %element_listgen_root.exit, label %122

122:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %123 = inttoptr i64 %121 to ptr
  %124 = and i64 %118, 511
  %125 = getelementptr inbounds ptr, ptr %123, i64 %124
  %126 = load atomic i64, ptr %125 acquire, align 8
  %127 = inttoptr i64 %126 to ptr
  br label %element_listgen_root.exit

element_listgen_root.exit:                        ; preds = %122, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %128 = phi ptr [ %127, %122 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %129 = load i64, ptr %20, align 8
  %130 = load i32, ptr %16, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %130
  %131 = xor i32 %notmask.i.i.i.i, -1
  %132 = and i32 %21, %131
  %133 = sext i32 %132 to i64
  %134 = mul i64 %129, %133
  %135 = getelementptr inbounds i8, ptr %128, i64 %134
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %135, ptr nonnull align 8 %1, i64 %129, i1 false)
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %1)
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @selection_abandon_42_kernel_3_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.924, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 42
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @selection_abandon_42_kernel_4_listgen_S42bitmasked(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %0, align 8
  %1 = alloca %struct.PhysicalCoordinates.937, align 4
  %2 = alloca %0, align 8
  %3 = getelementptr inbounds %struct.RuntimeContext.924, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %2)
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 13
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %6, i64 41
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %10 = load i32, ptr %9, align 8
  %11 = getelementptr inbounds ptr, ptr %6, i64 42
  %12 = load ptr, ptr %11, align 8
  %13 = icmp sgt i32 %10, 0
  br i1 %13, label %.lr.ph61.i, label %element_listgen_nonroot.exit

.lr.ph61.i:                                       ; preds = %entry
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  %16 = getelementptr inbounds %0, ptr %0, i64 0, i32 1
  %17 = getelementptr inbounds %0, ptr %0, i64 0, i32 1, i64 1
  %18 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %19 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %20 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 5
  %21 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %22 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 4
  %23 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 6
  %24 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 2
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %.8.sroa_idx11 = getelementptr inbounds i8, ptr %2, i64 8
  br label %26

26:                                               ; preds = %._crit_edge.i, %.lr.ph61.i
  %.04359.i = phi i32 [ 0, %.lr.ph61.i ], [ %173, %._crit_edge.i ]
  %27 = load i32, ptr %14, align 8
  %28 = lshr i32 %.04359.i, %27
  %29 = sext i32 %28 to i64
  %30 = lshr i64 %29, 9
  %31 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %30
  %32 = load atomic i64, ptr %31 acquire, align 8
  %.not.i.i.i.i = icmp eq i64 %32, 0
  br i1 %.not.i.i.i.i, label %_ZN11ListManager3getI7ElementEERT_i.exit.i, label %33

33:                                               ; preds = %26
  %34 = inttoptr i64 %32 to ptr
  %35 = and i64 %29, 511
  %36 = getelementptr inbounds ptr, ptr %34, i64 %35
  %37 = load atomic i64, ptr %36 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit.i

_ZN11ListManager3getI7ElementEERT_i.exit.i:       ; preds = %33, %26
  %39 = phi ptr [ %38, %33 ], [ null, %26 ]
  %40 = load i64, ptr %15, align 8
  %41 = load i32, ptr %14, align 8
  %notmask.i.i.i = shl nsw i32 -1, %41
  %42 = xor i32 %notmask.i.i.i, -1
  %43 = and i32 %.04359.i, %42
  %44 = zext i32 %43 to i64
  %45 = mul i64 %40, %44
  %46 = getelementptr inbounds i8, ptr %39, i64 %45
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %0, ptr noundef nonnull align 8 dereferenceable(64) %46, i64 64, i1 false)
  %47 = load i32, ptr %16, align 8
  %48 = load i32, ptr %17, align 4
  %49 = icmp slt i32 %47, %48
  br i1 %49, label %.lr.ph58.i.preheader, label %._crit_edge.i

.lr.ph58.i.preheader:                             ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit.i
  %50 = zext i32 %47 to i64
  br label %.lr.ph58.i

.lr.ph58.i:                                       ; preds = %.loopexit.i, %.lr.ph58.i.preheader
  %indvars.iv = phi i64 [ %50, %.lr.ph58.i.preheader ], [ %indvars.iv.next, %.loopexit.i ]
  %51 = trunc i64 %indvars.iv to i32
  call fastcc void @S41_refine_coordinates(ptr noundef nonnull %18, ptr noundef nonnull %1, i32 noundef %51) #1
  %52 = load ptr, ptr %0, align 8
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %53 = trunc i64 %indvars.iv.next to i32
  %54 = shl nsw i32 %53, 3
  %55 = sext i32 %54 to i64
  %56 = getelementptr inbounds i8, ptr %52, i64 %55
  %57 = load ptr, ptr %56, align 8
  %.not = icmp eq ptr %57, null
  br i1 %.not, label %.loopexit.i, label %.lr.ph.i

.lr.ph.i:                                         ; preds = %.lr.ph58.i
  store ptr %57, ptr %2, align 8
  store <2 x i32> <i32 0, i32 32>, ptr %.8.sroa_idx11, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %19, ptr noundef nonnull align 4 dereferenceable(48) %1, i64 48, i1 false)
  %58 = atomicrmw volatile add ptr %20, i32 1 seq_cst, align 4
  %59 = load i32, ptr %21, align 8
  %60 = ashr i32 %58, %59
  %61 = icmp ugt i32 %60, 131071
  br i1 %61, label %62, label %64

62:                                               ; preds = %.lr.ph.i
  %63 = load ptr, ptr %23, align 8
  call fastcc void @taichi_assert_format(ptr noundef %63, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

64:                                               ; preds = %.lr.ph.i
  %65 = zext i32 %60 to i64
  %66 = lshr i64 %65, 9
  %67 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %66
  %68 = load atomic i64, ptr %67 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %68, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %64
  %69 = inttoptr i64 %68 to ptr
  %70 = and i64 %65, 511
  %71 = getelementptr inbounds ptr, ptr %69, i64 %70
  %72 = load atomic i64, ptr %71 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %72, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %64
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %73 = atomicrmw volatile xchg ptr %22, i32 1 seq_cst, align 4
  %74 = icmp eq i32 %73, 1
  br i1 %74, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %75 = load atomic i64, ptr %67 acquire, align 8
  %76 = inttoptr i64 %75 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %75, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %77, label %111

77:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %78 = load ptr, ptr %23, align 8
  %79 = getelementptr inbounds %struct.LLVMRuntime, ptr %78, i64 0, i32 1
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %78, i64 0, i32 28
  %81 = atomicrmw volatile add ptr %80, i64 4096 seq_cst, align 8
  %82 = getelementptr inbounds %struct.LLVMRuntime, ptr %78, i64 0, i32 1, i32 2
  %83 = load i64, ptr %82, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %83, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %104, label %84

84:                                               ; preds = %77
  %85 = getelementptr inbounds %struct.LLVMRuntime, ptr %78, i64 0, i32 26
  br label %86

86:                                               ; preds = %86, %84
  %87 = atomicrmw volatile xchg ptr %85, i32 1 seq_cst, align 4
  %88 = icmp eq i32 %87, 1
  br i1 %88, label %86, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %86
  %89 = load ptr, ptr %79, align 8
  %90 = ptrtoint ptr %89 to i64
  %91 = getelementptr inbounds %struct.LLVMRuntime, ptr %78, i64 0, i32 1, i32 1
  %92 = load ptr, ptr %91, align 8
  %93 = ptrtoint ptr %92 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %90
  %94 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %95 = or i64 %94, 4096
  %96 = add i64 %95, %90
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %96, %93
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %97

97:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %98 = add i64 %94, %90
  %99 = inttoptr i64 %98 to ptr
  %100 = getelementptr i8, ptr %89, i64 %94
  %101 = getelementptr inbounds i8, ptr %100, i64 4096
  store ptr %101, ptr %79, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %97, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %99, %97 ]
  %102 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %103 = atomicrmw volatile xchg ptr %85, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %78, i1 noundef zeroext %102, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

104:                                              ; preds = %77
  %105 = getelementptr inbounds %struct.LLVMRuntime, ptr %78, i64 0, i32 2
  %106 = load ptr, ptr %105, align 8
  %107 = getelementptr inbounds %struct.LLVMRuntime, ptr %78, i64 0, i32 6
  %108 = load ptr, ptr %107, align 8
  %109 = call noundef ptr %106(ptr noundef %108, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %104, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %109, %104 ]
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %110 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %110, ptr %67 release, align 8
  br label %111

111:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %76, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %112 = and i32 %60, 511
  %113 = zext i32 %112 to i64
  %114 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %113
  %115 = load atomic i64, ptr %114 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %115, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %116, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

116:                                              ; preds = %111
  %117 = load ptr, ptr %23, align 8
  %118 = getelementptr inbounds %struct.LLVMRuntime, ptr %117, i64 0, i32 1
  %119 = load i64, ptr %24, align 8
  %120 = load i64, ptr %25, align 8
  %121 = mul i64 %120, %119
  %122 = getelementptr inbounds %struct.LLVMRuntime, ptr %117, i64 0, i32 28
  %123 = atomicrmw volatile add ptr %122, i64 %121 seq_cst, align 8
  %124 = getelementptr inbounds %struct.LLVMRuntime, ptr %117, i64 0, i32 1, i32 2
  %125 = load i64, ptr %124, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %125, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %145, label %126

126:                                              ; preds = %116
  %127 = getelementptr inbounds %struct.LLVMRuntime, ptr %117, i64 0, i32 26
  br label %128

128:                                              ; preds = %128, %126
  %129 = atomicrmw volatile xchg ptr %127, i32 1 seq_cst, align 4
  %130 = icmp eq i32 %129, 1
  br i1 %130, label %128, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %128
  %131 = load ptr, ptr %118, align 8
  %132 = ptrtoint ptr %131 to i64
  %133 = getelementptr inbounds %struct.LLVMRuntime, ptr %117, i64 0, i32 1, i32 1
  %134 = load ptr, ptr %133, align 8
  %135 = ptrtoint ptr %134 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %132
  %136 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %137 = add i64 %136, %121
  %138 = add i64 %137, %132
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %138, %135
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %139

139:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %140 = add i64 %136, %132
  %141 = inttoptr i64 %140 to ptr
  %142 = getelementptr inbounds i8, ptr %131, i64 %137
  store ptr %142, ptr %118, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %139, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %141, %139 ]
  %143 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %144 = atomicrmw volatile xchg ptr %127, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %117, i1 noundef zeroext %143, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

145:                                              ; preds = %116
  %146 = getelementptr inbounds %struct.LLVMRuntime, ptr %117, i64 0, i32 2
  %147 = load ptr, ptr %146, align 8
  %148 = getelementptr inbounds %struct.LLVMRuntime, ptr %117, i64 0, i32 6
  %149 = load ptr, ptr %148, align 8
  %150 = call noundef ptr %147(ptr noundef %149, i64 noundef %121, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %145, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %150, %145 ]
  %151 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %151, ptr %114 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %111
  %152 = atomicrmw volatile xchg ptr %22, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %62
  %153 = load i32, ptr %21, align 8
  %154 = ashr i32 %58, %153
  %155 = sext i32 %154 to i64
  %156 = lshr i64 %155, 9
  %157 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %156
  %158 = load atomic i64, ptr %157 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %158, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %159

159:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %160 = inttoptr i64 %158 to ptr
  %161 = and i64 %155, 511
  %162 = getelementptr inbounds ptr, ptr %160, i64 %161
  %163 = load atomic i64, ptr %162 acquire, align 8
  %164 = inttoptr i64 %163 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %159, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %165 = phi ptr [ %164, %159 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %166 = load i64, ptr %25, align 8
  %167 = load i32, ptr %21, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %167
  %168 = xor i32 %notmask.i.i.i.i, -1
  %169 = and i32 %58, %168
  %170 = sext i32 %169 to i64
  %171 = mul i64 %166, %170
  %172 = getelementptr inbounds i8, ptr %165, i64 %171
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %172, ptr nonnull align 8 %2, i64 %166, i1 false)
  br label %.loopexit.i, !llvm.loop !8

.loopexit.i:                                      ; preds = %_ZN11ListManager6appendEPv.exit.i, %.lr.ph58.i
  %exitcond.not.i = icmp eq i32 %48, %53
  br i1 %exitcond.not.i, label %._crit_edge.i.loopexit, label %.lr.ph58.i, !llvm.loop !9

._crit_edge.i.loopexit:                           ; preds = %.loopexit.i
  br label %._crit_edge.i

._crit_edge.i:                                    ; preds = %._crit_edge.i.loopexit, %_ZN11ListManager3getI7ElementEERT_i.exit.i
  %173 = add nuw nsw i32 %.04359.i, 1
  %exitcond63.not.i = icmp eq i32 %173, %10
  br i1 %exitcond63.not.i, label %element_listgen_nonroot.exit.loopexit, label %26, !llvm.loop !10

element_listgen_nonroot.exit.loopexit:            ; preds = %._crit_edge.i
  br label %element_listgen_nonroot.exit

element_listgen_nonroot.exit:                     ; preds = %element_listgen_nonroot.exit.loopexit, %entry
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %2)
  ret void
}

; Function Attrs: nounwind
define void @selection_abandon_42_kernel_5_struct_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.cpu_block_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.RuntimeContext.924, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 42
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds %struct.ListManager, ptr %6, i64 0, i32 5
  %8 = load i32, ptr %7, align 8
  store ptr %context, ptr %0, align 8
  %9 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  store ptr @function_body, ptr %9, align 8
  %10 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  store ptr %6, ptr %10, align 8
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  store <2 x i32> <i32 32, i32 32>, ptr %11, align 8
  %12 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  store i64 1, ptr %12, align 8
  %13 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 12
  %14 = load ptr, ptr %13, align 8
  %15 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 11
  %16 = load ptr, ptr %15, align 8
  %17 = shl nsw i32 %8, 5
  call void %14(ptr noundef %16, i32 noundef %17, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_struct_for_block_helper) #1
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree norecurse nounwind
define internal void @function_body(ptr %0, ptr nocapture readnone %1, ptr nocapture readonly %2, i32 %3, i32 %4) #2 {
allocs:
  %5 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %6 = icmp sgt i32 %4, %3
  br i1 %6, label %loop_body.lr.ph, label %func_exit

loop_body.lr.ph:                                  ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.924, ptr %0, i64 0, i32 1
  %8 = sub i32 %4, %3
  %9 = xor i32 %3, -1
  %10 = add i32 %9, %4
  %xtraiter = and i32 %8, 7
  %lcmp.mod.not = icmp eq i32 %xtraiter, 0
  br i1 %lcmp.mod.not, label %loop_body.prol.loopexit, label %loop_body.prol.preheader

loop_body.prol.preheader:                         ; preds = %loop_body.lr.ph
  br label %loop_body.prol

loop_body.prol:                                   ; preds = %loop_body_tail.prol, %loop_body.prol.preheader
  %lsr.iv45 = phi i32 [ %xtraiter, %loop_body.prol.preheader ], [ %lsr.iv.next46, %loop_body_tail.prol ]
  %.044.prol = phi i32 [ %47, %loop_body_tail.prol ], [ %3, %loop_body.prol.preheader ]
  %11 = load i32, ptr %5, align 4
  %12 = load ptr, ptr %2, align 8
  %13 = getelementptr inbounds i8, ptr %12, i64 32
  %14 = sdiv i32 %.044.prol, 8
  %15 = sext i32 %14 to i64
  %16 = getelementptr inbounds i8, ptr %13, i64 %15
  %17 = load i8, ptr %16, align 1
  %18 = zext i8 %17 to i32
  %19 = and i32 %.044.prol, 7
  %20 = shl nuw nsw i32 1, %19
  %21 = and i32 %20, %18
  %.not43.prol = icmp eq i32 %21, 0
  br i1 %.not43.prol, label %loop_body_tail.prol, label %struct_for_body_body.prol

struct_for_body_body.prol:                        ; preds = %loop_body.prol
  %22 = load ptr, ptr %7, align 8
  %23 = getelementptr inbounds %struct.LLVMRuntime, ptr %22, i64 0, i32 16
  %24 = load ptr, ptr %23, align 8
  %25 = load i32, ptr %24, align 4
  %.not.prol = icmp eq i32 %25, 0
  br i1 %.not.prol, label %loop_body_tail.prol, label %true_block.prol

true_block.prol:                                  ; preds = %struct_for_body_body.prol
  %26 = getelementptr inbounds %struct.LLVMRuntime, ptr %22, i64 0, i32 7
  %27 = load ptr, ptr %26, align 8
  %28 = getelementptr inbounds ptr, ptr %27, i64 6
  %29 = load ptr, ptr %28, align 8
  %30 = shl i32 %11, 3
  %31 = and i32 %30, 1073741816
  %32 = zext i32 %31 to i64
  %33 = getelementptr i8, ptr %29, i64 %32
  %34 = getelementptr inbounds i8, ptr %33, i64 8
  %35 = load ptr, ptr %34, align 8
  %36 = icmp eq ptr %35, null
  br i1 %36, label %37, label %Pointer_lookup_element.exit.prol

37:                                               ; preds = %true_block.prol
  %38 = getelementptr inbounds %struct.LLVMRuntime, ptr %22, i64 0, i32 15
  %39 = load ptr, ptr %38, align 8
  %40 = getelementptr inbounds ptr, ptr %39, i64 41
  %41 = load ptr, ptr %40, align 8
  br label %Pointer_lookup_element.exit.prol

Pointer_lookup_element.exit.prol:                 ; preds = %37, %true_block.prol
  %.0.i.prol = phi ptr [ %41, %37 ], [ %35, %true_block.prol ]
  %42 = and i32 %.044.prol, 31
  %43 = getelementptr inbounds i8, ptr %.0.i.prol, i64 32
  %44 = shl nuw i32 1, %42
  %45 = xor i32 %44, -1
  %46 = atomicrmw volatile and ptr %43, i32 %45 seq_cst, align 4
  br label %loop_body_tail.prol

loop_body_tail.prol:                              ; preds = %Pointer_lookup_element.exit.prol, %struct_for_body_body.prol, %loop_body.prol
  %47 = add i32 %.044.prol, 1
  %lsr.iv.next46 = add nsw i32 %lsr.iv45, -1
  %prol.iter.cmp.not = icmp eq i32 %lsr.iv.next46, 0
  br i1 %prol.iter.cmp.not, label %loop_body.prol.loopexit.loopexit, label %loop_body.prol, !llvm.loop !11

loop_body.prol.loopexit.loopexit:                 ; preds = %loop_body_tail.prol
  br label %loop_body.prol.loopexit

loop_body.prol.loopexit:                          ; preds = %loop_body.prol.loopexit.loopexit, %loop_body.lr.ph
  %.044.unr = phi i32 [ %3, %loop_body.lr.ph ], [ %47, %loop_body.prol.loopexit.loopexit ]
  %48 = icmp ult i32 %10, 7
  br i1 %48, label %func_exit, label %loop_body.lr.ph.new

loop_body.lr.ph.new:                              ; preds = %loop_body.prol.loopexit
  %49 = and i32 %.044.unr, 7
  %50 = add i32 %.044.unr, 1
  %51 = and i32 %50, 7
  %52 = add i32 %.044.unr, 2
  %53 = and i32 %52, 7
  %54 = add i32 %.044.unr, 3
  %55 = and i32 %54, 7
  %56 = xor i32 %49, 4
  %57 = add i32 %.044.unr, 5
  %58 = and i32 %57, 7
  %59 = add i32 %.044.unr, 6
  %60 = and i32 %59, 7
  %61 = add i32 %.044.unr, 7
  %62 = and i32 %61, 7
  %63 = shl nuw nsw i32 1, %49
  %64 = shl nuw nsw i32 1, %51
  %65 = shl nuw nsw i32 1, %53
  %66 = shl nuw nsw i32 1, %55
  %67 = shl nuw nsw i32 1, %56
  %68 = shl nuw nsw i32 1, %58
  %69 = shl nuw nsw i32 1, %60
  %70 = shl nuw nsw i32 1, %62
  br label %loop_body

loop_body:                                        ; preds = %loop_body_tail.7, %loop_body.lr.ph.new
  %lsr.iv = phi i32 [ %lsr.iv.next, %loop_body_tail.7 ], [ %61, %loop_body.lr.ph.new ]
  %71 = add i32 %lsr.iv, -7
  %72 = load i32, ptr %5, align 4
  %73 = load ptr, ptr %2, align 8
  %74 = getelementptr inbounds i8, ptr %73, i64 32
  %75 = sdiv i32 %71, 8
  %76 = sext i32 %75 to i64
  %77 = getelementptr inbounds i8, ptr %74, i64 %76
  %78 = load i8, ptr %77, align 1
  %79 = zext i8 %78 to i32
  %80 = and i32 %63, %79
  %.not43 = icmp eq i32 %80, 0
  br i1 %.not43, label %loop_body_tail, label %struct_for_body_body

loop_body_tail:                                   ; preds = %Pointer_lookup_element.exit, %struct_for_body_body, %loop_body
  %81 = add i32 %lsr.iv, -6
  %82 = load i32, ptr %5, align 4
  %83 = load ptr, ptr %2, align 8
  %84 = getelementptr inbounds i8, ptr %83, i64 32
  %85 = add i32 %71, 1
  %86 = sdiv i32 %85, 8
  %87 = sext i32 %86 to i64
  %88 = getelementptr inbounds i8, ptr %84, i64 %87
  %89 = load i8, ptr %88, align 1
  %90 = zext i8 %89 to i32
  %91 = and i32 %64, %90
  %.not43.1 = icmp eq i32 %91, 0
  br i1 %.not43.1, label %loop_body_tail.1, label %struct_for_body_body.1

struct_for_body_body.1:                           ; preds = %loop_body_tail
  %92 = load ptr, ptr %7, align 8
  %93 = getelementptr inbounds %struct.LLVMRuntime, ptr %92, i64 0, i32 16
  %94 = load ptr, ptr %93, align 8
  %95 = load i32, ptr %94, align 4
  %.not.1 = icmp eq i32 %95, 0
  br i1 %.not.1, label %loop_body_tail.1, label %true_block.1

true_block.1:                                     ; preds = %struct_for_body_body.1
  %96 = getelementptr inbounds %struct.LLVMRuntime, ptr %92, i64 0, i32 7
  %97 = load ptr, ptr %96, align 8
  %98 = getelementptr inbounds ptr, ptr %97, i64 6
  %99 = load ptr, ptr %98, align 8
  %100 = shl i32 %82, 3
  %101 = and i32 %100, 1073741816
  %102 = zext i32 %101 to i64
  %103 = getelementptr i8, ptr %99, i64 %102
  %104 = getelementptr inbounds i8, ptr %103, i64 8
  %105 = load ptr, ptr %104, align 8
  %106 = icmp eq ptr %105, null
  br i1 %106, label %107, label %Pointer_lookup_element.exit.1

107:                                              ; preds = %true_block.1
  %108 = getelementptr inbounds %struct.LLVMRuntime, ptr %92, i64 0, i32 15
  %109 = load ptr, ptr %108, align 8
  %110 = getelementptr inbounds ptr, ptr %109, i64 41
  %111 = load ptr, ptr %110, align 8
  br label %Pointer_lookup_element.exit.1

Pointer_lookup_element.exit.1:                    ; preds = %107, %true_block.1
  %.0.i.1 = phi ptr [ %111, %107 ], [ %105, %true_block.1 ]
  %112 = and i32 %81, 31
  %113 = getelementptr inbounds i8, ptr %.0.i.1, i64 32
  %114 = shl nuw i32 1, %112
  %115 = xor i32 %114, -1
  %116 = atomicrmw volatile and ptr %113, i32 %115 seq_cst, align 4
  br label %loop_body_tail.1

loop_body_tail.1:                                 ; preds = %Pointer_lookup_element.exit.1, %struct_for_body_body.1, %loop_body_tail
  %117 = add i32 %lsr.iv, -5
  %118 = load i32, ptr %5, align 4
  %119 = load ptr, ptr %2, align 8
  %120 = getelementptr inbounds i8, ptr %119, i64 32
  %121 = add i32 %85, 1
  %122 = sdiv i32 %121, 8
  %123 = sext i32 %122 to i64
  %124 = getelementptr inbounds i8, ptr %120, i64 %123
  %125 = load i8, ptr %124, align 1
  %126 = zext i8 %125 to i32
  %127 = and i32 %65, %126
  %.not43.2 = icmp eq i32 %127, 0
  br i1 %.not43.2, label %loop_body_tail.2, label %struct_for_body_body.2

struct_for_body_body.2:                           ; preds = %loop_body_tail.1
  %128 = load ptr, ptr %7, align 8
  %129 = getelementptr inbounds %struct.LLVMRuntime, ptr %128, i64 0, i32 16
  %130 = load ptr, ptr %129, align 8
  %131 = load i32, ptr %130, align 4
  %.not.2 = icmp eq i32 %131, 0
  br i1 %.not.2, label %loop_body_tail.2, label %true_block.2

true_block.2:                                     ; preds = %struct_for_body_body.2
  %132 = getelementptr inbounds %struct.LLVMRuntime, ptr %128, i64 0, i32 7
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr inbounds ptr, ptr %133, i64 6
  %135 = load ptr, ptr %134, align 8
  %136 = shl i32 %118, 3
  %137 = and i32 %136, 1073741816
  %138 = zext i32 %137 to i64
  %139 = getelementptr i8, ptr %135, i64 %138
  %140 = getelementptr inbounds i8, ptr %139, i64 8
  %141 = load ptr, ptr %140, align 8
  %142 = icmp eq ptr %141, null
  br i1 %142, label %143, label %Pointer_lookup_element.exit.2

143:                                              ; preds = %true_block.2
  %144 = getelementptr inbounds %struct.LLVMRuntime, ptr %128, i64 0, i32 15
  %145 = load ptr, ptr %144, align 8
  %146 = getelementptr inbounds ptr, ptr %145, i64 41
  %147 = load ptr, ptr %146, align 8
  br label %Pointer_lookup_element.exit.2

Pointer_lookup_element.exit.2:                    ; preds = %143, %true_block.2
  %.0.i.2 = phi ptr [ %147, %143 ], [ %141, %true_block.2 ]
  %148 = and i32 %117, 31
  %149 = getelementptr inbounds i8, ptr %.0.i.2, i64 32
  %150 = shl nuw i32 1, %148
  %151 = xor i32 %150, -1
  %152 = atomicrmw volatile and ptr %149, i32 %151 seq_cst, align 4
  br label %loop_body_tail.2

loop_body_tail.2:                                 ; preds = %Pointer_lookup_element.exit.2, %struct_for_body_body.2, %loop_body_tail.1
  %153 = add i32 %lsr.iv, -4
  %154 = load i32, ptr %5, align 4
  %155 = load ptr, ptr %2, align 8
  %156 = getelementptr inbounds i8, ptr %155, i64 32
  %157 = add i32 %121, 1
  %158 = sdiv i32 %157, 8
  %159 = sext i32 %158 to i64
  %160 = getelementptr inbounds i8, ptr %156, i64 %159
  %161 = load i8, ptr %160, align 1
  %162 = zext i8 %161 to i32
  %163 = and i32 %66, %162
  %.not43.3 = icmp eq i32 %163, 0
  br i1 %.not43.3, label %loop_body_tail.3, label %struct_for_body_body.3

struct_for_body_body.3:                           ; preds = %loop_body_tail.2
  %164 = load ptr, ptr %7, align 8
  %165 = getelementptr inbounds %struct.LLVMRuntime, ptr %164, i64 0, i32 16
  %166 = load ptr, ptr %165, align 8
  %167 = load i32, ptr %166, align 4
  %.not.3 = icmp eq i32 %167, 0
  br i1 %.not.3, label %loop_body_tail.3, label %true_block.3

true_block.3:                                     ; preds = %struct_for_body_body.3
  %168 = getelementptr inbounds %struct.LLVMRuntime, ptr %164, i64 0, i32 7
  %169 = load ptr, ptr %168, align 8
  %170 = getelementptr inbounds ptr, ptr %169, i64 6
  %171 = load ptr, ptr %170, align 8
  %172 = shl i32 %154, 3
  %173 = and i32 %172, 1073741816
  %174 = zext i32 %173 to i64
  %175 = getelementptr i8, ptr %171, i64 %174
  %176 = getelementptr inbounds i8, ptr %175, i64 8
  %177 = load ptr, ptr %176, align 8
  %178 = icmp eq ptr %177, null
  br i1 %178, label %179, label %Pointer_lookup_element.exit.3

179:                                              ; preds = %true_block.3
  %180 = getelementptr inbounds %struct.LLVMRuntime, ptr %164, i64 0, i32 15
  %181 = load ptr, ptr %180, align 8
  %182 = getelementptr inbounds ptr, ptr %181, i64 41
  %183 = load ptr, ptr %182, align 8
  br label %Pointer_lookup_element.exit.3

Pointer_lookup_element.exit.3:                    ; preds = %179, %true_block.3
  %.0.i.3 = phi ptr [ %183, %179 ], [ %177, %true_block.3 ]
  %184 = and i32 %153, 31
  %185 = getelementptr inbounds i8, ptr %.0.i.3, i64 32
  %186 = shl nuw i32 1, %184
  %187 = xor i32 %186, -1
  %188 = atomicrmw volatile and ptr %185, i32 %187 seq_cst, align 4
  br label %loop_body_tail.3

loop_body_tail.3:                                 ; preds = %Pointer_lookup_element.exit.3, %struct_for_body_body.3, %loop_body_tail.2
  %189 = add i32 %lsr.iv, -3
  %190 = load i32, ptr %5, align 4
  %191 = load ptr, ptr %2, align 8
  %192 = getelementptr inbounds i8, ptr %191, i64 32
  %193 = add i32 %157, 1
  %194 = sdiv i32 %193, 8
  %195 = sext i32 %194 to i64
  %196 = getelementptr inbounds i8, ptr %192, i64 %195
  %197 = load i8, ptr %196, align 1
  %198 = zext i8 %197 to i32
  %199 = and i32 %67, %198
  %.not43.4 = icmp eq i32 %199, 0
  br i1 %.not43.4, label %loop_body_tail.4, label %struct_for_body_body.4

struct_for_body_body.4:                           ; preds = %loop_body_tail.3
  %200 = load ptr, ptr %7, align 8
  %201 = getelementptr inbounds %struct.LLVMRuntime, ptr %200, i64 0, i32 16
  %202 = load ptr, ptr %201, align 8
  %203 = load i32, ptr %202, align 4
  %.not.4 = icmp eq i32 %203, 0
  br i1 %.not.4, label %loop_body_tail.4, label %true_block.4

true_block.4:                                     ; preds = %struct_for_body_body.4
  %204 = getelementptr inbounds %struct.LLVMRuntime, ptr %200, i64 0, i32 7
  %205 = load ptr, ptr %204, align 8
  %206 = getelementptr inbounds ptr, ptr %205, i64 6
  %207 = load ptr, ptr %206, align 8
  %208 = shl i32 %190, 3
  %209 = and i32 %208, 1073741816
  %210 = zext i32 %209 to i64
  %211 = getelementptr i8, ptr %207, i64 %210
  %212 = getelementptr inbounds i8, ptr %211, i64 8
  %213 = load ptr, ptr %212, align 8
  %214 = icmp eq ptr %213, null
  br i1 %214, label %215, label %Pointer_lookup_element.exit.4

215:                                              ; preds = %true_block.4
  %216 = getelementptr inbounds %struct.LLVMRuntime, ptr %200, i64 0, i32 15
  %217 = load ptr, ptr %216, align 8
  %218 = getelementptr inbounds ptr, ptr %217, i64 41
  %219 = load ptr, ptr %218, align 8
  br label %Pointer_lookup_element.exit.4

Pointer_lookup_element.exit.4:                    ; preds = %215, %true_block.4
  %.0.i.4 = phi ptr [ %219, %215 ], [ %213, %true_block.4 ]
  %220 = and i32 %189, 31
  %221 = getelementptr inbounds i8, ptr %.0.i.4, i64 32
  %222 = shl nuw i32 1, %220
  %223 = xor i32 %222, -1
  %224 = atomicrmw volatile and ptr %221, i32 %223 seq_cst, align 4
  br label %loop_body_tail.4

loop_body_tail.4:                                 ; preds = %Pointer_lookup_element.exit.4, %struct_for_body_body.4, %loop_body_tail.3
  %225 = add i32 %lsr.iv, -2
  %226 = load i32, ptr %5, align 4
  %227 = load ptr, ptr %2, align 8
  %228 = getelementptr inbounds i8, ptr %227, i64 32
  %229 = add i32 %193, 1
  %230 = sdiv i32 %229, 8
  %231 = sext i32 %230 to i64
  %232 = getelementptr inbounds i8, ptr %228, i64 %231
  %233 = load i8, ptr %232, align 1
  %234 = zext i8 %233 to i32
  %235 = and i32 %68, %234
  %.not43.5 = icmp eq i32 %235, 0
  br i1 %.not43.5, label %loop_body_tail.5, label %struct_for_body_body.5

struct_for_body_body.5:                           ; preds = %loop_body_tail.4
  %236 = load ptr, ptr %7, align 8
  %237 = getelementptr inbounds %struct.LLVMRuntime, ptr %236, i64 0, i32 16
  %238 = load ptr, ptr %237, align 8
  %239 = load i32, ptr %238, align 4
  %.not.5 = icmp eq i32 %239, 0
  br i1 %.not.5, label %loop_body_tail.5, label %true_block.5

true_block.5:                                     ; preds = %struct_for_body_body.5
  %240 = getelementptr inbounds %struct.LLVMRuntime, ptr %236, i64 0, i32 7
  %241 = load ptr, ptr %240, align 8
  %242 = getelementptr inbounds ptr, ptr %241, i64 6
  %243 = load ptr, ptr %242, align 8
  %244 = shl i32 %226, 3
  %245 = and i32 %244, 1073741816
  %246 = zext i32 %245 to i64
  %247 = getelementptr i8, ptr %243, i64 %246
  %248 = getelementptr inbounds i8, ptr %247, i64 8
  %249 = load ptr, ptr %248, align 8
  %250 = icmp eq ptr %249, null
  br i1 %250, label %251, label %Pointer_lookup_element.exit.5

251:                                              ; preds = %true_block.5
  %252 = getelementptr inbounds %struct.LLVMRuntime, ptr %236, i64 0, i32 15
  %253 = load ptr, ptr %252, align 8
  %254 = getelementptr inbounds ptr, ptr %253, i64 41
  %255 = load ptr, ptr %254, align 8
  br label %Pointer_lookup_element.exit.5

Pointer_lookup_element.exit.5:                    ; preds = %251, %true_block.5
  %.0.i.5 = phi ptr [ %255, %251 ], [ %249, %true_block.5 ]
  %256 = and i32 %225, 31
  %257 = getelementptr inbounds i8, ptr %.0.i.5, i64 32
  %258 = shl nuw i32 1, %256
  %259 = xor i32 %258, -1
  %260 = atomicrmw volatile and ptr %257, i32 %259 seq_cst, align 4
  br label %loop_body_tail.5

loop_body_tail.5:                                 ; preds = %Pointer_lookup_element.exit.5, %struct_for_body_body.5, %loop_body_tail.4
  %261 = add i32 %lsr.iv, -1
  %262 = load i32, ptr %5, align 4
  %263 = load ptr, ptr %2, align 8
  %264 = getelementptr inbounds i8, ptr %263, i64 32
  %265 = add i32 %229, 1
  %266 = sdiv i32 %265, 8
  %267 = sext i32 %266 to i64
  %268 = getelementptr inbounds i8, ptr %264, i64 %267
  %269 = load i8, ptr %268, align 1
  %270 = zext i8 %269 to i32
  %271 = and i32 %69, %270
  %.not43.6 = icmp eq i32 %271, 0
  br i1 %.not43.6, label %loop_body_tail.6, label %struct_for_body_body.6

struct_for_body_body.6:                           ; preds = %loop_body_tail.5
  %272 = load ptr, ptr %7, align 8
  %273 = getelementptr inbounds %struct.LLVMRuntime, ptr %272, i64 0, i32 16
  %274 = load ptr, ptr %273, align 8
  %275 = load i32, ptr %274, align 4
  %.not.6 = icmp eq i32 %275, 0
  br i1 %.not.6, label %loop_body_tail.6, label %true_block.6

true_block.6:                                     ; preds = %struct_for_body_body.6
  %276 = getelementptr inbounds %struct.LLVMRuntime, ptr %272, i64 0, i32 7
  %277 = load ptr, ptr %276, align 8
  %278 = getelementptr inbounds ptr, ptr %277, i64 6
  %279 = load ptr, ptr %278, align 8
  %280 = shl i32 %262, 3
  %281 = and i32 %280, 1073741816
  %282 = zext i32 %281 to i64
  %283 = getelementptr i8, ptr %279, i64 %282
  %284 = getelementptr inbounds i8, ptr %283, i64 8
  %285 = load ptr, ptr %284, align 8
  %286 = icmp eq ptr %285, null
  br i1 %286, label %287, label %Pointer_lookup_element.exit.6

287:                                              ; preds = %true_block.6
  %288 = getelementptr inbounds %struct.LLVMRuntime, ptr %272, i64 0, i32 15
  %289 = load ptr, ptr %288, align 8
  %290 = getelementptr inbounds ptr, ptr %289, i64 41
  %291 = load ptr, ptr %290, align 8
  br label %Pointer_lookup_element.exit.6

Pointer_lookup_element.exit.6:                    ; preds = %287, %true_block.6
  %.0.i.6 = phi ptr [ %291, %287 ], [ %285, %true_block.6 ]
  %292 = and i32 %261, 31
  %293 = getelementptr inbounds i8, ptr %.0.i.6, i64 32
  %294 = shl nuw i32 1, %292
  %295 = xor i32 %294, -1
  %296 = atomicrmw volatile and ptr %293, i32 %295 seq_cst, align 4
  br label %loop_body_tail.6

loop_body_tail.6:                                 ; preds = %Pointer_lookup_element.exit.6, %struct_for_body_body.6, %loop_body_tail.5
  %297 = load i32, ptr %5, align 4
  %298 = load ptr, ptr %2, align 8
  %299 = getelementptr inbounds i8, ptr %298, i64 32
  %300 = add i32 %265, 1
  %301 = sdiv i32 %300, 8
  %302 = sext i32 %301 to i64
  %303 = getelementptr inbounds i8, ptr %299, i64 %302
  %304 = load i8, ptr %303, align 1
  %305 = zext i8 %304 to i32
  %306 = and i32 %70, %305
  %.not43.7 = icmp eq i32 %306, 0
  br i1 %.not43.7, label %loop_body_tail.7, label %struct_for_body_body.7

struct_for_body_body.7:                           ; preds = %loop_body_tail.6
  %307 = load ptr, ptr %7, align 8
  %308 = getelementptr inbounds %struct.LLVMRuntime, ptr %307, i64 0, i32 16
  %309 = load ptr, ptr %308, align 8
  %310 = load i32, ptr %309, align 4
  %.not.7 = icmp eq i32 %310, 0
  br i1 %.not.7, label %loop_body_tail.7, label %true_block.7

true_block.7:                                     ; preds = %struct_for_body_body.7
  %311 = getelementptr inbounds %struct.LLVMRuntime, ptr %307, i64 0, i32 7
  %312 = load ptr, ptr %311, align 8
  %313 = getelementptr inbounds ptr, ptr %312, i64 6
  %314 = load ptr, ptr %313, align 8
  %315 = shl i32 %297, 3
  %316 = and i32 %315, 1073741816
  %317 = zext i32 %316 to i64
  %318 = getelementptr i8, ptr %314, i64 %317
  %319 = getelementptr inbounds i8, ptr %318, i64 8
  %320 = load ptr, ptr %319, align 8
  %321 = icmp eq ptr %320, null
  br i1 %321, label %322, label %Pointer_lookup_element.exit.7

322:                                              ; preds = %true_block.7
  %323 = getelementptr inbounds %struct.LLVMRuntime, ptr %307, i64 0, i32 15
  %324 = load ptr, ptr %323, align 8
  %325 = getelementptr inbounds ptr, ptr %324, i64 41
  %326 = load ptr, ptr %325, align 8
  br label %Pointer_lookup_element.exit.7

Pointer_lookup_element.exit.7:                    ; preds = %322, %true_block.7
  %.0.i.7 = phi ptr [ %326, %322 ], [ %320, %true_block.7 ]
  %327 = and i32 %lsr.iv, 31
  %328 = getelementptr inbounds i8, ptr %.0.i.7, i64 32
  %329 = shl nuw i32 1, %327
  %330 = xor i32 %329, -1
  %331 = atomicrmw volatile and ptr %328, i32 %330 seq_cst, align 4
  br label %loop_body_tail.7

loop_body_tail.7:                                 ; preds = %Pointer_lookup_element.exit.7, %struct_for_body_body.7, %loop_body_tail.6
  %lsr.iv.next = add i32 %lsr.iv, 8
  %332 = add i32 %300, 1
  %exitcond.not.7 = icmp eq i32 %332, %4
  br i1 %exitcond.not.7, label %func_exit.loopexit, label %loop_body

func_exit.loopexit:                               ; preds = %loop_body_tail.7
  br label %func_exit

func_exit:                                        ; preds = %func_exit.loopexit, %loop_body.prol.loopexit, %allocs
  ret void

struct_for_body_body:                             ; preds = %loop_body
  %333 = load ptr, ptr %7, align 8
  %334 = getelementptr inbounds %struct.LLVMRuntime, ptr %333, i64 0, i32 16
  %335 = load ptr, ptr %334, align 8
  %336 = load i32, ptr %335, align 4
  %.not = icmp eq i32 %336, 0
  br i1 %.not, label %loop_body_tail, label %true_block

true_block:                                       ; preds = %struct_for_body_body
  %337 = getelementptr inbounds %struct.LLVMRuntime, ptr %333, i64 0, i32 7
  %338 = load ptr, ptr %337, align 8
  %339 = getelementptr inbounds ptr, ptr %338, i64 6
  %340 = load ptr, ptr %339, align 8
  %341 = shl i32 %72, 3
  %342 = and i32 %341, 1073741816
  %343 = zext i32 %342 to i64
  %344 = getelementptr i8, ptr %340, i64 %343
  %345 = getelementptr inbounds i8, ptr %344, i64 8
  %346 = load ptr, ptr %345, align 8
  %347 = icmp eq ptr %346, null
  br i1 %347, label %348, label %Pointer_lookup_element.exit

348:                                              ; preds = %true_block
  %349 = getelementptr inbounds %struct.LLVMRuntime, ptr %333, i64 0, i32 15
  %350 = load ptr, ptr %349, align 8
  %351 = getelementptr inbounds ptr, ptr %350, i64 41
  %352 = load ptr, ptr %351, align 8
  br label %Pointer_lookup_element.exit

Pointer_lookup_element.exit:                      ; preds = %348, %true_block
  %.0.i = phi ptr [ %352, %348 ], [ %346, %true_block ]
  %353 = and i32 %71, 31
  %354 = getelementptr inbounds i8, ptr %.0.i, i64 32
  %355 = shl nuw i32 1, %353
  %356 = xor i32 %355, -1
  %357 = atomicrmw volatile and ptr %354, i32 %356 seq_cst, align 4
  br label %loop_body_tail
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @selection_abandon_42_kernel_6_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.924, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 44
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @selection_abandon_42_kernel_7_listgen_S44pointer(ptr %context) local_unnamed_addr #1 {
  %.sroa.2.i = alloca { [2 x i32], %struct.PhysicalCoordinates.937 }, align 8
  %1 = alloca %0, align 8
  %2 = getelementptr inbounds %struct.RuntimeContext.924, ptr %context, i64 0, i32 1
  %3 = load ptr, ptr %2, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %1)
  %4 = getelementptr inbounds %struct.LLVMRuntime, ptr %3, i64 0, i32 13
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds ptr, ptr %5, i64 40
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds ptr, ptr %5, i64 44
  %9 = load ptr, ptr %8, align 8
  %10 = load atomic i64, ptr %7 acquire, align 8
  %.not.i.i.i.i = icmp ne i64 %10, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i)
  %11 = inttoptr i64 %10 to ptr
  %12 = load atomic i64, ptr %11 acquire, align 8
  %13 = inttoptr i64 %12 to ptr
  %.sroa.0.0.copyload.i = load ptr, ptr %13, align 8
  %.sroa.2.0..sroa_idx.i = getelementptr inbounds i8, ptr %13, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.i, ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.0..sroa_idx.i, i64 56, i1 false)
  %getch.i = getelementptr %1, ptr %.sroa.0.0.copyload.i, i64 0, i32 1
  %14 = getelementptr inbounds %0, ptr %1, i64 0, i32 2
  %.sroa.2.16.sroa_idx.i = getelementptr inbounds i8, ptr %.sroa.2.i, i64 8
  %15 = getelementptr inbounds %struct.ListManager, ptr %9, i64 0, i32 5
  %16 = getelementptr inbounds %struct.ListManager, ptr %9, i64 0, i32 3
  %17 = getelementptr inbounds %struct.ListManager, ptr %9, i64 0, i32 4
  %18 = getelementptr inbounds %struct.ListManager, ptr %9, i64 0, i32 6
  %19 = getelementptr inbounds %struct.ListManager, ptr %9, i64 0, i32 2
  %20 = getelementptr inbounds %struct.ListManager, ptr %9, i64 0, i32 1
  store ptr %getch.i, ptr %1, align 8
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %1, i64 8
  store <2 x i32> <i32 0, i32 1>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %14, ptr noundef nonnull align 8 dereferenceable(48) %.sroa.2.16.sroa_idx.i, i64 48, i1 false)
  %21 = atomicrmw volatile add ptr %15, i32 1 seq_cst, align 4
  %22 = load i32, ptr %16, align 8
  %23 = ashr i32 %21, %22
  %24 = icmp ugt i32 %23, 131071
  br i1 %24, label %25, label %27

25:                                               ; preds = %0
  %26 = load ptr, ptr %18, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %26, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

27:                                               ; preds = %0
  %28 = zext i32 %23 to i64
  %29 = lshr i64 %28, 9
  %30 = getelementptr inbounds [256 x ptr], ptr %9, i64 0, i64 %29
  %31 = load atomic i64, ptr %30 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %31, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %27
  %32 = inttoptr i64 %31 to ptr
  %33 = and i64 %28, 511
  %34 = getelementptr inbounds ptr, ptr %32, i64 %33
  %35 = load atomic i64, ptr %34 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %35, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %27
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %36 = atomicrmw volatile xchg ptr %17, i32 1 seq_cst, align 4
  %37 = icmp eq i32 %36, 1
  br i1 %37, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %38 = load atomic i64, ptr %30 acquire, align 8
  %39 = inttoptr i64 %38 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %38, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %40, label %74

40:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %41 = load ptr, ptr %18, align 8
  %42 = getelementptr inbounds %struct.LLVMRuntime, ptr %41, i64 0, i32 1
  %43 = getelementptr inbounds %struct.LLVMRuntime, ptr %41, i64 0, i32 28
  %44 = atomicrmw volatile add ptr %43, i64 4096 seq_cst, align 8
  %45 = getelementptr inbounds %struct.LLVMRuntime, ptr %41, i64 0, i32 1, i32 2
  %46 = load i64, ptr %45, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %46, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %67, label %47

47:                                               ; preds = %40
  %48 = getelementptr inbounds %struct.LLVMRuntime, ptr %41, i64 0, i32 26
  br label %49

49:                                               ; preds = %49, %47
  %50 = atomicrmw volatile xchg ptr %48, i32 1 seq_cst, align 4
  %51 = icmp eq i32 %50, 1
  br i1 %51, label %49, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %49
  %52 = load ptr, ptr %42, align 8
  %53 = ptrtoint ptr %52 to i64
  %54 = getelementptr inbounds %struct.LLVMRuntime, ptr %41, i64 0, i32 1, i32 1
  %55 = load ptr, ptr %54, align 8
  %56 = ptrtoint ptr %55 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %53
  %57 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %58 = or i64 %57, 4096
  %59 = add i64 %58, %53
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %59, %56
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %60

60:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %61 = add i64 %57, %53
  %62 = inttoptr i64 %61 to ptr
  %63 = getelementptr i8, ptr %52, i64 %57
  %64 = getelementptr inbounds i8, ptr %63, i64 4096
  store ptr %64, ptr %42, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %60, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %62, %60 ]
  %65 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %66 = atomicrmw volatile xchg ptr %48, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %41, i1 noundef zeroext %65, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

67:                                               ; preds = %40
  %68 = getelementptr inbounds %struct.LLVMRuntime, ptr %41, i64 0, i32 2
  %69 = load ptr, ptr %68, align 8
  %70 = getelementptr inbounds %struct.LLVMRuntime, ptr %41, i64 0, i32 6
  %71 = load ptr, ptr %70, align 8
  %72 = tail call noundef ptr %69(ptr noundef %71, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %67, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %72, %67 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %73 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %73, ptr %30 release, align 8
  br label %74

74:                                               ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %39, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %75 = and i32 %23, 511
  %76 = zext i32 %75 to i64
  %77 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %76
  %78 = load atomic i64, ptr %77 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %78, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %79, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

79:                                               ; preds = %74
  %80 = load ptr, ptr %18, align 8
  %81 = getelementptr inbounds %struct.LLVMRuntime, ptr %80, i64 0, i32 1
  %82 = load i64, ptr %19, align 8
  %83 = load i64, ptr %20, align 8
  %84 = mul i64 %83, %82
  %85 = getelementptr inbounds %struct.LLVMRuntime, ptr %80, i64 0, i32 28
  %86 = atomicrmw volatile add ptr %85, i64 %84 seq_cst, align 8
  %87 = getelementptr inbounds %struct.LLVMRuntime, ptr %80, i64 0, i32 1, i32 2
  %88 = load i64, ptr %87, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %88, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %108, label %89

89:                                               ; preds = %79
  %90 = getelementptr inbounds %struct.LLVMRuntime, ptr %80, i64 0, i32 26
  br label %91

91:                                               ; preds = %91, %89
  %92 = atomicrmw volatile xchg ptr %90, i32 1 seq_cst, align 4
  %93 = icmp eq i32 %92, 1
  br i1 %93, label %91, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %91
  %94 = load ptr, ptr %81, align 8
  %95 = ptrtoint ptr %94 to i64
  %96 = getelementptr inbounds %struct.LLVMRuntime, ptr %80, i64 0, i32 1, i32 1
  %97 = load ptr, ptr %96, align 8
  %98 = ptrtoint ptr %97 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %95
  %99 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %100 = add i64 %99, %84
  %101 = add i64 %100, %95
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %101, %98
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %102

102:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %103 = add i64 %99, %95
  %104 = inttoptr i64 %103 to ptr
  %105 = getelementptr inbounds i8, ptr %94, i64 %100
  store ptr %105, ptr %81, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %102, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %104, %102 ]
  %106 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %107 = atomicrmw volatile xchg ptr %90, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %80, i1 noundef zeroext %106, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

108:                                              ; preds = %79
  %109 = getelementptr inbounds %struct.LLVMRuntime, ptr %80, i64 0, i32 2
  %110 = load ptr, ptr %109, align 8
  %111 = getelementptr inbounds %struct.LLVMRuntime, ptr %80, i64 0, i32 6
  %112 = load ptr, ptr %111, align 8
  %113 = tail call noundef ptr %110(ptr noundef %112, i64 noundef %84, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %108, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %113, %108 ]
  %114 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %114, ptr %77 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %74
  %115 = atomicrmw volatile xchg ptr %17, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %25
  %116 = load i32, ptr %16, align 8
  %117 = ashr i32 %21, %116
  %118 = sext i32 %117 to i64
  %119 = lshr i64 %118, 9
  %120 = getelementptr inbounds [256 x ptr], ptr %9, i64 0, i64 %119
  %121 = load atomic i64, ptr %120 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %121, 0
  br i1 %.not.i.i1.i.i.i, label %element_listgen_root.exit, label %122

122:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %123 = inttoptr i64 %121 to ptr
  %124 = and i64 %118, 511
  %125 = getelementptr inbounds ptr, ptr %123, i64 %124
  %126 = load atomic i64, ptr %125 acquire, align 8
  %127 = inttoptr i64 %126 to ptr
  br label %element_listgen_root.exit

element_listgen_root.exit:                        ; preds = %122, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %128 = phi ptr [ %127, %122 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %129 = load i64, ptr %20, align 8
  %130 = load i32, ptr %16, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %130
  %131 = xor i32 %notmask.i.i.i.i, -1
  %132 = and i32 %21, %131
  %133 = sext i32 %132 to i64
  %134 = mul i64 %129, %133
  %135 = getelementptr inbounds i8, ptr %128, i64 %134
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %135, ptr nonnull align 8 %1, i64 %129, i1 false)
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %1)
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @selection_abandon_42_kernel_8_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.924, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 45
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @selection_abandon_42_kernel_9_listgen_S45bitmasked(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %0, align 8
  %1 = alloca %struct.PhysicalCoordinates.937, align 4
  %2 = alloca %0, align 8
  %3 = getelementptr inbounds %struct.RuntimeContext.924, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %2)
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 13
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %6, i64 44
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %10 = load i32, ptr %9, align 8
  %11 = getelementptr inbounds ptr, ptr %6, i64 45
  %12 = load ptr, ptr %11, align 8
  %13 = icmp sgt i32 %10, 0
  br i1 %13, label %.lr.ph61.i, label %element_listgen_nonroot.exit

.lr.ph61.i:                                       ; preds = %entry
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  %16 = getelementptr inbounds %0, ptr %0, i64 0, i32 1
  %17 = getelementptr inbounds %0, ptr %0, i64 0, i32 1, i64 1
  %18 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %19 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %20 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 5
  %21 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %22 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 4
  %23 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 6
  %24 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 2
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %.8.sroa_idx11 = getelementptr inbounds i8, ptr %2, i64 8
  br label %26

26:                                               ; preds = %._crit_edge.i, %.lr.ph61.i
  %.04359.i = phi i32 [ 0, %.lr.ph61.i ], [ %173, %._crit_edge.i ]
  %27 = load i32, ptr %14, align 8
  %28 = lshr i32 %.04359.i, %27
  %29 = sext i32 %28 to i64
  %30 = lshr i64 %29, 9
  %31 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %30
  %32 = load atomic i64, ptr %31 acquire, align 8
  %.not.i.i.i.i = icmp eq i64 %32, 0
  br i1 %.not.i.i.i.i, label %_ZN11ListManager3getI7ElementEERT_i.exit.i, label %33

33:                                               ; preds = %26
  %34 = inttoptr i64 %32 to ptr
  %35 = and i64 %29, 511
  %36 = getelementptr inbounds ptr, ptr %34, i64 %35
  %37 = load atomic i64, ptr %36 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit.i

_ZN11ListManager3getI7ElementEERT_i.exit.i:       ; preds = %33, %26
  %39 = phi ptr [ %38, %33 ], [ null, %26 ]
  %40 = load i64, ptr %15, align 8
  %41 = load i32, ptr %14, align 8
  %notmask.i.i.i = shl nsw i32 -1, %41
  %42 = xor i32 %notmask.i.i.i, -1
  %43 = and i32 %.04359.i, %42
  %44 = zext i32 %43 to i64
  %45 = mul i64 %40, %44
  %46 = getelementptr inbounds i8, ptr %39, i64 %45
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %0, ptr noundef nonnull align 8 dereferenceable(64) %46, i64 64, i1 false)
  %47 = load i32, ptr %16, align 8
  %48 = load i32, ptr %17, align 4
  %49 = icmp slt i32 %47, %48
  br i1 %49, label %.lr.ph58.i.preheader, label %._crit_edge.i

.lr.ph58.i.preheader:                             ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit.i
  %50 = zext i32 %47 to i64
  br label %.lr.ph58.i

.lr.ph58.i:                                       ; preds = %.loopexit.i, %.lr.ph58.i.preheader
  %indvars.iv = phi i64 [ %50, %.lr.ph58.i.preheader ], [ %indvars.iv.next, %.loopexit.i ]
  %51 = trunc i64 %indvars.iv to i32
  call fastcc void @S44_refine_coordinates(ptr noundef nonnull %18, ptr noundef nonnull %1, i32 noundef %51) #1
  %52 = load ptr, ptr %0, align 8
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %53 = trunc i64 %indvars.iv.next to i32
  %54 = shl nsw i32 %53, 3
  %55 = sext i32 %54 to i64
  %56 = getelementptr inbounds i8, ptr %52, i64 %55
  %57 = load ptr, ptr %56, align 8
  %.not = icmp eq ptr %57, null
  br i1 %.not, label %.loopexit.i, label %.lr.ph.i

.lr.ph.i:                                         ; preds = %.lr.ph58.i
  store ptr %57, ptr %2, align 8
  store <2 x i32> <i32 0, i32 32>, ptr %.8.sroa_idx11, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %19, ptr noundef nonnull align 4 dereferenceable(48) %1, i64 48, i1 false)
  %58 = atomicrmw volatile add ptr %20, i32 1 seq_cst, align 4
  %59 = load i32, ptr %21, align 8
  %60 = ashr i32 %58, %59
  %61 = icmp ugt i32 %60, 131071
  br i1 %61, label %62, label %64

62:                                               ; preds = %.lr.ph.i
  %63 = load ptr, ptr %23, align 8
  call fastcc void @taichi_assert_format(ptr noundef %63, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

64:                                               ; preds = %.lr.ph.i
  %65 = zext i32 %60 to i64
  %66 = lshr i64 %65, 9
  %67 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %66
  %68 = load atomic i64, ptr %67 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %68, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %64
  %69 = inttoptr i64 %68 to ptr
  %70 = and i64 %65, 511
  %71 = getelementptr inbounds ptr, ptr %69, i64 %70
  %72 = load atomic i64, ptr %71 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %72, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %64
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %73 = atomicrmw volatile xchg ptr %22, i32 1 seq_cst, align 4
  %74 = icmp eq i32 %73, 1
  br i1 %74, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %75 = load atomic i64, ptr %67 acquire, align 8
  %76 = inttoptr i64 %75 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %75, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %77, label %111

77:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %78 = load ptr, ptr %23, align 8
  %79 = getelementptr inbounds %struct.LLVMRuntime, ptr %78, i64 0, i32 1
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %78, i64 0, i32 28
  %81 = atomicrmw volatile add ptr %80, i64 4096 seq_cst, align 8
  %82 = getelementptr inbounds %struct.LLVMRuntime, ptr %78, i64 0, i32 1, i32 2
  %83 = load i64, ptr %82, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %83, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %104, label %84

84:                                               ; preds = %77
  %85 = getelementptr inbounds %struct.LLVMRuntime, ptr %78, i64 0, i32 26
  br label %86

86:                                               ; preds = %86, %84
  %87 = atomicrmw volatile xchg ptr %85, i32 1 seq_cst, align 4
  %88 = icmp eq i32 %87, 1
  br i1 %88, label %86, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %86
  %89 = load ptr, ptr %79, align 8
  %90 = ptrtoint ptr %89 to i64
  %91 = getelementptr inbounds %struct.LLVMRuntime, ptr %78, i64 0, i32 1, i32 1
  %92 = load ptr, ptr %91, align 8
  %93 = ptrtoint ptr %92 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %90
  %94 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %95 = or i64 %94, 4096
  %96 = add i64 %95, %90
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %96, %93
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %97

97:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %98 = add i64 %94, %90
  %99 = inttoptr i64 %98 to ptr
  %100 = getelementptr i8, ptr %89, i64 %94
  %101 = getelementptr inbounds i8, ptr %100, i64 4096
  store ptr %101, ptr %79, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %97, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %99, %97 ]
  %102 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %103 = atomicrmw volatile xchg ptr %85, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %78, i1 noundef zeroext %102, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

104:                                              ; preds = %77
  %105 = getelementptr inbounds %struct.LLVMRuntime, ptr %78, i64 0, i32 2
  %106 = load ptr, ptr %105, align 8
  %107 = getelementptr inbounds %struct.LLVMRuntime, ptr %78, i64 0, i32 6
  %108 = load ptr, ptr %107, align 8
  %109 = call noundef ptr %106(ptr noundef %108, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %104, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %109, %104 ]
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %110 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %110, ptr %67 release, align 8
  br label %111

111:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %76, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %112 = and i32 %60, 511
  %113 = zext i32 %112 to i64
  %114 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %113
  %115 = load atomic i64, ptr %114 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %115, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %116, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

116:                                              ; preds = %111
  %117 = load ptr, ptr %23, align 8
  %118 = getelementptr inbounds %struct.LLVMRuntime, ptr %117, i64 0, i32 1
  %119 = load i64, ptr %24, align 8
  %120 = load i64, ptr %25, align 8
  %121 = mul i64 %120, %119
  %122 = getelementptr inbounds %struct.LLVMRuntime, ptr %117, i64 0, i32 28
  %123 = atomicrmw volatile add ptr %122, i64 %121 seq_cst, align 8
  %124 = getelementptr inbounds %struct.LLVMRuntime, ptr %117, i64 0, i32 1, i32 2
  %125 = load i64, ptr %124, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %125, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %145, label %126

126:                                              ; preds = %116
  %127 = getelementptr inbounds %struct.LLVMRuntime, ptr %117, i64 0, i32 26
  br label %128

128:                                              ; preds = %128, %126
  %129 = atomicrmw volatile xchg ptr %127, i32 1 seq_cst, align 4
  %130 = icmp eq i32 %129, 1
  br i1 %130, label %128, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %128
  %131 = load ptr, ptr %118, align 8
  %132 = ptrtoint ptr %131 to i64
  %133 = getelementptr inbounds %struct.LLVMRuntime, ptr %117, i64 0, i32 1, i32 1
  %134 = load ptr, ptr %133, align 8
  %135 = ptrtoint ptr %134 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %132
  %136 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %137 = add i64 %136, %121
  %138 = add i64 %137, %132
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %138, %135
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %139

139:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %140 = add i64 %136, %132
  %141 = inttoptr i64 %140 to ptr
  %142 = getelementptr inbounds i8, ptr %131, i64 %137
  store ptr %142, ptr %118, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %139, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %141, %139 ]
  %143 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %144 = atomicrmw volatile xchg ptr %127, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %117, i1 noundef zeroext %143, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

145:                                              ; preds = %116
  %146 = getelementptr inbounds %struct.LLVMRuntime, ptr %117, i64 0, i32 2
  %147 = load ptr, ptr %146, align 8
  %148 = getelementptr inbounds %struct.LLVMRuntime, ptr %117, i64 0, i32 6
  %149 = load ptr, ptr %148, align 8
  %150 = call noundef ptr %147(ptr noundef %149, i64 noundef %121, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %145, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %150, %145 ]
  %151 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %151, ptr %114 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %111
  %152 = atomicrmw volatile xchg ptr %22, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %62
  %153 = load i32, ptr %21, align 8
  %154 = ashr i32 %58, %153
  %155 = sext i32 %154 to i64
  %156 = lshr i64 %155, 9
  %157 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %156
  %158 = load atomic i64, ptr %157 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %158, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %159

159:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %160 = inttoptr i64 %158 to ptr
  %161 = and i64 %155, 511
  %162 = getelementptr inbounds ptr, ptr %160, i64 %161
  %163 = load atomic i64, ptr %162 acquire, align 8
  %164 = inttoptr i64 %163 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %159, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %165 = phi ptr [ %164, %159 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %166 = load i64, ptr %25, align 8
  %167 = load i32, ptr %21, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %167
  %168 = xor i32 %notmask.i.i.i.i, -1
  %169 = and i32 %58, %168
  %170 = sext i32 %169 to i64
  %171 = mul i64 %166, %170
  %172 = getelementptr inbounds i8, ptr %165, i64 %171
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %172, ptr nonnull align 8 %2, i64 %166, i1 false)
  br label %.loopexit.i, !llvm.loop !8

.loopexit.i:                                      ; preds = %_ZN11ListManager6appendEPv.exit.i, %.lr.ph58.i
  %exitcond.not.i = icmp eq i32 %48, %53
  br i1 %exitcond.not.i, label %._crit_edge.i.loopexit, label %.lr.ph58.i, !llvm.loop !9

._crit_edge.i.loopexit:                           ; preds = %.loopexit.i
  br label %._crit_edge.i

._crit_edge.i:                                    ; preds = %._crit_edge.i.loopexit, %_ZN11ListManager3getI7ElementEERT_i.exit.i
  %173 = add nuw nsw i32 %.04359.i, 1
  %exitcond63.not.i = icmp eq i32 %173, %10
  br i1 %exitcond63.not.i, label %element_listgen_nonroot.exit.loopexit, label %26, !llvm.loop !10

element_listgen_nonroot.exit.loopexit:            ; preds = %._crit_edge.i
  br label %element_listgen_nonroot.exit

element_listgen_nonroot.exit:                     ; preds = %element_listgen_nonroot.exit.loopexit, %entry
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %2)
  ret void
}

; Function Attrs: nounwind
define void @selection_abandon_42_kernel_10_struct_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.cpu_block_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.RuntimeContext.924, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 45
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds %struct.ListManager, ptr %6, i64 0, i32 5
  %8 = load i32, ptr %7, align 8
  store ptr %context, ptr %0, align 8
  %9 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  store ptr @function_body.1, ptr %9, align 8
  %10 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  store ptr %6, ptr %10, align 8
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  store <2 x i32> <i32 32, i32 32>, ptr %11, align 8
  %12 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  store i64 1, ptr %12, align 8
  %13 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 12
  %14 = load ptr, ptr %13, align 8
  %15 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 11
  %16 = load ptr, ptr %15, align 8
  %17 = shl nsw i32 %8, 5
  call void %14(ptr noundef %16, i32 noundef %17, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_struct_for_block_helper) #1
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree norecurse nounwind
define internal void @function_body.1(ptr %0, ptr nocapture readnone %1, ptr nocapture readonly %2, i32 %3, i32 %4) #2 {
allocs:
  %5 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %6 = icmp sgt i32 %4, %3
  br i1 %6, label %loop_body.lr.ph, label %func_exit

loop_body.lr.ph:                                  ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.924, ptr %0, i64 0, i32 1
  %8 = sub i32 %4, %3
  %9 = xor i32 %3, -1
  %10 = add i32 %9, %4
  %xtraiter = and i32 %8, 7
  %lcmp.mod.not = icmp eq i32 %xtraiter, 0
  br i1 %lcmp.mod.not, label %loop_body.prol.loopexit, label %loop_body.prol.preheader

loop_body.prol.preheader:                         ; preds = %loop_body.lr.ph
  br label %loop_body.prol

loop_body.prol:                                   ; preds = %loop_body_tail.prol, %loop_body.prol.preheader
  %lsr.iv45 = phi i32 [ %xtraiter, %loop_body.prol.preheader ], [ %lsr.iv.next46, %loop_body_tail.prol ]
  %.044.prol = phi i32 [ %47, %loop_body_tail.prol ], [ %3, %loop_body.prol.preheader ]
  %11 = load i32, ptr %5, align 4
  %12 = load ptr, ptr %2, align 8
  %13 = getelementptr inbounds i8, ptr %12, i64 32
  %14 = sdiv i32 %.044.prol, 8
  %15 = sext i32 %14 to i64
  %16 = getelementptr inbounds i8, ptr %13, i64 %15
  %17 = load i8, ptr %16, align 1
  %18 = zext i8 %17 to i32
  %19 = and i32 %.044.prol, 7
  %20 = shl nuw nsw i32 1, %19
  %21 = and i32 %20, %18
  %.not43.prol = icmp eq i32 %21, 0
  br i1 %.not43.prol, label %loop_body_tail.prol, label %struct_for_body_body.prol

struct_for_body_body.prol:                        ; preds = %loop_body.prol
  %22 = load ptr, ptr %7, align 8
  %23 = getelementptr inbounds %struct.LLVMRuntime, ptr %22, i64 0, i32 16
  %24 = load ptr, ptr %23, align 8
  %25 = load i32, ptr %24, align 4
  %.not.prol = icmp eq i32 %25, 0
  br i1 %.not.prol, label %loop_body_tail.prol, label %true_block.prol

true_block.prol:                                  ; preds = %struct_for_body_body.prol
  %26 = getelementptr inbounds %struct.LLVMRuntime, ptr %22, i64 0, i32 7
  %27 = load ptr, ptr %26, align 8
  %28 = getelementptr inbounds ptr, ptr %27, i64 6
  %29 = load ptr, ptr %28, align 8
  %getch.i.prol = getelementptr %1, ptr %29, i64 0, i32 1
  %30 = shl i32 %11, 3
  %31 = and i32 %30, 1073741816
  %32 = zext i32 %31 to i64
  %33 = getelementptr i8, ptr %getch.i.prol, i64 %32
  %34 = getelementptr inbounds i8, ptr %33, i64 8
  %35 = load ptr, ptr %34, align 8
  %36 = icmp eq ptr %35, null
  br i1 %36, label %37, label %Pointer_lookup_element.exit.prol

37:                                               ; preds = %true_block.prol
  %38 = getelementptr inbounds %struct.LLVMRuntime, ptr %22, i64 0, i32 15
  %39 = load ptr, ptr %38, align 8
  %40 = getelementptr inbounds ptr, ptr %39, i64 44
  %41 = load ptr, ptr %40, align 8
  br label %Pointer_lookup_element.exit.prol

Pointer_lookup_element.exit.prol:                 ; preds = %37, %true_block.prol
  %.0.i.prol = phi ptr [ %41, %37 ], [ %35, %true_block.prol ]
  %42 = and i32 %.044.prol, 31
  %43 = getelementptr inbounds i8, ptr %.0.i.prol, i64 32
  %44 = shl nuw i32 1, %42
  %45 = xor i32 %44, -1
  %46 = atomicrmw volatile and ptr %43, i32 %45 seq_cst, align 4
  br label %loop_body_tail.prol

loop_body_tail.prol:                              ; preds = %Pointer_lookup_element.exit.prol, %struct_for_body_body.prol, %loop_body.prol
  %47 = add i32 %.044.prol, 1
  %lsr.iv.next46 = add nsw i32 %lsr.iv45, -1
  %prol.iter.cmp.not = icmp eq i32 %lsr.iv.next46, 0
  br i1 %prol.iter.cmp.not, label %loop_body.prol.loopexit.loopexit, label %loop_body.prol, !llvm.loop !13

loop_body.prol.loopexit.loopexit:                 ; preds = %loop_body_tail.prol
  br label %loop_body.prol.loopexit

loop_body.prol.loopexit:                          ; preds = %loop_body.prol.loopexit.loopexit, %loop_body.lr.ph
  %.044.unr = phi i32 [ %3, %loop_body.lr.ph ], [ %47, %loop_body.prol.loopexit.loopexit ]
  %48 = icmp ult i32 %10, 7
  br i1 %48, label %func_exit, label %loop_body.lr.ph.new

loop_body.lr.ph.new:                              ; preds = %loop_body.prol.loopexit
  %49 = and i32 %.044.unr, 7
  %50 = add i32 %.044.unr, 1
  %51 = and i32 %50, 7
  %52 = add i32 %.044.unr, 2
  %53 = and i32 %52, 7
  %54 = add i32 %.044.unr, 3
  %55 = and i32 %54, 7
  %56 = xor i32 %49, 4
  %57 = add i32 %.044.unr, 5
  %58 = and i32 %57, 7
  %59 = add i32 %.044.unr, 6
  %60 = and i32 %59, 7
  %61 = add i32 %.044.unr, 7
  %62 = and i32 %61, 7
  %63 = shl nuw nsw i32 1, %49
  %64 = shl nuw nsw i32 1, %51
  %65 = shl nuw nsw i32 1, %53
  %66 = shl nuw nsw i32 1, %55
  %67 = shl nuw nsw i32 1, %56
  %68 = shl nuw nsw i32 1, %58
  %69 = shl nuw nsw i32 1, %60
  %70 = shl nuw nsw i32 1, %62
  br label %loop_body

loop_body:                                        ; preds = %loop_body_tail.7, %loop_body.lr.ph.new
  %lsr.iv = phi i32 [ %lsr.iv.next, %loop_body_tail.7 ], [ %61, %loop_body.lr.ph.new ]
  %71 = add i32 %lsr.iv, -7
  %72 = load i32, ptr %5, align 4
  %73 = load ptr, ptr %2, align 8
  %74 = getelementptr inbounds i8, ptr %73, i64 32
  %75 = sdiv i32 %71, 8
  %76 = sext i32 %75 to i64
  %77 = getelementptr inbounds i8, ptr %74, i64 %76
  %78 = load i8, ptr %77, align 1
  %79 = zext i8 %78 to i32
  %80 = and i32 %63, %79
  %.not43 = icmp eq i32 %80, 0
  br i1 %.not43, label %loop_body_tail, label %struct_for_body_body

loop_body_tail:                                   ; preds = %Pointer_lookup_element.exit, %struct_for_body_body, %loop_body
  %81 = add i32 %lsr.iv, -6
  %82 = load i32, ptr %5, align 4
  %83 = load ptr, ptr %2, align 8
  %84 = getelementptr inbounds i8, ptr %83, i64 32
  %85 = add i32 %71, 1
  %86 = sdiv i32 %85, 8
  %87 = sext i32 %86 to i64
  %88 = getelementptr inbounds i8, ptr %84, i64 %87
  %89 = load i8, ptr %88, align 1
  %90 = zext i8 %89 to i32
  %91 = and i32 %64, %90
  %.not43.1 = icmp eq i32 %91, 0
  br i1 %.not43.1, label %loop_body_tail.1, label %struct_for_body_body.1

struct_for_body_body.1:                           ; preds = %loop_body_tail
  %92 = load ptr, ptr %7, align 8
  %93 = getelementptr inbounds %struct.LLVMRuntime, ptr %92, i64 0, i32 16
  %94 = load ptr, ptr %93, align 8
  %95 = load i32, ptr %94, align 4
  %.not.1 = icmp eq i32 %95, 0
  br i1 %.not.1, label %loop_body_tail.1, label %true_block.1

true_block.1:                                     ; preds = %struct_for_body_body.1
  %96 = getelementptr inbounds %struct.LLVMRuntime, ptr %92, i64 0, i32 7
  %97 = load ptr, ptr %96, align 8
  %98 = getelementptr inbounds ptr, ptr %97, i64 6
  %99 = load ptr, ptr %98, align 8
  %getch.i.1 = getelementptr %1, ptr %99, i64 0, i32 1
  %100 = shl i32 %82, 3
  %101 = and i32 %100, 1073741816
  %102 = zext i32 %101 to i64
  %103 = getelementptr i8, ptr %getch.i.1, i64 %102
  %104 = getelementptr inbounds i8, ptr %103, i64 8
  %105 = load ptr, ptr %104, align 8
  %106 = icmp eq ptr %105, null
  br i1 %106, label %107, label %Pointer_lookup_element.exit.1

107:                                              ; preds = %true_block.1
  %108 = getelementptr inbounds %struct.LLVMRuntime, ptr %92, i64 0, i32 15
  %109 = load ptr, ptr %108, align 8
  %110 = getelementptr inbounds ptr, ptr %109, i64 44
  %111 = load ptr, ptr %110, align 8
  br label %Pointer_lookup_element.exit.1

Pointer_lookup_element.exit.1:                    ; preds = %107, %true_block.1
  %.0.i.1 = phi ptr [ %111, %107 ], [ %105, %true_block.1 ]
  %112 = and i32 %81, 31
  %113 = getelementptr inbounds i8, ptr %.0.i.1, i64 32
  %114 = shl nuw i32 1, %112
  %115 = xor i32 %114, -1
  %116 = atomicrmw volatile and ptr %113, i32 %115 seq_cst, align 4
  br label %loop_body_tail.1

loop_body_tail.1:                                 ; preds = %Pointer_lookup_element.exit.1, %struct_for_body_body.1, %loop_body_tail
  %117 = add i32 %lsr.iv, -5
  %118 = load i32, ptr %5, align 4
  %119 = load ptr, ptr %2, align 8
  %120 = getelementptr inbounds i8, ptr %119, i64 32
  %121 = add i32 %85, 1
  %122 = sdiv i32 %121, 8
  %123 = sext i32 %122 to i64
  %124 = getelementptr inbounds i8, ptr %120, i64 %123
  %125 = load i8, ptr %124, align 1
  %126 = zext i8 %125 to i32
  %127 = and i32 %65, %126
  %.not43.2 = icmp eq i32 %127, 0
  br i1 %.not43.2, label %loop_body_tail.2, label %struct_for_body_body.2

struct_for_body_body.2:                           ; preds = %loop_body_tail.1
  %128 = load ptr, ptr %7, align 8
  %129 = getelementptr inbounds %struct.LLVMRuntime, ptr %128, i64 0, i32 16
  %130 = load ptr, ptr %129, align 8
  %131 = load i32, ptr %130, align 4
  %.not.2 = icmp eq i32 %131, 0
  br i1 %.not.2, label %loop_body_tail.2, label %true_block.2

true_block.2:                                     ; preds = %struct_for_body_body.2
  %132 = getelementptr inbounds %struct.LLVMRuntime, ptr %128, i64 0, i32 7
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr inbounds ptr, ptr %133, i64 6
  %135 = load ptr, ptr %134, align 8
  %getch.i.2 = getelementptr %1, ptr %135, i64 0, i32 1
  %136 = shl i32 %118, 3
  %137 = and i32 %136, 1073741816
  %138 = zext i32 %137 to i64
  %139 = getelementptr i8, ptr %getch.i.2, i64 %138
  %140 = getelementptr inbounds i8, ptr %139, i64 8
  %141 = load ptr, ptr %140, align 8
  %142 = icmp eq ptr %141, null
  br i1 %142, label %143, label %Pointer_lookup_element.exit.2

143:                                              ; preds = %true_block.2
  %144 = getelementptr inbounds %struct.LLVMRuntime, ptr %128, i64 0, i32 15
  %145 = load ptr, ptr %144, align 8
  %146 = getelementptr inbounds ptr, ptr %145, i64 44
  %147 = load ptr, ptr %146, align 8
  br label %Pointer_lookup_element.exit.2

Pointer_lookup_element.exit.2:                    ; preds = %143, %true_block.2
  %.0.i.2 = phi ptr [ %147, %143 ], [ %141, %true_block.2 ]
  %148 = and i32 %117, 31
  %149 = getelementptr inbounds i8, ptr %.0.i.2, i64 32
  %150 = shl nuw i32 1, %148
  %151 = xor i32 %150, -1
  %152 = atomicrmw volatile and ptr %149, i32 %151 seq_cst, align 4
  br label %loop_body_tail.2

loop_body_tail.2:                                 ; preds = %Pointer_lookup_element.exit.2, %struct_for_body_body.2, %loop_body_tail.1
  %153 = add i32 %lsr.iv, -4
  %154 = load i32, ptr %5, align 4
  %155 = load ptr, ptr %2, align 8
  %156 = getelementptr inbounds i8, ptr %155, i64 32
  %157 = add i32 %121, 1
  %158 = sdiv i32 %157, 8
  %159 = sext i32 %158 to i64
  %160 = getelementptr inbounds i8, ptr %156, i64 %159
  %161 = load i8, ptr %160, align 1
  %162 = zext i8 %161 to i32
  %163 = and i32 %66, %162
  %.not43.3 = icmp eq i32 %163, 0
  br i1 %.not43.3, label %loop_body_tail.3, label %struct_for_body_body.3

struct_for_body_body.3:                           ; preds = %loop_body_tail.2
  %164 = load ptr, ptr %7, align 8
  %165 = getelementptr inbounds %struct.LLVMRuntime, ptr %164, i64 0, i32 16
  %166 = load ptr, ptr %165, align 8
  %167 = load i32, ptr %166, align 4
  %.not.3 = icmp eq i32 %167, 0
  br i1 %.not.3, label %loop_body_tail.3, label %true_block.3

true_block.3:                                     ; preds = %struct_for_body_body.3
  %168 = getelementptr inbounds %struct.LLVMRuntime, ptr %164, i64 0, i32 7
  %169 = load ptr, ptr %168, align 8
  %170 = getelementptr inbounds ptr, ptr %169, i64 6
  %171 = load ptr, ptr %170, align 8
  %getch.i.3 = getelementptr %1, ptr %171, i64 0, i32 1
  %172 = shl i32 %154, 3
  %173 = and i32 %172, 1073741816
  %174 = zext i32 %173 to i64
  %175 = getelementptr i8, ptr %getch.i.3, i64 %174
  %176 = getelementptr inbounds i8, ptr %175, i64 8
  %177 = load ptr, ptr %176, align 8
  %178 = icmp eq ptr %177, null
  br i1 %178, label %179, label %Pointer_lookup_element.exit.3

179:                                              ; preds = %true_block.3
  %180 = getelementptr inbounds %struct.LLVMRuntime, ptr %164, i64 0, i32 15
  %181 = load ptr, ptr %180, align 8
  %182 = getelementptr inbounds ptr, ptr %181, i64 44
  %183 = load ptr, ptr %182, align 8
  br label %Pointer_lookup_element.exit.3

Pointer_lookup_element.exit.3:                    ; preds = %179, %true_block.3
  %.0.i.3 = phi ptr [ %183, %179 ], [ %177, %true_block.3 ]
  %184 = and i32 %153, 31
  %185 = getelementptr inbounds i8, ptr %.0.i.3, i64 32
  %186 = shl nuw i32 1, %184
  %187 = xor i32 %186, -1
  %188 = atomicrmw volatile and ptr %185, i32 %187 seq_cst, align 4
  br label %loop_body_tail.3

loop_body_tail.3:                                 ; preds = %Pointer_lookup_element.exit.3, %struct_for_body_body.3, %loop_body_tail.2
  %189 = add i32 %lsr.iv, -3
  %190 = load i32, ptr %5, align 4
  %191 = load ptr, ptr %2, align 8
  %192 = getelementptr inbounds i8, ptr %191, i64 32
  %193 = add i32 %157, 1
  %194 = sdiv i32 %193, 8
  %195 = sext i32 %194 to i64
  %196 = getelementptr inbounds i8, ptr %192, i64 %195
  %197 = load i8, ptr %196, align 1
  %198 = zext i8 %197 to i32
  %199 = and i32 %67, %198
  %.not43.4 = icmp eq i32 %199, 0
  br i1 %.not43.4, label %loop_body_tail.4, label %struct_for_body_body.4

struct_for_body_body.4:                           ; preds = %loop_body_tail.3
  %200 = load ptr, ptr %7, align 8
  %201 = getelementptr inbounds %struct.LLVMRuntime, ptr %200, i64 0, i32 16
  %202 = load ptr, ptr %201, align 8
  %203 = load i32, ptr %202, align 4
  %.not.4 = icmp eq i32 %203, 0
  br i1 %.not.4, label %loop_body_tail.4, label %true_block.4

true_block.4:                                     ; preds = %struct_for_body_body.4
  %204 = getelementptr inbounds %struct.LLVMRuntime, ptr %200, i64 0, i32 7
  %205 = load ptr, ptr %204, align 8
  %206 = getelementptr inbounds ptr, ptr %205, i64 6
  %207 = load ptr, ptr %206, align 8
  %getch.i.4 = getelementptr %1, ptr %207, i64 0, i32 1
  %208 = shl i32 %190, 3
  %209 = and i32 %208, 1073741816
  %210 = zext i32 %209 to i64
  %211 = getelementptr i8, ptr %getch.i.4, i64 %210
  %212 = getelementptr inbounds i8, ptr %211, i64 8
  %213 = load ptr, ptr %212, align 8
  %214 = icmp eq ptr %213, null
  br i1 %214, label %215, label %Pointer_lookup_element.exit.4

215:                                              ; preds = %true_block.4
  %216 = getelementptr inbounds %struct.LLVMRuntime, ptr %200, i64 0, i32 15
  %217 = load ptr, ptr %216, align 8
  %218 = getelementptr inbounds ptr, ptr %217, i64 44
  %219 = load ptr, ptr %218, align 8
  br label %Pointer_lookup_element.exit.4

Pointer_lookup_element.exit.4:                    ; preds = %215, %true_block.4
  %.0.i.4 = phi ptr [ %219, %215 ], [ %213, %true_block.4 ]
  %220 = and i32 %189, 31
  %221 = getelementptr inbounds i8, ptr %.0.i.4, i64 32
  %222 = shl nuw i32 1, %220
  %223 = xor i32 %222, -1
  %224 = atomicrmw volatile and ptr %221, i32 %223 seq_cst, align 4
  br label %loop_body_tail.4

loop_body_tail.4:                                 ; preds = %Pointer_lookup_element.exit.4, %struct_for_body_body.4, %loop_body_tail.3
  %225 = add i32 %lsr.iv, -2
  %226 = load i32, ptr %5, align 4
  %227 = load ptr, ptr %2, align 8
  %228 = getelementptr inbounds i8, ptr %227, i64 32
  %229 = add i32 %193, 1
  %230 = sdiv i32 %229, 8
  %231 = sext i32 %230 to i64
  %232 = getelementptr inbounds i8, ptr %228, i64 %231
  %233 = load i8, ptr %232, align 1
  %234 = zext i8 %233 to i32
  %235 = and i32 %68, %234
  %.not43.5 = icmp eq i32 %235, 0
  br i1 %.not43.5, label %loop_body_tail.5, label %struct_for_body_body.5

struct_for_body_body.5:                           ; preds = %loop_body_tail.4
  %236 = load ptr, ptr %7, align 8
  %237 = getelementptr inbounds %struct.LLVMRuntime, ptr %236, i64 0, i32 16
  %238 = load ptr, ptr %237, align 8
  %239 = load i32, ptr %238, align 4
  %.not.5 = icmp eq i32 %239, 0
  br i1 %.not.5, label %loop_body_tail.5, label %true_block.5

true_block.5:                                     ; preds = %struct_for_body_body.5
  %240 = getelementptr inbounds %struct.LLVMRuntime, ptr %236, i64 0, i32 7
  %241 = load ptr, ptr %240, align 8
  %242 = getelementptr inbounds ptr, ptr %241, i64 6
  %243 = load ptr, ptr %242, align 8
  %getch.i.5 = getelementptr %1, ptr %243, i64 0, i32 1
  %244 = shl i32 %226, 3
  %245 = and i32 %244, 1073741816
  %246 = zext i32 %245 to i64
  %247 = getelementptr i8, ptr %getch.i.5, i64 %246
  %248 = getelementptr inbounds i8, ptr %247, i64 8
  %249 = load ptr, ptr %248, align 8
  %250 = icmp eq ptr %249, null
  br i1 %250, label %251, label %Pointer_lookup_element.exit.5

251:                                              ; preds = %true_block.5
  %252 = getelementptr inbounds %struct.LLVMRuntime, ptr %236, i64 0, i32 15
  %253 = load ptr, ptr %252, align 8
  %254 = getelementptr inbounds ptr, ptr %253, i64 44
  %255 = load ptr, ptr %254, align 8
  br label %Pointer_lookup_element.exit.5

Pointer_lookup_element.exit.5:                    ; preds = %251, %true_block.5
  %.0.i.5 = phi ptr [ %255, %251 ], [ %249, %true_block.5 ]
  %256 = and i32 %225, 31
  %257 = getelementptr inbounds i8, ptr %.0.i.5, i64 32
  %258 = shl nuw i32 1, %256
  %259 = xor i32 %258, -1
  %260 = atomicrmw volatile and ptr %257, i32 %259 seq_cst, align 4
  br label %loop_body_tail.5

loop_body_tail.5:                                 ; preds = %Pointer_lookup_element.exit.5, %struct_for_body_body.5, %loop_body_tail.4
  %261 = add i32 %lsr.iv, -1
  %262 = load i32, ptr %5, align 4
  %263 = load ptr, ptr %2, align 8
  %264 = getelementptr inbounds i8, ptr %263, i64 32
  %265 = add i32 %229, 1
  %266 = sdiv i32 %265, 8
  %267 = sext i32 %266 to i64
  %268 = getelementptr inbounds i8, ptr %264, i64 %267
  %269 = load i8, ptr %268, align 1
  %270 = zext i8 %269 to i32
  %271 = and i32 %69, %270
  %.not43.6 = icmp eq i32 %271, 0
  br i1 %.not43.6, label %loop_body_tail.6, label %struct_for_body_body.6

struct_for_body_body.6:                           ; preds = %loop_body_tail.5
  %272 = load ptr, ptr %7, align 8
  %273 = getelementptr inbounds %struct.LLVMRuntime, ptr %272, i64 0, i32 16
  %274 = load ptr, ptr %273, align 8
  %275 = load i32, ptr %274, align 4
  %.not.6 = icmp eq i32 %275, 0
  br i1 %.not.6, label %loop_body_tail.6, label %true_block.6

true_block.6:                                     ; preds = %struct_for_body_body.6
  %276 = getelementptr inbounds %struct.LLVMRuntime, ptr %272, i64 0, i32 7
  %277 = load ptr, ptr %276, align 8
  %278 = getelementptr inbounds ptr, ptr %277, i64 6
  %279 = load ptr, ptr %278, align 8
  %getch.i.6 = getelementptr %1, ptr %279, i64 0, i32 1
  %280 = shl i32 %262, 3
  %281 = and i32 %280, 1073741816
  %282 = zext i32 %281 to i64
  %283 = getelementptr i8, ptr %getch.i.6, i64 %282
  %284 = getelementptr inbounds i8, ptr %283, i64 8
  %285 = load ptr, ptr %284, align 8
  %286 = icmp eq ptr %285, null
  br i1 %286, label %287, label %Pointer_lookup_element.exit.6

287:                                              ; preds = %true_block.6
  %288 = getelementptr inbounds %struct.LLVMRuntime, ptr %272, i64 0, i32 15
  %289 = load ptr, ptr %288, align 8
  %290 = getelementptr inbounds ptr, ptr %289, i64 44
  %291 = load ptr, ptr %290, align 8
  br label %Pointer_lookup_element.exit.6

Pointer_lookup_element.exit.6:                    ; preds = %287, %true_block.6
  %.0.i.6 = phi ptr [ %291, %287 ], [ %285, %true_block.6 ]
  %292 = and i32 %261, 31
  %293 = getelementptr inbounds i8, ptr %.0.i.6, i64 32
  %294 = shl nuw i32 1, %292
  %295 = xor i32 %294, -1
  %296 = atomicrmw volatile and ptr %293, i32 %295 seq_cst, align 4
  br label %loop_body_tail.6

loop_body_tail.6:                                 ; preds = %Pointer_lookup_element.exit.6, %struct_for_body_body.6, %loop_body_tail.5
  %297 = load i32, ptr %5, align 4
  %298 = load ptr, ptr %2, align 8
  %299 = getelementptr inbounds i8, ptr %298, i64 32
  %300 = add i32 %265, 1
  %301 = sdiv i32 %300, 8
  %302 = sext i32 %301 to i64
  %303 = getelementptr inbounds i8, ptr %299, i64 %302
  %304 = load i8, ptr %303, align 1
  %305 = zext i8 %304 to i32
  %306 = and i32 %70, %305
  %.not43.7 = icmp eq i32 %306, 0
  br i1 %.not43.7, label %loop_body_tail.7, label %struct_for_body_body.7

struct_for_body_body.7:                           ; preds = %loop_body_tail.6
  %307 = load ptr, ptr %7, align 8
  %308 = getelementptr inbounds %struct.LLVMRuntime, ptr %307, i64 0, i32 16
  %309 = load ptr, ptr %308, align 8
  %310 = load i32, ptr %309, align 4
  %.not.7 = icmp eq i32 %310, 0
  br i1 %.not.7, label %loop_body_tail.7, label %true_block.7

true_block.7:                                     ; preds = %struct_for_body_body.7
  %311 = getelementptr inbounds %struct.LLVMRuntime, ptr %307, i64 0, i32 7
  %312 = load ptr, ptr %311, align 8
  %313 = getelementptr inbounds ptr, ptr %312, i64 6
  %314 = load ptr, ptr %313, align 8
  %getch.i.7 = getelementptr %1, ptr %314, i64 0, i32 1
  %315 = shl i32 %297, 3
  %316 = and i32 %315, 1073741816
  %317 = zext i32 %316 to i64
  %318 = getelementptr i8, ptr %getch.i.7, i64 %317
  %319 = getelementptr inbounds i8, ptr %318, i64 8
  %320 = load ptr, ptr %319, align 8
  %321 = icmp eq ptr %320, null
  br i1 %321, label %322, label %Pointer_lookup_element.exit.7

322:                                              ; preds = %true_block.7
  %323 = getelementptr inbounds %struct.LLVMRuntime, ptr %307, i64 0, i32 15
  %324 = load ptr, ptr %323, align 8
  %325 = getelementptr inbounds ptr, ptr %324, i64 44
  %326 = load ptr, ptr %325, align 8
  br label %Pointer_lookup_element.exit.7

Pointer_lookup_element.exit.7:                    ; preds = %322, %true_block.7
  %.0.i.7 = phi ptr [ %326, %322 ], [ %320, %true_block.7 ]
  %327 = and i32 %lsr.iv, 31
  %328 = getelementptr inbounds i8, ptr %.0.i.7, i64 32
  %329 = shl nuw i32 1, %327
  %330 = xor i32 %329, -1
  %331 = atomicrmw volatile and ptr %328, i32 %330 seq_cst, align 4
  br label %loop_body_tail.7

loop_body_tail.7:                                 ; preds = %Pointer_lookup_element.exit.7, %struct_for_body_body.7, %loop_body_tail.6
  %lsr.iv.next = add i32 %lsr.iv, 8
  %332 = add i32 %300, 1
  %exitcond.not.7 = icmp eq i32 %332, %4
  br i1 %exitcond.not.7, label %func_exit.loopexit, label %loop_body

func_exit.loopexit:                               ; preds = %loop_body_tail.7
  br label %func_exit

func_exit:                                        ; preds = %func_exit.loopexit, %loop_body.prol.loopexit, %allocs
  ret void

struct_for_body_body:                             ; preds = %loop_body
  %333 = load ptr, ptr %7, align 8
  %334 = getelementptr inbounds %struct.LLVMRuntime, ptr %333, i64 0, i32 16
  %335 = load ptr, ptr %334, align 8
  %336 = load i32, ptr %335, align 4
  %.not = icmp eq i32 %336, 0
  br i1 %.not, label %loop_body_tail, label %true_block

true_block:                                       ; preds = %struct_for_body_body
  %337 = getelementptr inbounds %struct.LLVMRuntime, ptr %333, i64 0, i32 7
  %338 = load ptr, ptr %337, align 8
  %339 = getelementptr inbounds ptr, ptr %338, i64 6
  %340 = load ptr, ptr %339, align 8
  %getch.i = getelementptr %1, ptr %340, i64 0, i32 1
  %341 = shl i32 %72, 3
  %342 = and i32 %341, 1073741816
  %343 = zext i32 %342 to i64
  %344 = getelementptr i8, ptr %getch.i, i64 %343
  %345 = getelementptr inbounds i8, ptr %344, i64 8
  %346 = load ptr, ptr %345, align 8
  %347 = icmp eq ptr %346, null
  br i1 %347, label %348, label %Pointer_lookup_element.exit

348:                                              ; preds = %true_block
  %349 = getelementptr inbounds %struct.LLVMRuntime, ptr %333, i64 0, i32 15
  %350 = load ptr, ptr %349, align 8
  %351 = getelementptr inbounds ptr, ptr %350, i64 44
  %352 = load ptr, ptr %351, align 8
  br label %Pointer_lookup_element.exit

Pointer_lookup_element.exit:                      ; preds = %348, %true_block
  %.0.i = phi ptr [ %352, %348 ], [ %346, %true_block ]
  %353 = and i32 %71, 31
  %354 = getelementptr inbounds i8, ptr %.0.i, i64 32
  %355 = shl nuw i32 1, %353
  %356 = xor i32 %355, -1
  %357 = atomicrmw volatile and ptr %354, i32 %356 seq_cst, align 4
  br label %loop_body_tail
}

; Function Attrs: argmemonly mustprogress nofree norecurse nosync nounwind willreturn
define internal fastcc void @S41_refine_coordinates(ptr nocapture readonly %0, ptr nocapture writeonly %1, i32 %2) unnamed_addr #3 {
entry:
  %3 = load i32, ptr %0, align 4
  store i32 %3, ptr %1, align 4
  %4 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 1
  %5 = load i32, ptr %4, align 4
  %6 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 1
  store i32 %5, ptr %6, align 4
  %7 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 2
  %8 = load i32, ptr %7, align 4
  %9 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 2
  store i32 %8, ptr %9, align 4
  %10 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 3
  %11 = load i32, ptr %10, align 4
  %12 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 3
  store i32 %11, ptr %12, align 4
  %13 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 4
  %14 = load i32, ptr %13, align 4
  %15 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 4
  store i32 %14, ptr %15, align 4
  %16 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 5
  %17 = load i32, ptr %16, align 4
  %18 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 5
  store i32 %17, ptr %18, align 4
  %19 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 6
  %20 = load i32, ptr %19, align 4
  %21 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 6
  store i32 %20, ptr %21, align 4
  %22 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 7
  %23 = load i32, ptr %22, align 4
  %24 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 7
  store i32 %23, ptr %24, align 4
  %25 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 8
  %26 = load i32, ptr %25, align 4
  %27 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 8
  store i32 %26, ptr %27, align 4
  %28 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 9
  %29 = load i32, ptr %28, align 4
  %30 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 9
  store i32 %29, ptr %30, align 4
  %31 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 10
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 10
  store i32 %32, ptr %33, align 4
  %34 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 11
  %35 = load i32, ptr %34, align 4
  %36 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 11
  store i32 %35, ptr %36, align 4
  ret void
}

; Function Attrs: argmemonly mustprogress nofree norecurse nosync nounwind willreturn
define internal fastcc void @S44_refine_coordinates(ptr nocapture readonly %0, ptr nocapture writeonly %1, i32 %2) unnamed_addr #3 {
entry:
  %3 = load i32, ptr %0, align 4
  store i32 %3, ptr %1, align 4
  %4 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 1
  %5 = load i32, ptr %4, align 4
  %6 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 1
  store i32 %5, ptr %6, align 4
  %7 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 2
  %8 = load i32, ptr %7, align 4
  %9 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 2
  store i32 %8, ptr %9, align 4
  %10 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 3
  %11 = load i32, ptr %10, align 4
  %12 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 3
  store i32 %11, ptr %12, align 4
  %13 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 4
  %14 = load i32, ptr %13, align 4
  %15 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 4
  store i32 %14, ptr %15, align 4
  %16 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 5
  %17 = load i32, ptr %16, align 4
  %18 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 5
  store i32 %17, ptr %18, align 4
  %19 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 6
  %20 = load i32, ptr %19, align 4
  %21 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 6
  store i32 %20, ptr %21, align 4
  %22 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 7
  %23 = load i32, ptr %22, align 4
  %24 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 7
  store i32 %23, ptr %24, align 4
  %25 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 8
  %26 = load i32, ptr %25, align 4
  %27 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 8
  store i32 %26, ptr %27, align 4
  %28 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 9
  %29 = load i32, ptr %28, align 4
  %30 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 9
  store i32 %29, ptr %30, align 4
  %31 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 10
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 10
  store i32 %32, ptr %33, align 4
  %34 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 11
  %35 = load i32, ptr %34, align 4
  %36 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 11
  store i32 %35, ptr %36, align 4
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #4

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn writeonly
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #5

; Function Attrs: noinline nounwind optnone uwtable
define internal fastcc void @taichi_assert_format(ptr noundef %0, i1 noundef zeroext %1, ptr noundef %2) unnamed_addr #6 {
  %4 = alloca ptr, align 8
  %5 = alloca i8, align 1
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca ptr, align 8
  %9 = alloca %class.anon, align 8
  store ptr %0, ptr %4, align 8
  %10 = zext i1 %1 to i8
  store i8 %10, ptr %5, align 1
  store ptr %2, ptr %6, align 8
  store i32 0, ptr %7, align 4
  store ptr null, ptr %8, align 8
  %11 = load i8, ptr %5, align 1
  %12 = trunc i8 %11 to i1
  %13 = zext i1 %12 to i32
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %15, label %16

15:                                               ; preds = %3
  br label %69

16:                                               ; preds = %3
  %17 = load ptr, ptr %4, align 8
  %18 = getelementptr inbounds %struct.LLVMRuntime, ptr %17, i32 0, i32 24
  %19 = load i64, ptr %18, align 8
  %20 = icmp ne i64 %19, 0
  br i1 %20, label %69, label %21

21:                                               ; preds = %16
  %22 = load ptr, ptr %4, align 8
  %23 = getelementptr inbounds %struct.LLVMRuntime, ptr %22, i32 0, i32 23
  %24 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 0
  store ptr %4, ptr %24, align 8
  %25 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 1
  store ptr %6, ptr %25, align 8
  %26 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 2
  store ptr %7, ptr %26, align 8
  %27 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 3
  store ptr %8, ptr %27, align 8
  br label %28

28:                                               ; preds = %28, %21
  %29 = atomicrmw volatile xchg ptr %23, i32 1 seq_cst, align 4
  %30 = icmp eq i32 %29, 1
  br i1 %30, label %28, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i:                        ; preds = %28
  %31 = load ptr, ptr %9, align 8
  %32 = load ptr, ptr %31, align 8
  %33 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 24
  %34 = load i64, ptr %33, align 8
  %.not.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i, label %35, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

35:                                               ; preds = %mutex_lock_i32.exit.i.i.i
  store i64 1, ptr %33, align 8
  %36 = load ptr, ptr %9, align 8
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr inbounds %struct.LLVMRuntime, ptr %37, i64 0, i32 21
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %38, i8 0, i64 2048, i1 false)
  %39 = load ptr, ptr %9, align 8
  %40 = load ptr, ptr %39, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 21
  %42 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 1
  %43 = load ptr, ptr %42, align 8
  %44 = load ptr, ptr %43, align 8
  %45 = load i8, ptr %44, align 1
  %.not5.i.i.i.i.i = icmp eq i8 %45, 0
  br i1 %.not5.i.i.i.i.i, label %taichi_strlen.exit.thread.i.i.i.i, label %.lr.ph.i.i.i.i.i.preheader

.lr.ph.i.i.i.i.i.preheader:                       ; preds = %35
  br label %.lr.ph.i.i.i.i.i

.lr.ph.i.i.i.i.i:                                 ; preds = %.lr.ph.i.i.i.i.i, %.lr.ph.i.i.i.i.i.preheader
  %.07.i.i.i.i.i = phi ptr [ %47, %.lr.ph.i.i.i.i.i ], [ %44, %.lr.ph.i.i.i.i.i.preheader ]
  %.046.i.i.i.i.i = phi i64 [ %46, %.lr.ph.i.i.i.i.i ], [ 0, %.lr.ph.i.i.i.i.i.preheader ]
  %46 = add i64 %.046.i.i.i.i.i, 1
  %47 = getelementptr inbounds i8, ptr %.07.i.i.i.i.i, i64 1
  %48 = load i8, ptr %47, align 1
  %.not.i.i.i.i.i = icmp eq i8 %48, 0
  br i1 %.not.i.i.i.i.i, label %taichi_strlen.exit.i.i.i.i, label %.lr.ph.i.i.i.i.i, !llvm.loop !14

taichi_strlen.exit.i.i.i.i:                       ; preds = %.lr.ph.i.i.i.i.i
  %.lcssa = phi i64 [ %46, %.lr.ph.i.i.i.i.i ]
  %49 = call i64 @llvm.umin.i64(i64 %.lcssa, i64 2047)
  br label %taichi_strlen.exit.thread.i.i.i.i

taichi_strlen.exit.thread.i.i.i.i:                ; preds = %taichi_strlen.exit.i.i.i.i, %35
  %50 = phi i64 [ 0, %35 ], [ %49, %taichi_strlen.exit.i.i.i.i ]
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %41, ptr nonnull align 1 %44, i64 %50, i1 false)
  %51 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 2
  %52 = load ptr, ptr %51, align 8
  %53 = load i32, ptr %52, align 4
  %54 = icmp sgt i32 %53, 0
  br i1 %54, label %.lr.ph.i.i.i.i, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

.lr.ph.i.i.i.i:                                   ; preds = %taichi_strlen.exit.thread.i.i.i.i
  %55 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 3
  br label %56

56:                                               ; preds = %56, %.lr.ph.i.i.i.i
  %indvars.iv.i.i.i.i = phi i64 [ 0, %.lr.ph.i.i.i.i ], [ %indvars.iv.next.i.i.i.i, %56 ]
  %57 = load ptr, ptr %55, align 8
  %58 = load ptr, ptr %57, align 8
  %59 = getelementptr inbounds i64, ptr %58, i64 %indvars.iv.i.i.i.i
  %60 = load i64, ptr %59, align 8
  %61 = load ptr, ptr %9, align 8
  %62 = load ptr, ptr %61, align 8
  %63 = getelementptr inbounds %struct.LLVMRuntime, ptr %62, i64 0, i32 22, i64 %indvars.iv.i.i.i.i
  store i64 %60, ptr %63, align 8
  %indvars.iv.next.i.i.i.i = add nuw nsw i64 %indvars.iv.i.i.i.i, 1
  %64 = load ptr, ptr %51, align 8
  %65 = load i32, ptr %64, align 4
  %66 = sext i32 %65 to i64
  %67 = icmp slt i64 %indvars.iv.next.i.i.i.i, %66
  br i1 %67, label %56, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", !llvm.loop !15

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit": ; preds = %56
  br label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit": ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", %taichi_strlen.exit.thread.i.i.i.i, %mutex_lock_i32.exit.i.i.i
  %68 = atomicrmw volatile xchg ptr %23, i32 0 seq_cst, align 4
  br label %69

69:                                               ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit", %16, %15
  ret void
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_struct_for_block_helper(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #7 {
_ZN11ListManager3getI7ElementEERT_i.exit:
  %3 = alloca %struct.RuntimeContext.924, align 8
  %4 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 4
  %5 = load i32, ptr %4, align 4
  %6 = sdiv i32 %2, %5
  %7 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  %8 = load i32, ptr %7, align 8
  %9 = sdiv i32 %8, %5
  %10 = srem i32 %2, %5
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  %12 = load ptr, ptr %11, align 8
  %13 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %14 = load i32, ptr %13, align 8
  %15 = ashr i32 %6, %14
  %16 = sext i32 %15 to i64
  %17 = lshr i64 %16, 9
  %18 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %17
  %19 = load atomic i64, ptr %18 acquire, align 8
  %.not.i.i.i = icmp ne i64 %19, 0
  tail call void @llvm.assume(i1 %.not.i.i.i)
  %20 = inttoptr i64 %19 to ptr
  %21 = and i64 %16, 511
  %22 = getelementptr inbounds ptr, ptr %20, i64 %21
  %23 = load atomic i64, ptr %22 acquire, align 8
  %24 = inttoptr i64 %23 to ptr
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %26 = load i64, ptr %25, align 8
  %27 = load i32, ptr %13, align 8
  %notmask.i.i = shl nsw i32 -1, %27
  %28 = xor i32 %notmask.i.i, -1
  %29 = and i32 %6, %28
  %30 = sext i32 %29 to i64
  %31 = mul i64 %26, %30
  %32 = getelementptr inbounds i8, ptr %24, i64 %31
  %33 = getelementptr inbounds %0, ptr %32, i64 0, i32 1
  %34 = load i32, ptr %33, align 8
  %35 = mul nsw i32 %10, %9
  %36 = add nsw i32 %34, %35
  %37 = add nsw i32 %10, 1
  %38 = mul nsw i32 %37, %9
  %39 = add nsw i32 %34, %38
  %40 = getelementptr inbounds %0, ptr %32, i64 0, i32 1, i64 1
  %41 = load i32, ptr %40, align 4
  %42 = tail call i32 @llvm.smin.i32(i32 %41, i32 %39)
  %43 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  %44 = load i64, ptr %43, align 8
  %45 = alloca i8, i64 %44, align 8
  %46 = load ptr, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %3, ptr noundef nonnull align 8 dereferenceable(32) %46, i64 32, i1 false)
  %47 = getelementptr inbounds %struct.RuntimeContext.924, ptr %3, i64 0, i32 2
  store i32 %1, ptr %47, align 8
  %48 = icmp slt i32 %36, %42
  br i1 %48, label %49, label %75

49:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit
  %50 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = load ptr, ptr %11, align 8
  %53 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 3
  %54 = load i32, ptr %53, align 8
  %55 = ashr i32 %6, %54
  %56 = sext i32 %55 to i64
  %57 = lshr i64 %56, 9
  %58 = getelementptr inbounds [256 x ptr], ptr %52, i64 0, i64 %57
  %59 = load atomic i64, ptr %58 acquire, align 8
  %.not.i.i.i24 = icmp eq i64 %59, 0
  br i1 %.not.i.i.i24, label %_ZN11ListManager3getI7ElementEERT_i.exit26, label %60

60:                                               ; preds = %49
  %61 = inttoptr i64 %59 to ptr
  %62 = and i64 %56, 511
  %63 = getelementptr inbounds ptr, ptr %61, i64 %62
  %64 = load atomic i64, ptr %63 acquire, align 8
  %65 = inttoptr i64 %64 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit26

_ZN11ListManager3getI7ElementEERT_i.exit26:       ; preds = %60, %49
  %66 = phi ptr [ %65, %60 ], [ null, %49 ]
  %67 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 1
  %68 = load i64, ptr %67, align 8
  %69 = load i32, ptr %53, align 8
  %notmask.i.i25 = shl nsw i32 -1, %69
  %70 = xor i32 %notmask.i.i25, -1
  %71 = and i32 %6, %70
  %72 = sext i32 %71 to i64
  %73 = mul i64 %68, %72
  %74 = getelementptr inbounds i8, ptr %66, i64 %73
  call void %51(ptr noundef nonnull %3, ptr noundef nonnull %45, ptr noundef nonnull %74, i32 noundef %36, i32 noundef %42) #1
  br label %75

75:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit26, %_ZN11ListManager3getI7ElementEERT_i.exit
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i64 @llvm.umin.i64(i64, i64) #8

; Function Attrs: inaccessiblememonly nocallback nofree nosync nounwind willreturn
declare void @llvm.assume(i1 noundef) #9

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #8

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #10

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #10

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { nofree norecurse nounwind }
attributes #3 = { argmemonly mustprogress nofree norecurse nosync nounwind willreturn }
attributes #4 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #5 = { argmemonly mustprogress nocallback nofree nounwind willreturn writeonly }
attributes #6 = { noinline nounwind optnone uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #9 = { inaccessiblememonly nocallback nofree nosync nounwind willreturn }
attributes #10 = { argmemonly nocallback nofree nosync nounwind willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !12}
!12 = !{!"llvm.loop.unroll.disable"}
!13 = distinct !{!13, !12}
!14 = distinct !{!14, !7}
!15 = distinct !{!15, !7}
