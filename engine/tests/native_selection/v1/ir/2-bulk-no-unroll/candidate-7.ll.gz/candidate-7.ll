; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct.RuntimeContext.738 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }
%struct.range_task_helper_context = type { ptr, ptr, ptr, ptr, i64, i32, i32, i32, i32 }

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @selection_numeric_publish_28_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 20
  %2 = load i32, ptr %1, align 4
  %3 = getelementptr inbounds %struct.RuntimeContext.738, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  store i32 %2, ptr %6, align 4
  ret void
}

; Function Attrs: nounwind
define void @selection_numeric_publish_28_kernel_1_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.738, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 560)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.738, ptr %0, i64 0, i32 1
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.LLVMRuntime, ptr %8, i64 0, i32 16
  %10 = load ptr, ptr %9, align 8
  %11 = load i32, ptr %10, align 4
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.lr.ph
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if, %for_loop_body.preheader
  %.04 = phi i32 [ %39, %after_if ], [ %3, %for_loop_body.preheader ]
  %13 = load ptr, ptr %7, align 8
  %14 = getelementptr inbounds %struct.LLVMRuntime, ptr %13, i64 0, i32 16
  %15 = load ptr, ptr %14, align 8
  %16 = load i32, ptr %15, align 4
  %.not = icmp eq i32 %16, 0
  br i1 %.not, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.lr.ph, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %17 = sdiv i32 %.04, 70
  %18 = srem i32 %.04, 70
  %19 = load ptr, ptr %0, align 8
  %20 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 1, i32 1
  %21 = load ptr, ptr %20, align 8
  %22 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 1, i32 0, i32 1
  %23 = load i32, ptr %22, align 4
  %24 = sext i32 %17 to i64
  %25 = sext i32 %23 to i64
  %26 = mul nsw i64 %25, %24
  %27 = sext i32 %18 to i64
  %28 = add nsw i64 %26, %27
  %29 = getelementptr double, ptr %21, i64 %28
  %30 = getelementptr { { i32, i32 }, ptr }, ptr %19, i64 0, i32 1
  %31 = load ptr, ptr %30, align 8
  %32 = getelementptr { { i32, i32 }, ptr }, ptr %19, i64 0, i32 0, i32 1
  %33 = load i32, ptr %32, align 4
  %34 = sext i32 %33 to i64
  %35 = mul nsw i64 %34, %24
  %36 = add nsw i64 %35, %27
  %37 = getelementptr double, ptr %31, i64 %36
  %38 = load double, ptr %37, align 8
  store double %38, ptr %29, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %39 = add nsw i32 %.04, 1
  %exitcond.not = icmp eq i32 %5, %39
  br i1 %exitcond.not, label %after_for.loopexit, label %for_loop_body, !llvm.loop !6
}

; Function Attrs: nounwind
define void @selection_numeric_publish_28_kernel_2_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.1, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.738, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.1(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.738, ptr %0, i64 0, i32 1
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.LLVMRuntime, ptr %8, i64 0, i32 16
  %10 = load ptr, ptr %9, align 8
  %11 = load i32, ptr %10, align 4
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.lr.ph
  %13 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %13, %for_loop_body.preheader ], [ %indvars.iv.next, %after_if ]
  %14 = load ptr, ptr %7, align 8
  %15 = getelementptr inbounds %struct.LLVMRuntime, ptr %14, i64 0, i32 16
  %16 = load ptr, ptr %15, align 8
  %17 = load i32, ptr %16, align 4
  %.not = icmp eq i32 %17, 0
  br i1 %.not, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.lr.ph, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %18 = load ptr, ptr %0, align 8
  %19 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %18, i64 0, i32 3, i32 1
  %20 = load ptr, ptr %19, align 8
  %21 = shl i64 %indvars.iv, 2
  %uglygep = getelementptr i8, ptr %20, i64 %21
  %22 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %18, i64 0, i32 2, i32 1
  %23 = load ptr, ptr %22, align 8
  %uglygep7 = getelementptr i8, ptr %23, i64 %21
  %24 = load i32, ptr %uglygep7, align 4
  store i32 %24, ptr %uglygep, align 4
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %indvars.iv.next = add nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %wide.trip.count, %indvars.iv.next
  br i1 %exitcond.not, label %after_for.loopexit, label %for_loop_body, !llvm.loop !8
}

; Function Attrs: nounwind
define void @selection_numeric_publish_28_kernel_3_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.2, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.738, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.2(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 770)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.738, ptr %0, i64 0, i32 1
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.LLVMRuntime, ptr %8, i64 0, i32 16
  %10 = load ptr, ptr %9, align 8
  %11 = load i32, ptr %10, align 4
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.lr.ph
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if, %for_loop_body.preheader
  %.04 = phi i32 [ %39, %after_if ], [ %3, %for_loop_body.preheader ]
  %13 = load ptr, ptr %7, align 8
  %14 = getelementptr inbounds %struct.LLVMRuntime, ptr %13, i64 0, i32 16
  %15 = load ptr, ptr %14, align 8
  %16 = load i32, ptr %15, align 4
  %.not = icmp eq i32 %16, 0
  br i1 %.not, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.lr.ph, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %17 = sdiv i32 %.04, 70
  %18 = srem i32 %.04, 70
  %19 = load ptr, ptr %0, align 8
  %20 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 5, i32 1
  %21 = load ptr, ptr %20, align 8
  %22 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 5, i32 0, i32 1
  %23 = load i32, ptr %22, align 4
  %24 = sext i32 %17 to i64
  %25 = sext i32 %23 to i64
  %26 = mul nsw i64 %25, %24
  %27 = sext i32 %18 to i64
  %28 = add nsw i64 %26, %27
  %29 = getelementptr double, ptr %21, i64 %28
  %30 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 4, i32 1
  %31 = load ptr, ptr %30, align 8
  %32 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 4, i32 0, i32 1
  %33 = load i32, ptr %32, align 4
  %34 = sext i32 %33 to i64
  %35 = mul nsw i64 %34, %24
  %36 = add nsw i64 %35, %27
  %37 = getelementptr double, ptr %31, i64 %36
  %38 = load double, ptr %37, align 8
  store double %38, ptr %29, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %39 = add nsw i32 %.04, 1
  %exitcond.not = icmp eq i32 %5, %39
  br i1 %exitcond.not, label %after_for.loopexit, label %for_loop_body, !llvm.loop !9
}

; Function Attrs: nounwind
define void @selection_numeric_publish_28_kernel_4_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.3, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.738, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.3(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 560)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.738, ptr %0, i64 0, i32 1
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.LLVMRuntime, ptr %8, i64 0, i32 16
  %10 = load ptr, ptr %9, align 8
  %11 = load i32, ptr %10, align 4
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.lr.ph
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if, %for_loop_body.preheader
  %.04 = phi i32 [ %39, %after_if ], [ %3, %for_loop_body.preheader ]
  %13 = load ptr, ptr %7, align 8
  %14 = getelementptr inbounds %struct.LLVMRuntime, ptr %13, i64 0, i32 16
  %15 = load ptr, ptr %14, align 8
  %16 = load i32, ptr %15, align 4
  %.not = icmp eq i32 %16, 0
  br i1 %.not, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.lr.ph, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %17 = sdiv i32 %.04, 70
  %18 = srem i32 %.04, 70
  %19 = load ptr, ptr %0, align 8
  %20 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 7, i32 1
  %21 = load ptr, ptr %20, align 8
  %22 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 7, i32 0, i32 1
  %23 = load i32, ptr %22, align 4
  %24 = sext i32 %17 to i64
  %25 = sext i32 %23 to i64
  %26 = mul nsw i64 %25, %24
  %27 = sext i32 %18 to i64
  %28 = add nsw i64 %26, %27
  %29 = getelementptr double, ptr %21, i64 %28
  %30 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 6, i32 1
  %31 = load ptr, ptr %30, align 8
  %32 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 6, i32 0, i32 1
  %33 = load i32, ptr %32, align 4
  %34 = sext i32 %33 to i64
  %35 = mul nsw i64 %34, %24
  %36 = add nsw i64 %35, %27
  %37 = getelementptr double, ptr %31, i64 %36
  %38 = load double, ptr %37, align 8
  store double %38, ptr %29, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %39 = add nsw i32 %.04, 1
  %exitcond.not = icmp eq i32 %5, %39
  br i1 %exitcond.not, label %after_for.loopexit, label %for_loop_body, !llvm.loop !10
}

; Function Attrs: nounwind
define void @selection_numeric_publish_28_kernel_5_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.4, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.738, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.4(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 280)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.738, ptr %0, i64 0, i32 1
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.LLVMRuntime, ptr %8, i64 0, i32 16
  %10 = load ptr, ptr %9, align 8
  %11 = load i32, ptr %10, align 4
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.lr.ph
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if, %for_loop_body.preheader
  %.04 = phi i32 [ %39, %after_if ], [ %3, %for_loop_body.preheader ]
  %13 = load ptr, ptr %7, align 8
  %14 = getelementptr inbounds %struct.LLVMRuntime, ptr %13, i64 0, i32 16
  %15 = load ptr, ptr %14, align 8
  %16 = load i32, ptr %15, align 4
  %.not = icmp eq i32 %16, 0
  br i1 %.not, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.lr.ph, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %17 = sdiv i32 %.04, 70
  %18 = srem i32 %.04, 70
  %19 = load ptr, ptr %0, align 8
  %20 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 9, i32 1
  %21 = load ptr, ptr %20, align 8
  %22 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 9, i32 0, i32 1
  %23 = load i32, ptr %22, align 4
  %24 = sext i32 %17 to i64
  %25 = sext i32 %23 to i64
  %26 = mul nsw i64 %25, %24
  %27 = sext i32 %18 to i64
  %28 = add nsw i64 %26, %27
  %29 = getelementptr double, ptr %21, i64 %28
  %30 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 8, i32 1
  %31 = load ptr, ptr %30, align 8
  %32 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 8, i32 0, i32 1
  %33 = load i32, ptr %32, align 4
  %34 = sext i32 %33 to i64
  %35 = mul nsw i64 %34, %24
  %36 = add nsw i64 %35, %27
  %37 = getelementptr double, ptr %31, i64 %36
  %38 = load double, ptr %37, align 8
  store double %38, ptr %29, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %39 = add nsw i32 %.04, 1
  %exitcond.not = icmp eq i32 %5, %39
  br i1 %exitcond.not, label %after_for.loopexit, label %for_loop_body, !llvm.loop !11
}

; Function Attrs: nounwind
define void @selection_numeric_publish_28_kernel_6_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.5, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.738, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.5(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 10)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.738, ptr %0, i64 0, i32 1
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.LLVMRuntime, ptr %8, i64 0, i32 16
  %10 = load ptr, ptr %9, align 8
  %11 = load i32, ptr %10, align 4
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.lr.ph
  %13 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %13, %for_loop_body.preheader ], [ %indvars.iv.next, %after_if ]
  %14 = load ptr, ptr %7, align 8
  %15 = getelementptr inbounds %struct.LLVMRuntime, ptr %14, i64 0, i32 16
  %16 = load ptr, ptr %15, align 8
  %17 = load i32, ptr %16, align 4
  %.not = icmp eq i32 %17, 0
  br i1 %.not, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.lr.ph, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %18 = load ptr, ptr %0, align 8
  %19 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %18, i64 0, i32 11, i32 1
  %20 = load ptr, ptr %19, align 8
  %21 = shl i64 %indvars.iv, 3
  %uglygep = getelementptr i8, ptr %20, i64 %21
  %22 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %18, i64 0, i32 10, i32 1
  %23 = load ptr, ptr %22, align 8
  %uglygep7 = getelementptr i8, ptr %23, i64 %21
  %24 = load i64, ptr %uglygep7, align 8
  store i64 %24, ptr %uglygep, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %indvars.iv.next = add nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %wide.trip.count, %indvars.iv.next
  br i1 %exitcond.not, label %after_for.loopexit, label %for_loop_body, !llvm.loop !12
}

; Function Attrs: nounwind
define void @selection_numeric_publish_28_kernel_7_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.6, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.738, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.6(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 20)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.738, ptr %0, i64 0, i32 1
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.LLVMRuntime, ptr %8, i64 0, i32 16
  %10 = load ptr, ptr %9, align 8
  %11 = load i32, ptr %10, align 4
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.lr.ph
  %13 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %13, %for_loop_body.preheader ], [ %indvars.iv.next, %after_if ]
  %14 = load ptr, ptr %7, align 8
  %15 = getelementptr inbounds %struct.LLVMRuntime, ptr %14, i64 0, i32 16
  %16 = load ptr, ptr %15, align 8
  %17 = load i32, ptr %16, align 4
  %.not = icmp eq i32 %17, 0
  br i1 %.not, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.lr.ph, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %18 = load ptr, ptr %0, align 8
  %19 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %18, i64 0, i32 13, i32 1
  %20 = load ptr, ptr %19, align 8
  %21 = shl i64 %indvars.iv, 3
  %uglygep = getelementptr i8, ptr %20, i64 %21
  %22 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %18, i64 0, i32 12, i32 1
  %23 = load ptr, ptr %22, align 8
  %uglygep7 = getelementptr i8, ptr %23, i64 %21
  %24 = load i64, ptr %uglygep7, align 8
  store i64 %24, ptr %uglygep, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %indvars.iv.next = add nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %wide.trip.count, %indvars.iv.next
  br i1 %exitcond.not, label %after_for.loopexit, label %for_loop_body, !llvm.loop !13
}

; Function Attrs: nounwind
define void @selection_numeric_publish_28_kernel_8_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.7, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.738, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.7(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 420)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.738, ptr %0, i64 0, i32 1
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.LLVMRuntime, ptr %8, i64 0, i32 16
  %10 = load ptr, ptr %9, align 8
  %11 = load i32, ptr %10, align 4
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.lr.ph
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if, %for_loop_body.preheader
  %.04 = phi i32 [ %39, %after_if ], [ %3, %for_loop_body.preheader ]
  %13 = load ptr, ptr %7, align 8
  %14 = getelementptr inbounds %struct.LLVMRuntime, ptr %13, i64 0, i32 16
  %15 = load ptr, ptr %14, align 8
  %16 = load i32, ptr %15, align 4
  %.not = icmp eq i32 %16, 0
  br i1 %.not, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.lr.ph, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %17 = sdiv i32 %.04, 70
  %18 = srem i32 %.04, 70
  %19 = load ptr, ptr %0, align 8
  %20 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 15, i32 1
  %21 = load ptr, ptr %20, align 8
  %22 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 15, i32 0, i32 1
  %23 = load i32, ptr %22, align 4
  %24 = sext i32 %17 to i64
  %25 = sext i32 %23 to i64
  %26 = mul nsw i64 %25, %24
  %27 = sext i32 %18 to i64
  %28 = add nsw i64 %26, %27
  %29 = getelementptr double, ptr %21, i64 %28
  %30 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 14, i32 1
  %31 = load ptr, ptr %30, align 8
  %32 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 14, i32 0, i32 1
  %33 = load i32, ptr %32, align 4
  %34 = sext i32 %33 to i64
  %35 = mul nsw i64 %34, %24
  %36 = add nsw i64 %35, %27
  %37 = getelementptr double, ptr %31, i64 %36
  %38 = load double, ptr %37, align 8
  store double %38, ptr %29, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %39 = add nsw i32 %.04, 1
  %exitcond.not = icmp eq i32 %5, %39
  br i1 %exitcond.not, label %after_for.loopexit, label %for_loop_body, !llvm.loop !14
}

; Function Attrs: nounwind
define void @selection_numeric_publish_28_kernel_9_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.8, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.738, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.8(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 140)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.738, ptr %0, i64 0, i32 1
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.LLVMRuntime, ptr %8, i64 0, i32 16
  %10 = load ptr, ptr %9, align 8
  %11 = load i32, ptr %10, align 4
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.lr.ph
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if, %for_loop_body.preheader
  %.04 = phi i32 [ %39, %after_if ], [ %3, %for_loop_body.preheader ]
  %13 = load ptr, ptr %7, align 8
  %14 = getelementptr inbounds %struct.LLVMRuntime, ptr %13, i64 0, i32 16
  %15 = load ptr, ptr %14, align 8
  %16 = load i32, ptr %15, align 4
  %.not = icmp eq i32 %16, 0
  br i1 %.not, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.lr.ph, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %17 = sdiv i32 %.04, 70
  %18 = srem i32 %.04, 70
  %19 = load ptr, ptr %0, align 8
  %20 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 17, i32 1
  %21 = load ptr, ptr %20, align 8
  %22 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 17, i32 0, i32 1
  %23 = load i32, ptr %22, align 4
  %24 = sext i32 %17 to i64
  %25 = sext i32 %23 to i64
  %26 = mul nsw i64 %25, %24
  %27 = sext i32 %18 to i64
  %28 = add nsw i64 %26, %27
  %29 = getelementptr i64, ptr %21, i64 %28
  %30 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 16, i32 1
  %31 = load ptr, ptr %30, align 8
  %32 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 16, i32 0, i32 1
  %33 = load i32, ptr %32, align 4
  %34 = sext i32 %33 to i64
  %35 = mul nsw i64 %34, %24
  %36 = add nsw i64 %35, %27
  %37 = getelementptr i64, ptr %31, i64 %36
  %38 = load i64, ptr %37, align 8
  store i64 %38, ptr %29, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %39 = add nsw i32 %.04, 1
  %exitcond.not = icmp eq i32 %5, %39
  br i1 %exitcond.not, label %after_for.loopexit, label %for_loop_body, !llvm.loop !15
}

; Function Attrs: nounwind
define void @selection_numeric_publish_28_kernel_10_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.9, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.738, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.9(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 140)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.738, ptr %0, i64 0, i32 1
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.LLVMRuntime, ptr %8, i64 0, i32 16
  %10 = load ptr, ptr %9, align 8
  %11 = load i32, ptr %10, align 4
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.lr.ph
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if, %for_loop_body.preheader
  %.04 = phi i32 [ %39, %after_if ], [ %3, %for_loop_body.preheader ]
  %13 = load ptr, ptr %7, align 8
  %14 = getelementptr inbounds %struct.LLVMRuntime, ptr %13, i64 0, i32 16
  %15 = load ptr, ptr %14, align 8
  %16 = load i32, ptr %15, align 4
  %.not = icmp eq i32 %16, 0
  br i1 %.not, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.lr.ph, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %17 = sdiv i32 %.04, 70
  %18 = srem i32 %.04, 70
  %19 = load ptr, ptr %0, align 8
  %20 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 19, i32 1
  %21 = load ptr, ptr %20, align 8
  %22 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 19, i32 0, i32 1
  %23 = load i32, ptr %22, align 4
  %24 = sext i32 %17 to i64
  %25 = sext i32 %23 to i64
  %26 = mul nsw i64 %25, %24
  %27 = sext i32 %18 to i64
  %28 = add nsw i64 %26, %27
  %29 = getelementptr i32, ptr %21, i64 %28
  %30 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 18, i32 1
  %31 = load ptr, ptr %30, align 8
  %32 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %19, i64 0, i32 18, i32 0, i32 1
  %33 = load i32, ptr %32, align 4
  %34 = sext i32 %33 to i64
  %35 = mul nsw i64 %34, %24
  %36 = add nsw i64 %35, %27
  %37 = getelementptr i32, ptr %31, i64 %36
  %38 = load i32, ptr %37, align 4
  store i32 %38, ptr %29, align 4
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %39 = add nsw i32 %.04, 1
  %exitcond.not = icmp eq i32 %5, %39
  br i1 %exitcond.not, label %after_for.loopexit, label %for_loop_body, !llvm.loop !16
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_parallel_range_for_task(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #3 {
  %4 = alloca %struct.RuntimeContext.738, align 8
  %.sroa.0.0.copyload = load ptr, ptr %0, align 8
  %.sroa.4.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 8
  %.sroa.4.0.copyload = load ptr, ptr %.sroa.4.0..sroa_idx, align 8
  %.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 16
  %.sroa.5.0.copyload = load ptr, ptr %.sroa.5.0..sroa_idx, align 8
  %.sroa.7.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 24
  %.sroa.7.0.copyload = load ptr, ptr %.sroa.7.0..sroa_idx, align 8
  %.sroa.8.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 32
  %.sroa.8.0.copyload = load i64, ptr %.sroa.8.0..sroa_idx, align 8
  %.sroa.9.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 40
  %.sroa.9.0.copyload = load i32, ptr %.sroa.9.0..sroa_idx, align 8
  %.sroa.12.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 44
  %.sroa.12.0.copyload = load i32, ptr %.sroa.12.0..sroa_idx, align 4
  %.sroa.15.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 48
  %.sroa.15.0.copyload = load i32, ptr %.sroa.15.0..sroa_idx, align 8
  %.sroa.17.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 52
  %.sroa.17.0.copyload = load i32, ptr %.sroa.17.0..sroa_idx, align 4
  %5 = alloca i8, i64 %.sroa.8.0.copyload, align 8
  %.not = icmp eq ptr %.sroa.4.0.copyload, null
  br i1 %.not, label %7, label %6

6:                                                ; preds = %3
  call void %.sroa.4.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %7

7:                                                ; preds = %6, %3
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %4, ptr noundef nonnull align 8 dereferenceable(32) %.sroa.0.0.copyload, i64 32, i1 false)
  %8 = getelementptr inbounds %struct.RuntimeContext.738, ptr %4, i64 0, i32 2
  store i32 %1, ptr %8, align 8
  switch i32 %.sroa.17.0.copyload, label %.loopexit [
    i32 1, label %9
    i32 -1, label %17
  ]

9:                                                ; preds = %7
  %10 = mul nsw i32 %.sroa.15.0.copyload, %2
  %11 = add nsw i32 %10, %.sroa.9.0.copyload
  %12 = add nsw i32 %11, %.sroa.15.0.copyload
  %13 = call i32 @llvm.smin.i32(i32 %.sroa.12.0.copyload, i32 %12)
  %14 = icmp slt i32 %11, %13
  br i1 %14, label %.lr.ph.preheader, label %.loopexit

.lr.ph.preheader:                                 ; preds = %9
  br label %.lr.ph

.lr.ph:                                           ; preds = %.lr.ph, %.lr.ph.preheader
  %.02039 = phi i32 [ %15, %.lr.ph ], [ %11, %.lr.ph.preheader ]
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.02039) #1
  %15 = add nsw i32 %.02039, 1
  %16 = icmp slt i32 %15, %13
  br i1 %16, label %.lr.ph, label %.loopexit.loopexit, !llvm.loop !17

17:                                               ; preds = %7
  %18 = mul nsw i32 %.sroa.15.0.copyload, %2
  %19 = sub nsw i32 %.sroa.12.0.copyload, %18
  %20 = mul nsw i32 %19, %.sroa.15.0.copyload
  %21 = call i32 @llvm.smax.i32(i32 %.sroa.9.0.copyload, i32 %20)
  %.not25.not40 = icmp sgt i32 %19, %21
  br i1 %.not25.not40, label %.lr.ph42.preheader, label %.loopexit

.lr.ph42.preheader:                               ; preds = %17
  br label %.lr.ph42

.lr.ph42:                                         ; preds = %.lr.ph42, %.lr.ph42.preheader
  %.0.in41 = phi i32 [ %.0, %.lr.ph42 ], [ %19, %.lr.ph42.preheader ]
  %.0 = add nsw i32 %.0.in41, -1
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.0) #1
  %.not25.not = icmp sgt i32 %.0, %21
  br i1 %.not25.not, label %.lr.ph42, label %.loopexit.loopexit47, !llvm.loop !19

.loopexit.loopexit:                               ; preds = %.lr.ph
  br label %.loopexit

.loopexit.loopexit47:                             ; preds = %.lr.ph42
  br label %.loopexit

.loopexit:                                        ; preds = %.loopexit.loopexit47, %.loopexit.loopexit, %17, %9, %7
  %.not24 = icmp eq ptr %.sroa.7.0.copyload, null
  br i1 %.not24, label %23, label %22

22:                                               ; preds = %.loopexit
  call void %.sroa.7.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %23

23:                                               ; preds = %22, %.loopexit
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #5

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #6

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #6

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smax.i32(i32, i32) #7

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { nofree nosync nounwind }
attributes #3 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #5 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #6 = { argmemonly nocallback nofree nosync nounwind willreturn }
attributes #7 = { nocallback nofree nosync nounwind readnone speculatable willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.unroll.disable"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
!13 = distinct !{!13, !7}
!14 = distinct !{!14, !7}
!15 = distinct !{!15, !7}
!16 = distinct !{!16, !7}
!17 = distinct !{!17, !18, !7}
!18 = !{!"llvm.loop.mustprogress"}
!19 = distinct !{!19, !18, !7}
