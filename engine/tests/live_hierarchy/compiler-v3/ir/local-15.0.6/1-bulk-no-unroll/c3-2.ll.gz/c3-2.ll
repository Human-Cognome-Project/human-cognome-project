; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind
define void @live_hierarchy_control_21_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 24
  %2 = load i32, ptr %1, align 4
  %3 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 26
  %4 = load i32, ptr %3, align 4
  %5 = icmp eq i32 %4, 0
  br i1 %5, label %true_block, label %for_loop_test.preheader

for_loop_test.preheader:                          ; preds = %entry
  %6 = icmp sgt i32 %2, 0
  br i1 %6, label %for_loop_body.lr.ph, label %after_if

for_loop_body.lr.ph:                              ; preds = %for_loop_test.preheader
  %7 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 2, i32 1
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 2, i32 0, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 29, i32 1
  %10 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 29, i32 0, i32 1
  %11 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 8, i32 1
  %12 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 8, i32 0, i32 1
  %13 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 13, i32 1
  %14 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 13, i32 0, i32 1
  %15 = getelementptr { { i32, i32 }, ptr }, ptr %0, i64 0, i32 1
  %16 = getelementptr { { i32, i32 }, ptr }, ptr %0, i64 0, i32 0, i32 1
  %17 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 16, i32 1
  %18 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 16, i32 0, i32 1
  %wide.trip.count = zext i32 %2 to i64
  br label %for_loop_body

true_block:                                       ; preds = %entry
  %19 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 14, i32 1
  %20 = load ptr, ptr %19, align 8
  store i64 0, ptr %20, align 8
  %21 = load ptr, ptr %19, align 8
  %22 = getelementptr i64, ptr %21, i64 1
  store i64 0, ptr %22, align 8
  %23 = load ptr, ptr %19, align 8
  %24 = getelementptr i64, ptr %23, i64 2
  store i64 0, ptr %24, align 8
  %25 = load ptr, ptr %19, align 8
  %26 = getelementptr i64, ptr %25, i64 3
  store i64 0, ptr %26, align 8
  %27 = load ptr, ptr %19, align 8
  %28 = getelementptr i64, ptr %27, i64 4
  store i64 0, ptr %28, align 8
  %29 = load ptr, ptr %19, align 8
  %30 = getelementptr i64, ptr %29, i64 5
  store i64 0, ptr %30, align 8
  %31 = load ptr, ptr %19, align 8
  %32 = getelementptr i64, ptr %31, i64 6
  store i64 0, ptr %32, align 8
  %33 = load ptr, ptr %19, align 8
  %34 = getelementptr i64, ptr %33, i64 7
  store i64 0, ptr %34, align 8
  %35 = load ptr, ptr %19, align 8
  %36 = getelementptr i64, ptr %35, i64 8
  store i64 0, ptr %36, align 8
  %37 = load ptr, ptr %19, align 8
  %38 = getelementptr i64, ptr %37, i64 9
  store i64 0, ptr %38, align 8
  br label %after_if

after_if.loopexit:                                ; preds = %for_loop_body
  br label %after_if

after_if:                                         ; preds = %after_if.loopexit, %true_block, %for_loop_test.preheader
  ret void

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.lr.ph
  %indvars.iv = phi i64 [ 0, %for_loop_body.lr.ph ], [ %indvars.iv.next, %for_loop_body ]
  %39 = load ptr, ptr %7, align 8
  %40 = load i32, ptr %8, align 4
  %41 = sext i32 %40 to i64
  %42 = mul nsw i64 %41, 20
  %uglygep14 = getelementptr i8, ptr %39, i64 %42
  %43 = shl nuw nsw i64 %indvars.iv, 2
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %43
  %44 = load i32, ptr %uglygep15, align 4
  %45 = load ptr, ptr %9, align 8
  %46 = sext i32 %44 to i64
  %47 = getelementptr i32, ptr %45, i64 %46
  store i32 0, ptr %47, align 4
  %48 = load ptr, ptr %9, align 8
  %49 = load i32, ptr %10, align 4
  %50 = sext i32 %49 to i64
  %51 = add nsw i64 %50, %46
  %52 = getelementptr i32, ptr %48, i64 %51
  store i32 0, ptr %52, align 4
  %53 = load ptr, ptr %11, align 8
  %54 = load i32, ptr %12, align 4
  %55 = sext i32 %54 to i64
  %56 = shl nsw i64 %55, 2
  %57 = add nsw i64 %56, %46
  %58 = getelementptr double, ptr %53, i64 %57
  store double 0.000000e+00, ptr %58, align 8
  %59 = load ptr, ptr %11, align 8
  %60 = load i32, ptr %12, align 4
  %61 = sext i32 %60 to i64
  %62 = mul nsw i64 %61, 5
  %63 = add nsw i64 %62, %46
  %64 = getelementptr double, ptr %59, i64 %63
  store double 0.000000e+00, ptr %64, align 8
  %65 = load ptr, ptr %11, align 8
  %66 = load i32, ptr %12, align 4
  %67 = sext i32 %66 to i64
  %68 = mul nsw i64 %67, 6
  %69 = add nsw i64 %68, %46
  %70 = getelementptr double, ptr %65, i64 %69
  store double 0.000000e+00, ptr %70, align 8
  %71 = load ptr, ptr %11, align 8
  %72 = load i32, ptr %12, align 4
  %73 = sext i32 %72 to i64
  %74 = mul nsw i64 %73, 7
  %75 = add nsw i64 %74, %46
  %76 = getelementptr double, ptr %71, i64 %75
  store double 0.000000e+00, ptr %76, align 8
  %77 = load ptr, ptr %11, align 8
  %78 = getelementptr double, ptr %77, i64 %46
  %79 = load double, ptr %78, align 8
  %80 = load ptr, ptr %13, align 8
  %81 = shl nuw nsw i64 %indvars.iv, 3
  %uglygep13 = getelementptr i8, ptr %80, i64 %81
  store double %79, ptr %uglygep13, align 8
  %82 = load ptr, ptr %15, align 8
  %uglygep12 = getelementptr i8, ptr %82, i64 %81
  %83 = load double, ptr %uglygep12, align 8
  store double %83, ptr %78, align 8
  %84 = load ptr, ptr %17, align 8
  %85 = load i32, ptr %18, align 4
  %86 = sext i32 %85 to i64
  %87 = mul nsw i64 %86, 3
  %88 = add nsw i64 %87, %46
  %89 = getelementptr double, ptr %84, i64 %88
  store double %79, ptr %89, align 8
  %90 = load ptr, ptr %17, align 8
  %91 = getelementptr double, ptr %90, i64 %46
  store double 0.000000e+00, ptr %91, align 8
  %92 = load ptr, ptr %11, align 8
  %93 = load i32, ptr %12, align 4
  %94 = sext i32 %93 to i64
  %95 = add nsw i64 %94, %46
  %96 = getelementptr double, ptr %92, i64 %95
  %97 = load double, ptr %96, align 8
  %98 = load ptr, ptr %13, align 8
  %99 = load i32, ptr %14, align 4
  %100 = sext i32 %99 to i64
  %101 = add nsw i64 %indvars.iv, %100
  %102 = getelementptr double, ptr %98, i64 %101
  store double %97, ptr %102, align 8
  %103 = load ptr, ptr %15, align 8
  %104 = load i32, ptr %16, align 4
  %105 = sext i32 %104 to i64
  %106 = add nsw i64 %indvars.iv, %105
  %107 = getelementptr double, ptr %103, i64 %106
  %108 = load double, ptr %107, align 8
  store double %108, ptr %96, align 8
  %109 = load ptr, ptr %17, align 8
  %110 = load i32, ptr %18, align 4
  %111 = sext i32 %110 to i64
  %112 = shl nsw i64 %111, 2
  %113 = add nsw i64 %112, %46
  %114 = getelementptr double, ptr %109, i64 %113
  store double %97, ptr %114, align 8
  %115 = load ptr, ptr %17, align 8
  %116 = load i32, ptr %18, align 4
  %117 = sext i32 %116 to i64
  %118 = add nsw i64 %117, %46
  %119 = getelementptr double, ptr %115, i64 %118
  store double 0.000000e+00, ptr %119, align 8
  %120 = load ptr, ptr %11, align 8
  %121 = load i32, ptr %12, align 4
  %122 = sext i32 %121 to i64
  %123 = shl nsw i64 %122, 1
  %124 = add nsw i64 %123, %46
  %125 = getelementptr double, ptr %120, i64 %124
  %126 = load double, ptr %125, align 8
  %127 = load ptr, ptr %13, align 8
  %128 = load i32, ptr %14, align 4
  %129 = sext i32 %128 to i64
  %130 = shl nsw i64 %129, 4
  %uglygep10 = getelementptr i8, ptr %127, i64 %130
  %uglygep11 = getelementptr i8, ptr %uglygep10, i64 %81
  store double %126, ptr %uglygep11, align 8
  %131 = load ptr, ptr %15, align 8
  %132 = load i32, ptr %16, align 4
  %133 = sext i32 %132 to i64
  %134 = shl nsw i64 %133, 4
  %uglygep8 = getelementptr i8, ptr %131, i64 %134
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %81
  %135 = load double, ptr %uglygep9, align 8
  store double %135, ptr %125, align 8
  %136 = load ptr, ptr %17, align 8
  %137 = load i32, ptr %18, align 4
  %138 = sext i32 %137 to i64
  %139 = mul nsw i64 %138, 5
  %140 = add nsw i64 %139, %46
  %141 = getelementptr double, ptr %136, i64 %140
  store double %126, ptr %141, align 8
  %142 = load ptr, ptr %17, align 8
  %143 = load i32, ptr %18, align 4
  %144 = sext i32 %143 to i64
  %145 = shl nsw i64 %144, 1
  %146 = add nsw i64 %145, %46
  %147 = getelementptr double, ptr %142, i64 %146
  store double 0.000000e+00, ptr %147, align 8
  %148 = load ptr, ptr %11, align 8
  %149 = load i32, ptr %12, align 4
  %150 = sext i32 %149 to i64
  %151 = mul nsw i64 %150, 3
  %152 = add nsw i64 %151, %46
  %153 = getelementptr double, ptr %148, i64 %152
  %154 = load double, ptr %153, align 8
  %155 = load ptr, ptr %13, align 8
  %156 = load i32, ptr %14, align 4
  %157 = sext i32 %156 to i64
  %158 = mul nsw i64 %157, 24
  %uglygep6 = getelementptr i8, ptr %155, i64 %158
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 %81
  store double %154, ptr %uglygep7, align 8
  %159 = load ptr, ptr %15, align 8
  %160 = load i32, ptr %16, align 4
  %161 = sext i32 %160 to i64
  %162 = mul nsw i64 %161, 24
  %uglygep = getelementptr i8, ptr %159, i64 %162
  %uglygep5 = getelementptr i8, ptr %uglygep, i64 %81
  %163 = load double, ptr %uglygep5, align 8
  store double %163, ptr %153, align 8
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %wide.trip.count, %indvars.iv.next
  br i1 %exitcond.not, label %after_if.loopexit, label %for_loop_body, !llvm.loop !6
}

attributes #0 = { nofree norecurse nosync nounwind }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.unroll.disable"}
