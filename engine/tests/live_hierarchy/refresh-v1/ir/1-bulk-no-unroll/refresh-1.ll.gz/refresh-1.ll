; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%0 = type { %1, %1 }
%1 = type { [4 x i64], [4 x ptr] }
%struct.range_task_helper_context = type { ptr, ptr, ptr, ptr, i64, i32, i32, i32, i32 }
%struct.RuntimeContext.465 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }
%struct.NodeManager = type <{ ptr, i32, i32, i32, i32, ptr, ptr, ptr, i32, [4 x i8] }>
%struct.ListManager = type { [256 x ptr], i64, i64, i32, i32, i32, ptr }
%class.anon = type { ptr, ptr, ptr, ptr }

@.str = private unnamed_addr constant [28 x i8] c"Out of pre-allocated memory\00", align 1
@.str.2 = private unnamed_addr constant [28 x i8] c"List manager out of chunks.\00", align 1

; Function Attrs: nounwind
define void @live_refresh_commit_21_kernel_0_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.465, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nounwind
define internal void @function_body(ptr %0, ptr nocapture readnone %1, i32 %2) #0 {
allocs:
  %3 = alloca ptr, align 8
  %4 = shl i32 %2, 9
  %5 = add i32 %4, 512
  %6 = tail call i32 @llvm.smin.i32(i32 %5, i32 70)
  %7 = icmp slt i32 %4, %6
  br i1 %7, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %8, i64 0, i32 11, i32 1
  %10 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %8, i64 0, i32 11, i32 0, i32 1
  %11 = getelementptr inbounds %struct.RuntimeContext.465, ptr %0, i64 0, i32 1
  %12 = sext i32 %4 to i64
  %wide.trip.count = sext i32 %6 to i64
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if, %for_loop_body.lr.ph
  %indvars.iv = phi i64 [ %12, %for_loop_body.lr.ph ], [ %indvars.iv.next, %after_if ]
  %13 = load ptr, ptr %9, align 8
  %14 = load i32, ptr %10, align 4
  %15 = sext i32 %14 to i64
  %16 = mul nsw i64 %15, 3
  %17 = add nsw i64 %16, %indvars.iv
  %18 = getelementptr i32, ptr %13, i64 %17
  %19 = load i32, ptr %18, align 4
  %.not = icmp eq i32 %19, 0
  %20 = load ptr, ptr %0, align 8
  br i1 %.not, label %false_block, label %true_block

after_for.loopexit:                               ; preds = %after_if
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %21 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %20, i64 0, i32 6, i32 1
  %22 = load ptr, ptr %21, align 8
  %23 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %20, i64 0, i32 6, i32 0, i32 1
  %24 = load i32, ptr %23, align 4
  %25 = sext i32 %24 to i64
  %26 = mul nsw i64 %25, 5
  %27 = add nsw i64 %26, %indvars.iv
  %28 = getelementptr i32, ptr %22, i64 %27
  %29 = load i32, ptr %28, align 4
  %30 = add i32 %29, 70
  %31 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %20, i64 0, i32 20, i32 1
  %32 = load ptr, ptr %31, align 8
  %33 = sext i32 %30 to i64
  %34 = getelementptr i32, ptr %32, i64 %33
  %35 = load i32, ptr %34, align 4
  %36 = getelementptr i32, ptr %13, i64 %indvars.iv
  %37 = load i32, ptr %36, align 4
  %38 = icmp slt i32 %37, 0
  %39 = shl nsw i64 %15, 2
  %40 = add nsw i64 %39, %indvars.iv
  %41 = getelementptr i32, ptr %13, i64 %40
  %42 = load i32, ptr %41, align 4
  %.not4 = icmp eq i32 %42, 0
  br i1 %.not4, label %after_if3, label %true_block1

false_block:                                      ; preds = %for_loop_body
  %43 = getelementptr { { i32, i32 }, ptr }, ptr %20, i64 0, i32 1
  %44 = load ptr, ptr %43, align 8
  %45 = getelementptr { { i32, i32 }, ptr }, ptr %20, i64 0, i32 0, i32 1
  %46 = getelementptr double, ptr %44, i64 %indvars.iv
  store double 0.000000e+00, ptr %46, align 8
  %47 = load ptr, ptr %43, align 8
  %48 = load i32, ptr %45, align 4
  %49 = sext i32 %48 to i64
  %50 = add nsw i64 %indvars.iv, %49
  %51 = getelementptr double, ptr %47, i64 %50
  store double 0.000000e+00, ptr %51, align 8
  %52 = load ptr, ptr %43, align 8
  %53 = load i32, ptr %45, align 4
  %54 = sext i32 %53 to i64
  %55 = shl nsw i64 %54, 1
  %56 = add nsw i64 %55, %indvars.iv
  %57 = getelementptr double, ptr %52, i64 %56
  store double 0.000000e+00, ptr %57, align 8
  %58 = load ptr, ptr %43, align 8
  %59 = load i32, ptr %45, align 4
  %60 = sext i32 %59 to i64
  %61 = mul nsw i64 %60, 3
  %62 = add nsw i64 %61, %indvars.iv
  %63 = getelementptr double, ptr %58, i64 %62
  store double 0.000000e+00, ptr %63, align 8
  %64 = load ptr, ptr %43, align 8
  %65 = load i32, ptr %45, align 4
  %66 = sext i32 %65 to i64
  %67 = shl nsw i64 %66, 2
  %68 = add nsw i64 %67, %indvars.iv
  %69 = getelementptr double, ptr %64, i64 %68
  store double 0.000000e+00, ptr %69, align 8
  %70 = load ptr, ptr %43, align 8
  %71 = load i32, ptr %45, align 4
  %72 = sext i32 %71 to i64
  %73 = mul nsw i64 %72, 5
  %74 = add nsw i64 %73, %indvars.iv
  %75 = getelementptr double, ptr %70, i64 %74
  store double 0.000000e+00, ptr %75, align 8
  %76 = load ptr, ptr %43, align 8
  %77 = load i32, ptr %45, align 4
  %78 = sext i32 %77 to i64
  %79 = mul nsw i64 %78, 6
  %80 = add nsw i64 %79, %indvars.iv
  %81 = getelementptr double, ptr %76, i64 %80
  store double 0.000000e+00, ptr %81, align 8
  %82 = load ptr, ptr %43, align 8
  %83 = load i32, ptr %45, align 4
  %84 = sext i32 %83 to i64
  %85 = mul nsw i64 %84, 7
  %86 = add nsw i64 %85, %indvars.iv
  %87 = getelementptr double, ptr %82, i64 %86
  store double 0.000000e+00, ptr %87, align 8
  %88 = load ptr, ptr %0, align 8
  %89 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %88, i64 0, i32 2, i32 1
  %90 = load ptr, ptr %89, align 8
  %91 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %88, i64 0, i32 2, i32 0, i32 1
  %92 = getelementptr double, ptr %90, i64 %indvars.iv
  store double 0.000000e+00, ptr %92, align 8
  %93 = load ptr, ptr %89, align 8
  %94 = load i32, ptr %91, align 4
  %95 = sext i32 %94 to i64
  %96 = add nsw i64 %indvars.iv, %95
  %97 = getelementptr double, ptr %93, i64 %96
  store double 0.000000e+00, ptr %97, align 8
  %98 = load ptr, ptr %89, align 8
  %99 = load i32, ptr %91, align 4
  %100 = sext i32 %99 to i64
  %101 = shl nsw i64 %100, 1
  %102 = add nsw i64 %101, %indvars.iv
  %103 = getelementptr double, ptr %98, i64 %102
  store double 0.000000e+00, ptr %103, align 8
  %104 = load ptr, ptr %89, align 8
  %105 = load i32, ptr %91, align 4
  %106 = sext i32 %105 to i64
  %107 = mul nsw i64 %106, 3
  %108 = add nsw i64 %107, %indvars.iv
  %109 = getelementptr double, ptr %104, i64 %108
  store double 0.000000e+00, ptr %109, align 8
  %110 = load ptr, ptr %0, align 8
  %111 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %110, i64 0, i32 1, i32 1
  %112 = load ptr, ptr %111, align 8
  %113 = getelementptr i32, ptr %112, i64 %indvars.iv
  store i32 0, ptr %113, align 4
  br label %after_if.sink.split

after_if.sink.split:                              ; preds = %after_if6, %false_block
  %.sink34 = load ptr, ptr %0, align 8
  %114 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %.sink34, i64 0, i32 21, i32 1
  %115 = load ptr, ptr %114, align 8
  %116 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %.sink34, i64 0, i32 21, i32 0, i32 1
  %117 = getelementptr i64, ptr %115, i64 %indvars.iv
  store i64 0, ptr %117, align 8
  %118 = load ptr, ptr %114, align 8
  %119 = load i32, ptr %116, align 4
  %120 = sext i32 %119 to i64
  %121 = add nsw i64 %indvars.iv, %120
  %122 = getelementptr i64, ptr %118, i64 %121
  store i64 0, ptr %122, align 8
  br label %after_if

after_if:                                         ; preds = %after_if6, %after_if.sink.split
  %indvars.iv.next = add nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %indvars.iv.next, %wide.trip.count
  br i1 %exitcond.not, label %after_for.loopexit, label %for_loop_body

true_block1:                                      ; preds = %true_block
  %123 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %20, i64 0, i32 3, i32 1
  %124 = load ptr, ptr %123, align 8
  %125 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %20, i64 0, i32 3, i32 0, i32 1
  %126 = getelementptr double, ptr %124, i64 %indvars.iv
  %127 = load double, ptr %126, align 8
  %128 = getelementptr { { i32, i32 }, ptr }, ptr %20, i64 0, i32 1
  %129 = load ptr, ptr %128, align 8
  %130 = getelementptr { { i32, i32 }, ptr }, ptr %20, i64 0, i32 0, i32 1
  %131 = getelementptr double, ptr %129, i64 %indvars.iv
  store double %127, ptr %131, align 8
  %132 = load ptr, ptr %123, align 8
  %133 = load i32, ptr %125, align 4
  %134 = sext i32 %133 to i64
  %135 = add nsw i64 %indvars.iv, %134
  %136 = getelementptr double, ptr %132, i64 %135
  %137 = load double, ptr %136, align 8
  %138 = load ptr, ptr %128, align 8
  %139 = load i32, ptr %130, align 4
  %140 = sext i32 %139 to i64
  %141 = add nsw i64 %indvars.iv, %140
  %142 = getelementptr double, ptr %138, i64 %141
  store double %137, ptr %142, align 8
  %143 = load ptr, ptr %123, align 8
  %144 = load i32, ptr %125, align 4
  %145 = sext i32 %144 to i64
  %146 = shl nsw i64 %145, 1
  %147 = add nsw i64 %146, %indvars.iv
  %148 = getelementptr double, ptr %143, i64 %147
  %149 = load double, ptr %148, align 8
  %150 = load ptr, ptr %128, align 8
  %151 = load i32, ptr %130, align 4
  %152 = sext i32 %151 to i64
  %153 = shl nsw i64 %152, 1
  %154 = add nsw i64 %153, %indvars.iv
  %155 = getelementptr double, ptr %150, i64 %154
  store double %149, ptr %155, align 8
  %156 = load ptr, ptr %123, align 8
  %157 = load i32, ptr %125, align 4
  %158 = sext i32 %157 to i64
  %159 = mul nsw i64 %158, 3
  %160 = add nsw i64 %159, %indvars.iv
  %161 = getelementptr double, ptr %156, i64 %160
  %162 = load double, ptr %161, align 8
  %163 = load ptr, ptr %128, align 8
  %164 = load i32, ptr %130, align 4
  %165 = sext i32 %164 to i64
  %166 = mul nsw i64 %165, 3
  %167 = add nsw i64 %166, %indvars.iv
  %168 = getelementptr double, ptr %163, i64 %167
  store double %162, ptr %168, align 8
  %169 = load ptr, ptr %123, align 8
  %170 = load i32, ptr %125, align 4
  %171 = sext i32 %170 to i64
  %172 = shl nsw i64 %171, 2
  %173 = add nsw i64 %172, %indvars.iv
  %174 = getelementptr double, ptr %169, i64 %173
  %175 = load double, ptr %174, align 8
  %176 = load ptr, ptr %128, align 8
  %177 = load i32, ptr %130, align 4
  %178 = sext i32 %177 to i64
  %179 = shl nsw i64 %178, 2
  %180 = add nsw i64 %179, %indvars.iv
  %181 = getelementptr double, ptr %176, i64 %180
  store double %175, ptr %181, align 8
  %182 = load ptr, ptr %123, align 8
  %183 = load i32, ptr %125, align 4
  %184 = sext i32 %183 to i64
  %185 = mul nsw i64 %184, 5
  %186 = add nsw i64 %185, %indvars.iv
  %187 = getelementptr double, ptr %182, i64 %186
  %188 = load double, ptr %187, align 8
  %189 = load ptr, ptr %128, align 8
  %190 = load i32, ptr %130, align 4
  %191 = sext i32 %190 to i64
  %192 = mul nsw i64 %191, 5
  %193 = add nsw i64 %192, %indvars.iv
  %194 = getelementptr double, ptr %189, i64 %193
  store double %188, ptr %194, align 8
  %195 = load ptr, ptr %123, align 8
  %196 = load i32, ptr %125, align 4
  %197 = sext i32 %196 to i64
  %198 = mul nsw i64 %197, 6
  %199 = add nsw i64 %198, %indvars.iv
  %200 = getelementptr double, ptr %195, i64 %199
  %201 = load double, ptr %200, align 8
  %202 = load ptr, ptr %128, align 8
  %203 = load i32, ptr %130, align 4
  %204 = sext i32 %203 to i64
  %205 = mul nsw i64 %204, 6
  %206 = add nsw i64 %205, %indvars.iv
  %207 = getelementptr double, ptr %202, i64 %206
  store double %201, ptr %207, align 8
  %208 = load ptr, ptr %123, align 8
  %209 = load i32, ptr %125, align 4
  %210 = sext i32 %209 to i64
  %211 = mul nsw i64 %210, 7
  %212 = add nsw i64 %211, %indvars.iv
  %213 = getelementptr double, ptr %208, i64 %212
  %214 = load double, ptr %213, align 8
  %215 = load ptr, ptr %128, align 8
  %216 = load i32, ptr %130, align 4
  %217 = sext i32 %216 to i64
  %218 = mul nsw i64 %217, 7
  %219 = add nsw i64 %218, %indvars.iv
  %220 = getelementptr double, ptr %215, i64 %219
  store double %214, ptr %220, align 8
  %221 = load ptr, ptr %0, align 8
  %222 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %221, i64 0, i32 4, i32 1
  %223 = load ptr, ptr %222, align 8
  %224 = getelementptr i32, ptr %223, i64 %indvars.iv
  %225 = load i32, ptr %224, align 4
  %226 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %221, i64 0, i32 1, i32 1
  %227 = load ptr, ptr %226, align 8
  %228 = getelementptr i32, ptr %227, i64 %indvars.iv
  store i32 %225, ptr %228, align 4
  %229 = load ptr, ptr %0, align 8
  %230 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %229, i64 0, i32 5, i32 1
  %231 = load ptr, ptr %230, align 8
  %232 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %229, i64 0, i32 5, i32 0, i32 1
  %233 = getelementptr double, ptr %231, i64 %indvars.iv
  %234 = load double, ptr %233, align 8
  %235 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %229, i64 0, i32 2, i32 1
  %236 = load ptr, ptr %235, align 8
  %237 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %229, i64 0, i32 2, i32 0, i32 1
  %238 = getelementptr double, ptr %236, i64 %indvars.iv
  store double %234, ptr %238, align 8
  %239 = shl i32 %225, 2
  %240 = load ptr, ptr %123, align 8
  %241 = load i32, ptr %125, align 4
  %242 = sext i32 %239 to i64
  %243 = sext i32 %241 to i64
  %244 = mul nsw i64 %243, %242
  %245 = add nsw i64 %244, %indvars.iv
  %246 = getelementptr double, ptr %240, i64 %245
  %247 = load double, ptr %246, align 8
  %248 = load ptr, ptr %0, align 8
  %249 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %248, i64 0, i32 17, i32 1
  %250 = load ptr, ptr %249, align 8
  %251 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %248, i64 0, i32 17, i32 0, i32 1
  %252 = sext i32 %35 to i64
  %253 = getelementptr double, ptr %250, i64 %252
  store double %247, ptr %253, align 8
  %254 = load ptr, ptr %249, align 8
  %255 = load i32, ptr %251, align 4
  %256 = sext i32 %255 to i64
  %257 = shl nsw i64 %256, 2
  %258 = add nsw i64 %257, %252
  %259 = getelementptr double, ptr %254, i64 %258
  store double 0.000000e+00, ptr %259, align 8
  %260 = load ptr, ptr %0, align 8
  %261 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %260, i64 0, i32 18, i32 1
  %262 = load ptr, ptr %261, align 8
  %263 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %260, i64 0, i32 18, i32 0, i32 1
  %264 = getelementptr double, ptr %262, i64 %252
  store double 0.000000e+00, ptr %264, align 8
  %265 = load ptr, ptr %261, align 8
  %266 = load i32, ptr %263, align 4
  %267 = sext i32 %266 to i64
  %268 = mul nsw i64 %267, 3
  %269 = add nsw i64 %268, %252
  %270 = getelementptr double, ptr %265, i64 %269
  store double %234, ptr %270, align 8
  %271 = load ptr, ptr %230, align 8
  %272 = load i32, ptr %232, align 4
  %273 = sext i32 %272 to i64
  %274 = add nsw i64 %indvars.iv, %273
  %275 = getelementptr double, ptr %271, i64 %274
  %276 = load double, ptr %275, align 8
  %277 = load ptr, ptr %235, align 8
  %278 = load i32, ptr %237, align 4
  %279 = sext i32 %278 to i64
  %280 = add nsw i64 %indvars.iv, %279
  %281 = getelementptr double, ptr %277, i64 %280
  store double %276, ptr %281, align 8
  %282 = or i32 %239, 1
  %283 = load ptr, ptr %123, align 8
  %284 = load i32, ptr %125, align 4
  %285 = sext i32 %282 to i64
  %286 = sext i32 %284 to i64
  %287 = mul nsw i64 %286, %285
  %288 = add nsw i64 %287, %indvars.iv
  %289 = getelementptr double, ptr %283, i64 %288
  %290 = load double, ptr %289, align 8
  %291 = load ptr, ptr %249, align 8
  %292 = load i32, ptr %251, align 4
  %293 = sext i32 %292 to i64
  %294 = add nsw i64 %293, %252
  %295 = getelementptr double, ptr %291, i64 %294
  store double %290, ptr %295, align 8
  %296 = load ptr, ptr %249, align 8
  %297 = load i32, ptr %251, align 4
  %298 = sext i32 %297 to i64
  %299 = mul nsw i64 %298, 5
  %300 = add nsw i64 %299, %252
  %301 = getelementptr double, ptr %296, i64 %300
  store double 0.000000e+00, ptr %301, align 8
  %302 = load ptr, ptr %261, align 8
  %303 = load i32, ptr %263, align 4
  %304 = sext i32 %303 to i64
  %305 = add nsw i64 %304, %252
  %306 = getelementptr double, ptr %302, i64 %305
  store double 0.000000e+00, ptr %306, align 8
  %307 = load ptr, ptr %261, align 8
  %308 = load i32, ptr %263, align 4
  %309 = sext i32 %308 to i64
  %310 = shl nsw i64 %309, 2
  %311 = add nsw i64 %310, %252
  %312 = getelementptr double, ptr %307, i64 %311
  store double %276, ptr %312, align 8
  %313 = load ptr, ptr %230, align 8
  %314 = load i32, ptr %232, align 4
  %315 = sext i32 %314 to i64
  %316 = shl nsw i64 %315, 1
  %317 = add nsw i64 %316, %indvars.iv
  %318 = getelementptr double, ptr %313, i64 %317
  %319 = load double, ptr %318, align 8
  %320 = load ptr, ptr %235, align 8
  %321 = load i32, ptr %237, align 4
  %322 = sext i32 %321 to i64
  %323 = shl nsw i64 %322, 1
  %324 = add nsw i64 %323, %indvars.iv
  %325 = getelementptr double, ptr %320, i64 %324
  store double %319, ptr %325, align 8
  %326 = or i32 %239, 2
  %327 = load ptr, ptr %123, align 8
  %328 = load i32, ptr %125, align 4
  %329 = sext i32 %326 to i64
  %330 = sext i32 %328 to i64
  %331 = mul nsw i64 %330, %329
  %332 = add nsw i64 %331, %indvars.iv
  %333 = getelementptr double, ptr %327, i64 %332
  %334 = load double, ptr %333, align 8
  %335 = load ptr, ptr %249, align 8
  %336 = load i32, ptr %251, align 4
  %337 = sext i32 %336 to i64
  %338 = shl nsw i64 %337, 1
  %339 = add nsw i64 %338, %252
  %340 = getelementptr double, ptr %335, i64 %339
  store double %334, ptr %340, align 8
  %341 = load ptr, ptr %249, align 8
  %342 = load i32, ptr %251, align 4
  %343 = sext i32 %342 to i64
  %344 = mul nsw i64 %343, 6
  %345 = add nsw i64 %344, %252
  %346 = getelementptr double, ptr %341, i64 %345
  store double 0.000000e+00, ptr %346, align 8
  %347 = load ptr, ptr %261, align 8
  %348 = load i32, ptr %263, align 4
  %349 = sext i32 %348 to i64
  %350 = shl nsw i64 %349, 1
  %351 = add nsw i64 %350, %252
  %352 = getelementptr double, ptr %347, i64 %351
  store double 0.000000e+00, ptr %352, align 8
  %353 = load ptr, ptr %261, align 8
  %354 = load i32, ptr %263, align 4
  %355 = sext i32 %354 to i64
  %356 = mul nsw i64 %355, 5
  %357 = add nsw i64 %356, %252
  %358 = getelementptr double, ptr %353, i64 %357
  store double %319, ptr %358, align 8
  %359 = load ptr, ptr %230, align 8
  %360 = load i32, ptr %232, align 4
  %361 = sext i32 %360 to i64
  %362 = mul nsw i64 %361, 3
  %363 = add nsw i64 %362, %indvars.iv
  %364 = getelementptr double, ptr %359, i64 %363
  %365 = load double, ptr %364, align 8
  %366 = load ptr, ptr %235, align 8
  %367 = load i32, ptr %237, align 4
  %368 = sext i32 %367 to i64
  %369 = mul nsw i64 %368, 3
  %370 = add nsw i64 %369, %indvars.iv
  %371 = getelementptr double, ptr %366, i64 %370
  store double %365, ptr %371, align 8
  %372 = or i32 %239, 3
  %373 = load ptr, ptr %123, align 8
  %374 = load i32, ptr %125, align 4
  %375 = sext i32 %372 to i64
  %376 = sext i32 %374 to i64
  %377 = mul nsw i64 %376, %375
  %378 = add nsw i64 %377, %indvars.iv
  %379 = getelementptr double, ptr %373, i64 %378
  %380 = load double, ptr %379, align 8
  %381 = load ptr, ptr %249, align 8
  %382 = load i32, ptr %251, align 4
  %383 = sext i32 %382 to i64
  %384 = mul nsw i64 %383, 3
  %385 = add nsw i64 %384, %252
  %386 = getelementptr double, ptr %381, i64 %385
  store double %380, ptr %386, align 8
  %387 = load ptr, ptr %249, align 8
  %388 = load i32, ptr %251, align 4
  %389 = sext i32 %388 to i64
  %390 = mul nsw i64 %389, 7
  %391 = add nsw i64 %390, %252
  %392 = getelementptr double, ptr %387, i64 %391
  store double 0.000000e+00, ptr %392, align 8
  %393 = load ptr, ptr %0, align 8
  %394 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %393, i64 0, i32 19, i32 1
  %395 = load ptr, ptr %394, align 8
  %396 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %393, i64 0, i32 19, i32 0, i32 1
  %397 = getelementptr i32, ptr %395, i64 %252
  store i32 0, ptr %397, align 4
  %398 = load ptr, ptr %394, align 8
  %399 = load i32, ptr %396, align 4
  %400 = sext i32 %399 to i64
  %401 = add nsw i64 %400, %252
  %402 = getelementptr i32, ptr %398, i64 %401
  store i32 0, ptr %402, align 4
  %.pre = load ptr, ptr %9, align 8
  %.pre25 = load i32, ptr %10, align 4
  %.pre26 = sext i32 %.pre25 to i64
  br label %after_if3

after_if3:                                        ; preds = %true_block1, %true_block
  %.pre-phi = phi i64 [ %15, %true_block ], [ %.pre26, %true_block1 ]
  %403 = phi ptr [ %13, %true_block ], [ %.pre, %true_block1 ]
  %404 = add nsw i64 %.pre-phi, %indvars.iv
  %405 = getelementptr i32, ptr %403, i64 %404
  %406 = load i32, ptr %405, align 4
  %.not5 = icmp eq i32 %406, 0
  br i1 %.not5, label %after_if6, label %true_block4

true_block4:                                      ; preds = %after_if3
  %407 = sdiv i32 %35, 32
  %408 = load ptr, ptr %11, align 8
  %409 = getelementptr inbounds %struct.LLVMRuntime, ptr %408, i64 0, i32 7
  %410 = load ptr, ptr %409, align 8
  %411 = getelementptr inbounds ptr, ptr %410, i64 2
  %412 = load ptr, ptr %411, align 8
  %getch.i = getelementptr %0, ptr %412, i64 0, i32 1
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %3)
  %413 = shl nsw i32 %407, 3
  %414 = sext i32 %413 to i64
  %415 = getelementptr i8, ptr %getch.i, i64 %414
  store volatile ptr %415, ptr %3, align 8
  %416 = getelementptr inbounds i8, ptr %415, i64 32
  %417 = load volatile ptr, ptr %416, align 8
  %418 = icmp eq ptr %417, null
  br i1 %418, label %419, label %Pointer_activate.exit

419:                                              ; preds = %true_block4
  %.0..0..0..0..0..i = load volatile ptr, ptr %3, align 8
  %.0..0..0..0..0.2.i = load volatile ptr, ptr %3, align 8
  br label %420

420:                                              ; preds = %420, %419
  %421 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i, i32 1 seq_cst, align 4
  %422 = icmp eq i32 %421, 1
  br i1 %422, label %420, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i:                        ; preds = %420
  %423 = load volatile ptr, ptr %416, align 8
  %424 = icmp eq ptr %423, null
  br i1 %424, label %425, label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i"

425:                                              ; preds = %mutex_lock_i32.exit.i.i.i
  %426 = load ptr, ptr %11, align 8
  %427 = getelementptr inbounds %struct.LLVMRuntime, ptr %426, i64 0, i32 14
  %428 = load ptr, ptr %427, align 8
  %429 = getelementptr inbounds ptr, ptr %428, i64 20
  %430 = load ptr, ptr %429, align 8
  %431 = getelementptr inbounds %struct.NodeManager, ptr %430, i64 0, i32 4
  %432 = atomicrmw volatile add ptr %431, i32 1 seq_cst, align 4
  %433 = getelementptr inbounds %struct.NodeManager, ptr %430, i64 0, i32 5
  %434 = load ptr, ptr %433, align 8
  %435 = getelementptr inbounds %struct.ListManager, ptr %434, i64 0, i32 5
  %436 = load i32, ptr %435, align 8
  %.not.i.i.i.i.i = icmp slt i32 %432, %436
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i, label %437

437:                                              ; preds = %425
  %438 = getelementptr inbounds %struct.NodeManager, ptr %430, i64 0, i32 7
  %439 = load ptr, ptr %438, align 8
  %440 = getelementptr inbounds %struct.ListManager, ptr %439, i64 0, i32 5
  %441 = atomicrmw volatile add ptr %440, i32 1 seq_cst, align 4
  %442 = getelementptr inbounds %struct.ListManager, ptr %439, i64 0, i32 3
  %443 = load i32, ptr %442, align 8
  %444 = ashr i32 %441, %443
  %445 = icmp ugt i32 %444, 131071
  br i1 %445, label %446, label %449

446:                                              ; preds = %437
  %447 = getelementptr inbounds %struct.ListManager, ptr %439, i64 0, i32 6
  %448 = load ptr, ptr %447, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %448, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

449:                                              ; preds = %437
  %450 = zext i32 %444 to i64
  %451 = lshr i64 %450, 9
  %452 = getelementptr inbounds [256 x ptr], ptr %439, i64 0, i64 %451
  %453 = load atomic i64, ptr %452 acquire, align 8
  %.not.i.i.i4.i.i.i.i.i = icmp eq i64 %453, 0
  br i1 %.not.i.i.i4.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i:  ; preds = %449
  %454 = inttoptr i64 %453 to ptr
  %455 = and i64 %450, 511
  %456 = getelementptr inbounds ptr, ptr %454, i64 %455
  %457 = load atomic i64, ptr %456 acquire, align 8
  %.not.i.i5.i.i.i.i.i = icmp eq i64 %457, 0
  br i1 %.not.i.i5.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i, %449
  %458 = getelementptr inbounds %struct.ListManager, ptr %439, i64 0, i32 4
  br label %459

459:                                              ; preds = %459, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i
  %460 = atomicrmw volatile xchg ptr %458, i32 1 seq_cst, align 4
  %461 = icmp eq i32 %460, 1
  br i1 %461, label %459, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i:          ; preds = %459
  %462 = load atomic i64, ptr %452 acquire, align 8
  %463 = inttoptr i64 %462 to ptr
  %.not.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %462, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i, label %464, label %499

464:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i
  %465 = getelementptr inbounds %struct.ListManager, ptr %439, i64 0, i32 6
  %466 = load ptr, ptr %465, align 8
  %467 = getelementptr inbounds %struct.LLVMRuntime, ptr %466, i64 0, i32 1
  %468 = getelementptr inbounds %struct.LLVMRuntime, ptr %466, i64 0, i32 28
  %469 = atomicrmw volatile add ptr %468, i64 4096 seq_cst, align 8
  %470 = getelementptr inbounds %struct.LLVMRuntime, ptr %466, i64 0, i32 1, i32 2
  %471 = load i64, ptr %470, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %471, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i.i.i, label %492, label %472

472:                                              ; preds = %464
  %473 = getelementptr inbounds %struct.LLVMRuntime, ptr %466, i64 0, i32 26
  br label %474

474:                                              ; preds = %474, %472
  %475 = atomicrmw volatile xchg ptr %473, i32 1 seq_cst, align 4
  %476 = icmp eq i32 %475, 1
  br i1 %476, label %474, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i: ; preds = %474
  %477 = load ptr, ptr %467, align 8
  %478 = ptrtoint ptr %477 to i64
  %479 = getelementptr inbounds %struct.LLVMRuntime, ptr %466, i64 0, i32 1, i32 1
  %480 = load ptr, ptr %479, align 8
  %481 = ptrtoint ptr %480 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %478
  %482 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i, 4095
  %483 = or i64 %482, 4096
  %484 = add i64 %483, %478
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %484, %481
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i, label %485

485:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i
  %486 = add i64 %482, %478
  %487 = inttoptr i64 %486 to ptr
  %488 = getelementptr i8, ptr %477, i64 %482
  %489 = getelementptr inbounds i8, ptr %488, i64 4096
  store ptr %489, ptr %467, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i: ; preds = %485, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i ], [ %487, %485 ]
  %490 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i, true
  %491 = atomicrmw volatile xchg ptr %473, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %466, i1 noundef zeroext %490, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i

492:                                              ; preds = %464
  %493 = getelementptr inbounds %struct.LLVMRuntime, ptr %466, i64 0, i32 2
  %494 = load ptr, ptr %493, align 8
  %495 = getelementptr inbounds %struct.LLVMRuntime, ptr %466, i64 0, i32 6
  %496 = load ptr, ptr %495, align 8
  %497 = tail call noundef ptr %494(ptr noundef %496, i64 noundef 4096, i64 noundef 4096) #0
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i: ; preds = %492, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i ], [ %497, %492 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %498 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %498, ptr %452 release, align 8
  br label %499

499:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %463, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i ]
  %500 = and i32 %444, 511
  %501 = zext i32 %500 to i64
  %502 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i.i.i, i64 %501
  %503 = load atomic i64, ptr %502 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %503, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i.i.i, label %504, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i"

504:                                              ; preds = %499
  %505 = getelementptr inbounds %struct.ListManager, ptr %439, i64 0, i32 6
  %506 = load ptr, ptr %505, align 8
  %507 = getelementptr inbounds %struct.LLVMRuntime, ptr %506, i64 0, i32 1
  %508 = getelementptr inbounds %struct.ListManager, ptr %439, i64 0, i32 2
  %509 = load i64, ptr %508, align 8
  %510 = getelementptr inbounds %struct.ListManager, ptr %439, i64 0, i32 1
  %511 = load i64, ptr %510, align 8
  %512 = mul i64 %511, %509
  %513 = getelementptr inbounds %struct.LLVMRuntime, ptr %506, i64 0, i32 28
  %514 = atomicrmw volatile add ptr %513, i64 %512 seq_cst, align 8
  %515 = getelementptr inbounds %struct.LLVMRuntime, ptr %506, i64 0, i32 1, i32 2
  %516 = load i64, ptr %515, align 8
  %.not.i.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %516, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i, label %536, label %517

517:                                              ; preds = %504
  %518 = getelementptr inbounds %struct.LLVMRuntime, ptr %506, i64 0, i32 26
  br label %519

519:                                              ; preds = %519, %517
  %520 = atomicrmw volatile xchg ptr %518, i32 1 seq_cst, align 4
  %521 = icmp eq i32 %520, 1
  br i1 %521, label %519, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i: ; preds = %519
  %522 = load ptr, ptr %507, align 8
  %523 = ptrtoint ptr %522 to i64
  %524 = getelementptr inbounds %struct.LLVMRuntime, ptr %506, i64 0, i32 1, i32 1
  %525 = load ptr, ptr %524, align 8
  %526 = ptrtoint ptr %525 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %523
  %527 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i, 4095
  %528 = add i64 %527, %512
  %529 = add i64 %528, %523
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %529, %526
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i, label %530

530:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %531 = add i64 %527, %523
  %532 = inttoptr i64 %531 to ptr
  %533 = getelementptr inbounds i8, ptr %522, i64 %528
  store ptr %533, ptr %507, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i: ; preds = %530, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %532, %530 ]
  %534 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %535 = atomicrmw volatile xchg ptr %518, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %506, i1 noundef zeroext %534, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i

536:                                              ; preds = %504
  %537 = getelementptr inbounds %struct.LLVMRuntime, ptr %506, i64 0, i32 2
  %538 = load ptr, ptr %537, align 8
  %539 = getelementptr inbounds %struct.LLVMRuntime, ptr %506, i64 0, i32 6
  %540 = load ptr, ptr %539, align 8
  %541 = tail call noundef ptr %538(ptr noundef %540, i64 noundef %512, i64 noundef 4096) #0
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i: ; preds = %536, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i ], [ %541, %536 ]
  %542 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %542, ptr %502 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i, %499
  %543 = atomicrmw volatile xchg ptr %458, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i:      ; preds = %425
  %544 = getelementptr inbounds %struct.ListManager, ptr %434, i64 0, i32 3
  %545 = load i32, ptr %544, align 8
  %546 = ashr i32 %432, %545
  %547 = sext i32 %546 to i64
  %548 = lshr i64 %547, 9
  %549 = getelementptr inbounds [256 x ptr], ptr %434, i64 0, i64 %548
  %550 = load atomic i64, ptr %549 acquire, align 8
  %.not.i.i.i.i.i.i.i.i = icmp ne i64 %550, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i.i.i.i.i)
  %551 = inttoptr i64 %550 to ptr
  %552 = and i64 %547, 511
  %553 = getelementptr inbounds ptr, ptr %551, i64 %552
  %554 = load atomic i64, ptr %553 acquire, align 8
  %555 = inttoptr i64 %554 to ptr
  %556 = getelementptr inbounds %struct.ListManager, ptr %434, i64 0, i32 1
  %557 = load i64, ptr %556, align 8
  %558 = load i32, ptr %544, align 8
  %notmask.i.i.i.i.i.i.i = shl nsw i32 -1, %558
  %559 = xor i32 %notmask.i.i.i.i.i.i.i, -1
  %560 = and i32 %432, %559
  %561 = sext i32 %560 to i64
  %562 = mul i64 %557, %561
  %563 = getelementptr inbounds i8, ptr %555, i64 %562
  %564 = load i32, ptr %563, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i: ; preds = %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i, %446
  %.0.i.i.i.i.i = phi i32 [ %564, %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i ], [ %441, %446 ], [ %441, %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i ], [ %441, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i" ]
  %565 = getelementptr inbounds %struct.NodeManager, ptr %430, i64 0, i32 7
  %566 = load ptr, ptr %565, align 8
  %567 = getelementptr inbounds %struct.ListManager, ptr %566, i64 0, i32 3
  %568 = load i32, ptr %567, align 8
  %569 = ashr i32 %.0.i.i.i.i.i, %568
  %570 = sext i32 %569 to i64
  %571 = lshr i64 %570, 9
  %572 = getelementptr inbounds [256 x ptr], ptr %566, i64 0, i64 %571
  %573 = load atomic i64, ptr %572 acquire, align 8
  %.not.i.i.i.i.i.i.i = icmp eq i64 %573, 0
  br i1 %.not.i.i.i.i.i.i.i, label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i", label %574

574:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i
  %575 = inttoptr i64 %573 to ptr
  %576 = and i64 %570, 511
  %577 = getelementptr inbounds ptr, ptr %575, i64 %576
  %578 = load atomic i64, ptr %577 acquire, align 8
  %579 = inttoptr i64 %578 to ptr
  br label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i"

"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i":    ; preds = %574, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i
  %580 = phi ptr [ %579, %574 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i ]
  %581 = getelementptr inbounds %struct.ListManager, ptr %566, i64 0, i32 1
  %582 = load i64, ptr %581, align 8
  %583 = load i32, ptr %567, align 8
  %notmask.i.i.i.i.i.i = shl nsw i32 -1, %583
  %584 = xor i32 %notmask.i.i.i.i.i.i, -1
  %585 = and i32 %.0.i.i.i.i.i, %584
  %586 = sext i32 %585 to i64
  %587 = mul i64 %582, %586
  %588 = getelementptr inbounds i8, ptr %580, i64 %587
  %589 = ptrtoint ptr %588 to i64
  %590 = atomicrmw volatile xchg ptr %416, i64 %589 seq_cst, align 8
  br label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i"

"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i": ; preds = %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i", %mutex_lock_i32.exit.i.i.i
  %591 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i, i32 0 seq_cst, align 4
  br label %Pointer_activate.exit

Pointer_activate.exit:                            ; preds = %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i", %true_block4
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %3)
  %592 = lshr i32 %35, 2
  %593 = and i32 %592, 1073741816
  %594 = zext i32 %593 to i64
  %595 = getelementptr i8, ptr %getch.i, i64 %594
  %596 = getelementptr inbounds i8, ptr %595, i64 32
  %597 = load ptr, ptr %596, align 8
  %598 = icmp eq ptr %597, null
  br i1 %598, label %599, label %Pointer_lookup_element.exit

599:                                              ; preds = %Pointer_activate.exit
  %600 = load ptr, ptr %11, align 8
  %601 = getelementptr inbounds %struct.LLVMRuntime, ptr %600, i64 0, i32 15
  %602 = load ptr, ptr %601, align 8
  %603 = getelementptr inbounds ptr, ptr %602, i64 20
  %604 = load ptr, ptr %603, align 8
  br label %Pointer_lookup_element.exit

Pointer_lookup_element.exit:                      ; preds = %599, %Pointer_activate.exit
  %.0.i = phi ptr [ %604, %599 ], [ %597, %Pointer_activate.exit ]
  %605 = and i32 %35, 31
  %606 = getelementptr inbounds i8, ptr %.0.i, i64 32
  %607 = shl nuw i32 1, %605
  %608 = atomicrmw volatile or ptr %606, i32 %607 seq_cst, align 4
  br label %after_if6

after_if6:                                        ; preds = %Pointer_lookup_element.exit, %after_if3
  br i1 %38, label %after_if.sink.split, label %after_if
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_parallel_range_for_task(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #1 {
  %4 = alloca %struct.RuntimeContext.465, align 8
  %.sroa.0.0.copyload = load ptr, ptr %0, align 8
  %.sroa.4.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 8
  %.sroa.4.0.copyload = load ptr, ptr %.sroa.4.0..sroa_idx, align 8
  %.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 16
  %.sroa.5.0.copyload = load ptr, ptr %.sroa.5.0..sroa_idx, align 8
  %.sroa.7.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 24
  %.sroa.7.0.copyload = load ptr, ptr %.sroa.7.0..sroa_idx, align 8
  %.sroa.8.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 32
  %.sroa.8.0.copyload = load i64, ptr %.sroa.8.0..sroa_idx, align 8
  %.sroa.9.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 40
  %.sroa.9.0.copyload = load i32, ptr %.sroa.9.0..sroa_idx, align 8
  %.sroa.12.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 44
  %.sroa.12.0.copyload = load i32, ptr %.sroa.12.0..sroa_idx, align 4
  %.sroa.15.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 48
  %.sroa.15.0.copyload = load i32, ptr %.sroa.15.0..sroa_idx, align 8
  %.sroa.17.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 52
  %.sroa.17.0.copyload = load i32, ptr %.sroa.17.0..sroa_idx, align 4
  %5 = alloca i8, i64 %.sroa.8.0.copyload, align 8
  %.not = icmp eq ptr %.sroa.4.0.copyload, null
  br i1 %.not, label %7, label %6

6:                                                ; preds = %3
  call void %.sroa.4.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #0
  br label %7

7:                                                ; preds = %6, %3
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %4, ptr noundef nonnull align 8 dereferenceable(32) %.sroa.0.0.copyload, i64 32, i1 false)
  %8 = getelementptr inbounds %struct.RuntimeContext.465, ptr %4, i64 0, i32 2
  store i32 %1, ptr %8, align 8
  switch i32 %.sroa.17.0.copyload, label %.loopexit [
    i32 1, label %9
    i32 -1, label %17
  ]

9:                                                ; preds = %7
  %10 = mul nsw i32 %.sroa.15.0.copyload, %2
  %11 = add nsw i32 %10, %.sroa.9.0.copyload
  %12 = add nsw i32 %11, %.sroa.15.0.copyload
  %13 = call i32 @llvm.smin.i32(i32 %.sroa.12.0.copyload, i32 %12)
  %14 = icmp slt i32 %11, %13
  br i1 %14, label %.lr.ph.preheader, label %.loopexit

.lr.ph.preheader:                                 ; preds = %9
  br label %.lr.ph

.lr.ph:                                           ; preds = %.lr.ph, %.lr.ph.preheader
  %.02039 = phi i32 [ %15, %.lr.ph ], [ %11, %.lr.ph.preheader ]
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.02039) #0
  %15 = add nsw i32 %.02039, 1
  %16 = icmp slt i32 %15, %13
  br i1 %16, label %.lr.ph, label %.loopexit.loopexit, !llvm.loop !9

17:                                               ; preds = %7
  %18 = mul nsw i32 %.sroa.15.0.copyload, %2
  %19 = sub nsw i32 %.sroa.12.0.copyload, %18
  %20 = mul nsw i32 %19, %.sroa.15.0.copyload
  %21 = call i32 @llvm.smax.i32(i32 %.sroa.9.0.copyload, i32 %20)
  %.not25.not40 = icmp sgt i32 %19, %21
  br i1 %.not25.not40, label %.lr.ph42.preheader, label %.loopexit

.lr.ph42.preheader:                               ; preds = %17
  br label %.lr.ph42

.lr.ph42:                                         ; preds = %.lr.ph42, %.lr.ph42.preheader
  %.0.in41 = phi i32 [ %.0, %.lr.ph42 ], [ %19, %.lr.ph42.preheader ]
  %.0 = add nsw i32 %.0.in41, -1
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.0) #0
  %.not25.not = icmp sgt i32 %.0, %21
  br i1 %.not25.not, label %.lr.ph42, label %.loopexit.loopexit47, !llvm.loop !10

.loopexit.loopexit:                               ; preds = %.lr.ph
  br label %.loopexit

.loopexit.loopexit47:                             ; preds = %.lr.ph42
  br label %.loopexit

.loopexit:                                        ; preds = %.loopexit.loopexit47, %.loopexit.loopexit, %17, %9, %7
  %.not24 = icmp eq ptr %.sroa.7.0.copyload, null
  br i1 %.not24, label %23, label %22

22:                                               ; preds = %.loopexit
  call void %.sroa.7.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #0
  br label %23

23:                                               ; preds = %22, %.loopexit
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #2

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn writeonly
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #3

; Function Attrs: noinline nounwind optnone uwtable
define internal fastcc void @taichi_assert_format(ptr noundef %0, i1 noundef zeroext %1, ptr noundef %2) unnamed_addr #4 {
  %4 = alloca ptr, align 8
  %5 = alloca i8, align 1
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca ptr, align 8
  %9 = alloca %class.anon, align 8
  store ptr %0, ptr %4, align 8
  %10 = zext i1 %1 to i8
  store i8 %10, ptr %5, align 1
  store ptr %2, ptr %6, align 8
  store i32 0, ptr %7, align 4
  store ptr null, ptr %8, align 8
  %11 = load i8, ptr %5, align 1
  %12 = trunc i8 %11 to i1
  %13 = zext i1 %12 to i32
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %15, label %16

15:                                               ; preds = %3
  br label %69

16:                                               ; preds = %3
  %17 = load ptr, ptr %4, align 8
  %18 = getelementptr inbounds %struct.LLVMRuntime, ptr %17, i32 0, i32 24
  %19 = load i64, ptr %18, align 8
  %20 = icmp ne i64 %19, 0
  br i1 %20, label %69, label %21

21:                                               ; preds = %16
  %22 = load ptr, ptr %4, align 8
  %23 = getelementptr inbounds %struct.LLVMRuntime, ptr %22, i32 0, i32 23
  %24 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 0
  store ptr %4, ptr %24, align 8
  %25 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 1
  store ptr %6, ptr %25, align 8
  %26 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 2
  store ptr %7, ptr %26, align 8
  %27 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 3
  store ptr %8, ptr %27, align 8
  br label %28

28:                                               ; preds = %28, %21
  %29 = atomicrmw volatile xchg ptr %23, i32 1 seq_cst, align 4
  %30 = icmp eq i32 %29, 1
  br i1 %30, label %28, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i:                        ; preds = %28
  %31 = load ptr, ptr %9, align 8
  %32 = load ptr, ptr %31, align 8
  %33 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 24
  %34 = load i64, ptr %33, align 8
  %.not.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i, label %35, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

35:                                               ; preds = %mutex_lock_i32.exit.i.i.i
  store i64 1, ptr %33, align 8
  %36 = load ptr, ptr %9, align 8
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr inbounds %struct.LLVMRuntime, ptr %37, i64 0, i32 21
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %38, i8 0, i64 2048, i1 false)
  %39 = load ptr, ptr %9, align 8
  %40 = load ptr, ptr %39, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 21
  %42 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 1
  %43 = load ptr, ptr %42, align 8
  %44 = load ptr, ptr %43, align 8
  %45 = load i8, ptr %44, align 1
  %.not5.i.i.i.i.i = icmp eq i8 %45, 0
  br i1 %.not5.i.i.i.i.i, label %taichi_strlen.exit.thread.i.i.i.i, label %.lr.ph.i.i.i.i.i.preheader

.lr.ph.i.i.i.i.i.preheader:                       ; preds = %35
  br label %.lr.ph.i.i.i.i.i

.lr.ph.i.i.i.i.i:                                 ; preds = %.lr.ph.i.i.i.i.i, %.lr.ph.i.i.i.i.i.preheader
  %.07.i.i.i.i.i = phi ptr [ %47, %.lr.ph.i.i.i.i.i ], [ %44, %.lr.ph.i.i.i.i.i.preheader ]
  %.046.i.i.i.i.i = phi i64 [ %46, %.lr.ph.i.i.i.i.i ], [ 0, %.lr.ph.i.i.i.i.i.preheader ]
  %46 = add i64 %.046.i.i.i.i.i, 1
  %47 = getelementptr inbounds i8, ptr %.07.i.i.i.i.i, i64 1
  %48 = load i8, ptr %47, align 1
  %.not.i.i.i.i.i = icmp eq i8 %48, 0
  br i1 %.not.i.i.i.i.i, label %taichi_strlen.exit.i.i.i.i, label %.lr.ph.i.i.i.i.i, !llvm.loop !11

taichi_strlen.exit.i.i.i.i:                       ; preds = %.lr.ph.i.i.i.i.i
  %.lcssa = phi i64 [ %46, %.lr.ph.i.i.i.i.i ]
  %49 = call i64 @llvm.umin.i64(i64 %.lcssa, i64 2047)
  br label %taichi_strlen.exit.thread.i.i.i.i

taichi_strlen.exit.thread.i.i.i.i:                ; preds = %taichi_strlen.exit.i.i.i.i, %35
  %50 = phi i64 [ 0, %35 ], [ %49, %taichi_strlen.exit.i.i.i.i ]
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %41, ptr nonnull align 1 %44, i64 %50, i1 false)
  %51 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 2
  %52 = load ptr, ptr %51, align 8
  %53 = load i32, ptr %52, align 4
  %54 = icmp sgt i32 %53, 0
  br i1 %54, label %.lr.ph.i.i.i.i, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

.lr.ph.i.i.i.i:                                   ; preds = %taichi_strlen.exit.thread.i.i.i.i
  %55 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 3
  br label %56

56:                                               ; preds = %56, %.lr.ph.i.i.i.i
  %indvars.iv.i.i.i.i = phi i64 [ 0, %.lr.ph.i.i.i.i ], [ %indvars.iv.next.i.i.i.i, %56 ]
  %57 = load ptr, ptr %55, align 8
  %58 = load ptr, ptr %57, align 8
  %59 = getelementptr inbounds i64, ptr %58, i64 %indvars.iv.i.i.i.i
  %60 = load i64, ptr %59, align 8
  %61 = load ptr, ptr %9, align 8
  %62 = load ptr, ptr %61, align 8
  %63 = getelementptr inbounds %struct.LLVMRuntime, ptr %62, i64 0, i32 22, i64 %indvars.iv.i.i.i.i
  store i64 %60, ptr %63, align 8
  %indvars.iv.next.i.i.i.i = add nuw nsw i64 %indvars.iv.i.i.i.i, 1
  %64 = load ptr, ptr %51, align 8
  %65 = load i32, ptr %64, align 4
  %66 = sext i32 %65 to i64
  %67 = icmp slt i64 %indvars.iv.next.i.i.i.i, %66
  br i1 %67, label %56, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", !llvm.loop !12

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit": ; preds = %56
  br label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit": ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", %taichi_strlen.exit.thread.i.i.i.i, %mutex_lock_i32.exit.i.i.i
  %68 = atomicrmw volatile xchg ptr %23, i32 0 seq_cst, align 4
  br label %69

69:                                               ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit", %16, %15
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #5

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #6

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #6

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i64 @llvm.umin.i64(i64, i64) #7

; Function Attrs: inaccessiblememonly nocallback nofree nosync nounwind willreturn
declare void @llvm.assume(i1 noundef) #8

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smax.i32(i32, i32) #7

attributes #0 = { nounwind }
attributes #1 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #3 = { argmemonly mustprogress nocallback nofree nounwind willreturn writeonly }
attributes #4 = { noinline nounwind optnone uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #6 = { argmemonly nocallback nofree nosync nounwind willreturn }
attributes #7 = { nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #8 = { inaccessiblememonly nocallback nofree nosync nounwind willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7, !8}
!7 = !{!"llvm.loop.mustprogress"}
!8 = !{!"llvm.loop.unroll.disable"}
!9 = distinct !{!9, !7, !8}
!10 = distinct !{!10, !7, !8}
!11 = distinct !{!11, !7, !8}
!12 = distinct !{!12, !7, !8}
