; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind
define void @live_refresh_candidate_44_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 22
  %2 = load i32, ptr %1, align 4
  %3 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 16, i32 1
  %4 = load ptr, ptr %3, align 8
  store i32 0, ptr %4, align 4
  %5 = icmp sgt i32 %2, 0
  br i1 %5, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %entry
  %6 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 11, i32 1
  %7 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 11, i32 0, i32 1
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 1, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 4, i32 1
  %10 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 3, i32 1
  %11 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 3, i32 0, i32 1
  %12 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 5, i32 1
  %13 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 5, i32 0, i32 1
  %14 = getelementptr { { i32, i32 }, ptr }, ptr %0, i64 0, i32 1
  %15 = getelementptr { { i32, i32 }, ptr }, ptr %0, i64 0, i32 0, i32 1
  %16 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 2, i32 1
  %17 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 2, i32 0, i32 1
  %18 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 6, i32 1
  %19 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 6, i32 0, i32 1
  %20 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 7, i32 1
  %21 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 8, i32 1
  %22 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 14, i32 1
  %23 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 12, i32 1
  %24 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 12, i32 0, i32 1
  %25 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 13, i32 1
  %26 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 13, i32 0, i32 1
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 9, i32 1
  %28 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 9, i32 0, i32 1
  %29 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 10, i32 1
  %30 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 15, i32 1
  %wide.trip.count217 = zext i32 %2 to i64
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if39, %for_loop_body.lr.ph
  %indvars.iv214 = phi i64 [ 0, %for_loop_body.lr.ph ], [ %indvars.iv.next215, %after_if39 ]
  %31 = load ptr, ptr %6, align 8
  %32 = load i32, ptr %7, align 4
  %33 = sext i32 %32 to i64
  %34 = shl nsw i64 %33, 1
  %35 = add nsw i64 %34, %indvars.iv214
  %36 = getelementptr i32, ptr %31, i64 %35
  %37 = load i32, ptr %36, align 4
  %38 = sext i32 %37 to i64
  %39 = getelementptr i32, ptr %31, i64 %38
  %40 = load i32, ptr %39, align 4
  %41 = icmp sgt i32 %40, -1
  br i1 %41, label %true_block, label %after_if

after_for.loopexit:                               ; preds = %after_if39
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %entry
  ret void

true_block:                                       ; preds = %for_loop_body
  %42 = load ptr, ptr %8, align 8
  %43 = zext i32 %40 to i64
  %44 = getelementptr i32, ptr %42, i64 %43
  %45 = load i32, ptr %44, align 4
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %.0115 = phi i32 [ %45, %true_block ], [ 0, %for_loop_body ]
  %46 = load ptr, ptr %9, align 8
  %47 = getelementptr i32, ptr %46, i64 %38
  store i32 %.0115, ptr %47, align 4
  %48 = load ptr, ptr %6, align 8
  %49 = load i32, ptr %7, align 4
  %50 = sext i32 %49 to i64
  %51 = shl nsw i64 %50, 2
  %52 = add nsw i64 %51, %38
  %53 = getelementptr i32, ptr %48, i64 %52
  store i32 0, ptr %53, align 4
  br i1 %41, label %true_block34, label %after_if33

after_if33:                                       ; preds = %after_if
  %54 = load ptr, ptr %10, align 8
  %55 = getelementptr double, ptr %54, i64 %38
  store double 0.000000e+00, ptr %55, align 8
  %56 = load ptr, ptr %10, align 8
  %57 = load i32, ptr %11, align 4
  %58 = sext i32 %57 to i64
  %59 = add nsw i64 %58, %38
  %60 = getelementptr double, ptr %56, i64 %59
  store double 0.000000e+00, ptr %60, align 8
  %61 = load ptr, ptr %10, align 8
  %62 = load i32, ptr %11, align 4
  %63 = sext i32 %62 to i64
  %64 = shl nsw i64 %63, 1
  %65 = add nsw i64 %64, %38
  %66 = getelementptr double, ptr %61, i64 %65
  store double 0.000000e+00, ptr %66, align 8
  %67 = load ptr, ptr %10, align 8
  %68 = load i32, ptr %11, align 4
  %69 = sext i32 %68 to i64
  %70 = mul nsw i64 %69, 3
  %71 = add nsw i64 %70, %38
  %72 = getelementptr double, ptr %67, i64 %71
  store double 0.000000e+00, ptr %72, align 8
  %73 = load ptr, ptr %10, align 8
  %74 = load i32, ptr %11, align 4
  %75 = sext i32 %74 to i64
  %76 = shl nsw i64 %75, 2
  %77 = add nsw i64 %76, %38
  %78 = getelementptr double, ptr %73, i64 %77
  store double 0.000000e+00, ptr %78, align 8
  %79 = load ptr, ptr %10, align 8
  %80 = load i32, ptr %11, align 4
  %81 = sext i32 %80 to i64
  %82 = mul nsw i64 %81, 5
  %83 = add nsw i64 %82, %38
  %84 = getelementptr double, ptr %79, i64 %83
  store double 0.000000e+00, ptr %84, align 8
  %85 = load ptr, ptr %10, align 8
  %86 = load i32, ptr %11, align 4
  %87 = sext i32 %86 to i64
  %88 = mul nsw i64 %87, 6
  %89 = add nsw i64 %88, %38
  %90 = getelementptr double, ptr %85, i64 %89
  store double 0.000000e+00, ptr %90, align 8
  %91 = load ptr, ptr %10, align 8
  %92 = load i32, ptr %11, align 4
  %93 = sext i32 %92 to i64
  %94 = mul nsw i64 %93, 7
  %95 = add nsw i64 %94, %38
  %96 = getelementptr double, ptr %91, i64 %95
  store double 0.000000e+00, ptr %96, align 8
  %97 = load ptr, ptr %12, align 8
  %98 = getelementptr double, ptr %97, i64 %38
  store double 0.000000e+00, ptr %98, align 8
  %99 = load ptr, ptr %12, align 8
  %100 = load i32, ptr %13, align 4
  %101 = sext i32 %100 to i64
  %102 = add nsw i64 %101, %38
  %103 = getelementptr double, ptr %99, i64 %102
  store double 0.000000e+00, ptr %103, align 8
  %104 = load ptr, ptr %12, align 8
  %105 = load i32, ptr %13, align 4
  %106 = sext i32 %105 to i64
  %107 = shl nsw i64 %106, 1
  %108 = add nsw i64 %107, %38
  %109 = getelementptr double, ptr %104, i64 %108
  store double 0.000000e+00, ptr %109, align 8
  br label %after_if36

true_block34:                                     ; preds = %after_if
  %110 = load ptr, ptr %14, align 8
  %111 = zext i32 %40 to i64
  %112 = getelementptr double, ptr %110, i64 %111
  %113 = load double, ptr %112, align 8
  %114 = load ptr, ptr %10, align 8
  %115 = getelementptr double, ptr %114, i64 %38
  store double %113, ptr %115, align 8
  %116 = load ptr, ptr %14, align 8
  %117 = load i32, ptr %15, align 4
  %118 = sext i32 %117 to i64
  %119 = add nsw i64 %118, %111
  %120 = getelementptr double, ptr %116, i64 %119
  %121 = load double, ptr %120, align 8
  %122 = load ptr, ptr %10, align 8
  %123 = load i32, ptr %11, align 4
  %124 = sext i32 %123 to i64
  %125 = add nsw i64 %124, %38
  %126 = getelementptr double, ptr %122, i64 %125
  store double %121, ptr %126, align 8
  %127 = load ptr, ptr %14, align 8
  %128 = load i32, ptr %15, align 4
  %129 = sext i32 %128 to i64
  %130 = shl nsw i64 %129, 1
  %131 = add nsw i64 %130, %111
  %132 = getelementptr double, ptr %127, i64 %131
  %133 = load double, ptr %132, align 8
  %134 = load ptr, ptr %10, align 8
  %135 = load i32, ptr %11, align 4
  %136 = sext i32 %135 to i64
  %137 = shl nsw i64 %136, 1
  %138 = add nsw i64 %137, %38
  %139 = getelementptr double, ptr %134, i64 %138
  store double %133, ptr %139, align 8
  %140 = load ptr, ptr %14, align 8
  %141 = load i32, ptr %15, align 4
  %142 = sext i32 %141 to i64
  %143 = mul nsw i64 %142, 3
  %144 = add nsw i64 %143, %111
  %145 = getelementptr double, ptr %140, i64 %144
  %146 = load double, ptr %145, align 8
  %147 = load ptr, ptr %10, align 8
  %148 = load i32, ptr %11, align 4
  %149 = sext i32 %148 to i64
  %150 = mul nsw i64 %149, 3
  %151 = add nsw i64 %150, %38
  %152 = getelementptr double, ptr %147, i64 %151
  store double %146, ptr %152, align 8
  %153 = load ptr, ptr %14, align 8
  %154 = load i32, ptr %15, align 4
  %155 = sext i32 %154 to i64
  %156 = shl nsw i64 %155, 2
  %157 = add nsw i64 %156, %111
  %158 = getelementptr double, ptr %153, i64 %157
  %159 = load double, ptr %158, align 8
  %160 = load ptr, ptr %10, align 8
  %161 = load i32, ptr %11, align 4
  %162 = sext i32 %161 to i64
  %163 = shl nsw i64 %162, 2
  %164 = add nsw i64 %163, %38
  %165 = getelementptr double, ptr %160, i64 %164
  store double %159, ptr %165, align 8
  %166 = load ptr, ptr %14, align 8
  %167 = load i32, ptr %15, align 4
  %168 = sext i32 %167 to i64
  %169 = mul nsw i64 %168, 5
  %170 = add nsw i64 %169, %111
  %171 = getelementptr double, ptr %166, i64 %170
  %172 = load double, ptr %171, align 8
  %173 = load ptr, ptr %10, align 8
  %174 = load i32, ptr %11, align 4
  %175 = sext i32 %174 to i64
  %176 = mul nsw i64 %175, 5
  %177 = add nsw i64 %176, %38
  %178 = getelementptr double, ptr %173, i64 %177
  store double %172, ptr %178, align 8
  %179 = load ptr, ptr %14, align 8
  %180 = load i32, ptr %15, align 4
  %181 = sext i32 %180 to i64
  %182 = mul nsw i64 %181, 6
  %183 = add nsw i64 %182, %111
  %184 = getelementptr double, ptr %179, i64 %183
  %185 = load double, ptr %184, align 8
  %186 = load ptr, ptr %10, align 8
  %187 = load i32, ptr %11, align 4
  %188 = sext i32 %187 to i64
  %189 = mul nsw i64 %188, 6
  %190 = add nsw i64 %189, %38
  %191 = getelementptr double, ptr %186, i64 %190
  store double %185, ptr %191, align 8
  %192 = load ptr, ptr %14, align 8
  %193 = load i32, ptr %15, align 4
  %194 = sext i32 %193 to i64
  %195 = mul nsw i64 %194, 7
  %196 = add nsw i64 %195, %111
  %197 = getelementptr double, ptr %192, i64 %196
  %198 = load double, ptr %197, align 8
  %199 = load ptr, ptr %10, align 8
  %200 = load i32, ptr %11, align 4
  %201 = sext i32 %200 to i64
  %202 = mul nsw i64 %201, 7
  %203 = add nsw i64 %202, %38
  %204 = getelementptr double, ptr %199, i64 %203
  store double %198, ptr %204, align 8
  %205 = load ptr, ptr %16, align 8
  %206 = getelementptr double, ptr %205, i64 %111
  %207 = load double, ptr %206, align 8
  %208 = load ptr, ptr %12, align 8
  %209 = getelementptr double, ptr %208, i64 %38
  store double %207, ptr %209, align 8
  %210 = load ptr, ptr %16, align 8
  %211 = load i32, ptr %17, align 4
  %212 = sext i32 %211 to i64
  %213 = add nsw i64 %212, %111
  %214 = getelementptr double, ptr %210, i64 %213
  %215 = load double, ptr %214, align 8
  %216 = load ptr, ptr %12, align 8
  %217 = load i32, ptr %13, align 4
  %218 = sext i32 %217 to i64
  %219 = add nsw i64 %218, %38
  %220 = getelementptr double, ptr %216, i64 %219
  store double %215, ptr %220, align 8
  %221 = load ptr, ptr %16, align 8
  %222 = load i32, ptr %17, align 4
  %223 = sext i32 %222 to i64
  %224 = shl nsw i64 %223, 1
  %225 = add nsw i64 %224, %111
  %226 = getelementptr double, ptr %221, i64 %225
  %227 = load double, ptr %226, align 8
  %228 = load ptr, ptr %12, align 8
  %229 = load i32, ptr %13, align 4
  %230 = sext i32 %229 to i64
  %231 = shl nsw i64 %230, 1
  %232 = add nsw i64 %231, %38
  %233 = getelementptr double, ptr %228, i64 %232
  store double %227, ptr %233, align 8
  %234 = load ptr, ptr %16, align 8
  %235 = load i32, ptr %17, align 4
  %236 = sext i32 %235 to i64
  %237 = mul nsw i64 %236, 3
  %238 = add nsw i64 %237, %111
  %239 = getelementptr double, ptr %234, i64 %238
  %240 = load double, ptr %239, align 8
  br label %after_if36

after_if36:                                       ; preds = %true_block34, %after_if33
  %241 = phi ptr [ %233, %true_block34 ], [ %109, %after_if33 ]
  %242 = phi ptr [ %209, %true_block34 ], [ %98, %after_if33 ]
  %243 = phi ptr [ %191, %true_block34 ], [ %90, %after_if33 ]
  %244 = phi ptr [ %165, %true_block34 ], [ %78, %after_if33 ]
  %245 = phi ptr [ %139, %true_block34 ], [ %66, %after_if33 ]
  %246 = phi ptr [ %115, %true_block34 ], [ %55, %after_if33 ]
  %247 = phi ptr [ %126, %true_block34 ], [ %60, %after_if33 ]
  %248 = phi ptr [ %152, %true_block34 ], [ %72, %after_if33 ]
  %249 = phi ptr [ %178, %true_block34 ], [ %84, %after_if33 ]
  %250 = phi ptr [ %204, %true_block34 ], [ %96, %after_if33 ]
  %251 = phi ptr [ %220, %true_block34 ], [ %103, %after_if33 ]
  %.0103 = phi double [ %240, %true_block34 ], [ 0.000000e+00, %after_if33 ]
  %252 = load ptr, ptr %12, align 8
  %253 = load i32, ptr %13, align 4
  %254 = sext i32 %253 to i64
  %255 = mul nsw i64 %254, 3
  %256 = add nsw i64 %255, %38
  %257 = getelementptr double, ptr %252, i64 %256
  store double %.0103, ptr %257, align 8
  %258 = load ptr, ptr %6, align 8
  %259 = load i32, ptr %7, align 4
  %260 = sext i32 %259 to i64
  %261 = add nsw i64 %260, %38
  %262 = getelementptr i32, ptr %258, i64 %261
  %263 = load i32, ptr %262, align 4
  %.not = icmp eq i32 %263, 0
  br i1 %.not, label %after_if36.after_if39_crit_edge, label %true_block37

after_if36.after_if39_crit_edge:                  ; preds = %after_if36
  %.pre229 = shl i32 %.0115, 2
  %.pre231 = sext i32 %.pre229 to i64
  %.pre233 = or i32 %.pre229, 1
  %.pre235 = sext i32 %.pre233 to i64
  %.pre237 = or i32 %.pre229, 2
  %.pre239 = sext i32 %.pre237 to i64
  %.pre241 = or i32 %.pre229, 3
  %.pre243 = sext i32 %.pre241 to i64
  br label %after_if39

true_block37:                                     ; preds = %after_if36
  %264 = load ptr, ptr %18, align 8
  %265 = load i32, ptr %19, align 4
  %266 = sext i32 %265 to i64
  %267 = shl nsw i64 %266, 1
  %268 = add nsw i64 %267, %38
  %269 = getelementptr i32, ptr %264, i64 %268
  %270 = load i32, ptr %269, align 4
  %.not128 = icmp eq i32 %270, 0
  br i1 %.not128, label %false_block41, label %true_block40

after_if39:                                       ; preds = %true_block132, %after_if131, %after_if36.after_if39_crit_edge
  %.pre-phi244 = phi i64 [ %.pre243, %after_if36.after_if39_crit_edge ], [ %627, %true_block132 ], [ %627, %after_if131 ]
  %.pre-phi240 = phi i64 [ %.pre239, %after_if36.after_if39_crit_edge ], [ %609, %true_block132 ], [ %609, %after_if131 ]
  %.pre-phi236 = phi i64 [ %.pre235, %after_if36.after_if39_crit_edge ], [ %591, %true_block132 ], [ %591, %after_if131 ]
  %.pre-phi232 = phi i64 [ %.pre231, %after_if36.after_if39_crit_edge ], [ %572, %true_block132 ], [ %572, %after_if131 ]
  %271 = load ptr, ptr %18, align 8
  %272 = load i32, ptr %19, align 4
  %273 = sext i32 %272 to i64
  %274 = mul nsw i64 %273, 5
  %275 = add nsw i64 %274, %38
  %276 = getelementptr i32, ptr %271, i64 %275
  %277 = load i32, ptr %276, align 4
  %278 = load ptr, ptr %10, align 8
  %279 = load i32, ptr %11, align 4
  %280 = sext i32 %279 to i64
  %281 = mul nsw i64 %.pre-phi232, %280
  %282 = add i64 %281, %38
  %283 = getelementptr double, ptr %278, i64 %282
  %284 = load double, ptr %283, align 8
  %285 = load ptr, ptr %30, align 8
  %286 = sext i32 %277 to i64
  %287 = getelementptr double, ptr %285, i64 %286
  store double %284, ptr %287, align 8
  %288 = add i32 %277, 70
  %289 = load ptr, ptr %10, align 8
  %290 = load i32, ptr %11, align 4
  %291 = sext i32 %290 to i64
  %292 = mul nsw i64 %.pre-phi236, %291
  %293 = add i64 %292, %38
  %294 = getelementptr double, ptr %289, i64 %293
  %295 = load double, ptr %294, align 8
  %296 = load ptr, ptr %30, align 8
  %297 = sext i32 %288 to i64
  %298 = getelementptr double, ptr %296, i64 %297
  store double %295, ptr %298, align 8
  %299 = add i32 %277, 140
  %300 = load ptr, ptr %10, align 8
  %301 = load i32, ptr %11, align 4
  %302 = sext i32 %301 to i64
  %303 = mul nsw i64 %.pre-phi240, %302
  %304 = add i64 %303, %38
  %305 = getelementptr double, ptr %300, i64 %304
  %306 = load double, ptr %305, align 8
  %307 = load ptr, ptr %30, align 8
  %308 = sext i32 %299 to i64
  %309 = getelementptr double, ptr %307, i64 %308
  store double %306, ptr %309, align 8
  %310 = add i32 %277, 210
  %311 = load ptr, ptr %10, align 8
  %312 = load i32, ptr %11, align 4
  %313 = sext i32 %312 to i64
  %314 = mul nsw i64 %.pre-phi244, %313
  %315 = add i64 %314, %38
  %316 = getelementptr double, ptr %311, i64 %315
  %317 = load double, ptr %316, align 8
  %318 = load ptr, ptr %30, align 8
  %319 = sext i32 %310 to i64
  %320 = getelementptr double, ptr %318, i64 %319
  store double %317, ptr %320, align 8
  %indvars.iv.next215 = add nuw nsw i64 %indvars.iv214, 1
  %exitcond218.not = icmp eq i64 %indvars.iv.next215, %wide.trip.count217
  br i1 %exitcond218.not, label %after_for.loopexit, label %for_loop_body

true_block40:                                     ; preds = %true_block37
  %321 = add nsw i64 %266, %38
  %322 = getelementptr i32, ptr %264, i64 %321
  %323 = load i32, ptr %322, align 4
  %324 = load i32, ptr %4, align 4
  %325 = icmp sgt i32 %270, 0
  br i1 %325, label %for_loop_body43.lr.ph, label %after_if42

for_loop_body43.lr.ph:                            ; preds = %true_block40
  %326 = load ptr, ptr %20, align 8
  %327 = load ptr, ptr %9, align 8
  %328 = load ptr, ptr %10, align 8
  %329 = load i32, ptr %11, align 4
  %330 = sext i32 %329 to i64
  %wide.trip.count = zext i32 %270 to i64
  %331 = zext i32 %323 to i64
  br label %for_loop_body43

false_block41:                                    ; preds = %true_block37
  %332 = mul nsw i64 %266, 3
  %333 = add nsw i64 %332, %38
  %334 = getelementptr i32, ptr %264, i64 %333
  %335 = load i32, ptr %334, align 4
  %336 = shl nsw i64 %266, 2
  %337 = add nsw i64 %336, %38
  %338 = getelementptr i32, ptr %264, i64 %337
  %339 = load i32, ptr %338, align 4
  %340 = load i32, ptr %4, align 4
  %341 = icmp sgt i32 %339, 0
  br i1 %341, label %for_loop_body71.lr.ph, label %after_if42

for_loop_body71.lr.ph:                            ; preds = %false_block41
  %342 = load ptr, ptr %21, align 8
  %343 = load ptr, ptr %22, align 8
  %344 = load ptr, ptr %27, align 8
  %345 = load i32, ptr %28, align 4
  %346 = sext i32 %345 to i64
  %wide.trip.count212 = zext i32 %339 to i64
  %347 = zext i32 %335 to i64
  br label %for_loop_body71

after_if42.loopexit:                              ; preds = %after_if86
  br label %after_if42

after_if42.loopexit289:                           ; preds = %for_loop_body43
  br label %after_if42

after_if42:                                       ; preds = %after_if42.loopexit289, %after_if42.loopexit, %false_block41, %true_block40
  %storemerge = phi i32 [ %340, %false_block41 ], [ %324, %true_block40 ], [ %.5, %after_if42.loopexit ], [ %.575, %after_if42.loopexit289 ]
  %.0100 = phi double [ 0.000000e+00, %false_block41 ], [ 0.000000e+00, %true_block40 ], [ %566, %after_if42.loopexit ], [ %460, %after_if42.loopexit289 ]
  %.087 = phi double [ 0.000000e+00, %false_block41 ], [ 0.000000e+00, %true_block40 ], [ %.491, %after_if42.loopexit ], [ %.289, %after_if42.loopexit289 ]
  %.084 = phi double [ 0.000000e+00, %false_block41 ], [ 0.000000e+00, %true_block40 ], [ %557, %after_if42.loopexit ], [ %433, %after_if42.loopexit289 ]
  %348 = phi <2 x double> [ zeroinitializer, %false_block41 ], [ zeroinitializer, %true_block40 ], [ %560, %after_if42.loopexit ], [ %454, %after_if42.loopexit289 ]
  %349 = phi <2 x double> [ zeroinitializer, %false_block41 ], [ zeroinitializer, %true_block40 ], [ %565, %after_if42.loopexit ], [ %459, %after_if42.loopexit289 ]
  %350 = insertelement <2 x double> poison, double %.0100, i64 0
  %351 = shufflevector <2 x double> %350, <2 x double> poison, <2 x i32> zeroinitializer
  %352 = fdiv <2 x double> %349, %351
  %353 = fdiv double %.084, %.0100
  %354 = fadd double %.087, %353
  %355 = bitcast double %354 to i64
  %356 = or i32 %storemerge, 1
  %357 = fadd <2 x double> %348, %352
  %358 = bitcast <2 x double> %357 to <2 x i64>
  %359 = and <2 x i64> %358, <i64 9223372036854775807, i64 9223372036854775807>
  %360 = icmp eq <2 x i64> %359, zeroinitializer
  %361 = extractelement <2 x i1> %360, i64 1
  %362 = extractelement <2 x i64> %358, i64 1
  %363 = and <2 x i64> %358, <i64 9218868437227405312, i64 9218868437227405312>
  %shuffle = shufflevector <2 x i64> %363, <2 x i64> poison, <4 x i32> <i32 0, i32 0, i32 1, i32 1>
  %364 = icmp ne <4 x i64> %shuffle, <i64 9218868437227405312, i64 0, i64 9218868437227405312, i64 0>
  %shift = shufflevector <4 x i1> %364, <4 x i1> poison, <4 x i32> <i32 undef, i32 undef, i32 3, i32 undef>
  %365 = and <4 x i1> %shift, %364
  %366 = extractelement <4 x i1> %365, i64 2
  %367 = or i1 %361, %366
  %not. = xor i1 %367, true
  %368 = zext i1 %not. to i32
  %spec.select = or i32 %storemerge, %368
  store i32 %spec.select, ptr %4, align 4
  %369 = load ptr, ptr %29, align 8
  %370 = getelementptr i64, ptr %369, i64 %38
  %371 = load i64, ptr %370, align 8
  %372 = and i64 %371, %362
  %373 = bitcast i64 %372 to double
  %374 = and i64 %371, %355
  %375 = bitcast i64 %374 to double
  %shift271 = shufflevector <4 x i1> %364, <4 x i1> poison, <4 x i32> <i32 1, i32 undef, i32 undef, i32 undef>
  %376 = and <4 x i1> %shift271, %364
  %377 = extractelement <4 x i1> %376, i64 0
  %378 = extractelement <2 x i1> %360, i64 0
  %379 = or i1 %378, %377
  %380 = extractelement <2 x i64> %358, i64 0
  %381 = and i64 %371, %380
  %382 = bitcast i64 %381 to double
  %383 = xor i1 %41, true
  %384 = insertelement <2 x i64> poison, i64 %355, i64 0
  %385 = insertelement <2 x i64> %384, i64 %372, i64 1
  %386 = and <2 x i64> %385, <i64 9223372036854775807, i64 9223372036854775807>
  %387 = and <2 x i64> %385, <i64 9218868437227405312, i64 9218868437227405312>
  %388 = icmp eq <2 x i64> %386, zeroinitializer
  %389 = icmp ne <2 x i64> %387, <i64 9218868437227405312, i64 0>
  %390 = icmp ne <2 x i64> %387, <i64 0, i64 9218868437227405312>
  %391 = and <2 x i1> %389, %390
  %392 = or <2 x i1> %388, %391
  %393 = extractelement <2 x i1> %392, i64 0
  %394 = select i1 %393, i32 %spec.select, i32 %356
  %.demorgan = and i1 %393, %379
  %395 = extractelement <2 x i1> %392, i64 1
  %396 = select i1 %395, i1 %379, i1 false
  %narrow259 = xor i1 %396, true
  %spec.select257.v = zext i1 %narrow259 to i32
  %spec.select257 = or i32 %394, %spec.select257.v
  %.demorgan261 = and i1 %.demorgan, %395
  br i1 %.demorgan261, label %568, label %567

for_loop_body43:                                  ; preds = %for_loop_body43, %for_loop_body43.lr.ph
  %indvars.iv = phi i64 [ 0, %for_loop_body43.lr.ph ], [ %indvars.iv.next, %for_loop_body43 ]
  %.070173 = phi i32 [ %324, %for_loop_body43.lr.ph ], [ %.575, %for_loop_body43 ]
  %.185170 = phi double [ 0.000000e+00, %for_loop_body43.lr.ph ], [ %433, %for_loop_body43 ]
  %.188169 = phi double [ 0.000000e+00, %for_loop_body43.lr.ph ], [ %.289, %for_loop_body43 ]
  %.1101166 = phi double [ 0.000000e+00, %for_loop_body43.lr.ph ], [ %460, %for_loop_body43 ]
  %397 = phi <2 x double> [ zeroinitializer, %for_loop_body43.lr.ph ], [ %454, %for_loop_body43 ]
  %398 = phi <2 x double> [ zeroinitializer, %for_loop_body43.lr.ph ], [ %459, %for_loop_body43 ]
  %399 = add nuw nsw i64 %331, %indvars.iv
  %tmp = trunc i64 %399 to i32
  %400 = sext i32 %tmp to i64
  %401 = getelementptr i32, ptr %326, i64 %400
  %402 = load i32, ptr %401, align 4
  %403 = sext i32 %402 to i64
  %404 = getelementptr i32, ptr %327, i64 %403
  %405 = load i32, ptr %404, align 4
  %406 = shl i32 %405, 2
  %407 = sext i32 %406 to i64
  %408 = mul nsw i64 %330, %407
  %409 = add nsw i64 %408, %403
  %410 = getelementptr double, ptr %328, i64 %409
  %411 = or i32 %406, 1
  %412 = sext i32 %411 to i64
  %413 = mul nsw i64 %412, %330
  %414 = add nsw i64 %413, %403
  %415 = getelementptr double, ptr %328, i64 %414
  %416 = or i32 %406, 2
  %417 = sext i32 %416 to i64
  %418 = mul nsw i64 %417, %330
  %419 = add nsw i64 %418, %403
  %420 = getelementptr double, ptr %328, i64 %419
  %421 = or i32 %406, 3
  %422 = sext i32 %421 to i64
  %423 = mul nsw i64 %422, %330
  %424 = add nsw i64 %423, %403
  %425 = getelementptr double, ptr %328, i64 %424
  %426 = load double, ptr %415, align 8
  %427 = load double, ptr %425, align 8
  %428 = insertelement <4 x double> poison, double %427, i64 0
  %429 = fcmp ole double %427, 0.000000e+00
  %430 = icmp eq i64 %indvars.iv, 0
  %.289 = select i1 %430, double %426, double %.188169
  %431 = fsub double %426, %.289
  %432 = fmul double %427, %431
  %433 = fadd double %.185170, %432
  %434 = load double, ptr %410, align 8
  %435 = load double, ptr %420, align 8
  %436 = insertelement <4 x double> %428, double %435, i64 1
  %437 = insertelement <4 x double> %436, double %426, i64 2
  %438 = insertelement <4 x double> %437, double %434, i64 3
  %439 = bitcast <4 x double> %438 to <4 x i64>
  %440 = and <4 x i64> %439, <i64 9223372036854775807, i64 9223372036854775807, i64 9223372036854775807, i64 9223372036854775807>
  %441 = and <4 x i64> %439, <i64 9218868437227405312, i64 9218868437227405312, i64 9218868437227405312, i64 9218868437227405312>
  %442 = icmp eq <4 x i64> %440, zeroinitializer
  %443 = icmp ne <4 x i64> %441, <i64 0, i64 9218868437227405312, i64 0, i64 9218868437227405312>
  %444 = icmp ne <4 x i64> %441, <i64 9218868437227405312, i64 0, i64 9218868437227405312, i64 0>
  %445 = and <4 x i1> %444, %443
  %446 = or <4 x i1> %442, %445
  %447 = freeze <4 x i1> %446
  %448 = bitcast <4 x i1> %447 to i4
  %449 = icmp ne i4 %448, -1
  %op.rdx270 = select i1 %449, i1 true, i1 %429
  %.575.v = zext i1 %op.rdx270 to i32
  %.575 = or i32 %.070173, %.575.v
  %450 = insertelement <2 x i1> poison, i1 %430, i64 0
  %451 = shufflevector <2 x i1> %450, <2 x i1> poison, <2 x i32> zeroinitializer
  %452 = insertelement <2 x double> poison, double %435, i64 0
  %453 = insertelement <2 x double> %452, double %434, i64 1
  %454 = select <2 x i1> %451, <2 x double> %453, <2 x double> %397
  %455 = fsub <2 x double> %453, %454
  %456 = insertelement <2 x double> poison, double %427, i64 0
  %457 = shufflevector <2 x double> %456, <2 x double> poison, <2 x i32> zeroinitializer
  %458 = fmul <2 x double> %457, %455
  %459 = fadd <2 x double> %398, %458
  %460 = fadd double %.1101166, %427
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %wide.trip.count, %indvars.iv.next
  br i1 %exitcond.not, label %after_if42.loopexit289, label %for_loop_body43, !llvm.loop !6

for_loop_body71:                                  ; preds = %after_if86, %for_loop_body71.lr.ph
  %indvars.iv209 = phi i64 [ 0, %for_loop_body71.lr.ph ], [ %indvars.iv.next210, %after_if86 ]
  %.068189 = phi i32 [ %340, %for_loop_body71.lr.ph ], [ %.5, %after_if86 ]
  %.286186 = phi double [ 0.000000e+00, %for_loop_body71.lr.ph ], [ %557, %after_if86 ]
  %.390185 = phi double [ 0.000000e+00, %for_loop_body71.lr.ph ], [ %.491, %after_if86 ]
  %.2102182 = phi double [ 0.000000e+00, %for_loop_body71.lr.ph ], [ %566, %after_if86 ]
  %461 = phi <2 x double> [ zeroinitializer, %for_loop_body71.lr.ph ], [ %560, %after_if86 ]
  %462 = phi <2 x double> [ zeroinitializer, %for_loop_body71.lr.ph ], [ %565, %after_if86 ]
  %463 = add nuw nsw i64 %347, %indvars.iv209
  %tmp290 = trunc i64 %463 to i32
  %464 = sext i32 %tmp290 to i64
  %465 = getelementptr i32, ptr %342, i64 %464
  %466 = load i32, ptr %465, align 4
  %467 = sext i32 %466 to i64
  %468 = getelementptr i32, ptr %343, i64 %467
  %469 = load i32, ptr %468, align 4
  %470 = icmp sgt i32 %469, 1
  br i1 %470, label %true_block84, label %false_block85

true_block84:                                     ; preds = %for_loop_body71
  %471 = add nsw i32 %469, -2
  %472 = load ptr, ptr %25, align 8
  %473 = zext i32 %471 to i64
  %474 = getelementptr double, ptr %472, i64 %473
  %475 = load i64, ptr %474, align 8
  %476 = load i32, ptr %26, align 4
  %477 = sext i32 %476 to i64
  %478 = add nsw i64 %477, %473
  %479 = getelementptr double, ptr %472, i64 %478
  %480 = load i64, ptr %479, align 8
  %481 = and i64 %480, 9218868437227405312
  %482 = icmp ne i64 %481, 9218868437227405312
  %483 = select i1 %482, i64 %480, i64 0
  %484 = and i64 %483, 9218868437227405312
  %485 = icmp ne i64 %484, 9218868437227405312
  %486 = and i1 %482, %485
  %.op129 = and i64 %483, -17592186044416
  %487 = bitcast i64 %.op129 to double
  %488 = select i1 %486, double %487, double 0.000000e+00
  %489 = shl nsw i64 %477, 1
  %490 = add nsw i64 %489, %473
  %491 = getelementptr double, ptr %472, i64 %490
  %492 = load i64, ptr %491, align 8
  %493 = and i64 %492, 9218868437227405312
  %494 = icmp ne i64 %493, 9218868437227405312
  %495 = select i1 %494, i64 %492, i64 0
  %496 = insertelement <2 x i64> poison, i64 %495, i64 0
  %497 = insertelement <2 x i64> %496, i64 %475, i64 1
  %498 = and <2 x i64> %497, <i64 9218868437227405312, i64 9218868437227405312>
  %499 = icmp ne <2 x i64> %498, <i64 9218868437227405312, i64 9218868437227405312>
  %500 = extractelement <2 x i1> %499, i64 1
  %501 = select i1 %500, i64 %475, i64 0
  %502 = and i64 %501, 9218868437227405312
  %503 = icmp ne i64 %502, 9218868437227405312
  %504 = insertelement <2 x i1> poison, i1 %494, i64 0
  %505 = insertelement <2 x i1> %504, i1 %503, i64 1
  %506 = and <2 x i1> %499, %505
  %507 = insertelement <2 x i64> %496, i64 %501, i64 1
  %508 = and <2 x i64> %507, <i64 -17592186044416, i64 -17592186044416>
  %509 = bitcast <2 x i64> %508 to <2 x double>
  %510 = select <2 x i1> %506, <2 x double> %509, <2 x double> zeroinitializer
  br label %after_if86

false_block85:                                    ; preds = %for_loop_body71
  %511 = load ptr, ptr %23, align 8
  %512 = getelementptr double, ptr %511, i64 %467
  %513 = load i32, ptr %24, align 4
  %514 = sext i32 %513 to i64
  %515 = add nsw i64 %514, %467
  %516 = getelementptr double, ptr %511, i64 %515
  %517 = load double, ptr %516, align 8
  %518 = shl nsw i64 %514, 1
  %519 = add nsw i64 %518, %467
  %520 = getelementptr double, ptr %511, i64 %519
  %521 = load double, ptr %512, align 8
  %522 = load double, ptr %520, align 8
  %523 = insertelement <2 x double> poison, double %522, i64 0
  %524 = insertelement <2 x double> %523, double %521, i64 1
  br label %after_if86

after_if86:                                       ; preds = %false_block85, %true_block84
  %.sink256 = phi i64 [ %514, %false_block85 ], [ %477, %true_block84 ]
  %.sink255 = phi i64 [ %467, %false_block85 ], [ %473, %true_block84 ]
  %.sink = phi ptr [ %511, %false_block85 ], [ %472, %true_block84 ]
  %.065150155 = phi double [ %517, %false_block85 ], [ %488, %true_block84 ]
  %525 = phi <2 x double> [ %524, %false_block85 ], [ %510, %true_block84 ]
  %526 = mul nsw i64 %.sink256, 6
  %527 = add nsw i64 %526, %.sink255
  %528 = getelementptr double, ptr %.sink, i64 %527
  %.0 = load double, ptr %528, align 8
  %529 = getelementptr i64, ptr %344, i64 %464
  %530 = load i64, ptr %529, align 8
  %531 = uitofp i64 %530 to double
  %532 = add nsw i64 %346, %464
  %533 = getelementptr i64, ptr %344, i64 %532
  %534 = load i64, ptr %533, align 8
  %535 = uitofp i64 %534 to double
  %536 = fdiv double %531, %535
  %537 = fmul double %.0, %536
  %538 = insertelement <4 x double> poison, double %537, i64 0
  %539 = shufflevector <2 x double> %525, <2 x double> poison, <4 x i32> <i32 0, i32 1, i32 undef, i32 undef>
  %540 = shufflevector <4 x double> %538, <4 x double> %539, <4 x i32> <i32 0, i32 4, i32 undef, i32 5>
  %541 = insertelement <4 x double> %540, double %.065150155, i64 2
  %542 = bitcast <4 x double> %541 to <4 x i64>
  %543 = and <4 x i64> %542, <i64 9223372036854775807, i64 9223372036854775807, i64 9223372036854775807, i64 9223372036854775807>
  %544 = and <4 x i64> %542, <i64 9218868437227405312, i64 9218868437227405312, i64 9218868437227405312, i64 9218868437227405312>
  %545 = icmp eq <4 x i64> %543, zeroinitializer
  %546 = icmp ne <4 x i64> %544, <i64 0, i64 9218868437227405312, i64 0, i64 9218868437227405312>
  %547 = icmp ne <4 x i64> %544, <i64 9218868437227405312, i64 0, i64 9218868437227405312, i64 0>
  %548 = and <4 x i1> %547, %546
  %549 = or <4 x i1> %545, %548
  %550 = fcmp ole double %537, 0.000000e+00
  %551 = freeze <4 x i1> %549
  %552 = bitcast <4 x i1> %551 to i4
  %553 = icmp ne i4 %552, -1
  %op.rdx = select i1 %553, i1 true, i1 %550
  %.5.v = zext i1 %op.rdx to i32
  %.5 = or i32 %.068189, %.5.v
  %554 = icmp eq i64 %indvars.iv209, 0
  %.491 = select i1 %554, double %.065150155, double %.390185
  %555 = fsub double %.065150155, %.491
  %556 = fmul double %555, %537
  %557 = fadd double %.286186, %556
  %558 = insertelement <2 x i1> poison, i1 %554, i64 0
  %559 = shufflevector <2 x i1> %558, <2 x i1> poison, <2 x i32> zeroinitializer
  %560 = select <2 x i1> %559, <2 x double> %525, <2 x double> %461
  %561 = fsub <2 x double> %525, %560
  %562 = insertelement <2 x double> poison, double %537, i64 0
  %563 = shufflevector <2 x double> %562, <2 x double> poison, <2 x i32> zeroinitializer
  %564 = fmul <2 x double> %561, %563
  %565 = fadd <2 x double> %462, %564
  %566 = fadd double %.2102182, %537
  %indvars.iv.next210 = add nuw nsw i64 %indvars.iv209, 1
  %exitcond213.not = icmp eq i64 %wide.trip.count212, %indvars.iv.next210
  br i1 %exitcond213.not, label %after_if42.loopexit, label %for_loop_body71, !llvm.loop !8

567:                                              ; preds = %after_if42
  store i32 %spec.select257, ptr %4, align 4
  br label %568

568:                                              ; preds = %567, %after_if42
  %569 = shl i32 %.0115, 2
  %570 = load ptr, ptr %10, align 8
  %571 = load i32, ptr %11, align 4
  %572 = sext i32 %569 to i64
  %573 = sext i32 %571 to i64
  %574 = mul nsw i64 %573, %572
  %575 = add i64 %574, %38
  %576 = getelementptr double, ptr %570, i64 %575
  %577 = load double, ptr %576, align 8
  %578 = fcmp one double %577, %373
  %579 = or i1 %578, %383
  %580 = and i64 %374, 9223372036854775807
  %581 = and i64 %374, 9218868437227405312
  %582 = icmp eq i64 %580, 0
  %583 = icmp ne i64 %581, 0
  %584 = icmp ne i64 %581, 9218868437227405312
  %585 = and i1 %583, %584
  %586 = or i1 %582, %585
  br i1 %586, label %after_if125, label %true_block123

true_block123:                                    ; preds = %568
  %587 = or i32 %394, 1
  store i32 %587, ptr %4, align 4
  %.pre = load ptr, ptr %10, align 8
  %.pre219 = load i32, ptr %11, align 4
  %.pre224 = sext i32 %.pre219 to i64
  br label %after_if125

after_if125:                                      ; preds = %true_block123, %568
  %.pre-phi = phi i64 [ %573, %568 ], [ %.pre224, %true_block123 ]
  %588 = phi i32 [ %spec.select257, %568 ], [ %587, %true_block123 ]
  %589 = phi ptr [ %570, %568 ], [ %.pre, %true_block123 ]
  %590 = or i32 %569, 1
  %591 = sext i32 %590 to i64
  %592 = mul nsw i64 %.pre-phi, %591
  %593 = add i64 %592, %38
  %594 = getelementptr double, ptr %589, i64 %593
  %595 = load double, ptr %594, align 8
  %596 = fcmp one double %595, %375
  %597 = or i1 %579, %596
  %598 = and i64 %381, 9223372036854775807
  %599 = and i64 %381, 9218868437227405312
  %600 = icmp eq i64 %598, 0
  %601 = icmp ne i64 %599, 0
  %602 = icmp ne i64 %599, 9218868437227405312
  %603 = and i1 %601, %602
  %604 = or i1 %600, %603
  br i1 %604, label %after_if128, label %true_block126

true_block126:                                    ; preds = %after_if125
  %605 = or i32 %588, 1
  store i32 %605, ptr %4, align 4
  %.pre220 = load ptr, ptr %10, align 8
  %.pre221 = load i32, ptr %11, align 4
  %.pre225 = sext i32 %.pre221 to i64
  br label %after_if128

after_if128:                                      ; preds = %true_block126, %after_if125
  %.pre-phi226 = phi i64 [ %.pre-phi, %after_if125 ], [ %.pre225, %true_block126 ]
  %606 = phi i32 [ %588, %after_if125 ], [ %605, %true_block126 ]
  %607 = phi ptr [ %589, %after_if125 ], [ %.pre220, %true_block126 ]
  %608 = or i32 %569, 2
  %609 = sext i32 %608 to i64
  %610 = mul nsw i64 %.pre-phi226, %609
  %611 = add i64 %610, %38
  %612 = getelementptr double, ptr %607, i64 %611
  %613 = load double, ptr %612, align 8
  %614 = fcmp one double %613, %382
  %615 = or i1 %597, %614
  %616 = bitcast double %.0100 to i64
  %617 = and i64 %616, 9223372036854775807
  %618 = and i64 %616, 9218868437227405312
  %619 = icmp eq i64 %617, 0
  %620 = icmp ne i64 %618, 0
  %621 = icmp ne i64 %618, 9218868437227405312
  %622 = and i1 %620, %621
  %623 = or i1 %619, %622
  br i1 %623, label %after_if131, label %true_block129

true_block129:                                    ; preds = %after_if128
  %624 = or i32 %606, 1
  store i32 %624, ptr %4, align 4
  %.pre222 = load ptr, ptr %10, align 8
  %.pre223 = load i32, ptr %11, align 4
  %.pre227 = sext i32 %.pre223 to i64
  br label %after_if131

after_if131:                                      ; preds = %true_block129, %after_if128
  %.pre-phi228 = phi i64 [ %.pre-phi226, %after_if128 ], [ %.pre227, %true_block129 ]
  %625 = phi ptr [ %607, %after_if128 ], [ %.pre222, %true_block129 ]
  %626 = or i32 %569, 3
  %627 = sext i32 %626 to i64
  %628 = mul nsw i64 %.pre-phi228, %627
  %629 = add i64 %628, %38
  %630 = getelementptr double, ptr %625, i64 %629
  %631 = load double, ptr %630, align 8
  %632 = fcmp one double %.0100, %631
  %633 = or i1 %615, %632
  br i1 %633, label %true_block132, label %after_if39

true_block132:                                    ; preds = %after_if131
  store i32 1, ptr %53, align 4
  %634 = load ptr, ptr %10, align 8
  %635 = load i32, ptr %11, align 4
  %636 = sext i32 %635 to i64
  %637 = mul nsw i64 %636, %572
  %638 = add i64 %637, %38
  %639 = getelementptr double, ptr %634, i64 %638
  %640 = load double, ptr %639, align 8
  %641 = select i1 %41, double %640, double %373
  store double %641, ptr %242, align 8
  store i64 %372, ptr %246, align 8
  store i64 %372, ptr %244, align 8
  %642 = load ptr, ptr %10, align 8
  %643 = load i32, ptr %11, align 4
  %644 = sext i32 %643 to i64
  %645 = mul nsw i64 %644, %591
  %646 = add i64 %645, %38
  %647 = getelementptr double, ptr %642, i64 %646
  %648 = load double, ptr %647, align 8
  %649 = select i1 %41, double %648, double %375
  store double %649, ptr %251, align 8
  store i64 %374, ptr %247, align 8
  store i64 %374, ptr %249, align 8
  %650 = load ptr, ptr %10, align 8
  %651 = load i32, ptr %11, align 4
  %652 = sext i32 %651 to i64
  %653 = mul nsw i64 %652, %609
  %654 = add i64 %653, %38
  %655 = getelementptr double, ptr %650, i64 %654
  %656 = load double, ptr %655, align 8
  %657 = select i1 %41, double %656, double %382
  store double %657, ptr %241, align 8
  store i64 %381, ptr %245, align 8
  store i64 %381, ptr %243, align 8
  %658 = load ptr, ptr %10, align 8
  %659 = load i32, ptr %11, align 4
  %660 = sext i32 %659 to i64
  %661 = mul nsw i64 %660, %627
  %662 = add i64 %661, %38
  %663 = getelementptr double, ptr %658, i64 %662
  %664 = load double, ptr %663, align 8
  %665 = select i1 %41, double %664, double %.0100
  store double %665, ptr %257, align 8
  store double %.0100, ptr %248, align 8
  store double %.0100, ptr %250, align 8
  br label %after_if39
}

attributes #0 = { nofree norecurse nosync nounwind }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.unroll.disable"}
!8 = distinct !{!8, !7}
