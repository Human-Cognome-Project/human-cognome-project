; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%0 = type { ptr, [2 x i32], %struct.PhysicalCoordinates.456 }
%1 = type { %2, %2 }
%2 = type { [4 x i64], [4 x ptr] }
%struct.RuntimeContext.443 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }
%struct.ListManager = type { [256 x ptr], i64, i64, i32, i32, i32, ptr }
%struct.PhysicalCoordinates.456 = type { [12 x i32] }
%struct.cpu_block_task_helper_context = type { ptr, ptr, ptr, i32, i32, i64 }
%struct.NodeManager = type <{ ptr, i32, i32, i32, i32, ptr, ptr, ptr, i32, [4 x i8] }>
%class.anon = type { ptr, ptr, ptr, ptr }

@.str = private unnamed_addr constant [28 x i8] c"Out of pre-allocated memory\00", align 1
@.str.2 = private unnamed_addr constant [28 x i8] c"List manager out of chunks.\00", align 1

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @live_hierarchy_poll_21_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 25
  %2 = load double, ptr %1, align 8
  %3 = getelementptr inbounds %struct.RuntimeContext.443, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 8
  store double %2, ptr %7, align 8
  %8 = load ptr, ptr %context, align 8
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %8, i64 0, i32 26
  %10 = load i32, ptr %9, align 4
  %11 = load ptr, ptr %3, align 8
  %12 = getelementptr inbounds %struct.LLVMRuntime, ptr %11, i64 0, i32 16
  %13 = load ptr, ptr %12, align 8
  store i32 %10, ptr %13, align 4
  %14 = load ptr, ptr %context, align 8
  %15 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %14, i64 0, i32 27
  %16 = load double, ptr %15, align 8
  %17 = load ptr, ptr %3, align 8
  %18 = getelementptr inbounds %struct.LLVMRuntime, ptr %17, i64 0, i32 16
  %19 = load ptr, ptr %18, align 8
  %20 = getelementptr inbounds i8, ptr %19, i64 16
  store double %16, ptr %20, align 8
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @live_hierarchy_poll_21_kernel_1_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.443, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 20
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @live_hierarchy_poll_21_kernel_2_listgen_S20pointer(ptr %context) local_unnamed_addr #1 {
.lr.ph.i:
  %.sroa.2.i = alloca { [2 x i32], %struct.PhysicalCoordinates.456 }, align 8
  %0 = alloca %0, align 8
  %1 = getelementptr inbounds %struct.RuntimeContext.443, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 16
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %4, i64 20
  %8 = load ptr, ptr %7, align 8
  %9 = load atomic i64, ptr %6 acquire, align 8
  %.not.i.i.i.i = icmp ne i64 %9, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i)
  %10 = inttoptr i64 %9 to ptr
  %11 = load atomic i64, ptr %10 acquire, align 8
  %12 = inttoptr i64 %11 to ptr
  %.sroa.0.0.copyload.i = load ptr, ptr %12, align 8
  %.sroa.2.0..sroa_idx.i = getelementptr inbounds i8, ptr %12, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.i, ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.0..sroa_idx.i, i64 56, i1 false)
  %getch.i = getelementptr %1, ptr %.sroa.0.0.copyload.i, i64 0, i32 1
  %13 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %.sroa.2.16.sroa_idx.i = getelementptr inbounds i8, ptr %.sroa.2.i, i64 8
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %16 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 4
  %17 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 6
  %18 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 2
  %19 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  store ptr %getch.i, ptr %0, align 8
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %0, i64 8
  store <2 x i32> <i32 0, i32 4>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %13, ptr noundef nonnull align 8 dereferenceable(48) %.sroa.2.16.sroa_idx.i, i64 48, i1 false)
  %20 = atomicrmw volatile add ptr %14, i32 1 seq_cst, align 4
  %21 = load i32, ptr %15, align 8
  %22 = ashr i32 %20, %21
  %23 = icmp ugt i32 %22, 131071
  br i1 %23, label %24, label %26

24:                                               ; preds = %.lr.ph.i
  %25 = load ptr, ptr %17, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %25, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

26:                                               ; preds = %.lr.ph.i
  %27 = zext i32 %22 to i64
  %28 = lshr i64 %27, 9
  %29 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %28
  %30 = load atomic i64, ptr %29 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %30, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %26
  %31 = inttoptr i64 %30 to ptr
  %32 = and i64 %27, 511
  %33 = getelementptr inbounds ptr, ptr %31, i64 %32
  %34 = load atomic i64, ptr %33 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %26
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %35 = atomicrmw volatile xchg ptr %16, i32 1 seq_cst, align 4
  %36 = icmp eq i32 %35, 1
  br i1 %36, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %37 = load atomic i64, ptr %29 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %37, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %39, label %73

39:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %40 = load ptr, ptr %17, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1
  %42 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 28
  %43 = atomicrmw volatile add ptr %42, i64 4096 seq_cst, align 8
  %44 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 2
  %45 = load i64, ptr %44, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %45, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %66, label %46

46:                                               ; preds = %39
  %47 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 26
  br label %48

48:                                               ; preds = %48, %46
  %49 = atomicrmw volatile xchg ptr %47, i32 1 seq_cst, align 4
  %50 = icmp eq i32 %49, 1
  br i1 %50, label %48, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %48
  %51 = load ptr, ptr %41, align 8
  %52 = ptrtoint ptr %51 to i64
  %53 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 1
  %54 = load ptr, ptr %53, align 8
  %55 = ptrtoint ptr %54 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %52
  %56 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %57 = or i64 %56, 4096
  %58 = add i64 %57, %52
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %58, %55
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %59

59:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %60 = add i64 %56, %52
  %61 = inttoptr i64 %60 to ptr
  %62 = getelementptr i8, ptr %51, i64 %56
  %63 = getelementptr inbounds i8, ptr %62, i64 4096
  store ptr %63, ptr %41, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %59, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %61, %59 ]
  %64 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %65 = atomicrmw volatile xchg ptr %47, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %40, i1 noundef zeroext %64, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

66:                                               ; preds = %39
  %67 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 2
  %68 = load ptr, ptr %67, align 8
  %69 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 6
  %70 = load ptr, ptr %69, align 8
  %71 = tail call noundef ptr %68(ptr noundef %70, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %66, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %71, %66 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %72 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %72, ptr %29 release, align 8
  br label %73

73:                                               ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %38, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %74 = and i32 %22, 511
  %75 = zext i32 %74 to i64
  %76 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %75
  %77 = load atomic i64, ptr %76 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %77, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %78, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

78:                                               ; preds = %73
  %79 = load ptr, ptr %17, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1
  %81 = load i64, ptr %18, align 8
  %82 = load i64, ptr %19, align 8
  %83 = mul i64 %82, %81
  %84 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 28
  %85 = atomicrmw volatile add ptr %84, i64 %83 seq_cst, align 8
  %86 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 2
  %87 = load i64, ptr %86, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %87, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %107, label %88

88:                                               ; preds = %78
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 26
  br label %90

90:                                               ; preds = %90, %88
  %91 = atomicrmw volatile xchg ptr %89, i32 1 seq_cst, align 4
  %92 = icmp eq i32 %91, 1
  br i1 %92, label %90, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %90
  %93 = load ptr, ptr %80, align 8
  %94 = ptrtoint ptr %93 to i64
  %95 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 1
  %96 = load ptr, ptr %95, align 8
  %97 = ptrtoint ptr %96 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %94
  %98 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %99 = add i64 %98, %83
  %100 = add i64 %99, %94
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %100, %97
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %101

101:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %102 = add i64 %98, %94
  %103 = inttoptr i64 %102 to ptr
  %104 = getelementptr inbounds i8, ptr %93, i64 %99
  store ptr %104, ptr %80, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %101, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %103, %101 ]
  %105 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %106 = atomicrmw volatile xchg ptr %89, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %79, i1 noundef zeroext %105, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

107:                                              ; preds = %78
  %108 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 2
  %109 = load ptr, ptr %108, align 8
  %110 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 6
  %111 = load ptr, ptr %110, align 8
  %112 = tail call noundef ptr %109(ptr noundef %111, i64 noundef %83, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %107, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %112, %107 ]
  %113 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %113, ptr %76 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %73
  %114 = atomicrmw volatile xchg ptr %16, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %24
  %115 = load i32, ptr %15, align 8
  %116 = ashr i32 %20, %115
  %117 = sext i32 %116 to i64
  %118 = lshr i64 %117, 9
  %119 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %118
  %120 = load atomic i64, ptr %119 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %120, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %121

121:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %122 = inttoptr i64 %120 to ptr
  %123 = and i64 %117, 511
  %124 = getelementptr inbounds ptr, ptr %122, i64 %123
  %125 = load atomic i64, ptr %124 acquire, align 8
  %126 = inttoptr i64 %125 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %121, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %127 = phi ptr [ %126, %121 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %128 = load i64, ptr %19, align 8
  %129 = load i32, ptr %15, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %129
  %130 = xor i32 %notmask.i.i.i.i, -1
  %131 = and i32 %20, %130
  %132 = sext i32 %131 to i64
  %133 = mul i64 %128, %132
  %134 = getelementptr inbounds i8, ptr %127, i64 %133
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %134, ptr nonnull align 8 %0, i64 %128, i1 false)
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @live_hierarchy_poll_21_kernel_3_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.443, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 21
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @live_hierarchy_poll_21_kernel_4_listgen_S21bitmasked(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %0, align 8
  %1 = alloca %struct.PhysicalCoordinates.456, align 4
  %2 = alloca %0, align 8
  %3 = getelementptr inbounds %struct.RuntimeContext.443, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %2)
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 13
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %6, i64 20
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %10 = load i32, ptr %9, align 8
  %11 = getelementptr inbounds ptr, ptr %6, i64 21
  %12 = load ptr, ptr %11, align 8
  %13 = icmp sgt i32 %10, 0
  br i1 %13, label %.lr.ph61.i, label %element_listgen_nonroot.exit

.lr.ph61.i:                                       ; preds = %entry
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  %16 = getelementptr inbounds %0, ptr %0, i64 0, i32 1
  %17 = getelementptr inbounds %0, ptr %0, i64 0, i32 1, i64 1
  %18 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %19 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %20 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 5
  %21 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %22 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 4
  %23 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 6
  %24 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 2
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %2, i64 8
  br label %26

26:                                               ; preds = %._crit_edge.i, %.lr.ph61.i
  %.04359.i = phi i32 [ 0, %.lr.ph61.i ], [ %172, %._crit_edge.i ]
  %27 = load i32, ptr %14, align 8
  %28 = lshr i32 %.04359.i, %27
  %29 = sext i32 %28 to i64
  %30 = lshr i64 %29, 9
  %31 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %30
  %32 = load atomic i64, ptr %31 acquire, align 8
  %.not.i.i.i.i = icmp eq i64 %32, 0
  br i1 %.not.i.i.i.i, label %_ZN11ListManager3getI7ElementEERT_i.exit.i, label %33

33:                                               ; preds = %26
  %34 = inttoptr i64 %32 to ptr
  %35 = and i64 %29, 511
  %36 = getelementptr inbounds ptr, ptr %34, i64 %35
  %37 = load atomic i64, ptr %36 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit.i

_ZN11ListManager3getI7ElementEERT_i.exit.i:       ; preds = %33, %26
  %39 = phi ptr [ %38, %33 ], [ null, %26 ]
  %40 = load i64, ptr %15, align 8
  %41 = load i32, ptr %14, align 8
  %notmask.i.i.i = shl nsw i32 -1, %41
  %42 = xor i32 %notmask.i.i.i, -1
  %43 = and i32 %.04359.i, %42
  %44 = zext i32 %43 to i64
  %45 = mul i64 %40, %44
  %46 = getelementptr inbounds i8, ptr %39, i64 %45
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %0, ptr noundef nonnull align 8 dereferenceable(64) %46, i64 64, i1 false)
  %47 = load i32, ptr %16, align 8
  %48 = load i32, ptr %17, align 4
  %49 = icmp slt i32 %47, %48
  br i1 %49, label %.lr.ph58.i.preheader, label %._crit_edge.i

.lr.ph58.i.preheader:                             ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit.i
  br label %.lr.ph58.i

.lr.ph58.i:                                       ; preds = %.loopexit.i, %.lr.ph58.i.preheader
  %.04457.i = phi i32 [ %171, %.loopexit.i ], [ %47, %.lr.ph58.i.preheader ]
  call fastcc void @S20_refine_coordinates(ptr noundef nonnull %18, ptr noundef nonnull %1, i32 noundef %.04457.i) #1
  %50 = load ptr, ptr %0, align 8
  %51 = shl i32 %.04457.i, 3
  %52 = sext i32 %51 to i64
  %53 = getelementptr i8, ptr %50, i64 %52
  %54 = getelementptr inbounds i8, ptr %53, i64 32
  %55 = load ptr, ptr %54, align 8
  %.not = icmp eq ptr %55, null
  br i1 %.not, label %.loopexit.i, label %.lr.ph.i

.lr.ph.i:                                         ; preds = %.lr.ph58.i
  store ptr %55, ptr %2, align 8
  store <2 x i32> <i32 0, i32 32>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %19, ptr noundef nonnull align 4 dereferenceable(48) %1, i64 48, i1 false)
  %56 = atomicrmw volatile add ptr %20, i32 1 seq_cst, align 4
  %57 = load i32, ptr %21, align 8
  %58 = ashr i32 %56, %57
  %59 = icmp ugt i32 %58, 131071
  br i1 %59, label %60, label %62

60:                                               ; preds = %.lr.ph.i
  %61 = load ptr, ptr %23, align 8
  call fastcc void @taichi_assert_format(ptr noundef %61, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

62:                                               ; preds = %.lr.ph.i
  %63 = zext i32 %58 to i64
  %64 = lshr i64 %63, 9
  %65 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %64
  %66 = load atomic i64, ptr %65 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %66, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %62
  %67 = inttoptr i64 %66 to ptr
  %68 = and i64 %63, 511
  %69 = getelementptr inbounds ptr, ptr %67, i64 %68
  %70 = load atomic i64, ptr %69 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %70, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %62
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %71 = atomicrmw volatile xchg ptr %22, i32 1 seq_cst, align 4
  %72 = icmp eq i32 %71, 1
  br i1 %72, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %73 = load atomic i64, ptr %65 acquire, align 8
  %74 = inttoptr i64 %73 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %73, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %75, label %109

75:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %76 = load ptr, ptr %23, align 8
  %77 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1
  %78 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 28
  %79 = atomicrmw volatile add ptr %78, i64 4096 seq_cst, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 2
  %81 = load i64, ptr %80, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %81, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %102, label %82

82:                                               ; preds = %75
  %83 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 26
  br label %84

84:                                               ; preds = %84, %82
  %85 = atomicrmw volatile xchg ptr %83, i32 1 seq_cst, align 4
  %86 = icmp eq i32 %85, 1
  br i1 %86, label %84, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %84
  %87 = load ptr, ptr %77, align 8
  %88 = ptrtoint ptr %87 to i64
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 1
  %90 = load ptr, ptr %89, align 8
  %91 = ptrtoint ptr %90 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %88
  %92 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %93 = or i64 %92, 4096
  %94 = add i64 %93, %88
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %94, %91
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %95

95:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %96 = add i64 %92, %88
  %97 = inttoptr i64 %96 to ptr
  %98 = getelementptr i8, ptr %87, i64 %92
  %99 = getelementptr inbounds i8, ptr %98, i64 4096
  store ptr %99, ptr %77, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %95, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %97, %95 ]
  %100 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %101 = atomicrmw volatile xchg ptr %83, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %76, i1 noundef zeroext %100, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

102:                                              ; preds = %75
  %103 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 2
  %104 = load ptr, ptr %103, align 8
  %105 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 6
  %106 = load ptr, ptr %105, align 8
  %107 = call noundef ptr %104(ptr noundef %106, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %102, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %107, %102 ]
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %108 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %108, ptr %65 release, align 8
  br label %109

109:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %74, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %110 = and i32 %58, 511
  %111 = zext i32 %110 to i64
  %112 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %111
  %113 = load atomic i64, ptr %112 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %113, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %114, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

114:                                              ; preds = %109
  %115 = load ptr, ptr %23, align 8
  %116 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1
  %117 = load i64, ptr %24, align 8
  %118 = load i64, ptr %25, align 8
  %119 = mul i64 %118, %117
  %120 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 28
  %121 = atomicrmw volatile add ptr %120, i64 %119 seq_cst, align 8
  %122 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 2
  %123 = load i64, ptr %122, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %123, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %143, label %124

124:                                              ; preds = %114
  %125 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 26
  br label %126

126:                                              ; preds = %126, %124
  %127 = atomicrmw volatile xchg ptr %125, i32 1 seq_cst, align 4
  %128 = icmp eq i32 %127, 1
  br i1 %128, label %126, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %126
  %129 = load ptr, ptr %116, align 8
  %130 = ptrtoint ptr %129 to i64
  %131 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 1
  %132 = load ptr, ptr %131, align 8
  %133 = ptrtoint ptr %132 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %130
  %134 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %135 = add i64 %134, %119
  %136 = add i64 %135, %130
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %136, %133
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %137

137:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %138 = add i64 %134, %130
  %139 = inttoptr i64 %138 to ptr
  %140 = getelementptr inbounds i8, ptr %129, i64 %135
  store ptr %140, ptr %116, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %137, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %139, %137 ]
  %141 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %142 = atomicrmw volatile xchg ptr %125, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %115, i1 noundef zeroext %141, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

143:                                              ; preds = %114
  %144 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 2
  %145 = load ptr, ptr %144, align 8
  %146 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 6
  %147 = load ptr, ptr %146, align 8
  %148 = call noundef ptr %145(ptr noundef %147, i64 noundef %119, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %143, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %148, %143 ]
  %149 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %149, ptr %112 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %109
  %150 = atomicrmw volatile xchg ptr %22, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %60
  %151 = load i32, ptr %21, align 8
  %152 = ashr i32 %56, %151
  %153 = sext i32 %152 to i64
  %154 = lshr i64 %153, 9
  %155 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %154
  %156 = load atomic i64, ptr %155 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %156, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %157

157:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %158 = inttoptr i64 %156 to ptr
  %159 = and i64 %153, 511
  %160 = getelementptr inbounds ptr, ptr %158, i64 %159
  %161 = load atomic i64, ptr %160 acquire, align 8
  %162 = inttoptr i64 %161 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %157, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %163 = phi ptr [ %162, %157 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %164 = load i64, ptr %25, align 8
  %165 = load i32, ptr %21, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %165
  %166 = xor i32 %notmask.i.i.i.i, -1
  %167 = and i32 %56, %166
  %168 = sext i32 %167 to i64
  %169 = mul i64 %164, %168
  %170 = getelementptr inbounds i8, ptr %163, i64 %169
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %170, ptr nonnull align 8 %2, i64 %164, i1 false)
  br label %.loopexit.i, !llvm.loop !8

.loopexit.i:                                      ; preds = %_ZN11ListManager6appendEPv.exit.i, %.lr.ph58.i
  %171 = add i32 %.04457.i, 1
  %exitcond.not.i = icmp eq i32 %171, %48
  br i1 %exitcond.not.i, label %._crit_edge.i.loopexit, label %.lr.ph58.i, !llvm.loop !9

._crit_edge.i.loopexit:                           ; preds = %.loopexit.i
  br label %._crit_edge.i

._crit_edge.i:                                    ; preds = %._crit_edge.i.loopexit, %_ZN11ListManager3getI7ElementEERT_i.exit.i
  %172 = add nuw nsw i32 %.04359.i, 1
  %exitcond63.not.i = icmp eq i32 %172, %10
  br i1 %exitcond63.not.i, label %element_listgen_nonroot.exit.loopexit, label %26, !llvm.loop !10

element_listgen_nonroot.exit.loopexit:            ; preds = %._crit_edge.i
  br label %element_listgen_nonroot.exit

element_listgen_nonroot.exit:                     ; preds = %element_listgen_nonroot.exit.loopexit, %entry
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %2)
  ret void
}

; Function Attrs: nounwind
define void @live_hierarchy_poll_21_kernel_5_struct_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.cpu_block_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.RuntimeContext.443, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 21
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds %struct.ListManager, ptr %6, i64 0, i32 5
  %8 = load i32, ptr %7, align 8
  store ptr %context, ptr %0, align 8
  %9 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  store ptr @function_body, ptr %9, align 8
  %10 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  store ptr %6, ptr %10, align 8
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  store <2 x i32> <i32 32, i32 32>, ptr %11, align 8
  %12 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  store i64 1, ptr %12, align 8
  %13 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 12
  %14 = load ptr, ptr %13, align 8
  %15 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 11
  %16 = load ptr, ptr %15, align 8
  %17 = shl nsw i32 %8, 5
  call void %14(ptr noundef %16, i32 noundef %17, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_struct_for_block_helper) #1
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %0)
  ret void
}

; Function Attrs: nounwind
define internal void @function_body(ptr %0, ptr nocapture readnone %1, ptr nocapture readonly %2, i32 %3, i32 %4) #1 {
allocs:
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %8 = icmp slt i32 %3, %4
  br i1 %8, label %loop_body.lr.ph, label %func_exit

loop_body.lr.ph:                                  ; preds = %allocs
  %9 = getelementptr inbounds %struct.RuntimeContext.443, ptr %0, i64 0, i32 1
  br label %loop_body

loop_body:                                        ; preds = %loop_body_tail, %loop_body.lr.ph
  %.0115331 = phi i32 [ %3, %loop_body.lr.ph ], [ %22, %loop_body_tail ]
  %10 = and i32 %.0115331, 31
  %11 = load i32, ptr %7, align 4
  %12 = load ptr, ptr %2, align 8
  %13 = getelementptr inbounds i8, ptr %12, i64 32
  %14 = sdiv i32 %.0115331, 8
  %15 = sext i32 %14 to i64
  %16 = getelementptr inbounds i8, ptr %13, i64 %15
  %17 = load i8, ptr %16, align 1
  %18 = zext i8 %17 to i32
  %19 = and i32 %.0115331, 7
  %20 = shl nuw nsw i32 1, %19
  %21 = and i32 %20, %18
  %.not272 = icmp eq i32 %21, 0
  br i1 %.not272, label %loop_body_tail, label %struct_for_body_body

loop_body_tail.loopexit:                          ; preds = %after_if180
  br label %loop_body_tail

loop_body_tail:                                   ; preds = %after_if82, %after_if76, %struct_for_body_body, %loop_body_tail.loopexit, %loop_body
  %22 = add nsw i32 %.0115331, 1
  %exitcond378.not = icmp eq i32 %22, %4
  br i1 %exitcond378.not, label %func_exit.loopexit, label %loop_body

func_exit.loopexit:                               ; preds = %loop_body_tail
  br label %func_exit

func_exit:                                        ; preds = %func_exit.loopexit, %allocs
  ret void

struct_for_body_body:                             ; preds = %loop_body
  %23 = shl i32 %11, 5
  %24 = or i32 %23, %10
  %25 = load ptr, ptr %0, align 8
  %26 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %25, i64 0, i32 18, i32 1
  %27 = load ptr, ptr %26, align 8
  %28 = sext i32 %24 to i64
  %29 = getelementptr i32, ptr %27, i64 %28
  %30 = load i32, ptr %29, align 4
  %31 = icmp sgt i32 %30, -1
  %32 = load ptr, ptr %9, align 8
  %33 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 16
  %34 = load ptr, ptr %33, align 8
  %35 = load i32, ptr %34, align 4
  %36 = icmp slt i32 %35, 0
  %37 = icmp eq i32 %30, %35
  %38 = or i1 %36, %37
  %39 = and i1 %31, %38
  br i1 %39, label %true_block, label %loop_body_tail

true_block:                                       ; preds = %struct_for_body_body
  %40 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 7
  %41 = load ptr, ptr %40, align 8
  %42 = getelementptr inbounds ptr, ptr %41, i64 2
  %43 = load ptr, ptr %42, align 8
  %getch.i = getelementptr %1, ptr %43, i64 0, i32 1
  %44 = shl i32 %11, 3
  %45 = and i32 %44, 1073741816
  %46 = zext i32 %45 to i64
  %47 = getelementptr i8, ptr %getch.i, i64 %46
  %48 = getelementptr inbounds i8, ptr %47, i64 32
  %49 = load ptr, ptr %48, align 8
  %50 = icmp eq ptr %49, null
  br i1 %50, label %51, label %Pointer_lookup_element.exit169

51:                                               ; preds = %true_block
  %52 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 15
  %53 = load ptr, ptr %52, align 8
  %54 = getelementptr inbounds ptr, ptr %53, i64 20
  %55 = load ptr, ptr %54, align 8
  br label %Pointer_lookup_element.exit169

Pointer_lookup_element.exit169:                   ; preds = %51, %true_block
  %.0.i168 = phi ptr [ %55, %51 ], [ %49, %true_block ]
  %56 = getelementptr inbounds i8, ptr %.0.i168, i64 32
  %57 = shl nuw i32 1, %10
  %58 = xor i32 %57, -1
  %59 = atomicrmw volatile and ptr %56, i32 %58 seq_cst, align 4
  %60 = load ptr, ptr %0, align 8
  %61 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %60, i64 0, i32 29, i32 1
  %62 = load ptr, ptr %61, align 8
  %63 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %60, i64 0, i32 29, i32 0, i32 1
  %64 = getelementptr i32, ptr %62, i64 %28
  store i32 1, ptr %64, align 4
  %65 = load ptr, ptr %61, align 8
  %66 = load i32, ptr %63, align 4
  %67 = sext i32 %66 to i64
  %68 = add nsw i64 %67, %28
  %69 = getelementptr i32, ptr %65, i64 %68
  store i32 0, ptr %69, align 4
  %70 = load ptr, ptr %0, align 8
  %71 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %70, i64 0, i32 8, i32 1
  %72 = load ptr, ptr %71, align 8
  %73 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %70, i64 0, i32 8, i32 0, i32 1
  %74 = load i32, ptr %73, align 4
  %75 = sext i32 %74 to i64
  %76 = shl nsw i64 %75, 2
  %77 = add nsw i64 %76, %28
  %78 = getelementptr double, ptr %72, i64 %77
  store double 0.000000e+00, ptr %78, align 8
  %79 = load ptr, ptr %71, align 8
  %80 = load i32, ptr %73, align 4
  %81 = sext i32 %80 to i64
  %82 = mul nsw i64 %81, 5
  %83 = add nsw i64 %82, %28
  %84 = getelementptr double, ptr %79, i64 %83
  store double 0.000000e+00, ptr %84, align 8
  %85 = load ptr, ptr %71, align 8
  %86 = load i32, ptr %73, align 4
  %87 = sext i32 %86 to i64
  %88 = mul nsw i64 %87, 6
  %89 = add nsw i64 %88, %28
  %90 = getelementptr double, ptr %85, i64 %89
  store double 0.000000e+00, ptr %90, align 8
  %91 = load ptr, ptr %71, align 8
  %92 = load i32, ptr %73, align 4
  %93 = sext i32 %92 to i64
  %94 = mul nsw i64 %93, 7
  %95 = add nsw i64 %94, %28
  %96 = getelementptr double, ptr %91, i64 %95
  store double 0.000000e+00, ptr %96, align 8
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %97, i64 0, i32 28, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %97, i64 0, i32 28, i32 0, i32 1
  %101 = zext i32 %30 to i64
  %102 = getelementptr i64, ptr %99, i64 %101
  %103 = atomicrmw add ptr %102, i64 1 seq_cst, align 8
  %104 = load ptr, ptr %0, align 8
  %105 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %104, i64 0, i32 14, i32 1
  %106 = load ptr, ptr %105, align 8
  %107 = getelementptr i64, ptr %106, i64 1
  %108 = atomicrmw add ptr %107, i64 1 seq_cst, align 8
  %109 = load ptr, ptr %0, align 8
  %110 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %109, i64 0, i32 15, i32 1
  %111 = load ptr, ptr %110, align 8
  %112 = getelementptr i64, ptr %111, i64 7
  %113 = atomicrmw add ptr %112, i64 1 seq_cst, align 8
  %114 = load ptr, ptr %110, align 8
  %115 = getelementptr i64, ptr %114, i64 13
  %116 = atomicrmw add ptr %115, i64 1 seq_cst, align 8
  %117 = load ptr, ptr %110, align 8
  %118 = getelementptr i64, ptr %117, i64 6
  %119 = atomicrmw add ptr %118, i64 1 seq_cst, align 8
  %120 = load ptr, ptr %0, align 8
  %121 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %120, i64 0, i32 1, i32 1
  %122 = load ptr, ptr %121, align 8
  %123 = getelementptr i32, ptr %122, i64 %101
  %124 = atomicrmw or ptr %123, i32 0 seq_cst, align 4
  %125 = shl i32 %124, 2
  %126 = load ptr, ptr %0, align 8
  %127 = getelementptr { { i32, i32 }, ptr }, ptr %126, i64 0, i32 1
  %128 = load ptr, ptr %127, align 8
  %129 = getelementptr { { i32, i32 }, ptr }, ptr %126, i64 0, i32 0, i32 1
  %130 = load i32, ptr %129, align 4
  %131 = sext i32 %125 to i64
  %132 = sext i32 %130 to i64
  %133 = mul nsw i64 %132, %131
  %134 = add nsw i64 %133, %101
  %135 = getelementptr double, ptr %128, i64 %134
  %136 = load double, ptr %135, align 8
  %137 = or i32 %125, 1
  %138 = sext i32 %137 to i64
  %139 = mul nsw i64 %132, %138
  %140 = add nsw i64 %139, %101
  %141 = getelementptr double, ptr %128, i64 %140
  %142 = load double, ptr %141, align 8
  %143 = or i32 %125, 2
  %144 = sext i32 %143 to i64
  %145 = mul nsw i64 %132, %144
  %146 = add nsw i64 %145, %101
  %147 = getelementptr double, ptr %128, i64 %146
  %148 = load double, ptr %147, align 8
  %149 = or i32 %125, 3
  %150 = sext i32 %149 to i64
  %151 = mul nsw i64 %132, %150
  %152 = add nsw i64 %151, %101
  %153 = getelementptr double, ptr %128, i64 %152
  %154 = load double, ptr %153, align 8
  %155 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %126, i64 0, i32 2, i32 1
  %156 = load ptr, ptr %155, align 8
  %157 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %126, i64 0, i32 2, i32 0, i32 1
  %158 = load i32, ptr %157, align 4
  %159 = sext i32 %158 to i64
  %160 = shl nsw i64 %159, 1
  %161 = add nsw i64 %160, %101
  %162 = getelementptr i32, ptr %156, i64 %161
  %163 = load i32, ptr %162, align 4
  %.not = icmp eq i32 %163, 0
  br i1 %.not, label %false_block2, label %true_block1

true_block1:                                      ; preds = %Pointer_lookup_element.exit169
  %164 = add nsw i64 %159, %101
  %165 = getelementptr i32, ptr %156, i64 %164
  %166 = load i32, ptr %165, align 4
  %167 = load ptr, ptr %105, align 8
  %168 = getelementptr i64, ptr %167, i64 4
  %169 = load ptr, ptr %110, align 8
  %170 = getelementptr i64, ptr %169, i64 12
  %171 = icmp sgt i32 %163, 0
  br i1 %171, label %for_loop_body.lr.ph, label %after_if3

for_loop_body.lr.ph:                              ; preds = %true_block1
  %172 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %126, i64 0, i32 3, i32 1
  %wide.trip.count = zext i32 %163 to i64
  %173 = add nsw i64 %wide.trip.count, -1
  %xtraiter = and i64 %wide.trip.count, 3
  %174 = icmp ult i64 %173, 3
  br i1 %174, label %after_if3.loopexit426.unr-lcssa, label %for_loop_body.lr.ph.new

for_loop_body.lr.ph.new:                          ; preds = %for_loop_body.lr.ph
  %unroll_iter = and i64 %wide.trip.count, 4294967292
  br label %for_loop_body

false_block2:                                     ; preds = %Pointer_lookup_element.exit169
  %175 = mul nsw i64 %159, 3
  %176 = add nsw i64 %175, %101
  %177 = getelementptr i32, ptr %156, i64 %176
  %178 = load i32, ptr %177, align 4
  %179 = shl nsw i64 %159, 2
  %180 = add nsw i64 %179, %101
  %181 = getelementptr i32, ptr %156, i64 %180
  %182 = load i32, ptr %181, align 4
  %183 = load ptr, ptr %105, align 8
  %184 = getelementptr i64, ptr %183, i64 3
  %185 = load ptr, ptr %110, align 8
  %186 = getelementptr i64, ptr %185, i64 12
  %187 = icmp sgt i32 %182, 0
  br i1 %187, label %for_loop_body28.lr.ph, label %after_if3

for_loop_body28.lr.ph:                            ; preds = %false_block2
  %188 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %126, i64 0, i32 4, i32 1
  %189 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %126, i64 0, i32 7, i32 1
  %190 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %126, i64 0, i32 7, i32 0, i32 1
  %191 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %126, i64 0, i32 5, i32 1
  %192 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %126, i64 0, i32 5, i32 0, i32 1
  %wide.trip.count356 = zext i32 %182 to i64
  %193 = add nsw i64 %wide.trip.count356, -1
  %xtraiter453 = and i64 %wide.trip.count356, 3
  %194 = icmp ult i64 %193, 3
  br i1 %194, label %after_if3.loopexit.unr-lcssa, label %for_loop_body28.lr.ph.new

for_loop_body28.lr.ph.new:                        ; preds = %for_loop_body28.lr.ph
  %unroll_iter463 = and i64 %wide.trip.count356, 4294967292
  br label %for_loop_body28

after_if3.loopexit.unr-lcssa.loopexit:            ; preds = %after_if46.3
  br label %after_if3.loopexit.unr-lcssa

after_if3.loopexit.unr-lcssa:                     ; preds = %after_if3.loopexit.unr-lcssa.loopexit, %for_loop_body28.lr.ph
  %spec.select122.lcssa.ph = phi double [ undef, %for_loop_body28.lr.ph ], [ %spec.select122, %after_if3.loopexit.unr-lcssa.loopexit ]
  %.lcssa433.ph = phi double [ undef, %for_loop_body28.lr.ph ], [ %1115, %after_if3.loopexit.unr-lcssa.loopexit ]
  %.4103.lcssa.ph = phi double [ undef, %for_loop_body28.lr.ph ], [ %.4103, %after_if3.loopexit.unr-lcssa.loopexit ]
  %.lcssa432.ph = phi double [ undef, %for_loop_body28.lr.ph ], [ %1118, %after_if3.loopexit.unr-lcssa.loopexit ]
  %.4.lcssa.ph = phi double [ undef, %for_loop_body28.lr.ph ], [ %.4, %after_if3.loopexit.unr-lcssa.loopexit ]
  %.lcssa431.ph = phi double [ undef, %for_loop_body28.lr.ph ], [ %1121, %after_if3.loopexit.unr-lcssa.loopexit ]
  %.lcssa430.ph = phi double [ undef, %for_loop_body28.lr.ph ], [ %1122, %after_if3.loopexit.unr-lcssa.loopexit ]
  %indvars.iv353.unr = phi i64 [ 0, %for_loop_body28.lr.ph ], [ %indvars.iv.next354.3, %after_if3.loopexit.unr-lcssa.loopexit ]
  %.292294.unr = phi double [ 0.000000e+00, %for_loop_body28.lr.ph ], [ %1121, %after_if3.loopexit.unr-lcssa.loopexit ]
  %.3293.unr = phi double [ 0.000000e+00, %for_loop_body28.lr.ph ], [ %.4, %after_if3.loopexit.unr-lcssa.loopexit ]
  %.298292.unr = phi double [ 0.000000e+00, %for_loop_body28.lr.ph ], [ %1118, %after_if3.loopexit.unr-lcssa.loopexit ]
  %.3102291.unr = phi double [ 0.000000e+00, %for_loop_body28.lr.ph ], [ %.4103, %after_if3.loopexit.unr-lcssa.loopexit ]
  %.2106290.unr = phi double [ 0.000000e+00, %for_loop_body28.lr.ph ], [ %1115, %after_if3.loopexit.unr-lcssa.loopexit ]
  %.3110289.unr = phi double [ 0.000000e+00, %for_loop_body28.lr.ph ], [ %spec.select122, %after_if3.loopexit.unr-lcssa.loopexit ]
  %.2114288.unr = phi double [ 0.000000e+00, %for_loop_body28.lr.ph ], [ %1122, %after_if3.loopexit.unr-lcssa.loopexit ]
  %lcmp.mod455.not = icmp eq i64 %xtraiter453, 0
  br i1 %lcmp.mod455.not, label %after_if3, label %for_loop_body28.epil.preheader

for_loop_body28.epil.preheader:                   ; preds = %after_if3.loopexit.unr-lcssa
  %195 = mul i64 %indvars.iv353.unr, -1
  %196 = trunc i64 %indvars.iv353.unr to i32
  %197 = add i32 %178, %196
  %198 = zext i32 %197 to i64
  br label %for_loop_body28.epil

for_loop_body28.epil:                             ; preds = %after_if46.epil, %for_loop_body28.epil.preheader
  %.292294.epil = phi double [ %287, %after_if46.epil ], [ %.292294.unr, %for_loop_body28.epil.preheader ]
  %.3293.epil = phi double [ %.4.epil, %after_if46.epil ], [ %.3293.unr, %for_loop_body28.epil.preheader ]
  %.298292.epil = phi double [ %284, %after_if46.epil ], [ %.298292.unr, %for_loop_body28.epil.preheader ]
  %.3102291.epil = phi double [ %.4103.epil, %after_if46.epil ], [ %.3102291.unr, %for_loop_body28.epil.preheader ]
  %.2106290.epil = phi double [ %281, %after_if46.epil ], [ %.2106290.unr, %for_loop_body28.epil.preheader ]
  %.3110289.epil = phi double [ %spec.select122.epil, %after_if46.epil ], [ %.3110289.unr, %for_loop_body28.epil.preheader ]
  %.2114288.epil = phi double [ %288, %after_if46.epil ], [ %.2114288.unr, %for_loop_body28.epil.preheader ]
  %epil.iter454 = phi i64 [ %epil.iter454.next, %after_if46.epil ], [ 0, %for_loop_body28.epil.preheader ]
  %199 = add nuw nsw i64 %198, %epil.iter454
  %200 = load ptr, ptr %188, align 8
  %tmp515 = trunc i64 %199 to i32
  %201 = sext i32 %tmp515 to i64
  %202 = getelementptr i32, ptr %200, i64 %201
  %203 = load i32, ptr %202, align 4
  %204 = load ptr, ptr %189, align 8
  %205 = load i32, ptr %190, align 4
  %206 = sext i32 %205 to i64
  %207 = sext i32 %203 to i64
  %208 = getelementptr double, ptr %204, i64 %207
  %209 = load double, ptr %208, align 8
  %210 = add nsw i64 %206, %207
  %211 = getelementptr double, ptr %204, i64 %210
  %212 = load double, ptr %211, align 8
  %213 = shl nsw i64 %206, 1
  %214 = add nsw i64 %213, %207
  %215 = getelementptr double, ptr %204, i64 %214
  %216 = load double, ptr %215, align 8
  %217 = mul nsw i64 %206, 6
  %218 = add nsw i64 %217, %207
  %219 = getelementptr double, ptr %204, i64 %218
  %220 = load double, ptr %219, align 8
  %221 = load ptr, ptr %191, align 8
  %222 = load i32, ptr %192, align 4
  %223 = sext i32 %222 to i64
  %224 = getelementptr i64, ptr %221, i64 %201
  %225 = load i64, ptr %224, align 8
  %226 = uitofp i64 %225 to double
  %227 = add nsw i64 %223, %201
  %228 = getelementptr i64, ptr %221, i64 %227
  %229 = load i64, ptr %228, align 8
  %230 = uitofp i64 %229 to double
  %231 = fdiv double %226, %230
  %232 = fmul double %220, %231
  %233 = atomicrmw add ptr %184, i64 1 seq_cst, align 8
  %234 = atomicrmw add ptr %186, i64 1 seq_cst, align 8
  %235 = bitcast double %209 to i64
  %236 = and i64 %235, 9223372036854775807
  %237 = and i64 %235, 9218868437227405312
  %238 = icmp eq i64 %236, 0
  %239 = icmp ne i64 %237, 0
  %240 = icmp ne i64 %237, 9218868437227405312
  %241 = and i1 %239, %240
  %242 = or i1 %238, %241
  br i1 %242, label %after_if34.epil, label %true_block32.epil

true_block32.epil:                                ; preds = %for_loop_body28.epil
  %243 = load ptr, ptr %105, align 8
  %244 = atomicrmw add ptr %243, i64 1 seq_cst, align 8
  br label %after_if34.epil

after_if34.epil:                                  ; preds = %true_block32.epil, %for_loop_body28.epil
  %245 = bitcast double %212 to i64
  %246 = and i64 %245, 9223372036854775807
  %247 = and i64 %245, 9218868437227405312
  %248 = icmp eq i64 %246, 0
  %249 = icmp ne i64 %247, 0
  %250 = icmp ne i64 %247, 9218868437227405312
  %251 = and i1 %249, %250
  %252 = or i1 %248, %251
  br i1 %252, label %after_if37.epil, label %true_block35.epil

true_block35.epil:                                ; preds = %after_if34.epil
  %253 = load ptr, ptr %105, align 8
  %254 = atomicrmw add ptr %253, i64 1 seq_cst, align 8
  br label %after_if37.epil

after_if37.epil:                                  ; preds = %true_block35.epil, %after_if34.epil
  %255 = bitcast double %216 to i64
  %256 = and i64 %255, 9223372036854775807
  %257 = and i64 %255, 9218868437227405312
  %258 = icmp eq i64 %256, 0
  %259 = icmp ne i64 %257, 0
  %260 = icmp ne i64 %257, 9218868437227405312
  %261 = and i1 %259, %260
  %262 = or i1 %258, %261
  br i1 %262, label %after_if40.epil, label %true_block38.epil

true_block38.epil:                                ; preds = %after_if37.epil
  %263 = load ptr, ptr %105, align 8
  %264 = atomicrmw add ptr %263, i64 1 seq_cst, align 8
  br label %after_if40.epil

after_if40.epil:                                  ; preds = %true_block38.epil, %after_if37.epil
  %265 = bitcast double %232 to i64
  %266 = and i64 %265, 9223372036854775807
  %267 = and i64 %265, 9218868437227405312
  %268 = icmp eq i64 %266, 0
  %269 = icmp ne i64 %267, 0
  %270 = icmp ne i64 %267, 9218868437227405312
  %271 = and i1 %269, %270
  %272 = or i1 %268, %271
  br i1 %272, label %after_if43.epil, label %true_block41.epil

true_block41.epil:                                ; preds = %after_if40.epil
  %273 = load ptr, ptr %105, align 8
  %274 = atomicrmw add ptr %273, i64 1 seq_cst, align 8
  br label %after_if43.epil

after_if43.epil:                                  ; preds = %true_block41.epil, %after_if40.epil
  %275 = fcmp ugt double %232, 0.000000e+00
  br i1 %275, label %after_if46.epil, label %true_block44.epil

true_block44.epil:                                ; preds = %after_if43.epil
  %276 = load ptr, ptr %105, align 8
  %277 = atomicrmw add ptr %276, i64 1 seq_cst, align 8
  br label %after_if46.epil

after_if46.epil:                                  ; preds = %true_block44.epil, %after_if43.epil
  %278 = icmp eq i64 %195, %epil.iter454
  %spec.select122.epil = select i1 %278, double %209, double %.3110289.epil
  %279 = fsub double %209, %spec.select122.epil
  %280 = fmul double %279, %232
  %281 = fadd double %.2106290.epil, %280
  %.4103.epil = select i1 %278, double %212, double %.3102291.epil
  %282 = fsub double %212, %.4103.epil
  %283 = fmul double %282, %232
  %284 = fadd double %.298292.epil, %283
  %.4.epil = select i1 %278, double %216, double %.3293.epil
  %285 = fsub double %216, %.4.epil
  %286 = fmul double %285, %232
  %287 = fadd double %.292294.epil, %286
  %288 = fadd double %.2114288.epil, %232
  %epil.iter454.next = add nuw nsw i64 %epil.iter454, 1
  %epil.iter454.cmp.not = icmp eq i64 %xtraiter453, %epil.iter454.next
  br i1 %epil.iter454.cmp.not, label %after_if3.loopexit, label %for_loop_body28.epil, !llvm.loop !11

after_if3.loopexit426.unr-lcssa.loopexit:         ; preds = %after_if18.3
  br label %after_if3.loopexit426.unr-lcssa

after_if3.loopexit426.unr-lcssa:                  ; preds = %after_if3.loopexit426.unr-lcssa.loopexit, %for_loop_body.lr.ph
  %spec.select.lcssa.ph = phi double [ undef, %for_loop_body.lr.ph ], [ %spec.select, %after_if3.loopexit426.unr-lcssa.loopexit ]
  %.lcssa429.ph = phi double [ undef, %for_loop_body.lr.ph ], [ %759, %after_if3.loopexit426.unr-lcssa.loopexit ]
  %.2101.lcssa.ph = phi double [ undef, %for_loop_body.lr.ph ], [ %.2101, %after_if3.loopexit426.unr-lcssa.loopexit ]
  %.lcssa428.ph = phi double [ undef, %for_loop_body.lr.ph ], [ %762, %after_if3.loopexit426.unr-lcssa.loopexit ]
  %.295.lcssa.ph = phi double [ undef, %for_loop_body.lr.ph ], [ %.295, %after_if3.loopexit426.unr-lcssa.loopexit ]
  %.lcssa427.ph = phi double [ undef, %for_loop_body.lr.ph ], [ %765, %after_if3.loopexit426.unr-lcssa.loopexit ]
  %.lcssa.ph = phi double [ undef, %for_loop_body.lr.ph ], [ %766, %after_if3.loopexit426.unr-lcssa.loopexit ]
  %indvars.iv.unr = phi i64 [ 0, %for_loop_body.lr.ph ], [ %indvars.iv.next.3, %after_if3.loopexit426.unr-lcssa.loopexit ]
  %.191280.unr = phi double [ 0.000000e+00, %for_loop_body.lr.ph ], [ %765, %after_if3.loopexit426.unr-lcssa.loopexit ]
  %.194279.unr = phi double [ 0.000000e+00, %for_loop_body.lr.ph ], [ %.295, %after_if3.loopexit426.unr-lcssa.loopexit ]
  %.197278.unr = phi double [ 0.000000e+00, %for_loop_body.lr.ph ], [ %762, %after_if3.loopexit426.unr-lcssa.loopexit ]
  %.1100277.unr = phi double [ 0.000000e+00, %for_loop_body.lr.ph ], [ %.2101, %after_if3.loopexit426.unr-lcssa.loopexit ]
  %.1105276.unr = phi double [ 0.000000e+00, %for_loop_body.lr.ph ], [ %759, %after_if3.loopexit426.unr-lcssa.loopexit ]
  %.1108275.unr = phi double [ 0.000000e+00, %for_loop_body.lr.ph ], [ %spec.select, %after_if3.loopexit426.unr-lcssa.loopexit ]
  %.1113274.unr = phi double [ 0.000000e+00, %for_loop_body.lr.ph ], [ %766, %after_if3.loopexit426.unr-lcssa.loopexit ]
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %after_if3, label %for_loop_body.epil.preheader

for_loop_body.epil.preheader:                     ; preds = %after_if3.loopexit426.unr-lcssa
  %289 = mul i64 %indvars.iv.unr, -1
  %290 = trunc i64 %indvars.iv.unr to i32
  %291 = add i32 %166, %290
  %292 = zext i32 %291 to i64
  br label %for_loop_body.epil

for_loop_body.epil:                               ; preds = %after_if18.epil, %for_loop_body.epil.preheader
  %.191280.epil = phi double [ %383, %after_if18.epil ], [ %.191280.unr, %for_loop_body.epil.preheader ]
  %.194279.epil = phi double [ %.295.epil, %after_if18.epil ], [ %.194279.unr, %for_loop_body.epil.preheader ]
  %.197278.epil = phi double [ %380, %after_if18.epil ], [ %.197278.unr, %for_loop_body.epil.preheader ]
  %.1100277.epil = phi double [ %.2101.epil, %after_if18.epil ], [ %.1100277.unr, %for_loop_body.epil.preheader ]
  %.1105276.epil = phi double [ %377, %after_if18.epil ], [ %.1105276.unr, %for_loop_body.epil.preheader ]
  %.1108275.epil = phi double [ %spec.select.epil, %after_if18.epil ], [ %.1108275.unr, %for_loop_body.epil.preheader ]
  %.1113274.epil = phi double [ %384, %after_if18.epil ], [ %.1113274.unr, %for_loop_body.epil.preheader ]
  %epil.iter = phi i64 [ %epil.iter.next, %after_if18.epil ], [ 0, %for_loop_body.epil.preheader ]
  %293 = add nuw nsw i64 %292, %epil.iter
  %294 = load ptr, ptr %172, align 8
  %tmp = trunc i64 %293 to i32
  %295 = sext i32 %tmp to i64
  %296 = getelementptr i32, ptr %294, i64 %295
  %297 = load i32, ptr %296, align 4
  %298 = load ptr, ptr %121, align 8
  %299 = sext i32 %297 to i64
  %300 = getelementptr i32, ptr %298, i64 %299
  %301 = atomicrmw or ptr %300, i32 0 seq_cst, align 4
  %302 = shl i32 %301, 2
  %303 = load ptr, ptr %127, align 8
  %304 = load i32, ptr %129, align 4
  %305 = sext i32 %302 to i64
  %306 = sext i32 %304 to i64
  %307 = mul nsw i64 %306, %305
  %308 = add nsw i64 %307, %299
  %309 = getelementptr double, ptr %303, i64 %308
  %310 = load double, ptr %309, align 8
  %311 = or i32 %302, 1
  %312 = sext i32 %311 to i64
  %313 = mul nsw i64 %312, %306
  %314 = add nsw i64 %313, %299
  %315 = getelementptr double, ptr %303, i64 %314
  %316 = load double, ptr %315, align 8
  %317 = or i32 %302, 2
  %318 = sext i32 %317 to i64
  %319 = mul nsw i64 %318, %306
  %320 = add nsw i64 %319, %299
  %321 = getelementptr double, ptr %303, i64 %320
  %322 = load double, ptr %321, align 8
  %323 = or i32 %302, 3
  %324 = sext i32 %323 to i64
  %325 = mul nsw i64 %324, %306
  %326 = add nsw i64 %325, %299
  %327 = getelementptr double, ptr %303, i64 %326
  %328 = load double, ptr %327, align 8
  %329 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  %330 = atomicrmw add ptr %170, i64 1 seq_cst, align 8
  %331 = bitcast double %310 to i64
  %332 = and i64 %331, 9223372036854775807
  %333 = and i64 %331, 9218868437227405312
  %334 = icmp eq i64 %332, 0
  %335 = icmp ne i64 %333, 0
  %336 = icmp ne i64 %333, 9218868437227405312
  %337 = and i1 %335, %336
  %338 = or i1 %334, %337
  br i1 %338, label %after_if6.epil, label %true_block4.epil

true_block4.epil:                                 ; preds = %for_loop_body.epil
  %339 = load ptr, ptr %105, align 8
  %340 = atomicrmw add ptr %339, i64 1 seq_cst, align 8
  br label %after_if6.epil

after_if6.epil:                                   ; preds = %true_block4.epil, %for_loop_body.epil
  %341 = bitcast double %316 to i64
  %342 = and i64 %341, 9223372036854775807
  %343 = and i64 %341, 9218868437227405312
  %344 = icmp eq i64 %342, 0
  %345 = icmp ne i64 %343, 0
  %346 = icmp ne i64 %343, 9218868437227405312
  %347 = and i1 %345, %346
  %348 = or i1 %344, %347
  br i1 %348, label %after_if9.epil, label %true_block7.epil

true_block7.epil:                                 ; preds = %after_if6.epil
  %349 = load ptr, ptr %105, align 8
  %350 = atomicrmw add ptr %349, i64 1 seq_cst, align 8
  br label %after_if9.epil

after_if9.epil:                                   ; preds = %true_block7.epil, %after_if6.epil
  %351 = bitcast double %322 to i64
  %352 = and i64 %351, 9223372036854775807
  %353 = and i64 %351, 9218868437227405312
  %354 = icmp eq i64 %352, 0
  %355 = icmp ne i64 %353, 0
  %356 = icmp ne i64 %353, 9218868437227405312
  %357 = and i1 %355, %356
  %358 = or i1 %354, %357
  br i1 %358, label %after_if12.epil, label %true_block10.epil

true_block10.epil:                                ; preds = %after_if9.epil
  %359 = load ptr, ptr %105, align 8
  %360 = atomicrmw add ptr %359, i64 1 seq_cst, align 8
  br label %after_if12.epil

after_if12.epil:                                  ; preds = %true_block10.epil, %after_if9.epil
  %361 = bitcast double %328 to i64
  %362 = and i64 %361, 9223372036854775807
  %363 = and i64 %361, 9218868437227405312
  %364 = icmp eq i64 %362, 0
  %365 = icmp ne i64 %363, 0
  %366 = icmp ne i64 %363, 9218868437227405312
  %367 = and i1 %365, %366
  %368 = or i1 %364, %367
  br i1 %368, label %after_if15.epil, label %true_block13.epil

true_block13.epil:                                ; preds = %after_if12.epil
  %369 = load ptr, ptr %105, align 8
  %370 = atomicrmw add ptr %369, i64 1 seq_cst, align 8
  br label %after_if15.epil

after_if15.epil:                                  ; preds = %true_block13.epil, %after_if12.epil
  %371 = fcmp ugt double %328, 0.000000e+00
  br i1 %371, label %after_if18.epil, label %true_block16.epil

true_block16.epil:                                ; preds = %after_if15.epil
  %372 = load ptr, ptr %105, align 8
  %373 = atomicrmw add ptr %372, i64 1 seq_cst, align 8
  br label %after_if18.epil

after_if18.epil:                                  ; preds = %true_block16.epil, %after_if15.epil
  %374 = icmp eq i64 %289, %epil.iter
  %spec.select.epil = select i1 %374, double %310, double %.1108275.epil
  %375 = fsub double %310, %spec.select.epil
  %376 = fmul double %375, %328
  %377 = fadd double %.1105276.epil, %376
  %.2101.epil = select i1 %374, double %316, double %.1100277.epil
  %378 = fsub double %316, %.2101.epil
  %379 = fmul double %328, %378
  %380 = fadd double %.197278.epil, %379
  %.295.epil = select i1 %374, double %322, double %.194279.epil
  %381 = fsub double %322, %.295.epil
  %382 = fmul double %328, %381
  %383 = fadd double %.191280.epil, %382
  %384 = fadd double %.1113274.epil, %328
  %epil.iter.next = add nuw nsw i64 %epil.iter, 1
  %epil.iter.cmp.not = icmp eq i64 %xtraiter, %epil.iter.next
  br i1 %epil.iter.cmp.not, label %after_if3.loopexit512, label %for_loop_body.epil, !llvm.loop !13

after_if3.loopexit:                               ; preds = %after_if46.epil
  br label %after_if3

after_if3.loopexit512:                            ; preds = %after_if18.epil
  br label %after_if3

after_if3:                                        ; preds = %after_if3.loopexit512, %after_if3.loopexit, %after_if3.loopexit426.unr-lcssa, %after_if3.loopexit.unr-lcssa, %false_block2, %true_block1
  %.0112 = phi double [ 0.000000e+00, %false_block2 ], [ 0.000000e+00, %true_block1 ], [ %.lcssa430.ph, %after_if3.loopexit.unr-lcssa ], [ %.lcssa.ph, %after_if3.loopexit426.unr-lcssa ], [ %288, %after_if3.loopexit ], [ %384, %after_if3.loopexit512 ]
  %.0107 = phi double [ 0.000000e+00, %false_block2 ], [ 0.000000e+00, %true_block1 ], [ %spec.select122.lcssa.ph, %after_if3.loopexit.unr-lcssa ], [ %spec.select.lcssa.ph, %after_if3.loopexit426.unr-lcssa ], [ %spec.select122.epil, %after_if3.loopexit ], [ %spec.select.epil, %after_if3.loopexit512 ]
  %.0104 = phi double [ 0.000000e+00, %false_block2 ], [ 0.000000e+00, %true_block1 ], [ %.lcssa433.ph, %after_if3.loopexit.unr-lcssa ], [ %.lcssa429.ph, %after_if3.loopexit426.unr-lcssa ], [ %281, %after_if3.loopexit ], [ %377, %after_if3.loopexit512 ]
  %.099 = phi double [ 0.000000e+00, %false_block2 ], [ 0.000000e+00, %true_block1 ], [ %.4103.lcssa.ph, %after_if3.loopexit.unr-lcssa ], [ %.2101.lcssa.ph, %after_if3.loopexit426.unr-lcssa ], [ %.4103.epil, %after_if3.loopexit ], [ %.2101.epil, %after_if3.loopexit512 ]
  %.096 = phi double [ 0.000000e+00, %false_block2 ], [ 0.000000e+00, %true_block1 ], [ %.lcssa432.ph, %after_if3.loopexit.unr-lcssa ], [ %.lcssa428.ph, %after_if3.loopexit426.unr-lcssa ], [ %284, %after_if3.loopexit ], [ %380, %after_if3.loopexit512 ]
  %.093 = phi double [ 0.000000e+00, %false_block2 ], [ 0.000000e+00, %true_block1 ], [ %.4.lcssa.ph, %after_if3.loopexit.unr-lcssa ], [ %.295.lcssa.ph, %after_if3.loopexit426.unr-lcssa ], [ %.4.epil, %after_if3.loopexit ], [ %.295.epil, %after_if3.loopexit512 ]
  %.090 = phi double [ 0.000000e+00, %false_block2 ], [ 0.000000e+00, %true_block1 ], [ %.lcssa431.ph, %after_if3.loopexit.unr-lcssa ], [ %.lcssa427.ph, %after_if3.loopexit426.unr-lcssa ], [ %287, %after_if3.loopexit ], [ %383, %after_if3.loopexit512 ]
  %385 = fcmp one double %.0112, %154
  %386 = fdiv double %.0104, %.0112
  %387 = fadd double %.0107, %386
  %388 = bitcast double %387 to i64
  %389 = load ptr, ptr %0, align 8
  %390 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %389, i64 0, i32 6, i32 1
  %391 = load ptr, ptr %390, align 8
  %392 = getelementptr i64, ptr %391, i64 %101
  %393 = load i64, ptr %392, align 8
  %394 = and i64 %393, %388
  %395 = bitcast i64 %394 to double
  %396 = and i64 %388, 9223372036854775807
  %397 = and i64 %388, 9218868437227405312
  %398 = icmp eq i64 %396, 0
  %399 = icmp ne i64 %397, 0
  %400 = icmp ne i64 %397, 9218868437227405312
  %401 = and i1 %399, %400
  %402 = or i1 %398, %401
  br i1 %402, label %after_if58, label %true_block56

for_loop_body:                                    ; preds = %after_if18.3, %for_loop_body.lr.ph.new
  %lsr.iv = phi i32 [ %lsr.iv.next, %after_if18.3 ], [ %166, %for_loop_body.lr.ph.new ]
  %indvars.iv = phi i64 [ 0, %for_loop_body.lr.ph.new ], [ %indvars.iv.next.3, %after_if18.3 ]
  %.191280 = phi double [ 0.000000e+00, %for_loop_body.lr.ph.new ], [ %765, %after_if18.3 ]
  %.194279 = phi double [ 0.000000e+00, %for_loop_body.lr.ph.new ], [ %.295, %after_if18.3 ]
  %.197278 = phi double [ 0.000000e+00, %for_loop_body.lr.ph.new ], [ %762, %after_if18.3 ]
  %.1100277 = phi double [ 0.000000e+00, %for_loop_body.lr.ph.new ], [ %.2101, %after_if18.3 ]
  %.1105276 = phi double [ 0.000000e+00, %for_loop_body.lr.ph.new ], [ %759, %after_if18.3 ]
  %.1108275 = phi double [ 0.000000e+00, %for_loop_body.lr.ph.new ], [ %spec.select, %after_if18.3 ]
  %.1113274 = phi double [ 0.000000e+00, %for_loop_body.lr.ph.new ], [ %766, %after_if18.3 ]
  %403 = load ptr, ptr %172, align 8
  %404 = sext i32 %lsr.iv to i64
  %405 = getelementptr i32, ptr %403, i64 %404
  %406 = load i32, ptr %405, align 4
  %407 = load ptr, ptr %121, align 8
  %408 = sext i32 %406 to i64
  %409 = getelementptr i32, ptr %407, i64 %408
  %410 = atomicrmw or ptr %409, i32 0 seq_cst, align 4
  %411 = shl i32 %410, 2
  %412 = load ptr, ptr %127, align 8
  %413 = load i32, ptr %129, align 4
  %414 = sext i32 %411 to i64
  %415 = sext i32 %413 to i64
  %416 = mul nsw i64 %415, %414
  %417 = add nsw i64 %416, %408
  %418 = getelementptr double, ptr %412, i64 %417
  %419 = load double, ptr %418, align 8
  %420 = or i32 %411, 1
  %421 = sext i32 %420 to i64
  %422 = mul nsw i64 %421, %415
  %423 = add nsw i64 %422, %408
  %424 = getelementptr double, ptr %412, i64 %423
  %425 = load double, ptr %424, align 8
  %426 = or i32 %411, 2
  %427 = sext i32 %426 to i64
  %428 = mul nsw i64 %427, %415
  %429 = add nsw i64 %428, %408
  %430 = getelementptr double, ptr %412, i64 %429
  %431 = load double, ptr %430, align 8
  %432 = or i32 %411, 3
  %433 = sext i32 %432 to i64
  %434 = mul nsw i64 %433, %415
  %435 = add nsw i64 %434, %408
  %436 = getelementptr double, ptr %412, i64 %435
  %437 = load double, ptr %436, align 8
  %438 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  %439 = atomicrmw add ptr %170, i64 1 seq_cst, align 8
  %440 = bitcast double %419 to i64
  %441 = and i64 %440, 9223372036854775807
  %442 = and i64 %440, 9218868437227405312
  %443 = icmp eq i64 %441, 0
  %444 = icmp ne i64 %442, 0
  %445 = icmp ne i64 %442, 9218868437227405312
  %446 = and i1 %444, %445
  %447 = or i1 %443, %446
  br i1 %447, label %after_if6, label %true_block4

true_block4:                                      ; preds = %for_loop_body
  %448 = load ptr, ptr %105, align 8
  %449 = atomicrmw add ptr %448, i64 1 seq_cst, align 8
  br label %after_if6

after_if6:                                        ; preds = %true_block4, %for_loop_body
  %450 = bitcast double %425 to i64
  %451 = and i64 %450, 9223372036854775807
  %452 = and i64 %450, 9218868437227405312
  %453 = icmp eq i64 %451, 0
  %454 = icmp ne i64 %452, 0
  %455 = icmp ne i64 %452, 9218868437227405312
  %456 = and i1 %454, %455
  %457 = or i1 %453, %456
  br i1 %457, label %after_if9, label %true_block7

true_block7:                                      ; preds = %after_if6
  %458 = load ptr, ptr %105, align 8
  %459 = atomicrmw add ptr %458, i64 1 seq_cst, align 8
  br label %after_if9

after_if9:                                        ; preds = %true_block7, %after_if6
  %460 = bitcast double %431 to i64
  %461 = and i64 %460, 9223372036854775807
  %462 = and i64 %460, 9218868437227405312
  %463 = icmp eq i64 %461, 0
  %464 = icmp ne i64 %462, 0
  %465 = icmp ne i64 %462, 9218868437227405312
  %466 = and i1 %464, %465
  %467 = or i1 %463, %466
  br i1 %467, label %after_if12, label %true_block10

true_block10:                                     ; preds = %after_if9
  %468 = load ptr, ptr %105, align 8
  %469 = atomicrmw add ptr %468, i64 1 seq_cst, align 8
  br label %after_if12

after_if12:                                       ; preds = %true_block10, %after_if9
  %470 = bitcast double %437 to i64
  %471 = and i64 %470, 9223372036854775807
  %472 = and i64 %470, 9218868437227405312
  %473 = icmp eq i64 %471, 0
  %474 = icmp ne i64 %472, 0
  %475 = icmp ne i64 %472, 9218868437227405312
  %476 = and i1 %474, %475
  %477 = or i1 %473, %476
  br i1 %477, label %after_if15, label %true_block13

true_block13:                                     ; preds = %after_if12
  %478 = load ptr, ptr %105, align 8
  %479 = atomicrmw add ptr %478, i64 1 seq_cst, align 8
  br label %after_if15

after_if15:                                       ; preds = %true_block13, %after_if12
  %480 = fcmp ugt double %437, 0.000000e+00
  br i1 %480, label %after_if18, label %true_block16

true_block16:                                     ; preds = %after_if15
  %481 = load ptr, ptr %105, align 8
  %482 = atomicrmw add ptr %481, i64 1 seq_cst, align 8
  br label %after_if18

after_if18:                                       ; preds = %true_block16, %after_if15
  %483 = icmp eq i64 %indvars.iv, 0
  %spec.select = select i1 %483, double %419, double %.1108275
  %484 = fsub double %419, %spec.select
  %485 = fmul double %484, %437
  %486 = fadd double %.1105276, %485
  %.2101 = select i1 %483, double %425, double %.1100277
  %487 = fsub double %425, %.2101
  %488 = fmul double %437, %487
  %489 = fadd double %.197278, %488
  %.295 = select i1 %483, double %431, double %.194279
  %490 = fsub double %431, %.295
  %491 = fmul double %437, %490
  %492 = fadd double %.191280, %491
  %493 = fadd double %.1113274, %437
  %494 = add i32 %lsr.iv, 1
  %495 = load ptr, ptr %172, align 8
  %496 = sext i32 %494 to i64
  %497 = getelementptr i32, ptr %495, i64 %496
  %498 = load i32, ptr %497, align 4
  %499 = load ptr, ptr %121, align 8
  %500 = sext i32 %498 to i64
  %501 = getelementptr i32, ptr %499, i64 %500
  %502 = atomicrmw or ptr %501, i32 0 seq_cst, align 4
  %503 = shl i32 %502, 2
  %504 = load ptr, ptr %127, align 8
  %505 = load i32, ptr %129, align 4
  %506 = sext i32 %503 to i64
  %507 = sext i32 %505 to i64
  %508 = mul nsw i64 %507, %506
  %509 = add nsw i64 %508, %500
  %510 = getelementptr double, ptr %504, i64 %509
  %511 = load double, ptr %510, align 8
  %512 = or i32 %503, 1
  %513 = sext i32 %512 to i64
  %514 = mul nsw i64 %513, %507
  %515 = add nsw i64 %514, %500
  %516 = getelementptr double, ptr %504, i64 %515
  %517 = load double, ptr %516, align 8
  %518 = or i32 %503, 2
  %519 = sext i32 %518 to i64
  %520 = mul nsw i64 %519, %507
  %521 = add nsw i64 %520, %500
  %522 = getelementptr double, ptr %504, i64 %521
  %523 = load double, ptr %522, align 8
  %524 = or i32 %503, 3
  %525 = sext i32 %524 to i64
  %526 = mul nsw i64 %525, %507
  %527 = add nsw i64 %526, %500
  %528 = getelementptr double, ptr %504, i64 %527
  %529 = load double, ptr %528, align 8
  %530 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  %531 = atomicrmw add ptr %170, i64 1 seq_cst, align 8
  %532 = bitcast double %511 to i64
  %533 = and i64 %532, 9223372036854775807
  %534 = and i64 %532, 9218868437227405312
  %535 = icmp eq i64 %533, 0
  %536 = icmp ne i64 %534, 0
  %537 = icmp ne i64 %534, 9218868437227405312
  %538 = and i1 %536, %537
  %539 = or i1 %535, %538
  br i1 %539, label %after_if6.1, label %true_block4.1

true_block4.1:                                    ; preds = %after_if18
  %540 = load ptr, ptr %105, align 8
  %541 = atomicrmw add ptr %540, i64 1 seq_cst, align 8
  br label %after_if6.1

after_if6.1:                                      ; preds = %true_block4.1, %after_if18
  %542 = bitcast double %517 to i64
  %543 = and i64 %542, 9223372036854775807
  %544 = and i64 %542, 9218868437227405312
  %545 = icmp eq i64 %543, 0
  %546 = icmp ne i64 %544, 0
  %547 = icmp ne i64 %544, 9218868437227405312
  %548 = and i1 %546, %547
  %549 = or i1 %545, %548
  br i1 %549, label %after_if9.1, label %true_block7.1

true_block7.1:                                    ; preds = %after_if6.1
  %550 = load ptr, ptr %105, align 8
  %551 = atomicrmw add ptr %550, i64 1 seq_cst, align 8
  br label %after_if9.1

after_if9.1:                                      ; preds = %true_block7.1, %after_if6.1
  %552 = bitcast double %523 to i64
  %553 = and i64 %552, 9223372036854775807
  %554 = and i64 %552, 9218868437227405312
  %555 = icmp eq i64 %553, 0
  %556 = icmp ne i64 %554, 0
  %557 = icmp ne i64 %554, 9218868437227405312
  %558 = and i1 %556, %557
  %559 = or i1 %555, %558
  br i1 %559, label %after_if12.1, label %true_block10.1

true_block10.1:                                   ; preds = %after_if9.1
  %560 = load ptr, ptr %105, align 8
  %561 = atomicrmw add ptr %560, i64 1 seq_cst, align 8
  br label %after_if12.1

after_if12.1:                                     ; preds = %true_block10.1, %after_if9.1
  %562 = bitcast double %529 to i64
  %563 = and i64 %562, 9223372036854775807
  %564 = and i64 %562, 9218868437227405312
  %565 = icmp eq i64 %563, 0
  %566 = icmp ne i64 %564, 0
  %567 = icmp ne i64 %564, 9218868437227405312
  %568 = and i1 %566, %567
  %569 = or i1 %565, %568
  br i1 %569, label %after_if15.1, label %true_block13.1

true_block13.1:                                   ; preds = %after_if12.1
  %570 = load ptr, ptr %105, align 8
  %571 = atomicrmw add ptr %570, i64 1 seq_cst, align 8
  br label %after_if15.1

after_if15.1:                                     ; preds = %true_block13.1, %after_if12.1
  %572 = fcmp ugt double %529, 0.000000e+00
  br i1 %572, label %after_if18.1, label %true_block16.1

true_block16.1:                                   ; preds = %after_if15.1
  %573 = load ptr, ptr %105, align 8
  %574 = atomicrmw add ptr %573, i64 1 seq_cst, align 8
  br label %after_if18.1

after_if18.1:                                     ; preds = %true_block16.1, %after_if15.1
  %575 = fsub double %511, %spec.select
  %576 = fmul double %575, %529
  %577 = fadd double %486, %576
  %578 = fsub double %517, %.2101
  %579 = fmul double %529, %578
  %580 = fadd double %489, %579
  %581 = fsub double %523, %.295
  %582 = fmul double %529, %581
  %583 = fadd double %492, %582
  %584 = fadd double %493, %529
  %585 = add i32 %lsr.iv, 2
  %586 = load ptr, ptr %172, align 8
  %587 = sext i32 %585 to i64
  %588 = getelementptr i32, ptr %586, i64 %587
  %589 = load i32, ptr %588, align 4
  %590 = load ptr, ptr %121, align 8
  %591 = sext i32 %589 to i64
  %592 = getelementptr i32, ptr %590, i64 %591
  %593 = atomicrmw or ptr %592, i32 0 seq_cst, align 4
  %594 = shl i32 %593, 2
  %595 = load ptr, ptr %127, align 8
  %596 = load i32, ptr %129, align 4
  %597 = sext i32 %594 to i64
  %598 = sext i32 %596 to i64
  %599 = mul nsw i64 %598, %597
  %600 = add nsw i64 %599, %591
  %601 = getelementptr double, ptr %595, i64 %600
  %602 = load double, ptr %601, align 8
  %603 = or i32 %594, 1
  %604 = sext i32 %603 to i64
  %605 = mul nsw i64 %604, %598
  %606 = add nsw i64 %605, %591
  %607 = getelementptr double, ptr %595, i64 %606
  %608 = load double, ptr %607, align 8
  %609 = or i32 %594, 2
  %610 = sext i32 %609 to i64
  %611 = mul nsw i64 %610, %598
  %612 = add nsw i64 %611, %591
  %613 = getelementptr double, ptr %595, i64 %612
  %614 = load double, ptr %613, align 8
  %615 = or i32 %594, 3
  %616 = sext i32 %615 to i64
  %617 = mul nsw i64 %616, %598
  %618 = add nsw i64 %617, %591
  %619 = getelementptr double, ptr %595, i64 %618
  %620 = load double, ptr %619, align 8
  %621 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  %622 = atomicrmw add ptr %170, i64 1 seq_cst, align 8
  %623 = bitcast double %602 to i64
  %624 = and i64 %623, 9223372036854775807
  %625 = and i64 %623, 9218868437227405312
  %626 = icmp eq i64 %624, 0
  %627 = icmp ne i64 %625, 0
  %628 = icmp ne i64 %625, 9218868437227405312
  %629 = and i1 %627, %628
  %630 = or i1 %626, %629
  br i1 %630, label %after_if6.2, label %true_block4.2

true_block4.2:                                    ; preds = %after_if18.1
  %631 = load ptr, ptr %105, align 8
  %632 = atomicrmw add ptr %631, i64 1 seq_cst, align 8
  br label %after_if6.2

after_if6.2:                                      ; preds = %true_block4.2, %after_if18.1
  %633 = bitcast double %608 to i64
  %634 = and i64 %633, 9223372036854775807
  %635 = and i64 %633, 9218868437227405312
  %636 = icmp eq i64 %634, 0
  %637 = icmp ne i64 %635, 0
  %638 = icmp ne i64 %635, 9218868437227405312
  %639 = and i1 %637, %638
  %640 = or i1 %636, %639
  br i1 %640, label %after_if9.2, label %true_block7.2

true_block7.2:                                    ; preds = %after_if6.2
  %641 = load ptr, ptr %105, align 8
  %642 = atomicrmw add ptr %641, i64 1 seq_cst, align 8
  br label %after_if9.2

after_if9.2:                                      ; preds = %true_block7.2, %after_if6.2
  %643 = bitcast double %614 to i64
  %644 = and i64 %643, 9223372036854775807
  %645 = and i64 %643, 9218868437227405312
  %646 = icmp eq i64 %644, 0
  %647 = icmp ne i64 %645, 0
  %648 = icmp ne i64 %645, 9218868437227405312
  %649 = and i1 %647, %648
  %650 = or i1 %646, %649
  br i1 %650, label %after_if12.2, label %true_block10.2

true_block10.2:                                   ; preds = %after_if9.2
  %651 = load ptr, ptr %105, align 8
  %652 = atomicrmw add ptr %651, i64 1 seq_cst, align 8
  br label %after_if12.2

after_if12.2:                                     ; preds = %true_block10.2, %after_if9.2
  %653 = bitcast double %620 to i64
  %654 = and i64 %653, 9223372036854775807
  %655 = and i64 %653, 9218868437227405312
  %656 = icmp eq i64 %654, 0
  %657 = icmp ne i64 %655, 0
  %658 = icmp ne i64 %655, 9218868437227405312
  %659 = and i1 %657, %658
  %660 = or i1 %656, %659
  br i1 %660, label %after_if15.2, label %true_block13.2

true_block13.2:                                   ; preds = %after_if12.2
  %661 = load ptr, ptr %105, align 8
  %662 = atomicrmw add ptr %661, i64 1 seq_cst, align 8
  br label %after_if15.2

after_if15.2:                                     ; preds = %true_block13.2, %after_if12.2
  %663 = fcmp ugt double %620, 0.000000e+00
  br i1 %663, label %after_if18.2, label %true_block16.2

true_block16.2:                                   ; preds = %after_if15.2
  %664 = load ptr, ptr %105, align 8
  %665 = atomicrmw add ptr %664, i64 1 seq_cst, align 8
  br label %after_if18.2

after_if18.2:                                     ; preds = %true_block16.2, %after_if15.2
  %666 = fsub double %602, %spec.select
  %667 = fmul double %666, %620
  %668 = fadd double %577, %667
  %669 = fsub double %608, %.2101
  %670 = fmul double %620, %669
  %671 = fadd double %580, %670
  %672 = fsub double %614, %.295
  %673 = fmul double %620, %672
  %674 = fadd double %583, %673
  %675 = fadd double %584, %620
  %676 = add i32 %lsr.iv, 3
  %677 = load ptr, ptr %172, align 8
  %678 = sext i32 %676 to i64
  %679 = getelementptr i32, ptr %677, i64 %678
  %680 = load i32, ptr %679, align 4
  %681 = load ptr, ptr %121, align 8
  %682 = sext i32 %680 to i64
  %683 = getelementptr i32, ptr %681, i64 %682
  %684 = atomicrmw or ptr %683, i32 0 seq_cst, align 4
  %685 = shl i32 %684, 2
  %686 = load ptr, ptr %127, align 8
  %687 = load i32, ptr %129, align 4
  %688 = sext i32 %685 to i64
  %689 = sext i32 %687 to i64
  %690 = mul nsw i64 %689, %688
  %691 = add nsw i64 %690, %682
  %692 = getelementptr double, ptr %686, i64 %691
  %693 = load double, ptr %692, align 8
  %694 = or i32 %685, 1
  %695 = sext i32 %694 to i64
  %696 = mul nsw i64 %695, %689
  %697 = add nsw i64 %696, %682
  %698 = getelementptr double, ptr %686, i64 %697
  %699 = load double, ptr %698, align 8
  %700 = or i32 %685, 2
  %701 = sext i32 %700 to i64
  %702 = mul nsw i64 %701, %689
  %703 = add nsw i64 %702, %682
  %704 = getelementptr double, ptr %686, i64 %703
  %705 = load double, ptr %704, align 8
  %706 = or i32 %685, 3
  %707 = sext i32 %706 to i64
  %708 = mul nsw i64 %707, %689
  %709 = add nsw i64 %708, %682
  %710 = getelementptr double, ptr %686, i64 %709
  %711 = load double, ptr %710, align 8
  %712 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  %713 = atomicrmw add ptr %170, i64 1 seq_cst, align 8
  %714 = bitcast double %693 to i64
  %715 = and i64 %714, 9223372036854775807
  %716 = and i64 %714, 9218868437227405312
  %717 = icmp eq i64 %715, 0
  %718 = icmp ne i64 %716, 0
  %719 = icmp ne i64 %716, 9218868437227405312
  %720 = and i1 %718, %719
  %721 = or i1 %717, %720
  br i1 %721, label %after_if6.3, label %true_block4.3

true_block4.3:                                    ; preds = %after_if18.2
  %722 = load ptr, ptr %105, align 8
  %723 = atomicrmw add ptr %722, i64 1 seq_cst, align 8
  br label %after_if6.3

after_if6.3:                                      ; preds = %true_block4.3, %after_if18.2
  %724 = bitcast double %699 to i64
  %725 = and i64 %724, 9223372036854775807
  %726 = and i64 %724, 9218868437227405312
  %727 = icmp eq i64 %725, 0
  %728 = icmp ne i64 %726, 0
  %729 = icmp ne i64 %726, 9218868437227405312
  %730 = and i1 %728, %729
  %731 = or i1 %727, %730
  br i1 %731, label %after_if9.3, label %true_block7.3

true_block7.3:                                    ; preds = %after_if6.3
  %732 = load ptr, ptr %105, align 8
  %733 = atomicrmw add ptr %732, i64 1 seq_cst, align 8
  br label %after_if9.3

after_if9.3:                                      ; preds = %true_block7.3, %after_if6.3
  %734 = bitcast double %705 to i64
  %735 = and i64 %734, 9223372036854775807
  %736 = and i64 %734, 9218868437227405312
  %737 = icmp eq i64 %735, 0
  %738 = icmp ne i64 %736, 0
  %739 = icmp ne i64 %736, 9218868437227405312
  %740 = and i1 %738, %739
  %741 = or i1 %737, %740
  br i1 %741, label %after_if12.3, label %true_block10.3

true_block10.3:                                   ; preds = %after_if9.3
  %742 = load ptr, ptr %105, align 8
  %743 = atomicrmw add ptr %742, i64 1 seq_cst, align 8
  br label %after_if12.3

after_if12.3:                                     ; preds = %true_block10.3, %after_if9.3
  %744 = bitcast double %711 to i64
  %745 = and i64 %744, 9223372036854775807
  %746 = and i64 %744, 9218868437227405312
  %747 = icmp eq i64 %745, 0
  %748 = icmp ne i64 %746, 0
  %749 = icmp ne i64 %746, 9218868437227405312
  %750 = and i1 %748, %749
  %751 = or i1 %747, %750
  br i1 %751, label %after_if15.3, label %true_block13.3

true_block13.3:                                   ; preds = %after_if12.3
  %752 = load ptr, ptr %105, align 8
  %753 = atomicrmw add ptr %752, i64 1 seq_cst, align 8
  br label %after_if15.3

after_if15.3:                                     ; preds = %true_block13.3, %after_if12.3
  %754 = fcmp ugt double %711, 0.000000e+00
  br i1 %754, label %after_if18.3, label %true_block16.3

true_block16.3:                                   ; preds = %after_if15.3
  %755 = load ptr, ptr %105, align 8
  %756 = atomicrmw add ptr %755, i64 1 seq_cst, align 8
  br label %after_if18.3

after_if18.3:                                     ; preds = %true_block16.3, %after_if15.3
  %757 = fsub double %693, %spec.select
  %758 = fmul double %757, %711
  %759 = fadd double %668, %758
  %760 = fsub double %699, %.2101
  %761 = fmul double %711, %760
  %762 = fadd double %671, %761
  %763 = fsub double %705, %.295
  %764 = fmul double %711, %763
  %765 = fadd double %674, %764
  %766 = fadd double %675, %711
  %indvars.iv.next.3 = add nuw i64 %indvars.iv, 4
  %lsr.iv.next = add i32 %lsr.iv, 4
  %niter.ncmp.3 = icmp eq i64 %unroll_iter, %indvars.iv.next.3
  br i1 %niter.ncmp.3, label %after_if3.loopexit426.unr-lcssa.loopexit, label %for_loop_body

for_loop_body28:                                  ; preds = %after_if46.3, %for_loop_body28.lr.ph.new
  %lsr.iv513 = phi i32 [ %lsr.iv.next514, %after_if46.3 ], [ %178, %for_loop_body28.lr.ph.new ]
  %indvars.iv353 = phi i64 [ 0, %for_loop_body28.lr.ph.new ], [ %indvars.iv.next354.3, %after_if46.3 ]
  %.292294 = phi double [ 0.000000e+00, %for_loop_body28.lr.ph.new ], [ %1121, %after_if46.3 ]
  %.3293 = phi double [ 0.000000e+00, %for_loop_body28.lr.ph.new ], [ %.4, %after_if46.3 ]
  %.298292 = phi double [ 0.000000e+00, %for_loop_body28.lr.ph.new ], [ %1118, %after_if46.3 ]
  %.3102291 = phi double [ 0.000000e+00, %for_loop_body28.lr.ph.new ], [ %.4103, %after_if46.3 ]
  %.2106290 = phi double [ 0.000000e+00, %for_loop_body28.lr.ph.new ], [ %1115, %after_if46.3 ]
  %.3110289 = phi double [ 0.000000e+00, %for_loop_body28.lr.ph.new ], [ %spec.select122, %after_if46.3 ]
  %.2114288 = phi double [ 0.000000e+00, %for_loop_body28.lr.ph.new ], [ %1122, %after_if46.3 ]
  %767 = load ptr, ptr %188, align 8
  %768 = sext i32 %lsr.iv513 to i64
  %769 = getelementptr i32, ptr %767, i64 %768
  %770 = load i32, ptr %769, align 4
  %771 = load ptr, ptr %189, align 8
  %772 = load i32, ptr %190, align 4
  %773 = sext i32 %772 to i64
  %774 = sext i32 %770 to i64
  %775 = getelementptr double, ptr %771, i64 %774
  %776 = load double, ptr %775, align 8
  %777 = add nsw i64 %773, %774
  %778 = getelementptr double, ptr %771, i64 %777
  %779 = load double, ptr %778, align 8
  %780 = shl nsw i64 %773, 1
  %781 = add nsw i64 %780, %774
  %782 = getelementptr double, ptr %771, i64 %781
  %783 = load double, ptr %782, align 8
  %784 = mul nsw i64 %773, 6
  %785 = add nsw i64 %784, %774
  %786 = getelementptr double, ptr %771, i64 %785
  %787 = load double, ptr %786, align 8
  %788 = load ptr, ptr %191, align 8
  %789 = load i32, ptr %192, align 4
  %790 = sext i32 %789 to i64
  %791 = getelementptr i64, ptr %788, i64 %768
  %792 = load i64, ptr %791, align 8
  %793 = uitofp i64 %792 to double
  %794 = add nsw i64 %790, %768
  %795 = getelementptr i64, ptr %788, i64 %794
  %796 = load i64, ptr %795, align 8
  %797 = uitofp i64 %796 to double
  %798 = fdiv double %793, %797
  %799 = fmul double %787, %798
  %800 = atomicrmw add ptr %184, i64 1 seq_cst, align 8
  %801 = atomicrmw add ptr %186, i64 1 seq_cst, align 8
  %802 = bitcast double %776 to i64
  %803 = and i64 %802, 9223372036854775807
  %804 = and i64 %802, 9218868437227405312
  %805 = icmp eq i64 %803, 0
  %806 = icmp ne i64 %804, 0
  %807 = icmp ne i64 %804, 9218868437227405312
  %808 = and i1 %806, %807
  %809 = or i1 %805, %808
  br i1 %809, label %after_if34, label %true_block32

true_block32:                                     ; preds = %for_loop_body28
  %810 = load ptr, ptr %105, align 8
  %811 = atomicrmw add ptr %810, i64 1 seq_cst, align 8
  br label %after_if34

after_if34:                                       ; preds = %true_block32, %for_loop_body28
  %812 = bitcast double %779 to i64
  %813 = and i64 %812, 9223372036854775807
  %814 = and i64 %812, 9218868437227405312
  %815 = icmp eq i64 %813, 0
  %816 = icmp ne i64 %814, 0
  %817 = icmp ne i64 %814, 9218868437227405312
  %818 = and i1 %816, %817
  %819 = or i1 %815, %818
  br i1 %819, label %after_if37, label %true_block35

true_block35:                                     ; preds = %after_if34
  %820 = load ptr, ptr %105, align 8
  %821 = atomicrmw add ptr %820, i64 1 seq_cst, align 8
  br label %after_if37

after_if37:                                       ; preds = %true_block35, %after_if34
  %822 = bitcast double %783 to i64
  %823 = and i64 %822, 9223372036854775807
  %824 = and i64 %822, 9218868437227405312
  %825 = icmp eq i64 %823, 0
  %826 = icmp ne i64 %824, 0
  %827 = icmp ne i64 %824, 9218868437227405312
  %828 = and i1 %826, %827
  %829 = or i1 %825, %828
  br i1 %829, label %after_if40, label %true_block38

true_block38:                                     ; preds = %after_if37
  %830 = load ptr, ptr %105, align 8
  %831 = atomicrmw add ptr %830, i64 1 seq_cst, align 8
  br label %after_if40

after_if40:                                       ; preds = %true_block38, %after_if37
  %832 = bitcast double %799 to i64
  %833 = and i64 %832, 9223372036854775807
  %834 = and i64 %832, 9218868437227405312
  %835 = icmp eq i64 %833, 0
  %836 = icmp ne i64 %834, 0
  %837 = icmp ne i64 %834, 9218868437227405312
  %838 = and i1 %836, %837
  %839 = or i1 %835, %838
  br i1 %839, label %after_if43, label %true_block41

true_block41:                                     ; preds = %after_if40
  %840 = load ptr, ptr %105, align 8
  %841 = atomicrmw add ptr %840, i64 1 seq_cst, align 8
  br label %after_if43

after_if43:                                       ; preds = %true_block41, %after_if40
  %842 = fcmp ugt double %799, 0.000000e+00
  br i1 %842, label %after_if46, label %true_block44

true_block44:                                     ; preds = %after_if43
  %843 = load ptr, ptr %105, align 8
  %844 = atomicrmw add ptr %843, i64 1 seq_cst, align 8
  br label %after_if46

after_if46:                                       ; preds = %true_block44, %after_if43
  %845 = icmp eq i64 %indvars.iv353, 0
  %spec.select122 = select i1 %845, double %776, double %.3110289
  %846 = fsub double %776, %spec.select122
  %847 = fmul double %846, %799
  %848 = fadd double %.2106290, %847
  %.4103 = select i1 %845, double %779, double %.3102291
  %849 = fsub double %779, %.4103
  %850 = fmul double %849, %799
  %851 = fadd double %.298292, %850
  %.4 = select i1 %845, double %783, double %.3293
  %852 = fsub double %783, %.4
  %853 = fmul double %852, %799
  %854 = fadd double %.292294, %853
  %855 = fadd double %.2114288, %799
  %856 = add i32 %lsr.iv513, 1
  %857 = load ptr, ptr %188, align 8
  %858 = sext i32 %856 to i64
  %859 = getelementptr i32, ptr %857, i64 %858
  %860 = load i32, ptr %859, align 4
  %861 = load ptr, ptr %189, align 8
  %862 = load i32, ptr %190, align 4
  %863 = sext i32 %862 to i64
  %864 = sext i32 %860 to i64
  %865 = getelementptr double, ptr %861, i64 %864
  %866 = load double, ptr %865, align 8
  %867 = add nsw i64 %863, %864
  %868 = getelementptr double, ptr %861, i64 %867
  %869 = load double, ptr %868, align 8
  %870 = shl nsw i64 %863, 1
  %871 = add nsw i64 %870, %864
  %872 = getelementptr double, ptr %861, i64 %871
  %873 = load double, ptr %872, align 8
  %874 = mul nsw i64 %863, 6
  %875 = add nsw i64 %874, %864
  %876 = getelementptr double, ptr %861, i64 %875
  %877 = load double, ptr %876, align 8
  %878 = load ptr, ptr %191, align 8
  %879 = load i32, ptr %192, align 4
  %880 = sext i32 %879 to i64
  %881 = getelementptr i64, ptr %878, i64 %858
  %882 = load i64, ptr %881, align 8
  %883 = uitofp i64 %882 to double
  %884 = add nsw i64 %880, %858
  %885 = getelementptr i64, ptr %878, i64 %884
  %886 = load i64, ptr %885, align 8
  %887 = uitofp i64 %886 to double
  %888 = fdiv double %883, %887
  %889 = fmul double %877, %888
  %890 = atomicrmw add ptr %184, i64 1 seq_cst, align 8
  %891 = atomicrmw add ptr %186, i64 1 seq_cst, align 8
  %892 = bitcast double %866 to i64
  %893 = and i64 %892, 9223372036854775807
  %894 = and i64 %892, 9218868437227405312
  %895 = icmp eq i64 %893, 0
  %896 = icmp ne i64 %894, 0
  %897 = icmp ne i64 %894, 9218868437227405312
  %898 = and i1 %896, %897
  %899 = or i1 %895, %898
  br i1 %899, label %after_if34.1, label %true_block32.1

true_block32.1:                                   ; preds = %after_if46
  %900 = load ptr, ptr %105, align 8
  %901 = atomicrmw add ptr %900, i64 1 seq_cst, align 8
  br label %after_if34.1

after_if34.1:                                     ; preds = %true_block32.1, %after_if46
  %902 = bitcast double %869 to i64
  %903 = and i64 %902, 9223372036854775807
  %904 = and i64 %902, 9218868437227405312
  %905 = icmp eq i64 %903, 0
  %906 = icmp ne i64 %904, 0
  %907 = icmp ne i64 %904, 9218868437227405312
  %908 = and i1 %906, %907
  %909 = or i1 %905, %908
  br i1 %909, label %after_if37.1, label %true_block35.1

true_block35.1:                                   ; preds = %after_if34.1
  %910 = load ptr, ptr %105, align 8
  %911 = atomicrmw add ptr %910, i64 1 seq_cst, align 8
  br label %after_if37.1

after_if37.1:                                     ; preds = %true_block35.1, %after_if34.1
  %912 = bitcast double %873 to i64
  %913 = and i64 %912, 9223372036854775807
  %914 = and i64 %912, 9218868437227405312
  %915 = icmp eq i64 %913, 0
  %916 = icmp ne i64 %914, 0
  %917 = icmp ne i64 %914, 9218868437227405312
  %918 = and i1 %916, %917
  %919 = or i1 %915, %918
  br i1 %919, label %after_if40.1, label %true_block38.1

true_block38.1:                                   ; preds = %after_if37.1
  %920 = load ptr, ptr %105, align 8
  %921 = atomicrmw add ptr %920, i64 1 seq_cst, align 8
  br label %after_if40.1

after_if40.1:                                     ; preds = %true_block38.1, %after_if37.1
  %922 = bitcast double %889 to i64
  %923 = and i64 %922, 9223372036854775807
  %924 = and i64 %922, 9218868437227405312
  %925 = icmp eq i64 %923, 0
  %926 = icmp ne i64 %924, 0
  %927 = icmp ne i64 %924, 9218868437227405312
  %928 = and i1 %926, %927
  %929 = or i1 %925, %928
  br i1 %929, label %after_if43.1, label %true_block41.1

true_block41.1:                                   ; preds = %after_if40.1
  %930 = load ptr, ptr %105, align 8
  %931 = atomicrmw add ptr %930, i64 1 seq_cst, align 8
  br label %after_if43.1

after_if43.1:                                     ; preds = %true_block41.1, %after_if40.1
  %932 = fcmp ugt double %889, 0.000000e+00
  br i1 %932, label %after_if46.1, label %true_block44.1

true_block44.1:                                   ; preds = %after_if43.1
  %933 = load ptr, ptr %105, align 8
  %934 = atomicrmw add ptr %933, i64 1 seq_cst, align 8
  br label %after_if46.1

after_if46.1:                                     ; preds = %true_block44.1, %after_if43.1
  %935 = fsub double %866, %spec.select122
  %936 = fmul double %935, %889
  %937 = fadd double %848, %936
  %938 = fsub double %869, %.4103
  %939 = fmul double %938, %889
  %940 = fadd double %851, %939
  %941 = fsub double %873, %.4
  %942 = fmul double %941, %889
  %943 = fadd double %854, %942
  %944 = fadd double %855, %889
  %945 = add i32 %lsr.iv513, 2
  %946 = load ptr, ptr %188, align 8
  %947 = sext i32 %945 to i64
  %948 = getelementptr i32, ptr %946, i64 %947
  %949 = load i32, ptr %948, align 4
  %950 = load ptr, ptr %189, align 8
  %951 = load i32, ptr %190, align 4
  %952 = sext i32 %951 to i64
  %953 = sext i32 %949 to i64
  %954 = getelementptr double, ptr %950, i64 %953
  %955 = load double, ptr %954, align 8
  %956 = add nsw i64 %952, %953
  %957 = getelementptr double, ptr %950, i64 %956
  %958 = load double, ptr %957, align 8
  %959 = shl nsw i64 %952, 1
  %960 = add nsw i64 %959, %953
  %961 = getelementptr double, ptr %950, i64 %960
  %962 = load double, ptr %961, align 8
  %963 = mul nsw i64 %952, 6
  %964 = add nsw i64 %963, %953
  %965 = getelementptr double, ptr %950, i64 %964
  %966 = load double, ptr %965, align 8
  %967 = load ptr, ptr %191, align 8
  %968 = load i32, ptr %192, align 4
  %969 = sext i32 %968 to i64
  %970 = getelementptr i64, ptr %967, i64 %947
  %971 = load i64, ptr %970, align 8
  %972 = uitofp i64 %971 to double
  %973 = add nsw i64 %969, %947
  %974 = getelementptr i64, ptr %967, i64 %973
  %975 = load i64, ptr %974, align 8
  %976 = uitofp i64 %975 to double
  %977 = fdiv double %972, %976
  %978 = fmul double %966, %977
  %979 = atomicrmw add ptr %184, i64 1 seq_cst, align 8
  %980 = atomicrmw add ptr %186, i64 1 seq_cst, align 8
  %981 = bitcast double %955 to i64
  %982 = and i64 %981, 9223372036854775807
  %983 = and i64 %981, 9218868437227405312
  %984 = icmp eq i64 %982, 0
  %985 = icmp ne i64 %983, 0
  %986 = icmp ne i64 %983, 9218868437227405312
  %987 = and i1 %985, %986
  %988 = or i1 %984, %987
  br i1 %988, label %after_if34.2, label %true_block32.2

true_block32.2:                                   ; preds = %after_if46.1
  %989 = load ptr, ptr %105, align 8
  %990 = atomicrmw add ptr %989, i64 1 seq_cst, align 8
  br label %after_if34.2

after_if34.2:                                     ; preds = %true_block32.2, %after_if46.1
  %991 = bitcast double %958 to i64
  %992 = and i64 %991, 9223372036854775807
  %993 = and i64 %991, 9218868437227405312
  %994 = icmp eq i64 %992, 0
  %995 = icmp ne i64 %993, 0
  %996 = icmp ne i64 %993, 9218868437227405312
  %997 = and i1 %995, %996
  %998 = or i1 %994, %997
  br i1 %998, label %after_if37.2, label %true_block35.2

true_block35.2:                                   ; preds = %after_if34.2
  %999 = load ptr, ptr %105, align 8
  %1000 = atomicrmw add ptr %999, i64 1 seq_cst, align 8
  br label %after_if37.2

after_if37.2:                                     ; preds = %true_block35.2, %after_if34.2
  %1001 = bitcast double %962 to i64
  %1002 = and i64 %1001, 9223372036854775807
  %1003 = and i64 %1001, 9218868437227405312
  %1004 = icmp eq i64 %1002, 0
  %1005 = icmp ne i64 %1003, 0
  %1006 = icmp ne i64 %1003, 9218868437227405312
  %1007 = and i1 %1005, %1006
  %1008 = or i1 %1004, %1007
  br i1 %1008, label %after_if40.2, label %true_block38.2

true_block38.2:                                   ; preds = %after_if37.2
  %1009 = load ptr, ptr %105, align 8
  %1010 = atomicrmw add ptr %1009, i64 1 seq_cst, align 8
  br label %after_if40.2

after_if40.2:                                     ; preds = %true_block38.2, %after_if37.2
  %1011 = bitcast double %978 to i64
  %1012 = and i64 %1011, 9223372036854775807
  %1013 = and i64 %1011, 9218868437227405312
  %1014 = icmp eq i64 %1012, 0
  %1015 = icmp ne i64 %1013, 0
  %1016 = icmp ne i64 %1013, 9218868437227405312
  %1017 = and i1 %1015, %1016
  %1018 = or i1 %1014, %1017
  br i1 %1018, label %after_if43.2, label %true_block41.2

true_block41.2:                                   ; preds = %after_if40.2
  %1019 = load ptr, ptr %105, align 8
  %1020 = atomicrmw add ptr %1019, i64 1 seq_cst, align 8
  br label %after_if43.2

after_if43.2:                                     ; preds = %true_block41.2, %after_if40.2
  %1021 = fcmp ugt double %978, 0.000000e+00
  br i1 %1021, label %after_if46.2, label %true_block44.2

true_block44.2:                                   ; preds = %after_if43.2
  %1022 = load ptr, ptr %105, align 8
  %1023 = atomicrmw add ptr %1022, i64 1 seq_cst, align 8
  br label %after_if46.2

after_if46.2:                                     ; preds = %true_block44.2, %after_if43.2
  %1024 = fsub double %955, %spec.select122
  %1025 = fmul double %1024, %978
  %1026 = fadd double %937, %1025
  %1027 = fsub double %958, %.4103
  %1028 = fmul double %1027, %978
  %1029 = fadd double %940, %1028
  %1030 = fsub double %962, %.4
  %1031 = fmul double %1030, %978
  %1032 = fadd double %943, %1031
  %1033 = fadd double %944, %978
  %1034 = add i32 %lsr.iv513, 3
  %1035 = load ptr, ptr %188, align 8
  %1036 = sext i32 %1034 to i64
  %1037 = getelementptr i32, ptr %1035, i64 %1036
  %1038 = load i32, ptr %1037, align 4
  %1039 = load ptr, ptr %189, align 8
  %1040 = load i32, ptr %190, align 4
  %1041 = sext i32 %1040 to i64
  %1042 = sext i32 %1038 to i64
  %1043 = getelementptr double, ptr %1039, i64 %1042
  %1044 = load double, ptr %1043, align 8
  %1045 = add nsw i64 %1041, %1042
  %1046 = getelementptr double, ptr %1039, i64 %1045
  %1047 = load double, ptr %1046, align 8
  %1048 = shl nsw i64 %1041, 1
  %1049 = add nsw i64 %1048, %1042
  %1050 = getelementptr double, ptr %1039, i64 %1049
  %1051 = load double, ptr %1050, align 8
  %1052 = mul nsw i64 %1041, 6
  %1053 = add nsw i64 %1052, %1042
  %1054 = getelementptr double, ptr %1039, i64 %1053
  %1055 = load double, ptr %1054, align 8
  %1056 = load ptr, ptr %191, align 8
  %1057 = load i32, ptr %192, align 4
  %1058 = sext i32 %1057 to i64
  %1059 = getelementptr i64, ptr %1056, i64 %1036
  %1060 = load i64, ptr %1059, align 8
  %1061 = uitofp i64 %1060 to double
  %1062 = add nsw i64 %1058, %1036
  %1063 = getelementptr i64, ptr %1056, i64 %1062
  %1064 = load i64, ptr %1063, align 8
  %1065 = uitofp i64 %1064 to double
  %1066 = fdiv double %1061, %1065
  %1067 = fmul double %1055, %1066
  %1068 = atomicrmw add ptr %184, i64 1 seq_cst, align 8
  %1069 = atomicrmw add ptr %186, i64 1 seq_cst, align 8
  %1070 = bitcast double %1044 to i64
  %1071 = and i64 %1070, 9223372036854775807
  %1072 = and i64 %1070, 9218868437227405312
  %1073 = icmp eq i64 %1071, 0
  %1074 = icmp ne i64 %1072, 0
  %1075 = icmp ne i64 %1072, 9218868437227405312
  %1076 = and i1 %1074, %1075
  %1077 = or i1 %1073, %1076
  br i1 %1077, label %after_if34.3, label %true_block32.3

true_block32.3:                                   ; preds = %after_if46.2
  %1078 = load ptr, ptr %105, align 8
  %1079 = atomicrmw add ptr %1078, i64 1 seq_cst, align 8
  br label %after_if34.3

after_if34.3:                                     ; preds = %true_block32.3, %after_if46.2
  %1080 = bitcast double %1047 to i64
  %1081 = and i64 %1080, 9223372036854775807
  %1082 = and i64 %1080, 9218868437227405312
  %1083 = icmp eq i64 %1081, 0
  %1084 = icmp ne i64 %1082, 0
  %1085 = icmp ne i64 %1082, 9218868437227405312
  %1086 = and i1 %1084, %1085
  %1087 = or i1 %1083, %1086
  br i1 %1087, label %after_if37.3, label %true_block35.3

true_block35.3:                                   ; preds = %after_if34.3
  %1088 = load ptr, ptr %105, align 8
  %1089 = atomicrmw add ptr %1088, i64 1 seq_cst, align 8
  br label %after_if37.3

after_if37.3:                                     ; preds = %true_block35.3, %after_if34.3
  %1090 = bitcast double %1051 to i64
  %1091 = and i64 %1090, 9223372036854775807
  %1092 = and i64 %1090, 9218868437227405312
  %1093 = icmp eq i64 %1091, 0
  %1094 = icmp ne i64 %1092, 0
  %1095 = icmp ne i64 %1092, 9218868437227405312
  %1096 = and i1 %1094, %1095
  %1097 = or i1 %1093, %1096
  br i1 %1097, label %after_if40.3, label %true_block38.3

true_block38.3:                                   ; preds = %after_if37.3
  %1098 = load ptr, ptr %105, align 8
  %1099 = atomicrmw add ptr %1098, i64 1 seq_cst, align 8
  br label %after_if40.3

after_if40.3:                                     ; preds = %true_block38.3, %after_if37.3
  %1100 = bitcast double %1067 to i64
  %1101 = and i64 %1100, 9223372036854775807
  %1102 = and i64 %1100, 9218868437227405312
  %1103 = icmp eq i64 %1101, 0
  %1104 = icmp ne i64 %1102, 0
  %1105 = icmp ne i64 %1102, 9218868437227405312
  %1106 = and i1 %1104, %1105
  %1107 = or i1 %1103, %1106
  br i1 %1107, label %after_if43.3, label %true_block41.3

true_block41.3:                                   ; preds = %after_if40.3
  %1108 = load ptr, ptr %105, align 8
  %1109 = atomicrmw add ptr %1108, i64 1 seq_cst, align 8
  br label %after_if43.3

after_if43.3:                                     ; preds = %true_block41.3, %after_if40.3
  %1110 = fcmp ugt double %1067, 0.000000e+00
  br i1 %1110, label %after_if46.3, label %true_block44.3

true_block44.3:                                   ; preds = %after_if43.3
  %1111 = load ptr, ptr %105, align 8
  %1112 = atomicrmw add ptr %1111, i64 1 seq_cst, align 8
  br label %after_if46.3

after_if46.3:                                     ; preds = %true_block44.3, %after_if43.3
  %1113 = fsub double %1044, %spec.select122
  %1114 = fmul double %1113, %1067
  %1115 = fadd double %1026, %1114
  %1116 = fsub double %1047, %.4103
  %1117 = fmul double %1116, %1067
  %1118 = fadd double %1029, %1117
  %1119 = fsub double %1051, %.4
  %1120 = fmul double %1119, %1067
  %1121 = fadd double %1032, %1120
  %1122 = fadd double %1033, %1067
  %indvars.iv.next354.3 = add nuw i64 %indvars.iv353, 4
  %lsr.iv.next514 = add i32 %lsr.iv513, 4
  %niter464.ncmp.3 = icmp eq i64 %unroll_iter463, %indvars.iv.next354.3
  br i1 %niter464.ncmp.3, label %after_if3.loopexit.unr-lcssa.loopexit, label %for_loop_body28

true_block56:                                     ; preds = %after_if3
  %1123 = load ptr, ptr %105, align 8
  %1124 = atomicrmw add ptr %1123, i64 1 seq_cst, align 8
  br label %after_if58

after_if58:                                       ; preds = %true_block56, %after_if3
  %1125 = and i64 %394, 9223372036854775807
  %1126 = and i64 %394, 9218868437227405312
  %1127 = icmp eq i64 %1125, 0
  %1128 = icmp ne i64 %1126, 0
  %1129 = icmp ne i64 %1126, 9218868437227405312
  %1130 = and i1 %1128, %1129
  %1131 = or i1 %1127, %1130
  br i1 %1131, label %after_if61, label %true_block59

true_block59:                                     ; preds = %after_if58
  %1132 = load ptr, ptr %105, align 8
  %1133 = atomicrmw add ptr %1132, i64 1 seq_cst, align 8
  br label %after_if61

after_if61:                                       ; preds = %true_block59, %after_if58
  %1134 = fcmp one double %136, %395
  %1135 = or i1 %385, %1134
  %1136 = fdiv double %.096, %.0112
  %1137 = fadd double %.099, %1136
  %1138 = bitcast double %1137 to i64
  %1139 = and i64 %393, %1138
  %1140 = bitcast i64 %1139 to double
  %1141 = and i64 %1138, 9223372036854775807
  %1142 = and i64 %1138, 9218868437227405312
  %1143 = icmp eq i64 %1141, 0
  %1144 = icmp ne i64 %1142, 0
  %1145 = icmp ne i64 %1142, 9218868437227405312
  %1146 = and i1 %1144, %1145
  %1147 = or i1 %1143, %1146
  br i1 %1147, label %after_if64, label %true_block62

true_block62:                                     ; preds = %after_if61
  %1148 = load ptr, ptr %105, align 8
  %1149 = atomicrmw add ptr %1148, i64 1 seq_cst, align 8
  br label %after_if64

after_if64:                                       ; preds = %true_block62, %after_if61
  %1150 = and i64 %1139, 9223372036854775807
  %1151 = and i64 %1139, 9218868437227405312
  %1152 = icmp eq i64 %1150, 0
  %1153 = icmp ne i64 %1151, 0
  %1154 = icmp ne i64 %1151, 9218868437227405312
  %1155 = and i1 %1153, %1154
  %1156 = or i1 %1152, %1155
  br i1 %1156, label %after_if67, label %true_block65

true_block65:                                     ; preds = %after_if64
  %1157 = load ptr, ptr %105, align 8
  %1158 = atomicrmw add ptr %1157, i64 1 seq_cst, align 8
  br label %after_if67

after_if67:                                       ; preds = %true_block65, %after_if64
  %1159 = fcmp one double %142, %1140
  %1160 = or i1 %1159, %1135
  %1161 = fdiv double %.090, %.0112
  %1162 = fadd double %.093, %1161
  %1163 = bitcast double %1162 to i64
  %1164 = and i64 %393, %1163
  %1165 = bitcast i64 %1164 to double
  %1166 = and i64 %1163, 9223372036854775807
  %1167 = and i64 %1163, 9218868437227405312
  %1168 = icmp eq i64 %1166, 0
  %1169 = icmp ne i64 %1167, 0
  %1170 = icmp ne i64 %1167, 9218868437227405312
  %1171 = and i1 %1169, %1170
  %1172 = or i1 %1168, %1171
  br i1 %1172, label %after_if70, label %true_block68

true_block68:                                     ; preds = %after_if67
  %1173 = load ptr, ptr %105, align 8
  %1174 = atomicrmw add ptr %1173, i64 1 seq_cst, align 8
  br label %after_if70

after_if70:                                       ; preds = %true_block68, %after_if67
  %1175 = and i64 %1164, 9223372036854775807
  %1176 = and i64 %1164, 9218868437227405312
  %1177 = icmp eq i64 %1175, 0
  %1178 = icmp ne i64 %1176, 0
  %1179 = icmp ne i64 %1176, 9218868437227405312
  %1180 = and i1 %1178, %1179
  %1181 = or i1 %1177, %1180
  br i1 %1181, label %after_if73, label %true_block71

true_block71:                                     ; preds = %after_if70
  %1182 = load ptr, ptr %105, align 8
  %1183 = atomicrmw add ptr %1182, i64 1 seq_cst, align 8
  br label %after_if73

after_if73:                                       ; preds = %true_block71, %after_if70
  %1184 = fcmp one double %148, %1165
  %1185 = or i1 %1184, %1160
  %1186 = bitcast double %.0112 to i64
  %1187 = and i64 %1186, 9223372036854775807
  %1188 = and i64 %1186, 9218868437227405312
  %1189 = icmp eq i64 %1187, 0
  %1190 = icmp ne i64 %1188, 0
  %1191 = icmp ne i64 %1188, 9218868437227405312
  %1192 = and i1 %1190, %1191
  %1193 = or i1 %1189, %1192
  br i1 %1193, label %after_if76, label %true_block74

true_block74:                                     ; preds = %after_if73
  %1194 = load ptr, ptr %105, align 8
  %1195 = atomicrmw add ptr %1194, i64 1 seq_cst, align 8
  br label %after_if76

after_if76:                                       ; preds = %true_block74, %after_if73
  br i1 %1185, label %true_block77, label %loop_body_tail

true_block77:                                     ; preds = %after_if76
  store i32 1, ptr %69, align 4
  %1196 = load ptr, ptr %0, align 8
  %1197 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1196, i64 0, i32 13, i32 1
  %1198 = load ptr, ptr %1197, align 8
  %1199 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1196, i64 0, i32 13, i32 0, i32 1
  %1200 = getelementptr double, ptr %1198, i64 %101
  store double %136, ptr %1200, align 8
  %1201 = xor i32 %125, 4
  %1202 = load ptr, ptr %127, align 8
  %1203 = load i32, ptr %129, align 4
  %1204 = sext i32 %1201 to i64
  %1205 = sext i32 %1203 to i64
  %1206 = mul nsw i64 %1205, %1204
  %1207 = add i64 %1206, %101
  %1208 = getelementptr double, ptr %1202, i64 %1207
  store i64 %394, ptr %1208, align 8
  %1209 = load ptr, ptr %71, align 8
  %1210 = getelementptr double, ptr %1209, i64 %28
  store i64 %394, ptr %1210, align 8
  %1211 = load ptr, ptr %0, align 8
  %1212 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1211, i64 0, i32 16, i32 1
  %1213 = load ptr, ptr %1212, align 8
  %1214 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1211, i64 0, i32 16, i32 0, i32 1
  %1215 = load i32, ptr %1214, align 4
  %1216 = sext i32 %1215 to i64
  %1217 = mul nsw i64 %1216, 3
  %1218 = add nsw i64 %1217, %28
  %1219 = getelementptr double, ptr %1213, i64 %1218
  store double %136, ptr %1219, align 8
  %1220 = load ptr, ptr %1197, align 8
  %1221 = load i32, ptr %1199, align 4
  %1222 = sext i32 %1221 to i64
  %1223 = add nsw i64 %1222, %101
  %1224 = getelementptr double, ptr %1220, i64 %1223
  store double %142, ptr %1224, align 8
  %1225 = or i32 %1201, 1
  %1226 = load ptr, ptr %127, align 8
  %1227 = load i32, ptr %129, align 4
  %1228 = sext i32 %1225 to i64
  %1229 = sext i32 %1227 to i64
  %1230 = mul nsw i64 %1229, %1228
  %1231 = add i64 %1230, %101
  %1232 = getelementptr double, ptr %1226, i64 %1231
  store i64 %1139, ptr %1232, align 8
  %1233 = load ptr, ptr %71, align 8
  %1234 = load i32, ptr %73, align 4
  %1235 = sext i32 %1234 to i64
  %1236 = add nsw i64 %1235, %28
  %1237 = getelementptr double, ptr %1233, i64 %1236
  store i64 %1139, ptr %1237, align 8
  %1238 = load ptr, ptr %1212, align 8
  %1239 = load i32, ptr %1214, align 4
  %1240 = sext i32 %1239 to i64
  %1241 = shl nsw i64 %1240, 2
  %1242 = add nsw i64 %1241, %28
  %1243 = getelementptr double, ptr %1238, i64 %1242
  store double %142, ptr %1243, align 8
  %1244 = load ptr, ptr %1197, align 8
  %1245 = load i32, ptr %1199, align 4
  %1246 = sext i32 %1245 to i64
  %1247 = shl nsw i64 %1246, 1
  %1248 = add nsw i64 %1247, %101
  %1249 = getelementptr double, ptr %1244, i64 %1248
  store double %148, ptr %1249, align 8
  %1250 = or i32 %1201, 2
  %1251 = load ptr, ptr %127, align 8
  %1252 = load i32, ptr %129, align 4
  %1253 = sext i32 %1250 to i64
  %1254 = sext i32 %1252 to i64
  %1255 = mul nsw i64 %1254, %1253
  %1256 = add i64 %1255, %101
  %1257 = getelementptr double, ptr %1251, i64 %1256
  store i64 %1164, ptr %1257, align 8
  %1258 = load ptr, ptr %71, align 8
  %1259 = load i32, ptr %73, align 4
  %1260 = sext i32 %1259 to i64
  %1261 = shl nsw i64 %1260, 1
  %1262 = add nsw i64 %1261, %28
  %1263 = getelementptr double, ptr %1258, i64 %1262
  store i64 %1164, ptr %1263, align 8
  %1264 = load ptr, ptr %1212, align 8
  %1265 = load i32, ptr %1214, align 4
  %1266 = sext i32 %1265 to i64
  %1267 = mul nsw i64 %1266, 5
  %1268 = add nsw i64 %1267, %28
  %1269 = getelementptr double, ptr %1264, i64 %1268
  store double %148, ptr %1269, align 8
  %1270 = load ptr, ptr %1197, align 8
  %1271 = load i32, ptr %1199, align 4
  %1272 = sext i32 %1271 to i64
  %1273 = mul nsw i64 %1272, 3
  %1274 = add nsw i64 %1273, %101
  %1275 = getelementptr double, ptr %1270, i64 %1274
  store double %154, ptr %1275, align 8
  %1276 = or i32 %1201, 3
  %1277 = load ptr, ptr %127, align 8
  %1278 = load i32, ptr %129, align 4
  %1279 = sext i32 %1276 to i64
  %1280 = sext i32 %1278 to i64
  %1281 = mul nsw i64 %1280, %1279
  %1282 = add i64 %1281, %101
  %1283 = getelementptr double, ptr %1277, i64 %1282
  store double %.0112, ptr %1283, align 8
  %1284 = load ptr, ptr %71, align 8
  %1285 = load i32, ptr %73, align 4
  %1286 = sext i32 %1285 to i64
  %1287 = mul nsw i64 %1286, 3
  %1288 = add nsw i64 %1287, %28
  %1289 = getelementptr double, ptr %1284, i64 %1288
  store double %.0112, ptr %1289, align 8
  %1290 = atomicrmw xor ptr %123, i32 1 seq_cst, align 4
  %1291 = load ptr, ptr %98, align 8
  %1292 = load i32, ptr %100, align 4
  %1293 = sext i32 %1292 to i64
  %1294 = add nsw i64 %1293, %101
  %1295 = getelementptr i64, ptr %1291, i64 %1294
  %1296 = atomicrmw add ptr %1295, i64 1 seq_cst, align 8
  %1297 = load ptr, ptr %105, align 8
  %1298 = getelementptr i64, ptr %1297, i64 2
  %1299 = atomicrmw add ptr %1298, i64 1 seq_cst, align 8
  %1300 = load ptr, ptr %155, align 8
  %1301 = getelementptr i32, ptr %1300, i64 %101
  %1302 = load i32, ptr %1301, align 4
  %1303 = icmp sgt i32 %1302, -1
  br i1 %1303, label %true_block80, label %after_if82

true_block80:                                     ; preds = %true_block77
  %1304 = load i32, ptr %157, align 4
  %1305 = sext i32 %1304 to i64
  %1306 = mul nsw i64 %1305, 5
  %1307 = zext i32 %1302 to i64
  %1308 = add nsw i64 %1306, %1307
  %1309 = getelementptr i32, ptr %1300, i64 %1308
  %1310 = load i32, ptr %1309, align 4
  %1311 = sdiv i32 %1310, 32
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %5)
  %1312 = shl nsw i32 %1311, 3
  %1313 = sext i32 %1312 to i64
  %1314 = getelementptr i8, ptr %getch.i, i64 %1313
  store volatile ptr %1314, ptr %5, align 8
  %1315 = getelementptr inbounds i8, ptr %1314, i64 32
  %1316 = load volatile ptr, ptr %1315, align 8
  %1317 = icmp eq ptr %1316, null
  br i1 %1317, label %1318, label %Pointer_activate.exit166

1318:                                             ; preds = %true_block80
  %.0..0..0..0..0..i128 = load volatile ptr, ptr %5, align 8
  %.0..0..0..0..0.2.i129 = load volatile ptr, ptr %5, align 8
  br label %1319

1319:                                             ; preds = %1319, %1318
  %1320 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i129, i32 1 seq_cst, align 4
  %1321 = icmp eq i32 %1320, 1
  br i1 %1321, label %1319, label %mutex_lock_i32.exit.i.i.i130, !llvm.loop !6

mutex_lock_i32.exit.i.i.i130:                     ; preds = %1319
  %1322 = load volatile ptr, ptr %1315, align 8
  %1323 = icmp eq ptr %1322, null
  br i1 %1323, label %1324, label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i165"

1324:                                             ; preds = %mutex_lock_i32.exit.i.i.i130
  %1325 = load ptr, ptr %9, align 8
  %1326 = getelementptr inbounds %struct.LLVMRuntime, ptr %1325, i64 0, i32 14
  %1327 = load ptr, ptr %1326, align 8
  %1328 = getelementptr inbounds ptr, ptr %1327, i64 20
  %1329 = load ptr, ptr %1328, align 8
  %1330 = getelementptr inbounds %struct.NodeManager, ptr %1329, i64 0, i32 4
  %1331 = atomicrmw volatile add ptr %1330, i32 1 seq_cst, align 4
  %1332 = getelementptr inbounds %struct.NodeManager, ptr %1329, i64 0, i32 5
  %1333 = load ptr, ptr %1332, align 8
  %1334 = getelementptr inbounds %struct.ListManager, ptr %1333, i64 0, i32 5
  %1335 = load i32, ptr %1334, align 8
  %.not.i.i.i.i.i131 = icmp slt i32 %1331, %1335
  br i1 %.not.i.i.i.i.i131, label %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i159, label %1336

1336:                                             ; preds = %1324
  %1337 = getelementptr inbounds %struct.NodeManager, ptr %1329, i64 0, i32 7
  %1338 = load ptr, ptr %1337, align 8
  %1339 = getelementptr inbounds %struct.ListManager, ptr %1338, i64 0, i32 5
  %1340 = atomicrmw volatile add ptr %1339, i32 1 seq_cst, align 4
  %1341 = getelementptr inbounds %struct.ListManager, ptr %1338, i64 0, i32 3
  %1342 = load i32, ptr %1341, align 8
  %1343 = ashr i32 %1340, %1342
  %1344 = icmp ugt i32 %1343, 131071
  br i1 %1344, label %1345, label %1348

1345:                                             ; preds = %1336
  %1346 = getelementptr inbounds %struct.ListManager, ptr %1338, i64 0, i32 6
  %1347 = load ptr, ptr %1346, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %1347, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i162

1348:                                             ; preds = %1336
  %1349 = zext i32 %1343 to i64
  %1350 = lshr i64 %1349, 9
  %1351 = getelementptr inbounds [256 x ptr], ptr %1338, i64 0, i64 %1350
  %1352 = load atomic i64, ptr %1351 acquire, align 8
  %.not.i.i.i4.i.i.i.i.i132 = icmp eq i64 %1352, 0
  br i1 %.not.i.i.i4.i.i.i.i.i132, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i135, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i134

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i134: ; preds = %1348
  %1353 = inttoptr i64 %1352 to ptr
  %1354 = and i64 %1349, 511
  %1355 = getelementptr inbounds ptr, ptr %1353, i64 %1354
  %1356 = load atomic i64, ptr %1355 acquire, align 8
  %.not.i.i5.i.i.i.i.i133 = icmp eq i64 %1356, 0
  br i1 %.not.i.i5.i.i.i.i.i133, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i135, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i162

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i135: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i134, %1348
  %1357 = getelementptr inbounds %struct.ListManager, ptr %1338, i64 0, i32 4
  br label %1358

1358:                                             ; preds = %1358, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i135
  %1359 = atomicrmw volatile xchg ptr %1357, i32 1 seq_cst, align 4
  %1360 = icmp eq i32 %1359, 1
  br i1 %1360, label %1358, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i137, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i137:       ; preds = %1358
  %1361 = load atomic i64, ptr %1351 acquire, align 8
  %1362 = inttoptr i64 %1361 to ptr
  %.not.i.i.i.i.i.i.i.i.i.i.i136 = icmp eq i64 %1361, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i136, label %1363, label %1398

1363:                                             ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i137
  %1364 = getelementptr inbounds %struct.ListManager, ptr %1338, i64 0, i32 6
  %1365 = load ptr, ptr %1364, align 8
  %1366 = getelementptr inbounds %struct.LLVMRuntime, ptr %1365, i64 0, i32 1
  %1367 = getelementptr inbounds %struct.LLVMRuntime, ptr %1365, i64 0, i32 28
  %1368 = atomicrmw volatile add ptr %1367, i64 4096 seq_cst, align 8
  %1369 = getelementptr inbounds %struct.LLVMRuntime, ptr %1365, i64 0, i32 1, i32 2
  %1370 = load i64, ptr %1369, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i.i.i138 = icmp eq i64 %1370, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i.i.i138, label %1391, label %1371

1371:                                             ; preds = %1363
  %1372 = getelementptr inbounds %struct.LLVMRuntime, ptr %1365, i64 0, i32 26
  br label %1373

1373:                                             ; preds = %1373, %1371
  %1374 = atomicrmw volatile xchg ptr %1372, i32 1 seq_cst, align 4
  %1375 = icmp eq i32 %1374, 1
  br i1 %1375, label %1373, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i141, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i141: ; preds = %1373
  %1376 = load ptr, ptr %1366, align 8
  %1377 = ptrtoint ptr %1376 to i64
  %1378 = getelementptr inbounds %struct.LLVMRuntime, ptr %1365, i64 0, i32 1, i32 1
  %1379 = load ptr, ptr %1378, align 8
  %1380 = ptrtoint ptr %1379 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i139 = sub i64 0, %1377
  %1381 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i139, 4095
  %1382 = or i64 %1381, 4096
  %1383 = add i64 %1382, %1377
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i140 = icmp ugt i64 %1383, %1380
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i140, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i143, label %1384

1384:                                             ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i141
  %1385 = add i64 %1381, %1377
  %1386 = inttoptr i64 %1385 to ptr
  %1387 = getelementptr i8, ptr %1376, i64 %1381
  %1388 = getelementptr inbounds i8, ptr %1387, i64 4096
  store ptr %1388, ptr %1366, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i143

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i143: ; preds = %1384, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i141
  %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i142 = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i141 ], [ %1386, %1384 ]
  %1389 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i140, true
  %1390 = atomicrmw volatile xchg ptr %1372, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %1365, i1 noundef zeroext %1389, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i145

1391:                                             ; preds = %1363
  %1392 = getelementptr inbounds %struct.LLVMRuntime, ptr %1365, i64 0, i32 2
  %1393 = load ptr, ptr %1392, align 8
  %1394 = getelementptr inbounds %struct.LLVMRuntime, ptr %1365, i64 0, i32 6
  %1395 = load ptr, ptr %1394, align 8
  %1396 = tail call noundef ptr %1393(ptr noundef %1395, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i145

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i145: ; preds = %1391, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i143
  %.0.i17.i.i.i.i.i.i.i.i.i.i.i144 = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i142, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i143 ], [ %1396, %1391 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i.i.i144, i8 0, i64 4096, i1 false)
  %1397 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i.i.i144 to i64
  store atomic i64 %1397, ptr %1351 release, align 8
  br label %1398

1398:                                             ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i145, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i137
  %.0.i.i.i.i.i.i.i.i.i.i.i146 = phi ptr [ %1362, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i137 ], [ %.0.i17.i.i.i.i.i.i.i.i.i.i.i144, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i145 ]
  %1399 = and i32 %1343, 511
  %1400 = zext i32 %1399 to i64
  %1401 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i.i.i146, i64 %1400
  %1402 = load atomic i64, ptr %1401 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i.i.i147 = icmp eq i64 %1402, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i.i.i147, label %1403, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i156"

1403:                                             ; preds = %1398
  %1404 = getelementptr inbounds %struct.ListManager, ptr %1338, i64 0, i32 6
  %1405 = load ptr, ptr %1404, align 8
  %1406 = getelementptr inbounds %struct.LLVMRuntime, ptr %1405, i64 0, i32 1
  %1407 = getelementptr inbounds %struct.ListManager, ptr %1338, i64 0, i32 2
  %1408 = load i64, ptr %1407, align 8
  %1409 = getelementptr inbounds %struct.ListManager, ptr %1338, i64 0, i32 1
  %1410 = load i64, ptr %1409, align 8
  %1411 = mul i64 %1410, %1408
  %1412 = getelementptr inbounds %struct.LLVMRuntime, ptr %1405, i64 0, i32 28
  %1413 = atomicrmw volatile add ptr %1412, i64 %1411 seq_cst, align 8
  %1414 = getelementptr inbounds %struct.LLVMRuntime, ptr %1405, i64 0, i32 1, i32 2
  %1415 = load i64, ptr %1414, align 8
  %.not.i.i.i.i.i.i.i.i.i.i.i.i148 = icmp eq i64 %1415, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i148, label %1435, label %1416

1416:                                             ; preds = %1403
  %1417 = getelementptr inbounds %struct.LLVMRuntime, ptr %1405, i64 0, i32 26
  br label %1418

1418:                                             ; preds = %1418, %1416
  %1419 = atomicrmw volatile xchg ptr %1417, i32 1 seq_cst, align 4
  %1420 = icmp eq i32 %1419, 1
  br i1 %1420, label %1418, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i151, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i151: ; preds = %1418
  %1421 = load ptr, ptr %1406, align 8
  %1422 = ptrtoint ptr %1421 to i64
  %1423 = getelementptr inbounds %struct.LLVMRuntime, ptr %1405, i64 0, i32 1, i32 1
  %1424 = load ptr, ptr %1423, align 8
  %1425 = ptrtoint ptr %1424 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i149 = sub i64 0, %1422
  %1426 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i149, 4095
  %1427 = add i64 %1426, %1411
  %1428 = add i64 %1427, %1422
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i150 = icmp ugt i64 %1428, %1425
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i150, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i153, label %1429

1429:                                             ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i151
  %1430 = add i64 %1426, %1422
  %1431 = inttoptr i64 %1430 to ptr
  %1432 = getelementptr inbounds i8, ptr %1421, i64 %1427
  store ptr %1432, ptr %1406, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i153

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i153: ; preds = %1429, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i151
  %.0.i.i.i.i.i.i.i.i.i.i.i.i.i152 = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i151 ], [ %1431, %1429 ]
  %1433 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i150, true
  %1434 = atomicrmw volatile xchg ptr %1417, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %1405, i1 noundef zeroext %1433, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i155

1435:                                             ; preds = %1403
  %1436 = getelementptr inbounds %struct.LLVMRuntime, ptr %1405, i64 0, i32 2
  %1437 = load ptr, ptr %1436, align 8
  %1438 = getelementptr inbounds %struct.LLVMRuntime, ptr %1405, i64 0, i32 6
  %1439 = load ptr, ptr %1438, align 8
  %1440 = tail call noundef ptr %1437(ptr noundef %1439, i64 noundef %1411, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i155

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i155: ; preds = %1435, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i153
  %.0.i.i.i.i.i.i.i.i.i.i.i.i154 = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i.i.i152, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i153 ], [ %1440, %1435 ]
  %1441 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i.i.i154 to i64
  store atomic i64 %1441, ptr %1401 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i156"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i156": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i155, %1398
  %1442 = atomicrmw volatile xchg ptr %1357, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i162

_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i159:   ; preds = %1324
  %1443 = getelementptr inbounds %struct.ListManager, ptr %1333, i64 0, i32 3
  %1444 = load i32, ptr %1443, align 8
  %1445 = ashr i32 %1331, %1444
  %1446 = sext i32 %1445 to i64
  %1447 = lshr i64 %1446, 9
  %1448 = getelementptr inbounds [256 x ptr], ptr %1333, i64 0, i64 %1447
  %1449 = load atomic i64, ptr %1448 acquire, align 8
  %.not.i.i.i.i.i.i.i.i157 = icmp ne i64 %1449, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i.i.i.i.i157)
  %1450 = inttoptr i64 %1449 to ptr
  %1451 = and i64 %1446, 511
  %1452 = getelementptr inbounds ptr, ptr %1450, i64 %1451
  %1453 = load atomic i64, ptr %1452 acquire, align 8
  %1454 = inttoptr i64 %1453 to ptr
  %1455 = getelementptr inbounds %struct.ListManager, ptr %1333, i64 0, i32 1
  %1456 = load i64, ptr %1455, align 8
  %1457 = load i32, ptr %1443, align 8
  %notmask.i.i.i.i.i.i.i158 = shl nsw i32 -1, %1457
  %1458 = xor i32 %notmask.i.i.i.i.i.i.i158, -1
  %1459 = and i32 %1331, %1458
  %1460 = sext i32 %1459 to i64
  %1461 = mul i64 %1456, %1460
  %1462 = getelementptr inbounds i8, ptr %1454, i64 %1461
  %1463 = load i32, ptr %1462, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i162

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i162: ; preds = %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i159, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i156", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i134, %1345
  %.0.i.i.i.i.i160 = phi i32 [ %1463, %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i159 ], [ %1340, %1345 ], [ %1340, %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i134 ], [ %1340, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i156" ]
  %1464 = getelementptr inbounds %struct.NodeManager, ptr %1329, i64 0, i32 7
  %1465 = load ptr, ptr %1464, align 8
  %1466 = getelementptr inbounds %struct.ListManager, ptr %1465, i64 0, i32 3
  %1467 = load i32, ptr %1466, align 8
  %1468 = ashr i32 %.0.i.i.i.i.i160, %1467
  %1469 = sext i32 %1468 to i64
  %1470 = lshr i64 %1469, 9
  %1471 = getelementptr inbounds [256 x ptr], ptr %1465, i64 0, i64 %1470
  %1472 = load atomic i64, ptr %1471 acquire, align 8
  %.not.i.i.i.i.i.i.i161 = icmp eq i64 %1472, 0
  br i1 %.not.i.i.i.i.i.i.i161, label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i164", label %1473

1473:                                             ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i162
  %1474 = inttoptr i64 %1472 to ptr
  %1475 = and i64 %1469, 511
  %1476 = getelementptr inbounds ptr, ptr %1474, i64 %1475
  %1477 = load atomic i64, ptr %1476 acquire, align 8
  %1478 = inttoptr i64 %1477 to ptr
  br label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i164"

"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i164": ; preds = %1473, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i162
  %1479 = phi ptr [ %1478, %1473 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i162 ]
  %1480 = getelementptr inbounds %struct.ListManager, ptr %1465, i64 0, i32 1
  %1481 = load i64, ptr %1480, align 8
  %1482 = load i32, ptr %1466, align 8
  %notmask.i.i.i.i.i.i163 = shl nsw i32 -1, %1482
  %1483 = xor i32 %notmask.i.i.i.i.i.i163, -1
  %1484 = and i32 %.0.i.i.i.i.i160, %1483
  %1485 = sext i32 %1484 to i64
  %1486 = mul i64 %1481, %1485
  %1487 = getelementptr inbounds i8, ptr %1479, i64 %1486
  %1488 = ptrtoint ptr %1487 to i64
  %1489 = atomicrmw volatile xchg ptr %1315, i64 %1488 seq_cst, align 8
  br label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i165"

"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i165": ; preds = %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i164", %mutex_lock_i32.exit.i.i.i130
  %1490 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i129, i32 0 seq_cst, align 4
  br label %Pointer_activate.exit166

Pointer_activate.exit166:                         ; preds = %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i165", %true_block80
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5)
  %1491 = lshr i32 %1310, 2
  %1492 = and i32 %1491, 1073741816
  %1493 = zext i32 %1492 to i64
  %1494 = getelementptr i8, ptr %getch.i, i64 %1493
  %1495 = getelementptr inbounds i8, ptr %1494, i64 32
  %1496 = load ptr, ptr %1495, align 8
  %1497 = icmp eq ptr %1496, null
  br i1 %1497, label %1498, label %Pointer_lookup_element.exit127

1498:                                             ; preds = %Pointer_activate.exit166
  %1499 = load ptr, ptr %9, align 8
  %1500 = getelementptr inbounds %struct.LLVMRuntime, ptr %1499, i64 0, i32 15
  %1501 = load ptr, ptr %1500, align 8
  %1502 = getelementptr inbounds ptr, ptr %1501, i64 20
  %1503 = load ptr, ptr %1502, align 8
  br label %Pointer_lookup_element.exit127

Pointer_lookup_element.exit127:                   ; preds = %1498, %Pointer_activate.exit166
  %.0.i126 = phi ptr [ %1503, %1498 ], [ %1496, %Pointer_activate.exit166 ]
  %1504 = and i32 %1310, 31
  %1505 = getelementptr inbounds i8, ptr %.0.i126, i64 32
  %1506 = shl nuw i32 1, %1504
  %1507 = atomicrmw volatile or ptr %1505, i32 %1506 seq_cst, align 4
  %.pre = load ptr, ptr %155, align 8
  br label %after_if82

after_if82:                                       ; preds = %Pointer_lookup_element.exit127, %true_block77
  %1508 = phi ptr [ %1300, %true_block77 ], [ %.pre, %Pointer_lookup_element.exit127 ]
  %1509 = load i32, ptr %157, align 4
  %1510 = sext i32 %1509 to i64
  %1511 = mul nsw i64 %1510, 6
  %1512 = add nsw i64 %1511, %101
  %1513 = getelementptr i32, ptr %1508, i64 %1512
  %1514 = load i32, ptr %1513, align 4
  %1515 = mul nsw i64 %1510, 7
  %1516 = add nsw i64 %1515, %101
  %1517 = getelementptr i32, ptr %1508, i64 %1516
  %1518 = load i32, ptr %1517, align 4
  %1519 = load ptr, ptr %105, align 8
  %1520 = getelementptr i64, ptr %1519, i64 6
  %1521 = load ptr, ptr %110, align 8
  %1522 = getelementptr i64, ptr %1521, i64 10
  %1523 = getelementptr i64, ptr %1521, i64 15
  %1524 = getelementptr i64, ptr %1519, i64 8
  %1525 = load ptr, ptr %9, align 8
  %1526 = getelementptr inbounds %struct.LLVMRuntime, ptr %1525, i64 0, i32 16
  %1527 = load ptr, ptr %1526, align 8
  %1528 = getelementptr inbounds i8, ptr %1527, i64 8
  %1529 = load double, ptr %1528, align 8
  %1530 = fcmp one double %1529, 0.000000e+00
  %1531 = getelementptr i64, ptr %1519, i64 9
  %1532 = icmp sgt i32 %1518, 0
  br i1 %1532, label %for_loop_body83.lr.ph, label %loop_body_tail

for_loop_body83.lr.ph:                            ; preds = %after_if82
  %1533 = load ptr, ptr %0, align 8
  %1534 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1533, i64 0, i32 9, i32 1
  %1535 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1533, i64 0, i32 12, i32 1
  %1536 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1533, i64 0, i32 12, i32 0, i32 1
  %1537 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1533, i64 0, i32 10, i32 1
  %1538 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1533, i64 0, i32 10, i32 0, i32 1
  %1539 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1533, i64 0, i32 7, i32 1
  %1540 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1533, i64 0, i32 7, i32 0, i32 1
  %1541 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1533, i64 0, i32 20, i32 1
  %1542 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1533, i64 0, i32 20, i32 0, i32 1
  %1543 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1533, i64 0, i32 21, i32 1
  %1544 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1533, i64 0, i32 19, i32 1
  %1545 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1533, i64 0, i32 19, i32 0, i32 1
  %1546 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1533, i64 0, i32 22, i32 1
  %1547 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1533, i64 0, i32 22, i32 0, i32 1
  %1548 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1533, i64 0, i32 23, i32 1
  %wide.trip.count376 = zext i32 %1518 to i64
  br label %for_loop_body83

for_loop_body83:                                  ; preds = %after_if180, %for_loop_body83.lr.ph
  %indvars.iv373 = phi i64 [ 0, %for_loop_body83.lr.ph ], [ %indvars.iv.next374, %after_if180 ]
  %1549 = trunc i64 %indvars.iv373 to i32
  %1550 = add i32 %1514, %1549
  %1551 = load ptr, ptr %1534, align 8
  %1552 = sext i32 %1550 to i64
  %1553 = getelementptr i32, ptr %1551, i64 %1552
  %1554 = load i32, ptr %1553, align 4
  %1555 = atomicrmw add ptr %1520, i64 1 seq_cst, align 8
  %1556 = atomicrmw add ptr %1522, i64 1 seq_cst, align 8
  %1557 = atomicrmw add ptr %1523, i64 1 seq_cst, align 8
  %1558 = load ptr, ptr %1535, align 8
  %1559 = load i32, ptr %1536, align 4
  %1560 = sext i32 %1559 to i64
  %1561 = sext i32 %1554 to i64
  %1562 = getelementptr i32, ptr %1558, i64 %1561
  %1563 = load i32, ptr %1562, align 4
  %1564 = add nsw i64 %1560, %1561
  %1565 = getelementptr i32, ptr %1558, i64 %1564
  %1566 = load i32, ptr %1565, align 4
  %1567 = icmp slt i32 %1563, %1566
  br i1 %1567, label %for_loop_body87.preheader, label %after_for89

for_loop_body87.preheader:                        ; preds = %for_loop_body83
  %1568 = sext i32 %1563 to i64
  %wide.trip.count361 = sext i32 %1566 to i64
  br label %for_loop_body87

for_loop_body87:                                  ; preds = %after_if123, %for_loop_body87.preheader
  %indvars.iv358 = phi i64 [ %1568, %for_loop_body87.preheader ], [ %indvars.iv.next359, %after_if123 ]
  %.077308 = phi double [ 0.000000e+00, %for_loop_body87.preheader ], [ %1942, %after_if123 ]
  %.078307 = phi double [ 0.000000e+00, %for_loop_body87.preheader ], [ %1941, %after_if123 ]
  %.079306 = phi double [ 0.000000e+00, %for_loop_body87.preheader ], [ %1940, %after_if123 ]
  %.082305 = phi double [ 0.000000e+00, %for_loop_body87.preheader ], [ %1939, %after_if123 ]
  %.083304 = phi double [ 0.000000e+00, %for_loop_body87.preheader ], [ %1938, %after_if123 ]
  %.086303 = phi double [ 0.000000e+00, %for_loop_body87.preheader ], [ %1937, %after_if123 ]
  %1569 = atomicrmw add ptr %1524, i64 1 seq_cst, align 8
  %1570 = load ptr, ptr %1537, align 8
  %1571 = load i32, ptr %1538, align 4
  %1572 = sext i32 %1571 to i64
  %1573 = add nsw i64 %indvars.iv358, %1572
  %1574 = getelementptr i32, ptr %1570, i64 %1573
  %1575 = load i32, ptr %1574, align 4
  %1576 = shl nsw i64 %1572, 3
  %uglygep = getelementptr i8, ptr %1570, i64 %1576
  %1577 = shl i64 %indvars.iv358, 2
  %uglygep516 = getelementptr i8, ptr %uglygep, i64 %1577
  %1578 = load i32, ptr %uglygep516, align 4
  %1579 = load ptr, ptr %121, align 8
  %1580 = sext i32 %1575 to i64
  %1581 = getelementptr i32, ptr %1579, i64 %1580
  %1582 = atomicrmw or ptr %1581, i32 0 seq_cst, align 4
  %1583 = shl i32 %1582, 2
  %1584 = load ptr, ptr %127, align 8
  %1585 = load i32, ptr %129, align 4
  %1586 = sext i32 %1583 to i64
  %1587 = sext i32 %1585 to i64
  %1588 = mul nsw i64 %1587, %1586
  %1589 = add nsw i64 %1588, %1580
  %1590 = getelementptr double, ptr %1584, i64 %1589
  %1591 = load double, ptr %1590, align 8
  %1592 = or i32 %1583, 1
  %1593 = sext i32 %1592 to i64
  %1594 = mul nsw i64 %1593, %1587
  %1595 = add nsw i64 %1594, %1580
  %1596 = getelementptr double, ptr %1584, i64 %1595
  %1597 = load double, ptr %1596, align 8
  %1598 = or i32 %1583, 2
  %1599 = sext i32 %1598 to i64
  %1600 = mul nsw i64 %1599, %1587
  %1601 = add nsw i64 %1600, %1580
  %1602 = getelementptr double, ptr %1584, i64 %1601
  %1603 = load double, ptr %1602, align 8
  %1604 = or i32 %1583, 3
  %1605 = sext i32 %1604 to i64
  %1606 = mul nsw i64 %1605, %1587
  %1607 = add nsw i64 %1606, %1580
  %1608 = getelementptr double, ptr %1584, i64 %1607
  %1609 = load double, ptr %1608, align 8
  %1610 = load ptr, ptr %121, align 8
  %1611 = sext i32 %1578 to i64
  %1612 = getelementptr i32, ptr %1610, i64 %1611
  %1613 = atomicrmw or ptr %1612, i32 0 seq_cst, align 4
  %1614 = shl i32 %1613, 2
  %1615 = load ptr, ptr %127, align 8
  %1616 = load i32, ptr %129, align 4
  %1617 = sext i32 %1614 to i64
  %1618 = sext i32 %1616 to i64
  %1619 = mul nsw i64 %1618, %1617
  %1620 = add nsw i64 %1619, %1611
  %1621 = getelementptr double, ptr %1615, i64 %1620
  %1622 = load double, ptr %1621, align 8
  %1623 = or i32 %1614, 1
  %1624 = sext i32 %1623 to i64
  %1625 = mul nsw i64 %1624, %1618
  %1626 = add nsw i64 %1625, %1611
  %1627 = getelementptr double, ptr %1615, i64 %1626
  %1628 = load double, ptr %1627, align 8
  %1629 = or i32 %1614, 2
  %1630 = sext i32 %1629 to i64
  %1631 = mul nsw i64 %1630, %1618
  %1632 = add nsw i64 %1631, %1611
  %1633 = getelementptr double, ptr %1615, i64 %1632
  %1634 = load double, ptr %1633, align 8
  %1635 = or i32 %1614, 3
  %1636 = sext i32 %1635 to i64
  %1637 = mul nsw i64 %1636, %1618
  %1638 = add nsw i64 %1637, %1611
  %1639 = getelementptr double, ptr %1615, i64 %1638
  %1640 = load double, ptr %1639, align 8
  %1641 = icmp eq i32 %1575, %30
  %1642 = select i1 %1641, double %154, double %1609
  %1643 = icmp eq i32 %1578, %30
  %1644 = select i1 %1643, double %154, double %1640
  %1645 = load ptr, ptr %1537, align 8
  %1646 = load i32, ptr %1538, align 4
  %1647 = sext i32 %1646 to i64
  %1648 = mul nsw i64 %1647, 12
  %uglygep517 = getelementptr i8, ptr %1645, i64 %1648
  %uglygep518 = getelementptr i8, ptr %uglygep517, i64 %1577
  %1649 = load i32, ptr %uglygep518, align 4
  %.not121 = icmp eq i32 %1649, 0
  %1650 = select i1 %.not121, i32 %1575, i32 %1578
  %1651 = load ptr, ptr %155, align 8
  %1652 = load i32, ptr %157, align 4
  %1653 = sext i32 %1652 to i64
  %1654 = shl nsw i64 %1653, 3
  %1655 = sext i32 %1650 to i64
  %1656 = add nsw i64 %1654, %1655
  %1657 = getelementptr i32, ptr %1651, i64 %1656
  %1658 = load i32, ptr %1657, align 4
  %1659 = mul nsw i64 %1653, 9
  %1660 = add nsw i64 %1659, %1580
  %1661 = getelementptr i32, ptr %1651, i64 %1660
  %1662 = load i32, ptr %1661, align 4
  %1663 = icmp ne i32 %1662, 0
  %1664 = or i1 %.not121, %1663
  %1665 = icmp ne i32 %1658, 0
  %1666 = and i1 %1665, %1664
  %1667 = and i1 %1530, %1666
  br i1 %1667, label %true_block91, label %after_if123

after_for89.loopexit:                             ; preds = %after_if123
  br label %after_for89

after_for89:                                      ; preds = %after_for89.loopexit, %for_loop_body83
  %.086.lcssa = phi double [ 0.000000e+00, %for_loop_body83 ], [ %1937, %after_for89.loopexit ]
  %.083.lcssa = phi double [ 0.000000e+00, %for_loop_body83 ], [ %1938, %after_for89.loopexit ]
  %.082.lcssa = phi double [ 0.000000e+00, %for_loop_body83 ], [ %1939, %after_for89.loopexit ]
  %.079.lcssa = phi double [ 0.000000e+00, %for_loop_body83 ], [ %1940, %after_for89.loopexit ]
  %.078.lcssa = phi double [ 0.000000e+00, %for_loop_body83 ], [ %1941, %after_for89.loopexit ]
  %.077.lcssa = phi double [ 0.000000e+00, %for_loop_body83 ], [ %1942, %after_for89.loopexit ]
  %1668 = fcmp one double %.086.lcssa, %.083.lcssa
  %1669 = or i1 %385, %1668
  %1670 = fcmp one double %.082.lcssa, %.079.lcssa
  %1671 = or i1 %1669, %1670
  %1672 = fcmp one double %.078.lcssa, %.077.lcssa
  %1673 = or i1 %1671, %1672
  %1674 = load ptr, ptr %1541, align 8
  %1675 = load i32, ptr %1542, align 4
  %1676 = sext i32 %1675 to i64
  %1677 = getelementptr i32, ptr %1674, i64 %1561
  %1678 = load i32, ptr %1677, align 4
  %1679 = add nsw i64 %1676, %1561
  %1680 = getelementptr i32, ptr %1674, i64 %1679
  %1681 = load i32, ptr %1680, align 4
  %1682 = icmp slt i32 %1678, %1681
  br i1 %1682, label %for_loop_body152.preheader, label %after_for154

for_loop_body152.preheader:                       ; preds = %after_for89
  %1683 = sext i32 %1678 to i64
  %wide.trip.count366 = sext i32 %1681 to i64
  %1684 = sub nsw i64 %wide.trip.count366, %1683
  %1685 = xor i64 %1683, -1
  %1686 = add nsw i64 %1685, %wide.trip.count366
  %xtraiter465 = and i64 %1684, 3
  %lcmp.mod466.not = icmp eq i64 %xtraiter465, 0
  br i1 %lcmp.mod466.not, label %for_loop_body152.prol.loopexit, label %for_loop_body152.prol.preheader

for_loop_body152.prol.preheader:                  ; preds = %for_loop_body152.preheader
  br label %for_loop_body152.prol

for_loop_body152.prol:                            ; preds = %for_loop_body152.prol, %for_loop_body152.prol.preheader
  %lsr.iv522 = phi i64 [ %xtraiter465, %for_loop_body152.prol.preheader ], [ %lsr.iv.next523, %for_loop_body152.prol ]
  %indvars.iv363.prol = phi i64 [ %indvars.iv.next364.prol, %for_loop_body152.prol ], [ %1683, %for_loop_body152.prol.preheader ]
  %.1318.prol = phi double [ %1758, %for_loop_body152.prol ], [ %.077.lcssa, %for_loop_body152.prol.preheader ]
  %.180317.prol = phi double [ %1756, %for_loop_body152.prol ], [ %.079.lcssa, %for_loop_body152.prol.preheader ]
  %.184316.prol = phi double [ %1754, %for_loop_body152.prol ], [ %.083.lcssa, %for_loop_body152.prol.preheader ]
  %1687 = atomicrmw add ptr %1531, i64 1 seq_cst, align 8
  %1688 = load ptr, ptr %1543, align 8
  %1689 = shl nsw i64 %indvars.iv363.prol, 2
  %uglygep521 = getelementptr i8, ptr %1688, i64 %1689
  %1690 = load i32, ptr %uglygep521, align 4
  %1691 = load ptr, ptr %1544, align 8
  %1692 = load i32, ptr %1545, align 4
  %1693 = sext i32 %1692 to i64
  %1694 = sext i32 %1690 to i64
  %1695 = getelementptr i32, ptr %1691, i64 %1694
  %1696 = load i32, ptr %1695, align 4
  %1697 = add nsw i64 %1693, %1694
  %1698 = getelementptr i32, ptr %1691, i64 %1697
  %1699 = load i32, ptr %1698, align 4
  %1700 = load ptr, ptr %1539, align 8
  %1701 = load i32, ptr %1540, align 4
  %1702 = sext i32 %1701 to i64
  %1703 = sext i32 %1699 to i64
  %1704 = getelementptr double, ptr %1700, i64 %1703
  %1705 = load double, ptr %1704, align 8
  %1706 = sext i32 %1696 to i64
  %1707 = getelementptr double, ptr %1700, i64 %1706
  %1708 = load double, ptr %1707, align 8
  %1709 = fsub double %1705, %1708
  %1710 = add nsw i64 %1702, %1703
  %1711 = getelementptr double, ptr %1700, i64 %1710
  %1712 = load double, ptr %1711, align 8
  %1713 = add nsw i64 %1702, %1706
  %1714 = getelementptr double, ptr %1700, i64 %1713
  %1715 = load double, ptr %1714, align 8
  %1716 = fsub double %1712, %1715
  %1717 = shl nsw i64 %1702, 1
  %1718 = add nsw i64 %1717, %1703
  %1719 = getelementptr double, ptr %1700, i64 %1718
  %1720 = load double, ptr %1719, align 8
  %1721 = add nsw i64 %1717, %1706
  %1722 = getelementptr double, ptr %1700, i64 %1721
  %1723 = load double, ptr %1722, align 8
  %1724 = fsub double %1720, %1723
  %1725 = mul nsw i64 %1702, 7
  %1726 = add nsw i64 %1725, %1706
  %1727 = getelementptr double, ptr %1700, i64 %1726
  %1728 = load double, ptr %1727, align 8
  %1729 = add nsw i64 %1725, %1703
  %1730 = getelementptr double, ptr %1700, i64 %1729
  %1731 = load double, ptr %1730, align 8
  %1732 = fmul double %1709, %1709
  %1733 = fmul double %1716, %1716
  %1734 = fadd double %1732, %1733
  %1735 = fmul double %1724, %1724
  %1736 = fadd double %1734, %1735
  %1737 = fcmp ogt double %1736, 0.000000e+00
  %.0.i124.prol = select i1 %1737, double 1.000000e+00, double 0.000000e+00
  %1738 = fsub double 1.000000e+00, %.0.i124.prol
  %1739 = fadd double %1736, %1738
  %sqrt156.prol = tail call double @llvm.sqrt.f64(double %1739)
  %1740 = fdiv double 1.000000e+00, %sqrt156.prol
  %1741 = fmul double %1739, %1740
  %1742 = fadd double %1728, %1731
  %1743 = fsub double %1742, %1741
  %1744 = tail call double @llvm.maxnum.f64(double %1743, double 0.000000e+00)
  %1745 = load ptr, ptr %9, align 8
  %1746 = getelementptr inbounds %struct.LLVMRuntime, ptr %1745, i64 0, i32 16
  %1747 = load ptr, ptr %1746, align 8
  %1748 = getelementptr inbounds i8, ptr %1747, i64 16
  %1749 = load double, ptr %1748, align 8
  %1750 = fmul double %.0.i124.prol, %1740
  %1751 = fneg double %1749
  %1752 = fmul double %1744, %1751
  %neg.prol = fmul double %1750, %1752
  %1753 = fmul double %1709, %neg.prol
  %1754 = fadd double %.184316.prol, %1753
  %1755 = fmul double %1716, %neg.prol
  %1756 = fadd double %.180317.prol, %1755
  %1757 = fmul double %1724, %neg.prol
  %1758 = fadd double %.1318.prol, %1757
  %indvars.iv.next364.prol = add nsw i64 %indvars.iv363.prol, 1
  %lsr.iv.next523 = add nsw i64 %lsr.iv522, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next523, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body152.prol.loopexit.loopexit, label %for_loop_body152.prol, !llvm.loop !14

for_loop_body152.prol.loopexit.loopexit:          ; preds = %for_loop_body152.prol
  %1759 = add i64 %1683, %xtraiter465
  br label %for_loop_body152.prol.loopexit

for_loop_body152.prol.loopexit:                   ; preds = %for_loop_body152.prol.loopexit.loopexit, %for_loop_body152.preheader
  %.lcssa442.unr = phi double [ undef, %for_loop_body152.preheader ], [ %1754, %for_loop_body152.prol.loopexit.loopexit ]
  %.lcssa441.unr = phi double [ undef, %for_loop_body152.preheader ], [ %1756, %for_loop_body152.prol.loopexit.loopexit ]
  %.lcssa440.unr = phi double [ undef, %for_loop_body152.preheader ], [ %1758, %for_loop_body152.prol.loopexit.loopexit ]
  %indvars.iv363.unr = phi i64 [ %1683, %for_loop_body152.preheader ], [ %1759, %for_loop_body152.prol.loopexit.loopexit ]
  %.1318.unr = phi double [ %.077.lcssa, %for_loop_body152.preheader ], [ %1758, %for_loop_body152.prol.loopexit.loopexit ]
  %.180317.unr = phi double [ %.079.lcssa, %for_loop_body152.preheader ], [ %1756, %for_loop_body152.prol.loopexit.loopexit ]
  %.184316.unr = phi double [ %.083.lcssa, %for_loop_body152.preheader ], [ %1754, %for_loop_body152.prol.loopexit.loopexit ]
  %1760 = icmp ult i64 %1686, 3
  br i1 %1760, label %after_for154, label %for_loop_body152.preheader511

for_loop_body152.preheader511:                    ; preds = %for_loop_body152.prol.loopexit
  br label %for_loop_body152

true_block91:                                     ; preds = %for_loop_body87
  %1761 = select i1 %1643, double %148, double %1634
  %1762 = select i1 %1643, double %142, double %1628
  %1763 = select i1 %1643, double %136, double %1622
  %1764 = select i1 %1641, double %148, double %1603
  %1765 = select i1 %1641, double %142, double %1597
  %1766 = select i1 %1641, double %136, double %1591
  %1767 = fsub double %1763, %1766
  %1768 = load ptr, ptr %1539, align 8
  %1769 = load i32, ptr %1540, align 4
  %1770 = sext i32 %1769 to i64
  %1771 = getelementptr double, ptr %1768, i64 %1561
  %1772 = load double, ptr %1771, align 8
  %1773 = fsub double %1766, %1772
  %1774 = select i1 %.not121, double %1773, double %1767
  %1775 = fmul double %1774, %1774
  %1776 = fsub double %1762, %1765
  %1777 = add nsw i64 %1770, %1561
  %1778 = getelementptr double, ptr %1768, i64 %1777
  %1779 = load double, ptr %1778, align 8
  %1780 = fsub double %1765, %1779
  %1781 = select i1 %.not121, double %1780, double %1776
  %1782 = fmul double %1781, %1781
  %1783 = fadd double %1775, %1782
  %1784 = fsub double %1761, %1764
  %1785 = shl nsw i64 %1770, 1
  %1786 = add nsw i64 %1785, %1561
  %1787 = getelementptr double, ptr %1768, i64 %1786
  %1788 = load double, ptr %1787, align 8
  %1789 = fsub double %1764, %1788
  %1790 = select i1 %.not121, double %1789, double %1784
  %1791 = fmul double %1790, %1790
  %1792 = fadd double %1783, %1791
  %1793 = fcmp ogt double %1792, 0.000000e+00
  br i1 %1793, label %true_block94, label %true_block121

true_block94:                                     ; preds = %true_block91
  %sqrt = tail call double @llvm.sqrt.f64(double %1792)
  %1794 = fdiv double 1.000000e+00, %sqrt
  %1795 = mul nsw i64 %1770, 6
  %1796 = add nsw i64 %1795, %1561
  %1797 = getelementptr double, ptr %1768, i64 %1796
  %1798 = load double, ptr %1797, align 8
  %1799 = load ptr, ptr %0, align 8
  %1800 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1799, i64 0, i32 11, i32 1
  %1801 = load ptr, ptr %1800, align 8
  %1802 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1799, i64 0, i32 11, i32 0, i32 1
  %1803 = load i32, ptr %1802, align 4
  %1804 = sext i32 %1803 to i64
  %1805 = shl i64 %indvars.iv358, 3
  %uglygep519 = getelementptr i8, ptr %1801, i64 %1805
  %1806 = load i64, ptr %uglygep519, align 8
  %1807 = uitofp i64 %1806 to double
  %1808 = add nsw i64 %indvars.iv358, %1804
  %1809 = getelementptr i64, ptr %1801, i64 %1808
  %1810 = load i64, ptr %1809, align 8
  %1811 = uitofp i64 %1810 to double
  %1812 = fdiv double %1807, %1811
  %1813 = fmul double %1798, %1812
  %1814 = select i1 %.not121, double %1642, double %1644
  %1815 = load double, ptr %1528, align 8
  %1816 = fmul double %1815, %1813
  %1817 = fmul double %1794, %1794
  %1818 = fmul double %1794, %1817
  %1819 = fmul double %1814, %1818
  %1820 = fmul double %1819, %1816
  %1821 = bitcast double %1792 to i64
  %1822 = and i64 %1821, 9223372036854775807
  %1823 = and i64 %1821, 9218868437227405312
  %1824 = icmp eq i64 %1822, 0
  %1825 = icmp ne i64 %1823, 0
  %1826 = icmp ne i64 %1823, 9218868437227405312
  %1827 = and i1 %1825, %1826
  %1828 = or i1 %1824, %1827
  br i1 %1828, label %after_if99, label %true_block97

true_block97:                                     ; preds = %true_block94
  %1829 = load ptr, ptr %105, align 8
  %1830 = atomicrmw add ptr %1829, i64 1 seq_cst, align 8
  br label %after_if99

after_if99:                                       ; preds = %true_block97, %true_block94
  %1831 = bitcast double %1794 to i64
  %1832 = and i64 %1831, 9223372036854775807
  %1833 = and i64 %1831, 9218868437227405312
  %1834 = icmp eq i64 %1832, 0
  %1835 = icmp ne i64 %1833, 0
  %1836 = icmp ne i64 %1833, 9218868437227405312
  %1837 = and i1 %1835, %1836
  %1838 = or i1 %1834, %1837
  br i1 %1838, label %after_if102, label %true_block100

true_block100:                                    ; preds = %after_if99
  %1839 = load ptr, ptr %105, align 8
  %1840 = atomicrmw add ptr %1839, i64 1 seq_cst, align 8
  br label %after_if102

after_if102:                                      ; preds = %true_block100, %after_if99
  %1841 = bitcast double %1813 to i64
  %1842 = and i64 %1841, 9223372036854775807
  %1843 = and i64 %1841, 9218868437227405312
  %1844 = icmp eq i64 %1842, 0
  %1845 = icmp ne i64 %1843, 0
  %1846 = icmp ne i64 %1843, 9218868437227405312
  %1847 = and i1 %1845, %1846
  %1848 = or i1 %1844, %1847
  br i1 %1848, label %after_if105, label %true_block103

true_block103:                                    ; preds = %after_if102
  %1849 = load ptr, ptr %105, align 8
  %1850 = atomicrmw add ptr %1849, i64 1 seq_cst, align 8
  br label %after_if105

after_if105:                                      ; preds = %true_block103, %after_if102
  %1851 = bitcast double %1814 to i64
  %1852 = and i64 %1851, 9223372036854775807
  %1853 = and i64 %1851, 9218868437227405312
  %1854 = icmp eq i64 %1852, 0
  %1855 = icmp ne i64 %1853, 0
  %1856 = icmp ne i64 %1853, 9218868437227405312
  %1857 = and i1 %1855, %1856
  %1858 = or i1 %1854, %1857
  br i1 %1858, label %after_if108, label %true_block106

true_block106:                                    ; preds = %after_if105
  %1859 = load ptr, ptr %105, align 8
  %1860 = atomicrmw add ptr %1859, i64 1 seq_cst, align 8
  br label %after_if108

after_if108:                                      ; preds = %true_block106, %after_if105
  %1861 = bitcast double %1820 to i64
  %1862 = and i64 %1861, 9223372036854775807
  %1863 = and i64 %1861, 9218868437227405312
  %1864 = icmp eq i64 %1862, 0
  %1865 = icmp ne i64 %1863, 0
  %1866 = icmp ne i64 %1863, 9218868437227405312
  %1867 = and i1 %1865, %1866
  %1868 = or i1 %1864, %1867
  br i1 %1868, label %after_if111, label %true_block109

true_block109:                                    ; preds = %after_if108
  %1869 = load ptr, ptr %105, align 8
  %1870 = atomicrmw add ptr %1869, i64 1 seq_cst, align 8
  br label %after_if111

after_if111:                                      ; preds = %true_block109, %after_if108
  %1871 = fmul double %1774, %1820
  %1872 = bitcast double %1871 to i64
  %1873 = and i64 %1872, 9223372036854775807
  %1874 = and i64 %1872, 9218868437227405312
  %1875 = icmp eq i64 %1873, 0
  %1876 = icmp ne i64 %1874, 0
  %1877 = icmp ne i64 %1874, 9218868437227405312
  %1878 = and i1 %1876, %1877
  %1879 = or i1 %1875, %1878
  br i1 %1879, label %after_if114, label %true_block112

true_block112:                                    ; preds = %after_if111
  %1880 = load ptr, ptr %105, align 8
  %1881 = atomicrmw add ptr %1880, i64 1 seq_cst, align 8
  br label %after_if114

after_if114:                                      ; preds = %true_block112, %after_if111
  %1882 = fmul double %1781, %1820
  %1883 = bitcast double %1882 to i64
  %1884 = and i64 %1883, 9223372036854775807
  %1885 = and i64 %1883, 9218868437227405312
  %1886 = icmp eq i64 %1884, 0
  %1887 = icmp ne i64 %1885, 0
  %1888 = icmp ne i64 %1885, 9218868437227405312
  %1889 = and i1 %1887, %1888
  %1890 = or i1 %1886, %1889
  br i1 %1890, label %after_if117, label %true_block115

true_block115:                                    ; preds = %after_if114
  %1891 = load ptr, ptr %105, align 8
  %1892 = atomicrmw add ptr %1891, i64 1 seq_cst, align 8
  br label %after_if117

after_if117:                                      ; preds = %true_block115, %after_if114
  %1893 = fmul double %1790, %1820
  %1894 = bitcast double %1893 to i64
  %1895 = and i64 %1894, 9223372036854775807
  %1896 = and i64 %1894, 9218868437227405312
  %1897 = icmp eq i64 %1895, 0
  %1898 = icmp ne i64 %1896, 0
  %1899 = icmp ne i64 %1896, 9218868437227405312
  %1900 = and i1 %1898, %1899
  %1901 = or i1 %1897, %1900
  br i1 %1901, label %true_block121, label %true_block118

true_block118:                                    ; preds = %after_if117
  %1902 = load ptr, ptr %105, align 8
  %1903 = atomicrmw add ptr %1902, i64 1 seq_cst, align 8
  br label %true_block121

true_block121:                                    ; preds = %true_block118, %after_if117, %true_block91
  %.075.ph = phi double [ %1871, %true_block118 ], [ %1871, %after_if117 ], [ 0.000000e+00, %true_block91 ]
  %.074.ph = phi double [ %1882, %true_block118 ], [ %1882, %after_if117 ], [ 0.000000e+00, %true_block91 ]
  %.073.ph = phi double [ %1893, %true_block118 ], [ %1893, %after_if117 ], [ 0.000000e+00, %true_block91 ]
  %1904 = select i1 %1643, double %1165, double %1634
  %1905 = select i1 %1643, double %1140, double %1628
  %1906 = select i1 %1643, double %395, double %1622
  %1907 = select i1 %1641, double %1165, double %1603
  %1908 = select i1 %1641, double %1140, double %1597
  %1909 = select i1 %1641, double %395, double %1591
  %1910 = fsub double %1906, %1909
  %1911 = load ptr, ptr %1539, align 8
  %1912 = load i32, ptr %1540, align 4
  %1913 = sext i32 %1912 to i64
  %1914 = getelementptr double, ptr %1911, i64 %1561
  %1915 = load double, ptr %1914, align 8
  %1916 = fsub double %1909, %1915
  %1917 = select i1 %.not121, double %1916, double %1910
  %1918 = fmul double %1917, %1917
  %1919 = fsub double %1905, %1908
  %1920 = add nsw i64 %1913, %1561
  %1921 = getelementptr double, ptr %1911, i64 %1920
  %1922 = load double, ptr %1921, align 8
  %1923 = fsub double %1908, %1922
  %1924 = select i1 %.not121, double %1923, double %1919
  %1925 = fmul double %1924, %1924
  %1926 = fadd double %1918, %1925
  %1927 = fsub double %1904, %1907
  %1928 = shl nsw i64 %1913, 1
  %1929 = add nsw i64 %1928, %1561
  %1930 = getelementptr double, ptr %1911, i64 %1929
  %1931 = load double, ptr %1930, align 8
  %1932 = fsub double %1907, %1931
  %1933 = select i1 %.not121, double %1932, double %1927
  %1934 = fmul double %1933, %1933
  %1935 = fadd double %1926, %1934
  %1936 = fcmp ogt double %1935, 0.000000e+00
  br i1 %1936, label %true_block124, label %after_if123

after_if123:                                      ; preds = %true_block149, %after_if148, %true_block121, %for_loop_body87
  %.073270 = phi double [ %.073.ph, %true_block121 ], [ %.073.ph, %after_if148 ], [ %.073.ph, %true_block149 ], [ 0.000000e+00, %for_loop_body87 ]
  %.074268 = phi double [ %.074.ph, %true_block121 ], [ %.074.ph, %after_if148 ], [ %.074.ph, %true_block149 ], [ 0.000000e+00, %for_loop_body87 ]
  %.075266 = phi double [ %.075.ph, %true_block121 ], [ %.075.ph, %after_if148 ], [ %.075.ph, %true_block149 ], [ 0.000000e+00, %for_loop_body87 ]
  %.072 = phi double [ 0.000000e+00, %true_block121 ], [ %2022, %after_if148 ], [ %2022, %true_block149 ], [ 0.000000e+00, %for_loop_body87 ]
  %.071 = phi double [ 0.000000e+00, %true_block121 ], [ %2033, %after_if148 ], [ %2033, %true_block149 ], [ 0.000000e+00, %for_loop_body87 ]
  %.070 = phi double [ 0.000000e+00, %true_block121 ], [ %2044, %after_if148 ], [ %2044, %true_block149 ], [ 0.000000e+00, %for_loop_body87 ]
  %1937 = fadd double %.086303, %.075266
  %1938 = fadd double %.083304, %.072
  %1939 = fadd double %.082305, %.074268
  %1940 = fadd double %.079306, %.071
  %1941 = fadd double %.078307, %.073270
  %1942 = fadd double %.077308, %.070
  %indvars.iv.next359 = add nsw i64 %indvars.iv358, 1
  %exitcond362.not = icmp eq i64 %wide.trip.count361, %indvars.iv.next359
  br i1 %exitcond362.not, label %after_for89.loopexit, label %for_loop_body87

true_block124:                                    ; preds = %true_block121
  %1943 = select i1 %1643, double %.0112, double %1640
  %1944 = select i1 %1641, double %.0112, double %1609
  %sqrt127 = tail call double @llvm.sqrt.f64(double %1935)
  %1945 = fdiv double 1.000000e+00, %sqrt127
  %1946 = mul nsw i64 %1913, 6
  %1947 = add nsw i64 %1946, %1561
  %1948 = getelementptr double, ptr %1911, i64 %1947
  %1949 = load double, ptr %1948, align 8
  %1950 = load ptr, ptr %0, align 8
  %1951 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1950, i64 0, i32 11, i32 1
  %1952 = load ptr, ptr %1951, align 8
  %1953 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1950, i64 0, i32 11, i32 0, i32 1
  %1954 = load i32, ptr %1953, align 4
  %1955 = sext i32 %1954 to i64
  %1956 = shl i64 %indvars.iv358, 3
  %uglygep520 = getelementptr i8, ptr %1952, i64 %1956
  %1957 = load i64, ptr %uglygep520, align 8
  %1958 = uitofp i64 %1957 to double
  %1959 = add nsw i64 %indvars.iv358, %1955
  %1960 = getelementptr i64, ptr %1952, i64 %1959
  %1961 = load i64, ptr %1960, align 8
  %1962 = uitofp i64 %1961 to double
  %1963 = fdiv double %1958, %1962
  %1964 = fmul double %1949, %1963
  %1965 = select i1 %.not121, double %1944, double %1943
  %1966 = load double, ptr %1528, align 8
  %1967 = fmul double %1966, %1964
  %1968 = fmul double %1945, %1945
  %1969 = fmul double %1945, %1968
  %1970 = fmul double %1965, %1969
  %1971 = fmul double %1970, %1967
  %1972 = bitcast double %1935 to i64
  %1973 = and i64 %1972, 9223372036854775807
  %1974 = and i64 %1972, 9218868437227405312
  %1975 = icmp eq i64 %1973, 0
  %1976 = icmp ne i64 %1974, 0
  %1977 = icmp ne i64 %1974, 9218868437227405312
  %1978 = and i1 %1976, %1977
  %1979 = or i1 %1975, %1978
  br i1 %1979, label %after_if130, label %true_block128

true_block128:                                    ; preds = %true_block124
  %1980 = load ptr, ptr %105, align 8
  %1981 = atomicrmw add ptr %1980, i64 1 seq_cst, align 8
  br label %after_if130

after_if130:                                      ; preds = %true_block128, %true_block124
  %1982 = bitcast double %1945 to i64
  %1983 = and i64 %1982, 9223372036854775807
  %1984 = and i64 %1982, 9218868437227405312
  %1985 = icmp eq i64 %1983, 0
  %1986 = icmp ne i64 %1984, 0
  %1987 = icmp ne i64 %1984, 9218868437227405312
  %1988 = and i1 %1986, %1987
  %1989 = or i1 %1985, %1988
  br i1 %1989, label %after_if133, label %true_block131

true_block131:                                    ; preds = %after_if130
  %1990 = load ptr, ptr %105, align 8
  %1991 = atomicrmw add ptr %1990, i64 1 seq_cst, align 8
  br label %after_if133

after_if133:                                      ; preds = %true_block131, %after_if130
  %1992 = bitcast double %1964 to i64
  %1993 = and i64 %1992, 9223372036854775807
  %1994 = and i64 %1992, 9218868437227405312
  %1995 = icmp eq i64 %1993, 0
  %1996 = icmp ne i64 %1994, 0
  %1997 = icmp ne i64 %1994, 9218868437227405312
  %1998 = and i1 %1996, %1997
  %1999 = or i1 %1995, %1998
  br i1 %1999, label %after_if136, label %true_block134

true_block134:                                    ; preds = %after_if133
  %2000 = load ptr, ptr %105, align 8
  %2001 = atomicrmw add ptr %2000, i64 1 seq_cst, align 8
  br label %after_if136

after_if136:                                      ; preds = %true_block134, %after_if133
  %2002 = bitcast double %1965 to i64
  %2003 = and i64 %2002, 9223372036854775807
  %2004 = and i64 %2002, 9218868437227405312
  %2005 = icmp eq i64 %2003, 0
  %2006 = icmp ne i64 %2004, 0
  %2007 = icmp ne i64 %2004, 9218868437227405312
  %2008 = and i1 %2006, %2007
  %2009 = or i1 %2005, %2008
  br i1 %2009, label %after_if139, label %true_block137

true_block137:                                    ; preds = %after_if136
  %2010 = load ptr, ptr %105, align 8
  %2011 = atomicrmw add ptr %2010, i64 1 seq_cst, align 8
  br label %after_if139

after_if139:                                      ; preds = %true_block137, %after_if136
  %2012 = bitcast double %1971 to i64
  %2013 = and i64 %2012, 9223372036854775807
  %2014 = and i64 %2012, 9218868437227405312
  %2015 = icmp eq i64 %2013, 0
  %2016 = icmp ne i64 %2014, 0
  %2017 = icmp ne i64 %2014, 9218868437227405312
  %2018 = and i1 %2016, %2017
  %2019 = or i1 %2015, %2018
  br i1 %2019, label %after_if142, label %true_block140

true_block140:                                    ; preds = %after_if139
  %2020 = load ptr, ptr %105, align 8
  %2021 = atomicrmw add ptr %2020, i64 1 seq_cst, align 8
  br label %after_if142

after_if142:                                      ; preds = %true_block140, %after_if139
  %2022 = fmul double %1917, %1971
  %2023 = bitcast double %2022 to i64
  %2024 = and i64 %2023, 9223372036854775807
  %2025 = and i64 %2023, 9218868437227405312
  %2026 = icmp eq i64 %2024, 0
  %2027 = icmp ne i64 %2025, 0
  %2028 = icmp ne i64 %2025, 9218868437227405312
  %2029 = and i1 %2027, %2028
  %2030 = or i1 %2026, %2029
  br i1 %2030, label %after_if145, label %true_block143

true_block143:                                    ; preds = %after_if142
  %2031 = load ptr, ptr %105, align 8
  %2032 = atomicrmw add ptr %2031, i64 1 seq_cst, align 8
  br label %after_if145

after_if145:                                      ; preds = %true_block143, %after_if142
  %2033 = fmul double %1924, %1971
  %2034 = bitcast double %2033 to i64
  %2035 = and i64 %2034, 9223372036854775807
  %2036 = and i64 %2034, 9218868437227405312
  %2037 = icmp eq i64 %2035, 0
  %2038 = icmp ne i64 %2036, 0
  %2039 = icmp ne i64 %2036, 9218868437227405312
  %2040 = and i1 %2038, %2039
  %2041 = or i1 %2037, %2040
  br i1 %2041, label %after_if148, label %true_block146

true_block146:                                    ; preds = %after_if145
  %2042 = load ptr, ptr %105, align 8
  %2043 = atomicrmw add ptr %2042, i64 1 seq_cst, align 8
  br label %after_if148

after_if148:                                      ; preds = %true_block146, %after_if145
  %2044 = fmul double %1933, %1971
  %2045 = bitcast double %2044 to i64
  %2046 = and i64 %2045, 9223372036854775807
  %2047 = and i64 %2045, 9218868437227405312
  %2048 = icmp eq i64 %2046, 0
  %2049 = icmp ne i64 %2047, 0
  %2050 = icmp ne i64 %2047, 9218868437227405312
  %2051 = and i1 %2049, %2050
  %2052 = or i1 %2048, %2051
  br i1 %2052, label %after_if123, label %true_block149

true_block149:                                    ; preds = %after_if148
  %2053 = load ptr, ptr %105, align 8
  %2054 = atomicrmw add ptr %2053, i64 1 seq_cst, align 8
  br label %after_if123

for_loop_body152:                                 ; preds = %for_loop_body152, %for_loop_body152.preheader511
  %indvars.iv363 = phi i64 [ %indvars.iv.next364.3, %for_loop_body152 ], [ %indvars.iv363.unr, %for_loop_body152.preheader511 ]
  %.1318 = phi double [ %2339, %for_loop_body152 ], [ %.1318.unr, %for_loop_body152.preheader511 ]
  %.180317 = phi double [ %2337, %for_loop_body152 ], [ %.180317.unr, %for_loop_body152.preheader511 ]
  %.184316 = phi double [ %2335, %for_loop_body152 ], [ %.184316.unr, %for_loop_body152.preheader511 ]
  %2055 = atomicrmw add ptr %1531, i64 1 seq_cst, align 8
  %2056 = load ptr, ptr %1543, align 8
  %2057 = shl i64 %indvars.iv363, 2
  %uglygep528 = getelementptr i8, ptr %2056, i64 %2057
  %2058 = load i32, ptr %uglygep528, align 4
  %2059 = load ptr, ptr %1544, align 8
  %2060 = load i32, ptr %1545, align 4
  %2061 = sext i32 %2060 to i64
  %2062 = sext i32 %2058 to i64
  %2063 = getelementptr i32, ptr %2059, i64 %2062
  %2064 = load i32, ptr %2063, align 4
  %2065 = add nsw i64 %2061, %2062
  %2066 = getelementptr i32, ptr %2059, i64 %2065
  %2067 = load i32, ptr %2066, align 4
  %2068 = load ptr, ptr %1539, align 8
  %2069 = load i32, ptr %1540, align 4
  %2070 = sext i32 %2069 to i64
  %2071 = sext i32 %2067 to i64
  %2072 = getelementptr double, ptr %2068, i64 %2071
  %2073 = load double, ptr %2072, align 8
  %2074 = sext i32 %2064 to i64
  %2075 = getelementptr double, ptr %2068, i64 %2074
  %2076 = load double, ptr %2075, align 8
  %2077 = fsub double %2073, %2076
  %2078 = add nsw i64 %2070, %2071
  %2079 = getelementptr double, ptr %2068, i64 %2078
  %2080 = load double, ptr %2079, align 8
  %2081 = add nsw i64 %2070, %2074
  %2082 = getelementptr double, ptr %2068, i64 %2081
  %2083 = load double, ptr %2082, align 8
  %2084 = fsub double %2080, %2083
  %2085 = shl nsw i64 %2070, 1
  %2086 = add nsw i64 %2085, %2071
  %2087 = getelementptr double, ptr %2068, i64 %2086
  %2088 = load double, ptr %2087, align 8
  %2089 = add nsw i64 %2085, %2074
  %2090 = getelementptr double, ptr %2068, i64 %2089
  %2091 = load double, ptr %2090, align 8
  %2092 = fsub double %2088, %2091
  %2093 = mul nsw i64 %2070, 7
  %2094 = add nsw i64 %2093, %2074
  %2095 = getelementptr double, ptr %2068, i64 %2094
  %2096 = load double, ptr %2095, align 8
  %2097 = add nsw i64 %2093, %2071
  %2098 = getelementptr double, ptr %2068, i64 %2097
  %2099 = load double, ptr %2098, align 8
  %2100 = fmul double %2077, %2077
  %2101 = fmul double %2084, %2084
  %2102 = fadd double %2100, %2101
  %2103 = fmul double %2092, %2092
  %2104 = fadd double %2102, %2103
  %2105 = fcmp ogt double %2104, 0.000000e+00
  %.0.i124 = select i1 %2105, double 1.000000e+00, double 0.000000e+00
  %2106 = fsub double 1.000000e+00, %.0.i124
  %2107 = fadd double %2104, %2106
  %sqrt156 = tail call double @llvm.sqrt.f64(double %2107)
  %2108 = fdiv double 1.000000e+00, %sqrt156
  %2109 = fmul double %2107, %2108
  %2110 = fadd double %2096, %2099
  %2111 = fsub double %2110, %2109
  %2112 = tail call double @llvm.maxnum.f64(double %2111, double 0.000000e+00)
  %2113 = load ptr, ptr %9, align 8
  %2114 = getelementptr inbounds %struct.LLVMRuntime, ptr %2113, i64 0, i32 16
  %2115 = load ptr, ptr %2114, align 8
  %2116 = getelementptr inbounds i8, ptr %2115, i64 16
  %2117 = load double, ptr %2116, align 8
  %2118 = fmul double %.0.i124, %2108
  %2119 = fneg double %2117
  %2120 = fmul double %2112, %2119
  %neg = fmul double %2118, %2120
  %2121 = fmul double %2077, %neg
  %2122 = fadd double %.184316, %2121
  %2123 = fmul double %2084, %neg
  %2124 = fadd double %.180317, %2123
  %2125 = fmul double %2092, %neg
  %2126 = fadd double %.1318, %2125
  %2127 = atomicrmw add ptr %1531, i64 1 seq_cst, align 8
  %2128 = load ptr, ptr %1543, align 8
  %uglygep529 = getelementptr i8, ptr %2128, i64 4
  %uglygep530 = getelementptr i8, ptr %uglygep529, i64 %2057
  %2129 = load i32, ptr %uglygep530, align 4
  %2130 = load ptr, ptr %1544, align 8
  %2131 = load i32, ptr %1545, align 4
  %2132 = sext i32 %2131 to i64
  %2133 = sext i32 %2129 to i64
  %2134 = getelementptr i32, ptr %2130, i64 %2133
  %2135 = load i32, ptr %2134, align 4
  %2136 = add nsw i64 %2132, %2133
  %2137 = getelementptr i32, ptr %2130, i64 %2136
  %2138 = load i32, ptr %2137, align 4
  %2139 = load ptr, ptr %1539, align 8
  %2140 = load i32, ptr %1540, align 4
  %2141 = sext i32 %2140 to i64
  %2142 = sext i32 %2138 to i64
  %2143 = getelementptr double, ptr %2139, i64 %2142
  %2144 = load double, ptr %2143, align 8
  %2145 = sext i32 %2135 to i64
  %2146 = getelementptr double, ptr %2139, i64 %2145
  %2147 = load double, ptr %2146, align 8
  %2148 = fsub double %2144, %2147
  %2149 = add nsw i64 %2141, %2142
  %2150 = getelementptr double, ptr %2139, i64 %2149
  %2151 = load double, ptr %2150, align 8
  %2152 = add nsw i64 %2141, %2145
  %2153 = getelementptr double, ptr %2139, i64 %2152
  %2154 = load double, ptr %2153, align 8
  %2155 = fsub double %2151, %2154
  %2156 = shl nsw i64 %2141, 1
  %2157 = add nsw i64 %2156, %2142
  %2158 = getelementptr double, ptr %2139, i64 %2157
  %2159 = load double, ptr %2158, align 8
  %2160 = add nsw i64 %2156, %2145
  %2161 = getelementptr double, ptr %2139, i64 %2160
  %2162 = load double, ptr %2161, align 8
  %2163 = fsub double %2159, %2162
  %2164 = mul nsw i64 %2141, 7
  %2165 = add nsw i64 %2164, %2145
  %2166 = getelementptr double, ptr %2139, i64 %2165
  %2167 = load double, ptr %2166, align 8
  %2168 = add nsw i64 %2164, %2142
  %2169 = getelementptr double, ptr %2139, i64 %2168
  %2170 = load double, ptr %2169, align 8
  %2171 = fmul double %2148, %2148
  %2172 = fmul double %2155, %2155
  %2173 = fadd double %2171, %2172
  %2174 = fmul double %2163, %2163
  %2175 = fadd double %2173, %2174
  %2176 = fcmp ogt double %2175, 0.000000e+00
  %.0.i124.1 = select i1 %2176, double 1.000000e+00, double 0.000000e+00
  %2177 = fsub double 1.000000e+00, %.0.i124.1
  %2178 = fadd double %2175, %2177
  %sqrt156.1 = tail call double @llvm.sqrt.f64(double %2178)
  %2179 = fdiv double 1.000000e+00, %sqrt156.1
  %2180 = fmul double %2178, %2179
  %2181 = fadd double %2167, %2170
  %2182 = fsub double %2181, %2180
  %2183 = tail call double @llvm.maxnum.f64(double %2182, double 0.000000e+00)
  %2184 = load ptr, ptr %9, align 8
  %2185 = getelementptr inbounds %struct.LLVMRuntime, ptr %2184, i64 0, i32 16
  %2186 = load ptr, ptr %2185, align 8
  %2187 = getelementptr inbounds i8, ptr %2186, i64 16
  %2188 = load double, ptr %2187, align 8
  %2189 = fmul double %.0.i124.1, %2179
  %2190 = fneg double %2188
  %2191 = fmul double %2183, %2190
  %neg.1 = fmul double %2189, %2191
  %2192 = fmul double %2148, %neg.1
  %2193 = fadd double %2122, %2192
  %2194 = fmul double %2155, %neg.1
  %2195 = fadd double %2124, %2194
  %2196 = fmul double %2163, %neg.1
  %2197 = fadd double %2126, %2196
  %2198 = atomicrmw add ptr %1531, i64 1 seq_cst, align 8
  %2199 = load ptr, ptr %1543, align 8
  %uglygep526 = getelementptr i8, ptr %2199, i64 8
  %uglygep527 = getelementptr i8, ptr %uglygep526, i64 %2057
  %2200 = load i32, ptr %uglygep527, align 4
  %2201 = load ptr, ptr %1544, align 8
  %2202 = load i32, ptr %1545, align 4
  %2203 = sext i32 %2202 to i64
  %2204 = sext i32 %2200 to i64
  %2205 = getelementptr i32, ptr %2201, i64 %2204
  %2206 = load i32, ptr %2205, align 4
  %2207 = add nsw i64 %2203, %2204
  %2208 = getelementptr i32, ptr %2201, i64 %2207
  %2209 = load i32, ptr %2208, align 4
  %2210 = load ptr, ptr %1539, align 8
  %2211 = load i32, ptr %1540, align 4
  %2212 = sext i32 %2211 to i64
  %2213 = sext i32 %2209 to i64
  %2214 = getelementptr double, ptr %2210, i64 %2213
  %2215 = load double, ptr %2214, align 8
  %2216 = sext i32 %2206 to i64
  %2217 = getelementptr double, ptr %2210, i64 %2216
  %2218 = load double, ptr %2217, align 8
  %2219 = fsub double %2215, %2218
  %2220 = add nsw i64 %2212, %2213
  %2221 = getelementptr double, ptr %2210, i64 %2220
  %2222 = load double, ptr %2221, align 8
  %2223 = add nsw i64 %2212, %2216
  %2224 = getelementptr double, ptr %2210, i64 %2223
  %2225 = load double, ptr %2224, align 8
  %2226 = fsub double %2222, %2225
  %2227 = shl nsw i64 %2212, 1
  %2228 = add nsw i64 %2227, %2213
  %2229 = getelementptr double, ptr %2210, i64 %2228
  %2230 = load double, ptr %2229, align 8
  %2231 = add nsw i64 %2227, %2216
  %2232 = getelementptr double, ptr %2210, i64 %2231
  %2233 = load double, ptr %2232, align 8
  %2234 = fsub double %2230, %2233
  %2235 = mul nsw i64 %2212, 7
  %2236 = add nsw i64 %2235, %2216
  %2237 = getelementptr double, ptr %2210, i64 %2236
  %2238 = load double, ptr %2237, align 8
  %2239 = add nsw i64 %2235, %2213
  %2240 = getelementptr double, ptr %2210, i64 %2239
  %2241 = load double, ptr %2240, align 8
  %2242 = fmul double %2219, %2219
  %2243 = fmul double %2226, %2226
  %2244 = fadd double %2242, %2243
  %2245 = fmul double %2234, %2234
  %2246 = fadd double %2244, %2245
  %2247 = fcmp ogt double %2246, 0.000000e+00
  %.0.i124.2 = select i1 %2247, double 1.000000e+00, double 0.000000e+00
  %2248 = fsub double 1.000000e+00, %.0.i124.2
  %2249 = fadd double %2246, %2248
  %sqrt156.2 = tail call double @llvm.sqrt.f64(double %2249)
  %2250 = fdiv double 1.000000e+00, %sqrt156.2
  %2251 = fmul double %2249, %2250
  %2252 = fadd double %2238, %2241
  %2253 = fsub double %2252, %2251
  %2254 = tail call double @llvm.maxnum.f64(double %2253, double 0.000000e+00)
  %2255 = load ptr, ptr %9, align 8
  %2256 = getelementptr inbounds %struct.LLVMRuntime, ptr %2255, i64 0, i32 16
  %2257 = load ptr, ptr %2256, align 8
  %2258 = getelementptr inbounds i8, ptr %2257, i64 16
  %2259 = load double, ptr %2258, align 8
  %2260 = fmul double %.0.i124.2, %2250
  %2261 = fneg double %2259
  %2262 = fmul double %2254, %2261
  %neg.2 = fmul double %2260, %2262
  %2263 = fmul double %2219, %neg.2
  %2264 = fadd double %2193, %2263
  %2265 = fmul double %2226, %neg.2
  %2266 = fadd double %2195, %2265
  %2267 = fmul double %2234, %neg.2
  %2268 = fadd double %2197, %2267
  %2269 = atomicrmw add ptr %1531, i64 1 seq_cst, align 8
  %2270 = load ptr, ptr %1543, align 8
  %uglygep524 = getelementptr i8, ptr %2270, i64 12
  %uglygep525 = getelementptr i8, ptr %uglygep524, i64 %2057
  %2271 = load i32, ptr %uglygep525, align 4
  %2272 = load ptr, ptr %1544, align 8
  %2273 = load i32, ptr %1545, align 4
  %2274 = sext i32 %2273 to i64
  %2275 = sext i32 %2271 to i64
  %2276 = getelementptr i32, ptr %2272, i64 %2275
  %2277 = load i32, ptr %2276, align 4
  %2278 = add nsw i64 %2274, %2275
  %2279 = getelementptr i32, ptr %2272, i64 %2278
  %2280 = load i32, ptr %2279, align 4
  %2281 = load ptr, ptr %1539, align 8
  %2282 = load i32, ptr %1540, align 4
  %2283 = sext i32 %2282 to i64
  %2284 = sext i32 %2280 to i64
  %2285 = getelementptr double, ptr %2281, i64 %2284
  %2286 = load double, ptr %2285, align 8
  %2287 = sext i32 %2277 to i64
  %2288 = getelementptr double, ptr %2281, i64 %2287
  %2289 = load double, ptr %2288, align 8
  %2290 = fsub double %2286, %2289
  %2291 = add nsw i64 %2283, %2284
  %2292 = getelementptr double, ptr %2281, i64 %2291
  %2293 = load double, ptr %2292, align 8
  %2294 = add nsw i64 %2283, %2287
  %2295 = getelementptr double, ptr %2281, i64 %2294
  %2296 = load double, ptr %2295, align 8
  %2297 = fsub double %2293, %2296
  %2298 = shl nsw i64 %2283, 1
  %2299 = add nsw i64 %2298, %2284
  %2300 = getelementptr double, ptr %2281, i64 %2299
  %2301 = load double, ptr %2300, align 8
  %2302 = add nsw i64 %2298, %2287
  %2303 = getelementptr double, ptr %2281, i64 %2302
  %2304 = load double, ptr %2303, align 8
  %2305 = fsub double %2301, %2304
  %2306 = mul nsw i64 %2283, 7
  %2307 = add nsw i64 %2306, %2287
  %2308 = getelementptr double, ptr %2281, i64 %2307
  %2309 = load double, ptr %2308, align 8
  %2310 = add nsw i64 %2306, %2284
  %2311 = getelementptr double, ptr %2281, i64 %2310
  %2312 = load double, ptr %2311, align 8
  %2313 = fmul double %2290, %2290
  %2314 = fmul double %2297, %2297
  %2315 = fadd double %2313, %2314
  %2316 = fmul double %2305, %2305
  %2317 = fadd double %2315, %2316
  %2318 = fcmp ogt double %2317, 0.000000e+00
  %.0.i124.3 = select i1 %2318, double 1.000000e+00, double 0.000000e+00
  %2319 = fsub double 1.000000e+00, %.0.i124.3
  %2320 = fadd double %2317, %2319
  %sqrt156.3 = tail call double @llvm.sqrt.f64(double %2320)
  %2321 = fdiv double 1.000000e+00, %sqrt156.3
  %2322 = fmul double %2320, %2321
  %2323 = fadd double %2309, %2312
  %2324 = fsub double %2323, %2322
  %2325 = tail call double @llvm.maxnum.f64(double %2324, double 0.000000e+00)
  %2326 = load ptr, ptr %9, align 8
  %2327 = getelementptr inbounds %struct.LLVMRuntime, ptr %2326, i64 0, i32 16
  %2328 = load ptr, ptr %2327, align 8
  %2329 = getelementptr inbounds i8, ptr %2328, i64 16
  %2330 = load double, ptr %2329, align 8
  %2331 = fmul double %.0.i124.3, %2321
  %2332 = fneg double %2330
  %2333 = fmul double %2325, %2332
  %neg.3 = fmul double %2331, %2333
  %2334 = fmul double %2290, %neg.3
  %2335 = fadd double %2264, %2334
  %2336 = fmul double %2297, %neg.3
  %2337 = fadd double %2266, %2336
  %2338 = fmul double %2305, %neg.3
  %2339 = fadd double %2268, %2338
  %indvars.iv.next364.3 = add nsw i64 %indvars.iv363, 4
  %exitcond367.not.3 = icmp eq i64 %wide.trip.count366, %indvars.iv.next364.3
  br i1 %exitcond367.not.3, label %after_for154.loopexit, label %for_loop_body152

after_for154.loopexit:                            ; preds = %for_loop_body152
  br label %after_for154

after_for154:                                     ; preds = %after_for154.loopexit, %for_loop_body152.prol.loopexit, %after_for89
  %.184.lcssa = phi double [ %.083.lcssa, %after_for89 ], [ %.lcssa442.unr, %for_loop_body152.prol.loopexit ], [ %2335, %after_for154.loopexit ]
  %.180.lcssa = phi double [ %.079.lcssa, %after_for89 ], [ %.lcssa441.unr, %for_loop_body152.prol.loopexit ], [ %2337, %after_for154.loopexit ]
  %.1.lcssa = phi double [ %.077.lcssa, %after_for89 ], [ %.lcssa440.unr, %for_loop_body152.prol.loopexit ], [ %2339, %after_for154.loopexit ]
  %2340 = load ptr, ptr %1546, align 8
  %2341 = load i32, ptr %1547, align 4
  %2342 = sext i32 %2341 to i64
  %2343 = getelementptr i32, ptr %2340, i64 %1561
  %2344 = load i32, ptr %2343, align 4
  %2345 = add nsw i64 %2342, %1561
  %2346 = getelementptr i32, ptr %2340, i64 %2345
  %2347 = load i32, ptr %2346, align 4
  %2348 = icmp slt i32 %2344, %2347
  br i1 %2348, label %for_loop_body157.preheader, label %after_for159

for_loop_body157.preheader:                       ; preds = %after_for154
  %2349 = sext i32 %2344 to i64
  %wide.trip.count371 = sext i32 %2347 to i64
  %2350 = sub nsw i64 %wide.trip.count371, %2349
  %2351 = xor i64 %2349, -1
  %2352 = add nsw i64 %2351, %wide.trip.count371
  %xtraiter467 = and i64 %2350, 3
  %lcmp.mod468.not = icmp eq i64 %xtraiter467, 0
  br i1 %lcmp.mod468.not, label %for_loop_body157.prol.loopexit, label %for_loop_body157.prol.preheader

for_loop_body157.prol.preheader:                  ; preds = %for_loop_body157.preheader
  br label %for_loop_body157.prol

for_loop_body157.prol:                            ; preds = %for_loop_body157.prol, %for_loop_body157.prol.preheader
  %lsr.iv532 = phi i64 [ %xtraiter467, %for_loop_body157.prol.preheader ], [ %lsr.iv.next533, %for_loop_body157.prol ]
  %indvars.iv368.prol = phi i64 [ %indvars.iv.next369.prol, %for_loop_body157.prol ], [ %2349, %for_loop_body157.prol.preheader ]
  %.2325.prol = phi double [ %2424, %for_loop_body157.prol ], [ %.1.lcssa, %for_loop_body157.prol.preheader ]
  %.281324.prol = phi double [ %2422, %for_loop_body157.prol ], [ %.180.lcssa, %for_loop_body157.prol.preheader ]
  %.285323.prol = phi double [ %2420, %for_loop_body157.prol ], [ %.184.lcssa, %for_loop_body157.prol.preheader ]
  %2353 = atomicrmw add ptr %1531, i64 1 seq_cst, align 8
  %2354 = load ptr, ptr %1548, align 8
  %2355 = shl nsw i64 %indvars.iv368.prol, 2
  %uglygep531 = getelementptr i8, ptr %2354, i64 %2355
  %2356 = load i32, ptr %uglygep531, align 4
  %2357 = load ptr, ptr %1544, align 8
  %2358 = load i32, ptr %1545, align 4
  %2359 = sext i32 %2358 to i64
  %2360 = sext i32 %2356 to i64
  %2361 = getelementptr i32, ptr %2357, i64 %2360
  %2362 = load i32, ptr %2361, align 4
  %2363 = add nsw i64 %2359, %2360
  %2364 = getelementptr i32, ptr %2357, i64 %2363
  %2365 = load i32, ptr %2364, align 4
  %2366 = load ptr, ptr %1539, align 8
  %2367 = load i32, ptr %1540, align 4
  %2368 = sext i32 %2367 to i64
  %2369 = sext i32 %2365 to i64
  %2370 = getelementptr double, ptr %2366, i64 %2369
  %2371 = load double, ptr %2370, align 8
  %2372 = sext i32 %2362 to i64
  %2373 = getelementptr double, ptr %2366, i64 %2372
  %2374 = load double, ptr %2373, align 8
  %2375 = fsub double %2371, %2374
  %2376 = add nsw i64 %2368, %2369
  %2377 = getelementptr double, ptr %2366, i64 %2376
  %2378 = load double, ptr %2377, align 8
  %2379 = add nsw i64 %2368, %2372
  %2380 = getelementptr double, ptr %2366, i64 %2379
  %2381 = load double, ptr %2380, align 8
  %2382 = fsub double %2378, %2381
  %2383 = shl nsw i64 %2368, 1
  %2384 = add nsw i64 %2383, %2369
  %2385 = getelementptr double, ptr %2366, i64 %2384
  %2386 = load double, ptr %2385, align 8
  %2387 = add nsw i64 %2383, %2372
  %2388 = getelementptr double, ptr %2366, i64 %2387
  %2389 = load double, ptr %2388, align 8
  %2390 = fsub double %2386, %2389
  %2391 = mul nsw i64 %2368, 7
  %2392 = add nsw i64 %2391, %2372
  %2393 = getelementptr double, ptr %2366, i64 %2392
  %2394 = load double, ptr %2393, align 8
  %2395 = add nsw i64 %2391, %2369
  %2396 = getelementptr double, ptr %2366, i64 %2395
  %2397 = load double, ptr %2396, align 8
  %2398 = fmul double %2375, %2375
  %2399 = fmul double %2382, %2382
  %2400 = fadd double %2398, %2399
  %2401 = fmul double %2390, %2390
  %2402 = fadd double %2400, %2401
  %2403 = fcmp ogt double %2402, 0.000000e+00
  %.0.i123.prol = select i1 %2403, double 1.000000e+00, double 0.000000e+00
  %2404 = fsub double 1.000000e+00, %.0.i123.prol
  %2405 = fadd double %2402, %2404
  %sqrt161.prol = tail call double @llvm.sqrt.f64(double %2405)
  %2406 = fdiv double 1.000000e+00, %sqrt161.prol
  %2407 = fmul double %2405, %2406
  %2408 = fadd double %2394, %2397
  %2409 = fsub double %2408, %2407
  %2410 = tail call double @llvm.maxnum.f64(double %2409, double 0.000000e+00)
  %2411 = load ptr, ptr %9, align 8
  %2412 = getelementptr inbounds %struct.LLVMRuntime, ptr %2411, i64 0, i32 16
  %2413 = load ptr, ptr %2412, align 8
  %2414 = getelementptr inbounds i8, ptr %2413, i64 16
  %2415 = load double, ptr %2414, align 8
  %2416 = fmul double %.0.i123.prol, %2406
  %2417 = fneg double %2415
  %2418 = fmul double %2410, %2417
  %neg162.prol = fmul double %2416, %2418
  %2419 = fmul double %2375, %neg162.prol
  %2420 = fsub double %.285323.prol, %2419
  %2421 = fmul double %2382, %neg162.prol
  %2422 = fsub double %.281324.prol, %2421
  %2423 = fmul double %2390, %neg162.prol
  %2424 = fsub double %.2325.prol, %2423
  %indvars.iv.next369.prol = add nsw i64 %indvars.iv368.prol, 1
  %lsr.iv.next533 = add nsw i64 %lsr.iv532, -1
  %prol.iter469.cmp.not = icmp eq i64 %lsr.iv.next533, 0
  br i1 %prol.iter469.cmp.not, label %for_loop_body157.prol.loopexit.loopexit, label %for_loop_body157.prol, !llvm.loop !15

for_loop_body157.prol.loopexit.loopexit:          ; preds = %for_loop_body157.prol
  %2425 = add i64 %2349, %xtraiter467
  br label %for_loop_body157.prol.loopexit

for_loop_body157.prol.loopexit:                   ; preds = %for_loop_body157.prol.loopexit.loopexit, %for_loop_body157.preheader
  %.lcssa445.unr = phi double [ undef, %for_loop_body157.preheader ], [ %2420, %for_loop_body157.prol.loopexit.loopexit ]
  %.lcssa444.unr = phi double [ undef, %for_loop_body157.preheader ], [ %2422, %for_loop_body157.prol.loopexit.loopexit ]
  %.lcssa443.unr = phi double [ undef, %for_loop_body157.preheader ], [ %2424, %for_loop_body157.prol.loopexit.loopexit ]
  %indvars.iv368.unr = phi i64 [ %2349, %for_loop_body157.preheader ], [ %2425, %for_loop_body157.prol.loopexit.loopexit ]
  %.2325.unr = phi double [ %.1.lcssa, %for_loop_body157.preheader ], [ %2424, %for_loop_body157.prol.loopexit.loopexit ]
  %.281324.unr = phi double [ %.180.lcssa, %for_loop_body157.preheader ], [ %2422, %for_loop_body157.prol.loopexit.loopexit ]
  %.285323.unr = phi double [ %.184.lcssa, %for_loop_body157.preheader ], [ %2420, %for_loop_body157.prol.loopexit.loopexit ]
  %2426 = icmp ult i64 %2352, 3
  br i1 %2426, label %after_for159, label %for_loop_body157.preheader510

for_loop_body157.preheader510:                    ; preds = %for_loop_body157.prol.loopexit
  br label %for_loop_body157

for_loop_body157:                                 ; preds = %for_loop_body157, %for_loop_body157.preheader510
  %indvars.iv368 = phi i64 [ %indvars.iv.next369.3, %for_loop_body157 ], [ %indvars.iv368.unr, %for_loop_body157.preheader510 ]
  %.2325 = phi double [ %2711, %for_loop_body157 ], [ %.2325.unr, %for_loop_body157.preheader510 ]
  %.281324 = phi double [ %2709, %for_loop_body157 ], [ %.281324.unr, %for_loop_body157.preheader510 ]
  %.285323 = phi double [ %2707, %for_loop_body157 ], [ %.285323.unr, %for_loop_body157.preheader510 ]
  %2427 = atomicrmw add ptr %1531, i64 1 seq_cst, align 8
  %2428 = load ptr, ptr %1548, align 8
  %2429 = shl i64 %indvars.iv368, 2
  %uglygep538 = getelementptr i8, ptr %2428, i64 %2429
  %2430 = load i32, ptr %uglygep538, align 4
  %2431 = load ptr, ptr %1544, align 8
  %2432 = load i32, ptr %1545, align 4
  %2433 = sext i32 %2432 to i64
  %2434 = sext i32 %2430 to i64
  %2435 = getelementptr i32, ptr %2431, i64 %2434
  %2436 = load i32, ptr %2435, align 4
  %2437 = add nsw i64 %2433, %2434
  %2438 = getelementptr i32, ptr %2431, i64 %2437
  %2439 = load i32, ptr %2438, align 4
  %2440 = load ptr, ptr %1539, align 8
  %2441 = load i32, ptr %1540, align 4
  %2442 = sext i32 %2441 to i64
  %2443 = sext i32 %2439 to i64
  %2444 = getelementptr double, ptr %2440, i64 %2443
  %2445 = load double, ptr %2444, align 8
  %2446 = sext i32 %2436 to i64
  %2447 = getelementptr double, ptr %2440, i64 %2446
  %2448 = load double, ptr %2447, align 8
  %2449 = fsub double %2445, %2448
  %2450 = add nsw i64 %2442, %2443
  %2451 = getelementptr double, ptr %2440, i64 %2450
  %2452 = load double, ptr %2451, align 8
  %2453 = add nsw i64 %2442, %2446
  %2454 = getelementptr double, ptr %2440, i64 %2453
  %2455 = load double, ptr %2454, align 8
  %2456 = fsub double %2452, %2455
  %2457 = shl nsw i64 %2442, 1
  %2458 = add nsw i64 %2457, %2443
  %2459 = getelementptr double, ptr %2440, i64 %2458
  %2460 = load double, ptr %2459, align 8
  %2461 = add nsw i64 %2457, %2446
  %2462 = getelementptr double, ptr %2440, i64 %2461
  %2463 = load double, ptr %2462, align 8
  %2464 = fsub double %2460, %2463
  %2465 = mul nsw i64 %2442, 7
  %2466 = add nsw i64 %2465, %2446
  %2467 = getelementptr double, ptr %2440, i64 %2466
  %2468 = load double, ptr %2467, align 8
  %2469 = add nsw i64 %2465, %2443
  %2470 = getelementptr double, ptr %2440, i64 %2469
  %2471 = load double, ptr %2470, align 8
  %2472 = fmul double %2449, %2449
  %2473 = fmul double %2456, %2456
  %2474 = fadd double %2472, %2473
  %2475 = fmul double %2464, %2464
  %2476 = fadd double %2474, %2475
  %2477 = fcmp ogt double %2476, 0.000000e+00
  %.0.i123 = select i1 %2477, double 1.000000e+00, double 0.000000e+00
  %2478 = fsub double 1.000000e+00, %.0.i123
  %2479 = fadd double %2476, %2478
  %sqrt161 = tail call double @llvm.sqrt.f64(double %2479)
  %2480 = fdiv double 1.000000e+00, %sqrt161
  %2481 = fmul double %2479, %2480
  %2482 = fadd double %2468, %2471
  %2483 = fsub double %2482, %2481
  %2484 = tail call double @llvm.maxnum.f64(double %2483, double 0.000000e+00)
  %2485 = load ptr, ptr %9, align 8
  %2486 = getelementptr inbounds %struct.LLVMRuntime, ptr %2485, i64 0, i32 16
  %2487 = load ptr, ptr %2486, align 8
  %2488 = getelementptr inbounds i8, ptr %2487, i64 16
  %2489 = load double, ptr %2488, align 8
  %2490 = fmul double %.0.i123, %2480
  %2491 = fneg double %2489
  %2492 = fmul double %2484, %2491
  %neg162 = fmul double %2490, %2492
  %2493 = fmul double %2449, %neg162
  %2494 = fsub double %.285323, %2493
  %2495 = fmul double %2456, %neg162
  %2496 = fsub double %.281324, %2495
  %2497 = fmul double %2464, %neg162
  %2498 = fsub double %.2325, %2497
  %2499 = atomicrmw add ptr %1531, i64 1 seq_cst, align 8
  %2500 = load ptr, ptr %1548, align 8
  %uglygep539 = getelementptr i8, ptr %2500, i64 4
  %uglygep540 = getelementptr i8, ptr %uglygep539, i64 %2429
  %2501 = load i32, ptr %uglygep540, align 4
  %2502 = load ptr, ptr %1544, align 8
  %2503 = load i32, ptr %1545, align 4
  %2504 = sext i32 %2503 to i64
  %2505 = sext i32 %2501 to i64
  %2506 = getelementptr i32, ptr %2502, i64 %2505
  %2507 = load i32, ptr %2506, align 4
  %2508 = add nsw i64 %2504, %2505
  %2509 = getelementptr i32, ptr %2502, i64 %2508
  %2510 = load i32, ptr %2509, align 4
  %2511 = load ptr, ptr %1539, align 8
  %2512 = load i32, ptr %1540, align 4
  %2513 = sext i32 %2512 to i64
  %2514 = sext i32 %2510 to i64
  %2515 = getelementptr double, ptr %2511, i64 %2514
  %2516 = load double, ptr %2515, align 8
  %2517 = sext i32 %2507 to i64
  %2518 = getelementptr double, ptr %2511, i64 %2517
  %2519 = load double, ptr %2518, align 8
  %2520 = fsub double %2516, %2519
  %2521 = add nsw i64 %2513, %2514
  %2522 = getelementptr double, ptr %2511, i64 %2521
  %2523 = load double, ptr %2522, align 8
  %2524 = add nsw i64 %2513, %2517
  %2525 = getelementptr double, ptr %2511, i64 %2524
  %2526 = load double, ptr %2525, align 8
  %2527 = fsub double %2523, %2526
  %2528 = shl nsw i64 %2513, 1
  %2529 = add nsw i64 %2528, %2514
  %2530 = getelementptr double, ptr %2511, i64 %2529
  %2531 = load double, ptr %2530, align 8
  %2532 = add nsw i64 %2528, %2517
  %2533 = getelementptr double, ptr %2511, i64 %2532
  %2534 = load double, ptr %2533, align 8
  %2535 = fsub double %2531, %2534
  %2536 = mul nsw i64 %2513, 7
  %2537 = add nsw i64 %2536, %2517
  %2538 = getelementptr double, ptr %2511, i64 %2537
  %2539 = load double, ptr %2538, align 8
  %2540 = add nsw i64 %2536, %2514
  %2541 = getelementptr double, ptr %2511, i64 %2540
  %2542 = load double, ptr %2541, align 8
  %2543 = fmul double %2520, %2520
  %2544 = fmul double %2527, %2527
  %2545 = fadd double %2543, %2544
  %2546 = fmul double %2535, %2535
  %2547 = fadd double %2545, %2546
  %2548 = fcmp ogt double %2547, 0.000000e+00
  %.0.i123.1 = select i1 %2548, double 1.000000e+00, double 0.000000e+00
  %2549 = fsub double 1.000000e+00, %.0.i123.1
  %2550 = fadd double %2547, %2549
  %sqrt161.1 = tail call double @llvm.sqrt.f64(double %2550)
  %2551 = fdiv double 1.000000e+00, %sqrt161.1
  %2552 = fmul double %2550, %2551
  %2553 = fadd double %2539, %2542
  %2554 = fsub double %2553, %2552
  %2555 = tail call double @llvm.maxnum.f64(double %2554, double 0.000000e+00)
  %2556 = load ptr, ptr %9, align 8
  %2557 = getelementptr inbounds %struct.LLVMRuntime, ptr %2556, i64 0, i32 16
  %2558 = load ptr, ptr %2557, align 8
  %2559 = getelementptr inbounds i8, ptr %2558, i64 16
  %2560 = load double, ptr %2559, align 8
  %2561 = fmul double %.0.i123.1, %2551
  %2562 = fneg double %2560
  %2563 = fmul double %2555, %2562
  %neg162.1 = fmul double %2561, %2563
  %2564 = fmul double %2520, %neg162.1
  %2565 = fsub double %2494, %2564
  %2566 = fmul double %2527, %neg162.1
  %2567 = fsub double %2496, %2566
  %2568 = fmul double %2535, %neg162.1
  %2569 = fsub double %2498, %2568
  %2570 = atomicrmw add ptr %1531, i64 1 seq_cst, align 8
  %2571 = load ptr, ptr %1548, align 8
  %uglygep536 = getelementptr i8, ptr %2571, i64 8
  %uglygep537 = getelementptr i8, ptr %uglygep536, i64 %2429
  %2572 = load i32, ptr %uglygep537, align 4
  %2573 = load ptr, ptr %1544, align 8
  %2574 = load i32, ptr %1545, align 4
  %2575 = sext i32 %2574 to i64
  %2576 = sext i32 %2572 to i64
  %2577 = getelementptr i32, ptr %2573, i64 %2576
  %2578 = load i32, ptr %2577, align 4
  %2579 = add nsw i64 %2575, %2576
  %2580 = getelementptr i32, ptr %2573, i64 %2579
  %2581 = load i32, ptr %2580, align 4
  %2582 = load ptr, ptr %1539, align 8
  %2583 = load i32, ptr %1540, align 4
  %2584 = sext i32 %2583 to i64
  %2585 = sext i32 %2581 to i64
  %2586 = getelementptr double, ptr %2582, i64 %2585
  %2587 = load double, ptr %2586, align 8
  %2588 = sext i32 %2578 to i64
  %2589 = getelementptr double, ptr %2582, i64 %2588
  %2590 = load double, ptr %2589, align 8
  %2591 = fsub double %2587, %2590
  %2592 = add nsw i64 %2584, %2585
  %2593 = getelementptr double, ptr %2582, i64 %2592
  %2594 = load double, ptr %2593, align 8
  %2595 = add nsw i64 %2584, %2588
  %2596 = getelementptr double, ptr %2582, i64 %2595
  %2597 = load double, ptr %2596, align 8
  %2598 = fsub double %2594, %2597
  %2599 = shl nsw i64 %2584, 1
  %2600 = add nsw i64 %2599, %2585
  %2601 = getelementptr double, ptr %2582, i64 %2600
  %2602 = load double, ptr %2601, align 8
  %2603 = add nsw i64 %2599, %2588
  %2604 = getelementptr double, ptr %2582, i64 %2603
  %2605 = load double, ptr %2604, align 8
  %2606 = fsub double %2602, %2605
  %2607 = mul nsw i64 %2584, 7
  %2608 = add nsw i64 %2607, %2588
  %2609 = getelementptr double, ptr %2582, i64 %2608
  %2610 = load double, ptr %2609, align 8
  %2611 = add nsw i64 %2607, %2585
  %2612 = getelementptr double, ptr %2582, i64 %2611
  %2613 = load double, ptr %2612, align 8
  %2614 = fmul double %2591, %2591
  %2615 = fmul double %2598, %2598
  %2616 = fadd double %2614, %2615
  %2617 = fmul double %2606, %2606
  %2618 = fadd double %2616, %2617
  %2619 = fcmp ogt double %2618, 0.000000e+00
  %.0.i123.2 = select i1 %2619, double 1.000000e+00, double 0.000000e+00
  %2620 = fsub double 1.000000e+00, %.0.i123.2
  %2621 = fadd double %2618, %2620
  %sqrt161.2 = tail call double @llvm.sqrt.f64(double %2621)
  %2622 = fdiv double 1.000000e+00, %sqrt161.2
  %2623 = fmul double %2621, %2622
  %2624 = fadd double %2610, %2613
  %2625 = fsub double %2624, %2623
  %2626 = tail call double @llvm.maxnum.f64(double %2625, double 0.000000e+00)
  %2627 = load ptr, ptr %9, align 8
  %2628 = getelementptr inbounds %struct.LLVMRuntime, ptr %2627, i64 0, i32 16
  %2629 = load ptr, ptr %2628, align 8
  %2630 = getelementptr inbounds i8, ptr %2629, i64 16
  %2631 = load double, ptr %2630, align 8
  %2632 = fmul double %.0.i123.2, %2622
  %2633 = fneg double %2631
  %2634 = fmul double %2626, %2633
  %neg162.2 = fmul double %2632, %2634
  %2635 = fmul double %2591, %neg162.2
  %2636 = fsub double %2565, %2635
  %2637 = fmul double %2598, %neg162.2
  %2638 = fsub double %2567, %2637
  %2639 = fmul double %2606, %neg162.2
  %2640 = fsub double %2569, %2639
  %2641 = atomicrmw add ptr %1531, i64 1 seq_cst, align 8
  %2642 = load ptr, ptr %1548, align 8
  %uglygep534 = getelementptr i8, ptr %2642, i64 12
  %uglygep535 = getelementptr i8, ptr %uglygep534, i64 %2429
  %2643 = load i32, ptr %uglygep535, align 4
  %2644 = load ptr, ptr %1544, align 8
  %2645 = load i32, ptr %1545, align 4
  %2646 = sext i32 %2645 to i64
  %2647 = sext i32 %2643 to i64
  %2648 = getelementptr i32, ptr %2644, i64 %2647
  %2649 = load i32, ptr %2648, align 4
  %2650 = add nsw i64 %2646, %2647
  %2651 = getelementptr i32, ptr %2644, i64 %2650
  %2652 = load i32, ptr %2651, align 4
  %2653 = load ptr, ptr %1539, align 8
  %2654 = load i32, ptr %1540, align 4
  %2655 = sext i32 %2654 to i64
  %2656 = sext i32 %2652 to i64
  %2657 = getelementptr double, ptr %2653, i64 %2656
  %2658 = load double, ptr %2657, align 8
  %2659 = sext i32 %2649 to i64
  %2660 = getelementptr double, ptr %2653, i64 %2659
  %2661 = load double, ptr %2660, align 8
  %2662 = fsub double %2658, %2661
  %2663 = add nsw i64 %2655, %2656
  %2664 = getelementptr double, ptr %2653, i64 %2663
  %2665 = load double, ptr %2664, align 8
  %2666 = add nsw i64 %2655, %2659
  %2667 = getelementptr double, ptr %2653, i64 %2666
  %2668 = load double, ptr %2667, align 8
  %2669 = fsub double %2665, %2668
  %2670 = shl nsw i64 %2655, 1
  %2671 = add nsw i64 %2670, %2656
  %2672 = getelementptr double, ptr %2653, i64 %2671
  %2673 = load double, ptr %2672, align 8
  %2674 = add nsw i64 %2670, %2659
  %2675 = getelementptr double, ptr %2653, i64 %2674
  %2676 = load double, ptr %2675, align 8
  %2677 = fsub double %2673, %2676
  %2678 = mul nsw i64 %2655, 7
  %2679 = add nsw i64 %2678, %2659
  %2680 = getelementptr double, ptr %2653, i64 %2679
  %2681 = load double, ptr %2680, align 8
  %2682 = add nsw i64 %2678, %2656
  %2683 = getelementptr double, ptr %2653, i64 %2682
  %2684 = load double, ptr %2683, align 8
  %2685 = fmul double %2662, %2662
  %2686 = fmul double %2669, %2669
  %2687 = fadd double %2685, %2686
  %2688 = fmul double %2677, %2677
  %2689 = fadd double %2687, %2688
  %2690 = fcmp ogt double %2689, 0.000000e+00
  %.0.i123.3 = select i1 %2690, double 1.000000e+00, double 0.000000e+00
  %2691 = fsub double 1.000000e+00, %.0.i123.3
  %2692 = fadd double %2689, %2691
  %sqrt161.3 = tail call double @llvm.sqrt.f64(double %2692)
  %2693 = fdiv double 1.000000e+00, %sqrt161.3
  %2694 = fmul double %2692, %2693
  %2695 = fadd double %2681, %2684
  %2696 = fsub double %2695, %2694
  %2697 = tail call double @llvm.maxnum.f64(double %2696, double 0.000000e+00)
  %2698 = load ptr, ptr %9, align 8
  %2699 = getelementptr inbounds %struct.LLVMRuntime, ptr %2698, i64 0, i32 16
  %2700 = load ptr, ptr %2699, align 8
  %2701 = getelementptr inbounds i8, ptr %2700, i64 16
  %2702 = load double, ptr %2701, align 8
  %2703 = fmul double %.0.i123.3, %2693
  %2704 = fneg double %2702
  %2705 = fmul double %2697, %2704
  %neg162.3 = fmul double %2703, %2705
  %2706 = fmul double %2662, %neg162.3
  %2707 = fsub double %2636, %2706
  %2708 = fmul double %2669, %neg162.3
  %2709 = fsub double %2638, %2708
  %2710 = fmul double %2677, %neg162.3
  %2711 = fsub double %2640, %2710
  %indvars.iv.next369.3 = add nsw i64 %indvars.iv368, 4
  %exitcond372.not.3 = icmp eq i64 %wide.trip.count371, %indvars.iv.next369.3
  br i1 %exitcond372.not.3, label %after_for159.loopexit, label %for_loop_body157

after_for159.loopexit:                            ; preds = %for_loop_body157
  br label %after_for159

after_for159:                                     ; preds = %after_for159.loopexit, %for_loop_body157.prol.loopexit, %after_for154
  %.285.lcssa = phi double [ %.184.lcssa, %after_for154 ], [ %.lcssa445.unr, %for_loop_body157.prol.loopexit ], [ %2707, %after_for159.loopexit ]
  %.281.lcssa = phi double [ %.180.lcssa, %after_for154 ], [ %.lcssa444.unr, %for_loop_body157.prol.loopexit ], [ %2709, %after_for159.loopexit ]
  %.2.lcssa = phi double [ %.1.lcssa, %after_for154 ], [ %.lcssa443.unr, %for_loop_body157.prol.loopexit ], [ %2711, %after_for159.loopexit ]
  %2712 = bitcast double %.285.lcssa to i64
  %2713 = and i64 %2712, 9223372036854775807
  %2714 = and i64 %2712, 9218868437227405312
  %2715 = icmp eq i64 %2713, 0
  %2716 = icmp ne i64 %2714, 0
  %2717 = icmp ne i64 %2714, 9218868437227405312
  %2718 = and i1 %2716, %2717
  %2719 = or i1 %2715, %2718
  br i1 %2719, label %after_if168, label %true_block166

true_block166:                                    ; preds = %after_for159
  %2720 = load ptr, ptr %105, align 8
  %2721 = atomicrmw add ptr %2720, i64 1 seq_cst, align 8
  br label %after_if168

after_if168:                                      ; preds = %true_block166, %after_for159
  %2722 = load ptr, ptr %1539, align 8
  %2723 = load i32, ptr %1540, align 4
  %2724 = sext i32 %2723 to i64
  %2725 = shl nsw i64 %2724, 3
  %2726 = add nsw i64 %2725, %1561
  %2727 = getelementptr double, ptr %2722, i64 %2726
  %2728 = load double, ptr %2727, align 8
  %2729 = fcmp one double %.285.lcssa, %2728
  %2730 = bitcast double %.281.lcssa to i64
  %2731 = and i64 %2730, 9223372036854775807
  %2732 = and i64 %2730, 9218868437227405312
  %2733 = icmp eq i64 %2731, 0
  %2734 = icmp ne i64 %2732, 0
  %2735 = icmp ne i64 %2732, 9218868437227405312
  %2736 = and i1 %2734, %2735
  %2737 = or i1 %2733, %2736
  br i1 %2737, label %after_if171, label %true_block169

true_block169:                                    ; preds = %after_if168
  %2738 = load ptr, ptr %105, align 8
  %2739 = atomicrmw add ptr %2738, i64 1 seq_cst, align 8
  %.pre379 = load ptr, ptr %1539, align 8
  %.pre380 = load i32, ptr %1540, align 4
  %.pre383 = sext i32 %.pre380 to i64
  br label %after_if171

after_if171:                                      ; preds = %true_block169, %after_if168
  %.pre-phi = phi i64 [ %2724, %after_if168 ], [ %.pre383, %true_block169 ]
  %2740 = phi ptr [ %2722, %after_if168 ], [ %.pre379, %true_block169 ]
  %2741 = mul nsw i64 %.pre-phi, 9
  %2742 = add nsw i64 %2741, %1561
  %2743 = getelementptr double, ptr %2740, i64 %2742
  %2744 = load double, ptr %2743, align 8
  %2745 = fcmp one double %.281.lcssa, %2744
  %2746 = or i1 %2729, %2745
  %2747 = bitcast double %.2.lcssa to i64
  %2748 = and i64 %2747, 9223372036854775807
  %2749 = and i64 %2747, 9218868437227405312
  %2750 = icmp eq i64 %2748, 0
  %2751 = icmp ne i64 %2749, 0
  %2752 = icmp ne i64 %2749, 9218868437227405312
  %2753 = and i1 %2751, %2752
  %2754 = or i1 %2750, %2753
  br i1 %2754, label %after_if174, label %true_block172

true_block172:                                    ; preds = %after_if171
  %2755 = load ptr, ptr %105, align 8
  %2756 = atomicrmw add ptr %2755, i64 1 seq_cst, align 8
  %.pre381 = load ptr, ptr %1539, align 8
  %.pre382 = load i32, ptr %1540, align 4
  %.pre384 = sext i32 %.pre382 to i64
  br label %after_if174

after_if174:                                      ; preds = %true_block172, %after_if171
  %.pre-phi385 = phi i64 [ %.pre-phi, %after_if171 ], [ %.pre384, %true_block172 ]
  %2757 = phi ptr [ %2740, %after_if171 ], [ %.pre381, %true_block172 ]
  %2758 = mul nsw i64 %.pre-phi385, 10
  %2759 = add nsw i64 %2758, %1561
  %2760 = getelementptr double, ptr %2757, i64 %2759
  %2761 = load double, ptr %2760, align 8
  %2762 = fcmp one double %.2.lcssa, %2761
  %2763 = or i1 %2746, %2762
  %2764 = xor i1 %1673, true
  %2765 = and i1 %2763, %2764
  br i1 %2765, label %true_block175, label %after_if177

true_block175:                                    ; preds = %after_if174
  %2766 = load ptr, ptr %105, align 8
  %2767 = getelementptr i64, ptr %2766, i64 7
  %2768 = atomicrmw add ptr %2767, i64 1 seq_cst, align 8
  br label %after_if177

after_if177:                                      ; preds = %true_block175, %after_if174
  %2769 = or i1 %1673, %2763
  br i1 %2769, label %true_block178, label %after_if180

true_block178:                                    ; preds = %after_if177
  %2770 = sdiv i32 %1554, 32
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %6)
  %2771 = shl nsw i32 %2770, 3
  %2772 = sext i32 %2771 to i64
  %2773 = getelementptr i8, ptr %43, i64 %2772
  store volatile ptr %2773, ptr %6, align 8
  %2774 = getelementptr inbounds i8, ptr %2773, i64 32
  %2775 = load volatile ptr, ptr %2774, align 8
  %2776 = icmp eq ptr %2775, null
  br i1 %2776, label %2777, label %Pointer_activate.exit

2777:                                             ; preds = %true_block178
  %.0..0..0..0..0..i = load volatile ptr, ptr %6, align 8
  %.0..0..0..0..0.2.i = load volatile ptr, ptr %6, align 8
  br label %2778

2778:                                             ; preds = %2778, %2777
  %2779 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i, i32 1 seq_cst, align 4
  %2780 = icmp eq i32 %2779, 1
  br i1 %2780, label %2778, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i:                        ; preds = %2778
  %2781 = load volatile ptr, ptr %2774, align 8
  %2782 = icmp eq ptr %2781, null
  br i1 %2782, label %2783, label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i"

2783:                                             ; preds = %mutex_lock_i32.exit.i.i.i
  %2784 = load ptr, ptr %9, align 8
  %2785 = getelementptr inbounds %struct.LLVMRuntime, ptr %2784, i64 0, i32 14
  %2786 = load ptr, ptr %2785, align 8
  %2787 = getelementptr inbounds ptr, ptr %2786, i64 17
  %2788 = load ptr, ptr %2787, align 8
  %2789 = getelementptr inbounds %struct.NodeManager, ptr %2788, i64 0, i32 4
  %2790 = atomicrmw volatile add ptr %2789, i32 1 seq_cst, align 4
  %2791 = getelementptr inbounds %struct.NodeManager, ptr %2788, i64 0, i32 5
  %2792 = load ptr, ptr %2791, align 8
  %2793 = getelementptr inbounds %struct.ListManager, ptr %2792, i64 0, i32 5
  %2794 = load i32, ptr %2793, align 8
  %.not.i.i.i.i.i = icmp slt i32 %2790, %2794
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i, label %2795

2795:                                             ; preds = %2783
  %2796 = getelementptr inbounds %struct.NodeManager, ptr %2788, i64 0, i32 7
  %2797 = load ptr, ptr %2796, align 8
  %2798 = getelementptr inbounds %struct.ListManager, ptr %2797, i64 0, i32 5
  %2799 = atomicrmw volatile add ptr %2798, i32 1 seq_cst, align 4
  %2800 = getelementptr inbounds %struct.ListManager, ptr %2797, i64 0, i32 3
  %2801 = load i32, ptr %2800, align 8
  %2802 = ashr i32 %2799, %2801
  %2803 = icmp ugt i32 %2802, 131071
  br i1 %2803, label %2804, label %2807

2804:                                             ; preds = %2795
  %2805 = getelementptr inbounds %struct.ListManager, ptr %2797, i64 0, i32 6
  %2806 = load ptr, ptr %2805, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %2806, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

2807:                                             ; preds = %2795
  %2808 = zext i32 %2802 to i64
  %2809 = lshr i64 %2808, 9
  %2810 = getelementptr inbounds [256 x ptr], ptr %2797, i64 0, i64 %2809
  %2811 = load atomic i64, ptr %2810 acquire, align 8
  %.not.i.i.i4.i.i.i.i.i = icmp eq i64 %2811, 0
  br i1 %.not.i.i.i4.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i:  ; preds = %2807
  %2812 = inttoptr i64 %2811 to ptr
  %2813 = and i64 %2808, 511
  %2814 = getelementptr inbounds ptr, ptr %2812, i64 %2813
  %2815 = load atomic i64, ptr %2814 acquire, align 8
  %.not.i.i5.i.i.i.i.i = icmp eq i64 %2815, 0
  br i1 %.not.i.i5.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i, %2807
  %2816 = getelementptr inbounds %struct.ListManager, ptr %2797, i64 0, i32 4
  br label %2817

2817:                                             ; preds = %2817, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i
  %2818 = atomicrmw volatile xchg ptr %2816, i32 1 seq_cst, align 4
  %2819 = icmp eq i32 %2818, 1
  br i1 %2819, label %2817, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i:          ; preds = %2817
  %2820 = load atomic i64, ptr %2810 acquire, align 8
  %2821 = inttoptr i64 %2820 to ptr
  %.not.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %2820, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i, label %2822, label %2857

2822:                                             ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i
  %2823 = getelementptr inbounds %struct.ListManager, ptr %2797, i64 0, i32 6
  %2824 = load ptr, ptr %2823, align 8
  %2825 = getelementptr inbounds %struct.LLVMRuntime, ptr %2824, i64 0, i32 1
  %2826 = getelementptr inbounds %struct.LLVMRuntime, ptr %2824, i64 0, i32 28
  %2827 = atomicrmw volatile add ptr %2826, i64 4096 seq_cst, align 8
  %2828 = getelementptr inbounds %struct.LLVMRuntime, ptr %2824, i64 0, i32 1, i32 2
  %2829 = load i64, ptr %2828, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %2829, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i.i.i, label %2850, label %2830

2830:                                             ; preds = %2822
  %2831 = getelementptr inbounds %struct.LLVMRuntime, ptr %2824, i64 0, i32 26
  br label %2832

2832:                                             ; preds = %2832, %2830
  %2833 = atomicrmw volatile xchg ptr %2831, i32 1 seq_cst, align 4
  %2834 = icmp eq i32 %2833, 1
  br i1 %2834, label %2832, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i: ; preds = %2832
  %2835 = load ptr, ptr %2825, align 8
  %2836 = ptrtoint ptr %2835 to i64
  %2837 = getelementptr inbounds %struct.LLVMRuntime, ptr %2824, i64 0, i32 1, i32 1
  %2838 = load ptr, ptr %2837, align 8
  %2839 = ptrtoint ptr %2838 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %2836
  %2840 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i, 4095
  %2841 = or i64 %2840, 4096
  %2842 = add i64 %2841, %2836
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %2842, %2839
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i, label %2843

2843:                                             ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i
  %2844 = add i64 %2840, %2836
  %2845 = inttoptr i64 %2844 to ptr
  %2846 = getelementptr i8, ptr %2835, i64 %2840
  %2847 = getelementptr inbounds i8, ptr %2846, i64 4096
  store ptr %2847, ptr %2825, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i: ; preds = %2843, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i ], [ %2845, %2843 ]
  %2848 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i, true
  %2849 = atomicrmw volatile xchg ptr %2831, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %2824, i1 noundef zeroext %2848, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i

2850:                                             ; preds = %2822
  %2851 = getelementptr inbounds %struct.LLVMRuntime, ptr %2824, i64 0, i32 2
  %2852 = load ptr, ptr %2851, align 8
  %2853 = getelementptr inbounds %struct.LLVMRuntime, ptr %2824, i64 0, i32 6
  %2854 = load ptr, ptr %2853, align 8
  %2855 = tail call noundef ptr %2852(ptr noundef %2854, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i: ; preds = %2850, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i ], [ %2855, %2850 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %2856 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %2856, ptr %2810 release, align 8
  br label %2857

2857:                                             ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %2821, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i ]
  %2858 = and i32 %2802, 511
  %2859 = zext i32 %2858 to i64
  %2860 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i.i.i, i64 %2859
  %2861 = load atomic i64, ptr %2860 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %2861, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i.i.i, label %2862, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i"

2862:                                             ; preds = %2857
  %2863 = getelementptr inbounds %struct.ListManager, ptr %2797, i64 0, i32 6
  %2864 = load ptr, ptr %2863, align 8
  %2865 = getelementptr inbounds %struct.LLVMRuntime, ptr %2864, i64 0, i32 1
  %2866 = getelementptr inbounds %struct.ListManager, ptr %2797, i64 0, i32 2
  %2867 = load i64, ptr %2866, align 8
  %2868 = getelementptr inbounds %struct.ListManager, ptr %2797, i64 0, i32 1
  %2869 = load i64, ptr %2868, align 8
  %2870 = mul i64 %2869, %2867
  %2871 = getelementptr inbounds %struct.LLVMRuntime, ptr %2864, i64 0, i32 28
  %2872 = atomicrmw volatile add ptr %2871, i64 %2870 seq_cst, align 8
  %2873 = getelementptr inbounds %struct.LLVMRuntime, ptr %2864, i64 0, i32 1, i32 2
  %2874 = load i64, ptr %2873, align 8
  %.not.i.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %2874, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i, label %2894, label %2875

2875:                                             ; preds = %2862
  %2876 = getelementptr inbounds %struct.LLVMRuntime, ptr %2864, i64 0, i32 26
  br label %2877

2877:                                             ; preds = %2877, %2875
  %2878 = atomicrmw volatile xchg ptr %2876, i32 1 seq_cst, align 4
  %2879 = icmp eq i32 %2878, 1
  br i1 %2879, label %2877, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i: ; preds = %2877
  %2880 = load ptr, ptr %2865, align 8
  %2881 = ptrtoint ptr %2880 to i64
  %2882 = getelementptr inbounds %struct.LLVMRuntime, ptr %2864, i64 0, i32 1, i32 1
  %2883 = load ptr, ptr %2882, align 8
  %2884 = ptrtoint ptr %2883 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %2881
  %2885 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i, 4095
  %2886 = add i64 %2885, %2870
  %2887 = add i64 %2886, %2881
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %2887, %2884
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i, label %2888

2888:                                             ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %2889 = add i64 %2885, %2881
  %2890 = inttoptr i64 %2889 to ptr
  %2891 = getelementptr inbounds i8, ptr %2880, i64 %2886
  store ptr %2891, ptr %2865, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i: ; preds = %2888, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %2890, %2888 ]
  %2892 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %2893 = atomicrmw volatile xchg ptr %2876, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %2864, i1 noundef zeroext %2892, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i

2894:                                             ; preds = %2862
  %2895 = getelementptr inbounds %struct.LLVMRuntime, ptr %2864, i64 0, i32 2
  %2896 = load ptr, ptr %2895, align 8
  %2897 = getelementptr inbounds %struct.LLVMRuntime, ptr %2864, i64 0, i32 6
  %2898 = load ptr, ptr %2897, align 8
  %2899 = tail call noundef ptr %2896(ptr noundef %2898, i64 noundef %2870, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i: ; preds = %2894, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i ], [ %2899, %2894 ]
  %2900 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %2900, ptr %2860 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i, %2857
  %2901 = atomicrmw volatile xchg ptr %2816, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i:      ; preds = %2783
  %2902 = getelementptr inbounds %struct.ListManager, ptr %2792, i64 0, i32 3
  %2903 = load i32, ptr %2902, align 8
  %2904 = ashr i32 %2790, %2903
  %2905 = sext i32 %2904 to i64
  %2906 = lshr i64 %2905, 9
  %2907 = getelementptr inbounds [256 x ptr], ptr %2792, i64 0, i64 %2906
  %2908 = load atomic i64, ptr %2907 acquire, align 8
  %.not.i.i.i.i.i.i.i.i = icmp ne i64 %2908, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i.i.i.i.i)
  %2909 = inttoptr i64 %2908 to ptr
  %2910 = and i64 %2905, 511
  %2911 = getelementptr inbounds ptr, ptr %2909, i64 %2910
  %2912 = load atomic i64, ptr %2911 acquire, align 8
  %2913 = inttoptr i64 %2912 to ptr
  %2914 = getelementptr inbounds %struct.ListManager, ptr %2792, i64 0, i32 1
  %2915 = load i64, ptr %2914, align 8
  %2916 = load i32, ptr %2902, align 8
  %notmask.i.i.i.i.i.i.i = shl nsw i32 -1, %2916
  %2917 = xor i32 %notmask.i.i.i.i.i.i.i, -1
  %2918 = and i32 %2790, %2917
  %2919 = sext i32 %2918 to i64
  %2920 = mul i64 %2915, %2919
  %2921 = getelementptr inbounds i8, ptr %2913, i64 %2920
  %2922 = load i32, ptr %2921, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i: ; preds = %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i, %2804
  %.0.i.i.i.i.i = phi i32 [ %2922, %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i ], [ %2799, %2804 ], [ %2799, %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i ], [ %2799, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i" ]
  %2923 = getelementptr inbounds %struct.NodeManager, ptr %2788, i64 0, i32 7
  %2924 = load ptr, ptr %2923, align 8
  %2925 = getelementptr inbounds %struct.ListManager, ptr %2924, i64 0, i32 3
  %2926 = load i32, ptr %2925, align 8
  %2927 = ashr i32 %.0.i.i.i.i.i, %2926
  %2928 = sext i32 %2927 to i64
  %2929 = lshr i64 %2928, 9
  %2930 = getelementptr inbounds [256 x ptr], ptr %2924, i64 0, i64 %2929
  %2931 = load atomic i64, ptr %2930 acquire, align 8
  %.not.i.i.i.i.i.i.i = icmp eq i64 %2931, 0
  br i1 %.not.i.i.i.i.i.i.i, label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i", label %2932

2932:                                             ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i
  %2933 = inttoptr i64 %2931 to ptr
  %2934 = and i64 %2928, 511
  %2935 = getelementptr inbounds ptr, ptr %2933, i64 %2934
  %2936 = load atomic i64, ptr %2935 acquire, align 8
  %2937 = inttoptr i64 %2936 to ptr
  br label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i"

"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i":    ; preds = %2932, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i
  %2938 = phi ptr [ %2937, %2932 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i ]
  %2939 = getelementptr inbounds %struct.ListManager, ptr %2924, i64 0, i32 1
  %2940 = load i64, ptr %2939, align 8
  %2941 = load i32, ptr %2925, align 8
  %notmask.i.i.i.i.i.i = shl nsw i32 -1, %2941
  %2942 = xor i32 %notmask.i.i.i.i.i.i, -1
  %2943 = and i32 %.0.i.i.i.i.i, %2942
  %2944 = sext i32 %2943 to i64
  %2945 = mul i64 %2940, %2944
  %2946 = getelementptr inbounds i8, ptr %2938, i64 %2945
  %2947 = ptrtoint ptr %2946 to i64
  %2948 = atomicrmw volatile xchg ptr %2774, i64 %2947 seq_cst, align 8
  br label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i"

"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i": ; preds = %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i", %mutex_lock_i32.exit.i.i.i
  %2949 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i, i32 0 seq_cst, align 4
  br label %Pointer_activate.exit

Pointer_activate.exit:                            ; preds = %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i", %true_block178
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %6)
  %2950 = lshr i32 %1554, 2
  %2951 = and i32 %2950, 1073741816
  %2952 = zext i32 %2951 to i64
  %2953 = getelementptr i8, ptr %43, i64 %2952
  %2954 = getelementptr inbounds i8, ptr %2953, i64 32
  %2955 = load ptr, ptr %2954, align 8
  %2956 = icmp eq ptr %2955, null
  br i1 %2956, label %2957, label %Pointer_lookup_element.exit

2957:                                             ; preds = %Pointer_activate.exit
  %2958 = load ptr, ptr %9, align 8
  %2959 = getelementptr inbounds %struct.LLVMRuntime, ptr %2958, i64 0, i32 15
  %2960 = load ptr, ptr %2959, align 8
  %2961 = getelementptr inbounds ptr, ptr %2960, i64 17
  %2962 = load ptr, ptr %2961, align 8
  br label %Pointer_lookup_element.exit

Pointer_lookup_element.exit:                      ; preds = %2957, %Pointer_activate.exit
  %.0.i = phi ptr [ %2962, %2957 ], [ %2955, %Pointer_activate.exit ]
  %2963 = and i32 %1554, 31
  %2964 = getelementptr inbounds i8, ptr %.0.i, i64 32
  %2965 = shl nuw i32 1, %2963
  %2966 = atomicrmw volatile or ptr %2964, i32 %2965 seq_cst, align 4
  br label %after_if180

after_if180:                                      ; preds = %Pointer_lookup_element.exit, %after_if177
  %indvars.iv.next374 = add nuw nsw i64 %indvars.iv373, 1
  %exitcond377.not = icmp eq i64 %indvars.iv.next374, %wide.trip.count376
  br i1 %exitcond377.not, label %loop_body_tail.loopexit, label %for_loop_body83
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.sqrt.f64(double) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.maxnum.f64(double, double) #2

; Function Attrs: argmemonly mustprogress nofree norecurse nosync nounwind willreturn
define internal fastcc void @S20_refine_coordinates(ptr nocapture readonly %0, ptr nocapture writeonly %1, i32 %2) unnamed_addr #3 {
entry:
  %3 = and i32 %2, 3
  %4 = load i32, ptr %0, align 4
  %5 = shl i32 %4, 2
  %6 = or i32 %5, %3
  store i32 %6, ptr %1, align 4
  %7 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 1
  %8 = load i32, ptr %7, align 4
  %9 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 1
  store i32 %8, ptr %9, align 4
  %10 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 2
  %11 = load i32, ptr %10, align 4
  %12 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 2
  store i32 %11, ptr %12, align 4
  %13 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 3
  %14 = load i32, ptr %13, align 4
  %15 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 3
  store i32 %14, ptr %15, align 4
  %16 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 4
  %17 = load i32, ptr %16, align 4
  %18 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 4
  store i32 %17, ptr %18, align 4
  %19 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 5
  %20 = load i32, ptr %19, align 4
  %21 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 5
  store i32 %20, ptr %21, align 4
  %22 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 6
  %23 = load i32, ptr %22, align 4
  %24 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 6
  store i32 %23, ptr %24, align 4
  %25 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 7
  %26 = load i32, ptr %25, align 4
  %27 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 7
  store i32 %26, ptr %27, align 4
  %28 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 8
  %29 = load i32, ptr %28, align 4
  %30 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 8
  store i32 %29, ptr %30, align 4
  %31 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 9
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 9
  store i32 %32, ptr %33, align 4
  %34 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 10
  %35 = load i32, ptr %34, align 4
  %36 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 10
  store i32 %35, ptr %36, align 4
  %37 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 11
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 11
  store i32 %38, ptr %39, align 4
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #4

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn writeonly
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #5

; Function Attrs: noinline nounwind optnone uwtable
define internal fastcc void @taichi_assert_format(ptr noundef %0, i1 noundef zeroext %1, ptr noundef %2) unnamed_addr #6 {
  %4 = alloca ptr, align 8
  %5 = alloca i8, align 1
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca ptr, align 8
  %9 = alloca %class.anon, align 8
  store ptr %0, ptr %4, align 8
  %10 = zext i1 %1 to i8
  store i8 %10, ptr %5, align 1
  store ptr %2, ptr %6, align 8
  store i32 0, ptr %7, align 4
  store ptr null, ptr %8, align 8
  %11 = load i8, ptr %5, align 1
  %12 = trunc i8 %11 to i1
  %13 = zext i1 %12 to i32
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %15, label %16

15:                                               ; preds = %3
  br label %69

16:                                               ; preds = %3
  %17 = load ptr, ptr %4, align 8
  %18 = getelementptr inbounds %struct.LLVMRuntime, ptr %17, i32 0, i32 24
  %19 = load i64, ptr %18, align 8
  %20 = icmp ne i64 %19, 0
  br i1 %20, label %69, label %21

21:                                               ; preds = %16
  %22 = load ptr, ptr %4, align 8
  %23 = getelementptr inbounds %struct.LLVMRuntime, ptr %22, i32 0, i32 23
  %24 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 0
  store ptr %4, ptr %24, align 8
  %25 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 1
  store ptr %6, ptr %25, align 8
  %26 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 2
  store ptr %7, ptr %26, align 8
  %27 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 3
  store ptr %8, ptr %27, align 8
  br label %28

28:                                               ; preds = %28, %21
  %29 = atomicrmw volatile xchg ptr %23, i32 1 seq_cst, align 4
  %30 = icmp eq i32 %29, 1
  br i1 %30, label %28, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i:                        ; preds = %28
  %31 = load ptr, ptr %9, align 8
  %32 = load ptr, ptr %31, align 8
  %33 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 24
  %34 = load i64, ptr %33, align 8
  %.not.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i, label %35, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

35:                                               ; preds = %mutex_lock_i32.exit.i.i.i
  store i64 1, ptr %33, align 8
  %36 = load ptr, ptr %9, align 8
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr inbounds %struct.LLVMRuntime, ptr %37, i64 0, i32 21
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %38, i8 0, i64 2048, i1 false)
  %39 = load ptr, ptr %9, align 8
  %40 = load ptr, ptr %39, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 21
  %42 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 1
  %43 = load ptr, ptr %42, align 8
  %44 = load ptr, ptr %43, align 8
  %45 = load i8, ptr %44, align 1
  %.not5.i.i.i.i.i = icmp eq i8 %45, 0
  br i1 %.not5.i.i.i.i.i, label %taichi_strlen.exit.thread.i.i.i.i, label %.lr.ph.i.i.i.i.i.preheader

.lr.ph.i.i.i.i.i.preheader:                       ; preds = %35
  br label %.lr.ph.i.i.i.i.i

.lr.ph.i.i.i.i.i:                                 ; preds = %.lr.ph.i.i.i.i.i, %.lr.ph.i.i.i.i.i.preheader
  %.07.i.i.i.i.i = phi ptr [ %47, %.lr.ph.i.i.i.i.i ], [ %44, %.lr.ph.i.i.i.i.i.preheader ]
  %.046.i.i.i.i.i = phi i64 [ %46, %.lr.ph.i.i.i.i.i ], [ 0, %.lr.ph.i.i.i.i.i.preheader ]
  %46 = add i64 %.046.i.i.i.i.i, 1
  %47 = getelementptr inbounds i8, ptr %.07.i.i.i.i.i, i64 1
  %48 = load i8, ptr %47, align 1
  %.not.i.i.i.i.i = icmp eq i8 %48, 0
  br i1 %.not.i.i.i.i.i, label %taichi_strlen.exit.i.i.i.i, label %.lr.ph.i.i.i.i.i, !llvm.loop !16

taichi_strlen.exit.i.i.i.i:                       ; preds = %.lr.ph.i.i.i.i.i
  %.lcssa = phi i64 [ %46, %.lr.ph.i.i.i.i.i ]
  %49 = call i64 @llvm.umin.i64(i64 %.lcssa, i64 2047)
  br label %taichi_strlen.exit.thread.i.i.i.i

taichi_strlen.exit.thread.i.i.i.i:                ; preds = %taichi_strlen.exit.i.i.i.i, %35
  %50 = phi i64 [ 0, %35 ], [ %49, %taichi_strlen.exit.i.i.i.i ]
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %41, ptr nonnull align 1 %44, i64 %50, i1 false)
  %51 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 2
  %52 = load ptr, ptr %51, align 8
  %53 = load i32, ptr %52, align 4
  %54 = icmp sgt i32 %53, 0
  br i1 %54, label %.lr.ph.i.i.i.i, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

.lr.ph.i.i.i.i:                                   ; preds = %taichi_strlen.exit.thread.i.i.i.i
  %55 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 3
  br label %56

56:                                               ; preds = %56, %.lr.ph.i.i.i.i
  %indvars.iv.i.i.i.i = phi i64 [ 0, %.lr.ph.i.i.i.i ], [ %indvars.iv.next.i.i.i.i, %56 ]
  %57 = load ptr, ptr %55, align 8
  %58 = load ptr, ptr %57, align 8
  %59 = getelementptr inbounds i64, ptr %58, i64 %indvars.iv.i.i.i.i
  %60 = load i64, ptr %59, align 8
  %61 = load ptr, ptr %9, align 8
  %62 = load ptr, ptr %61, align 8
  %63 = getelementptr inbounds %struct.LLVMRuntime, ptr %62, i64 0, i32 22, i64 %indvars.iv.i.i.i.i
  store i64 %60, ptr %63, align 8
  %indvars.iv.next.i.i.i.i = add nuw nsw i64 %indvars.iv.i.i.i.i, 1
  %64 = load ptr, ptr %51, align 8
  %65 = load i32, ptr %64, align 4
  %66 = sext i32 %65 to i64
  %67 = icmp slt i64 %indvars.iv.next.i.i.i.i, %66
  br i1 %67, label %56, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", !llvm.loop !17

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit": ; preds = %56
  br label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit": ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", %taichi_strlen.exit.thread.i.i.i.i, %mutex_lock_i32.exit.i.i.i
  %68 = atomicrmw volatile xchg ptr %23, i32 0 seq_cst, align 4
  br label %69

69:                                               ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit", %16, %15
  ret void
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_struct_for_block_helper(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #7 {
_ZN11ListManager3getI7ElementEERT_i.exit:
  %3 = alloca %struct.RuntimeContext.443, align 8
  %4 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 4
  %5 = load i32, ptr %4, align 4
  %6 = sdiv i32 %2, %5
  %7 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  %8 = load i32, ptr %7, align 8
  %9 = sdiv i32 %8, %5
  %10 = srem i32 %2, %5
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  %12 = load ptr, ptr %11, align 8
  %13 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %14 = load i32, ptr %13, align 8
  %15 = ashr i32 %6, %14
  %16 = sext i32 %15 to i64
  %17 = lshr i64 %16, 9
  %18 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %17
  %19 = load atomic i64, ptr %18 acquire, align 8
  %.not.i.i.i = icmp ne i64 %19, 0
  tail call void @llvm.assume(i1 %.not.i.i.i)
  %20 = inttoptr i64 %19 to ptr
  %21 = and i64 %16, 511
  %22 = getelementptr inbounds ptr, ptr %20, i64 %21
  %23 = load atomic i64, ptr %22 acquire, align 8
  %24 = inttoptr i64 %23 to ptr
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %26 = load i64, ptr %25, align 8
  %27 = load i32, ptr %13, align 8
  %notmask.i.i = shl nsw i32 -1, %27
  %28 = xor i32 %notmask.i.i, -1
  %29 = and i32 %6, %28
  %30 = sext i32 %29 to i64
  %31 = mul i64 %26, %30
  %32 = getelementptr inbounds i8, ptr %24, i64 %31
  %33 = getelementptr inbounds %0, ptr %32, i64 0, i32 1
  %34 = load i32, ptr %33, align 8
  %35 = mul nsw i32 %10, %9
  %36 = add nsw i32 %34, %35
  %37 = add nsw i32 %10, 1
  %38 = mul nsw i32 %37, %9
  %39 = add nsw i32 %34, %38
  %40 = getelementptr inbounds %0, ptr %32, i64 0, i32 1, i64 1
  %41 = load i32, ptr %40, align 4
  %42 = tail call i32 @llvm.smin.i32(i32 %41, i32 %39)
  %43 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  %44 = load i64, ptr %43, align 8
  %45 = alloca i8, i64 %44, align 8
  %46 = load ptr, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %3, ptr noundef nonnull align 8 dereferenceable(32) %46, i64 32, i1 false)
  %47 = getelementptr inbounds %struct.RuntimeContext.443, ptr %3, i64 0, i32 2
  store i32 %1, ptr %47, align 8
  %48 = icmp slt i32 %36, %42
  br i1 %48, label %49, label %75

49:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit
  %50 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = load ptr, ptr %11, align 8
  %53 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 3
  %54 = load i32, ptr %53, align 8
  %55 = ashr i32 %6, %54
  %56 = sext i32 %55 to i64
  %57 = lshr i64 %56, 9
  %58 = getelementptr inbounds [256 x ptr], ptr %52, i64 0, i64 %57
  %59 = load atomic i64, ptr %58 acquire, align 8
  %.not.i.i.i24 = icmp eq i64 %59, 0
  br i1 %.not.i.i.i24, label %_ZN11ListManager3getI7ElementEERT_i.exit26, label %60

60:                                               ; preds = %49
  %61 = inttoptr i64 %59 to ptr
  %62 = and i64 %56, 511
  %63 = getelementptr inbounds ptr, ptr %61, i64 %62
  %64 = load atomic i64, ptr %63 acquire, align 8
  %65 = inttoptr i64 %64 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit26

_ZN11ListManager3getI7ElementEERT_i.exit26:       ; preds = %60, %49
  %66 = phi ptr [ %65, %60 ], [ null, %49 ]
  %67 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 1
  %68 = load i64, ptr %67, align 8
  %69 = load i32, ptr %53, align 8
  %notmask.i.i25 = shl nsw i32 -1, %69
  %70 = xor i32 %notmask.i.i25, -1
  %71 = and i32 %6, %70
  %72 = sext i32 %71 to i64
  %73 = mul i64 %68, %72
  %74 = getelementptr inbounds i8, ptr %66, i64 %73
  call void %51(ptr noundef nonnull %3, ptr noundef nonnull %45, ptr noundef nonnull %74, i32 noundef %36, i32 noundef %42) #1
  br label %75

75:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit26, %_ZN11ListManager3getI7ElementEERT_i.exit
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i64 @llvm.umin.i64(i64, i64) #8

; Function Attrs: inaccessiblememonly nocallback nofree nosync nounwind willreturn
declare void @llvm.assume(i1 noundef) #9

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #8

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #10

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #10

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #3 = { argmemonly mustprogress nofree norecurse nosync nounwind willreturn }
attributes #4 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #5 = { argmemonly mustprogress nocallback nofree nounwind willreturn writeonly }
attributes #6 = { noinline nounwind optnone uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #9 = { inaccessiblememonly nocallback nofree nosync nounwind willreturn }
attributes #10 = { argmemonly nocallback nofree nosync nounwind willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !12}
!12 = !{!"llvm.loop.unroll.disable"}
!13 = distinct !{!13, !12}
!14 = distinct !{!14, !12}
!15 = distinct !{!15, !12}
!16 = distinct !{!16, !7}
!17 = distinct !{!17, !7}
