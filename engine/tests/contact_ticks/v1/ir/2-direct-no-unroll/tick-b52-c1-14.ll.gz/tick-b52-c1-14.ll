; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%0 = type { ptr, [2 x i32], %struct.PhysicalCoordinates.2238 }
%1 = type { [1048576 x %2], %3, %4 }
%2 = type { i8 }
%3 = type { [128 x i64], [128 x ptr] }
%4 = type { [4 x i32], [128 x %5] }
%5 = type { i32, i64 }
%6 = type { [70 x %2], %3, %4 }
%struct.RuntimeContext.2230 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }
%struct.range_task_helper_context = type { ptr, ptr, ptr, ptr, i64, i32, i32, i32, i32 }
%struct.ListManager = type { [256 x ptr], i64, i64, i32, i32, i32, ptr }
%struct.PhysicalCoordinates.2238 = type { [12 x i32] }
%struct.cpu_block_task_helper_context = type { ptr, ptr, ptr, i32, i32, i64 }
%class.anon = type { ptr, ptr, ptr, ptr }

@.str = private unnamed_addr constant [28 x i8] c"Out of pre-allocated memory\00", align 1
@.str.2 = private unnamed_addr constant [28 x i8] c"List manager out of chunks.\00", align 1

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @geometry_collect_35_selection_55_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %0, i64 0, i32 8
  %2 = load i32, ptr %1, align 4
  %3 = getelementptr inbounds %struct.RuntimeContext.2230, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 4
  store i32 %2, ptr %7, align 4
  %8 = load ptr, ptr %context, align 8
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %8, i64 0, i32 9
  %10 = load i32, ptr %9, align 4
  %11 = load ptr, ptr %3, align 8
  %12 = getelementptr inbounds %struct.LLVMRuntime, ptr %11, i64 0, i32 16
  %13 = load ptr, ptr %12, align 8
  store i32 %10, ptr %13, align 4
  %14 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %0, i64 0, i32 4, i32 1
  %15 = load ptr, ptr %14, align 8
  store i64 0, ptr %15, align 8
  %16 = load ptr, ptr %14, align 8
  %17 = getelementptr i64, ptr %16, i64 1
  store i64 0, ptr %17, align 8
  %18 = load ptr, ptr %14, align 8
  %19 = getelementptr i64, ptr %18, i64 2
  %20 = getelementptr i64, ptr %18, i64 3
  store i64 0, ptr %20, align 8
  %21 = load ptr, ptr %14, align 8
  %22 = getelementptr i64, ptr %21, i64 4
  store i64 0, ptr %22, align 8
  %23 = load ptr, ptr %14, align 8
  %24 = getelementptr i64, ptr %23, i64 5
  store i64 0, ptr %24, align 8
  %25 = load ptr, ptr %14, align 8
  %26 = getelementptr i64, ptr %25, i64 7
  store i64 0, ptr %26, align 8
  %27 = load ptr, ptr %14, align 8
  %28 = getelementptr i64, ptr %27, i64 8
  store i64 0, ptr %28, align 8
  %29 = load ptr, ptr %14, align 8
  %30 = getelementptr i64, ptr %29, i64 9
  %31 = getelementptr i64, ptr %29, i64 10
  store i64 0, ptr %31, align 8
  %32 = load ptr, ptr %14, align 8
  %33 = getelementptr i64, ptr %32, i64 11
  store i64 0, ptr %33, align 8
  %34 = load ptr, ptr %14, align 8
  %35 = getelementptr i64, ptr %34, i64 12
  store i64 0, ptr %35, align 8
  %36 = load ptr, ptr %14, align 8
  %37 = getelementptr i64, ptr %36, i64 13
  store i64 0, ptr %37, align 8
  %38 = load ptr, ptr %14, align 8
  %39 = getelementptr i64, ptr %38, i64 14
  store i64 0, ptr %39, align 8
  %40 = load ptr, ptr %14, align 8
  %41 = getelementptr i64, ptr %40, i64 15
  store i64 0, ptr %41, align 8
  %42 = sext i32 %10 to i64
  store i64 %42, ptr %19, align 8
  store i64 70, ptr %30, align 8
  ret void
}

; Function Attrs: nounwind
define void @geometry_collect_35_selection_55_kernel_1_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.2230, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %7, i64 0, i32 3, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.lr.ph
  %indvars.iv = phi i64 [ %9, %for_loop_body.lr.ph ], [ %indvars.iv.next, %for_loop_body ]
  %10 = load ptr, ptr %8, align 8
  %11 = shl i64 %indvars.iv, 2
  %uglygep = getelementptr i8, ptr %10, i64 %11
  store i32 0, ptr %uglygep, align 4
  %indvars.iv.next = add nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %wide.trip.count, %indvars.iv.next
  br i1 %exitcond.not, label %after_for.loopexit, label %for_loop_body, !llvm.loop !6

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %allocs
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @geometry_collect_35_selection_55_kernel_2_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.2230, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 35
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @geometry_collect_35_selection_55_kernel_3_listgen_S35bitmasked(ptr %context) local_unnamed_addr #1 {
.lr.ph.i:
  %.sroa.2.i = alloca { [2 x i32], %struct.PhysicalCoordinates.2238 }, align 8
  %0 = alloca %0, align 8
  %1 = getelementptr inbounds %struct.RuntimeContext.2230, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 30
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %4, i64 35
  %8 = load ptr, ptr %7, align 8
  %9 = load atomic i64, ptr %6 acquire, align 8
  %.not.i.i.i.i = icmp ne i64 %9, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i)
  %10 = inttoptr i64 %9 to ptr
  %11 = load atomic i64, ptr %10 acquire, align 8
  %12 = inttoptr i64 %11 to ptr
  %.sroa.0.0.copyload.i = load ptr, ptr %12, align 8
  %.sroa.2.0..sroa_idx.i = getelementptr inbounds i8, ptr %12, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.i, ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.0..sroa_idx.i, i64 56, i1 false)
  %getch.i = getelementptr %1, ptr %.sroa.0.0.copyload.i, i64 0, i32 2
  %13 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %.sroa.2.16.sroa_idx.i = getelementptr inbounds i8, ptr %.sroa.2.i, i64 8
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %16 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 4
  %17 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 6
  %18 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 2
  %19 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  store ptr %getch.i, ptr %0, align 8
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %0, i64 8
  store <2 x i32> <i32 0, i32 128>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %13, ptr noundef nonnull align 8 dereferenceable(48) %.sroa.2.16.sroa_idx.i, i64 48, i1 false)
  %20 = atomicrmw volatile add ptr %14, i32 1 seq_cst, align 4
  %21 = load i32, ptr %15, align 8
  %22 = ashr i32 %20, %21
  %23 = icmp ugt i32 %22, 131071
  br i1 %23, label %24, label %26

24:                                               ; preds = %.lr.ph.i
  %25 = load ptr, ptr %17, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %25, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

26:                                               ; preds = %.lr.ph.i
  %27 = zext i32 %22 to i64
  %28 = lshr i64 %27, 9
  %29 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %28
  %30 = load atomic i64, ptr %29 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %30, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %26
  %31 = inttoptr i64 %30 to ptr
  %32 = and i64 %27, 511
  %33 = getelementptr inbounds ptr, ptr %31, i64 %32
  %34 = load atomic i64, ptr %33 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %26
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %35 = atomicrmw volatile xchg ptr %16, i32 1 seq_cst, align 4
  %36 = icmp eq i32 %35, 1
  br i1 %36, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !8

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %37 = load atomic i64, ptr %29 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %37, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %39, label %73

39:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %40 = load ptr, ptr %17, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1
  %42 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 28
  %43 = atomicrmw volatile add ptr %42, i64 4096 seq_cst, align 8
  %44 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 2
  %45 = load i64, ptr %44, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %45, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %66, label %46

46:                                               ; preds = %39
  %47 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 26
  br label %48

48:                                               ; preds = %48, %46
  %49 = atomicrmw volatile xchg ptr %47, i32 1 seq_cst, align 4
  %50 = icmp eq i32 %49, 1
  br i1 %50, label %48, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !8

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %48
  %51 = load ptr, ptr %41, align 8
  %52 = ptrtoint ptr %51 to i64
  %53 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 1
  %54 = load ptr, ptr %53, align 8
  %55 = ptrtoint ptr %54 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %52
  %56 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %57 = or i64 %56, 4096
  %58 = add i64 %57, %52
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %58, %55
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %59

59:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %60 = add i64 %56, %52
  %61 = inttoptr i64 %60 to ptr
  %62 = getelementptr i8, ptr %51, i64 %56
  %63 = getelementptr inbounds i8, ptr %62, i64 4096
  store ptr %63, ptr %41, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %59, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %61, %59 ]
  %64 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %65 = atomicrmw volatile xchg ptr %47, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %40, i1 noundef zeroext %64, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

66:                                               ; preds = %39
  %67 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 2
  %68 = load ptr, ptr %67, align 8
  %69 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 6
  %70 = load ptr, ptr %69, align 8
  %71 = tail call noundef ptr %68(ptr noundef %70, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %66, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %71, %66 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %72 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %72, ptr %29 release, align 8
  br label %73

73:                                               ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %38, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %74 = and i32 %22, 511
  %75 = zext i32 %74 to i64
  %76 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %75
  %77 = load atomic i64, ptr %76 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %77, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %78, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

78:                                               ; preds = %73
  %79 = load ptr, ptr %17, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1
  %81 = load i64, ptr %18, align 8
  %82 = load i64, ptr %19, align 8
  %83 = mul i64 %82, %81
  %84 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 28
  %85 = atomicrmw volatile add ptr %84, i64 %83 seq_cst, align 8
  %86 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 2
  %87 = load i64, ptr %86, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %87, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %107, label %88

88:                                               ; preds = %78
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 26
  br label %90

90:                                               ; preds = %90, %88
  %91 = atomicrmw volatile xchg ptr %89, i32 1 seq_cst, align 4
  %92 = icmp eq i32 %91, 1
  br i1 %92, label %90, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !8

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %90
  %93 = load ptr, ptr %80, align 8
  %94 = ptrtoint ptr %93 to i64
  %95 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 1
  %96 = load ptr, ptr %95, align 8
  %97 = ptrtoint ptr %96 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %94
  %98 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %99 = add i64 %98, %83
  %100 = add i64 %99, %94
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %100, %97
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %101

101:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %102 = add i64 %98, %94
  %103 = inttoptr i64 %102 to ptr
  %104 = getelementptr inbounds i8, ptr %93, i64 %99
  store ptr %104, ptr %80, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %101, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %103, %101 ]
  %105 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %106 = atomicrmw volatile xchg ptr %89, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %79, i1 noundef zeroext %105, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

107:                                              ; preds = %78
  %108 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 2
  %109 = load ptr, ptr %108, align 8
  %110 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 6
  %111 = load ptr, ptr %110, align 8
  %112 = tail call noundef ptr %109(ptr noundef %111, i64 noundef %83, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %107, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %112, %107 ]
  %113 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %113, ptr %76 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %73
  %114 = atomicrmw volatile xchg ptr %16, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %24
  %115 = load i32, ptr %15, align 8
  %116 = ashr i32 %20, %115
  %117 = sext i32 %116 to i64
  %118 = lshr i64 %117, 9
  %119 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %118
  %120 = load atomic i64, ptr %119 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %120, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %121

121:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %122 = inttoptr i64 %120 to ptr
  %123 = and i64 %117, 511
  %124 = getelementptr inbounds ptr, ptr %122, i64 %123
  %125 = load atomic i64, ptr %124 acquire, align 8
  %126 = inttoptr i64 %125 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %121, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %127 = phi ptr [ %126, %121 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %128 = load i64, ptr %19, align 8
  %129 = load i32, ptr %15, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %129
  %130 = xor i32 %notmask.i.i.i.i, -1
  %131 = and i32 %20, %130
  %132 = sext i32 %131 to i64
  %133 = mul i64 %128, %132
  %134 = getelementptr inbounds i8, ptr %127, i64 %133
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %134, ptr nonnull align 8 %0, i64 %128, i1 false)
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  ret void
}

; Function Attrs: nounwind
define void @geometry_collect_35_selection_55_kernel_4_struct_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.cpu_block_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.RuntimeContext.2230, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 35
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds %struct.ListManager, ptr %6, i64 0, i32 5
  %8 = load i32, ptr %7, align 8
  store ptr %context, ptr %0, align 8
  %9 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  store ptr @function_body.1, ptr %9, align 8
  %10 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  store ptr %6, ptr %10, align 8
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  store <2 x i32> <i32 128, i32 128>, ptr %11, align 8
  %12 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  store i64 1, ptr %12, align 8
  %13 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 12
  %14 = load ptr, ptr %13, align 8
  %15 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 11
  %16 = load ptr, ptr %15, align 8
  %17 = shl nsw i32 %8, 7
  call void %14(ptr noundef %16, i32 noundef %17, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_struct_for_block_helper) #1
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree norecurse nounwind
define internal void @function_body.1(ptr %0, ptr nocapture readnone %1, ptr nocapture readonly %2, i32 %3, i32 %4) #3 {
allocs:
  %5 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %6 = icmp slt i32 %3, %4
  br i1 %6, label %loop_body.lr.ph, label %func_exit

loop_body.lr.ph:                                  ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.2230, ptr %0, i64 0, i32 1
  br label %loop_body

loop_body:                                        ; preds = %loop_body_tail, %loop_body.lr.ph
  %.044 = phi i32 [ %3, %loop_body.lr.ph ], [ %18, %loop_body_tail ]
  %8 = load ptr, ptr %2, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 2048
  %10 = sdiv i32 %.044, 8
  %11 = sext i32 %10 to i64
  %12 = getelementptr inbounds i8, ptr %9, i64 %11
  %13 = load i8, ptr %12, align 1
  %14 = zext i8 %13 to i32
  %15 = and i32 %.044, 7
  %16 = shl nuw nsw i32 1, %15
  %17 = and i32 %16, %14
  %.not = icmp eq i32 %17, 0
  br i1 %.not, label %loop_body_tail, label %struct_for_body_body

loop_body_tail:                                   ; preds = %true_block, %Pointer_lookup_element.exit, %loop_body
  %18 = add nsw i32 %.044, 1
  %exitcond.not = icmp eq i32 %4, %18
  br i1 %exitcond.not, label %func_exit.loopexit, label %loop_body, !llvm.loop !10

func_exit.loopexit:                               ; preds = %loop_body_tail
  br label %func_exit

func_exit:                                        ; preds = %func_exit.loopexit, %allocs
  ret void

struct_for_body_body:                             ; preds = %loop_body
  %19 = and i32 %.044, 127
  %20 = load i32, ptr %5, align 4
  %21 = shl i32 %20, 7
  %22 = or i32 %21, %19
  %23 = load ptr, ptr %0, align 8
  %24 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %23, i64 0, i32 3, i32 1
  %25 = load ptr, ptr %24, align 8
  %26 = sext i32 %22 to i64
  %27 = getelementptr i32, ptr %25, i64 %26
  store i32 1, ptr %27, align 4
  %28 = load ptr, ptr %0, align 8
  %29 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %28, i64 0, i32 4, i32 1
  %30 = load ptr, ptr %29, align 8
  %31 = getelementptr i64, ptr %30, i64 8
  %32 = atomicrmw add ptr %31, i64 1 seq_cst, align 8
  %33 = load ptr, ptr %7, align 8
  %34 = getelementptr inbounds %struct.LLVMRuntime, ptr %33, i64 0, i32 7
  %35 = load ptr, ptr %34, align 8
  %36 = getelementptr inbounds ptr, ptr %35, i64 5
  %37 = load ptr, ptr %36, align 8
  %38 = lshr i32 %22, 2
  %39 = and i32 %38, 1073741816
  %40 = zext i32 %39 to i64
  %41 = getelementptr i8, ptr %37, i64 %40
  %42 = getelementptr inbounds i8, ptr %41, i64 32
  %43 = load ptr, ptr %42, align 8
  %44 = icmp eq ptr %43, null
  br i1 %44, label %45, label %Pointer_lookup_element.exit

45:                                               ; preds = %struct_for_body_body
  %46 = getelementptr inbounds %struct.LLVMRuntime, ptr %33, i64 0, i32 15
  %47 = load ptr, ptr %46, align 8
  %48 = getelementptr inbounds ptr, ptr %47, i64 54
  %49 = load ptr, ptr %48, align 8
  br label %Pointer_lookup_element.exit

Pointer_lookup_element.exit:                      ; preds = %45, %struct_for_body_body
  %.0.i = phi ptr [ %49, %45 ], [ %43, %struct_for_body_body ]
  %50 = getelementptr inbounds i8, ptr %.0.i, i64 32
  %51 = lshr i32 %.044, 3
  %52 = and i32 %51, 3
  %53 = zext i32 %52 to i64
  %54 = getelementptr inbounds i8, ptr %50, i64 %53
  %55 = load i8, ptr %54, align 1
  %56 = zext i8 %55 to i32
  %57 = and i32 %16, %56
  %.not43 = icmp eq i32 %57, 0
  br i1 %.not43, label %loop_body_tail, label %true_block

true_block:                                       ; preds = %Pointer_lookup_element.exit
  %58 = load ptr, ptr %29, align 8
  %59 = getelementptr i64, ptr %58, i64 1
  %60 = atomicrmw add ptr %59, i64 1 seq_cst, align 8
  br label %loop_body_tail
}

; Function Attrs: nofree norecurse nosync nounwind
define void @geometry_collect_35_selection_55_kernel_5_serial(ptr nocapture readonly %context) local_unnamed_addr #4 {
entry:
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if, %entry
  %indvars.iv = phi i64 [ 0, %entry ], [ %indvars.iv.next, %after_if ]
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %0, i64 0, i32 3, i32 1
  %2 = load ptr, ptr %1, align 8
  %3 = shl nuw nsw i64 %indvars.iv, 2
  %uglygep22 = getelementptr i8, ptr %2, i64 %3
  %4 = load i32, ptr %uglygep22, align 4
  %.not = icmp eq i32 %4, 0
  br i1 %.not, label %after_if, label %true_block

after_for:                                        ; preds = %after_if
  ret void

true_block:                                       ; preds = %for_loop_body
  %5 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %0, i64 0, i32 4, i32 1
  %6 = load ptr, ptr %5, align 8
  %7 = load i64, ptr %6, align 8
  %sext = shl i64 %7, 32
  %8 = ashr exact i64 %sext, 32
  %9 = getelementptr i32, ptr %2, i64 %8
  %tmp = trunc i64 %indvars.iv to i32
  store i32 %tmp, ptr %9, align 4
  %10 = add i64 %7, 1
  store i64 %10, ptr %6, align 8
  %11 = load ptr, ptr %context, align 8
  %12 = getelementptr { { i32, i32 }, ptr }, ptr %11, i64 0, i32 1
  %13 = load ptr, ptr %12, align 8
  %14 = getelementptr { { i32, i32 }, ptr }, ptr %11, i64 0, i32 0, i32 1
  %15 = shl nuw nsw i64 %indvars.iv, 3
  %uglygep21 = getelementptr i8, ptr %13, i64 %15
  %16 = load i64, ptr %uglygep21, align 8
  %17 = and i64 %16, 9223372036854775807
  %18 = and i64 %16, 9218868437227405312
  %19 = icmp eq i64 %17, 0
  %20 = icmp ne i64 %18, 0
  %21 = icmp ne i64 %18, 9218868437227405312
  %22 = and i1 %20, %21
  %23 = or i1 %19, %22
  br i1 %23, label %after_if3, label %true_block1

after_if:                                         ; preds = %true_block16, %after_if15, %for_loop_body
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %indvars.iv.next, 70
  br i1 %exitcond.not, label %after_for, label %for_loop_body, !llvm.loop !11

true_block1:                                      ; preds = %true_block
  %24 = load ptr, ptr %5, align 8
  %25 = getelementptr i64, ptr %24, i64 5
  %26 = load i64, ptr %25, align 8
  %27 = or i64 %26, 1
  store i64 %27, ptr %25, align 8
  %.pre = load ptr, ptr %12, align 8
  br label %after_if3

after_if3:                                        ; preds = %true_block1, %true_block
  %28 = phi ptr [ %13, %true_block ], [ %.pre, %true_block1 ]
  %29 = load i32, ptr %14, align 4
  %30 = sext i32 %29 to i64
  %31 = add nsw i64 %indvars.iv, %30
  %32 = getelementptr double, ptr %28, i64 %31
  %33 = load i64, ptr %32, align 8
  %34 = and i64 %33, 9223372036854775807
  %35 = and i64 %33, 9218868437227405312
  %36 = icmp eq i64 %34, 0
  %37 = icmp ne i64 %35, 0
  %38 = icmp ne i64 %35, 9218868437227405312
  %39 = and i1 %37, %38
  %40 = or i1 %36, %39
  br i1 %40, label %after_if6, label %true_block4

true_block4:                                      ; preds = %after_if3
  %41 = load ptr, ptr %5, align 8
  %42 = getelementptr i64, ptr %41, i64 5
  %43 = load i64, ptr %42, align 8
  %44 = or i64 %43, 1
  store i64 %44, ptr %42, align 8
  %.pre5 = load ptr, ptr %12, align 8
  %.pre6 = load i32, ptr %14, align 4
  %.pre11 = sext i32 %.pre6 to i64
  br label %after_if6

after_if6:                                        ; preds = %true_block4, %after_if3
  %.pre-phi = phi i64 [ %30, %after_if3 ], [ %.pre11, %true_block4 ]
  %45 = phi ptr [ %28, %after_if3 ], [ %.pre5, %true_block4 ]
  %46 = shl nsw i64 %.pre-phi, 4
  %uglygep19 = getelementptr i8, ptr %45, i64 %46
  %uglygep20 = getelementptr i8, ptr %uglygep19, i64 %15
  %47 = load i64, ptr %uglygep20, align 8
  %48 = and i64 %47, 9223372036854775807
  %49 = and i64 %47, 9218868437227405312
  %50 = icmp eq i64 %48, 0
  %51 = icmp ne i64 %49, 0
  %52 = icmp ne i64 %49, 9218868437227405312
  %53 = and i1 %51, %52
  %54 = or i1 %50, %53
  br i1 %54, label %after_if9, label %true_block7

true_block7:                                      ; preds = %after_if6
  %55 = load ptr, ptr %5, align 8
  %56 = getelementptr i64, ptr %55, i64 5
  %57 = load i64, ptr %56, align 8
  %58 = or i64 %57, 1
  store i64 %58, ptr %56, align 8
  %.pre7 = load ptr, ptr %12, align 8
  %.pre8 = load i32, ptr %14, align 4
  %.pre12 = sext i32 %.pre8 to i64
  br label %after_if9

after_if9:                                        ; preds = %true_block7, %after_if6
  %.pre-phi13 = phi i64 [ %.pre-phi, %after_if6 ], [ %.pre12, %true_block7 ]
  %59 = phi ptr [ %45, %after_if6 ], [ %.pre7, %true_block7 ]
  %60 = mul nsw i64 %.pre-phi13, 48
  %uglygep17 = getelementptr i8, ptr %59, i64 %60
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %15
  %61 = load double, ptr %uglygep18, align 8
  %62 = bitcast double %61 to i64
  %63 = and i64 %62, 9223372036854775807
  %64 = and i64 %62, 9218868437227405312
  %65 = icmp eq i64 %63, 0
  %66 = icmp ne i64 %64, 0
  %67 = icmp ne i64 %64, 9218868437227405312
  %68 = and i1 %66, %67
  %69 = or i1 %65, %68
  br i1 %69, label %after_if12, label %true_block10

true_block10:                                     ; preds = %after_if9
  %70 = load ptr, ptr %5, align 8
  %71 = getelementptr i64, ptr %70, i64 5
  %72 = load i64, ptr %71, align 8
  %73 = or i64 %72, 1
  store i64 %73, ptr %71, align 8
  %.pre9 = load ptr, ptr %12, align 8
  %.pre10 = load i32, ptr %14, align 4
  %.pre14 = sext i32 %.pre10 to i64
  br label %after_if12

after_if12:                                       ; preds = %true_block10, %after_if9
  %.pre-phi15 = phi i64 [ %.pre-phi13, %after_if9 ], [ %.pre14, %true_block10 ]
  %74 = phi ptr [ %59, %after_if9 ], [ %.pre9, %true_block10 ]
  %75 = mul nsw i64 %.pre-phi15, 56
  %uglygep = getelementptr i8, ptr %74, i64 %75
  %uglygep16 = getelementptr i8, ptr %uglygep, i64 %15
  %76 = load double, ptr %uglygep16, align 8
  %77 = bitcast double %76 to i64
  %78 = and i64 %77, 9223372036854775807
  %79 = and i64 %77, 9218868437227405312
  %80 = icmp eq i64 %78, 0
  %81 = icmp ne i64 %79, 0
  %82 = icmp ne i64 %79, 9218868437227405312
  %83 = and i1 %81, %82
  %84 = or i1 %80, %83
  br i1 %84, label %after_if15, label %true_block13

true_block13:                                     ; preds = %after_if12
  %85 = load ptr, ptr %5, align 8
  %86 = getelementptr i64, ptr %85, i64 5
  %87 = load i64, ptr %86, align 8
  %88 = or i64 %87, 1
  store i64 %88, ptr %86, align 8
  br label %after_if15

after_if15:                                       ; preds = %true_block13, %after_if12
  %89 = fcmp ole double %61, 0.000000e+00
  %90 = fcmp olt double %76, 0.000000e+00
  %91 = or i1 %89, %90
  br i1 %91, label %true_block16, label %after_if

true_block16:                                     ; preds = %after_if15
  %92 = load ptr, ptr %5, align 8
  %93 = getelementptr i64, ptr %92, i64 5
  %94 = load i64, ptr %93, align 8
  %95 = or i64 %94, 1
  store i64 %95, ptr %93, align 8
  br label %after_if
}

; Function Attrs: nounwind
define void @geometry_collect_35_selection_55_kernel_6_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.2, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.2230, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.2(ptr %0, ptr nocapture readnone %1, i32 %2) #5 {
allocs:
  %3 = getelementptr inbounds %struct.RuntimeContext.2230, ptr %0, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  %7 = load i32, ptr %6, align 4
  %8 = add i32 %7, 1
  %9 = sdiv i32 %8, 2
  %10 = icmp slt i32 %8, 0
  %11 = shl nsw i32 %9, 1
  %12 = icmp ne i32 %11, %8
  %13 = and i1 %10, %12
  %.neg = sext i1 %13 to i32
  %14 = add nsw i32 %9, %.neg
  %15 = tail call i32 @llvm.smax.i32(i32 %14, i32 512)
  %16 = mul i32 %15, %2
  %17 = add i32 %16, %15
  %18 = tail call i32 @llvm.smin.i32(i32 %7, i32 %17)
  %19 = icmp slt i32 %16, %18
  br i1 %19, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %20 = load ptr, ptr %0, align 8
  %21 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %20, i64 0, i32 2, i32 1
  %22 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %20, i64 0, i32 2, i32 0, i32 1
  %23 = sext i32 %16 to i64
  %wide.trip.count = sext i32 %18 to i64
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if, %for_loop_body.lr.ph
  %indvars.iv = phi i64 [ %23, %for_loop_body.lr.ph ], [ %indvars.iv.next, %after_if ]
  %24 = load ptr, ptr %21, align 8
  %25 = load i32, ptr %22, align 4
  %26 = sext i32 %25 to i64
  %27 = shl i64 %indvars.iv, 2
  %uglygep = getelementptr i8, ptr %24, i64 %27
  %28 = load i32, ptr %uglygep, align 4
  %29 = add nsw i64 %indvars.iv, %26
  %30 = getelementptr i32, ptr %24, i64 %29
  %31 = load i32, ptr %30, align 4
  %32 = icmp ult i32 %28, 70
  %33 = icmp ult i32 %31, 70
  %34 = and i1 %32, %33
  br i1 %34, label %true_block, label %after_if.sink.split

after_for.loopexit:                               ; preds = %after_if
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %35 = icmp ne i32 %28, %31
  %36 = load ptr, ptr %3, align 8
  %37 = getelementptr inbounds %struct.LLVMRuntime, ptr %36, i64 0, i32 7
  %38 = load ptr, ptr %37, align 8
  %39 = load ptr, ptr %38, align 8
  %40 = getelementptr %1, ptr %39, i64 0, i32 2, i32 1, i64 127
  %41 = lshr i32 %28, 3
  %42 = zext i32 %41 to i64
  %43 = getelementptr inbounds i8, ptr %40, i64 %42
  %44 = load i8, ptr %43, align 1
  %45 = zext i8 %44 to i32
  %46 = and i32 %28, 7
  %47 = shl nuw nsw i32 1, %46
  %48 = and i32 %47, %45
  %49 = icmp ne i32 %48, 0
  %50 = lshr i32 %31, 3
  %51 = zext i32 %50 to i64
  %52 = getelementptr inbounds i8, ptr %40, i64 %51
  %53 = load i8, ptr %52, align 1
  %54 = zext i8 %53 to i32
  %55 = and i32 %31, 7
  %56 = shl nuw nsw i32 1, %55
  %57 = and i32 %56, %54
  %58 = icmp ne i32 %57, 0
  %59 = and i1 %49, %58
  %60 = and i1 %35, %59
  br i1 %60, label %after_if, label %after_if.sink.split

after_if.sink.split:                              ; preds = %true_block, %for_loop_body
  %61 = load ptr, ptr %0, align 8
  %62 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %61, i64 0, i32 4, i32 1
  %63 = load ptr, ptr %62, align 8
  %64 = getelementptr i64, ptr %63, i64 5
  %65 = atomicrmw or ptr %64, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %after_if.sink.split, %true_block
  %indvars.iv.next = add nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %wide.trip.count, %indvars.iv.next
  br i1 %exitcond.not, label %after_for.loopexit, label %for_loop_body, !llvm.loop !12
}

; Function Attrs: nofree norecurse nosync nounwind
define void @geometry_collect_35_selection_55_kernel_7_serial(ptr %context) local_unnamed_addr #4 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.2230, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 16
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 4
  %5 = load i32, ptr %4, align 4
  %6 = icmp sgt i32 %5, 0
  %7 = load ptr, ptr %context, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %7, i64 0, i32 4, i32 1
  %9 = load ptr, ptr %8, align 8
  %10 = load i64, ptr %9, align 8
  %11 = icmp ne i64 %10, 0
  %12 = zext i1 %11 to i64
  %13 = select i1 %6, i64 2, i64 %12
  %14 = getelementptr i64, ptr %9, i64 6
  store i64 %13, ptr %14, align 8
  br i1 %6, label %for_loop_body.preheader, label %after_for

for_loop_body.preheader:                          ; preds = %entry
  %wide.trip.count = zext i32 %5 to i64
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if, %for_loop_body.preheader
  %indvars.iv = phi i64 [ 0, %for_loop_body.preheader ], [ %indvars.iv.next, %after_if ]
  %.01022 = phi double [ 0.000000e+00, %for_loop_body.preheader ], [ %.1, %after_if ]
  %.01121 = phi double [ 0.000000e+00, %for_loop_body.preheader ], [ %.112, %after_if ]
  %.01320 = phi double [ 0.000000e+00, %for_loop_body.preheader ], [ %.114, %after_if ]
  %.01519 = phi double [ 0.000000e+00, %for_loop_body.preheader ], [ %.116, %after_if ]
  %15 = load ptr, ptr %context, align 8
  %16 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %15, i64 0, i32 7, i32 1
  %17 = load ptr, ptr %16, align 8
  %18 = shl nuw nsw i64 %indvars.iv, 2
  %uglygep = getelementptr i8, ptr %17, i64 %18
  %19 = load i32, ptr %uglygep, align 4
  %20 = icmp ult i32 %19, 70
  br i1 %20, label %true_block, label %false_block

after_for.loopexit:                               ; preds = %after_if
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %entry
  %.015.lcssa = phi double [ 0.000000e+00, %entry ], [ %.116, %after_for.loopexit ]
  %.013.lcssa = phi double [ 0.000000e+00, %entry ], [ %.114, %after_for.loopexit ]
  %.011.lcssa = phi double [ 0.000000e+00, %entry ], [ %.112, %after_for.loopexit ]
  %.010.lcssa = phi double [ 0.000000e+00, %entry ], [ %.1, %after_for.loopexit ]
  %21 = fcmp ogt double %.010.lcssa, 0.000000e+00
  %22 = fcmp olt double %.010.lcssa, 0.000000e+00
  %..i.op = select i1 %22, double 2.000000e+00, double 1.000000e+00
  %23 = select i1 %21, double 0.000000e+00, double %..i.op
  %24 = fadd double %.010.lcssa, %23
  %25 = bitcast double %.010.lcssa to i64
  %26 = and i64 %25, 9223372036854775807
  %27 = and i64 %25, 9218868437227405312
  %28 = icmp eq i64 %26, 0
  %29 = icmp ne i64 %27, 0
  %30 = icmp ne i64 %27, 9218868437227405312
  %31 = and i1 %29, %30
  %32 = or i1 %28, %31
  br i1 %32, label %after_if21, label %true_block19

true_block:                                       ; preds = %for_loop_body
  %33 = load ptr, ptr %0, align 8
  %34 = getelementptr inbounds %struct.LLVMRuntime, ptr %33, i64 0, i32 7
  %35 = load ptr, ptr %34, align 8
  %36 = getelementptr inbounds ptr, ptr %35, i64 1
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr %6, ptr %37, i64 0, i32 2, i32 1, i64 127
  %39 = lshr i32 %19, 3
  %40 = zext i32 %39 to i64
  %41 = getelementptr inbounds i8, ptr %38, i64 %40
  %42 = load i8, ptr %41, align 1
  %43 = zext i8 %42 to i32
  %44 = and i32 %19, 7
  %45 = shl nuw nsw i32 1, %44
  %46 = and i32 %45, %43
  %.not = icmp eq i32 %46, 0
  br i1 %.not, label %false_block2, label %true_block1

false_block:                                      ; preds = %for_loop_body
  store i64 3, ptr %14, align 8
  br label %after_if

after_if:                                         ; preds = %after_if18, %false_block8, %false_block2, %false_block
  %.116 = phi double [ %93, %after_if18 ], [ %.01519, %false_block8 ], [ %.01519, %false_block2 ], [ %.01519, %false_block ]
  %.114 = phi double [ %117, %after_if18 ], [ %.01320, %false_block8 ], [ %.01320, %false_block2 ], [ %.01320, %false_block ]
  %.112 = phi double [ %139, %after_if18 ], [ %.01121, %false_block8 ], [ %.01121, %false_block2 ], [ %.01121, %false_block ]
  %.1 = phi double [ %70, %after_if18 ], [ %.01022, %false_block8 ], [ %.01022, %false_block2 ], [ %.01022, %false_block ]
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %wide.trip.count, %indvars.iv.next
  br i1 %exitcond.not, label %after_for.loopexit, label %for_loop_body, !llvm.loop !13

true_block1:                                      ; preds = %true_block
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %15, i64 0, i32 1, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %15, i64 0, i32 1, i32 0, i32 1
  %50 = load i32, ptr %49, align 4
  %51 = sext i32 %50 to i64
  %52 = mul nsw i64 %51, 3
  %53 = zext i32 %19 to i64
  %54 = add nsw i64 %52, %53
  %55 = getelementptr double, ptr %48, i64 %54
  %56 = load double, ptr %55, align 8
  %57 = bitcast double %56 to i64
  %58 = and i64 %57, 9223372036854775807
  %59 = and i64 %57, 9218868437227405312
  %60 = icmp eq i64 %58, 0
  %61 = icmp ne i64 %59, 0
  %62 = icmp ne i64 %59, 9218868437227405312
  %63 = and i1 %61, %62
  %64 = or i1 %60, %63
  br i1 %64, label %after_if6, label %true_block4

false_block2:                                     ; preds = %true_block
  store i64 3, ptr %14, align 8
  br label %after_if

true_block4:                                      ; preds = %true_block1
  %65 = load ptr, ptr %8, align 8
  %66 = getelementptr i64, ptr %65, i64 5
  %67 = load i64, ptr %66, align 8
  %68 = or i64 %67, 1
  store i64 %68, ptr %66, align 8
  br label %after_if6

after_if6:                                        ; preds = %true_block4, %true_block1
  %69 = fcmp ogt double %56, 0.000000e+00
  br i1 %69, label %true_block7, label %false_block8

true_block7:                                      ; preds = %after_if6
  %70 = fadd double %.01022, %56
  %71 = load ptr, ptr %47, align 8
  %72 = getelementptr double, ptr %71, i64 %53
  %73 = load double, ptr %72, align 8
  %74 = bitcast double %73 to i64
  %75 = and i64 %74, 9223372036854775807
  %76 = and i64 %74, 9218868437227405312
  %77 = icmp eq i64 %75, 0
  %78 = icmp ne i64 %76, 0
  %79 = icmp ne i64 %76, 9218868437227405312
  %80 = and i1 %78, %79
  %81 = or i1 %77, %80
  br i1 %81, label %after_if12, label %true_block10

false_block8:                                     ; preds = %after_if6
  store i64 3, ptr %14, align 8
  br label %after_if

true_block10:                                     ; preds = %true_block7
  %82 = load ptr, ptr %8, align 8
  %83 = getelementptr i64, ptr %82, i64 5
  %84 = load i64, ptr %83, align 8
  %85 = or i64 %84, 1
  store i64 %85, ptr %83, align 8
  %.pre = load ptr, ptr %47, align 8
  br label %after_if12

after_if12:                                       ; preds = %true_block10, %true_block7
  %86 = phi ptr [ %71, %true_block7 ], [ %.pre, %true_block10 ]
  %87 = load ptr, ptr %context, align 8
  %88 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %87, i64 0, i32 6, i32 1
  %89 = load ptr, ptr %88, align 8
  %90 = load double, ptr %89, align 8
  %91 = fsub double %73, %90
  %92 = fmul double %56, %91
  %93 = fadd double %.01519, %92
  %94 = load i32, ptr %49, align 4
  %95 = sext i32 %94 to i64
  %96 = add nsw i64 %95, %53
  %97 = getelementptr double, ptr %86, i64 %96
  %98 = load double, ptr %97, align 8
  %99 = bitcast double %98 to i64
  %100 = and i64 %99, 9223372036854775807
  %101 = and i64 %99, 9218868437227405312
  %102 = icmp eq i64 %100, 0
  %103 = icmp ne i64 %101, 0
  %104 = icmp ne i64 %101, 9218868437227405312
  %105 = and i1 %103, %104
  %106 = or i1 %102, %105
  br i1 %106, label %after_if15, label %true_block13

true_block13:                                     ; preds = %after_if12
  %107 = load ptr, ptr %8, align 8
  %108 = getelementptr i64, ptr %107, i64 5
  %109 = load i64, ptr %108, align 8
  %110 = or i64 %109, 1
  store i64 %110, ptr %108, align 8
  %.pre28 = load ptr, ptr %88, align 8
  %.pre29 = load ptr, ptr %47, align 8
  %.pre30 = load i32, ptr %49, align 4
  %.pre32 = sext i32 %.pre30 to i64
  br label %after_if15

after_if15:                                       ; preds = %true_block13, %after_if12
  %.pre-phi = phi i64 [ %95, %after_if12 ], [ %.pre32, %true_block13 ]
  %111 = phi ptr [ %86, %after_if12 ], [ %.pre29, %true_block13 ]
  %112 = phi ptr [ %89, %after_if12 ], [ %.pre28, %true_block13 ]
  %113 = getelementptr double, ptr %112, i64 1
  %114 = load double, ptr %113, align 8
  %115 = fsub double %98, %114
  %116 = fmul double %56, %115
  %117 = fadd double %.01320, %116
  %118 = shl nsw i64 %.pre-phi, 1
  %119 = add nsw i64 %118, %53
  %120 = getelementptr double, ptr %111, i64 %119
  %121 = load double, ptr %120, align 8
  %122 = bitcast double %121 to i64
  %123 = and i64 %122, 9223372036854775807
  %124 = and i64 %122, 9218868437227405312
  %125 = icmp eq i64 %123, 0
  %126 = icmp ne i64 %124, 0
  %127 = icmp ne i64 %124, 9218868437227405312
  %128 = and i1 %126, %127
  %129 = or i1 %125, %128
  br i1 %129, label %after_if18, label %true_block16

true_block16:                                     ; preds = %after_if15
  %130 = load ptr, ptr %8, align 8
  %131 = getelementptr i64, ptr %130, i64 5
  %132 = load i64, ptr %131, align 8
  %133 = or i64 %132, 1
  store i64 %133, ptr %131, align 8
  %.pre31 = load ptr, ptr %88, align 8
  br label %after_if18

after_if18:                                       ; preds = %true_block16, %after_if15
  %134 = phi ptr [ %112, %after_if15 ], [ %.pre31, %true_block16 ]
  %135 = getelementptr double, ptr %134, i64 2
  %136 = load double, ptr %135, align 8
  %137 = fsub double %121, %136
  %138 = fmul double %56, %137
  %139 = fadd double %.01121, %138
  br label %after_if

true_block19:                                     ; preds = %after_for
  %140 = load ptr, ptr %8, align 8
  %141 = getelementptr i64, ptr %140, i64 5
  %142 = load i64, ptr %141, align 8
  %143 = or i64 %142, 1
  store i64 %143, ptr %141, align 8
  br label %after_if21

after_if21:                                       ; preds = %true_block19, %after_for
  %144 = load ptr, ptr %context, align 8
  %145 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %144, i64 0, i32 5, i32 1
  %146 = load ptr, ptr %145, align 8
  %147 = getelementptr double, ptr %146, i64 3
  store double %.010.lcssa, ptr %147, align 8
  %148 = load ptr, ptr %context, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %148, i64 0, i32 6, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = load double, ptr %150, align 8
  %152 = fdiv double %.015.lcssa, %24
  %153 = fadd double %152, %151
  %154 = select i1 %21, double %153, double 0.000000e+00
  %155 = bitcast double %154 to i64
  %156 = and i64 %155, 9223372036854775807
  %157 = and i64 %155, 9218868437227405312
  %158 = icmp eq i64 %156, 0
  %159 = icmp ne i64 %157, 0
  %160 = icmp ne i64 %157, 9218868437227405312
  %161 = and i1 %159, %160
  %162 = or i1 %158, %161
  br i1 %162, label %after_if24, label %true_block22

true_block22:                                     ; preds = %after_if21
  %163 = load ptr, ptr %8, align 8
  %164 = getelementptr i64, ptr %163, i64 5
  %165 = load i64, ptr %164, align 8
  %166 = or i64 %165, 1
  store i64 %166, ptr %164, align 8
  br label %after_if24

after_if24:                                       ; preds = %true_block22, %after_if21
  %167 = load ptr, ptr %145, align 8
  store double %154, ptr %167, align 8
  %168 = load ptr, ptr %149, align 8
  %169 = getelementptr double, ptr %168, i64 1
  %170 = load double, ptr %169, align 8
  %171 = fdiv double %.013.lcssa, %24
  %172 = fadd double %171, %170
  %173 = select i1 %21, double %172, double 0.000000e+00
  %174 = bitcast double %173 to i64
  %175 = and i64 %174, 9223372036854775807
  %176 = and i64 %174, 9218868437227405312
  %177 = icmp eq i64 %175, 0
  %178 = icmp ne i64 %176, 0
  %179 = icmp ne i64 %176, 9218868437227405312
  %180 = and i1 %178, %179
  %181 = or i1 %177, %180
  br i1 %181, label %after_if27, label %true_block25

true_block25:                                     ; preds = %after_if24
  %182 = load ptr, ptr %8, align 8
  %183 = getelementptr i64, ptr %182, i64 5
  %184 = load i64, ptr %183, align 8
  %185 = or i64 %184, 1
  store i64 %185, ptr %183, align 8
  br label %after_if27

after_if27:                                       ; preds = %true_block25, %after_if24
  %186 = load ptr, ptr %145, align 8
  %187 = getelementptr double, ptr %186, i64 1
  store double %173, ptr %187, align 8
  %188 = load ptr, ptr %149, align 8
  %189 = getelementptr double, ptr %188, i64 2
  %190 = load double, ptr %189, align 8
  %191 = fdiv double %.011.lcssa, %24
  %192 = fadd double %191, %190
  %193 = select i1 %21, double %192, double 0.000000e+00
  %194 = bitcast double %193 to i64
  %195 = and i64 %194, 9223372036854775807
  %196 = and i64 %194, 9218868437227405312
  %197 = icmp eq i64 %195, 0
  %198 = icmp ne i64 %196, 0
  %199 = icmp ne i64 %196, 9218868437227405312
  %200 = and i1 %198, %199
  %201 = or i1 %197, %200
  br i1 %201, label %after_if30, label %true_block28

true_block28:                                     ; preds = %after_if27
  %202 = load ptr, ptr %8, align 8
  %203 = getelementptr i64, ptr %202, i64 5
  %204 = load i64, ptr %203, align 8
  %205 = or i64 %204, 1
  store i64 %205, ptr %203, align 8
  br label %after_if30

after_if30:                                       ; preds = %true_block28, %after_if27
  %206 = load ptr, ptr %145, align 8
  %207 = getelementptr double, ptr %206, i64 2
  store double %193, ptr %207, align 8
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #6

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn writeonly
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #7

; Function Attrs: noinline nounwind optnone uwtable
define internal fastcc void @taichi_assert_format(ptr noundef %0, i1 noundef zeroext %1, ptr noundef %2) unnamed_addr #8 {
  %4 = alloca ptr, align 8
  %5 = alloca i8, align 1
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca ptr, align 8
  %9 = alloca %class.anon, align 8
  store ptr %0, ptr %4, align 8
  %10 = zext i1 %1 to i8
  store i8 %10, ptr %5, align 1
  store ptr %2, ptr %6, align 8
  store i32 0, ptr %7, align 4
  store ptr null, ptr %8, align 8
  %11 = load i8, ptr %5, align 1
  %12 = trunc i8 %11 to i1
  %13 = zext i1 %12 to i32
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %15, label %16

15:                                               ; preds = %3
  br label %69

16:                                               ; preds = %3
  %17 = load ptr, ptr %4, align 8
  %18 = getelementptr inbounds %struct.LLVMRuntime, ptr %17, i32 0, i32 24
  %19 = load i64, ptr %18, align 8
  %20 = icmp ne i64 %19, 0
  br i1 %20, label %69, label %21

21:                                               ; preds = %16
  %22 = load ptr, ptr %4, align 8
  %23 = getelementptr inbounds %struct.LLVMRuntime, ptr %22, i32 0, i32 23
  %24 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 0
  store ptr %4, ptr %24, align 8
  %25 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 1
  store ptr %6, ptr %25, align 8
  %26 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 2
  store ptr %7, ptr %26, align 8
  %27 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 3
  store ptr %8, ptr %27, align 8
  br label %28

28:                                               ; preds = %28, %21
  %29 = atomicrmw volatile xchg ptr %23, i32 1 seq_cst, align 4
  %30 = icmp eq i32 %29, 1
  br i1 %30, label %28, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !8

mutex_lock_i32.exit.i.i.i:                        ; preds = %28
  %31 = load ptr, ptr %9, align 8
  %32 = load ptr, ptr %31, align 8
  %33 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 24
  %34 = load i64, ptr %33, align 8
  %.not.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i, label %35, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

35:                                               ; preds = %mutex_lock_i32.exit.i.i.i
  store i64 1, ptr %33, align 8
  %36 = load ptr, ptr %9, align 8
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr inbounds %struct.LLVMRuntime, ptr %37, i64 0, i32 21
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %38, i8 0, i64 2048, i1 false)
  %39 = load ptr, ptr %9, align 8
  %40 = load ptr, ptr %39, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 21
  %42 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 1
  %43 = load ptr, ptr %42, align 8
  %44 = load ptr, ptr %43, align 8
  %45 = load i8, ptr %44, align 1
  %.not5.i.i.i.i.i = icmp eq i8 %45, 0
  br i1 %.not5.i.i.i.i.i, label %taichi_strlen.exit.thread.i.i.i.i, label %.lr.ph.i.i.i.i.i.preheader

.lr.ph.i.i.i.i.i.preheader:                       ; preds = %35
  br label %.lr.ph.i.i.i.i.i

.lr.ph.i.i.i.i.i:                                 ; preds = %.lr.ph.i.i.i.i.i, %.lr.ph.i.i.i.i.i.preheader
  %.07.i.i.i.i.i = phi ptr [ %47, %.lr.ph.i.i.i.i.i ], [ %44, %.lr.ph.i.i.i.i.i.preheader ]
  %.046.i.i.i.i.i = phi i64 [ %46, %.lr.ph.i.i.i.i.i ], [ 0, %.lr.ph.i.i.i.i.i.preheader ]
  %46 = add i64 %.046.i.i.i.i.i, 1
  %47 = getelementptr inbounds i8, ptr %.07.i.i.i.i.i, i64 1
  %48 = load i8, ptr %47, align 1
  %.not.i.i.i.i.i = icmp eq i8 %48, 0
  br i1 %.not.i.i.i.i.i, label %taichi_strlen.exit.i.i.i.i, label %.lr.ph.i.i.i.i.i, !llvm.loop !14

taichi_strlen.exit.i.i.i.i:                       ; preds = %.lr.ph.i.i.i.i.i
  %.lcssa = phi i64 [ %46, %.lr.ph.i.i.i.i.i ]
  %49 = call i64 @llvm.umin.i64(i64 %.lcssa, i64 2047)
  br label %taichi_strlen.exit.thread.i.i.i.i

taichi_strlen.exit.thread.i.i.i.i:                ; preds = %taichi_strlen.exit.i.i.i.i, %35
  %50 = phi i64 [ 0, %35 ], [ %49, %taichi_strlen.exit.i.i.i.i ]
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %41, ptr nonnull align 1 %44, i64 %50, i1 false)
  %51 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 2
  %52 = load ptr, ptr %51, align 8
  %53 = load i32, ptr %52, align 4
  %54 = icmp sgt i32 %53, 0
  br i1 %54, label %.lr.ph.i.i.i.i, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

.lr.ph.i.i.i.i:                                   ; preds = %taichi_strlen.exit.thread.i.i.i.i
  %55 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 3
  br label %56

56:                                               ; preds = %56, %.lr.ph.i.i.i.i
  %indvars.iv.i.i.i.i = phi i64 [ 0, %.lr.ph.i.i.i.i ], [ %indvars.iv.next.i.i.i.i, %56 ]
  %57 = load ptr, ptr %55, align 8
  %58 = load ptr, ptr %57, align 8
  %59 = getelementptr inbounds i64, ptr %58, i64 %indvars.iv.i.i.i.i
  %60 = load i64, ptr %59, align 8
  %61 = load ptr, ptr %9, align 8
  %62 = load ptr, ptr %61, align 8
  %63 = getelementptr inbounds %struct.LLVMRuntime, ptr %62, i64 0, i32 22, i64 %indvars.iv.i.i.i.i
  store i64 %60, ptr %63, align 8
  %indvars.iv.next.i.i.i.i = add nuw nsw i64 %indvars.iv.i.i.i.i, 1
  %64 = load ptr, ptr %51, align 8
  %65 = load i32, ptr %64, align 4
  %66 = sext i32 %65 to i64
  %67 = icmp slt i64 %indvars.iv.next.i.i.i.i, %66
  br i1 %67, label %56, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", !llvm.loop !15

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit": ; preds = %56
  br label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit": ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", %taichi_strlen.exit.thread.i.i.i.i, %mutex_lock_i32.exit.i.i.i
  %68 = atomicrmw volatile xchg ptr %23, i32 0 seq_cst, align 4
  br label %69

69:                                               ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit", %16, %15
  ret void
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_struct_for_block_helper(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #9 {
_ZN11ListManager3getI7ElementEERT_i.exit:
  %3 = alloca %struct.RuntimeContext.2230, align 8
  %4 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 4
  %5 = load i32, ptr %4, align 4
  %6 = sdiv i32 %2, %5
  %7 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  %8 = load i32, ptr %7, align 8
  %9 = sdiv i32 %8, %5
  %10 = srem i32 %2, %5
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  %12 = load ptr, ptr %11, align 8
  %13 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %14 = load i32, ptr %13, align 8
  %15 = ashr i32 %6, %14
  %16 = sext i32 %15 to i64
  %17 = lshr i64 %16, 9
  %18 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %17
  %19 = load atomic i64, ptr %18 acquire, align 8
  %.not.i.i.i = icmp ne i64 %19, 0
  tail call void @llvm.assume(i1 %.not.i.i.i)
  %20 = inttoptr i64 %19 to ptr
  %21 = and i64 %16, 511
  %22 = getelementptr inbounds ptr, ptr %20, i64 %21
  %23 = load atomic i64, ptr %22 acquire, align 8
  %24 = inttoptr i64 %23 to ptr
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %26 = load i64, ptr %25, align 8
  %27 = load i32, ptr %13, align 8
  %notmask.i.i = shl nsw i32 -1, %27
  %28 = xor i32 %notmask.i.i, -1
  %29 = and i32 %6, %28
  %30 = sext i32 %29 to i64
  %31 = mul i64 %26, %30
  %32 = getelementptr inbounds i8, ptr %24, i64 %31
  %33 = getelementptr inbounds %0, ptr %32, i64 0, i32 1
  %34 = load i32, ptr %33, align 8
  %35 = mul nsw i32 %10, %9
  %36 = add nsw i32 %34, %35
  %37 = add nsw i32 %10, 1
  %38 = mul nsw i32 %37, %9
  %39 = add nsw i32 %34, %38
  %40 = getelementptr inbounds %0, ptr %32, i64 0, i32 1, i64 1
  %41 = load i32, ptr %40, align 4
  %42 = tail call i32 @llvm.smin.i32(i32 %41, i32 %39)
  %43 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  %44 = load i64, ptr %43, align 8
  %45 = alloca i8, i64 %44, align 8
  %46 = load ptr, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %3, ptr noundef nonnull align 8 dereferenceable(32) %46, i64 32, i1 false)
  %47 = getelementptr inbounds %struct.RuntimeContext.2230, ptr %3, i64 0, i32 2
  store i32 %1, ptr %47, align 8
  %48 = icmp slt i32 %36, %42
  br i1 %48, label %49, label %75

49:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit
  %50 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = load ptr, ptr %11, align 8
  %53 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 3
  %54 = load i32, ptr %53, align 8
  %55 = ashr i32 %6, %54
  %56 = sext i32 %55 to i64
  %57 = lshr i64 %56, 9
  %58 = getelementptr inbounds [256 x ptr], ptr %52, i64 0, i64 %57
  %59 = load atomic i64, ptr %58 acquire, align 8
  %.not.i.i.i24 = icmp eq i64 %59, 0
  br i1 %.not.i.i.i24, label %_ZN11ListManager3getI7ElementEERT_i.exit26, label %60

60:                                               ; preds = %49
  %61 = inttoptr i64 %59 to ptr
  %62 = and i64 %56, 511
  %63 = getelementptr inbounds ptr, ptr %61, i64 %62
  %64 = load atomic i64, ptr %63 acquire, align 8
  %65 = inttoptr i64 %64 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit26

_ZN11ListManager3getI7ElementEERT_i.exit26:       ; preds = %60, %49
  %66 = phi ptr [ %65, %60 ], [ null, %49 ]
  %67 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 1
  %68 = load i64, ptr %67, align 8
  %69 = load i32, ptr %53, align 8
  %notmask.i.i25 = shl nsw i32 -1, %69
  %70 = xor i32 %notmask.i.i25, -1
  %71 = and i32 %6, %70
  %72 = sext i32 %71 to i64
  %73 = mul i64 %68, %72
  %74 = getelementptr inbounds i8, ptr %66, i64 %73
  call void %51(ptr noundef nonnull %3, ptr noundef nonnull %45, ptr noundef nonnull %74, i32 noundef %36, i32 noundef %42) #1
  br label %75

75:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit26, %_ZN11ListManager3getI7ElementEERT_i.exit
  ret void
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_parallel_range_for_task(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #9 {
  %4 = alloca %struct.RuntimeContext.2230, align 8
  %.sroa.0.0.copyload = load ptr, ptr %0, align 8
  %.sroa.4.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 8
  %.sroa.4.0.copyload = load ptr, ptr %.sroa.4.0..sroa_idx, align 8
  %.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 16
  %.sroa.5.0.copyload = load ptr, ptr %.sroa.5.0..sroa_idx, align 8
  %.sroa.7.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 24
  %.sroa.7.0.copyload = load ptr, ptr %.sroa.7.0..sroa_idx, align 8
  %.sroa.8.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 32
  %.sroa.8.0.copyload = load i64, ptr %.sroa.8.0..sroa_idx, align 8
  %.sroa.9.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 40
  %.sroa.9.0.copyload = load i32, ptr %.sroa.9.0..sroa_idx, align 8
  %.sroa.12.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 44
  %.sroa.12.0.copyload = load i32, ptr %.sroa.12.0..sroa_idx, align 4
  %.sroa.15.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 48
  %.sroa.15.0.copyload = load i32, ptr %.sroa.15.0..sroa_idx, align 8
  %.sroa.17.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 52
  %.sroa.17.0.copyload = load i32, ptr %.sroa.17.0..sroa_idx, align 4
  %5 = alloca i8, i64 %.sroa.8.0.copyload, align 8
  %.not = icmp eq ptr %.sroa.4.0.copyload, null
  br i1 %.not, label %7, label %6

6:                                                ; preds = %3
  call void %.sroa.4.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %7

7:                                                ; preds = %6, %3
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %4, ptr noundef nonnull align 8 dereferenceable(32) %.sroa.0.0.copyload, i64 32, i1 false)
  %8 = getelementptr inbounds %struct.RuntimeContext.2230, ptr %4, i64 0, i32 2
  store i32 %1, ptr %8, align 8
  switch i32 %.sroa.17.0.copyload, label %.loopexit [
    i32 1, label %9
    i32 -1, label %17
  ]

9:                                                ; preds = %7
  %10 = mul nsw i32 %.sroa.15.0.copyload, %2
  %11 = add nsw i32 %10, %.sroa.9.0.copyload
  %12 = add nsw i32 %11, %.sroa.15.0.copyload
  %13 = call i32 @llvm.smin.i32(i32 %.sroa.12.0.copyload, i32 %12)
  %14 = icmp slt i32 %11, %13
  br i1 %14, label %.lr.ph.preheader, label %.loopexit

.lr.ph.preheader:                                 ; preds = %9
  br label %.lr.ph

.lr.ph:                                           ; preds = %.lr.ph, %.lr.ph.preheader
  %.02039 = phi i32 [ %15, %.lr.ph ], [ %11, %.lr.ph.preheader ]
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.02039) #1
  %15 = add nsw i32 %.02039, 1
  %16 = icmp slt i32 %15, %13
  br i1 %16, label %.lr.ph, label %.loopexit.loopexit, !llvm.loop !16

17:                                               ; preds = %7
  %18 = mul nsw i32 %.sroa.15.0.copyload, %2
  %19 = sub nsw i32 %.sroa.12.0.copyload, %18
  %20 = mul nsw i32 %19, %.sroa.15.0.copyload
  %21 = call i32 @llvm.smax.i32(i32 %.sroa.9.0.copyload, i32 %20)
  %.not25.not40 = icmp sgt i32 %19, %21
  br i1 %.not25.not40, label %.lr.ph42.preheader, label %.loopexit

.lr.ph42.preheader:                               ; preds = %17
  br label %.lr.ph42

.lr.ph42:                                         ; preds = %.lr.ph42, %.lr.ph42.preheader
  %.0.in41 = phi i32 [ %.0, %.lr.ph42 ], [ %19, %.lr.ph42.preheader ]
  %.0 = add nsw i32 %.0.in41, -1
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.0) #1
  %.not25.not = icmp sgt i32 %.0, %21
  br i1 %.not25.not, label %.lr.ph42, label %.loopexit.loopexit47, !llvm.loop !17

.loopexit.loopexit:                               ; preds = %.lr.ph
  br label %.loopexit

.loopexit.loopexit47:                             ; preds = %.lr.ph42
  br label %.loopexit

.loopexit:                                        ; preds = %.loopexit.loopexit47, %.loopexit.loopexit, %17, %9, %7
  %.not24 = icmp eq ptr %.sroa.7.0.copyload, null
  br i1 %.not24, label %23, label %22

22:                                               ; preds = %.loopexit
  call void %.sroa.7.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %23

23:                                               ; preds = %22, %.loopexit
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #10

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smax.i32(i32, i32) #10

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #11

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #11

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i64 @llvm.umin.i64(i64, i64) #12

; Function Attrs: inaccessiblememonly nocallback nofree nosync nounwind willreturn
declare void @llvm.assume(i1 noundef) #13

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { nofree nosync nounwind }
attributes #3 = { nofree norecurse nounwind }
attributes #4 = { nofree norecurse nosync nounwind }
attributes #5 = { nofree nounwind }
attributes #6 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #7 = { argmemonly mustprogress nocallback nofree nounwind willreturn writeonly }
attributes #8 = { noinline nounwind optnone uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #11 = { argmemonly nocallback nofree nosync nounwind willreturn }
attributes #12 = { nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #13 = { inaccessiblememonly nocallback nofree nosync nounwind willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.unroll.disable"}
!8 = distinct !{!8, !9, !7}
!9 = !{!"llvm.loop.mustprogress"}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
!13 = distinct !{!13, !7}
!14 = distinct !{!14, !9, !7}
!15 = distinct !{!15, !9, !7}
!16 = distinct !{!16, !9, !7}
!17 = distinct !{!17, !9, !7}
