; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%0 = type { ptr, [2 x i32], %struct.PhysicalCoordinates.712 }
%struct.RuntimeContext.699 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }
%struct.ListManager = type { [256 x ptr], i64, i64, i32, i32, i32, ptr }
%struct.PhysicalCoordinates.712 = type { [12 x i32] }
%struct.cpu_block_task_helper_context = type { ptr, ptr, ptr, i32, i32, i64 }
%class.anon = type { ptr, ptr, ptr, ptr }

@.str = private unnamed_addr constant [28 x i8] c"Out of pre-allocated memory\00", align 1
@.str.2 = private unnamed_addr constant [28 x i8] c"List manager out of chunks.\00", align 1

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @field_contact_25_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %0, i64 0, i32 3
  %2 = load double, ptr %1, align 8
  %3 = getelementptr inbounds %struct.RuntimeContext.699, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  store double %2, ptr %6, align 8
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @field_contact_25_kernel_1_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.699, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 24
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @field_contact_25_kernel_2_listgen_S24pointer(ptr %context) local_unnamed_addr #1 {
.lr.ph.i:
  %.sroa.2.i = alloca { [2 x i32], %struct.PhysicalCoordinates.712 }, align 8
  %0 = alloca %0, align 8
  %1 = getelementptr inbounds %struct.RuntimeContext.699, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 23
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %4, i64 24
  %8 = load ptr, ptr %7, align 8
  %9 = load atomic i64, ptr %6 acquire, align 8
  %.not.i.i.i.i = icmp ne i64 %9, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i)
  %10 = inttoptr i64 %9 to ptr
  %11 = load atomic i64, ptr %10 acquire, align 8
  %12 = inttoptr i64 %11 to ptr
  %.sroa.0.0.copyload.i = load ptr, ptr %12, align 8
  %.sroa.2.0..sroa_idx.i = getelementptr inbounds i8, ptr %12, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.i, ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.0..sroa_idx.i, i64 56, i1 false)
  %13 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %.sroa.2.16.sroa_idx.i = getelementptr inbounds i8, ptr %.sroa.2.i, i64 8
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %16 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 4
  %17 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 6
  %18 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 2
  %19 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  store ptr %.sroa.0.0.copyload.i, ptr %0, align 8
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %0, i64 8
  store <2 x i32> <i32 0, i32 4>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %13, ptr noundef nonnull align 8 dereferenceable(48) %.sroa.2.16.sroa_idx.i, i64 48, i1 false)
  %20 = atomicrmw volatile add ptr %14, i32 1 seq_cst, align 4
  %21 = load i32, ptr %15, align 8
  %22 = ashr i32 %20, %21
  %23 = icmp ugt i32 %22, 131071
  br i1 %23, label %24, label %26

24:                                               ; preds = %.lr.ph.i
  %25 = load ptr, ptr %17, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %25, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

26:                                               ; preds = %.lr.ph.i
  %27 = zext i32 %22 to i64
  %28 = lshr i64 %27, 9
  %29 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %28
  %30 = load atomic i64, ptr %29 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %30, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %26
  %31 = inttoptr i64 %30 to ptr
  %32 = and i64 %27, 511
  %33 = getelementptr inbounds ptr, ptr %31, i64 %32
  %34 = load atomic i64, ptr %33 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %26
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %35 = atomicrmw volatile xchg ptr %16, i32 1 seq_cst, align 4
  %36 = icmp eq i32 %35, 1
  br i1 %36, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %37 = load atomic i64, ptr %29 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %37, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %39, label %73

39:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %40 = load ptr, ptr %17, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1
  %42 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 28
  %43 = atomicrmw volatile add ptr %42, i64 4096 seq_cst, align 8
  %44 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 2
  %45 = load i64, ptr %44, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %45, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %66, label %46

46:                                               ; preds = %39
  %47 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 26
  br label %48

48:                                               ; preds = %48, %46
  %49 = atomicrmw volatile xchg ptr %47, i32 1 seq_cst, align 4
  %50 = icmp eq i32 %49, 1
  br i1 %50, label %48, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %48
  %51 = load ptr, ptr %41, align 8
  %52 = ptrtoint ptr %51 to i64
  %53 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 1
  %54 = load ptr, ptr %53, align 8
  %55 = ptrtoint ptr %54 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %52
  %56 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %57 = or i64 %56, 4096
  %58 = add i64 %57, %52
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %58, %55
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %59

59:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %60 = add i64 %56, %52
  %61 = inttoptr i64 %60 to ptr
  %62 = getelementptr i8, ptr %51, i64 %56
  %63 = getelementptr inbounds i8, ptr %62, i64 4096
  store ptr %63, ptr %41, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %59, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %61, %59 ]
  %64 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %65 = atomicrmw volatile xchg ptr %47, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %40, i1 noundef zeroext %64, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

66:                                               ; preds = %39
  %67 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 2
  %68 = load ptr, ptr %67, align 8
  %69 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 6
  %70 = load ptr, ptr %69, align 8
  %71 = tail call noundef ptr %68(ptr noundef %70, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %66, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %71, %66 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %72 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %72, ptr %29 release, align 8
  br label %73

73:                                               ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %38, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %74 = and i32 %22, 511
  %75 = zext i32 %74 to i64
  %76 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %75
  %77 = load atomic i64, ptr %76 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %77, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %78, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

78:                                               ; preds = %73
  %79 = load ptr, ptr %17, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1
  %81 = load i64, ptr %18, align 8
  %82 = load i64, ptr %19, align 8
  %83 = mul i64 %82, %81
  %84 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 28
  %85 = atomicrmw volatile add ptr %84, i64 %83 seq_cst, align 8
  %86 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 2
  %87 = load i64, ptr %86, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %87, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %107, label %88

88:                                               ; preds = %78
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 26
  br label %90

90:                                               ; preds = %90, %88
  %91 = atomicrmw volatile xchg ptr %89, i32 1 seq_cst, align 4
  %92 = icmp eq i32 %91, 1
  br i1 %92, label %90, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %90
  %93 = load ptr, ptr %80, align 8
  %94 = ptrtoint ptr %93 to i64
  %95 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 1
  %96 = load ptr, ptr %95, align 8
  %97 = ptrtoint ptr %96 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %94
  %98 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %99 = add i64 %98, %83
  %100 = add i64 %99, %94
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %100, %97
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %101

101:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %102 = add i64 %98, %94
  %103 = inttoptr i64 %102 to ptr
  %104 = getelementptr inbounds i8, ptr %93, i64 %99
  store ptr %104, ptr %80, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %101, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %103, %101 ]
  %105 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %106 = atomicrmw volatile xchg ptr %89, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %79, i1 noundef zeroext %105, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

107:                                              ; preds = %78
  %108 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 2
  %109 = load ptr, ptr %108, align 8
  %110 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 6
  %111 = load ptr, ptr %110, align 8
  %112 = tail call noundef ptr %109(ptr noundef %111, i64 noundef %83, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %107, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %112, %107 ]
  %113 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %113, ptr %76 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %73
  %114 = atomicrmw volatile xchg ptr %16, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %24
  %115 = load i32, ptr %15, align 8
  %116 = ashr i32 %20, %115
  %117 = sext i32 %116 to i64
  %118 = lshr i64 %117, 9
  %119 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %118
  %120 = load atomic i64, ptr %119 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %120, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %121

121:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %122 = inttoptr i64 %120 to ptr
  %123 = and i64 %117, 511
  %124 = getelementptr inbounds ptr, ptr %122, i64 %123
  %125 = load atomic i64, ptr %124 acquire, align 8
  %126 = inttoptr i64 %125 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %121, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %127 = phi ptr [ %126, %121 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %128 = load i64, ptr %19, align 8
  %129 = load i32, ptr %15, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %129
  %130 = xor i32 %notmask.i.i.i.i, -1
  %131 = and i32 %20, %130
  %132 = sext i32 %131 to i64
  %133 = mul i64 %128, %132
  %134 = getelementptr inbounds i8, ptr %127, i64 %133
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %134, ptr nonnull align 8 %0, i64 %128, i1 false)
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @field_contact_25_kernel_3_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.699, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 25
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @field_contact_25_kernel_4_listgen_S25bitmasked(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %0, align 8
  %1 = alloca %struct.PhysicalCoordinates.712, align 4
  %2 = alloca %0, align 8
  %3 = getelementptr inbounds %struct.RuntimeContext.699, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %2)
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 13
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %6, i64 24
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %10 = load i32, ptr %9, align 8
  %11 = getelementptr inbounds ptr, ptr %6, i64 25
  %12 = load ptr, ptr %11, align 8
  %13 = icmp sgt i32 %10, 0
  br i1 %13, label %.lr.ph61.i, label %element_listgen_nonroot.exit

.lr.ph61.i:                                       ; preds = %entry
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  %16 = getelementptr inbounds %0, ptr %0, i64 0, i32 1
  %17 = getelementptr inbounds %0, ptr %0, i64 0, i32 1, i64 1
  %18 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %19 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %20 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 5
  %21 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %22 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 4
  %23 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 6
  %24 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 2
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %2, i64 8
  br label %26

26:                                               ; preds = %._crit_edge.i, %.lr.ph61.i
  %.04359.i = phi i32 [ 0, %.lr.ph61.i ], [ %172, %._crit_edge.i ]
  %27 = load i32, ptr %14, align 8
  %28 = lshr i32 %.04359.i, %27
  %29 = sext i32 %28 to i64
  %30 = lshr i64 %29, 9
  %31 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %30
  %32 = load atomic i64, ptr %31 acquire, align 8
  %.not.i.i.i.i = icmp eq i64 %32, 0
  br i1 %.not.i.i.i.i, label %_ZN11ListManager3getI7ElementEERT_i.exit.i, label %33

33:                                               ; preds = %26
  %34 = inttoptr i64 %32 to ptr
  %35 = and i64 %29, 511
  %36 = getelementptr inbounds ptr, ptr %34, i64 %35
  %37 = load atomic i64, ptr %36 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit.i

_ZN11ListManager3getI7ElementEERT_i.exit.i:       ; preds = %33, %26
  %39 = phi ptr [ %38, %33 ], [ null, %26 ]
  %40 = load i64, ptr %15, align 8
  %41 = load i32, ptr %14, align 8
  %notmask.i.i.i = shl nsw i32 -1, %41
  %42 = xor i32 %notmask.i.i.i, -1
  %43 = and i32 %.04359.i, %42
  %44 = zext i32 %43 to i64
  %45 = mul i64 %40, %44
  %46 = getelementptr inbounds i8, ptr %39, i64 %45
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %0, ptr noundef nonnull align 8 dereferenceable(64) %46, i64 64, i1 false)
  %47 = load i32, ptr %16, align 8
  %48 = load i32, ptr %17, align 4
  %49 = icmp slt i32 %47, %48
  br i1 %49, label %.lr.ph58.i.preheader, label %._crit_edge.i

.lr.ph58.i.preheader:                             ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit.i
  br label %.lr.ph58.i

.lr.ph58.i:                                       ; preds = %.loopexit.i, %.lr.ph58.i.preheader
  %.04457.i = phi i32 [ %171, %.loopexit.i ], [ %47, %.lr.ph58.i.preheader ]
  call fastcc void @S24_refine_coordinates(ptr noundef nonnull %18, ptr noundef nonnull %1, i32 noundef %.04457.i) #1
  %50 = load ptr, ptr %0, align 8
  %51 = shl i32 %.04457.i, 3
  %52 = sext i32 %51 to i64
  %53 = getelementptr i8, ptr %50, i64 %52
  %54 = getelementptr inbounds i8, ptr %53, i64 32
  %55 = load ptr, ptr %54, align 8
  %.not = icmp eq ptr %55, null
  br i1 %.not, label %.loopexit.i, label %.lr.ph.i

.lr.ph.i:                                         ; preds = %.lr.ph58.i
  store ptr %55, ptr %2, align 8
  store <2 x i32> <i32 0, i32 32>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %19, ptr noundef nonnull align 4 dereferenceable(48) %1, i64 48, i1 false)
  %56 = atomicrmw volatile add ptr %20, i32 1 seq_cst, align 4
  %57 = load i32, ptr %21, align 8
  %58 = ashr i32 %56, %57
  %59 = icmp ugt i32 %58, 131071
  br i1 %59, label %60, label %62

60:                                               ; preds = %.lr.ph.i
  %61 = load ptr, ptr %23, align 8
  call fastcc void @taichi_assert_format(ptr noundef %61, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

62:                                               ; preds = %.lr.ph.i
  %63 = zext i32 %58 to i64
  %64 = lshr i64 %63, 9
  %65 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %64
  %66 = load atomic i64, ptr %65 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %66, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %62
  %67 = inttoptr i64 %66 to ptr
  %68 = and i64 %63, 511
  %69 = getelementptr inbounds ptr, ptr %67, i64 %68
  %70 = load atomic i64, ptr %69 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %70, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %62
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %71 = atomicrmw volatile xchg ptr %22, i32 1 seq_cst, align 4
  %72 = icmp eq i32 %71, 1
  br i1 %72, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %73 = load atomic i64, ptr %65 acquire, align 8
  %74 = inttoptr i64 %73 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %73, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %75, label %109

75:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %76 = load ptr, ptr %23, align 8
  %77 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1
  %78 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 28
  %79 = atomicrmw volatile add ptr %78, i64 4096 seq_cst, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 2
  %81 = load i64, ptr %80, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %81, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %102, label %82

82:                                               ; preds = %75
  %83 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 26
  br label %84

84:                                               ; preds = %84, %82
  %85 = atomicrmw volatile xchg ptr %83, i32 1 seq_cst, align 4
  %86 = icmp eq i32 %85, 1
  br i1 %86, label %84, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %84
  %87 = load ptr, ptr %77, align 8
  %88 = ptrtoint ptr %87 to i64
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 1
  %90 = load ptr, ptr %89, align 8
  %91 = ptrtoint ptr %90 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %88
  %92 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %93 = or i64 %92, 4096
  %94 = add i64 %93, %88
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %94, %91
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %95

95:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %96 = add i64 %92, %88
  %97 = inttoptr i64 %96 to ptr
  %98 = getelementptr i8, ptr %87, i64 %92
  %99 = getelementptr inbounds i8, ptr %98, i64 4096
  store ptr %99, ptr %77, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %95, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %97, %95 ]
  %100 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %101 = atomicrmw volatile xchg ptr %83, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %76, i1 noundef zeroext %100, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

102:                                              ; preds = %75
  %103 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 2
  %104 = load ptr, ptr %103, align 8
  %105 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 6
  %106 = load ptr, ptr %105, align 8
  %107 = call noundef ptr %104(ptr noundef %106, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %102, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %107, %102 ]
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %108 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %108, ptr %65 release, align 8
  br label %109

109:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %74, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %110 = and i32 %58, 511
  %111 = zext i32 %110 to i64
  %112 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %111
  %113 = load atomic i64, ptr %112 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %113, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %114, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

114:                                              ; preds = %109
  %115 = load ptr, ptr %23, align 8
  %116 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1
  %117 = load i64, ptr %24, align 8
  %118 = load i64, ptr %25, align 8
  %119 = mul i64 %118, %117
  %120 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 28
  %121 = atomicrmw volatile add ptr %120, i64 %119 seq_cst, align 8
  %122 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 2
  %123 = load i64, ptr %122, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %123, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %143, label %124

124:                                              ; preds = %114
  %125 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 26
  br label %126

126:                                              ; preds = %126, %124
  %127 = atomicrmw volatile xchg ptr %125, i32 1 seq_cst, align 4
  %128 = icmp eq i32 %127, 1
  br i1 %128, label %126, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %126
  %129 = load ptr, ptr %116, align 8
  %130 = ptrtoint ptr %129 to i64
  %131 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 1
  %132 = load ptr, ptr %131, align 8
  %133 = ptrtoint ptr %132 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %130
  %134 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %135 = add i64 %134, %119
  %136 = add i64 %135, %130
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %136, %133
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %137

137:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %138 = add i64 %134, %130
  %139 = inttoptr i64 %138 to ptr
  %140 = getelementptr inbounds i8, ptr %129, i64 %135
  store ptr %140, ptr %116, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %137, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %139, %137 ]
  %141 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %142 = atomicrmw volatile xchg ptr %125, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %115, i1 noundef zeroext %141, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

143:                                              ; preds = %114
  %144 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 2
  %145 = load ptr, ptr %144, align 8
  %146 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 6
  %147 = load ptr, ptr %146, align 8
  %148 = call noundef ptr %145(ptr noundef %147, i64 noundef %119, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %143, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %148, %143 ]
  %149 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %149, ptr %112 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %109
  %150 = atomicrmw volatile xchg ptr %22, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %60
  %151 = load i32, ptr %21, align 8
  %152 = ashr i32 %56, %151
  %153 = sext i32 %152 to i64
  %154 = lshr i64 %153, 9
  %155 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %154
  %156 = load atomic i64, ptr %155 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %156, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %157

157:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %158 = inttoptr i64 %156 to ptr
  %159 = and i64 %153, 511
  %160 = getelementptr inbounds ptr, ptr %158, i64 %159
  %161 = load atomic i64, ptr %160 acquire, align 8
  %162 = inttoptr i64 %161 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %157, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %163 = phi ptr [ %162, %157 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %164 = load i64, ptr %25, align 8
  %165 = load i32, ptr %21, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %165
  %166 = xor i32 %notmask.i.i.i.i, -1
  %167 = and i32 %56, %166
  %168 = sext i32 %167 to i64
  %169 = mul i64 %164, %168
  %170 = getelementptr inbounds i8, ptr %163, i64 %169
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %170, ptr nonnull align 8 %2, i64 %164, i1 false)
  br label %.loopexit.i, !llvm.loop !9

.loopexit.i:                                      ; preds = %_ZN11ListManager6appendEPv.exit.i, %.lr.ph58.i
  %171 = add i32 %.04457.i, 1
  %exitcond.not.i = icmp eq i32 %171, %48
  br i1 %exitcond.not.i, label %._crit_edge.i.loopexit, label %.lr.ph58.i, !llvm.loop !10

._crit_edge.i.loopexit:                           ; preds = %.loopexit.i
  br label %._crit_edge.i

._crit_edge.i:                                    ; preds = %._crit_edge.i.loopexit, %_ZN11ListManager3getI7ElementEERT_i.exit.i
  %172 = add nuw nsw i32 %.04359.i, 1
  %exitcond63.not.i = icmp eq i32 %172, %10
  br i1 %exitcond63.not.i, label %element_listgen_nonroot.exit.loopexit, label %26, !llvm.loop !11

element_listgen_nonroot.exit.loopexit:            ; preds = %._crit_edge.i
  br label %element_listgen_nonroot.exit

element_listgen_nonroot.exit:                     ; preds = %element_listgen_nonroot.exit.loopexit, %entry
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %2)
  ret void
}

; Function Attrs: nounwind
define void @field_contact_25_kernel_5_struct_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.cpu_block_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.RuntimeContext.699, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 25
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds %struct.ListManager, ptr %6, i64 0, i32 5
  %8 = load i32, ptr %7, align 8
  store ptr %context, ptr %0, align 8
  %9 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  store ptr @function_body, ptr %9, align 8
  %10 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  store ptr %6, ptr %10, align 8
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  store <2 x i32> <i32 32, i32 8>, ptr %11, align 8
  %12 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  store i64 1, ptr %12, align 8
  %13 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 12
  %14 = load ptr, ptr %13, align 8
  %15 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 11
  %16 = load ptr, ptr %15, align 8
  %17 = shl nsw i32 %8, 3
  call void %14(ptr noundef %16, i32 noundef %17, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_struct_for_block_helper) #1
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body(ptr %0, ptr nocapture readnone %1, ptr nocapture readonly %2, i32 %3, i32 %4) #2 {
allocs:
  %5 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %6 = icmp slt i32 %3, %4
  br i1 %6, label %loop_body.lr.ph, label %func_exit

loop_body.lr.ph:                                  ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.699, ptr %0, i64 0, i32 1
  br label %loop_body

loop_body:                                        ; preds = %loop_body_tail, %loop_body.lr.ph
  %.01135 = phi i32 [ %3, %loop_body.lr.ph ], [ %18, %loop_body_tail ]
  %8 = load ptr, ptr %2, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 32
  %10 = sdiv i32 %.01135, 8
  %11 = sext i32 %10 to i64
  %12 = getelementptr inbounds i8, ptr %9, i64 %11
  %13 = load i8, ptr %12, align 1
  %14 = zext i8 %13 to i32
  %15 = and i32 %.01135, 7
  %16 = shl nuw nsw i32 1, %15
  %17 = and i32 %16, %14
  %.not = icmp eq i32 %17, 0
  br i1 %.not, label %loop_body_tail, label %struct_for_body_body

loop_body_tail.loopexit:                          ; preds = %after_if32
  br label %loop_body_tail

loop_body_tail:                                   ; preds = %after_for, %loop_body_tail.loopexit, %loop_body
  %18 = add nsw i32 %.01135, 1
  %exitcond42.not = icmp eq i32 %18, %4
  br i1 %exitcond42.not, label %func_exit.loopexit, label %loop_body

func_exit.loopexit:                               ; preds = %loop_body_tail
  br label %func_exit

func_exit:                                        ; preds = %func_exit.loopexit, %allocs
  ret void

struct_for_body_body:                             ; preds = %loop_body
  %19 = load i32, ptr %5, align 4
  %20 = shl i32 %19, 5
  %21 = and i32 %.01135, 31
  %22 = or i32 %20, %21
  %23 = load ptr, ptr %0, align 8
  %24 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %23, i64 0, i32 6, i32 1
  %25 = load ptr, ptr %24, align 8
  %26 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %23, i64 0, i32 6, i32 0, i32 1
  %27 = load i32, ptr %26, align 4
  %28 = sext i32 %27 to i64
  %29 = sext i32 %22 to i64
  %30 = getelementptr i32, ptr %25, i64 %29
  %31 = load i32, ptr %30, align 4
  %32 = add nsw i64 %28, %29
  %33 = getelementptr i32, ptr %25, i64 %32
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %23, i64 0, i32 5, i32 1
  %36 = load ptr, ptr %35, align 8
  %37 = getelementptr i64, ptr %36, i64 3
  %38 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %23, i64 0, i32 1, i32 1
  %39 = load ptr, ptr %38, align 8
  %40 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %23, i64 0, i32 1, i32 0, i32 1
  %41 = load i32, ptr %40, align 4
  %42 = sext i32 %41 to i64
  %43 = shl nsw i64 %42, 3
  %44 = add nsw i64 %43, %29
  %45 = getelementptr double, ptr %39, i64 %44
  %46 = mul nsw i64 %42, 9
  %47 = add nsw i64 %46, %29
  %48 = getelementptr double, ptr %39, i64 %47
  %49 = mul nsw i64 %42, 10
  %50 = add nsw i64 %49, %29
  %51 = getelementptr double, ptr %39, i64 %50
  %52 = icmp slt i32 %31, %34
  br i1 %52, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %struct_for_body_body
  %53 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %23, i64 0, i32 7, i32 1
  %54 = getelementptr { { i32, i32 }, ptr }, ptr %23, i64 0, i32 1
  %55 = getelementptr { { i32, i32 }, ptr }, ptr %23, i64 0, i32 0, i32 1
  %56 = sext i32 %31 to i64
  %wide.trip.count = sext i32 %34 to i64
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if12, %for_loop_body.lr.ph
  %indvars.iv = phi i64 [ %56, %for_loop_body.lr.ph ], [ %indvars.iv.next, %after_if12 ]
  %57 = load ptr, ptr %53, align 8
  %58 = shl i64 %indvars.iv, 2
  %uglygep = getelementptr i8, ptr %57, i64 %58
  %59 = load i32, ptr %uglygep, align 4
  %60 = load ptr, ptr %54, align 8
  %61 = load i32, ptr %55, align 4
  %62 = sext i32 %61 to i64
  %63 = sext i32 %59 to i64
  %64 = getelementptr i32, ptr %60, i64 %63
  %65 = load i32, ptr %64, align 4
  %66 = add nsw i64 %62, %63
  %67 = getelementptr i32, ptr %60, i64 %66
  %68 = load i32, ptr %67, align 4
  %69 = atomicrmw add ptr %37, i64 1 seq_cst, align 8
  %70 = load ptr, ptr %38, align 8
  %71 = load i32, ptr %40, align 4
  %72 = sext i32 %71 to i64
  %73 = sext i32 %68 to i64
  %74 = getelementptr double, ptr %70, i64 %73
  %75 = load double, ptr %74, align 8
  %76 = sext i32 %65 to i64
  %77 = getelementptr double, ptr %70, i64 %76
  %78 = load double, ptr %77, align 8
  %79 = fsub double %75, %78
  %80 = add nsw i64 %72, %73
  %81 = getelementptr double, ptr %70, i64 %80
  %82 = load double, ptr %81, align 8
  %83 = add nsw i64 %72, %76
  %84 = getelementptr double, ptr %70, i64 %83
  %85 = load double, ptr %84, align 8
  %86 = fsub double %82, %85
  %87 = shl nsw i64 %72, 1
  %88 = add nsw i64 %87, %73
  %89 = getelementptr double, ptr %70, i64 %88
  %90 = load double, ptr %89, align 8
  %91 = add nsw i64 %87, %76
  %92 = getelementptr double, ptr %70, i64 %91
  %93 = load double, ptr %92, align 8
  %94 = fsub double %90, %93
  %95 = mul nsw i64 %72, 7
  %96 = add nsw i64 %95, %76
  %97 = getelementptr double, ptr %70, i64 %96
  %98 = load double, ptr %97, align 8
  %99 = add nsw i64 %95, %73
  %100 = getelementptr double, ptr %70, i64 %99
  %101 = load double, ptr %100, align 8
  %102 = fmul double %79, %79
  %103 = fmul double %86, %86
  %104 = fadd double %102, %103
  %105 = fmul double %94, %94
  %106 = fadd double %104, %105
  %107 = fcmp ogt double %106, 0.000000e+00
  %.0.i12 = select i1 %107, double 1.000000e+00, double 0.000000e+00
  %108 = fsub double 1.000000e+00, %.0.i12
  %109 = fadd double %106, %108
  %sqrt = tail call double @llvm.sqrt.f64(double %109)
  %110 = fdiv double 1.000000e+00, %sqrt
  %111 = fmul double %109, %110
  %112 = fadd double %98, %101
  %113 = fsub double %112, %111
  %114 = tail call double @llvm.maxnum.f64(double %113, double 0.000000e+00)
  %115 = bitcast double %106 to i64
  %116 = and i64 %115, 9223372036854775807
  %117 = and i64 %115, 9218868437227405312
  %118 = icmp eq i64 %116, 0
  %119 = icmp ne i64 %117, 0
  %120 = icmp ne i64 %117, 9218868437227405312
  %121 = and i1 %119, %120
  %122 = or i1 %118, %121
  br i1 %122, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if12
  %.pre = load ptr, ptr %0, align 8
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %struct_for_body_body
  %123 = phi ptr [ %.pre, %after_for.loopexit ], [ %23, %struct_for_body_body ]
  %124 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %123, i64 0, i32 8, i32 1
  %125 = load ptr, ptr %124, align 8
  %126 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %123, i64 0, i32 8, i32 0, i32 1
  %127 = load i32, ptr %126, align 4
  %128 = sext i32 %127 to i64
  %129 = getelementptr i32, ptr %125, i64 %29
  %130 = load i32, ptr %129, align 4
  %131 = add nsw i64 %128, %29
  %132 = getelementptr i32, ptr %125, i64 %131
  %133 = load i32, ptr %132, align 4
  %134 = icmp slt i32 %130, %133
  br i1 %134, label %for_loop_body13.lr.ph, label %loop_body_tail

for_loop_body13.lr.ph:                            ; preds = %after_for
  %135 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %123, i64 0, i32 9, i32 1
  %136 = getelementptr { { i32, i32 }, ptr }, ptr %23, i64 0, i32 1
  %137 = getelementptr { { i32, i32 }, ptr }, ptr %23, i64 0, i32 0, i32 1
  %138 = sext i32 %130 to i64
  %wide.trip.count40 = sext i32 %133 to i64
  br label %for_loop_body13

true_block:                                       ; preds = %for_loop_body
  %139 = load ptr, ptr %35, align 8
  %140 = getelementptr i64, ptr %139, i64 19
  %141 = atomicrmw add ptr %140, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %142 = bitcast double %110 to i64
  %143 = and i64 %142, 9223372036854775807
  %144 = and i64 %142, 9218868437227405312
  %145 = icmp eq i64 %143, 0
  %146 = icmp ne i64 %144, 0
  %147 = icmp ne i64 %144, 9218868437227405312
  %148 = and i1 %146, %147
  %149 = or i1 %145, %148
  br i1 %149, label %after_if3, label %true_block1

true_block1:                                      ; preds = %after_if
  %150 = load ptr, ptr %35, align 8
  %151 = getelementptr i64, ptr %150, i64 19
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if3

after_if3:                                        ; preds = %true_block1, %after_if
  %153 = bitcast double %111 to i64
  %154 = and i64 %153, 9223372036854775807
  %155 = and i64 %153, 9218868437227405312
  %156 = icmp eq i64 %154, 0
  %157 = icmp ne i64 %155, 0
  %158 = icmp ne i64 %155, 9218868437227405312
  %159 = and i1 %157, %158
  %160 = or i1 %156, %159
  br i1 %160, label %after_if6, label %true_block4

true_block4:                                      ; preds = %after_if3
  %161 = load ptr, ptr %35, align 8
  %162 = getelementptr i64, ptr %161, i64 19
  %163 = atomicrmw add ptr %162, i64 1 seq_cst, align 8
  br label %after_if6

after_if6:                                        ; preds = %true_block4, %after_if3
  %164 = bitcast double %112 to i64
  %165 = and i64 %164, 9223372036854775807
  %166 = and i64 %164, 9218868437227405312
  %167 = icmp eq i64 %165, 0
  %168 = icmp ne i64 %166, 0
  %169 = icmp ne i64 %166, 9218868437227405312
  %170 = and i1 %168, %169
  %171 = or i1 %167, %170
  br i1 %171, label %after_if9, label %true_block7

true_block7:                                      ; preds = %after_if6
  %172 = load ptr, ptr %35, align 8
  %173 = getelementptr i64, ptr %172, i64 19
  %174 = atomicrmw add ptr %173, i64 1 seq_cst, align 8
  br label %after_if9

after_if9:                                        ; preds = %true_block7, %after_if6
  %175 = bitcast double %114 to i64
  %176 = and i64 %175, 9223372036854775807
  %177 = and i64 %175, 9218868437227405312
  %178 = icmp eq i64 %176, 0
  %179 = icmp ne i64 %177, 0
  %180 = icmp ne i64 %177, 9218868437227405312
  %181 = and i1 %179, %180
  %182 = or i1 %178, %181
  br i1 %182, label %after_if12, label %true_block10

true_block10:                                     ; preds = %after_if9
  %183 = load ptr, ptr %35, align 8
  %184 = getelementptr i64, ptr %183, i64 19
  %185 = atomicrmw add ptr %184, i64 1 seq_cst, align 8
  br label %after_if12

after_if12:                                       ; preds = %true_block10, %after_if9
  %186 = load ptr, ptr %7, align 8
  %187 = getelementptr inbounds %struct.LLVMRuntime, ptr %186, i64 0, i32 16
  %188 = load ptr, ptr %187, align 8
  %189 = load double, ptr %188, align 8
  %190 = fmul double %.0.i12, %110
  %191 = fneg double %189
  %192 = fmul double %114, %191
  %neg = fmul double %190, %192
  %193 = fmul double %79, %neg
  %194 = load double, ptr %45, align 8
  %195 = fadd double %194, %193
  store double %195, ptr %45, align 8
  %196 = fmul double %86, %neg
  %197 = load double, ptr %48, align 8
  %198 = fadd double %197, %196
  store double %198, ptr %48, align 8
  %199 = fmul double %94, %neg
  %200 = load double, ptr %51, align 8
  %201 = fadd double %199, %200
  store double %201, ptr %51, align 8
  %indvars.iv.next = add nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %wide.trip.count, %indvars.iv.next
  br i1 %exitcond.not, label %after_for.loopexit, label %for_loop_body, !llvm.loop !12

for_loop_body13:                                  ; preds = %after_if32, %for_loop_body13.lr.ph
  %indvars.iv37 = phi i64 [ %138, %for_loop_body13.lr.ph ], [ %indvars.iv.next38, %after_if32 ]
  %202 = load ptr, ptr %135, align 8
  %203 = shl i64 %indvars.iv37, 2
  %uglygep43 = getelementptr i8, ptr %202, i64 %203
  %204 = load i32, ptr %uglygep43, align 4
  %205 = load ptr, ptr %136, align 8
  %206 = load i32, ptr %137, align 4
  %207 = sext i32 %206 to i64
  %208 = sext i32 %204 to i64
  %209 = getelementptr i32, ptr %205, i64 %208
  %210 = load i32, ptr %209, align 4
  %211 = add nsw i64 %207, %208
  %212 = getelementptr i32, ptr %205, i64 %211
  %213 = load i32, ptr %212, align 4
  %214 = atomicrmw add ptr %37, i64 1 seq_cst, align 8
  %215 = load ptr, ptr %38, align 8
  %216 = load i32, ptr %40, align 4
  %217 = sext i32 %216 to i64
  %218 = sext i32 %213 to i64
  %219 = getelementptr double, ptr %215, i64 %218
  %220 = load double, ptr %219, align 8
  %221 = sext i32 %210 to i64
  %222 = getelementptr double, ptr %215, i64 %221
  %223 = load double, ptr %222, align 8
  %224 = fsub double %220, %223
  %225 = add nsw i64 %217, %218
  %226 = getelementptr double, ptr %215, i64 %225
  %227 = load double, ptr %226, align 8
  %228 = add nsw i64 %217, %221
  %229 = getelementptr double, ptr %215, i64 %228
  %230 = load double, ptr %229, align 8
  %231 = fsub double %227, %230
  %232 = shl nsw i64 %217, 1
  %233 = add nsw i64 %232, %218
  %234 = getelementptr double, ptr %215, i64 %233
  %235 = load double, ptr %234, align 8
  %236 = add nsw i64 %232, %221
  %237 = getelementptr double, ptr %215, i64 %236
  %238 = load double, ptr %237, align 8
  %239 = fsub double %235, %238
  %240 = mul nsw i64 %217, 7
  %241 = add nsw i64 %240, %221
  %242 = getelementptr double, ptr %215, i64 %241
  %243 = load double, ptr %242, align 8
  %244 = add nsw i64 %240, %218
  %245 = getelementptr double, ptr %215, i64 %244
  %246 = load double, ptr %245, align 8
  %247 = fmul double %224, %224
  %248 = fmul double %231, %231
  %249 = fadd double %247, %248
  %250 = fmul double %239, %239
  %251 = fadd double %249, %250
  %252 = fcmp ogt double %251, 0.000000e+00
  %.0.i = select i1 %252, double 1.000000e+00, double 0.000000e+00
  %253 = fsub double 1.000000e+00, %.0.i
  %254 = fadd double %251, %253
  %sqrt17 = tail call double @llvm.sqrt.f64(double %254)
  %255 = fdiv double 1.000000e+00, %sqrt17
  %256 = fmul double %254, %255
  %257 = fadd double %243, %246
  %258 = fsub double %257, %256
  %259 = tail call double @llvm.maxnum.f64(double %258, double 0.000000e+00)
  %260 = bitcast double %251 to i64
  %261 = and i64 %260, 9223372036854775807
  %262 = and i64 %260, 9218868437227405312
  %263 = icmp eq i64 %261, 0
  %264 = icmp ne i64 %262, 0
  %265 = icmp ne i64 %262, 9218868437227405312
  %266 = and i1 %264, %265
  %267 = or i1 %263, %266
  br i1 %267, label %after_if20, label %true_block18

true_block18:                                     ; preds = %for_loop_body13
  %268 = load ptr, ptr %35, align 8
  %269 = getelementptr i64, ptr %268, i64 19
  %270 = atomicrmw add ptr %269, i64 1 seq_cst, align 8
  br label %after_if20

after_if20:                                       ; preds = %true_block18, %for_loop_body13
  %271 = bitcast double %255 to i64
  %272 = and i64 %271, 9223372036854775807
  %273 = and i64 %271, 9218868437227405312
  %274 = icmp eq i64 %272, 0
  %275 = icmp ne i64 %273, 0
  %276 = icmp ne i64 %273, 9218868437227405312
  %277 = and i1 %275, %276
  %278 = or i1 %274, %277
  br i1 %278, label %after_if23, label %true_block21

true_block21:                                     ; preds = %after_if20
  %279 = load ptr, ptr %35, align 8
  %280 = getelementptr i64, ptr %279, i64 19
  %281 = atomicrmw add ptr %280, i64 1 seq_cst, align 8
  br label %after_if23

after_if23:                                       ; preds = %true_block21, %after_if20
  %282 = bitcast double %256 to i64
  %283 = and i64 %282, 9223372036854775807
  %284 = and i64 %282, 9218868437227405312
  %285 = icmp eq i64 %283, 0
  %286 = icmp ne i64 %284, 0
  %287 = icmp ne i64 %284, 9218868437227405312
  %288 = and i1 %286, %287
  %289 = or i1 %285, %288
  br i1 %289, label %after_if26, label %true_block24

true_block24:                                     ; preds = %after_if23
  %290 = load ptr, ptr %35, align 8
  %291 = getelementptr i64, ptr %290, i64 19
  %292 = atomicrmw add ptr %291, i64 1 seq_cst, align 8
  br label %after_if26

after_if26:                                       ; preds = %true_block24, %after_if23
  %293 = bitcast double %257 to i64
  %294 = and i64 %293, 9223372036854775807
  %295 = and i64 %293, 9218868437227405312
  %296 = icmp eq i64 %294, 0
  %297 = icmp ne i64 %295, 0
  %298 = icmp ne i64 %295, 9218868437227405312
  %299 = and i1 %297, %298
  %300 = or i1 %296, %299
  br i1 %300, label %after_if29, label %true_block27

true_block27:                                     ; preds = %after_if26
  %301 = load ptr, ptr %35, align 8
  %302 = getelementptr i64, ptr %301, i64 19
  %303 = atomicrmw add ptr %302, i64 1 seq_cst, align 8
  br label %after_if29

after_if29:                                       ; preds = %true_block27, %after_if26
  %304 = bitcast double %259 to i64
  %305 = and i64 %304, 9223372036854775807
  %306 = and i64 %304, 9218868437227405312
  %307 = icmp eq i64 %305, 0
  %308 = icmp ne i64 %306, 0
  %309 = icmp ne i64 %306, 9218868437227405312
  %310 = and i1 %308, %309
  %311 = or i1 %307, %310
  br i1 %311, label %after_if32, label %true_block30

true_block30:                                     ; preds = %after_if29
  %312 = load ptr, ptr %35, align 8
  %313 = getelementptr i64, ptr %312, i64 19
  %314 = atomicrmw add ptr %313, i64 1 seq_cst, align 8
  br label %after_if32

after_if32:                                       ; preds = %true_block30, %after_if29
  %315 = load ptr, ptr %7, align 8
  %316 = getelementptr inbounds %struct.LLVMRuntime, ptr %315, i64 0, i32 16
  %317 = load ptr, ptr %316, align 8
  %318 = load double, ptr %317, align 8
  %319 = fmul double %.0.i, %255
  %320 = fneg double %318
  %321 = fmul double %259, %320
  %neg33 = fmul double %319, %321
  %322 = load double, ptr %45, align 8
  %323 = fmul double %224, %neg33
  %324 = fsub double %322, %323
  store double %324, ptr %45, align 8
  %325 = load double, ptr %48, align 8
  %326 = fmul double %231, %neg33
  %327 = fsub double %325, %326
  store double %327, ptr %48, align 8
  %328 = load double, ptr %51, align 8
  %329 = fmul double %239, %neg33
  %330 = fsub double %328, %329
  store double %330, ptr %51, align 8
  %indvars.iv.next38 = add nsw i64 %indvars.iv37, 1
  %exitcond41.not = icmp eq i64 %wide.trip.count40, %indvars.iv.next38
  br i1 %exitcond41.not, label %loop_body_tail.loopexit, label %for_loop_body13, !llvm.loop !13
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.sqrt.f64(double) #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.maxnum.f64(double, double) #3

; Function Attrs: argmemonly mustprogress nofree norecurse nosync nounwind willreturn
define internal fastcc void @S24_refine_coordinates(ptr nocapture readonly %0, ptr nocapture writeonly %1, i32 %2) unnamed_addr #4 {
entry:
  %3 = and i32 %2, 3
  %4 = load i32, ptr %0, align 4
  %5 = shl i32 %4, 2
  %6 = or i32 %5, %3
  store i32 %6, ptr %1, align 4
  %7 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 1
  %8 = load i32, ptr %7, align 4
  %9 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 1
  store i32 %8, ptr %9, align 4
  %10 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 2
  %11 = load i32, ptr %10, align 4
  %12 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 2
  store i32 %11, ptr %12, align 4
  %13 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 3
  %14 = load i32, ptr %13, align 4
  %15 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 3
  store i32 %14, ptr %15, align 4
  %16 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 4
  %17 = load i32, ptr %16, align 4
  %18 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 4
  store i32 %17, ptr %18, align 4
  %19 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 5
  %20 = load i32, ptr %19, align 4
  %21 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 5
  store i32 %20, ptr %21, align 4
  %22 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 6
  %23 = load i32, ptr %22, align 4
  %24 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 6
  store i32 %23, ptr %24, align 4
  %25 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 7
  %26 = load i32, ptr %25, align 4
  %27 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 7
  store i32 %26, ptr %27, align 4
  %28 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 8
  %29 = load i32, ptr %28, align 4
  %30 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 8
  store i32 %29, ptr %30, align 4
  %31 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 9
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 9
  store i32 %32, ptr %33, align 4
  %34 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 10
  %35 = load i32, ptr %34, align 4
  %36 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 10
  store i32 %35, ptr %36, align 4
  %37 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 11
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 11
  store i32 %38, ptr %39, align 4
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #5

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn writeonly
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #6

; Function Attrs: noinline nounwind optnone uwtable
define internal fastcc void @taichi_assert_format(ptr noundef %0, i1 noundef zeroext %1, ptr noundef %2) unnamed_addr #7 {
  %4 = alloca ptr, align 8
  %5 = alloca i8, align 1
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca ptr, align 8
  %9 = alloca %class.anon, align 8
  store ptr %0, ptr %4, align 8
  %10 = zext i1 %1 to i8
  store i8 %10, ptr %5, align 1
  store ptr %2, ptr %6, align 8
  store i32 0, ptr %7, align 4
  store ptr null, ptr %8, align 8
  %11 = load i8, ptr %5, align 1
  %12 = trunc i8 %11 to i1
  %13 = zext i1 %12 to i32
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %15, label %16

15:                                               ; preds = %3
  br label %69

16:                                               ; preds = %3
  %17 = load ptr, ptr %4, align 8
  %18 = getelementptr inbounds %struct.LLVMRuntime, ptr %17, i32 0, i32 24
  %19 = load i64, ptr %18, align 8
  %20 = icmp ne i64 %19, 0
  br i1 %20, label %69, label %21

21:                                               ; preds = %16
  %22 = load ptr, ptr %4, align 8
  %23 = getelementptr inbounds %struct.LLVMRuntime, ptr %22, i32 0, i32 23
  %24 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 0
  store ptr %4, ptr %24, align 8
  %25 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 1
  store ptr %6, ptr %25, align 8
  %26 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 2
  store ptr %7, ptr %26, align 8
  %27 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 3
  store ptr %8, ptr %27, align 8
  br label %28

28:                                               ; preds = %28, %21
  %29 = atomicrmw volatile xchg ptr %23, i32 1 seq_cst, align 4
  %30 = icmp eq i32 %29, 1
  br i1 %30, label %28, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i:                        ; preds = %28
  %31 = load ptr, ptr %9, align 8
  %32 = load ptr, ptr %31, align 8
  %33 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 24
  %34 = load i64, ptr %33, align 8
  %.not.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i, label %35, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

35:                                               ; preds = %mutex_lock_i32.exit.i.i.i
  store i64 1, ptr %33, align 8
  %36 = load ptr, ptr %9, align 8
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr inbounds %struct.LLVMRuntime, ptr %37, i64 0, i32 21
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %38, i8 0, i64 2048, i1 false)
  %39 = load ptr, ptr %9, align 8
  %40 = load ptr, ptr %39, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 21
  %42 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 1
  %43 = load ptr, ptr %42, align 8
  %44 = load ptr, ptr %43, align 8
  %45 = load i8, ptr %44, align 1
  %.not5.i.i.i.i.i = icmp eq i8 %45, 0
  br i1 %.not5.i.i.i.i.i, label %taichi_strlen.exit.thread.i.i.i.i, label %.lr.ph.i.i.i.i.i.preheader

.lr.ph.i.i.i.i.i.preheader:                       ; preds = %35
  br label %.lr.ph.i.i.i.i.i

.lr.ph.i.i.i.i.i:                                 ; preds = %.lr.ph.i.i.i.i.i, %.lr.ph.i.i.i.i.i.preheader
  %.07.i.i.i.i.i = phi ptr [ %47, %.lr.ph.i.i.i.i.i ], [ %44, %.lr.ph.i.i.i.i.i.preheader ]
  %.046.i.i.i.i.i = phi i64 [ %46, %.lr.ph.i.i.i.i.i ], [ 0, %.lr.ph.i.i.i.i.i.preheader ]
  %46 = add i64 %.046.i.i.i.i.i, 1
  %47 = getelementptr inbounds i8, ptr %.07.i.i.i.i.i, i64 1
  %48 = load i8, ptr %47, align 1
  %.not.i.i.i.i.i = icmp eq i8 %48, 0
  br i1 %.not.i.i.i.i.i, label %taichi_strlen.exit.i.i.i.i, label %.lr.ph.i.i.i.i.i, !llvm.loop !14

taichi_strlen.exit.i.i.i.i:                       ; preds = %.lr.ph.i.i.i.i.i
  %.lcssa = phi i64 [ %46, %.lr.ph.i.i.i.i.i ]
  %49 = call i64 @llvm.umin.i64(i64 %.lcssa, i64 2047)
  br label %taichi_strlen.exit.thread.i.i.i.i

taichi_strlen.exit.thread.i.i.i.i:                ; preds = %taichi_strlen.exit.i.i.i.i, %35
  %50 = phi i64 [ 0, %35 ], [ %49, %taichi_strlen.exit.i.i.i.i ]
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %41, ptr nonnull align 1 %44, i64 %50, i1 false)
  %51 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 2
  %52 = load ptr, ptr %51, align 8
  %53 = load i32, ptr %52, align 4
  %54 = icmp sgt i32 %53, 0
  br i1 %54, label %.lr.ph.i.i.i.i, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

.lr.ph.i.i.i.i:                                   ; preds = %taichi_strlen.exit.thread.i.i.i.i
  %55 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 3
  br label %56

56:                                               ; preds = %56, %.lr.ph.i.i.i.i
  %indvars.iv.i.i.i.i = phi i64 [ 0, %.lr.ph.i.i.i.i ], [ %indvars.iv.next.i.i.i.i, %56 ]
  %57 = load ptr, ptr %55, align 8
  %58 = load ptr, ptr %57, align 8
  %59 = getelementptr inbounds i64, ptr %58, i64 %indvars.iv.i.i.i.i
  %60 = load i64, ptr %59, align 8
  %61 = load ptr, ptr %9, align 8
  %62 = load ptr, ptr %61, align 8
  %63 = getelementptr inbounds %struct.LLVMRuntime, ptr %62, i64 0, i32 22, i64 %indvars.iv.i.i.i.i
  store i64 %60, ptr %63, align 8
  %indvars.iv.next.i.i.i.i = add nuw nsw i64 %indvars.iv.i.i.i.i, 1
  %64 = load ptr, ptr %51, align 8
  %65 = load i32, ptr %64, align 4
  %66 = sext i32 %65 to i64
  %67 = icmp slt i64 %indvars.iv.next.i.i.i.i, %66
  br i1 %67, label %56, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", !llvm.loop !15

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit": ; preds = %56
  br label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit": ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", %taichi_strlen.exit.thread.i.i.i.i, %mutex_lock_i32.exit.i.i.i
  %68 = atomicrmw volatile xchg ptr %23, i32 0 seq_cst, align 4
  br label %69

69:                                               ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit", %16, %15
  ret void
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_struct_for_block_helper(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #8 {
_ZN11ListManager3getI7ElementEERT_i.exit:
  %3 = alloca %struct.RuntimeContext.699, align 8
  %4 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 4
  %5 = load i32, ptr %4, align 4
  %6 = sdiv i32 %2, %5
  %7 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  %8 = load i32, ptr %7, align 8
  %9 = sdiv i32 %8, %5
  %10 = srem i32 %2, %5
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  %12 = load ptr, ptr %11, align 8
  %13 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %14 = load i32, ptr %13, align 8
  %15 = ashr i32 %6, %14
  %16 = sext i32 %15 to i64
  %17 = lshr i64 %16, 9
  %18 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %17
  %19 = load atomic i64, ptr %18 acquire, align 8
  %.not.i.i.i = icmp ne i64 %19, 0
  tail call void @llvm.assume(i1 %.not.i.i.i)
  %20 = inttoptr i64 %19 to ptr
  %21 = and i64 %16, 511
  %22 = getelementptr inbounds ptr, ptr %20, i64 %21
  %23 = load atomic i64, ptr %22 acquire, align 8
  %24 = inttoptr i64 %23 to ptr
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %26 = load i64, ptr %25, align 8
  %27 = load i32, ptr %13, align 8
  %notmask.i.i = shl nsw i32 -1, %27
  %28 = xor i32 %notmask.i.i, -1
  %29 = and i32 %6, %28
  %30 = sext i32 %29 to i64
  %31 = mul i64 %26, %30
  %32 = getelementptr inbounds i8, ptr %24, i64 %31
  %33 = getelementptr inbounds %0, ptr %32, i64 0, i32 1
  %34 = load i32, ptr %33, align 8
  %35 = mul nsw i32 %10, %9
  %36 = add nsw i32 %34, %35
  %37 = add nsw i32 %10, 1
  %38 = mul nsw i32 %37, %9
  %39 = add nsw i32 %34, %38
  %40 = getelementptr inbounds %0, ptr %32, i64 0, i32 1, i64 1
  %41 = load i32, ptr %40, align 4
  %42 = tail call i32 @llvm.smin.i32(i32 %41, i32 %39)
  %43 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  %44 = load i64, ptr %43, align 8
  %45 = alloca i8, i64 %44, align 8
  %46 = load ptr, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %3, ptr noundef nonnull align 8 dereferenceable(32) %46, i64 32, i1 false)
  %47 = getelementptr inbounds %struct.RuntimeContext.699, ptr %3, i64 0, i32 2
  store i32 %1, ptr %47, align 8
  %48 = icmp slt i32 %36, %42
  br i1 %48, label %49, label %75

49:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit
  %50 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = load ptr, ptr %11, align 8
  %53 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 3
  %54 = load i32, ptr %53, align 8
  %55 = ashr i32 %6, %54
  %56 = sext i32 %55 to i64
  %57 = lshr i64 %56, 9
  %58 = getelementptr inbounds [256 x ptr], ptr %52, i64 0, i64 %57
  %59 = load atomic i64, ptr %58 acquire, align 8
  %.not.i.i.i24 = icmp eq i64 %59, 0
  br i1 %.not.i.i.i24, label %_ZN11ListManager3getI7ElementEERT_i.exit26, label %60

60:                                               ; preds = %49
  %61 = inttoptr i64 %59 to ptr
  %62 = and i64 %56, 511
  %63 = getelementptr inbounds ptr, ptr %61, i64 %62
  %64 = load atomic i64, ptr %63 acquire, align 8
  %65 = inttoptr i64 %64 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit26

_ZN11ListManager3getI7ElementEERT_i.exit26:       ; preds = %60, %49
  %66 = phi ptr [ %65, %60 ], [ null, %49 ]
  %67 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 1
  %68 = load i64, ptr %67, align 8
  %69 = load i32, ptr %53, align 8
  %notmask.i.i25 = shl nsw i32 -1, %69
  %70 = xor i32 %notmask.i.i25, -1
  %71 = and i32 %6, %70
  %72 = sext i32 %71 to i64
  %73 = mul i64 %68, %72
  %74 = getelementptr inbounds i8, ptr %66, i64 %73
  call void %51(ptr noundef nonnull %3, ptr noundef nonnull %45, ptr noundef nonnull %74, i32 noundef %36, i32 noundef %42) #1
  br label %75

75:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit26, %_ZN11ListManager3getI7ElementEERT_i.exit
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i64 @llvm.umin.i64(i64, i64) #9

; Function Attrs: inaccessiblememonly nocallback nofree nosync nounwind willreturn
declare void @llvm.assume(i1 noundef) #10

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #9

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #11

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #11

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { nofree nounwind }
attributes #3 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #4 = { argmemonly mustprogress nofree norecurse nosync nounwind willreturn }
attributes #5 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #6 = { argmemonly mustprogress nocallback nofree nounwind willreturn writeonly }
attributes #7 = { noinline nounwind optnone uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #10 = { inaccessiblememonly nocallback nofree nosync nounwind willreturn }
attributes #11 = { argmemonly nocallback nofree nosync nounwind willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7, !8}
!7 = !{!"llvm.loop.mustprogress"}
!8 = !{!"llvm.loop.unroll.disable"}
!9 = distinct !{!9, !7, !8}
!10 = distinct !{!10, !7, !8}
!11 = distinct !{!11, !7, !8}
!12 = distinct !{!12, !8}
!13 = distinct !{!13, !8}
!14 = distinct !{!14, !7, !8}
!15 = distinct !{!15, !7, !8}
