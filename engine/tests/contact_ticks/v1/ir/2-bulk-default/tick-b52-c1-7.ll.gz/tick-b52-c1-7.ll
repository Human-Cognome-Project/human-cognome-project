; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%0 = type { %1, %1 }
%1 = type { [4 x i64], [4 x ptr] }
%2 = type { ptr, [2 x i32], %struct.PhysicalCoordinates.2068 }
%struct.RuntimeContext.2042 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }
%struct.range_task_helper_context = type { ptr, ptr, ptr, ptr, i64, i32, i32, i32, i32 }
%struct.NodeManager = type <{ ptr, i32, i32, i32, i32, ptr, ptr, ptr, i32, [4 x i8] }>
%struct.ListManager = type { [256 x ptr], i64, i64, i32, i32, i32, ptr }
%struct.PhysicalCoordinates.2068 = type { [12 x i32] }
%struct.cpu_block_task_helper_context = type { ptr, ptr, ptr, i32, i32, i64 }
%class.anon = type { ptr, ptr, ptr, ptr }

@.str = private unnamed_addr constant [28 x i8] c"Out of pre-allocated memory\00", align 1
@.str.2 = private unnamed_addr constant [28 x i8] c"List manager out of chunks.\00", align 1

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @activity_begin_55_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %0, i64 0, i32 8
  %2 = load i32, ptr %1, align 4
  %3 = getelementptr inbounds %struct.RuntimeContext.2042, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 16
  store i32 %2, ptr %7, align 4
  %8 = load ptr, ptr %context, align 8
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %8, i64 0, i32 9
  %10 = load i32, ptr %9, align 4
  %11 = load ptr, ptr %3, align 8
  %12 = getelementptr inbounds %struct.LLVMRuntime, ptr %11, i64 0, i32 16
  %13 = load ptr, ptr %12, align 8
  %14 = getelementptr inbounds i8, ptr %13, i64 24
  store i32 %10, ptr %14, align 4
  %15 = load ptr, ptr %context, align 8
  %16 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %15, i64 0, i32 10
  %17 = load i32, ptr %16, align 4
  %18 = load ptr, ptr %3, align 8
  %19 = getelementptr inbounds %struct.LLVMRuntime, ptr %18, i64 0, i32 16
  %20 = load ptr, ptr %19, align 8
  %21 = getelementptr inbounds i8, ptr %20, i64 4
  store i32 %17, ptr %21, align 4
  %22 = load ptr, ptr %context, align 8
  %23 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %22, i64 0, i32 11
  %24 = load i32, ptr %23, align 4
  %25 = load ptr, ptr %3, align 8
  %26 = getelementptr inbounds %struct.LLVMRuntime, ptr %25, i64 0, i32 16
  %27 = load ptr, ptr %26, align 8
  %28 = getelementptr inbounds i8, ptr %27, i64 8
  store i32 %24, ptr %28, align 4
  %29 = load ptr, ptr %context, align 8
  %30 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %29, i64 0, i32 12
  %31 = load i32, ptr %30, align 4
  %32 = load ptr, ptr %3, align 8
  %33 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 16
  %34 = load ptr, ptr %33, align 8
  store i32 %31, ptr %34, align 4
  %35 = load ptr, ptr %context, align 8
  %36 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %35, i64 0, i32 13
  %37 = load i32, ptr %36, align 4
  %38 = load ptr, ptr %3, align 8
  %39 = getelementptr inbounds %struct.LLVMRuntime, ptr %38, i64 0, i32 16
  %40 = load ptr, ptr %39, align 8
  %41 = getelementptr inbounds i8, ptr %40, i64 12
  store i32 %37, ptr %41, align 4
  ret void
}

; Function Attrs: nounwind
define void @activity_begin_55_kernel_1_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.2042, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 20)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %7, i64 0, i32 5, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %10 = xor i64 %9, -1
  %11 = add nsw i64 %10, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 4
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %9, %for_loop_body.prol.preheader ]
  %12 = load ptr, ptr %8, align 8
  %13 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep20 = getelementptr i8, ptr %12, i64 %13
  store i64 0, ptr %uglygep20, align 8
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !6

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %9, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %14 = icmp ult i64 %11, 7
  br i1 %14, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %for_loop_body ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %15 = load ptr, ptr %8, align 8
  %16 = shl i64 %indvars.iv, 3
  %uglygep17 = getelementptr i8, ptr %15, i64 %16
  store i64 0, ptr %uglygep17, align 8
  %17 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %17, i64 8
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %16
  store i64 0, ptr %uglygep19, align 8
  %18 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %18, i64 16
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %16
  store i64 0, ptr %uglygep16, align 8
  %19 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %19, i64 24
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %16
  store i64 0, ptr %uglygep14, align 8
  %20 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %20, i64 32
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %16
  store i64 0, ptr %uglygep12, align 8
  %21 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %21, i64 40
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %16
  store i64 0, ptr %uglygep10, align 8
  %22 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %22, i64 48
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %16
  store i64 0, ptr %uglygep8, align 8
  %23 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %23, i64 56
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %16
  store i64 0, ptr %uglygep6, align 8
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @activity_begin_55_kernel_2_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.1, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.2042, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.1(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 1)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %7, i64 0, i32 6, i32 1
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr double, ptr %9, i64 3
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(40) %10, i8 0, i64 40, i1 false)
  br label %after_for

after_for:                                        ; preds = %for_loop_body.lr.ph, %allocs
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind
define void @activity_begin_55_kernel_3_serial(ptr nocapture readonly %context) local_unnamed_addr #3 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.2042, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 16
  %3 = load ptr, ptr %2, align 8
  %4 = load i32, ptr %3, align 4
  %5 = icmp sgt i32 %4, 0
  br i1 %5, label %for_loop_body.preheader, label %after_for

for_loop_body.preheader:                          ; preds = %entry
  %wide.trip.count = zext i32 %4 to i64
  %6 = add nsw i64 %wide.trip.count, -1
  %xtraiter = and i64 %wide.trip.count, 7
  %7 = icmp ult i64 %6, 7
  br i1 %7, label %after_for.loopexit.unr-lcssa, label %for_loop_body.preheader.new

for_loop_body.preheader.new:                      ; preds = %for_loop_body.preheader
  %unroll_iter = and i64 %wide.trip.count, 4294967288
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader.new
  %indvars.iv = phi i64 [ 0, %for_loop_body.preheader.new ], [ %indvars.iv.next.7, %for_loop_body ]
  %8 = load ptr, ptr %context, align 8
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %8, i64 0, i32 7, i32 1
  %10 = load ptr, ptr %9, align 8
  %11 = shl i64 %indvars.iv, 2
  %uglygep19 = getelementptr i8, ptr %10, i64 %11
  %12 = load i32, ptr %uglygep19, align 4
  %13 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %8, i64 0, i32 1, i32 1
  %14 = load ptr, ptr %13, align 8
  %15 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %8, i64 0, i32 1, i32 0, i32 1
  %16 = load i32, ptr %15, align 4
  %17 = sext i32 %16 to i64
  %18 = mul nsw i64 %17, 3
  %19 = sext i32 %12 to i64
  %20 = add nsw i64 %18, %19
  %21 = getelementptr double, ptr %14, i64 %20
  %22 = load double, ptr %21, align 8
  %23 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %8, i64 0, i32 6, i32 1
  %24 = load ptr, ptr %23, align 8
  %25 = getelementptr double, ptr %24, i64 3
  %26 = load double, ptr %25, align 8
  %27 = getelementptr double, ptr %14, i64 %19
  %28 = load double, ptr %27, align 8
  %29 = load double, ptr %24, align 8
  %30 = fsub double %28, %29
  %31 = fmul double %22, %30
  %32 = fadd double %26, %31
  store double %32, ptr %25, align 8
  %33 = load ptr, ptr %23, align 8
  %34 = getelementptr double, ptr %33, i64 4
  %35 = load double, ptr %34, align 8
  %36 = load ptr, ptr %13, align 8
  %37 = load i32, ptr %15, align 4
  %38 = sext i32 %37 to i64
  %39 = add nsw i64 %38, %19
  %40 = getelementptr double, ptr %36, i64 %39
  %41 = load double, ptr %40, align 8
  %42 = getelementptr double, ptr %33, i64 1
  %43 = load double, ptr %42, align 8
  %44 = fsub double %41, %43
  %45 = fmul double %22, %44
  %46 = fadd double %35, %45
  store double %46, ptr %34, align 8
  %47 = load ptr, ptr %23, align 8
  %48 = getelementptr double, ptr %47, i64 5
  %49 = load double, ptr %48, align 8
  %50 = load ptr, ptr %13, align 8
  %51 = load i32, ptr %15, align 4
  %52 = sext i32 %51 to i64
  %53 = shl nsw i64 %52, 1
  %54 = add nsw i64 %53, %19
  %55 = getelementptr double, ptr %50, i64 %54
  %56 = load double, ptr %55, align 8
  %57 = getelementptr double, ptr %47, i64 2
  %58 = load double, ptr %57, align 8
  %59 = fsub double %56, %58
  %60 = fmul double %22, %59
  %61 = fadd double %49, %60
  store double %61, ptr %48, align 8
  %62 = load ptr, ptr %23, align 8
  %63 = getelementptr double, ptr %62, i64 6
  %64 = load double, ptr %63, align 8
  %65 = fadd double %22, %64
  store double %65, ptr %63, align 8
  %66 = load ptr, ptr %context, align 8
  %67 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %66, i64 0, i32 7, i32 1
  %68 = load ptr, ptr %67, align 8
  %uglygep15 = getelementptr i8, ptr %68, i64 4
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %11
  %69 = load i32, ptr %uglygep16, align 4
  %70 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %66, i64 0, i32 1, i32 1
  %71 = load ptr, ptr %70, align 8
  %72 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %66, i64 0, i32 1, i32 0, i32 1
  %73 = load i32, ptr %72, align 4
  %74 = sext i32 %73 to i64
  %75 = mul nsw i64 %74, 3
  %76 = sext i32 %69 to i64
  %77 = add nsw i64 %75, %76
  %78 = getelementptr double, ptr %71, i64 %77
  %79 = load double, ptr %78, align 8
  %80 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %66, i64 0, i32 6, i32 1
  %81 = load ptr, ptr %80, align 8
  %82 = getelementptr double, ptr %81, i64 3
  %83 = load double, ptr %82, align 8
  %84 = getelementptr double, ptr %71, i64 %76
  %85 = load double, ptr %84, align 8
  %86 = load double, ptr %81, align 8
  %87 = fsub double %85, %86
  %88 = fmul double %79, %87
  %89 = fadd double %83, %88
  store double %89, ptr %82, align 8
  %90 = load ptr, ptr %80, align 8
  %91 = getelementptr double, ptr %90, i64 4
  %92 = load double, ptr %91, align 8
  %93 = load ptr, ptr %70, align 8
  %94 = load i32, ptr %72, align 4
  %95 = sext i32 %94 to i64
  %96 = add nsw i64 %95, %76
  %97 = getelementptr double, ptr %93, i64 %96
  %98 = load double, ptr %97, align 8
  %99 = getelementptr double, ptr %90, i64 1
  %100 = load double, ptr %99, align 8
  %101 = fsub double %98, %100
  %102 = fmul double %79, %101
  %103 = fadd double %92, %102
  store double %103, ptr %91, align 8
  %104 = load ptr, ptr %80, align 8
  %105 = getelementptr double, ptr %104, i64 5
  %106 = load double, ptr %105, align 8
  %107 = load ptr, ptr %70, align 8
  %108 = load i32, ptr %72, align 4
  %109 = sext i32 %108 to i64
  %110 = shl nsw i64 %109, 1
  %111 = add nsw i64 %110, %76
  %112 = getelementptr double, ptr %107, i64 %111
  %113 = load double, ptr %112, align 8
  %114 = getelementptr double, ptr %104, i64 2
  %115 = load double, ptr %114, align 8
  %116 = fsub double %113, %115
  %117 = fmul double %79, %116
  %118 = fadd double %106, %117
  store double %118, ptr %105, align 8
  %119 = load ptr, ptr %80, align 8
  %120 = getelementptr double, ptr %119, i64 6
  %121 = load double, ptr %120, align 8
  %122 = fadd double %79, %121
  store double %122, ptr %120, align 8
  %123 = load ptr, ptr %context, align 8
  %124 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %123, i64 0, i32 7, i32 1
  %125 = load ptr, ptr %124, align 8
  %uglygep13 = getelementptr i8, ptr %125, i64 8
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %11
  %126 = load i32, ptr %uglygep14, align 4
  %127 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %123, i64 0, i32 1, i32 1
  %128 = load ptr, ptr %127, align 8
  %129 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %123, i64 0, i32 1, i32 0, i32 1
  %130 = load i32, ptr %129, align 4
  %131 = sext i32 %130 to i64
  %132 = mul nsw i64 %131, 3
  %133 = sext i32 %126 to i64
  %134 = add nsw i64 %132, %133
  %135 = getelementptr double, ptr %128, i64 %134
  %136 = load double, ptr %135, align 8
  %137 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %123, i64 0, i32 6, i32 1
  %138 = load ptr, ptr %137, align 8
  %139 = getelementptr double, ptr %138, i64 3
  %140 = load double, ptr %139, align 8
  %141 = getelementptr double, ptr %128, i64 %133
  %142 = load double, ptr %141, align 8
  %143 = load double, ptr %138, align 8
  %144 = fsub double %142, %143
  %145 = fmul double %136, %144
  %146 = fadd double %140, %145
  store double %146, ptr %139, align 8
  %147 = load ptr, ptr %137, align 8
  %148 = getelementptr double, ptr %147, i64 4
  %149 = load double, ptr %148, align 8
  %150 = load ptr, ptr %127, align 8
  %151 = load i32, ptr %129, align 4
  %152 = sext i32 %151 to i64
  %153 = add nsw i64 %152, %133
  %154 = getelementptr double, ptr %150, i64 %153
  %155 = load double, ptr %154, align 8
  %156 = getelementptr double, ptr %147, i64 1
  %157 = load double, ptr %156, align 8
  %158 = fsub double %155, %157
  %159 = fmul double %136, %158
  %160 = fadd double %149, %159
  store double %160, ptr %148, align 8
  %161 = load ptr, ptr %137, align 8
  %162 = getelementptr double, ptr %161, i64 5
  %163 = load double, ptr %162, align 8
  %164 = load ptr, ptr %127, align 8
  %165 = load i32, ptr %129, align 4
  %166 = sext i32 %165 to i64
  %167 = shl nsw i64 %166, 1
  %168 = add nsw i64 %167, %133
  %169 = getelementptr double, ptr %164, i64 %168
  %170 = load double, ptr %169, align 8
  %171 = getelementptr double, ptr %161, i64 2
  %172 = load double, ptr %171, align 8
  %173 = fsub double %170, %172
  %174 = fmul double %136, %173
  %175 = fadd double %163, %174
  store double %175, ptr %162, align 8
  %176 = load ptr, ptr %137, align 8
  %177 = getelementptr double, ptr %176, i64 6
  %178 = load double, ptr %177, align 8
  %179 = fadd double %136, %178
  store double %179, ptr %177, align 8
  %180 = load ptr, ptr %context, align 8
  %181 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %180, i64 0, i32 7, i32 1
  %182 = load ptr, ptr %181, align 8
  %uglygep11 = getelementptr i8, ptr %182, i64 12
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %11
  %183 = load i32, ptr %uglygep12, align 4
  %184 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %180, i64 0, i32 1, i32 1
  %185 = load ptr, ptr %184, align 8
  %186 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %180, i64 0, i32 1, i32 0, i32 1
  %187 = load i32, ptr %186, align 4
  %188 = sext i32 %187 to i64
  %189 = mul nsw i64 %188, 3
  %190 = sext i32 %183 to i64
  %191 = add nsw i64 %189, %190
  %192 = getelementptr double, ptr %185, i64 %191
  %193 = load double, ptr %192, align 8
  %194 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %180, i64 0, i32 6, i32 1
  %195 = load ptr, ptr %194, align 8
  %196 = getelementptr double, ptr %195, i64 3
  %197 = load double, ptr %196, align 8
  %198 = getelementptr double, ptr %185, i64 %190
  %199 = load double, ptr %198, align 8
  %200 = load double, ptr %195, align 8
  %201 = fsub double %199, %200
  %202 = fmul double %193, %201
  %203 = fadd double %197, %202
  store double %203, ptr %196, align 8
  %204 = load ptr, ptr %194, align 8
  %205 = getelementptr double, ptr %204, i64 4
  %206 = load double, ptr %205, align 8
  %207 = load ptr, ptr %184, align 8
  %208 = load i32, ptr %186, align 4
  %209 = sext i32 %208 to i64
  %210 = add nsw i64 %209, %190
  %211 = getelementptr double, ptr %207, i64 %210
  %212 = load double, ptr %211, align 8
  %213 = getelementptr double, ptr %204, i64 1
  %214 = load double, ptr %213, align 8
  %215 = fsub double %212, %214
  %216 = fmul double %193, %215
  %217 = fadd double %206, %216
  store double %217, ptr %205, align 8
  %218 = load ptr, ptr %194, align 8
  %219 = getelementptr double, ptr %218, i64 5
  %220 = load double, ptr %219, align 8
  %221 = load ptr, ptr %184, align 8
  %222 = load i32, ptr %186, align 4
  %223 = sext i32 %222 to i64
  %224 = shl nsw i64 %223, 1
  %225 = add nsw i64 %224, %190
  %226 = getelementptr double, ptr %221, i64 %225
  %227 = load double, ptr %226, align 8
  %228 = getelementptr double, ptr %218, i64 2
  %229 = load double, ptr %228, align 8
  %230 = fsub double %227, %229
  %231 = fmul double %193, %230
  %232 = fadd double %220, %231
  store double %232, ptr %219, align 8
  %233 = load ptr, ptr %194, align 8
  %234 = getelementptr double, ptr %233, i64 6
  %235 = load double, ptr %234, align 8
  %236 = fadd double %193, %235
  store double %236, ptr %234, align 8
  %237 = load ptr, ptr %context, align 8
  %238 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %237, i64 0, i32 7, i32 1
  %239 = load ptr, ptr %238, align 8
  %uglygep9 = getelementptr i8, ptr %239, i64 16
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %11
  %240 = load i32, ptr %uglygep10, align 4
  %241 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %237, i64 0, i32 1, i32 1
  %242 = load ptr, ptr %241, align 8
  %243 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %237, i64 0, i32 1, i32 0, i32 1
  %244 = load i32, ptr %243, align 4
  %245 = sext i32 %244 to i64
  %246 = mul nsw i64 %245, 3
  %247 = sext i32 %240 to i64
  %248 = add nsw i64 %246, %247
  %249 = getelementptr double, ptr %242, i64 %248
  %250 = load double, ptr %249, align 8
  %251 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %237, i64 0, i32 6, i32 1
  %252 = load ptr, ptr %251, align 8
  %253 = getelementptr double, ptr %252, i64 3
  %254 = load double, ptr %253, align 8
  %255 = getelementptr double, ptr %242, i64 %247
  %256 = load double, ptr %255, align 8
  %257 = load double, ptr %252, align 8
  %258 = fsub double %256, %257
  %259 = fmul double %250, %258
  %260 = fadd double %254, %259
  store double %260, ptr %253, align 8
  %261 = load ptr, ptr %251, align 8
  %262 = getelementptr double, ptr %261, i64 4
  %263 = load double, ptr %262, align 8
  %264 = load ptr, ptr %241, align 8
  %265 = load i32, ptr %243, align 4
  %266 = sext i32 %265 to i64
  %267 = add nsw i64 %266, %247
  %268 = getelementptr double, ptr %264, i64 %267
  %269 = load double, ptr %268, align 8
  %270 = getelementptr double, ptr %261, i64 1
  %271 = load double, ptr %270, align 8
  %272 = fsub double %269, %271
  %273 = fmul double %250, %272
  %274 = fadd double %263, %273
  store double %274, ptr %262, align 8
  %275 = load ptr, ptr %251, align 8
  %276 = getelementptr double, ptr %275, i64 5
  %277 = load double, ptr %276, align 8
  %278 = load ptr, ptr %241, align 8
  %279 = load i32, ptr %243, align 4
  %280 = sext i32 %279 to i64
  %281 = shl nsw i64 %280, 1
  %282 = add nsw i64 %281, %247
  %283 = getelementptr double, ptr %278, i64 %282
  %284 = load double, ptr %283, align 8
  %285 = getelementptr double, ptr %275, i64 2
  %286 = load double, ptr %285, align 8
  %287 = fsub double %284, %286
  %288 = fmul double %250, %287
  %289 = fadd double %277, %288
  store double %289, ptr %276, align 8
  %290 = load ptr, ptr %251, align 8
  %291 = getelementptr double, ptr %290, i64 6
  %292 = load double, ptr %291, align 8
  %293 = fadd double %250, %292
  store double %293, ptr %291, align 8
  %294 = load ptr, ptr %context, align 8
  %295 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %294, i64 0, i32 7, i32 1
  %296 = load ptr, ptr %295, align 8
  %uglygep7 = getelementptr i8, ptr %296, i64 20
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %11
  %297 = load i32, ptr %uglygep8, align 4
  %298 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %294, i64 0, i32 1, i32 1
  %299 = load ptr, ptr %298, align 8
  %300 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %294, i64 0, i32 1, i32 0, i32 1
  %301 = load i32, ptr %300, align 4
  %302 = sext i32 %301 to i64
  %303 = mul nsw i64 %302, 3
  %304 = sext i32 %297 to i64
  %305 = add nsw i64 %303, %304
  %306 = getelementptr double, ptr %299, i64 %305
  %307 = load double, ptr %306, align 8
  %308 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %294, i64 0, i32 6, i32 1
  %309 = load ptr, ptr %308, align 8
  %310 = getelementptr double, ptr %309, i64 3
  %311 = load double, ptr %310, align 8
  %312 = getelementptr double, ptr %299, i64 %304
  %313 = load double, ptr %312, align 8
  %314 = load double, ptr %309, align 8
  %315 = fsub double %313, %314
  %316 = fmul double %307, %315
  %317 = fadd double %311, %316
  store double %317, ptr %310, align 8
  %318 = load ptr, ptr %308, align 8
  %319 = getelementptr double, ptr %318, i64 4
  %320 = load double, ptr %319, align 8
  %321 = load ptr, ptr %298, align 8
  %322 = load i32, ptr %300, align 4
  %323 = sext i32 %322 to i64
  %324 = add nsw i64 %323, %304
  %325 = getelementptr double, ptr %321, i64 %324
  %326 = load double, ptr %325, align 8
  %327 = getelementptr double, ptr %318, i64 1
  %328 = load double, ptr %327, align 8
  %329 = fsub double %326, %328
  %330 = fmul double %307, %329
  %331 = fadd double %320, %330
  store double %331, ptr %319, align 8
  %332 = load ptr, ptr %308, align 8
  %333 = getelementptr double, ptr %332, i64 5
  %334 = load double, ptr %333, align 8
  %335 = load ptr, ptr %298, align 8
  %336 = load i32, ptr %300, align 4
  %337 = sext i32 %336 to i64
  %338 = shl nsw i64 %337, 1
  %339 = add nsw i64 %338, %304
  %340 = getelementptr double, ptr %335, i64 %339
  %341 = load double, ptr %340, align 8
  %342 = getelementptr double, ptr %332, i64 2
  %343 = load double, ptr %342, align 8
  %344 = fsub double %341, %343
  %345 = fmul double %307, %344
  %346 = fadd double %334, %345
  store double %346, ptr %333, align 8
  %347 = load ptr, ptr %308, align 8
  %348 = getelementptr double, ptr %347, i64 6
  %349 = load double, ptr %348, align 8
  %350 = fadd double %307, %349
  store double %350, ptr %348, align 8
  %351 = load ptr, ptr %context, align 8
  %352 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %351, i64 0, i32 7, i32 1
  %353 = load ptr, ptr %352, align 8
  %uglygep5 = getelementptr i8, ptr %353, i64 24
  %uglygep6 = getelementptr i8, ptr %uglygep5, i64 %11
  %354 = load i32, ptr %uglygep6, align 4
  %355 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %351, i64 0, i32 1, i32 1
  %356 = load ptr, ptr %355, align 8
  %357 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %351, i64 0, i32 1, i32 0, i32 1
  %358 = load i32, ptr %357, align 4
  %359 = sext i32 %358 to i64
  %360 = mul nsw i64 %359, 3
  %361 = sext i32 %354 to i64
  %362 = add nsw i64 %360, %361
  %363 = getelementptr double, ptr %356, i64 %362
  %364 = load double, ptr %363, align 8
  %365 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %351, i64 0, i32 6, i32 1
  %366 = load ptr, ptr %365, align 8
  %367 = getelementptr double, ptr %366, i64 3
  %368 = load double, ptr %367, align 8
  %369 = getelementptr double, ptr %356, i64 %361
  %370 = load double, ptr %369, align 8
  %371 = load double, ptr %366, align 8
  %372 = fsub double %370, %371
  %373 = fmul double %364, %372
  %374 = fadd double %368, %373
  store double %374, ptr %367, align 8
  %375 = load ptr, ptr %365, align 8
  %376 = getelementptr double, ptr %375, i64 4
  %377 = load double, ptr %376, align 8
  %378 = load ptr, ptr %355, align 8
  %379 = load i32, ptr %357, align 4
  %380 = sext i32 %379 to i64
  %381 = add nsw i64 %380, %361
  %382 = getelementptr double, ptr %378, i64 %381
  %383 = load double, ptr %382, align 8
  %384 = getelementptr double, ptr %375, i64 1
  %385 = load double, ptr %384, align 8
  %386 = fsub double %383, %385
  %387 = fmul double %364, %386
  %388 = fadd double %377, %387
  store double %388, ptr %376, align 8
  %389 = load ptr, ptr %365, align 8
  %390 = getelementptr double, ptr %389, i64 5
  %391 = load double, ptr %390, align 8
  %392 = load ptr, ptr %355, align 8
  %393 = load i32, ptr %357, align 4
  %394 = sext i32 %393 to i64
  %395 = shl nsw i64 %394, 1
  %396 = add nsw i64 %395, %361
  %397 = getelementptr double, ptr %392, i64 %396
  %398 = load double, ptr %397, align 8
  %399 = getelementptr double, ptr %389, i64 2
  %400 = load double, ptr %399, align 8
  %401 = fsub double %398, %400
  %402 = fmul double %364, %401
  %403 = fadd double %391, %402
  store double %403, ptr %390, align 8
  %404 = load ptr, ptr %365, align 8
  %405 = getelementptr double, ptr %404, i64 6
  %406 = load double, ptr %405, align 8
  %407 = fadd double %364, %406
  store double %407, ptr %405, align 8
  %408 = load ptr, ptr %context, align 8
  %409 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %408, i64 0, i32 7, i32 1
  %410 = load ptr, ptr %409, align 8
  %uglygep17 = getelementptr i8, ptr %410, i64 28
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %11
  %411 = load i32, ptr %uglygep18, align 4
  %412 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %408, i64 0, i32 1, i32 1
  %413 = load ptr, ptr %412, align 8
  %414 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %408, i64 0, i32 1, i32 0, i32 1
  %415 = load i32, ptr %414, align 4
  %416 = sext i32 %415 to i64
  %417 = mul nsw i64 %416, 3
  %418 = sext i32 %411 to i64
  %419 = add nsw i64 %417, %418
  %420 = getelementptr double, ptr %413, i64 %419
  %421 = load double, ptr %420, align 8
  %422 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %408, i64 0, i32 6, i32 1
  %423 = load ptr, ptr %422, align 8
  %424 = getelementptr double, ptr %423, i64 3
  %425 = load double, ptr %424, align 8
  %426 = getelementptr double, ptr %413, i64 %418
  %427 = load double, ptr %426, align 8
  %428 = load double, ptr %423, align 8
  %429 = fsub double %427, %428
  %430 = fmul double %421, %429
  %431 = fadd double %425, %430
  store double %431, ptr %424, align 8
  %432 = load ptr, ptr %422, align 8
  %433 = getelementptr double, ptr %432, i64 4
  %434 = load double, ptr %433, align 8
  %435 = load ptr, ptr %412, align 8
  %436 = load i32, ptr %414, align 4
  %437 = sext i32 %436 to i64
  %438 = add nsw i64 %437, %418
  %439 = getelementptr double, ptr %435, i64 %438
  %440 = load double, ptr %439, align 8
  %441 = getelementptr double, ptr %432, i64 1
  %442 = load double, ptr %441, align 8
  %443 = fsub double %440, %442
  %444 = fmul double %421, %443
  %445 = fadd double %434, %444
  store double %445, ptr %433, align 8
  %446 = load ptr, ptr %422, align 8
  %447 = getelementptr double, ptr %446, i64 5
  %448 = load double, ptr %447, align 8
  %449 = load ptr, ptr %412, align 8
  %450 = load i32, ptr %414, align 4
  %451 = sext i32 %450 to i64
  %452 = shl nsw i64 %451, 1
  %453 = add nsw i64 %452, %418
  %454 = getelementptr double, ptr %449, i64 %453
  %455 = load double, ptr %454, align 8
  %456 = getelementptr double, ptr %446, i64 2
  %457 = load double, ptr %456, align 8
  %458 = fsub double %455, %457
  %459 = fmul double %421, %458
  %460 = fadd double %448, %459
  store double %460, ptr %447, align 8
  %461 = load ptr, ptr %422, align 8
  %462 = getelementptr double, ptr %461, i64 6
  %463 = load double, ptr %462, align 8
  %464 = fadd double %421, %463
  store double %464, ptr %462, align 8
  %indvars.iv.next.7 = add nuw i64 %indvars.iv, 8
  %niter.ncmp.7 = icmp eq i64 %unroll_iter, %indvars.iv.next.7
  br i1 %niter.ncmp.7, label %after_for.loopexit.unr-lcssa.loopexit, label %for_loop_body

after_for.loopexit.unr-lcssa.loopexit:            ; preds = %for_loop_body
  br label %after_for.loopexit.unr-lcssa

after_for.loopexit.unr-lcssa:                     ; preds = %after_for.loopexit.unr-lcssa.loopexit, %for_loop_body.preheader
  %indvars.iv.unr = phi i64 [ 0, %for_loop_body.preheader ], [ %indvars.iv.next.7, %after_for.loopexit.unr-lcssa.loopexit ]
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %after_for, label %for_loop_body.epil.preheader

for_loop_body.epil.preheader:                     ; preds = %after_for.loopexit.unr-lcssa
  br label %for_loop_body.epil

for_loop_body.epil:                               ; preds = %for_loop_body.epil, %for_loop_body.epil.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.epil.preheader ], [ %lsr.iv.next, %for_loop_body.epil ]
  %indvars.iv.epil = phi i64 [ %indvars.iv.next.epil, %for_loop_body.epil ], [ %indvars.iv.unr, %for_loop_body.epil.preheader ]
  %465 = load ptr, ptr %context, align 8
  %466 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %465, i64 0, i32 7, i32 1
  %467 = load ptr, ptr %466, align 8
  %468 = shl i64 %indvars.iv.epil, 2
  %uglygep = getelementptr i8, ptr %467, i64 %468
  %469 = load i32, ptr %uglygep, align 4
  %470 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %465, i64 0, i32 1, i32 1
  %471 = load ptr, ptr %470, align 8
  %472 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %465, i64 0, i32 1, i32 0, i32 1
  %473 = load i32, ptr %472, align 4
  %474 = sext i32 %473 to i64
  %475 = mul nsw i64 %474, 3
  %476 = sext i32 %469 to i64
  %477 = add nsw i64 %475, %476
  %478 = getelementptr double, ptr %471, i64 %477
  %479 = load double, ptr %478, align 8
  %480 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %465, i64 0, i32 6, i32 1
  %481 = load ptr, ptr %480, align 8
  %482 = getelementptr double, ptr %481, i64 3
  %483 = load double, ptr %482, align 8
  %484 = getelementptr double, ptr %471, i64 %476
  %485 = load double, ptr %484, align 8
  %486 = load double, ptr %481, align 8
  %487 = fsub double %485, %486
  %488 = fmul double %479, %487
  %489 = fadd double %483, %488
  store double %489, ptr %482, align 8
  %490 = load ptr, ptr %480, align 8
  %491 = getelementptr double, ptr %490, i64 4
  %492 = load double, ptr %491, align 8
  %493 = load ptr, ptr %470, align 8
  %494 = load i32, ptr %472, align 4
  %495 = sext i32 %494 to i64
  %496 = add nsw i64 %495, %476
  %497 = getelementptr double, ptr %493, i64 %496
  %498 = load double, ptr %497, align 8
  %499 = getelementptr double, ptr %490, i64 1
  %500 = load double, ptr %499, align 8
  %501 = fsub double %498, %500
  %502 = fmul double %479, %501
  %503 = fadd double %492, %502
  store double %503, ptr %491, align 8
  %504 = load ptr, ptr %480, align 8
  %505 = getelementptr double, ptr %504, i64 5
  %506 = load double, ptr %505, align 8
  %507 = load ptr, ptr %470, align 8
  %508 = load i32, ptr %472, align 4
  %509 = sext i32 %508 to i64
  %510 = shl nsw i64 %509, 1
  %511 = add nsw i64 %510, %476
  %512 = getelementptr double, ptr %507, i64 %511
  %513 = load double, ptr %512, align 8
  %514 = getelementptr double, ptr %504, i64 2
  %515 = load double, ptr %514, align 8
  %516 = fsub double %513, %515
  %517 = fmul double %479, %516
  %518 = fadd double %506, %517
  store double %518, ptr %505, align 8
  %519 = load ptr, ptr %480, align 8
  %520 = getelementptr double, ptr %519, i64 6
  %521 = load double, ptr %520, align 8
  %522 = fadd double %479, %521
  store double %522, ptr %520, align 8
  %indvars.iv.next.epil = add nuw nsw i64 %indvars.iv.epil, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %epil.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %epil.iter.cmp.not, label %after_for.loopexit, label %for_loop_body.epil, !llvm.loop !8

after_for.loopexit:                               ; preds = %for_loop_body.epil
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %after_for.loopexit.unr-lcssa, %entry
  ret void
}

; Function Attrs: nounwind
define void @activity_begin_55_kernel_4_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.2, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.2042, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.2(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #4 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 1)
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %6, i64 0, i32 6, i32 1
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr double, ptr %8, i64 6
  %10 = getelementptr double, ptr %8, i64 3
  %11 = getelementptr double, ptr %8, i64 8
  %12 = getelementptr double, ptr %8, i64 1
  %13 = getelementptr double, ptr %8, i64 4
  %14 = getelementptr double, ptr %8, i64 9
  %15 = getelementptr double, ptr %8, i64 2
  %16 = getelementptr double, ptr %8, i64 5
  %17 = getelementptr double, ptr %8, i64 10
  %18 = icmp sgt i32 %5, %3
  br i1 %18, label %for_loop_body.preheader, label %after_for

for_loop_body.preheader:                          ; preds = %allocs
  %19 = xor i32 %3, -1
  %20 = add i32 %5, %19
  %xtraiter = and i32 %5, 1
  %lcmp.mod.not = icmp eq i32 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.preheader
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if18.prol, %for_loop_body.prol.preheader
  %21 = load double, ptr %9, align 8
  %22 = bitcast double %21 to i64
  %23 = and i64 %22, 9223372036854775807
  %24 = and i64 %22, 9218868437227405312
  %25 = icmp eq i64 %23, 0
  %26 = icmp ne i64 %24, 0
  %27 = icmp ne i64 %24, 9218868437227405312
  %28 = and i1 %26, %27
  %29 = or i1 %25, %28
  br i1 %29, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %30 = load ptr, ptr %0, align 8
  %31 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %30, i64 0, i32 5, i32 1
  %32 = load ptr, ptr %31, align 8
  %33 = getelementptr i64, ptr %32, i64 19
  %34 = atomicrmw add ptr %33, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %35 = fcmp ogt double %21, 0.000000e+00
  %36 = fcmp olt double %21, 0.000000e+00
  %..i.op.prol = select i1 %36, double 2.000000e+00, double 1.000000e+00
  %37 = select i1 %35, double 0.000000e+00, double %..i.op.prol
  %38 = fadd double %21, %37
  %39 = load double, ptr %8, align 8
  %40 = load double, ptr %10, align 8
  %41 = fdiv double %40, %38
  %42 = fadd double %39, %41
  %43 = load double, ptr %11, align 8
  %44 = select i1 %35, double %42, double %43
  %45 = bitcast double %44 to i64
  %46 = and i64 %45, 9223372036854775807
  %47 = and i64 %45, 9218868437227405312
  %48 = icmp eq i64 %46, 0
  %49 = icmp ne i64 %47, 0
  %50 = icmp ne i64 %47, 9218868437227405312
  %51 = and i1 %49, %50
  %52 = or i1 %48, %51
  br i1 %52, label %after_if3.prol, label %true_block1.prol

true_block1.prol:                                 ; preds = %after_if.prol
  %53 = load ptr, ptr %0, align 8
  %54 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %53, i64 0, i32 5, i32 1
  %55 = load ptr, ptr %54, align 8
  %56 = getelementptr i64, ptr %55, i64 19
  %57 = atomicrmw add ptr %56, i64 1 seq_cst, align 8
  br label %after_if3.prol

after_if3.prol:                                   ; preds = %true_block1.prol, %after_if.prol
  %58 = fcmp ueq double %44, %39
  br i1 %58, label %after_if6.prol, label %true_block4.prol

true_block4.prol:                                 ; preds = %after_if3.prol
  %59 = load ptr, ptr %7, align 8
  %60 = getelementptr double, ptr %59, i64 7
  store double 1.000000e+00, ptr %60, align 8
  br label %after_if6.prol

after_if6.prol:                                   ; preds = %true_block4.prol, %after_if3.prol
  %61 = load double, ptr %12, align 8
  %62 = load double, ptr %13, align 8
  %63 = fdiv double %62, %38
  %64 = fadd double %61, %63
  %65 = load double, ptr %14, align 8
  %66 = select i1 %35, double %64, double %65
  %67 = bitcast double %66 to i64
  %68 = and i64 %67, 9223372036854775807
  %69 = and i64 %67, 9218868437227405312
  %70 = icmp eq i64 %68, 0
  %71 = icmp ne i64 %69, 0
  %72 = icmp ne i64 %69, 9218868437227405312
  %73 = and i1 %71, %72
  %74 = or i1 %70, %73
  br i1 %74, label %after_if9.prol, label %true_block7.prol

true_block7.prol:                                 ; preds = %after_if6.prol
  %75 = load ptr, ptr %0, align 8
  %76 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %75, i64 0, i32 5, i32 1
  %77 = load ptr, ptr %76, align 8
  %78 = getelementptr i64, ptr %77, i64 19
  %79 = atomicrmw add ptr %78, i64 1 seq_cst, align 8
  br label %after_if9.prol

after_if9.prol:                                   ; preds = %true_block7.prol, %after_if6.prol
  %80 = fcmp ueq double %66, %61
  br i1 %80, label %after_if12.prol, label %true_block10.prol

true_block10.prol:                                ; preds = %after_if9.prol
  %81 = load ptr, ptr %7, align 8
  %82 = getelementptr double, ptr %81, i64 7
  store double 1.000000e+00, ptr %82, align 8
  br label %after_if12.prol

after_if12.prol:                                  ; preds = %true_block10.prol, %after_if9.prol
  %83 = load double, ptr %15, align 8
  %84 = load double, ptr %16, align 8
  %85 = fdiv double %84, %38
  %86 = fadd double %83, %85
  %87 = load double, ptr %17, align 8
  %88 = select i1 %35, double %86, double %87
  %89 = bitcast double %88 to i64
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if15.prol, label %true_block13.prol

true_block13.prol:                                ; preds = %after_if12.prol
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %97, i64 0, i32 5, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 19
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if15.prol

after_if15.prol:                                  ; preds = %true_block13.prol, %after_if12.prol
  %102 = fcmp ueq double %88, %83
  br i1 %102, label %after_if18.prol, label %true_block16.prol

true_block16.prol:                                ; preds = %after_if15.prol
  %103 = load ptr, ptr %7, align 8
  %104 = getelementptr double, ptr %103, i64 7
  store double 1.000000e+00, ptr %104, align 8
  br label %after_if18.prol

after_if18.prol:                                  ; preds = %true_block16.prol, %after_if15.prol
  store double %44, ptr %8, align 8
  store double %66, ptr %12, align 8
  store double %88, ptr %15, align 8
  br i1 true, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !9

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if18.prol
  %105 = sub i32 %3, -1
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.preheader
  %.03.unr = phi i32 [ %3, %for_loop_body.preheader ], [ %105, %for_loop_body.prol.loopexit.loopexit ]
  %106 = icmp ult i32 %20, 3
  br i1 %106, label %after_for, label %for_loop_body.preheader4

for_loop_body.preheader4:                         ; preds = %for_loop_body.prol.loopexit
  %107 = sub i32 %5, %.03.unr
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if18.3, %for_loop_body.preheader4
  %lsr.iv = phi i32 [ %107, %for_loop_body.preheader4 ], [ %lsr.iv.next, %after_if18.3 ]
  %108 = load double, ptr %9, align 8
  %109 = bitcast double %108 to i64
  %110 = and i64 %109, 9223372036854775807
  %111 = and i64 %109, 9218868437227405312
  %112 = icmp eq i64 %110, 0
  %113 = icmp ne i64 %111, 0
  %114 = icmp ne i64 %111, 9218868437227405312
  %115 = and i1 %113, %114
  %116 = or i1 %112, %115
  br i1 %116, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if18.3
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %117 = load ptr, ptr %0, align 8
  %118 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %117, i64 0, i32 5, i32 1
  %119 = load ptr, ptr %118, align 8
  %120 = getelementptr i64, ptr %119, i64 19
  %121 = atomicrmw add ptr %120, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %122 = fcmp ogt double %108, 0.000000e+00
  %123 = fcmp olt double %108, 0.000000e+00
  %..i.op = select i1 %123, double 2.000000e+00, double 1.000000e+00
  %124 = select i1 %122, double 0.000000e+00, double %..i.op
  %125 = fadd double %108, %124
  %126 = load double, ptr %8, align 8
  %127 = load double, ptr %10, align 8
  %128 = fdiv double %127, %125
  %129 = fadd double %126, %128
  %130 = load double, ptr %11, align 8
  %131 = select i1 %122, double %129, double %130
  %132 = bitcast double %131 to i64
  %133 = and i64 %132, 9223372036854775807
  %134 = and i64 %132, 9218868437227405312
  %135 = icmp eq i64 %133, 0
  %136 = icmp ne i64 %134, 0
  %137 = icmp ne i64 %134, 9218868437227405312
  %138 = and i1 %136, %137
  %139 = or i1 %135, %138
  br i1 %139, label %after_if3, label %true_block1

true_block1:                                      ; preds = %after_if
  %140 = load ptr, ptr %0, align 8
  %141 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %140, i64 0, i32 5, i32 1
  %142 = load ptr, ptr %141, align 8
  %143 = getelementptr i64, ptr %142, i64 19
  %144 = atomicrmw add ptr %143, i64 1 seq_cst, align 8
  br label %after_if3

after_if3:                                        ; preds = %true_block1, %after_if
  %145 = fcmp ueq double %131, %126
  br i1 %145, label %after_if6, label %true_block4

true_block4:                                      ; preds = %after_if3
  %146 = load ptr, ptr %7, align 8
  %147 = getelementptr double, ptr %146, i64 7
  store double 1.000000e+00, ptr %147, align 8
  br label %after_if6

after_if6:                                        ; preds = %true_block4, %after_if3
  %148 = load double, ptr %12, align 8
  %149 = load double, ptr %13, align 8
  %150 = fdiv double %149, %125
  %151 = fadd double %148, %150
  %152 = load double, ptr %14, align 8
  %153 = select i1 %122, double %151, double %152
  %154 = bitcast double %153 to i64
  %155 = and i64 %154, 9223372036854775807
  %156 = and i64 %154, 9218868437227405312
  %157 = icmp eq i64 %155, 0
  %158 = icmp ne i64 %156, 0
  %159 = icmp ne i64 %156, 9218868437227405312
  %160 = and i1 %158, %159
  %161 = or i1 %157, %160
  br i1 %161, label %after_if9, label %true_block7

true_block7:                                      ; preds = %after_if6
  %162 = load ptr, ptr %0, align 8
  %163 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %162, i64 0, i32 5, i32 1
  %164 = load ptr, ptr %163, align 8
  %165 = getelementptr i64, ptr %164, i64 19
  %166 = atomicrmw add ptr %165, i64 1 seq_cst, align 8
  br label %after_if9

after_if9:                                        ; preds = %true_block7, %after_if6
  %167 = fcmp ueq double %153, %148
  br i1 %167, label %after_if12, label %true_block10

true_block10:                                     ; preds = %after_if9
  %168 = load ptr, ptr %7, align 8
  %169 = getelementptr double, ptr %168, i64 7
  store double 1.000000e+00, ptr %169, align 8
  br label %after_if12

after_if12:                                       ; preds = %true_block10, %after_if9
  %170 = load double, ptr %15, align 8
  %171 = load double, ptr %16, align 8
  %172 = fdiv double %171, %125
  %173 = fadd double %170, %172
  %174 = load double, ptr %17, align 8
  %175 = select i1 %122, double %173, double %174
  %176 = bitcast double %175 to i64
  %177 = and i64 %176, 9223372036854775807
  %178 = and i64 %176, 9218868437227405312
  %179 = icmp eq i64 %177, 0
  %180 = icmp ne i64 %178, 0
  %181 = icmp ne i64 %178, 9218868437227405312
  %182 = and i1 %180, %181
  %183 = or i1 %179, %182
  br i1 %183, label %after_if15, label %true_block13

true_block13:                                     ; preds = %after_if12
  %184 = load ptr, ptr %0, align 8
  %185 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %184, i64 0, i32 5, i32 1
  %186 = load ptr, ptr %185, align 8
  %187 = getelementptr i64, ptr %186, i64 19
  %188 = atomicrmw add ptr %187, i64 1 seq_cst, align 8
  br label %after_if15

after_if15:                                       ; preds = %true_block13, %after_if12
  %189 = fcmp ueq double %175, %170
  br i1 %189, label %after_if18, label %true_block16

true_block16:                                     ; preds = %after_if15
  %190 = load ptr, ptr %7, align 8
  %191 = getelementptr double, ptr %190, i64 7
  store double 1.000000e+00, ptr %191, align 8
  br label %after_if18

after_if18:                                       ; preds = %true_block16, %after_if15
  store double %131, ptr %8, align 8
  store double %153, ptr %12, align 8
  store double %175, ptr %15, align 8
  %192 = load double, ptr %9, align 8
  %193 = bitcast double %192 to i64
  %194 = and i64 %193, 9223372036854775807
  %195 = and i64 %193, 9218868437227405312
  %196 = icmp eq i64 %194, 0
  %197 = icmp ne i64 %195, 0
  %198 = icmp ne i64 %195, 9218868437227405312
  %199 = and i1 %197, %198
  %200 = or i1 %196, %199
  br i1 %200, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if18
  %201 = load ptr, ptr %0, align 8
  %202 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %201, i64 0, i32 5, i32 1
  %203 = load ptr, ptr %202, align 8
  %204 = getelementptr i64, ptr %203, i64 19
  %205 = atomicrmw add ptr %204, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if18
  %206 = fcmp ogt double %192, 0.000000e+00
  %207 = fcmp olt double %192, 0.000000e+00
  %..i.op.1 = select i1 %207, double 2.000000e+00, double 1.000000e+00
  %208 = select i1 %206, double 0.000000e+00, double %..i.op.1
  %209 = fadd double %192, %208
  %210 = load double, ptr %8, align 8
  %211 = load double, ptr %10, align 8
  %212 = fdiv double %211, %209
  %213 = fadd double %210, %212
  %214 = load double, ptr %11, align 8
  %215 = select i1 %206, double %213, double %214
  %216 = bitcast double %215 to i64
  %217 = and i64 %216, 9223372036854775807
  %218 = and i64 %216, 9218868437227405312
  %219 = icmp eq i64 %217, 0
  %220 = icmp ne i64 %218, 0
  %221 = icmp ne i64 %218, 9218868437227405312
  %222 = and i1 %220, %221
  %223 = or i1 %219, %222
  br i1 %223, label %after_if3.1, label %true_block1.1

true_block1.1:                                    ; preds = %after_if.1
  %224 = load ptr, ptr %0, align 8
  %225 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %224, i64 0, i32 5, i32 1
  %226 = load ptr, ptr %225, align 8
  %227 = getelementptr i64, ptr %226, i64 19
  %228 = atomicrmw add ptr %227, i64 1 seq_cst, align 8
  br label %after_if3.1

after_if3.1:                                      ; preds = %true_block1.1, %after_if.1
  %229 = fcmp ueq double %215, %210
  br i1 %229, label %after_if6.1, label %true_block4.1

true_block4.1:                                    ; preds = %after_if3.1
  %230 = load ptr, ptr %7, align 8
  %231 = getelementptr double, ptr %230, i64 7
  store double 1.000000e+00, ptr %231, align 8
  br label %after_if6.1

after_if6.1:                                      ; preds = %true_block4.1, %after_if3.1
  %232 = load double, ptr %12, align 8
  %233 = load double, ptr %13, align 8
  %234 = fdiv double %233, %209
  %235 = fadd double %232, %234
  %236 = load double, ptr %14, align 8
  %237 = select i1 %206, double %235, double %236
  %238 = bitcast double %237 to i64
  %239 = and i64 %238, 9223372036854775807
  %240 = and i64 %238, 9218868437227405312
  %241 = icmp eq i64 %239, 0
  %242 = icmp ne i64 %240, 0
  %243 = icmp ne i64 %240, 9218868437227405312
  %244 = and i1 %242, %243
  %245 = or i1 %241, %244
  br i1 %245, label %after_if9.1, label %true_block7.1

true_block7.1:                                    ; preds = %after_if6.1
  %246 = load ptr, ptr %0, align 8
  %247 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %246, i64 0, i32 5, i32 1
  %248 = load ptr, ptr %247, align 8
  %249 = getelementptr i64, ptr %248, i64 19
  %250 = atomicrmw add ptr %249, i64 1 seq_cst, align 8
  br label %after_if9.1

after_if9.1:                                      ; preds = %true_block7.1, %after_if6.1
  %251 = fcmp ueq double %237, %232
  br i1 %251, label %after_if12.1, label %true_block10.1

true_block10.1:                                   ; preds = %after_if9.1
  %252 = load ptr, ptr %7, align 8
  %253 = getelementptr double, ptr %252, i64 7
  store double 1.000000e+00, ptr %253, align 8
  br label %after_if12.1

after_if12.1:                                     ; preds = %true_block10.1, %after_if9.1
  %254 = load double, ptr %15, align 8
  %255 = load double, ptr %16, align 8
  %256 = fdiv double %255, %209
  %257 = fadd double %254, %256
  %258 = load double, ptr %17, align 8
  %259 = select i1 %206, double %257, double %258
  %260 = bitcast double %259 to i64
  %261 = and i64 %260, 9223372036854775807
  %262 = and i64 %260, 9218868437227405312
  %263 = icmp eq i64 %261, 0
  %264 = icmp ne i64 %262, 0
  %265 = icmp ne i64 %262, 9218868437227405312
  %266 = and i1 %264, %265
  %267 = or i1 %263, %266
  br i1 %267, label %after_if15.1, label %true_block13.1

true_block13.1:                                   ; preds = %after_if12.1
  %268 = load ptr, ptr %0, align 8
  %269 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %268, i64 0, i32 5, i32 1
  %270 = load ptr, ptr %269, align 8
  %271 = getelementptr i64, ptr %270, i64 19
  %272 = atomicrmw add ptr %271, i64 1 seq_cst, align 8
  br label %after_if15.1

after_if15.1:                                     ; preds = %true_block13.1, %after_if12.1
  %273 = fcmp ueq double %259, %254
  br i1 %273, label %after_if18.1, label %true_block16.1

true_block16.1:                                   ; preds = %after_if15.1
  %274 = load ptr, ptr %7, align 8
  %275 = getelementptr double, ptr %274, i64 7
  store double 1.000000e+00, ptr %275, align 8
  br label %after_if18.1

after_if18.1:                                     ; preds = %true_block16.1, %after_if15.1
  store double %215, ptr %8, align 8
  store double %237, ptr %12, align 8
  store double %259, ptr %15, align 8
  %276 = load double, ptr %9, align 8
  %277 = bitcast double %276 to i64
  %278 = and i64 %277, 9223372036854775807
  %279 = and i64 %277, 9218868437227405312
  %280 = icmp eq i64 %278, 0
  %281 = icmp ne i64 %279, 0
  %282 = icmp ne i64 %279, 9218868437227405312
  %283 = and i1 %281, %282
  %284 = or i1 %280, %283
  br i1 %284, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if18.1
  %285 = load ptr, ptr %0, align 8
  %286 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %285, i64 0, i32 5, i32 1
  %287 = load ptr, ptr %286, align 8
  %288 = getelementptr i64, ptr %287, i64 19
  %289 = atomicrmw add ptr %288, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if18.1
  %290 = fcmp ogt double %276, 0.000000e+00
  %291 = fcmp olt double %276, 0.000000e+00
  %..i.op.2 = select i1 %291, double 2.000000e+00, double 1.000000e+00
  %292 = select i1 %290, double 0.000000e+00, double %..i.op.2
  %293 = fadd double %276, %292
  %294 = load double, ptr %8, align 8
  %295 = load double, ptr %10, align 8
  %296 = fdiv double %295, %293
  %297 = fadd double %294, %296
  %298 = load double, ptr %11, align 8
  %299 = select i1 %290, double %297, double %298
  %300 = bitcast double %299 to i64
  %301 = and i64 %300, 9223372036854775807
  %302 = and i64 %300, 9218868437227405312
  %303 = icmp eq i64 %301, 0
  %304 = icmp ne i64 %302, 0
  %305 = icmp ne i64 %302, 9218868437227405312
  %306 = and i1 %304, %305
  %307 = or i1 %303, %306
  br i1 %307, label %after_if3.2, label %true_block1.2

true_block1.2:                                    ; preds = %after_if.2
  %308 = load ptr, ptr %0, align 8
  %309 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %308, i64 0, i32 5, i32 1
  %310 = load ptr, ptr %309, align 8
  %311 = getelementptr i64, ptr %310, i64 19
  %312 = atomicrmw add ptr %311, i64 1 seq_cst, align 8
  br label %after_if3.2

after_if3.2:                                      ; preds = %true_block1.2, %after_if.2
  %313 = fcmp ueq double %299, %294
  br i1 %313, label %after_if6.2, label %true_block4.2

true_block4.2:                                    ; preds = %after_if3.2
  %314 = load ptr, ptr %7, align 8
  %315 = getelementptr double, ptr %314, i64 7
  store double 1.000000e+00, ptr %315, align 8
  br label %after_if6.2

after_if6.2:                                      ; preds = %true_block4.2, %after_if3.2
  %316 = load double, ptr %12, align 8
  %317 = load double, ptr %13, align 8
  %318 = fdiv double %317, %293
  %319 = fadd double %316, %318
  %320 = load double, ptr %14, align 8
  %321 = select i1 %290, double %319, double %320
  %322 = bitcast double %321 to i64
  %323 = and i64 %322, 9223372036854775807
  %324 = and i64 %322, 9218868437227405312
  %325 = icmp eq i64 %323, 0
  %326 = icmp ne i64 %324, 0
  %327 = icmp ne i64 %324, 9218868437227405312
  %328 = and i1 %326, %327
  %329 = or i1 %325, %328
  br i1 %329, label %after_if9.2, label %true_block7.2

true_block7.2:                                    ; preds = %after_if6.2
  %330 = load ptr, ptr %0, align 8
  %331 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %330, i64 0, i32 5, i32 1
  %332 = load ptr, ptr %331, align 8
  %333 = getelementptr i64, ptr %332, i64 19
  %334 = atomicrmw add ptr %333, i64 1 seq_cst, align 8
  br label %after_if9.2

after_if9.2:                                      ; preds = %true_block7.2, %after_if6.2
  %335 = fcmp ueq double %321, %316
  br i1 %335, label %after_if12.2, label %true_block10.2

true_block10.2:                                   ; preds = %after_if9.2
  %336 = load ptr, ptr %7, align 8
  %337 = getelementptr double, ptr %336, i64 7
  store double 1.000000e+00, ptr %337, align 8
  br label %after_if12.2

after_if12.2:                                     ; preds = %true_block10.2, %after_if9.2
  %338 = load double, ptr %15, align 8
  %339 = load double, ptr %16, align 8
  %340 = fdiv double %339, %293
  %341 = fadd double %338, %340
  %342 = load double, ptr %17, align 8
  %343 = select i1 %290, double %341, double %342
  %344 = bitcast double %343 to i64
  %345 = and i64 %344, 9223372036854775807
  %346 = and i64 %344, 9218868437227405312
  %347 = icmp eq i64 %345, 0
  %348 = icmp ne i64 %346, 0
  %349 = icmp ne i64 %346, 9218868437227405312
  %350 = and i1 %348, %349
  %351 = or i1 %347, %350
  br i1 %351, label %after_if15.2, label %true_block13.2

true_block13.2:                                   ; preds = %after_if12.2
  %352 = load ptr, ptr %0, align 8
  %353 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %352, i64 0, i32 5, i32 1
  %354 = load ptr, ptr %353, align 8
  %355 = getelementptr i64, ptr %354, i64 19
  %356 = atomicrmw add ptr %355, i64 1 seq_cst, align 8
  br label %after_if15.2

after_if15.2:                                     ; preds = %true_block13.2, %after_if12.2
  %357 = fcmp ueq double %343, %338
  br i1 %357, label %after_if18.2, label %true_block16.2

true_block16.2:                                   ; preds = %after_if15.2
  %358 = load ptr, ptr %7, align 8
  %359 = getelementptr double, ptr %358, i64 7
  store double 1.000000e+00, ptr %359, align 8
  br label %after_if18.2

after_if18.2:                                     ; preds = %true_block16.2, %after_if15.2
  store double %299, ptr %8, align 8
  store double %321, ptr %12, align 8
  store double %343, ptr %15, align 8
  %360 = load double, ptr %9, align 8
  %361 = bitcast double %360 to i64
  %362 = and i64 %361, 9223372036854775807
  %363 = and i64 %361, 9218868437227405312
  %364 = icmp eq i64 %362, 0
  %365 = icmp ne i64 %363, 0
  %366 = icmp ne i64 %363, 9218868437227405312
  %367 = and i1 %365, %366
  %368 = or i1 %364, %367
  br i1 %368, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if18.2
  %369 = load ptr, ptr %0, align 8
  %370 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %369, i64 0, i32 5, i32 1
  %371 = load ptr, ptr %370, align 8
  %372 = getelementptr i64, ptr %371, i64 19
  %373 = atomicrmw add ptr %372, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if18.2
  %374 = fcmp ogt double %360, 0.000000e+00
  %375 = fcmp olt double %360, 0.000000e+00
  %..i.op.3 = select i1 %375, double 2.000000e+00, double 1.000000e+00
  %376 = select i1 %374, double 0.000000e+00, double %..i.op.3
  %377 = fadd double %360, %376
  %378 = load double, ptr %8, align 8
  %379 = load double, ptr %10, align 8
  %380 = fdiv double %379, %377
  %381 = fadd double %378, %380
  %382 = load double, ptr %11, align 8
  %383 = select i1 %374, double %381, double %382
  %384 = bitcast double %383 to i64
  %385 = and i64 %384, 9223372036854775807
  %386 = and i64 %384, 9218868437227405312
  %387 = icmp eq i64 %385, 0
  %388 = icmp ne i64 %386, 0
  %389 = icmp ne i64 %386, 9218868437227405312
  %390 = and i1 %388, %389
  %391 = or i1 %387, %390
  br i1 %391, label %after_if3.3, label %true_block1.3

true_block1.3:                                    ; preds = %after_if.3
  %392 = load ptr, ptr %0, align 8
  %393 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %392, i64 0, i32 5, i32 1
  %394 = load ptr, ptr %393, align 8
  %395 = getelementptr i64, ptr %394, i64 19
  %396 = atomicrmw add ptr %395, i64 1 seq_cst, align 8
  br label %after_if3.3

after_if3.3:                                      ; preds = %true_block1.3, %after_if.3
  %397 = fcmp ueq double %383, %378
  br i1 %397, label %after_if6.3, label %true_block4.3

true_block4.3:                                    ; preds = %after_if3.3
  %398 = load ptr, ptr %7, align 8
  %399 = getelementptr double, ptr %398, i64 7
  store double 1.000000e+00, ptr %399, align 8
  br label %after_if6.3

after_if6.3:                                      ; preds = %true_block4.3, %after_if3.3
  %400 = load double, ptr %12, align 8
  %401 = load double, ptr %13, align 8
  %402 = fdiv double %401, %377
  %403 = fadd double %400, %402
  %404 = load double, ptr %14, align 8
  %405 = select i1 %374, double %403, double %404
  %406 = bitcast double %405 to i64
  %407 = and i64 %406, 9223372036854775807
  %408 = and i64 %406, 9218868437227405312
  %409 = icmp eq i64 %407, 0
  %410 = icmp ne i64 %408, 0
  %411 = icmp ne i64 %408, 9218868437227405312
  %412 = and i1 %410, %411
  %413 = or i1 %409, %412
  br i1 %413, label %after_if9.3, label %true_block7.3

true_block7.3:                                    ; preds = %after_if6.3
  %414 = load ptr, ptr %0, align 8
  %415 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %414, i64 0, i32 5, i32 1
  %416 = load ptr, ptr %415, align 8
  %417 = getelementptr i64, ptr %416, i64 19
  %418 = atomicrmw add ptr %417, i64 1 seq_cst, align 8
  br label %after_if9.3

after_if9.3:                                      ; preds = %true_block7.3, %after_if6.3
  %419 = fcmp ueq double %405, %400
  br i1 %419, label %after_if12.3, label %true_block10.3

true_block10.3:                                   ; preds = %after_if9.3
  %420 = load ptr, ptr %7, align 8
  %421 = getelementptr double, ptr %420, i64 7
  store double 1.000000e+00, ptr %421, align 8
  br label %after_if12.3

after_if12.3:                                     ; preds = %true_block10.3, %after_if9.3
  %422 = load double, ptr %15, align 8
  %423 = load double, ptr %16, align 8
  %424 = fdiv double %423, %377
  %425 = fadd double %422, %424
  %426 = load double, ptr %17, align 8
  %427 = select i1 %374, double %425, double %426
  %428 = bitcast double %427 to i64
  %429 = and i64 %428, 9223372036854775807
  %430 = and i64 %428, 9218868437227405312
  %431 = icmp eq i64 %429, 0
  %432 = icmp ne i64 %430, 0
  %433 = icmp ne i64 %430, 9218868437227405312
  %434 = and i1 %432, %433
  %435 = or i1 %431, %434
  br i1 %435, label %after_if15.3, label %true_block13.3

true_block13.3:                                   ; preds = %after_if12.3
  %436 = load ptr, ptr %0, align 8
  %437 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %436, i64 0, i32 5, i32 1
  %438 = load ptr, ptr %437, align 8
  %439 = getelementptr i64, ptr %438, i64 19
  %440 = atomicrmw add ptr %439, i64 1 seq_cst, align 8
  br label %after_if15.3

after_if15.3:                                     ; preds = %true_block13.3, %after_if12.3
  %441 = fcmp ueq double %427, %422
  br i1 %441, label %after_if18.3, label %true_block16.3

true_block16.3:                                   ; preds = %after_if15.3
  %442 = load ptr, ptr %7, align 8
  %443 = getelementptr double, ptr %442, i64 7
  store double 1.000000e+00, ptr %443, align 8
  br label %after_if18.3

after_if18.3:                                     ; preds = %true_block16.3, %after_if15.3
  store double %383, ptr %8, align 8
  store double %405, ptr %12, align 8
  store double %427, ptr %15, align 8
  %lsr.iv.next = add i32 %lsr.iv, -4
  %exitcond.not.3 = icmp eq i32 %lsr.iv.next, 0
  br i1 %exitcond.not.3, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @activity_begin_55_kernel_5_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.2042, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 16
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 4
  %5 = load i32, ptr %4, align 4
  %6 = getelementptr inbounds i8, ptr %3, i64 8
  %7 = load i32, ptr %6, align 4
  %8 = or i32 %7, %5
  %9 = icmp ne i32 %8, 0
  %10 = load ptr, ptr %context, align 8
  %11 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %10, i64 0, i32 6, i32 1
  %12 = load ptr, ptr %11, align 8
  %13 = getelementptr double, ptr %12, i64 7
  %14 = load double, ptr %13, align 8
  %15 = fcmp one double %14, 0.000000e+00
  %16 = getelementptr inbounds i8, ptr %3, i64 12
  %17 = load i32, ptr %16, align 4
  %18 = icmp ne i32 %17, 0
  %19 = and i1 %15, %18
  %20 = or i1 %9, %19
  %21 = getelementptr inbounds i8, ptr %3, i64 16
  %22 = load i32, ptr %21, align 4
  %23 = select i1 %20, i32 %22, i32 0
  %24 = getelementptr inbounds i8, ptr %3, i64 20
  store i32 %23, ptr %24, align 4
  ret void
}

; Function Attrs: nounwind
define void @activity_begin_55_kernel_6_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.3, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.2042, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nounwind
define internal void @function_body.3(ptr %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = alloca ptr, align 8
  %4 = getelementptr inbounds %struct.RuntimeContext.2042, ptr %0, i64 0, i32 1
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.LLVMRuntime, ptr %5, i64 0, i32 16
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds i8, ptr %7, i64 20
  %9 = load i32, ptr %8, align 4
  %10 = add i32 %9, 1
  %11 = sdiv i32 %10, 2
  %12 = icmp slt i32 %10, 0
  %13 = shl nsw i32 %11, 1
  %14 = icmp ne i32 %13, %10
  %15 = and i1 %12, %14
  %.neg = sext i1 %15 to i32
  %16 = add nsw i32 %11, %.neg
  %17 = tail call i32 @llvm.smax.i32(i32 %16, i32 512)
  %18 = mul i32 %17, %2
  %19 = add i32 %18, %17
  %20 = tail call i32 @llvm.smin.i32(i32 %9, i32 %19)
  %21 = load ptr, ptr %0, align 8
  %22 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %21, i64 0, i32 5, i32 1
  %23 = load ptr, ptr %22, align 8
  %24 = getelementptr i64, ptr %23, i64 17
  %25 = icmp slt i32 %18, %20
  br i1 %25, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %26 = getelementptr { { i32, i32 }, ptr }, ptr %21, i64 0, i32 1
  %27 = getelementptr { { i32, i32 }, ptr }, ptr %21, i64 0, i32 0, i32 1
  %28 = sext i32 %18 to i64
  %wide.trip.count = sext i32 %20 to i64
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if, %for_loop_body.lr.ph
  %indvars.iv = phi i64 [ %28, %for_loop_body.lr.ph ], [ %indvars.iv.next, %after_if ]
  %29 = atomicrmw add ptr %24, i64 1 seq_cst, align 8
  %30 = load ptr, ptr %26, align 8
  %31 = load i32, ptr %27, align 4
  %32 = sext i32 %31 to i64
  %33 = mul nsw i64 %32, 6
  %34 = add nsw i64 %33, %indvars.iv
  %35 = getelementptr double, ptr %30, i64 %34
  %36 = load double, ptr %35, align 8
  %37 = fcmp ogt double %36, 0.000000e+00
  br i1 %37, label %true_block, label %after_if

after_for.loopexit:                               ; preds = %after_if
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %38 = trunc i64 %indvars.iv to i32
  %39 = sdiv i32 %38, 32
  %40 = load ptr, ptr %4, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 7
  %42 = load ptr, ptr %41, align 8
  %43 = getelementptr inbounds ptr, ptr %42, i64 5
  %44 = load ptr, ptr %43, align 8
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %3)
  %45 = shl nsw i32 %39, 3
  %46 = sext i32 %45 to i64
  %47 = getelementptr i8, ptr %44, i64 %46
  store volatile ptr %47, ptr %3, align 8
  %48 = getelementptr inbounds i8, ptr %47, i64 32
  %49 = load volatile ptr, ptr %48, align 8
  %50 = icmp eq ptr %49, null
  br i1 %50, label %51, label %Pointer_activate.exit

51:                                               ; preds = %true_block
  %.0..0..0..0..0..i = load volatile ptr, ptr %3, align 8
  %.0..0..0..0..0.2.i = load volatile ptr, ptr %3, align 8
  br label %52

52:                                               ; preds = %52, %51
  %53 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i, i32 1 seq_cst, align 4
  %54 = icmp eq i32 %53, 1
  br i1 %54, label %52, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !10

mutex_lock_i32.exit.i.i.i:                        ; preds = %52
  %55 = load volatile ptr, ptr %48, align 8
  %56 = icmp eq ptr %55, null
  br i1 %56, label %57, label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i"

57:                                               ; preds = %mutex_lock_i32.exit.i.i.i
  %58 = load ptr, ptr %4, align 8
  %59 = getelementptr inbounds %struct.LLVMRuntime, ptr %58, i64 0, i32 14
  %60 = load ptr, ptr %59, align 8
  %61 = getelementptr inbounds ptr, ptr %60, i64 54
  %62 = load ptr, ptr %61, align 8
  %63 = getelementptr inbounds %struct.NodeManager, ptr %62, i64 0, i32 4
  %64 = atomicrmw volatile add ptr %63, i32 1 seq_cst, align 4
  %65 = getelementptr inbounds %struct.NodeManager, ptr %62, i64 0, i32 5
  %66 = load ptr, ptr %65, align 8
  %67 = getelementptr inbounds %struct.ListManager, ptr %66, i64 0, i32 5
  %68 = load i32, ptr %67, align 8
  %.not.i.i.i.i.i = icmp slt i32 %64, %68
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i, label %69

69:                                               ; preds = %57
  %70 = getelementptr inbounds %struct.NodeManager, ptr %62, i64 0, i32 7
  %71 = load ptr, ptr %70, align 8
  %72 = getelementptr inbounds %struct.ListManager, ptr %71, i64 0, i32 5
  %73 = atomicrmw volatile add ptr %72, i32 1 seq_cst, align 4
  %74 = getelementptr inbounds %struct.ListManager, ptr %71, i64 0, i32 3
  %75 = load i32, ptr %74, align 8
  %76 = ashr i32 %73, %75
  %77 = icmp ugt i32 %76, 131071
  br i1 %77, label %78, label %81

78:                                               ; preds = %69
  %79 = getelementptr inbounds %struct.ListManager, ptr %71, i64 0, i32 6
  %80 = load ptr, ptr %79, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %80, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

81:                                               ; preds = %69
  %82 = zext i32 %76 to i64
  %83 = lshr i64 %82, 9
  %84 = getelementptr inbounds [256 x ptr], ptr %71, i64 0, i64 %83
  %85 = load atomic i64, ptr %84 acquire, align 8
  %.not.i.i.i4.i.i.i.i.i = icmp eq i64 %85, 0
  br i1 %.not.i.i.i4.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i:  ; preds = %81
  %86 = inttoptr i64 %85 to ptr
  %87 = and i64 %82, 511
  %88 = getelementptr inbounds ptr, ptr %86, i64 %87
  %89 = load atomic i64, ptr %88 acquire, align 8
  %.not.i.i5.i.i.i.i.i = icmp eq i64 %89, 0
  br i1 %.not.i.i5.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i, %81
  %90 = getelementptr inbounds %struct.ListManager, ptr %71, i64 0, i32 4
  br label %91

91:                                               ; preds = %91, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i
  %92 = atomicrmw volatile xchg ptr %90, i32 1 seq_cst, align 4
  %93 = icmp eq i32 %92, 1
  br i1 %93, label %91, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i, !llvm.loop !10

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i:          ; preds = %91
  %94 = load atomic i64, ptr %84 acquire, align 8
  %95 = inttoptr i64 %94 to ptr
  %.not.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %94, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i, label %96, label %131

96:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i
  %97 = getelementptr inbounds %struct.ListManager, ptr %71, i64 0, i32 6
  %98 = load ptr, ptr %97, align 8
  %99 = getelementptr inbounds %struct.LLVMRuntime, ptr %98, i64 0, i32 1
  %100 = getelementptr inbounds %struct.LLVMRuntime, ptr %98, i64 0, i32 28
  %101 = atomicrmw volatile add ptr %100, i64 4096 seq_cst, align 8
  %102 = getelementptr inbounds %struct.LLVMRuntime, ptr %98, i64 0, i32 1, i32 2
  %103 = load i64, ptr %102, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %103, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i.i.i, label %124, label %104

104:                                              ; preds = %96
  %105 = getelementptr inbounds %struct.LLVMRuntime, ptr %98, i64 0, i32 26
  br label %106

106:                                              ; preds = %106, %104
  %107 = atomicrmw volatile xchg ptr %105, i32 1 seq_cst, align 4
  %108 = icmp eq i32 %107, 1
  br i1 %108, label %106, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !10

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i: ; preds = %106
  %109 = load ptr, ptr %99, align 8
  %110 = ptrtoint ptr %109 to i64
  %111 = getelementptr inbounds %struct.LLVMRuntime, ptr %98, i64 0, i32 1, i32 1
  %112 = load ptr, ptr %111, align 8
  %113 = ptrtoint ptr %112 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %110
  %114 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i, 4095
  %115 = or i64 %114, 4096
  %116 = add i64 %115, %110
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %116, %113
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i, label %117

117:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i
  %118 = add i64 %114, %110
  %119 = inttoptr i64 %118 to ptr
  %120 = getelementptr i8, ptr %109, i64 %114
  %121 = getelementptr inbounds i8, ptr %120, i64 4096
  store ptr %121, ptr %99, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i: ; preds = %117, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i ], [ %119, %117 ]
  %122 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i, true
  %123 = atomicrmw volatile xchg ptr %105, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %98, i1 noundef zeroext %122, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i

124:                                              ; preds = %96
  %125 = getelementptr inbounds %struct.LLVMRuntime, ptr %98, i64 0, i32 2
  %126 = load ptr, ptr %125, align 8
  %127 = getelementptr inbounds %struct.LLVMRuntime, ptr %98, i64 0, i32 6
  %128 = load ptr, ptr %127, align 8
  %129 = tail call noundef ptr %126(ptr noundef %128, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i: ; preds = %124, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i ], [ %129, %124 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %130 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %130, ptr %84 release, align 8
  br label %131

131:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %95, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i ]
  %132 = and i32 %76, 511
  %133 = zext i32 %132 to i64
  %134 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i.i.i, i64 %133
  %135 = load atomic i64, ptr %134 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %135, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i.i.i, label %136, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i"

136:                                              ; preds = %131
  %137 = getelementptr inbounds %struct.ListManager, ptr %71, i64 0, i32 6
  %138 = load ptr, ptr %137, align 8
  %139 = getelementptr inbounds %struct.LLVMRuntime, ptr %138, i64 0, i32 1
  %140 = getelementptr inbounds %struct.ListManager, ptr %71, i64 0, i32 2
  %141 = load i64, ptr %140, align 8
  %142 = getelementptr inbounds %struct.ListManager, ptr %71, i64 0, i32 1
  %143 = load i64, ptr %142, align 8
  %144 = mul i64 %143, %141
  %145 = getelementptr inbounds %struct.LLVMRuntime, ptr %138, i64 0, i32 28
  %146 = atomicrmw volatile add ptr %145, i64 %144 seq_cst, align 8
  %147 = getelementptr inbounds %struct.LLVMRuntime, ptr %138, i64 0, i32 1, i32 2
  %148 = load i64, ptr %147, align 8
  %.not.i.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %148, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i, label %168, label %149

149:                                              ; preds = %136
  %150 = getelementptr inbounds %struct.LLVMRuntime, ptr %138, i64 0, i32 26
  br label %151

151:                                              ; preds = %151, %149
  %152 = atomicrmw volatile xchg ptr %150, i32 1 seq_cst, align 4
  %153 = icmp eq i32 %152, 1
  br i1 %153, label %151, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !10

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i: ; preds = %151
  %154 = load ptr, ptr %139, align 8
  %155 = ptrtoint ptr %154 to i64
  %156 = getelementptr inbounds %struct.LLVMRuntime, ptr %138, i64 0, i32 1, i32 1
  %157 = load ptr, ptr %156, align 8
  %158 = ptrtoint ptr %157 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %155
  %159 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i, 4095
  %160 = add i64 %159, %144
  %161 = add i64 %160, %155
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %161, %158
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i, label %162

162:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %163 = add i64 %159, %155
  %164 = inttoptr i64 %163 to ptr
  %165 = getelementptr inbounds i8, ptr %154, i64 %160
  store ptr %165, ptr %139, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i: ; preds = %162, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %164, %162 ]
  %166 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %167 = atomicrmw volatile xchg ptr %150, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %138, i1 noundef zeroext %166, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i

168:                                              ; preds = %136
  %169 = getelementptr inbounds %struct.LLVMRuntime, ptr %138, i64 0, i32 2
  %170 = load ptr, ptr %169, align 8
  %171 = getelementptr inbounds %struct.LLVMRuntime, ptr %138, i64 0, i32 6
  %172 = load ptr, ptr %171, align 8
  %173 = tail call noundef ptr %170(ptr noundef %172, i64 noundef %144, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i: ; preds = %168, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i ], [ %173, %168 ]
  %174 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %174, ptr %134 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i, %131
  %175 = atomicrmw volatile xchg ptr %90, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i:      ; preds = %57
  %176 = getelementptr inbounds %struct.ListManager, ptr %66, i64 0, i32 3
  %177 = load i32, ptr %176, align 8
  %178 = ashr i32 %64, %177
  %179 = sext i32 %178 to i64
  %180 = lshr i64 %179, 9
  %181 = getelementptr inbounds [256 x ptr], ptr %66, i64 0, i64 %180
  %182 = load atomic i64, ptr %181 acquire, align 8
  %.not.i.i.i.i.i.i.i.i = icmp ne i64 %182, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i.i.i.i.i)
  %183 = inttoptr i64 %182 to ptr
  %184 = and i64 %179, 511
  %185 = getelementptr inbounds ptr, ptr %183, i64 %184
  %186 = load atomic i64, ptr %185 acquire, align 8
  %187 = inttoptr i64 %186 to ptr
  %188 = getelementptr inbounds %struct.ListManager, ptr %66, i64 0, i32 1
  %189 = load i64, ptr %188, align 8
  %190 = load i32, ptr %176, align 8
  %notmask.i.i.i.i.i.i.i = shl nsw i32 -1, %190
  %191 = xor i32 %notmask.i.i.i.i.i.i.i, -1
  %192 = and i32 %64, %191
  %193 = sext i32 %192 to i64
  %194 = mul i64 %189, %193
  %195 = getelementptr inbounds i8, ptr %187, i64 %194
  %196 = load i32, ptr %195, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i: ; preds = %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i, %78
  %.0.i.i.i.i.i = phi i32 [ %196, %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i ], [ %73, %78 ], [ %73, %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i ], [ %73, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i" ]
  %197 = getelementptr inbounds %struct.NodeManager, ptr %62, i64 0, i32 7
  %198 = load ptr, ptr %197, align 8
  %199 = getelementptr inbounds %struct.ListManager, ptr %198, i64 0, i32 3
  %200 = load i32, ptr %199, align 8
  %201 = ashr i32 %.0.i.i.i.i.i, %200
  %202 = sext i32 %201 to i64
  %203 = lshr i64 %202, 9
  %204 = getelementptr inbounds [256 x ptr], ptr %198, i64 0, i64 %203
  %205 = load atomic i64, ptr %204 acquire, align 8
  %.not.i.i.i.i.i.i.i = icmp eq i64 %205, 0
  br i1 %.not.i.i.i.i.i.i.i, label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i", label %206

206:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i
  %207 = inttoptr i64 %205 to ptr
  %208 = and i64 %202, 511
  %209 = getelementptr inbounds ptr, ptr %207, i64 %208
  %210 = load atomic i64, ptr %209 acquire, align 8
  %211 = inttoptr i64 %210 to ptr
  br label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i"

"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i":    ; preds = %206, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i
  %212 = phi ptr [ %211, %206 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i ]
  %213 = getelementptr inbounds %struct.ListManager, ptr %198, i64 0, i32 1
  %214 = load i64, ptr %213, align 8
  %215 = load i32, ptr %199, align 8
  %notmask.i.i.i.i.i.i = shl nsw i32 -1, %215
  %216 = xor i32 %notmask.i.i.i.i.i.i, -1
  %217 = and i32 %.0.i.i.i.i.i, %216
  %218 = sext i32 %217 to i64
  %219 = mul i64 %214, %218
  %220 = getelementptr inbounds i8, ptr %212, i64 %219
  %221 = ptrtoint ptr %220 to i64
  %222 = atomicrmw volatile xchg ptr %48, i64 %221 seq_cst, align 8
  br label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i"

"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i": ; preds = %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i", %mutex_lock_i32.exit.i.i.i
  %223 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i, i32 0 seq_cst, align 4
  br label %Pointer_activate.exit

Pointer_activate.exit:                            ; preds = %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i", %true_block
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %3)
  %224 = lshr i64 %indvars.iv, 2
  %225 = and i64 %224, 1073741816
  %226 = getelementptr i8, ptr %44, i64 %225
  %227 = getelementptr inbounds i8, ptr %226, i64 32
  %228 = load ptr, ptr %227, align 8
  %229 = icmp eq ptr %228, null
  br i1 %229, label %230, label %Pointer_lookup_element.exit

230:                                              ; preds = %Pointer_activate.exit
  %231 = load ptr, ptr %4, align 8
  %232 = getelementptr inbounds %struct.LLVMRuntime, ptr %231, i64 0, i32 15
  %233 = load ptr, ptr %232, align 8
  %234 = getelementptr inbounds ptr, ptr %233, i64 54
  %235 = load ptr, ptr %234, align 8
  br label %Pointer_lookup_element.exit

Pointer_lookup_element.exit:                      ; preds = %230, %Pointer_activate.exit
  %.0.i = phi ptr [ %235, %230 ], [ %228, %Pointer_activate.exit ]
  %236 = and i32 %38, 31
  %237 = getelementptr inbounds i8, ptr %.0.i, i64 32
  %238 = shl nuw i32 1, %236
  %239 = atomicrmw volatile or ptr %237, i32 %238 seq_cst, align 4
  br label %after_if

after_if:                                         ; preds = %Pointer_lookup_element.exit, %for_loop_body
  %indvars.iv.next = add nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %indvars.iv.next, %wide.trip.count
  br i1 %exitcond.not, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @activity_begin_55_kernel_7_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.2042, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 16
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 4
  %5 = load i32, ptr %4, align 4
  %6 = getelementptr inbounds i8, ptr %3, i64 24
  %7 = load i32, ptr %6, align 4
  %.not = icmp eq i32 %5, 0
  %8 = select i1 %.not, i32 0, i32 %7
  %9 = getelementptr inbounds i8, ptr %3, i64 28
  store i32 %8, ptr %9, align 4
  ret void
}

; Function Attrs: nounwind
define void @activity_begin_55_kernel_8_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.4, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.2042, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nounwind
define internal void @function_body.4(ptr %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = alloca ptr, align 8
  %4 = getelementptr inbounds %struct.RuntimeContext.2042, ptr %0, i64 0, i32 1
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.LLVMRuntime, ptr %5, i64 0, i32 16
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds i8, ptr %7, i64 28
  %9 = load i32, ptr %8, align 4
  %10 = add i32 %9, 1
  %11 = sdiv i32 %10, 2
  %12 = icmp slt i32 %10, 0
  %13 = shl nsw i32 %11, 1
  %14 = icmp ne i32 %13, %10
  %15 = and i1 %12, %14
  %.neg = sext i1 %15 to i32
  %16 = add nsw i32 %11, %.neg
  %17 = tail call i32 @llvm.smax.i32(i32 %16, i32 512)
  %18 = mul i32 %17, %2
  %19 = add i32 %18, %17
  %20 = tail call i32 @llvm.smin.i32(i32 %9, i32 %19)
  %21 = icmp slt i32 %18, %20
  br i1 %21, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %22 = load ptr, ptr %0, align 8
  %23 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %22, i64 0, i32 1, i32 1
  %24 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %22, i64 0, i32 1, i32 0, i32 1
  %25 = sext i32 %18 to i64
  %wide.trip.count = sext i32 %20 to i64
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if, %for_loop_body.lr.ph
  %indvars.iv = phi i64 [ %25, %for_loop_body.lr.ph ], [ %indvars.iv.next, %after_if ]
  %26 = load ptr, ptr %23, align 8
  %27 = load i32, ptr %24, align 4
  %28 = sext i32 %27 to i64
  %29 = mul nsw i64 %28, 3
  %30 = add nsw i64 %29, %indvars.iv
  %31 = getelementptr double, ptr %26, i64 %30
  %32 = load double, ptr %31, align 8
  %33 = fcmp ogt double %32, 0.000000e+00
  br i1 %33, label %true_block, label %after_if

after_for.loopexit:                               ; preds = %after_if
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %34 = load ptr, ptr %4, align 8
  %35 = getelementptr inbounds %struct.LLVMRuntime, ptr %34, i64 0, i32 7
  %36 = load ptr, ptr %35, align 8
  %37 = trunc i64 %indvars.iv to i32
  %38 = sdiv i32 %37, 32
  %39 = getelementptr inbounds ptr, ptr %36, i64 5
  %40 = load ptr, ptr %39, align 8
  %getch.i = getelementptr %0, ptr %40, i64 0, i32 1
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %3)
  %41 = shl nsw i32 %38, 3
  %42 = sext i32 %41 to i64
  %43 = getelementptr i8, ptr %getch.i, i64 %42
  store volatile ptr %43, ptr %3, align 8
  %44 = getelementptr inbounds i8, ptr %43, i64 32
  %45 = load volatile ptr, ptr %44, align 8
  %46 = icmp eq ptr %45, null
  br i1 %46, label %47, label %Pointer_activate.exit

47:                                               ; preds = %true_block
  %.0..0..0..0..0..i = load volatile ptr, ptr %3, align 8
  %.0..0..0..0..0.2.i = load volatile ptr, ptr %3, align 8
  br label %48

48:                                               ; preds = %48, %47
  %49 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i, i32 1 seq_cst, align 4
  %50 = icmp eq i32 %49, 1
  br i1 %50, label %48, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !10

mutex_lock_i32.exit.i.i.i:                        ; preds = %48
  %51 = load volatile ptr, ptr %44, align 8
  %52 = icmp eq ptr %51, null
  br i1 %52, label %53, label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i"

53:                                               ; preds = %mutex_lock_i32.exit.i.i.i
  %54 = load ptr, ptr %4, align 8
  %55 = getelementptr inbounds %struct.LLVMRuntime, ptr %54, i64 0, i32 14
  %56 = load ptr, ptr %55, align 8
  %57 = getelementptr inbounds ptr, ptr %56, i64 57
  %58 = load ptr, ptr %57, align 8
  %59 = getelementptr inbounds %struct.NodeManager, ptr %58, i64 0, i32 4
  %60 = atomicrmw volatile add ptr %59, i32 1 seq_cst, align 4
  %61 = getelementptr inbounds %struct.NodeManager, ptr %58, i64 0, i32 5
  %62 = load ptr, ptr %61, align 8
  %63 = getelementptr inbounds %struct.ListManager, ptr %62, i64 0, i32 5
  %64 = load i32, ptr %63, align 8
  %.not.i.i.i.i.i = icmp slt i32 %60, %64
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i, label %65

65:                                               ; preds = %53
  %66 = getelementptr inbounds %struct.NodeManager, ptr %58, i64 0, i32 7
  %67 = load ptr, ptr %66, align 8
  %68 = getelementptr inbounds %struct.ListManager, ptr %67, i64 0, i32 5
  %69 = atomicrmw volatile add ptr %68, i32 1 seq_cst, align 4
  %70 = getelementptr inbounds %struct.ListManager, ptr %67, i64 0, i32 3
  %71 = load i32, ptr %70, align 8
  %72 = ashr i32 %69, %71
  %73 = icmp ugt i32 %72, 131071
  br i1 %73, label %74, label %77

74:                                               ; preds = %65
  %75 = getelementptr inbounds %struct.ListManager, ptr %67, i64 0, i32 6
  %76 = load ptr, ptr %75, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %76, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

77:                                               ; preds = %65
  %78 = zext i32 %72 to i64
  %79 = lshr i64 %78, 9
  %80 = getelementptr inbounds [256 x ptr], ptr %67, i64 0, i64 %79
  %81 = load atomic i64, ptr %80 acquire, align 8
  %.not.i.i.i4.i.i.i.i.i = icmp eq i64 %81, 0
  br i1 %.not.i.i.i4.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i:  ; preds = %77
  %82 = inttoptr i64 %81 to ptr
  %83 = and i64 %78, 511
  %84 = getelementptr inbounds ptr, ptr %82, i64 %83
  %85 = load atomic i64, ptr %84 acquire, align 8
  %.not.i.i5.i.i.i.i.i = icmp eq i64 %85, 0
  br i1 %.not.i.i5.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i, %77
  %86 = getelementptr inbounds %struct.ListManager, ptr %67, i64 0, i32 4
  br label %87

87:                                               ; preds = %87, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i
  %88 = atomicrmw volatile xchg ptr %86, i32 1 seq_cst, align 4
  %89 = icmp eq i32 %88, 1
  br i1 %89, label %87, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i, !llvm.loop !10

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i:          ; preds = %87
  %90 = load atomic i64, ptr %80 acquire, align 8
  %91 = inttoptr i64 %90 to ptr
  %.not.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %90, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i, label %92, label %127

92:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i
  %93 = getelementptr inbounds %struct.ListManager, ptr %67, i64 0, i32 6
  %94 = load ptr, ptr %93, align 8
  %95 = getelementptr inbounds %struct.LLVMRuntime, ptr %94, i64 0, i32 1
  %96 = getelementptr inbounds %struct.LLVMRuntime, ptr %94, i64 0, i32 28
  %97 = atomicrmw volatile add ptr %96, i64 4096 seq_cst, align 8
  %98 = getelementptr inbounds %struct.LLVMRuntime, ptr %94, i64 0, i32 1, i32 2
  %99 = load i64, ptr %98, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %99, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i.i.i, label %120, label %100

100:                                              ; preds = %92
  %101 = getelementptr inbounds %struct.LLVMRuntime, ptr %94, i64 0, i32 26
  br label %102

102:                                              ; preds = %102, %100
  %103 = atomicrmw volatile xchg ptr %101, i32 1 seq_cst, align 4
  %104 = icmp eq i32 %103, 1
  br i1 %104, label %102, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !10

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i: ; preds = %102
  %105 = load ptr, ptr %95, align 8
  %106 = ptrtoint ptr %105 to i64
  %107 = getelementptr inbounds %struct.LLVMRuntime, ptr %94, i64 0, i32 1, i32 1
  %108 = load ptr, ptr %107, align 8
  %109 = ptrtoint ptr %108 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %106
  %110 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i, 4095
  %111 = or i64 %110, 4096
  %112 = add i64 %111, %106
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %112, %109
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i, label %113

113:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i
  %114 = add i64 %110, %106
  %115 = inttoptr i64 %114 to ptr
  %116 = getelementptr i8, ptr %105, i64 %110
  %117 = getelementptr inbounds i8, ptr %116, i64 4096
  store ptr %117, ptr %95, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i: ; preds = %113, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i ], [ %115, %113 ]
  %118 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i, true
  %119 = atomicrmw volatile xchg ptr %101, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %94, i1 noundef zeroext %118, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i

120:                                              ; preds = %92
  %121 = getelementptr inbounds %struct.LLVMRuntime, ptr %94, i64 0, i32 2
  %122 = load ptr, ptr %121, align 8
  %123 = getelementptr inbounds %struct.LLVMRuntime, ptr %94, i64 0, i32 6
  %124 = load ptr, ptr %123, align 8
  %125 = tail call noundef ptr %122(ptr noundef %124, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i: ; preds = %120, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i ], [ %125, %120 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %126 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %126, ptr %80 release, align 8
  br label %127

127:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %91, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i ]
  %128 = and i32 %72, 511
  %129 = zext i32 %128 to i64
  %130 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i.i.i, i64 %129
  %131 = load atomic i64, ptr %130 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %131, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i.i.i, label %132, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i"

132:                                              ; preds = %127
  %133 = getelementptr inbounds %struct.ListManager, ptr %67, i64 0, i32 6
  %134 = load ptr, ptr %133, align 8
  %135 = getelementptr inbounds %struct.LLVMRuntime, ptr %134, i64 0, i32 1
  %136 = getelementptr inbounds %struct.ListManager, ptr %67, i64 0, i32 2
  %137 = load i64, ptr %136, align 8
  %138 = getelementptr inbounds %struct.ListManager, ptr %67, i64 0, i32 1
  %139 = load i64, ptr %138, align 8
  %140 = mul i64 %139, %137
  %141 = getelementptr inbounds %struct.LLVMRuntime, ptr %134, i64 0, i32 28
  %142 = atomicrmw volatile add ptr %141, i64 %140 seq_cst, align 8
  %143 = getelementptr inbounds %struct.LLVMRuntime, ptr %134, i64 0, i32 1, i32 2
  %144 = load i64, ptr %143, align 8
  %.not.i.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %144, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i, label %164, label %145

145:                                              ; preds = %132
  %146 = getelementptr inbounds %struct.LLVMRuntime, ptr %134, i64 0, i32 26
  br label %147

147:                                              ; preds = %147, %145
  %148 = atomicrmw volatile xchg ptr %146, i32 1 seq_cst, align 4
  %149 = icmp eq i32 %148, 1
  br i1 %149, label %147, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !10

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i: ; preds = %147
  %150 = load ptr, ptr %135, align 8
  %151 = ptrtoint ptr %150 to i64
  %152 = getelementptr inbounds %struct.LLVMRuntime, ptr %134, i64 0, i32 1, i32 1
  %153 = load ptr, ptr %152, align 8
  %154 = ptrtoint ptr %153 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %151
  %155 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i, 4095
  %156 = add i64 %155, %140
  %157 = add i64 %156, %151
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %157, %154
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i, label %158

158:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %159 = add i64 %155, %151
  %160 = inttoptr i64 %159 to ptr
  %161 = getelementptr inbounds i8, ptr %150, i64 %156
  store ptr %161, ptr %135, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i: ; preds = %158, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %160, %158 ]
  %162 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %163 = atomicrmw volatile xchg ptr %146, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %134, i1 noundef zeroext %162, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i

164:                                              ; preds = %132
  %165 = getelementptr inbounds %struct.LLVMRuntime, ptr %134, i64 0, i32 2
  %166 = load ptr, ptr %165, align 8
  %167 = getelementptr inbounds %struct.LLVMRuntime, ptr %134, i64 0, i32 6
  %168 = load ptr, ptr %167, align 8
  %169 = tail call noundef ptr %166(ptr noundef %168, i64 noundef %140, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i: ; preds = %164, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i ], [ %169, %164 ]
  %170 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %170, ptr %130 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i, %127
  %171 = atomicrmw volatile xchg ptr %86, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i:      ; preds = %53
  %172 = getelementptr inbounds %struct.ListManager, ptr %62, i64 0, i32 3
  %173 = load i32, ptr %172, align 8
  %174 = ashr i32 %60, %173
  %175 = sext i32 %174 to i64
  %176 = lshr i64 %175, 9
  %177 = getelementptr inbounds [256 x ptr], ptr %62, i64 0, i64 %176
  %178 = load atomic i64, ptr %177 acquire, align 8
  %.not.i.i.i.i.i.i.i.i = icmp ne i64 %178, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i.i.i.i.i)
  %179 = inttoptr i64 %178 to ptr
  %180 = and i64 %175, 511
  %181 = getelementptr inbounds ptr, ptr %179, i64 %180
  %182 = load atomic i64, ptr %181 acquire, align 8
  %183 = inttoptr i64 %182 to ptr
  %184 = getelementptr inbounds %struct.ListManager, ptr %62, i64 0, i32 1
  %185 = load i64, ptr %184, align 8
  %186 = load i32, ptr %172, align 8
  %notmask.i.i.i.i.i.i.i = shl nsw i32 -1, %186
  %187 = xor i32 %notmask.i.i.i.i.i.i.i, -1
  %188 = and i32 %60, %187
  %189 = sext i32 %188 to i64
  %190 = mul i64 %185, %189
  %191 = getelementptr inbounds i8, ptr %183, i64 %190
  %192 = load i32, ptr %191, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i: ; preds = %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i, %74
  %.0.i.i.i.i.i = phi i32 [ %192, %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i ], [ %69, %74 ], [ %69, %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i ], [ %69, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i" ]
  %193 = getelementptr inbounds %struct.NodeManager, ptr %58, i64 0, i32 7
  %194 = load ptr, ptr %193, align 8
  %195 = getelementptr inbounds %struct.ListManager, ptr %194, i64 0, i32 3
  %196 = load i32, ptr %195, align 8
  %197 = ashr i32 %.0.i.i.i.i.i, %196
  %198 = sext i32 %197 to i64
  %199 = lshr i64 %198, 9
  %200 = getelementptr inbounds [256 x ptr], ptr %194, i64 0, i64 %199
  %201 = load atomic i64, ptr %200 acquire, align 8
  %.not.i.i.i.i.i.i.i = icmp eq i64 %201, 0
  br i1 %.not.i.i.i.i.i.i.i, label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i", label %202

202:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i
  %203 = inttoptr i64 %201 to ptr
  %204 = and i64 %198, 511
  %205 = getelementptr inbounds ptr, ptr %203, i64 %204
  %206 = load atomic i64, ptr %205 acquire, align 8
  %207 = inttoptr i64 %206 to ptr
  br label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i"

"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i":    ; preds = %202, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i
  %208 = phi ptr [ %207, %202 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i ]
  %209 = getelementptr inbounds %struct.ListManager, ptr %194, i64 0, i32 1
  %210 = load i64, ptr %209, align 8
  %211 = load i32, ptr %195, align 8
  %notmask.i.i.i.i.i.i = shl nsw i32 -1, %211
  %212 = xor i32 %notmask.i.i.i.i.i.i, -1
  %213 = and i32 %.0.i.i.i.i.i, %212
  %214 = sext i32 %213 to i64
  %215 = mul i64 %210, %214
  %216 = getelementptr inbounds i8, ptr %208, i64 %215
  %217 = ptrtoint ptr %216 to i64
  %218 = atomicrmw volatile xchg ptr %44, i64 %217 seq_cst, align 8
  br label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i"

"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i": ; preds = %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i", %mutex_lock_i32.exit.i.i.i
  %219 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i, i32 0 seq_cst, align 4
  br label %Pointer_activate.exit

Pointer_activate.exit:                            ; preds = %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i", %true_block
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %3)
  %220 = lshr i64 %indvars.iv, 2
  %221 = and i64 %220, 1073741816
  %222 = getelementptr i8, ptr %getch.i, i64 %221
  %223 = getelementptr inbounds i8, ptr %222, i64 32
  %224 = load ptr, ptr %223, align 8
  %225 = icmp eq ptr %224, null
  br i1 %225, label %226, label %Pointer_lookup_element.exit

226:                                              ; preds = %Pointer_activate.exit
  %227 = load ptr, ptr %4, align 8
  %228 = getelementptr inbounds %struct.LLVMRuntime, ptr %227, i64 0, i32 15
  %229 = load ptr, ptr %228, align 8
  %230 = getelementptr inbounds ptr, ptr %229, i64 57
  %231 = load ptr, ptr %230, align 8
  br label %Pointer_lookup_element.exit

Pointer_lookup_element.exit:                      ; preds = %226, %Pointer_activate.exit
  %.0.i = phi ptr [ %231, %226 ], [ %224, %Pointer_activate.exit ]
  %232 = and i32 %37, 31
  %233 = getelementptr inbounds i8, ptr %.0.i, i64 32
  %234 = shl nuw i32 1, %232
  %235 = atomicrmw volatile or ptr %233, i32 %234 seq_cst, align 4
  br label %after_if

after_if:                                         ; preds = %Pointer_lookup_element.exit, %for_loop_body
  %indvars.iv.next = add nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %indvars.iv.next, %wide.trip.count
  br i1 %exitcond.not, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @activity_begin_55_kernel_9_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.2042, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 54
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @activity_begin_55_kernel_10_listgen_S54pointer(ptr %context) local_unnamed_addr #1 {
.lr.ph.i:
  %.sroa.2.i = alloca { [2 x i32], %struct.PhysicalCoordinates.2068 }, align 8
  %0 = alloca %2, align 8
  %1 = getelementptr inbounds %struct.RuntimeContext.2042, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 53
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %4, i64 54
  %8 = load ptr, ptr %7, align 8
  %9 = load atomic i64, ptr %6 acquire, align 8
  %.not.i.i.i.i = icmp ne i64 %9, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i)
  %10 = inttoptr i64 %9 to ptr
  %11 = load atomic i64, ptr %10 acquire, align 8
  %12 = inttoptr i64 %11 to ptr
  %.sroa.0.0.copyload.i = load ptr, ptr %12, align 8
  %.sroa.2.0..sroa_idx.i = getelementptr inbounds i8, ptr %12, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.i, ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.0..sroa_idx.i, i64 56, i1 false)
  %13 = getelementptr inbounds %2, ptr %0, i64 0, i32 2
  %.sroa.2.16.sroa_idx.i = getelementptr inbounds i8, ptr %.sroa.2.i, i64 8
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %16 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 4
  %17 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 6
  %18 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 2
  %19 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  store ptr %.sroa.0.0.copyload.i, ptr %0, align 8
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %0, i64 8
  store <2 x i32> <i32 0, i32 4>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %13, ptr noundef nonnull align 8 dereferenceable(48) %.sroa.2.16.sroa_idx.i, i64 48, i1 false)
  %20 = atomicrmw volatile add ptr %14, i32 1 seq_cst, align 4
  %21 = load i32, ptr %15, align 8
  %22 = ashr i32 %20, %21
  %23 = icmp ugt i32 %22, 131071
  br i1 %23, label %24, label %26

24:                                               ; preds = %.lr.ph.i
  %25 = load ptr, ptr %17, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %25, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

26:                                               ; preds = %.lr.ph.i
  %27 = zext i32 %22 to i64
  %28 = lshr i64 %27, 9
  %29 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %28
  %30 = load atomic i64, ptr %29 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %30, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %26
  %31 = inttoptr i64 %30 to ptr
  %32 = and i64 %27, 511
  %33 = getelementptr inbounds ptr, ptr %31, i64 %32
  %34 = load atomic i64, ptr %33 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %26
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %35 = atomicrmw volatile xchg ptr %16, i32 1 seq_cst, align 4
  %36 = icmp eq i32 %35, 1
  br i1 %36, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !10

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %37 = load atomic i64, ptr %29 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %37, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %39, label %73

39:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %40 = load ptr, ptr %17, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1
  %42 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 28
  %43 = atomicrmw volatile add ptr %42, i64 4096 seq_cst, align 8
  %44 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 2
  %45 = load i64, ptr %44, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %45, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %66, label %46

46:                                               ; preds = %39
  %47 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 26
  br label %48

48:                                               ; preds = %48, %46
  %49 = atomicrmw volatile xchg ptr %47, i32 1 seq_cst, align 4
  %50 = icmp eq i32 %49, 1
  br i1 %50, label %48, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !10

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %48
  %51 = load ptr, ptr %41, align 8
  %52 = ptrtoint ptr %51 to i64
  %53 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 1
  %54 = load ptr, ptr %53, align 8
  %55 = ptrtoint ptr %54 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %52
  %56 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %57 = or i64 %56, 4096
  %58 = add i64 %57, %52
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %58, %55
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %59

59:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %60 = add i64 %56, %52
  %61 = inttoptr i64 %60 to ptr
  %62 = getelementptr i8, ptr %51, i64 %56
  %63 = getelementptr inbounds i8, ptr %62, i64 4096
  store ptr %63, ptr %41, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %59, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %61, %59 ]
  %64 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %65 = atomicrmw volatile xchg ptr %47, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %40, i1 noundef zeroext %64, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

66:                                               ; preds = %39
  %67 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 2
  %68 = load ptr, ptr %67, align 8
  %69 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 6
  %70 = load ptr, ptr %69, align 8
  %71 = tail call noundef ptr %68(ptr noundef %70, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %66, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %71, %66 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %72 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %72, ptr %29 release, align 8
  br label %73

73:                                               ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %38, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %74 = and i32 %22, 511
  %75 = zext i32 %74 to i64
  %76 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %75
  %77 = load atomic i64, ptr %76 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %77, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %78, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

78:                                               ; preds = %73
  %79 = load ptr, ptr %17, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1
  %81 = load i64, ptr %18, align 8
  %82 = load i64, ptr %19, align 8
  %83 = mul i64 %82, %81
  %84 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 28
  %85 = atomicrmw volatile add ptr %84, i64 %83 seq_cst, align 8
  %86 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 2
  %87 = load i64, ptr %86, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %87, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %107, label %88

88:                                               ; preds = %78
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 26
  br label %90

90:                                               ; preds = %90, %88
  %91 = atomicrmw volatile xchg ptr %89, i32 1 seq_cst, align 4
  %92 = icmp eq i32 %91, 1
  br i1 %92, label %90, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !10

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %90
  %93 = load ptr, ptr %80, align 8
  %94 = ptrtoint ptr %93 to i64
  %95 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 1
  %96 = load ptr, ptr %95, align 8
  %97 = ptrtoint ptr %96 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %94
  %98 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %99 = add i64 %98, %83
  %100 = add i64 %99, %94
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %100, %97
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %101

101:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %102 = add i64 %98, %94
  %103 = inttoptr i64 %102 to ptr
  %104 = getelementptr inbounds i8, ptr %93, i64 %99
  store ptr %104, ptr %80, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %101, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %103, %101 ]
  %105 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %106 = atomicrmw volatile xchg ptr %89, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %79, i1 noundef zeroext %105, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

107:                                              ; preds = %78
  %108 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 2
  %109 = load ptr, ptr %108, align 8
  %110 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 6
  %111 = load ptr, ptr %110, align 8
  %112 = tail call noundef ptr %109(ptr noundef %111, i64 noundef %83, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %107, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %112, %107 ]
  %113 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %113, ptr %76 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %73
  %114 = atomicrmw volatile xchg ptr %16, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %24
  %115 = load i32, ptr %15, align 8
  %116 = ashr i32 %20, %115
  %117 = sext i32 %116 to i64
  %118 = lshr i64 %117, 9
  %119 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %118
  %120 = load atomic i64, ptr %119 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %120, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %121

121:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %122 = inttoptr i64 %120 to ptr
  %123 = and i64 %117, 511
  %124 = getelementptr inbounds ptr, ptr %122, i64 %123
  %125 = load atomic i64, ptr %124 acquire, align 8
  %126 = inttoptr i64 %125 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %121, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %127 = phi ptr [ %126, %121 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %128 = load i64, ptr %19, align 8
  %129 = load i32, ptr %15, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %129
  %130 = xor i32 %notmask.i.i.i.i, -1
  %131 = and i32 %20, %130
  %132 = sext i32 %131 to i64
  %133 = mul i64 %128, %132
  %134 = getelementptr inbounds i8, ptr %127, i64 %133
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %134, ptr nonnull align 8 %0, i64 %128, i1 false)
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @activity_begin_55_kernel_11_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.2042, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 55
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @activity_begin_55_kernel_12_listgen_S55bitmasked(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %2, align 8
  %1 = alloca %struct.PhysicalCoordinates.2068, align 4
  %2 = alloca %2, align 8
  %3 = getelementptr inbounds %struct.RuntimeContext.2042, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %2)
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 13
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %6, i64 54
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %10 = load i32, ptr %9, align 8
  %11 = getelementptr inbounds ptr, ptr %6, i64 55
  %12 = load ptr, ptr %11, align 8
  %13 = icmp sgt i32 %10, 0
  br i1 %13, label %.lr.ph61.i, label %element_listgen_nonroot.exit

.lr.ph61.i:                                       ; preds = %entry
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  %16 = getelementptr inbounds %2, ptr %0, i64 0, i32 1
  %17 = getelementptr inbounds %2, ptr %0, i64 0, i32 1, i64 1
  %18 = getelementptr inbounds %2, ptr %0, i64 0, i32 2
  %19 = getelementptr inbounds %2, ptr %2, i64 0, i32 2
  %20 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 5
  %21 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %22 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 4
  %23 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 6
  %24 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 2
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %2, i64 8
  br label %26

26:                                               ; preds = %._crit_edge.i, %.lr.ph61.i
  %.04359.i = phi i32 [ 0, %.lr.ph61.i ], [ %172, %._crit_edge.i ]
  %27 = load i32, ptr %14, align 8
  %28 = lshr i32 %.04359.i, %27
  %29 = sext i32 %28 to i64
  %30 = lshr i64 %29, 9
  %31 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %30
  %32 = load atomic i64, ptr %31 acquire, align 8
  %.not.i.i.i.i = icmp eq i64 %32, 0
  br i1 %.not.i.i.i.i, label %_ZN11ListManager3getI7ElementEERT_i.exit.i, label %33

33:                                               ; preds = %26
  %34 = inttoptr i64 %32 to ptr
  %35 = and i64 %29, 511
  %36 = getelementptr inbounds ptr, ptr %34, i64 %35
  %37 = load atomic i64, ptr %36 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit.i

_ZN11ListManager3getI7ElementEERT_i.exit.i:       ; preds = %33, %26
  %39 = phi ptr [ %38, %33 ], [ null, %26 ]
  %40 = load i64, ptr %15, align 8
  %41 = load i32, ptr %14, align 8
  %notmask.i.i.i = shl nsw i32 -1, %41
  %42 = xor i32 %notmask.i.i.i, -1
  %43 = and i32 %.04359.i, %42
  %44 = zext i32 %43 to i64
  %45 = mul i64 %40, %44
  %46 = getelementptr inbounds i8, ptr %39, i64 %45
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %0, ptr noundef nonnull align 8 dereferenceable(64) %46, i64 64, i1 false)
  %47 = load i32, ptr %16, align 8
  %48 = load i32, ptr %17, align 4
  %49 = icmp slt i32 %47, %48
  br i1 %49, label %.lr.ph58.i.preheader, label %._crit_edge.i

.lr.ph58.i.preheader:                             ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit.i
  br label %.lr.ph58.i

.lr.ph58.i:                                       ; preds = %.loopexit.i, %.lr.ph58.i.preheader
  %.04457.i = phi i32 [ %171, %.loopexit.i ], [ %47, %.lr.ph58.i.preheader ]
  call fastcc void @S54_refine_coordinates(ptr noundef nonnull %18, ptr noundef nonnull %1, i32 noundef %.04457.i) #1
  %50 = load ptr, ptr %0, align 8
  %51 = shl i32 %.04457.i, 3
  %52 = sext i32 %51 to i64
  %53 = getelementptr i8, ptr %50, i64 %52
  %54 = getelementptr inbounds i8, ptr %53, i64 32
  %55 = load ptr, ptr %54, align 8
  %.not = icmp eq ptr %55, null
  br i1 %.not, label %.loopexit.i, label %.lr.ph.i

.lr.ph.i:                                         ; preds = %.lr.ph58.i
  store ptr %55, ptr %2, align 8
  store <2 x i32> <i32 0, i32 32>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %19, ptr noundef nonnull align 4 dereferenceable(48) %1, i64 48, i1 false)
  %56 = atomicrmw volatile add ptr %20, i32 1 seq_cst, align 4
  %57 = load i32, ptr %21, align 8
  %58 = ashr i32 %56, %57
  %59 = icmp ugt i32 %58, 131071
  br i1 %59, label %60, label %62

60:                                               ; preds = %.lr.ph.i
  %61 = load ptr, ptr %23, align 8
  call fastcc void @taichi_assert_format(ptr noundef %61, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

62:                                               ; preds = %.lr.ph.i
  %63 = zext i32 %58 to i64
  %64 = lshr i64 %63, 9
  %65 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %64
  %66 = load atomic i64, ptr %65 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %66, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %62
  %67 = inttoptr i64 %66 to ptr
  %68 = and i64 %63, 511
  %69 = getelementptr inbounds ptr, ptr %67, i64 %68
  %70 = load atomic i64, ptr %69 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %70, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %62
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %71 = atomicrmw volatile xchg ptr %22, i32 1 seq_cst, align 4
  %72 = icmp eq i32 %71, 1
  br i1 %72, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !10

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %73 = load atomic i64, ptr %65 acquire, align 8
  %74 = inttoptr i64 %73 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %73, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %75, label %109

75:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %76 = load ptr, ptr %23, align 8
  %77 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1
  %78 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 28
  %79 = atomicrmw volatile add ptr %78, i64 4096 seq_cst, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 2
  %81 = load i64, ptr %80, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %81, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %102, label %82

82:                                               ; preds = %75
  %83 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 26
  br label %84

84:                                               ; preds = %84, %82
  %85 = atomicrmw volatile xchg ptr %83, i32 1 seq_cst, align 4
  %86 = icmp eq i32 %85, 1
  br i1 %86, label %84, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !10

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %84
  %87 = load ptr, ptr %77, align 8
  %88 = ptrtoint ptr %87 to i64
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 1
  %90 = load ptr, ptr %89, align 8
  %91 = ptrtoint ptr %90 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %88
  %92 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %93 = or i64 %92, 4096
  %94 = add i64 %93, %88
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %94, %91
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %95

95:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %96 = add i64 %92, %88
  %97 = inttoptr i64 %96 to ptr
  %98 = getelementptr i8, ptr %87, i64 %92
  %99 = getelementptr inbounds i8, ptr %98, i64 4096
  store ptr %99, ptr %77, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %95, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %97, %95 ]
  %100 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %101 = atomicrmw volatile xchg ptr %83, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %76, i1 noundef zeroext %100, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

102:                                              ; preds = %75
  %103 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 2
  %104 = load ptr, ptr %103, align 8
  %105 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 6
  %106 = load ptr, ptr %105, align 8
  %107 = call noundef ptr %104(ptr noundef %106, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %102, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %107, %102 ]
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %108 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %108, ptr %65 release, align 8
  br label %109

109:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %74, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %110 = and i32 %58, 511
  %111 = zext i32 %110 to i64
  %112 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %111
  %113 = load atomic i64, ptr %112 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %113, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %114, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

114:                                              ; preds = %109
  %115 = load ptr, ptr %23, align 8
  %116 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1
  %117 = load i64, ptr %24, align 8
  %118 = load i64, ptr %25, align 8
  %119 = mul i64 %118, %117
  %120 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 28
  %121 = atomicrmw volatile add ptr %120, i64 %119 seq_cst, align 8
  %122 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 2
  %123 = load i64, ptr %122, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %123, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %143, label %124

124:                                              ; preds = %114
  %125 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 26
  br label %126

126:                                              ; preds = %126, %124
  %127 = atomicrmw volatile xchg ptr %125, i32 1 seq_cst, align 4
  %128 = icmp eq i32 %127, 1
  br i1 %128, label %126, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !10

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %126
  %129 = load ptr, ptr %116, align 8
  %130 = ptrtoint ptr %129 to i64
  %131 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 1
  %132 = load ptr, ptr %131, align 8
  %133 = ptrtoint ptr %132 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %130
  %134 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %135 = add i64 %134, %119
  %136 = add i64 %135, %130
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %136, %133
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %137

137:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %138 = add i64 %134, %130
  %139 = inttoptr i64 %138 to ptr
  %140 = getelementptr inbounds i8, ptr %129, i64 %135
  store ptr %140, ptr %116, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %137, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %139, %137 ]
  %141 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %142 = atomicrmw volatile xchg ptr %125, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %115, i1 noundef zeroext %141, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

143:                                              ; preds = %114
  %144 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 2
  %145 = load ptr, ptr %144, align 8
  %146 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 6
  %147 = load ptr, ptr %146, align 8
  %148 = call noundef ptr %145(ptr noundef %147, i64 noundef %119, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %143, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %148, %143 ]
  %149 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %149, ptr %112 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %109
  %150 = atomicrmw volatile xchg ptr %22, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %60
  %151 = load i32, ptr %21, align 8
  %152 = ashr i32 %56, %151
  %153 = sext i32 %152 to i64
  %154 = lshr i64 %153, 9
  %155 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %154
  %156 = load atomic i64, ptr %155 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %156, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %157

157:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %158 = inttoptr i64 %156 to ptr
  %159 = and i64 %153, 511
  %160 = getelementptr inbounds ptr, ptr %158, i64 %159
  %161 = load atomic i64, ptr %160 acquire, align 8
  %162 = inttoptr i64 %161 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %157, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %163 = phi ptr [ %162, %157 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %164 = load i64, ptr %25, align 8
  %165 = load i32, ptr %21, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %165
  %166 = xor i32 %notmask.i.i.i.i, -1
  %167 = and i32 %56, %166
  %168 = sext i32 %167 to i64
  %169 = mul i64 %164, %168
  %170 = getelementptr inbounds i8, ptr %163, i64 %169
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %170, ptr nonnull align 8 %2, i64 %164, i1 false)
  br label %.loopexit.i, !llvm.loop !12

.loopexit.i:                                      ; preds = %_ZN11ListManager6appendEPv.exit.i, %.lr.ph58.i
  %171 = add i32 %.04457.i, 1
  %exitcond.not.i = icmp eq i32 %171, %48
  br i1 %exitcond.not.i, label %._crit_edge.i.loopexit, label %.lr.ph58.i, !llvm.loop !13

._crit_edge.i.loopexit:                           ; preds = %.loopexit.i
  br label %._crit_edge.i

._crit_edge.i:                                    ; preds = %._crit_edge.i.loopexit, %_ZN11ListManager3getI7ElementEERT_i.exit.i
  %172 = add nuw nsw i32 %.04359.i, 1
  %exitcond63.not.i = icmp eq i32 %172, %10
  br i1 %exitcond63.not.i, label %element_listgen_nonroot.exit.loopexit, label %26, !llvm.loop !14

element_listgen_nonroot.exit.loopexit:            ; preds = %._crit_edge.i
  br label %element_listgen_nonroot.exit

element_listgen_nonroot.exit:                     ; preds = %element_listgen_nonroot.exit.loopexit, %entry
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %2)
  ret void
}

; Function Attrs: nounwind
define void @activity_begin_55_kernel_13_struct_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.cpu_block_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.RuntimeContext.2042, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 55
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds %struct.ListManager, ptr %6, i64 0, i32 5
  %8 = load i32, ptr %7, align 8
  store ptr %context, ptr %0, align 8
  %9 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  store ptr @function_body.5, ptr %9, align 8
  %10 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  store ptr %6, ptr %10, align 8
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  store <2 x i32> <i32 32, i32 8>, ptr %11, align 8
  %12 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  store i64 1, ptr %12, align 8
  %13 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 12
  %14 = load ptr, ptr %13, align 8
  %15 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 11
  %16 = load ptr, ptr %15, align 8
  %17 = shl nsw i32 %8, 3
  call void %14(ptr noundef %16, i32 noundef %17, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_struct_for_block_helper) #1
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind
define internal void @function_body.5(ptr %0, ptr nocapture readnone %1, ptr nocapture readonly %2, i32 %3, i32 %4) #3 {
allocs:
  %5 = getelementptr inbounds %2, ptr %2, i64 0, i32 2
  %6 = icmp sgt i32 %4, %3
  br i1 %6, label %loop_body.preheader, label %func_exit

loop_body.preheader:                              ; preds = %allocs
  %.pre25 = load ptr, ptr %2, align 8
  %7 = sub i32 %4, %3
  %8 = xor i32 %3, -1
  %9 = add i32 %8, %4
  %xtraiter = and i32 %7, 7
  %lcmp.mod.not = icmp eq i32 %xtraiter, 0
  br i1 %lcmp.mod.not, label %loop_body.prol.loopexit, label %loop_body.prol.preheader

loop_body.prol.preheader:                         ; preds = %loop_body.preheader
  br label %loop_body.prol

loop_body.prol:                                   ; preds = %loop_body_tail.prol, %loop_body.prol.preheader
  %lsr.iv27 = phi i32 [ %xtraiter, %loop_body.prol.preheader ], [ %lsr.iv.next28, %loop_body_tail.prol ]
  %10 = phi ptr [ %51, %loop_body_tail.prol ], [ %.pre25, %loop_body.prol.preheader ]
  %.024.prol = phi i32 [ %52, %loop_body_tail.prol ], [ %3, %loop_body.prol.preheader ]
  %11 = getelementptr inbounds i8, ptr %10, i64 32
  %12 = sdiv i32 %.024.prol, 8
  %13 = sext i32 %12 to i64
  %14 = getelementptr inbounds i8, ptr %11, i64 %13
  %15 = load i8, ptr %14, align 1
  %16 = zext i8 %15 to i32
  %17 = and i32 %.024.prol, 7
  %18 = shl nuw nsw i32 1, %17
  %19 = and i32 %18, %16
  %.not.prol = icmp eq i32 %19, 0
  br i1 %.not.prol, label %loop_body_tail.prol, label %struct_for_body_body.prol

struct_for_body_body.prol:                        ; preds = %loop_body.prol
  %20 = load i32, ptr %5, align 4
  %21 = shl i32 %20, 5
  %22 = and i32 %.024.prol, 31
  %23 = or i32 %21, %22
  %24 = load ptr, ptr %0, align 8
  %25 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %24, i64 0, i32 2, i32 1
  %26 = load ptr, ptr %25, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %24, i64 0, i32 2, i32 0, i32 1
  %28 = load i32, ptr %27, align 4
  %29 = sext i32 %28 to i64
  %30 = sext i32 %23 to i64
  %31 = getelementptr i32, ptr %26, i64 %30
  %32 = load i32, ptr %31, align 4
  %33 = add nsw i64 %29, %30
  %34 = getelementptr i32, ptr %26, i64 %33
  store i32 %32, ptr %34, align 4
  store i32 0, ptr %31, align 4
  %35 = load ptr, ptr %0, align 8
  %36 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %35, i64 0, i32 3, i32 1
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %35, i64 0, i32 3, i32 0, i32 1
  %39 = getelementptr double, ptr %37, i64 %30
  store double 0.000000e+00, ptr %39, align 8
  %40 = load ptr, ptr %36, align 8
  %41 = load i32, ptr %38, align 4
  %42 = sext i32 %41 to i64
  %43 = add nsw i64 %42, %30
  %44 = getelementptr double, ptr %40, i64 %43
  store double 0.000000e+00, ptr %44, align 8
  %45 = load ptr, ptr %36, align 8
  %46 = load i32, ptr %38, align 4
  %47 = sext i32 %46 to i64
  %48 = shl nsw i64 %47, 1
  %49 = add nsw i64 %48, %30
  %50 = getelementptr double, ptr %45, i64 %49
  store double 0.000000e+00, ptr %50, align 8
  %.pre.prol = load ptr, ptr %2, align 8
  br label %loop_body_tail.prol

loop_body_tail.prol:                              ; preds = %struct_for_body_body.prol, %loop_body.prol
  %51 = phi ptr [ %.pre.prol, %struct_for_body_body.prol ], [ %10, %loop_body.prol ]
  %52 = add i32 %.024.prol, 1
  %lsr.iv.next28 = add nsw i32 %lsr.iv27, -1
  %prol.iter.cmp.not = icmp eq i32 %lsr.iv.next28, 0
  br i1 %prol.iter.cmp.not, label %loop_body.prol.loopexit.loopexit, label %loop_body.prol, !llvm.loop !15

loop_body.prol.loopexit.loopexit:                 ; preds = %loop_body_tail.prol
  br label %loop_body.prol.loopexit

loop_body.prol.loopexit:                          ; preds = %loop_body.prol.loopexit.loopexit, %loop_body.preheader
  %.unr = phi ptr [ %.pre25, %loop_body.preheader ], [ %51, %loop_body.prol.loopexit.loopexit ]
  %.024.unr = phi i32 [ %3, %loop_body.preheader ], [ %52, %loop_body.prol.loopexit.loopexit ]
  %53 = icmp ult i32 %9, 7
  br i1 %53, label %func_exit, label %loop_body.preheader.new

loop_body.preheader.new:                          ; preds = %loop_body.prol.loopexit
  %54 = and i32 %.024.unr, 7
  %55 = add i32 %.024.unr, 1
  %56 = and i32 %55, 7
  %57 = add i32 %.024.unr, 2
  %58 = and i32 %57, 7
  %59 = add i32 %.024.unr, 3
  %60 = and i32 %59, 7
  %61 = xor i32 %54, 4
  %62 = add i32 %.024.unr, 5
  %63 = and i32 %62, 7
  %64 = add i32 %.024.unr, 6
  %65 = and i32 %64, 7
  %66 = add i32 %.024.unr, 7
  %67 = and i32 %66, 7
  %68 = shl nuw nsw i32 1, %54
  %69 = shl nuw nsw i32 1, %56
  %70 = shl nuw nsw i32 1, %58
  %71 = shl nuw nsw i32 1, %60
  %72 = shl nuw nsw i32 1, %61
  %73 = shl nuw nsw i32 1, %63
  %74 = shl nuw nsw i32 1, %65
  %75 = shl nuw nsw i32 1, %67
  br label %loop_body

loop_body:                                        ; preds = %loop_body_tail.7, %loop_body.preheader.new
  %lsr.iv = phi i32 [ %lsr.iv.next, %loop_body_tail.7 ], [ %66, %loop_body.preheader.new ]
  %76 = phi ptr [ %.unr, %loop_body.preheader.new ], [ %371, %loop_body_tail.7 ]
  %77 = add i32 %lsr.iv, -7
  %78 = getelementptr inbounds i8, ptr %76, i64 32
  %79 = sdiv i32 %77, 8
  %80 = sext i32 %79 to i64
  %81 = getelementptr inbounds i8, ptr %78, i64 %80
  %82 = load i8, ptr %81, align 1
  %83 = zext i8 %82 to i32
  %84 = and i32 %68, %83
  %.not = icmp eq i32 %84, 0
  br i1 %.not, label %loop_body_tail, label %struct_for_body_body

loop_body_tail:                                   ; preds = %struct_for_body_body, %loop_body
  %85 = phi ptr [ %.pre, %struct_for_body_body ], [ %76, %loop_body ]
  %86 = add i32 %lsr.iv, -6
  %87 = getelementptr inbounds i8, ptr %85, i64 32
  %88 = add i32 %77, 1
  %89 = sdiv i32 %88, 8
  %90 = sext i32 %89 to i64
  %91 = getelementptr inbounds i8, ptr %87, i64 %90
  %92 = load i8, ptr %91, align 1
  %93 = zext i8 %92 to i32
  %94 = and i32 %69, %93
  %.not.1 = icmp eq i32 %94, 0
  br i1 %.not.1, label %loop_body_tail.1, label %struct_for_body_body.1

struct_for_body_body.1:                           ; preds = %loop_body_tail
  %95 = load i32, ptr %5, align 4
  %96 = shl i32 %95, 5
  %97 = and i32 %86, 31
  %98 = or i32 %96, %97
  %99 = load ptr, ptr %0, align 8
  %100 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %99, i64 0, i32 2, i32 1
  %101 = load ptr, ptr %100, align 8
  %102 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %99, i64 0, i32 2, i32 0, i32 1
  %103 = load i32, ptr %102, align 4
  %104 = sext i32 %103 to i64
  %105 = sext i32 %98 to i64
  %106 = getelementptr i32, ptr %101, i64 %105
  %107 = load i32, ptr %106, align 4
  %108 = add nsw i64 %104, %105
  %109 = getelementptr i32, ptr %101, i64 %108
  store i32 %107, ptr %109, align 4
  store i32 0, ptr %106, align 4
  %110 = load ptr, ptr %0, align 8
  %111 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %110, i64 0, i32 3, i32 1
  %112 = load ptr, ptr %111, align 8
  %113 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %110, i64 0, i32 3, i32 0, i32 1
  %114 = getelementptr double, ptr %112, i64 %105
  store double 0.000000e+00, ptr %114, align 8
  %115 = load ptr, ptr %111, align 8
  %116 = load i32, ptr %113, align 4
  %117 = sext i32 %116 to i64
  %118 = add nsw i64 %117, %105
  %119 = getelementptr double, ptr %115, i64 %118
  store double 0.000000e+00, ptr %119, align 8
  %120 = load ptr, ptr %111, align 8
  %121 = load i32, ptr %113, align 4
  %122 = sext i32 %121 to i64
  %123 = shl nsw i64 %122, 1
  %124 = add nsw i64 %123, %105
  %125 = getelementptr double, ptr %120, i64 %124
  store double 0.000000e+00, ptr %125, align 8
  %.pre.1 = load ptr, ptr %2, align 8
  br label %loop_body_tail.1

loop_body_tail.1:                                 ; preds = %struct_for_body_body.1, %loop_body_tail
  %126 = phi ptr [ %.pre.1, %struct_for_body_body.1 ], [ %85, %loop_body_tail ]
  %127 = add i32 %lsr.iv, -5
  %128 = getelementptr inbounds i8, ptr %126, i64 32
  %129 = add i32 %88, 1
  %130 = sdiv i32 %129, 8
  %131 = sext i32 %130 to i64
  %132 = getelementptr inbounds i8, ptr %128, i64 %131
  %133 = load i8, ptr %132, align 1
  %134 = zext i8 %133 to i32
  %135 = and i32 %70, %134
  %.not.2 = icmp eq i32 %135, 0
  br i1 %.not.2, label %loop_body_tail.2, label %struct_for_body_body.2

struct_for_body_body.2:                           ; preds = %loop_body_tail.1
  %136 = load i32, ptr %5, align 4
  %137 = shl i32 %136, 5
  %138 = and i32 %127, 31
  %139 = or i32 %137, %138
  %140 = load ptr, ptr %0, align 8
  %141 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %140, i64 0, i32 2, i32 1
  %142 = load ptr, ptr %141, align 8
  %143 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %140, i64 0, i32 2, i32 0, i32 1
  %144 = load i32, ptr %143, align 4
  %145 = sext i32 %144 to i64
  %146 = sext i32 %139 to i64
  %147 = getelementptr i32, ptr %142, i64 %146
  %148 = load i32, ptr %147, align 4
  %149 = add nsw i64 %145, %146
  %150 = getelementptr i32, ptr %142, i64 %149
  store i32 %148, ptr %150, align 4
  store i32 0, ptr %147, align 4
  %151 = load ptr, ptr %0, align 8
  %152 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %151, i64 0, i32 3, i32 1
  %153 = load ptr, ptr %152, align 8
  %154 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %151, i64 0, i32 3, i32 0, i32 1
  %155 = getelementptr double, ptr %153, i64 %146
  store double 0.000000e+00, ptr %155, align 8
  %156 = load ptr, ptr %152, align 8
  %157 = load i32, ptr %154, align 4
  %158 = sext i32 %157 to i64
  %159 = add nsw i64 %158, %146
  %160 = getelementptr double, ptr %156, i64 %159
  store double 0.000000e+00, ptr %160, align 8
  %161 = load ptr, ptr %152, align 8
  %162 = load i32, ptr %154, align 4
  %163 = sext i32 %162 to i64
  %164 = shl nsw i64 %163, 1
  %165 = add nsw i64 %164, %146
  %166 = getelementptr double, ptr %161, i64 %165
  store double 0.000000e+00, ptr %166, align 8
  %.pre.2 = load ptr, ptr %2, align 8
  br label %loop_body_tail.2

loop_body_tail.2:                                 ; preds = %struct_for_body_body.2, %loop_body_tail.1
  %167 = phi ptr [ %.pre.2, %struct_for_body_body.2 ], [ %126, %loop_body_tail.1 ]
  %168 = add i32 %lsr.iv, -4
  %169 = getelementptr inbounds i8, ptr %167, i64 32
  %170 = add i32 %129, 1
  %171 = sdiv i32 %170, 8
  %172 = sext i32 %171 to i64
  %173 = getelementptr inbounds i8, ptr %169, i64 %172
  %174 = load i8, ptr %173, align 1
  %175 = zext i8 %174 to i32
  %176 = and i32 %71, %175
  %.not.3 = icmp eq i32 %176, 0
  br i1 %.not.3, label %loop_body_tail.3, label %struct_for_body_body.3

struct_for_body_body.3:                           ; preds = %loop_body_tail.2
  %177 = load i32, ptr %5, align 4
  %178 = shl i32 %177, 5
  %179 = and i32 %168, 31
  %180 = or i32 %178, %179
  %181 = load ptr, ptr %0, align 8
  %182 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %181, i64 0, i32 2, i32 1
  %183 = load ptr, ptr %182, align 8
  %184 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %181, i64 0, i32 2, i32 0, i32 1
  %185 = load i32, ptr %184, align 4
  %186 = sext i32 %185 to i64
  %187 = sext i32 %180 to i64
  %188 = getelementptr i32, ptr %183, i64 %187
  %189 = load i32, ptr %188, align 4
  %190 = add nsw i64 %186, %187
  %191 = getelementptr i32, ptr %183, i64 %190
  store i32 %189, ptr %191, align 4
  store i32 0, ptr %188, align 4
  %192 = load ptr, ptr %0, align 8
  %193 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %192, i64 0, i32 3, i32 1
  %194 = load ptr, ptr %193, align 8
  %195 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %192, i64 0, i32 3, i32 0, i32 1
  %196 = getelementptr double, ptr %194, i64 %187
  store double 0.000000e+00, ptr %196, align 8
  %197 = load ptr, ptr %193, align 8
  %198 = load i32, ptr %195, align 4
  %199 = sext i32 %198 to i64
  %200 = add nsw i64 %199, %187
  %201 = getelementptr double, ptr %197, i64 %200
  store double 0.000000e+00, ptr %201, align 8
  %202 = load ptr, ptr %193, align 8
  %203 = load i32, ptr %195, align 4
  %204 = sext i32 %203 to i64
  %205 = shl nsw i64 %204, 1
  %206 = add nsw i64 %205, %187
  %207 = getelementptr double, ptr %202, i64 %206
  store double 0.000000e+00, ptr %207, align 8
  %.pre.3 = load ptr, ptr %2, align 8
  br label %loop_body_tail.3

loop_body_tail.3:                                 ; preds = %struct_for_body_body.3, %loop_body_tail.2
  %208 = phi ptr [ %.pre.3, %struct_for_body_body.3 ], [ %167, %loop_body_tail.2 ]
  %209 = add i32 %lsr.iv, -3
  %210 = getelementptr inbounds i8, ptr %208, i64 32
  %211 = add i32 %170, 1
  %212 = sdiv i32 %211, 8
  %213 = sext i32 %212 to i64
  %214 = getelementptr inbounds i8, ptr %210, i64 %213
  %215 = load i8, ptr %214, align 1
  %216 = zext i8 %215 to i32
  %217 = and i32 %72, %216
  %.not.4 = icmp eq i32 %217, 0
  br i1 %.not.4, label %loop_body_tail.4, label %struct_for_body_body.4

struct_for_body_body.4:                           ; preds = %loop_body_tail.3
  %218 = load i32, ptr %5, align 4
  %219 = shl i32 %218, 5
  %220 = and i32 %209, 31
  %221 = or i32 %219, %220
  %222 = load ptr, ptr %0, align 8
  %223 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %222, i64 0, i32 2, i32 1
  %224 = load ptr, ptr %223, align 8
  %225 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %222, i64 0, i32 2, i32 0, i32 1
  %226 = load i32, ptr %225, align 4
  %227 = sext i32 %226 to i64
  %228 = sext i32 %221 to i64
  %229 = getelementptr i32, ptr %224, i64 %228
  %230 = load i32, ptr %229, align 4
  %231 = add nsw i64 %227, %228
  %232 = getelementptr i32, ptr %224, i64 %231
  store i32 %230, ptr %232, align 4
  store i32 0, ptr %229, align 4
  %233 = load ptr, ptr %0, align 8
  %234 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %233, i64 0, i32 3, i32 1
  %235 = load ptr, ptr %234, align 8
  %236 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %233, i64 0, i32 3, i32 0, i32 1
  %237 = getelementptr double, ptr %235, i64 %228
  store double 0.000000e+00, ptr %237, align 8
  %238 = load ptr, ptr %234, align 8
  %239 = load i32, ptr %236, align 4
  %240 = sext i32 %239 to i64
  %241 = add nsw i64 %240, %228
  %242 = getelementptr double, ptr %238, i64 %241
  store double 0.000000e+00, ptr %242, align 8
  %243 = load ptr, ptr %234, align 8
  %244 = load i32, ptr %236, align 4
  %245 = sext i32 %244 to i64
  %246 = shl nsw i64 %245, 1
  %247 = add nsw i64 %246, %228
  %248 = getelementptr double, ptr %243, i64 %247
  store double 0.000000e+00, ptr %248, align 8
  %.pre.4 = load ptr, ptr %2, align 8
  br label %loop_body_tail.4

loop_body_tail.4:                                 ; preds = %struct_for_body_body.4, %loop_body_tail.3
  %249 = phi ptr [ %.pre.4, %struct_for_body_body.4 ], [ %208, %loop_body_tail.3 ]
  %250 = add i32 %lsr.iv, -2
  %251 = getelementptr inbounds i8, ptr %249, i64 32
  %252 = add i32 %211, 1
  %253 = sdiv i32 %252, 8
  %254 = sext i32 %253 to i64
  %255 = getelementptr inbounds i8, ptr %251, i64 %254
  %256 = load i8, ptr %255, align 1
  %257 = zext i8 %256 to i32
  %258 = and i32 %73, %257
  %.not.5 = icmp eq i32 %258, 0
  br i1 %.not.5, label %loop_body_tail.5, label %struct_for_body_body.5

struct_for_body_body.5:                           ; preds = %loop_body_tail.4
  %259 = load i32, ptr %5, align 4
  %260 = shl i32 %259, 5
  %261 = and i32 %250, 31
  %262 = or i32 %260, %261
  %263 = load ptr, ptr %0, align 8
  %264 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %263, i64 0, i32 2, i32 1
  %265 = load ptr, ptr %264, align 8
  %266 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %263, i64 0, i32 2, i32 0, i32 1
  %267 = load i32, ptr %266, align 4
  %268 = sext i32 %267 to i64
  %269 = sext i32 %262 to i64
  %270 = getelementptr i32, ptr %265, i64 %269
  %271 = load i32, ptr %270, align 4
  %272 = add nsw i64 %268, %269
  %273 = getelementptr i32, ptr %265, i64 %272
  store i32 %271, ptr %273, align 4
  store i32 0, ptr %270, align 4
  %274 = load ptr, ptr %0, align 8
  %275 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %274, i64 0, i32 3, i32 1
  %276 = load ptr, ptr %275, align 8
  %277 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %274, i64 0, i32 3, i32 0, i32 1
  %278 = getelementptr double, ptr %276, i64 %269
  store double 0.000000e+00, ptr %278, align 8
  %279 = load ptr, ptr %275, align 8
  %280 = load i32, ptr %277, align 4
  %281 = sext i32 %280 to i64
  %282 = add nsw i64 %281, %269
  %283 = getelementptr double, ptr %279, i64 %282
  store double 0.000000e+00, ptr %283, align 8
  %284 = load ptr, ptr %275, align 8
  %285 = load i32, ptr %277, align 4
  %286 = sext i32 %285 to i64
  %287 = shl nsw i64 %286, 1
  %288 = add nsw i64 %287, %269
  %289 = getelementptr double, ptr %284, i64 %288
  store double 0.000000e+00, ptr %289, align 8
  %.pre.5 = load ptr, ptr %2, align 8
  br label %loop_body_tail.5

loop_body_tail.5:                                 ; preds = %struct_for_body_body.5, %loop_body_tail.4
  %290 = phi ptr [ %.pre.5, %struct_for_body_body.5 ], [ %249, %loop_body_tail.4 ]
  %291 = add i32 %lsr.iv, -1
  %292 = getelementptr inbounds i8, ptr %290, i64 32
  %293 = add i32 %252, 1
  %294 = sdiv i32 %293, 8
  %295 = sext i32 %294 to i64
  %296 = getelementptr inbounds i8, ptr %292, i64 %295
  %297 = load i8, ptr %296, align 1
  %298 = zext i8 %297 to i32
  %299 = and i32 %74, %298
  %.not.6 = icmp eq i32 %299, 0
  br i1 %.not.6, label %loop_body_tail.6, label %struct_for_body_body.6

struct_for_body_body.6:                           ; preds = %loop_body_tail.5
  %300 = load i32, ptr %5, align 4
  %301 = shl i32 %300, 5
  %302 = and i32 %291, 31
  %303 = or i32 %301, %302
  %304 = load ptr, ptr %0, align 8
  %305 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %304, i64 0, i32 2, i32 1
  %306 = load ptr, ptr %305, align 8
  %307 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %304, i64 0, i32 2, i32 0, i32 1
  %308 = load i32, ptr %307, align 4
  %309 = sext i32 %308 to i64
  %310 = sext i32 %303 to i64
  %311 = getelementptr i32, ptr %306, i64 %310
  %312 = load i32, ptr %311, align 4
  %313 = add nsw i64 %309, %310
  %314 = getelementptr i32, ptr %306, i64 %313
  store i32 %312, ptr %314, align 4
  store i32 0, ptr %311, align 4
  %315 = load ptr, ptr %0, align 8
  %316 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %315, i64 0, i32 3, i32 1
  %317 = load ptr, ptr %316, align 8
  %318 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %315, i64 0, i32 3, i32 0, i32 1
  %319 = getelementptr double, ptr %317, i64 %310
  store double 0.000000e+00, ptr %319, align 8
  %320 = load ptr, ptr %316, align 8
  %321 = load i32, ptr %318, align 4
  %322 = sext i32 %321 to i64
  %323 = add nsw i64 %322, %310
  %324 = getelementptr double, ptr %320, i64 %323
  store double 0.000000e+00, ptr %324, align 8
  %325 = load ptr, ptr %316, align 8
  %326 = load i32, ptr %318, align 4
  %327 = sext i32 %326 to i64
  %328 = shl nsw i64 %327, 1
  %329 = add nsw i64 %328, %310
  %330 = getelementptr double, ptr %325, i64 %329
  store double 0.000000e+00, ptr %330, align 8
  %.pre.6 = load ptr, ptr %2, align 8
  br label %loop_body_tail.6

loop_body_tail.6:                                 ; preds = %struct_for_body_body.6, %loop_body_tail.5
  %331 = phi ptr [ %.pre.6, %struct_for_body_body.6 ], [ %290, %loop_body_tail.5 ]
  %332 = getelementptr inbounds i8, ptr %331, i64 32
  %333 = add i32 %293, 1
  %334 = sdiv i32 %333, 8
  %335 = sext i32 %334 to i64
  %336 = getelementptr inbounds i8, ptr %332, i64 %335
  %337 = load i8, ptr %336, align 1
  %338 = zext i8 %337 to i32
  %339 = and i32 %75, %338
  %.not.7 = icmp eq i32 %339, 0
  br i1 %.not.7, label %loop_body_tail.7, label %struct_for_body_body.7

struct_for_body_body.7:                           ; preds = %loop_body_tail.6
  %340 = load i32, ptr %5, align 4
  %341 = shl i32 %340, 5
  %342 = and i32 %lsr.iv, 31
  %343 = or i32 %341, %342
  %344 = load ptr, ptr %0, align 8
  %345 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %344, i64 0, i32 2, i32 1
  %346 = load ptr, ptr %345, align 8
  %347 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %344, i64 0, i32 2, i32 0, i32 1
  %348 = load i32, ptr %347, align 4
  %349 = sext i32 %348 to i64
  %350 = sext i32 %343 to i64
  %351 = getelementptr i32, ptr %346, i64 %350
  %352 = load i32, ptr %351, align 4
  %353 = add nsw i64 %349, %350
  %354 = getelementptr i32, ptr %346, i64 %353
  store i32 %352, ptr %354, align 4
  store i32 0, ptr %351, align 4
  %355 = load ptr, ptr %0, align 8
  %356 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %355, i64 0, i32 3, i32 1
  %357 = load ptr, ptr %356, align 8
  %358 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %355, i64 0, i32 3, i32 0, i32 1
  %359 = getelementptr double, ptr %357, i64 %350
  store double 0.000000e+00, ptr %359, align 8
  %360 = load ptr, ptr %356, align 8
  %361 = load i32, ptr %358, align 4
  %362 = sext i32 %361 to i64
  %363 = add nsw i64 %362, %350
  %364 = getelementptr double, ptr %360, i64 %363
  store double 0.000000e+00, ptr %364, align 8
  %365 = load ptr, ptr %356, align 8
  %366 = load i32, ptr %358, align 4
  %367 = sext i32 %366 to i64
  %368 = shl nsw i64 %367, 1
  %369 = add nsw i64 %368, %350
  %370 = getelementptr double, ptr %365, i64 %369
  store double 0.000000e+00, ptr %370, align 8
  %.pre.7 = load ptr, ptr %2, align 8
  br label %loop_body_tail.7

loop_body_tail.7:                                 ; preds = %struct_for_body_body.7, %loop_body_tail.6
  %371 = phi ptr [ %.pre.7, %struct_for_body_body.7 ], [ %331, %loop_body_tail.6 ]
  %lsr.iv.next = add i32 %lsr.iv, 8
  %372 = add i32 %333, 1
  %exitcond.not.7 = icmp eq i32 %372, %4
  br i1 %exitcond.not.7, label %func_exit.loopexit, label %loop_body

func_exit.loopexit:                               ; preds = %loop_body_tail.7
  br label %func_exit

func_exit:                                        ; preds = %func_exit.loopexit, %loop_body.prol.loopexit, %allocs
  ret void

struct_for_body_body:                             ; preds = %loop_body
  %373 = load i32, ptr %5, align 4
  %374 = shl i32 %373, 5
  %375 = and i32 %77, 31
  %376 = or i32 %374, %375
  %377 = load ptr, ptr %0, align 8
  %378 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %377, i64 0, i32 2, i32 1
  %379 = load ptr, ptr %378, align 8
  %380 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %377, i64 0, i32 2, i32 0, i32 1
  %381 = load i32, ptr %380, align 4
  %382 = sext i32 %381 to i64
  %383 = sext i32 %376 to i64
  %384 = getelementptr i32, ptr %379, i64 %383
  %385 = load i32, ptr %384, align 4
  %386 = add nsw i64 %382, %383
  %387 = getelementptr i32, ptr %379, i64 %386
  store i32 %385, ptr %387, align 4
  store i32 0, ptr %384, align 4
  %388 = load ptr, ptr %0, align 8
  %389 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %388, i64 0, i32 3, i32 1
  %390 = load ptr, ptr %389, align 8
  %391 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32, i32, i32, i32, i32 }, ptr %388, i64 0, i32 3, i32 0, i32 1
  %392 = getelementptr double, ptr %390, i64 %383
  store double 0.000000e+00, ptr %392, align 8
  %393 = load ptr, ptr %389, align 8
  %394 = load i32, ptr %391, align 4
  %395 = sext i32 %394 to i64
  %396 = add nsw i64 %395, %383
  %397 = getelementptr double, ptr %393, i64 %396
  store double 0.000000e+00, ptr %397, align 8
  %398 = load ptr, ptr %389, align 8
  %399 = load i32, ptr %391, align 4
  %400 = sext i32 %399 to i64
  %401 = shl nsw i64 %400, 1
  %402 = add nsw i64 %401, %383
  %403 = getelementptr double, ptr %398, i64 %402
  store double 0.000000e+00, ptr %403, align 8
  %.pre = load ptr, ptr %2, align 8
  br label %loop_body_tail
}

; Function Attrs: argmemonly mustprogress nofree norecurse nosync nounwind willreturn
define internal fastcc void @S54_refine_coordinates(ptr nocapture readonly %0, ptr nocapture writeonly %1, i32 %2) unnamed_addr #5 {
entry:
  %3 = and i32 %2, 3
  %4 = load i32, ptr %0, align 4
  %5 = shl i32 %4, 2
  %6 = or i32 %5, %3
  store i32 %6, ptr %1, align 4
  %7 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 1
  %8 = load i32, ptr %7, align 4
  %9 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 1
  store i32 %8, ptr %9, align 4
  %10 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 2
  %11 = load i32, ptr %10, align 4
  %12 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 2
  store i32 %11, ptr %12, align 4
  %13 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 3
  %14 = load i32, ptr %13, align 4
  %15 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 3
  store i32 %14, ptr %15, align 4
  %16 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 4
  %17 = load i32, ptr %16, align 4
  %18 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 4
  store i32 %17, ptr %18, align 4
  %19 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 5
  %20 = load i32, ptr %19, align 4
  %21 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 5
  store i32 %20, ptr %21, align 4
  %22 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 6
  %23 = load i32, ptr %22, align 4
  %24 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 6
  store i32 %23, ptr %24, align 4
  %25 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 7
  %26 = load i32, ptr %25, align 4
  %27 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 7
  store i32 %26, ptr %27, align 4
  %28 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 8
  %29 = load i32, ptr %28, align 4
  %30 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 8
  store i32 %29, ptr %30, align 4
  %31 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 9
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 9
  store i32 %32, ptr %33, align 4
  %34 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 10
  %35 = load i32, ptr %34, align 4
  %36 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 10
  store i32 %35, ptr %36, align 4
  %37 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 11
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 11
  store i32 %38, ptr %39, align 4
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #6

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn writeonly
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #7

; Function Attrs: noinline nounwind optnone uwtable
define internal fastcc void @taichi_assert_format(ptr noundef %0, i1 noundef zeroext %1, ptr noundef %2) unnamed_addr #8 {
  %4 = alloca ptr, align 8
  %5 = alloca i8, align 1
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca ptr, align 8
  %9 = alloca %class.anon, align 8
  store ptr %0, ptr %4, align 8
  %10 = zext i1 %1 to i8
  store i8 %10, ptr %5, align 1
  store ptr %2, ptr %6, align 8
  store i32 0, ptr %7, align 4
  store ptr null, ptr %8, align 8
  %11 = load i8, ptr %5, align 1
  %12 = trunc i8 %11 to i1
  %13 = zext i1 %12 to i32
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %15, label %16

15:                                               ; preds = %3
  br label %69

16:                                               ; preds = %3
  %17 = load ptr, ptr %4, align 8
  %18 = getelementptr inbounds %struct.LLVMRuntime, ptr %17, i32 0, i32 24
  %19 = load i64, ptr %18, align 8
  %20 = icmp ne i64 %19, 0
  br i1 %20, label %69, label %21

21:                                               ; preds = %16
  %22 = load ptr, ptr %4, align 8
  %23 = getelementptr inbounds %struct.LLVMRuntime, ptr %22, i32 0, i32 23
  %24 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 0
  store ptr %4, ptr %24, align 8
  %25 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 1
  store ptr %6, ptr %25, align 8
  %26 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 2
  store ptr %7, ptr %26, align 8
  %27 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 3
  store ptr %8, ptr %27, align 8
  br label %28

28:                                               ; preds = %28, %21
  %29 = atomicrmw volatile xchg ptr %23, i32 1 seq_cst, align 4
  %30 = icmp eq i32 %29, 1
  br i1 %30, label %28, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !10

mutex_lock_i32.exit.i.i.i:                        ; preds = %28
  %31 = load ptr, ptr %9, align 8
  %32 = load ptr, ptr %31, align 8
  %33 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 24
  %34 = load i64, ptr %33, align 8
  %.not.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i, label %35, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

35:                                               ; preds = %mutex_lock_i32.exit.i.i.i
  store i64 1, ptr %33, align 8
  %36 = load ptr, ptr %9, align 8
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr inbounds %struct.LLVMRuntime, ptr %37, i64 0, i32 21
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %38, i8 0, i64 2048, i1 false)
  %39 = load ptr, ptr %9, align 8
  %40 = load ptr, ptr %39, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 21
  %42 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 1
  %43 = load ptr, ptr %42, align 8
  %44 = load ptr, ptr %43, align 8
  %45 = load i8, ptr %44, align 1
  %.not5.i.i.i.i.i = icmp eq i8 %45, 0
  br i1 %.not5.i.i.i.i.i, label %taichi_strlen.exit.thread.i.i.i.i, label %.lr.ph.i.i.i.i.i.preheader

.lr.ph.i.i.i.i.i.preheader:                       ; preds = %35
  br label %.lr.ph.i.i.i.i.i

.lr.ph.i.i.i.i.i:                                 ; preds = %.lr.ph.i.i.i.i.i, %.lr.ph.i.i.i.i.i.preheader
  %.07.i.i.i.i.i = phi ptr [ %47, %.lr.ph.i.i.i.i.i ], [ %44, %.lr.ph.i.i.i.i.i.preheader ]
  %.046.i.i.i.i.i = phi i64 [ %46, %.lr.ph.i.i.i.i.i ], [ 0, %.lr.ph.i.i.i.i.i.preheader ]
  %46 = add i64 %.046.i.i.i.i.i, 1
  %47 = getelementptr inbounds i8, ptr %.07.i.i.i.i.i, i64 1
  %48 = load i8, ptr %47, align 1
  %.not.i.i.i.i.i = icmp eq i8 %48, 0
  br i1 %.not.i.i.i.i.i, label %taichi_strlen.exit.i.i.i.i, label %.lr.ph.i.i.i.i.i, !llvm.loop !16

taichi_strlen.exit.i.i.i.i:                       ; preds = %.lr.ph.i.i.i.i.i
  %.lcssa = phi i64 [ %46, %.lr.ph.i.i.i.i.i ]
  %49 = call i64 @llvm.umin.i64(i64 %.lcssa, i64 2047)
  br label %taichi_strlen.exit.thread.i.i.i.i

taichi_strlen.exit.thread.i.i.i.i:                ; preds = %taichi_strlen.exit.i.i.i.i, %35
  %50 = phi i64 [ 0, %35 ], [ %49, %taichi_strlen.exit.i.i.i.i ]
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %41, ptr nonnull align 1 %44, i64 %50, i1 false)
  %51 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 2
  %52 = load ptr, ptr %51, align 8
  %53 = load i32, ptr %52, align 4
  %54 = icmp sgt i32 %53, 0
  br i1 %54, label %.lr.ph.i.i.i.i, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

.lr.ph.i.i.i.i:                                   ; preds = %taichi_strlen.exit.thread.i.i.i.i
  %55 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 3
  br label %56

56:                                               ; preds = %56, %.lr.ph.i.i.i.i
  %indvars.iv.i.i.i.i = phi i64 [ 0, %.lr.ph.i.i.i.i ], [ %indvars.iv.next.i.i.i.i, %56 ]
  %57 = load ptr, ptr %55, align 8
  %58 = load ptr, ptr %57, align 8
  %59 = getelementptr inbounds i64, ptr %58, i64 %indvars.iv.i.i.i.i
  %60 = load i64, ptr %59, align 8
  %61 = load ptr, ptr %9, align 8
  %62 = load ptr, ptr %61, align 8
  %63 = getelementptr inbounds %struct.LLVMRuntime, ptr %62, i64 0, i32 22, i64 %indvars.iv.i.i.i.i
  store i64 %60, ptr %63, align 8
  %indvars.iv.next.i.i.i.i = add nuw nsw i64 %indvars.iv.i.i.i.i, 1
  %64 = load ptr, ptr %51, align 8
  %65 = load i32, ptr %64, align 4
  %66 = sext i32 %65 to i64
  %67 = icmp slt i64 %indvars.iv.next.i.i.i.i, %66
  br i1 %67, label %56, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", !llvm.loop !17

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit": ; preds = %56
  br label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit": ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", %taichi_strlen.exit.thread.i.i.i.i, %mutex_lock_i32.exit.i.i.i
  %68 = atomicrmw volatile xchg ptr %23, i32 0 seq_cst, align 4
  br label %69

69:                                               ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit", %16, %15
  ret void
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_struct_for_block_helper(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #9 {
_ZN11ListManager3getI7ElementEERT_i.exit:
  %3 = alloca %struct.RuntimeContext.2042, align 8
  %4 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 4
  %5 = load i32, ptr %4, align 4
  %6 = sdiv i32 %2, %5
  %7 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  %8 = load i32, ptr %7, align 8
  %9 = sdiv i32 %8, %5
  %10 = srem i32 %2, %5
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  %12 = load ptr, ptr %11, align 8
  %13 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %14 = load i32, ptr %13, align 8
  %15 = ashr i32 %6, %14
  %16 = sext i32 %15 to i64
  %17 = lshr i64 %16, 9
  %18 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %17
  %19 = load atomic i64, ptr %18 acquire, align 8
  %.not.i.i.i = icmp ne i64 %19, 0
  tail call void @llvm.assume(i1 %.not.i.i.i)
  %20 = inttoptr i64 %19 to ptr
  %21 = and i64 %16, 511
  %22 = getelementptr inbounds ptr, ptr %20, i64 %21
  %23 = load atomic i64, ptr %22 acquire, align 8
  %24 = inttoptr i64 %23 to ptr
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %26 = load i64, ptr %25, align 8
  %27 = load i32, ptr %13, align 8
  %notmask.i.i = shl nsw i32 -1, %27
  %28 = xor i32 %notmask.i.i, -1
  %29 = and i32 %6, %28
  %30 = sext i32 %29 to i64
  %31 = mul i64 %26, %30
  %32 = getelementptr inbounds i8, ptr %24, i64 %31
  %33 = getelementptr inbounds %2, ptr %32, i64 0, i32 1
  %34 = load i32, ptr %33, align 8
  %35 = mul nsw i32 %10, %9
  %36 = add nsw i32 %34, %35
  %37 = add nsw i32 %10, 1
  %38 = mul nsw i32 %37, %9
  %39 = add nsw i32 %34, %38
  %40 = getelementptr inbounds %2, ptr %32, i64 0, i32 1, i64 1
  %41 = load i32, ptr %40, align 4
  %42 = tail call i32 @llvm.smin.i32(i32 %41, i32 %39)
  %43 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  %44 = load i64, ptr %43, align 8
  %45 = alloca i8, i64 %44, align 8
  %46 = load ptr, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %3, ptr noundef nonnull align 8 dereferenceable(32) %46, i64 32, i1 false)
  %47 = getelementptr inbounds %struct.RuntimeContext.2042, ptr %3, i64 0, i32 2
  store i32 %1, ptr %47, align 8
  %48 = icmp slt i32 %36, %42
  br i1 %48, label %49, label %75

49:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit
  %50 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = load ptr, ptr %11, align 8
  %53 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 3
  %54 = load i32, ptr %53, align 8
  %55 = ashr i32 %6, %54
  %56 = sext i32 %55 to i64
  %57 = lshr i64 %56, 9
  %58 = getelementptr inbounds [256 x ptr], ptr %52, i64 0, i64 %57
  %59 = load atomic i64, ptr %58 acquire, align 8
  %.not.i.i.i24 = icmp eq i64 %59, 0
  br i1 %.not.i.i.i24, label %_ZN11ListManager3getI7ElementEERT_i.exit26, label %60

60:                                               ; preds = %49
  %61 = inttoptr i64 %59 to ptr
  %62 = and i64 %56, 511
  %63 = getelementptr inbounds ptr, ptr %61, i64 %62
  %64 = load atomic i64, ptr %63 acquire, align 8
  %65 = inttoptr i64 %64 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit26

_ZN11ListManager3getI7ElementEERT_i.exit26:       ; preds = %60, %49
  %66 = phi ptr [ %65, %60 ], [ null, %49 ]
  %67 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 1
  %68 = load i64, ptr %67, align 8
  %69 = load i32, ptr %53, align 8
  %notmask.i.i25 = shl nsw i32 -1, %69
  %70 = xor i32 %notmask.i.i25, -1
  %71 = and i32 %6, %70
  %72 = sext i32 %71 to i64
  %73 = mul i64 %68, %72
  %74 = getelementptr inbounds i8, ptr %66, i64 %73
  call void %51(ptr noundef nonnull %3, ptr noundef nonnull %45, ptr noundef nonnull %74, i32 noundef %36, i32 noundef %42) #1
  br label %75

75:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit26, %_ZN11ListManager3getI7ElementEERT_i.exit
  ret void
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_parallel_range_for_task(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #9 {
  %4 = alloca %struct.RuntimeContext.2042, align 8
  %.sroa.0.0.copyload = load ptr, ptr %0, align 8
  %.sroa.4.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 8
  %.sroa.4.0.copyload = load ptr, ptr %.sroa.4.0..sroa_idx, align 8
  %.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 16
  %.sroa.5.0.copyload = load ptr, ptr %.sroa.5.0..sroa_idx, align 8
  %.sroa.7.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 24
  %.sroa.7.0.copyload = load ptr, ptr %.sroa.7.0..sroa_idx, align 8
  %.sroa.8.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 32
  %.sroa.8.0.copyload = load i64, ptr %.sroa.8.0..sroa_idx, align 8
  %.sroa.9.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 40
  %.sroa.9.0.copyload = load i32, ptr %.sroa.9.0..sroa_idx, align 8
  %.sroa.12.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 44
  %.sroa.12.0.copyload = load i32, ptr %.sroa.12.0..sroa_idx, align 4
  %.sroa.15.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 48
  %.sroa.15.0.copyload = load i32, ptr %.sroa.15.0..sroa_idx, align 8
  %.sroa.17.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 52
  %.sroa.17.0.copyload = load i32, ptr %.sroa.17.0..sroa_idx, align 4
  %5 = alloca i8, i64 %.sroa.8.0.copyload, align 8
  %.not = icmp eq ptr %.sroa.4.0.copyload, null
  br i1 %.not, label %7, label %6

6:                                                ; preds = %3
  call void %.sroa.4.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %7

7:                                                ; preds = %6, %3
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %4, ptr noundef nonnull align 8 dereferenceable(32) %.sroa.0.0.copyload, i64 32, i1 false)
  %8 = getelementptr inbounds %struct.RuntimeContext.2042, ptr %4, i64 0, i32 2
  store i32 %1, ptr %8, align 8
  switch i32 %.sroa.17.0.copyload, label %.loopexit [
    i32 1, label %9
    i32 -1, label %17
  ]

9:                                                ; preds = %7
  %10 = mul nsw i32 %.sroa.15.0.copyload, %2
  %11 = add nsw i32 %10, %.sroa.9.0.copyload
  %12 = add nsw i32 %11, %.sroa.15.0.copyload
  %13 = call i32 @llvm.smin.i32(i32 %.sroa.12.0.copyload, i32 %12)
  %14 = icmp slt i32 %11, %13
  br i1 %14, label %.lr.ph.preheader, label %.loopexit

.lr.ph.preheader:                                 ; preds = %9
  br label %.lr.ph

.lr.ph:                                           ; preds = %.lr.ph, %.lr.ph.preheader
  %.02039 = phi i32 [ %15, %.lr.ph ], [ %11, %.lr.ph.preheader ]
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.02039) #1
  %15 = add nsw i32 %.02039, 1
  %16 = icmp slt i32 %15, %13
  br i1 %16, label %.lr.ph, label %.loopexit.loopexit, !llvm.loop !18

17:                                               ; preds = %7
  %18 = mul nsw i32 %.sroa.15.0.copyload, %2
  %19 = sub nsw i32 %.sroa.12.0.copyload, %18
  %20 = mul nsw i32 %19, %.sroa.15.0.copyload
  %21 = call i32 @llvm.smax.i32(i32 %.sroa.9.0.copyload, i32 %20)
  %.not25.not40 = icmp sgt i32 %19, %21
  br i1 %.not25.not40, label %.lr.ph42.preheader, label %.loopexit

.lr.ph42.preheader:                               ; preds = %17
  br label %.lr.ph42

.lr.ph42:                                         ; preds = %.lr.ph42, %.lr.ph42.preheader
  %.0.in41 = phi i32 [ %.0, %.lr.ph42 ], [ %19, %.lr.ph42.preheader ]
  %.0 = add nsw i32 %.0.in41, -1
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.0) #1
  %.not25.not = icmp sgt i32 %.0, %21
  br i1 %.not25.not, label %.lr.ph42, label %.loopexit.loopexit47, !llvm.loop !19

.loopexit.loopexit:                               ; preds = %.lr.ph
  br label %.loopexit

.loopexit.loopexit47:                             ; preds = %.lr.ph42
  br label %.loopexit

.loopexit:                                        ; preds = %.loopexit.loopexit47, %.loopexit.loopexit, %17, %9, %7
  %.not24 = icmp eq ptr %.sroa.7.0.copyload, null
  br i1 %.not24, label %23, label %22

22:                                               ; preds = %.loopexit
  call void %.sroa.7.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %23

23:                                               ; preds = %22, %.loopexit
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #10

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smax.i32(i32, i32) #10

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #11

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #11

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i64 @llvm.umin.i64(i64, i64) #12

; Function Attrs: inaccessiblememonly nocallback nofree nosync nounwind willreturn
declare void @llvm.assume(i1 noundef) #13

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { nofree nosync nounwind }
attributes #3 = { nofree norecurse nosync nounwind }
attributes #4 = { nofree nounwind }
attributes #5 = { argmemonly mustprogress nofree norecurse nosync nounwind willreturn }
attributes #6 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #7 = { argmemonly mustprogress nocallback nofree nounwind willreturn writeonly }
attributes #8 = { noinline nounwind optnone uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #11 = { argmemonly nocallback nofree nosync nounwind willreturn }
attributes #12 = { nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #13 = { inaccessiblememonly nocallback nofree nosync nounwind willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.unroll.disable"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !11}
!11 = !{!"llvm.loop.mustprogress"}
!12 = distinct !{!12, !11}
!13 = distinct !{!13, !11}
!14 = distinct !{!14, !11}
!15 = distinct !{!15, !7}
!16 = distinct !{!16, !11}
!17 = distinct !{!17, !11}
!18 = distinct !{!18, !11}
!19 = distinct !{!19, !11}
