; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%0 = type { ptr, [2 x i32], %struct.PhysicalCoordinates.1955 }
%struct.RuntimeContext.1942 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }
%struct.ListManager = type { [256 x ptr], i64, i64, i32, i32, i32, ptr }
%struct.PhysicalCoordinates.1955 = type { [12 x i32] }
%struct.cpu_block_task_helper_context = type { ptr, ptr, ptr, i32, i32, i64 }
%class.anon = type { ptr, ptr, ptr, ptr }

@.str = private unnamed_addr constant [28 x i8] c"Out of pre-allocated memory\00", align 1
@.str.2 = private unnamed_addr constant [28 x i8] c"List manager out of chunks.\00", align 1

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @field_force_55_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %0, i64 0, i32 7
  %2 = load double, ptr %1, align 8
  %3 = getelementptr inbounds %struct.RuntimeContext.1942, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  store double %2, ptr %6, align 8
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @field_force_55_kernel_1_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.1942, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 54
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @field_force_55_kernel_2_listgen_S54pointer(ptr %context) local_unnamed_addr #1 {
.lr.ph.i:
  %.sroa.2.i = alloca { [2 x i32], %struct.PhysicalCoordinates.1955 }, align 8
  %0 = alloca %0, align 8
  %1 = getelementptr inbounds %struct.RuntimeContext.1942, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 53
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %4, i64 54
  %8 = load ptr, ptr %7, align 8
  %9 = load atomic i64, ptr %6 acquire, align 8
  %.not.i.i.i.i = icmp ne i64 %9, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i)
  %10 = inttoptr i64 %9 to ptr
  %11 = load atomic i64, ptr %10 acquire, align 8
  %12 = inttoptr i64 %11 to ptr
  %.sroa.0.0.copyload.i = load ptr, ptr %12, align 8
  %.sroa.2.0..sroa_idx.i = getelementptr inbounds i8, ptr %12, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.i, ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.0..sroa_idx.i, i64 56, i1 false)
  %13 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %.sroa.2.16.sroa_idx.i = getelementptr inbounds i8, ptr %.sroa.2.i, i64 8
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %16 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 4
  %17 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 6
  %18 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 2
  %19 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  store ptr %.sroa.0.0.copyload.i, ptr %0, align 8
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %0, i64 8
  store <2 x i32> <i32 0, i32 4>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %13, ptr noundef nonnull align 8 dereferenceable(48) %.sroa.2.16.sroa_idx.i, i64 48, i1 false)
  %20 = atomicrmw volatile add ptr %14, i32 1 seq_cst, align 4
  %21 = load i32, ptr %15, align 8
  %22 = ashr i32 %20, %21
  %23 = icmp ugt i32 %22, 131071
  br i1 %23, label %24, label %26

24:                                               ; preds = %.lr.ph.i
  %25 = load ptr, ptr %17, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %25, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

26:                                               ; preds = %.lr.ph.i
  %27 = zext i32 %22 to i64
  %28 = lshr i64 %27, 9
  %29 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %28
  %30 = load atomic i64, ptr %29 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %30, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %26
  %31 = inttoptr i64 %30 to ptr
  %32 = and i64 %27, 511
  %33 = getelementptr inbounds ptr, ptr %31, i64 %32
  %34 = load atomic i64, ptr %33 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %26
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %35 = atomicrmw volatile xchg ptr %16, i32 1 seq_cst, align 4
  %36 = icmp eq i32 %35, 1
  br i1 %36, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %37 = load atomic i64, ptr %29 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %37, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %39, label %73

39:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %40 = load ptr, ptr %17, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1
  %42 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 28
  %43 = atomicrmw volatile add ptr %42, i64 4096 seq_cst, align 8
  %44 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 2
  %45 = load i64, ptr %44, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %45, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %66, label %46

46:                                               ; preds = %39
  %47 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 26
  br label %48

48:                                               ; preds = %48, %46
  %49 = atomicrmw volatile xchg ptr %47, i32 1 seq_cst, align 4
  %50 = icmp eq i32 %49, 1
  br i1 %50, label %48, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %48
  %51 = load ptr, ptr %41, align 8
  %52 = ptrtoint ptr %51 to i64
  %53 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 1
  %54 = load ptr, ptr %53, align 8
  %55 = ptrtoint ptr %54 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %52
  %56 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %57 = or i64 %56, 4096
  %58 = add i64 %57, %52
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %58, %55
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %59

59:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %60 = add i64 %56, %52
  %61 = inttoptr i64 %60 to ptr
  %62 = getelementptr i8, ptr %51, i64 %56
  %63 = getelementptr inbounds i8, ptr %62, i64 4096
  store ptr %63, ptr %41, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %59, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %61, %59 ]
  %64 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %65 = atomicrmw volatile xchg ptr %47, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %40, i1 noundef zeroext %64, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

66:                                               ; preds = %39
  %67 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 2
  %68 = load ptr, ptr %67, align 8
  %69 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 6
  %70 = load ptr, ptr %69, align 8
  %71 = tail call noundef ptr %68(ptr noundef %70, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %66, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %71, %66 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %72 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %72, ptr %29 release, align 8
  br label %73

73:                                               ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %38, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %74 = and i32 %22, 511
  %75 = zext i32 %74 to i64
  %76 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %75
  %77 = load atomic i64, ptr %76 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %77, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %78, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

78:                                               ; preds = %73
  %79 = load ptr, ptr %17, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1
  %81 = load i64, ptr %18, align 8
  %82 = load i64, ptr %19, align 8
  %83 = mul i64 %82, %81
  %84 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 28
  %85 = atomicrmw volatile add ptr %84, i64 %83 seq_cst, align 8
  %86 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 2
  %87 = load i64, ptr %86, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %87, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %107, label %88

88:                                               ; preds = %78
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 26
  br label %90

90:                                               ; preds = %90, %88
  %91 = atomicrmw volatile xchg ptr %89, i32 1 seq_cst, align 4
  %92 = icmp eq i32 %91, 1
  br i1 %92, label %90, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %90
  %93 = load ptr, ptr %80, align 8
  %94 = ptrtoint ptr %93 to i64
  %95 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 1
  %96 = load ptr, ptr %95, align 8
  %97 = ptrtoint ptr %96 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %94
  %98 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %99 = add i64 %98, %83
  %100 = add i64 %99, %94
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %100, %97
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %101

101:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %102 = add i64 %98, %94
  %103 = inttoptr i64 %102 to ptr
  %104 = getelementptr inbounds i8, ptr %93, i64 %99
  store ptr %104, ptr %80, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %101, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %103, %101 ]
  %105 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %106 = atomicrmw volatile xchg ptr %89, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %79, i1 noundef zeroext %105, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

107:                                              ; preds = %78
  %108 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 2
  %109 = load ptr, ptr %108, align 8
  %110 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 6
  %111 = load ptr, ptr %110, align 8
  %112 = tail call noundef ptr %109(ptr noundef %111, i64 noundef %83, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %107, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %112, %107 ]
  %113 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %113, ptr %76 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %73
  %114 = atomicrmw volatile xchg ptr %16, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %24
  %115 = load i32, ptr %15, align 8
  %116 = ashr i32 %20, %115
  %117 = sext i32 %116 to i64
  %118 = lshr i64 %117, 9
  %119 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %118
  %120 = load atomic i64, ptr %119 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %120, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %121

121:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %122 = inttoptr i64 %120 to ptr
  %123 = and i64 %117, 511
  %124 = getelementptr inbounds ptr, ptr %122, i64 %123
  %125 = load atomic i64, ptr %124 acquire, align 8
  %126 = inttoptr i64 %125 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %121, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %127 = phi ptr [ %126, %121 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %128 = load i64, ptr %19, align 8
  %129 = load i32, ptr %15, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %129
  %130 = xor i32 %notmask.i.i.i.i, -1
  %131 = and i32 %20, %130
  %132 = sext i32 %131 to i64
  %133 = mul i64 %128, %132
  %134 = getelementptr inbounds i8, ptr %127, i64 %133
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %134, ptr nonnull align 8 %0, i64 %128, i1 false)
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @field_force_55_kernel_3_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.1942, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 55
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @field_force_55_kernel_4_listgen_S55bitmasked(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %0, align 8
  %1 = alloca %struct.PhysicalCoordinates.1955, align 4
  %2 = alloca %0, align 8
  %3 = getelementptr inbounds %struct.RuntimeContext.1942, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %2)
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 13
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %6, i64 54
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %10 = load i32, ptr %9, align 8
  %11 = getelementptr inbounds ptr, ptr %6, i64 55
  %12 = load ptr, ptr %11, align 8
  %13 = icmp sgt i32 %10, 0
  br i1 %13, label %.lr.ph61.i, label %element_listgen_nonroot.exit

.lr.ph61.i:                                       ; preds = %entry
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  %16 = getelementptr inbounds %0, ptr %0, i64 0, i32 1
  %17 = getelementptr inbounds %0, ptr %0, i64 0, i32 1, i64 1
  %18 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %19 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %20 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 5
  %21 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %22 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 4
  %23 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 6
  %24 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 2
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %2, i64 8
  br label %26

26:                                               ; preds = %._crit_edge.i, %.lr.ph61.i
  %.04359.i = phi i32 [ 0, %.lr.ph61.i ], [ %172, %._crit_edge.i ]
  %27 = load i32, ptr %14, align 8
  %28 = lshr i32 %.04359.i, %27
  %29 = sext i32 %28 to i64
  %30 = lshr i64 %29, 9
  %31 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %30
  %32 = load atomic i64, ptr %31 acquire, align 8
  %.not.i.i.i.i = icmp eq i64 %32, 0
  br i1 %.not.i.i.i.i, label %_ZN11ListManager3getI7ElementEERT_i.exit.i, label %33

33:                                               ; preds = %26
  %34 = inttoptr i64 %32 to ptr
  %35 = and i64 %29, 511
  %36 = getelementptr inbounds ptr, ptr %34, i64 %35
  %37 = load atomic i64, ptr %36 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit.i

_ZN11ListManager3getI7ElementEERT_i.exit.i:       ; preds = %33, %26
  %39 = phi ptr [ %38, %33 ], [ null, %26 ]
  %40 = load i64, ptr %15, align 8
  %41 = load i32, ptr %14, align 8
  %notmask.i.i.i = shl nsw i32 -1, %41
  %42 = xor i32 %notmask.i.i.i, -1
  %43 = and i32 %.04359.i, %42
  %44 = zext i32 %43 to i64
  %45 = mul i64 %40, %44
  %46 = getelementptr inbounds i8, ptr %39, i64 %45
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %0, ptr noundef nonnull align 8 dereferenceable(64) %46, i64 64, i1 false)
  %47 = load i32, ptr %16, align 8
  %48 = load i32, ptr %17, align 4
  %49 = icmp slt i32 %47, %48
  br i1 %49, label %.lr.ph58.i.preheader, label %._crit_edge.i

.lr.ph58.i.preheader:                             ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit.i
  br label %.lr.ph58.i

.lr.ph58.i:                                       ; preds = %.loopexit.i, %.lr.ph58.i.preheader
  %.04457.i = phi i32 [ %171, %.loopexit.i ], [ %47, %.lr.ph58.i.preheader ]
  call fastcc void @S54_refine_coordinates(ptr noundef nonnull %18, ptr noundef nonnull %1, i32 noundef %.04457.i) #1
  %50 = load ptr, ptr %0, align 8
  %51 = shl i32 %.04457.i, 3
  %52 = sext i32 %51 to i64
  %53 = getelementptr i8, ptr %50, i64 %52
  %54 = getelementptr inbounds i8, ptr %53, i64 32
  %55 = load ptr, ptr %54, align 8
  %.not = icmp eq ptr %55, null
  br i1 %.not, label %.loopexit.i, label %.lr.ph.i

.lr.ph.i:                                         ; preds = %.lr.ph58.i
  store ptr %55, ptr %2, align 8
  store <2 x i32> <i32 0, i32 32>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %19, ptr noundef nonnull align 4 dereferenceable(48) %1, i64 48, i1 false)
  %56 = atomicrmw volatile add ptr %20, i32 1 seq_cst, align 4
  %57 = load i32, ptr %21, align 8
  %58 = ashr i32 %56, %57
  %59 = icmp ugt i32 %58, 131071
  br i1 %59, label %60, label %62

60:                                               ; preds = %.lr.ph.i
  %61 = load ptr, ptr %23, align 8
  call fastcc void @taichi_assert_format(ptr noundef %61, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

62:                                               ; preds = %.lr.ph.i
  %63 = zext i32 %58 to i64
  %64 = lshr i64 %63, 9
  %65 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %64
  %66 = load atomic i64, ptr %65 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %66, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %62
  %67 = inttoptr i64 %66 to ptr
  %68 = and i64 %63, 511
  %69 = getelementptr inbounds ptr, ptr %67, i64 %68
  %70 = load atomic i64, ptr %69 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %70, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %62
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %71 = atomicrmw volatile xchg ptr %22, i32 1 seq_cst, align 4
  %72 = icmp eq i32 %71, 1
  br i1 %72, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %73 = load atomic i64, ptr %65 acquire, align 8
  %74 = inttoptr i64 %73 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %73, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %75, label %109

75:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %76 = load ptr, ptr %23, align 8
  %77 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1
  %78 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 28
  %79 = atomicrmw volatile add ptr %78, i64 4096 seq_cst, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 2
  %81 = load i64, ptr %80, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %81, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %102, label %82

82:                                               ; preds = %75
  %83 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 26
  br label %84

84:                                               ; preds = %84, %82
  %85 = atomicrmw volatile xchg ptr %83, i32 1 seq_cst, align 4
  %86 = icmp eq i32 %85, 1
  br i1 %86, label %84, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %84
  %87 = load ptr, ptr %77, align 8
  %88 = ptrtoint ptr %87 to i64
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 1
  %90 = load ptr, ptr %89, align 8
  %91 = ptrtoint ptr %90 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %88
  %92 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %93 = or i64 %92, 4096
  %94 = add i64 %93, %88
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %94, %91
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %95

95:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %96 = add i64 %92, %88
  %97 = inttoptr i64 %96 to ptr
  %98 = getelementptr i8, ptr %87, i64 %92
  %99 = getelementptr inbounds i8, ptr %98, i64 4096
  store ptr %99, ptr %77, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %95, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %97, %95 ]
  %100 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %101 = atomicrmw volatile xchg ptr %83, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %76, i1 noundef zeroext %100, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

102:                                              ; preds = %75
  %103 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 2
  %104 = load ptr, ptr %103, align 8
  %105 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 6
  %106 = load ptr, ptr %105, align 8
  %107 = call noundef ptr %104(ptr noundef %106, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %102, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %107, %102 ]
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %108 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %108, ptr %65 release, align 8
  br label %109

109:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %74, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %110 = and i32 %58, 511
  %111 = zext i32 %110 to i64
  %112 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %111
  %113 = load atomic i64, ptr %112 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %113, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %114, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

114:                                              ; preds = %109
  %115 = load ptr, ptr %23, align 8
  %116 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1
  %117 = load i64, ptr %24, align 8
  %118 = load i64, ptr %25, align 8
  %119 = mul i64 %118, %117
  %120 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 28
  %121 = atomicrmw volatile add ptr %120, i64 %119 seq_cst, align 8
  %122 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 2
  %123 = load i64, ptr %122, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %123, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %143, label %124

124:                                              ; preds = %114
  %125 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 26
  br label %126

126:                                              ; preds = %126, %124
  %127 = atomicrmw volatile xchg ptr %125, i32 1 seq_cst, align 4
  %128 = icmp eq i32 %127, 1
  br i1 %128, label %126, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %126
  %129 = load ptr, ptr %116, align 8
  %130 = ptrtoint ptr %129 to i64
  %131 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 1
  %132 = load ptr, ptr %131, align 8
  %133 = ptrtoint ptr %132 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %130
  %134 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %135 = add i64 %134, %119
  %136 = add i64 %135, %130
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %136, %133
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %137

137:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %138 = add i64 %134, %130
  %139 = inttoptr i64 %138 to ptr
  %140 = getelementptr inbounds i8, ptr %129, i64 %135
  store ptr %140, ptr %116, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %137, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %139, %137 ]
  %141 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %142 = atomicrmw volatile xchg ptr %125, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %115, i1 noundef zeroext %141, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

143:                                              ; preds = %114
  %144 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 2
  %145 = load ptr, ptr %144, align 8
  %146 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 6
  %147 = load ptr, ptr %146, align 8
  %148 = call noundef ptr %145(ptr noundef %147, i64 noundef %119, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %143, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %148, %143 ]
  %149 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %149, ptr %112 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %109
  %150 = atomicrmw volatile xchg ptr %22, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %60
  %151 = load i32, ptr %21, align 8
  %152 = ashr i32 %56, %151
  %153 = sext i32 %152 to i64
  %154 = lshr i64 %153, 9
  %155 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %154
  %156 = load atomic i64, ptr %155 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %156, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %157

157:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %158 = inttoptr i64 %156 to ptr
  %159 = and i64 %153, 511
  %160 = getelementptr inbounds ptr, ptr %158, i64 %159
  %161 = load atomic i64, ptr %160 acquire, align 8
  %162 = inttoptr i64 %161 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %157, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %163 = phi ptr [ %162, %157 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %164 = load i64, ptr %25, align 8
  %165 = load i32, ptr %21, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %165
  %166 = xor i32 %notmask.i.i.i.i, -1
  %167 = and i32 %56, %166
  %168 = sext i32 %167 to i64
  %169 = mul i64 %164, %168
  %170 = getelementptr inbounds i8, ptr %163, i64 %169
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %170, ptr nonnull align 8 %2, i64 %164, i1 false)
  br label %.loopexit.i, !llvm.loop !8

.loopexit.i:                                      ; preds = %_ZN11ListManager6appendEPv.exit.i, %.lr.ph58.i
  %171 = add i32 %.04457.i, 1
  %exitcond.not.i = icmp eq i32 %171, %48
  br i1 %exitcond.not.i, label %._crit_edge.i.loopexit, label %.lr.ph58.i, !llvm.loop !9

._crit_edge.i.loopexit:                           ; preds = %.loopexit.i
  br label %._crit_edge.i

._crit_edge.i:                                    ; preds = %._crit_edge.i.loopexit, %_ZN11ListManager3getI7ElementEERT_i.exit.i
  %172 = add nuw nsw i32 %.04359.i, 1
  %exitcond63.not.i = icmp eq i32 %172, %10
  br i1 %exitcond63.not.i, label %element_listgen_nonroot.exit.loopexit, label %26, !llvm.loop !10

element_listgen_nonroot.exit.loopexit:            ; preds = %._crit_edge.i
  br label %element_listgen_nonroot.exit

element_listgen_nonroot.exit:                     ; preds = %element_listgen_nonroot.exit.loopexit, %entry
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %2)
  ret void
}

; Function Attrs: nounwind
define void @field_force_55_kernel_5_struct_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.cpu_block_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.RuntimeContext.1942, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 55
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds %struct.ListManager, ptr %6, i64 0, i32 5
  %8 = load i32, ptr %7, align 8
  store ptr %context, ptr %0, align 8
  %9 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  store ptr @function_body, ptr %9, align 8
  %10 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  store ptr %6, ptr %10, align 8
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  store <2 x i32> <i32 32, i32 8>, ptr %11, align 8
  %12 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  store i64 1, ptr %12, align 8
  %13 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 12
  %14 = load ptr, ptr %13, align 8
  %15 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 11
  %16 = load ptr, ptr %15, align 8
  %17 = shl nsw i32 %8, 3
  call void %14(ptr noundef %16, i32 noundef %17, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_struct_for_block_helper) #1
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body(ptr %0, ptr nocapture readnone %1, ptr nocapture readonly %2, i32 %3, i32 %4) #2 {
allocs:
  %5 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %6 = icmp slt i32 %3, %4
  br i1 %6, label %loop_body.lr.ph, label %func_exit

loop_body.lr.ph:                                  ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.1942, ptr %0, i64 0, i32 1
  br label %loop_body

loop_body:                                        ; preds = %loop_body_tail, %loop_body.lr.ph
  %.0730 = phi i32 [ %3, %loop_body.lr.ph ], [ %18, %loop_body_tail ]
  %8 = load ptr, ptr %2, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 32
  %10 = sdiv i32 %.0730, 8
  %11 = sext i32 %10 to i64
  %12 = getelementptr inbounds i8, ptr %9, i64 %11
  %13 = load i8, ptr %12, align 1
  %14 = zext i8 %13 to i32
  %15 = and i32 %.0730, 7
  %16 = shl nuw nsw i32 1, %15
  %17 = and i32 %16, %14
  %.not = icmp eq i32 %17, 0
  br i1 %.not, label %loop_body_tail, label %struct_for_body_body

loop_body_tail.loopexit:                          ; preds = %after_if.us.7
  br label %loop_body_tail

loop_body_tail.loopexit48:                        ; preds = %after_if3.1
  br label %loop_body_tail

loop_body_tail:                                   ; preds = %for_loop_body.us.prol.loopexit, %for_loop_body.prol.loopexit, %struct_for_body_body, %loop_body_tail.loopexit48, %loop_body_tail.loopexit, %loop_body
  %18 = add nsw i32 %.0730, 1
  %exitcond40.not = icmp eq i32 %18, %4
  br i1 %exitcond40.not, label %func_exit.loopexit, label %loop_body

func_exit.loopexit:                               ; preds = %loop_body_tail
  br label %func_exit

func_exit:                                        ; preds = %func_exit.loopexit, %allocs
  ret void

struct_for_body_body:                             ; preds = %loop_body
  %19 = load i32, ptr %5, align 4
  %20 = shl i32 %19, 5
  %21 = and i32 %.0730, 31
  %22 = or i32 %20, %21
  %23 = load ptr, ptr %0, align 8
  %24 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %23, i64 0, i32 10, i32 1
  %25 = load ptr, ptr %24, align 8
  %26 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %23, i64 0, i32 10, i32 0, i32 1
  %27 = load i32, ptr %26, align 4
  %28 = sext i32 %27 to i64
  %29 = sext i32 %22 to i64
  %30 = getelementptr i32, ptr %25, i64 %29
  %31 = load i32, ptr %30, align 4
  %32 = add nsw i64 %28, %29
  %33 = getelementptr i32, ptr %25, i64 %32
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %23, i64 0, i32 9, i32 1
  %36 = load ptr, ptr %35, align 8
  %37 = getelementptr i64, ptr %36, i64 1
  %38 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %23, i64 0, i32 2, i32 1
  %39 = load ptr, ptr %38, align 8
  %40 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %23, i64 0, i32 2, i32 0, i32 1
  %41 = load i32, ptr %40, align 4
  %42 = sext i32 %41 to i64
  %43 = mul nsw i64 %42, 6
  %44 = add nsw i64 %43, %29
  %45 = getelementptr double, ptr %39, i64 %44
  %46 = load ptr, ptr %7, align 8
  %47 = getelementptr inbounds %struct.LLVMRuntime, ptr %46, i64 0, i32 16
  %48 = load ptr, ptr %47, align 8
  %49 = load double, ptr %45, align 8
  %50 = icmp slt i32 %31, %34
  br i1 %50, label %for_loop_body.lr.ph, label %loop_body_tail

for_loop_body.lr.ph:                              ; preds = %struct_for_body_body
  %51 = load double, ptr %48, align 8
  %.fr31 = freeze double %51
  %52 = fcmp ueq double %.fr31, 0.000000e+00
  %53 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %23, i64 0, i32 11, i32 1
  %54 = getelementptr { { i32, i32 }, ptr }, ptr %23, i64 0, i32 1
  %55 = getelementptr { { i32, i32 }, ptr }, ptr %23, i64 0, i32 0, i32 1
  %56 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %23, i64 0, i32 12, i32 1
  %57 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %23, i64 0, i32 1, i32 1
  %58 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %23, i64 0, i32 3, i32 1
  %59 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %23, i64 0, i32 3, i32 0, i32 1
  %60 = sext i32 %31 to i64
  %wide.trip.count = sext i32 %34 to i64
  br i1 %52, label %for_loop_body.us.preheader, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.lr.ph
  %61 = sub nsw i64 %wide.trip.count, %60
  %62 = xor i64 %60, -1
  %xtraiter = and i64 %61, 1
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.preheader
  %63 = load ptr, ptr %53, align 8
  %64 = getelementptr i32, ptr %63, i64 %60
  %65 = load i32, ptr %64, align 4
  %66 = load ptr, ptr %54, align 8
  %67 = load i32, ptr %55, align 4
  %68 = sext i32 %67 to i64
  %69 = sext i32 %65 to i64
  %70 = add nsw i64 %68, %69
  %71 = getelementptr i32, ptr %66, i64 %70
  %72 = load i32, ptr %71, align 4
  %73 = load ptr, ptr %56, align 8
  %74 = getelementptr i64, ptr %73, i64 %69
  %75 = load i64, ptr %74, align 8
  %76 = uitofp i64 %75 to double
  %77 = add i32 %65, 512
  %78 = sext i32 %77 to i64
  %79 = getelementptr i64, ptr %73, i64 %78
  %80 = load i64, ptr %79, align 8
  %81 = uitofp i64 %80 to double
  %82 = fdiv double %76, %81
  %83 = atomicrmw add ptr %37, i64 1 seq_cst, align 8
  %84 = fptrunc double %82 to float
  %85 = load ptr, ptr %57, align 8
  %86 = getelementptr float, ptr %85, i64 %69
  %87 = load float, ptr %86, align 4
  %88 = fcmp ueq float %87, %84
  br i1 %88, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %89 = load ptr, ptr %35, align 8
  %90 = getelementptr i64, ptr %89, i64 19
  %91 = atomicrmw add ptr %90, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %92 = load ptr, ptr %58, align 8
  %93 = load i32, ptr %59, align 4
  %94 = sext i32 %93 to i64
  %95 = mul nsw i64 %94, 3
  %96 = sext i32 %72 to i64
  %97 = add nsw i64 %95, %96
  %98 = getelementptr double, ptr %92, i64 %97
  %99 = load double, ptr %98, align 8
  %100 = add i32 %72, 1024
  %101 = load ptr, ptr %56, align 8
  %102 = sext i32 %100 to i64
  %103 = getelementptr i64, ptr %101, i64 %102
  %104 = load i64, ptr %103, align 8
  %.not32.prol = icmp eq i64 %104, 0
  br i1 %.not32.prol, label %after_if3.prol, label %true_block1.prol

true_block1.prol:                                 ; preds = %after_if.prol
  %105 = fmul double %49, %82
  %106 = load ptr, ptr %35, align 8
  %107 = getelementptr i64, ptr %106, i64 2
  %108 = atomicrmw add ptr %107, i64 1 seq_cst, align 8
  %109 = load ptr, ptr %38, align 8
  %110 = load i32, ptr %40, align 4
  %111 = sext i32 %110 to i64
  %112 = getelementptr double, ptr %109, i64 %29
  %113 = load double, ptr %112, align 8
  %114 = add nsw i64 %111, %29
  %115 = getelementptr double, ptr %109, i64 %114
  %116 = load double, ptr %115, align 8
  %117 = shl nsw i64 %111, 1
  %118 = add nsw i64 %117, %29
  %119 = getelementptr double, ptr %109, i64 %118
  %120 = load double, ptr %119, align 8
  %121 = load ptr, ptr %58, align 8
  %122 = load i32, ptr %59, align 4
  %123 = sext i32 %122 to i64
  %124 = getelementptr double, ptr %121, i64 %96
  %125 = load double, ptr %124, align 8
  %126 = add nsw i64 %123, %96
  %127 = getelementptr double, ptr %121, i64 %126
  %128 = load double, ptr %127, align 8
  %129 = shl nsw i64 %123, 1
  %130 = add nsw i64 %129, %96
  %131 = getelementptr double, ptr %121, i64 %130
  %132 = load double, ptr %131, align 8
  %133 = fsub double %125, %113
  %134 = fsub double %128, %116
  %135 = fsub double %132, %120
  %136 = fmul double %133, %133
  %137 = fmul double %134, %134
  %138 = fadd double %136, %137
  %139 = fmul double %135, %135
  %140 = fadd double %138, %139
  %141 = fcmp ogt double %140, 0.000000e+00
  %.0.i8.prol = select i1 %141, double 1.000000e+00, double 0.000000e+00
  %142 = fsub double 1.000000e+00, %.0.i8.prol
  %143 = fadd double %140, %142
  %sqrt.prol = tail call double @llvm.sqrt.f64(double %143)
  %144 = fdiv double 1.000000e+00, %sqrt.prol
  %145 = fmul double %144, %144
  %146 = fmul double %144, %145
  %147 = fsub double %99, %105
  %148 = fcmp one double %147, 0.000000e+00
  %.0.i.prol = select i1 %148, double 1.000000e+00, double 0.000000e+00
  %149 = load double, ptr %48, align 8
  %150 = fmul double %105, %149
  %151 = fmul double %99, %146
  %152 = fmul double %150, %151
  %153 = fmul double %.0.i.prol, %.0.i8.prol
  %154 = fmul double %153, %152
  %155 = fmul double %133, %154
  %156 = fmul double %134, %154
  %157 = fmul double %135, %154
  %158 = bitcast double %105 to i64
  %159 = and i64 %158, 9223372036854775807
  %160 = and i64 %158, 9218868437227405312
  %161 = icmp eq i64 %159, 0
  %162 = icmp ne i64 %160, 0
  %163 = icmp ne i64 %160, 9218868437227405312
  %164 = and i1 %162, %163
  %165 = or i1 %161, %164
  br i1 %165, label %after_if6.prol, label %true_block4.prol

true_block4.prol:                                 ; preds = %true_block1.prol
  %166 = load ptr, ptr %35, align 8
  %167 = getelementptr i64, ptr %166, i64 19
  %168 = atomicrmw add ptr %167, i64 1 seq_cst, align 8
  br label %after_if6.prol

after_if6.prol:                                   ; preds = %true_block4.prol, %true_block1.prol
  %169 = bitcast double %99 to i64
  %170 = and i64 %169, 9223372036854775807
  %171 = and i64 %169, 9218868437227405312
  %172 = icmp eq i64 %170, 0
  %173 = icmp ne i64 %171, 0
  %174 = icmp ne i64 %171, 9218868437227405312
  %175 = and i1 %173, %174
  %176 = or i1 %172, %175
  br i1 %176, label %after_if9.prol, label %true_block7.prol

true_block7.prol:                                 ; preds = %after_if6.prol
  %177 = load ptr, ptr %35, align 8
  %178 = getelementptr i64, ptr %177, i64 19
  %179 = atomicrmw add ptr %178, i64 1 seq_cst, align 8
  br label %after_if9.prol

after_if9.prol:                                   ; preds = %true_block7.prol, %after_if6.prol
  %180 = bitcast double %140 to i64
  %181 = and i64 %180, 9223372036854775807
  %182 = and i64 %180, 9218868437227405312
  %183 = icmp eq i64 %181, 0
  %184 = icmp ne i64 %182, 0
  %185 = icmp ne i64 %182, 9218868437227405312
  %186 = and i1 %184, %185
  %187 = or i1 %183, %186
  br i1 %187, label %after_if12.prol, label %true_block10.prol

true_block10.prol:                                ; preds = %after_if9.prol
  %188 = load ptr, ptr %35, align 8
  %189 = getelementptr i64, ptr %188, i64 19
  %190 = atomicrmw add ptr %189, i64 1 seq_cst, align 8
  br label %after_if12.prol

after_if12.prol:                                  ; preds = %true_block10.prol, %after_if9.prol
  %191 = bitcast double %144 to i64
  %192 = and i64 %191, 9223372036854775807
  %193 = and i64 %191, 9218868437227405312
  %194 = icmp eq i64 %192, 0
  %195 = icmp ne i64 %193, 0
  %196 = icmp ne i64 %193, 9218868437227405312
  %197 = and i1 %195, %196
  %198 = or i1 %194, %197
  br i1 %198, label %after_if15.prol, label %true_block13.prol

true_block13.prol:                                ; preds = %after_if12.prol
  %199 = load ptr, ptr %35, align 8
  %200 = getelementptr i64, ptr %199, i64 19
  %201 = atomicrmw add ptr %200, i64 1 seq_cst, align 8
  br label %after_if15.prol

after_if15.prol:                                  ; preds = %true_block13.prol, %after_if12.prol
  %202 = bitcast double %146 to i64
  %203 = and i64 %202, 9223372036854775807
  %204 = and i64 %202, 9218868437227405312
  %205 = icmp eq i64 %203, 0
  %206 = icmp ne i64 %204, 0
  %207 = icmp ne i64 %204, 9218868437227405312
  %208 = and i1 %206, %207
  %209 = or i1 %205, %208
  br i1 %209, label %after_if18.prol, label %true_block16.prol

true_block16.prol:                                ; preds = %after_if15.prol
  %210 = load ptr, ptr %35, align 8
  %211 = getelementptr i64, ptr %210, i64 19
  %212 = atomicrmw add ptr %211, i64 1 seq_cst, align 8
  br label %after_if18.prol

after_if18.prol:                                  ; preds = %true_block16.prol, %after_if15.prol
  %213 = bitcast double %154 to i64
  %214 = and i64 %213, 9223372036854775807
  %215 = and i64 %213, 9218868437227405312
  %216 = icmp eq i64 %214, 0
  %217 = icmp ne i64 %215, 0
  %218 = icmp ne i64 %215, 9218868437227405312
  %219 = and i1 %217, %218
  %220 = or i1 %216, %219
  br i1 %220, label %after_if21.prol, label %true_block19.prol

true_block19.prol:                                ; preds = %after_if18.prol
  %221 = load ptr, ptr %35, align 8
  %222 = getelementptr i64, ptr %221, i64 19
  %223 = atomicrmw add ptr %222, i64 1 seq_cst, align 8
  br label %after_if21.prol

after_if21.prol:                                  ; preds = %true_block19.prol, %after_if18.prol
  %224 = bitcast double %155 to i64
  %225 = and i64 %224, 9223372036854775807
  %226 = and i64 %224, 9218868437227405312
  %227 = icmp eq i64 %225, 0
  %228 = icmp ne i64 %226, 0
  %229 = icmp ne i64 %226, 9218868437227405312
  %230 = and i1 %228, %229
  %231 = or i1 %227, %230
  br i1 %231, label %after_if24.prol, label %true_block22.prol

true_block22.prol:                                ; preds = %after_if21.prol
  %232 = load ptr, ptr %35, align 8
  %233 = getelementptr i64, ptr %232, i64 19
  %234 = atomicrmw add ptr %233, i64 1 seq_cst, align 8
  br label %after_if24.prol

after_if24.prol:                                  ; preds = %true_block22.prol, %after_if21.prol
  %235 = bitcast double %156 to i64
  %236 = and i64 %235, 9223372036854775807
  %237 = and i64 %235, 9218868437227405312
  %238 = icmp eq i64 %236, 0
  %239 = icmp ne i64 %237, 0
  %240 = icmp ne i64 %237, 9218868437227405312
  %241 = and i1 %239, %240
  %242 = or i1 %238, %241
  br i1 %242, label %after_if27.prol, label %true_block25.prol

true_block25.prol:                                ; preds = %after_if24.prol
  %243 = load ptr, ptr %35, align 8
  %244 = getelementptr i64, ptr %243, i64 19
  %245 = atomicrmw add ptr %244, i64 1 seq_cst, align 8
  br label %after_if27.prol

after_if27.prol:                                  ; preds = %true_block25.prol, %after_if24.prol
  %246 = bitcast double %157 to i64
  %247 = and i64 %246, 9223372036854775807
  %248 = and i64 %246, 9218868437227405312
  %249 = icmp eq i64 %247, 0
  %250 = icmp ne i64 %248, 0
  %251 = icmp ne i64 %248, 9218868437227405312
  %252 = and i1 %250, %251
  %253 = or i1 %249, %252
  br i1 %253, label %after_if30.prol, label %true_block28.prol

true_block28.prol:                                ; preds = %after_if27.prol
  %254 = load ptr, ptr %35, align 8
  %255 = getelementptr i64, ptr %254, i64 19
  %256 = atomicrmw add ptr %255, i64 1 seq_cst, align 8
  br label %after_if30.prol

after_if30.prol:                                  ; preds = %true_block28.prol, %after_if27.prol
  %257 = load ptr, ptr %38, align 8
  %258 = load i32, ptr %40, align 4
  %259 = sext i32 %258 to i64
  %260 = shl nsw i64 %259, 3
  %261 = add nsw i64 %260, %29
  %262 = getelementptr double, ptr %257, i64 %261
  %263 = load double, ptr %262, align 8
  %264 = fadd double %155, %263
  store double %264, ptr %262, align 8
  %265 = load ptr, ptr %38, align 8
  %266 = load i32, ptr %40, align 4
  %267 = sext i32 %266 to i64
  %268 = mul nsw i64 %267, 9
  %269 = add nsw i64 %268, %29
  %270 = getelementptr double, ptr %265, i64 %269
  %271 = load double, ptr %270, align 8
  %272 = fadd double %156, %271
  store double %272, ptr %270, align 8
  %273 = load ptr, ptr %38, align 8
  %274 = load i32, ptr %40, align 4
  %275 = sext i32 %274 to i64
  %276 = mul nsw i64 %275, 10
  %277 = add nsw i64 %276, %29
  %278 = getelementptr double, ptr %273, i64 %277
  %279 = load double, ptr %278, align 8
  %280 = fadd double %157, %279
  store double %280, ptr %278, align 8
  br label %after_if3.prol

after_if3.prol:                                   ; preds = %after_if30.prol, %after_if.prol
  %indvars.iv.next36.prol = add nsw i64 %60, 1
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %after_if3.prol, %for_loop_body.preheader
  %indvars.iv35.unr = phi i64 [ %60, %for_loop_body.preheader ], [ %indvars.iv.next36.prol, %after_if3.prol ]
  %281 = sub nsw i64 0, %wide.trip.count
  %282 = icmp eq i64 %62, %281
  br i1 %282, label %loop_body_tail, label %for_loop_body.preheader47

for_loop_body.preheader47:                        ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body.us.preheader:                       ; preds = %for_loop_body.lr.ph
  %283 = sub nsw i64 %wide.trip.count, %60
  %284 = xor i64 %60, -1
  %285 = add nsw i64 %284, %wide.trip.count
  %xtraiter44 = and i64 %283, 7
  %lcmp.mod45.not = icmp eq i64 %xtraiter44, 0
  br i1 %lcmp.mod45.not, label %for_loop_body.us.prol.loopexit, label %for_loop_body.us.prol.preheader

for_loop_body.us.prol.preheader:                  ; preds = %for_loop_body.us.preheader
  br label %for_loop_body.us.prol

for_loop_body.us.prol:                            ; preds = %after_if.us.prol, %for_loop_body.us.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter44, %for_loop_body.us.prol.preheader ], [ %lsr.iv.next, %after_if.us.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.us.prol ], [ %60, %for_loop_body.us.prol.preheader ]
  %286 = load ptr, ptr %53, align 8
  %287 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep51 = getelementptr i8, ptr %286, i64 %287
  %288 = load i32, ptr %uglygep51, align 4
  %289 = sext i32 %288 to i64
  %290 = load ptr, ptr %56, align 8
  %291 = getelementptr i64, ptr %290, i64 %289
  %292 = load i64, ptr %291, align 8
  %293 = uitofp i64 %292 to double
  %294 = add i32 %288, 512
  %295 = sext i32 %294 to i64
  %296 = getelementptr i64, ptr %290, i64 %295
  %297 = load i64, ptr %296, align 8
  %298 = uitofp i64 %297 to double
  %299 = fdiv double %293, %298
  %300 = atomicrmw add ptr %37, i64 1 seq_cst, align 8
  %301 = fptrunc double %299 to float
  %302 = load ptr, ptr %57, align 8
  %303 = getelementptr float, ptr %302, i64 %289
  %304 = load float, ptr %303, align 4
  %305 = fcmp ueq float %304, %301
  br i1 %305, label %after_if.us.prol, label %true_block.us.prol

true_block.us.prol:                               ; preds = %for_loop_body.us.prol
  %306 = load ptr, ptr %35, align 8
  %307 = getelementptr i64, ptr %306, i64 19
  %308 = atomicrmw add ptr %307, i64 1 seq_cst, align 8
  br label %after_if.us.prol

after_if.us.prol:                                 ; preds = %true_block.us.prol, %for_loop_body.us.prol
  %indvars.iv.next.prol = add nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.us.prol.loopexit.loopexit, label %for_loop_body.us.prol, !llvm.loop !11

for_loop_body.us.prol.loopexit.loopexit:          ; preds = %after_if.us.prol
  %309 = add i64 %60, %xtraiter44
  br label %for_loop_body.us.prol.loopexit

for_loop_body.us.prol.loopexit:                   ; preds = %for_loop_body.us.prol.loopexit.loopexit, %for_loop_body.us.preheader
  %indvars.iv.unr = phi i64 [ %60, %for_loop_body.us.preheader ], [ %309, %for_loop_body.us.prol.loopexit.loopexit ]
  %310 = icmp ult i64 %285, 7
  br i1 %310, label %loop_body_tail, label %for_loop_body.us.preheader46

for_loop_body.us.preheader46:                     ; preds = %for_loop_body.us.prol.loopexit
  br label %for_loop_body.us

for_loop_body.us:                                 ; preds = %after_if.us.7, %for_loop_body.us.preheader46
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.us.7 ], [ %indvars.iv.unr, %for_loop_body.us.preheader46 ]
  %311 = load ptr, ptr %53, align 8
  %312 = shl i64 %indvars.iv, 2
  %uglygep64 = getelementptr i8, ptr %311, i64 %312
  %313 = load i32, ptr %uglygep64, align 4
  %314 = sext i32 %313 to i64
  %315 = load ptr, ptr %56, align 8
  %316 = getelementptr i64, ptr %315, i64 %314
  %317 = load i64, ptr %316, align 8
  %318 = uitofp i64 %317 to double
  %319 = add i32 %313, 512
  %320 = sext i32 %319 to i64
  %321 = getelementptr i64, ptr %315, i64 %320
  %322 = load i64, ptr %321, align 8
  %323 = uitofp i64 %322 to double
  %324 = fdiv double %318, %323
  %325 = atomicrmw add ptr %37, i64 1 seq_cst, align 8
  %326 = fptrunc double %324 to float
  %327 = load ptr, ptr %57, align 8
  %328 = getelementptr float, ptr %327, i64 %314
  %329 = load float, ptr %328, align 4
  %330 = fcmp ueq float %329, %326
  br i1 %330, label %after_if.us, label %true_block.us

true_block.us:                                    ; preds = %for_loop_body.us
  %331 = load ptr, ptr %35, align 8
  %332 = getelementptr i64, ptr %331, i64 19
  %333 = atomicrmw add ptr %332, i64 1 seq_cst, align 8
  br label %after_if.us

after_if.us:                                      ; preds = %true_block.us, %for_loop_body.us
  %334 = load ptr, ptr %53, align 8
  %uglygep65 = getelementptr i8, ptr %334, i64 4
  %uglygep66 = getelementptr i8, ptr %uglygep65, i64 %312
  %335 = load i32, ptr %uglygep66, align 4
  %336 = sext i32 %335 to i64
  %337 = load ptr, ptr %56, align 8
  %338 = getelementptr i64, ptr %337, i64 %336
  %339 = load i64, ptr %338, align 8
  %340 = uitofp i64 %339 to double
  %341 = add i32 %335, 512
  %342 = sext i32 %341 to i64
  %343 = getelementptr i64, ptr %337, i64 %342
  %344 = load i64, ptr %343, align 8
  %345 = uitofp i64 %344 to double
  %346 = fdiv double %340, %345
  %347 = atomicrmw add ptr %37, i64 1 seq_cst, align 8
  %348 = fptrunc double %346 to float
  %349 = load ptr, ptr %57, align 8
  %350 = getelementptr float, ptr %349, i64 %336
  %351 = load float, ptr %350, align 4
  %352 = fcmp ueq float %351, %348
  br i1 %352, label %after_if.us.1, label %true_block.us.1

true_block.us.1:                                  ; preds = %after_if.us
  %353 = load ptr, ptr %35, align 8
  %354 = getelementptr i64, ptr %353, i64 19
  %355 = atomicrmw add ptr %354, i64 1 seq_cst, align 8
  br label %after_if.us.1

after_if.us.1:                                    ; preds = %true_block.us.1, %after_if.us
  %356 = load ptr, ptr %53, align 8
  %uglygep62 = getelementptr i8, ptr %356, i64 8
  %uglygep63 = getelementptr i8, ptr %uglygep62, i64 %312
  %357 = load i32, ptr %uglygep63, align 4
  %358 = sext i32 %357 to i64
  %359 = load ptr, ptr %56, align 8
  %360 = getelementptr i64, ptr %359, i64 %358
  %361 = load i64, ptr %360, align 8
  %362 = uitofp i64 %361 to double
  %363 = add i32 %357, 512
  %364 = sext i32 %363 to i64
  %365 = getelementptr i64, ptr %359, i64 %364
  %366 = load i64, ptr %365, align 8
  %367 = uitofp i64 %366 to double
  %368 = fdiv double %362, %367
  %369 = atomicrmw add ptr %37, i64 1 seq_cst, align 8
  %370 = fptrunc double %368 to float
  %371 = load ptr, ptr %57, align 8
  %372 = getelementptr float, ptr %371, i64 %358
  %373 = load float, ptr %372, align 4
  %374 = fcmp ueq float %373, %370
  br i1 %374, label %after_if.us.2, label %true_block.us.2

true_block.us.2:                                  ; preds = %after_if.us.1
  %375 = load ptr, ptr %35, align 8
  %376 = getelementptr i64, ptr %375, i64 19
  %377 = atomicrmw add ptr %376, i64 1 seq_cst, align 8
  br label %after_if.us.2

after_if.us.2:                                    ; preds = %true_block.us.2, %after_if.us.1
  %378 = load ptr, ptr %53, align 8
  %uglygep60 = getelementptr i8, ptr %378, i64 12
  %uglygep61 = getelementptr i8, ptr %uglygep60, i64 %312
  %379 = load i32, ptr %uglygep61, align 4
  %380 = sext i32 %379 to i64
  %381 = load ptr, ptr %56, align 8
  %382 = getelementptr i64, ptr %381, i64 %380
  %383 = load i64, ptr %382, align 8
  %384 = uitofp i64 %383 to double
  %385 = add i32 %379, 512
  %386 = sext i32 %385 to i64
  %387 = getelementptr i64, ptr %381, i64 %386
  %388 = load i64, ptr %387, align 8
  %389 = uitofp i64 %388 to double
  %390 = fdiv double %384, %389
  %391 = atomicrmw add ptr %37, i64 1 seq_cst, align 8
  %392 = fptrunc double %390 to float
  %393 = load ptr, ptr %57, align 8
  %394 = getelementptr float, ptr %393, i64 %380
  %395 = load float, ptr %394, align 4
  %396 = fcmp ueq float %395, %392
  br i1 %396, label %after_if.us.3, label %true_block.us.3

true_block.us.3:                                  ; preds = %after_if.us.2
  %397 = load ptr, ptr %35, align 8
  %398 = getelementptr i64, ptr %397, i64 19
  %399 = atomicrmw add ptr %398, i64 1 seq_cst, align 8
  br label %after_if.us.3

after_if.us.3:                                    ; preds = %true_block.us.3, %after_if.us.2
  %400 = load ptr, ptr %53, align 8
  %uglygep58 = getelementptr i8, ptr %400, i64 16
  %uglygep59 = getelementptr i8, ptr %uglygep58, i64 %312
  %401 = load i32, ptr %uglygep59, align 4
  %402 = sext i32 %401 to i64
  %403 = load ptr, ptr %56, align 8
  %404 = getelementptr i64, ptr %403, i64 %402
  %405 = load i64, ptr %404, align 8
  %406 = uitofp i64 %405 to double
  %407 = add i32 %401, 512
  %408 = sext i32 %407 to i64
  %409 = getelementptr i64, ptr %403, i64 %408
  %410 = load i64, ptr %409, align 8
  %411 = uitofp i64 %410 to double
  %412 = fdiv double %406, %411
  %413 = atomicrmw add ptr %37, i64 1 seq_cst, align 8
  %414 = fptrunc double %412 to float
  %415 = load ptr, ptr %57, align 8
  %416 = getelementptr float, ptr %415, i64 %402
  %417 = load float, ptr %416, align 4
  %418 = fcmp ueq float %417, %414
  br i1 %418, label %after_if.us.4, label %true_block.us.4

true_block.us.4:                                  ; preds = %after_if.us.3
  %419 = load ptr, ptr %35, align 8
  %420 = getelementptr i64, ptr %419, i64 19
  %421 = atomicrmw add ptr %420, i64 1 seq_cst, align 8
  br label %after_if.us.4

after_if.us.4:                                    ; preds = %true_block.us.4, %after_if.us.3
  %422 = load ptr, ptr %53, align 8
  %uglygep56 = getelementptr i8, ptr %422, i64 20
  %uglygep57 = getelementptr i8, ptr %uglygep56, i64 %312
  %423 = load i32, ptr %uglygep57, align 4
  %424 = sext i32 %423 to i64
  %425 = load ptr, ptr %56, align 8
  %426 = getelementptr i64, ptr %425, i64 %424
  %427 = load i64, ptr %426, align 8
  %428 = uitofp i64 %427 to double
  %429 = add i32 %423, 512
  %430 = sext i32 %429 to i64
  %431 = getelementptr i64, ptr %425, i64 %430
  %432 = load i64, ptr %431, align 8
  %433 = uitofp i64 %432 to double
  %434 = fdiv double %428, %433
  %435 = atomicrmw add ptr %37, i64 1 seq_cst, align 8
  %436 = fptrunc double %434 to float
  %437 = load ptr, ptr %57, align 8
  %438 = getelementptr float, ptr %437, i64 %424
  %439 = load float, ptr %438, align 4
  %440 = fcmp ueq float %439, %436
  br i1 %440, label %after_if.us.5, label %true_block.us.5

true_block.us.5:                                  ; preds = %after_if.us.4
  %441 = load ptr, ptr %35, align 8
  %442 = getelementptr i64, ptr %441, i64 19
  %443 = atomicrmw add ptr %442, i64 1 seq_cst, align 8
  br label %after_if.us.5

after_if.us.5:                                    ; preds = %true_block.us.5, %after_if.us.4
  %444 = load ptr, ptr %53, align 8
  %uglygep54 = getelementptr i8, ptr %444, i64 24
  %uglygep55 = getelementptr i8, ptr %uglygep54, i64 %312
  %445 = load i32, ptr %uglygep55, align 4
  %446 = sext i32 %445 to i64
  %447 = load ptr, ptr %56, align 8
  %448 = getelementptr i64, ptr %447, i64 %446
  %449 = load i64, ptr %448, align 8
  %450 = uitofp i64 %449 to double
  %451 = add i32 %445, 512
  %452 = sext i32 %451 to i64
  %453 = getelementptr i64, ptr %447, i64 %452
  %454 = load i64, ptr %453, align 8
  %455 = uitofp i64 %454 to double
  %456 = fdiv double %450, %455
  %457 = atomicrmw add ptr %37, i64 1 seq_cst, align 8
  %458 = fptrunc double %456 to float
  %459 = load ptr, ptr %57, align 8
  %460 = getelementptr float, ptr %459, i64 %446
  %461 = load float, ptr %460, align 4
  %462 = fcmp ueq float %461, %458
  br i1 %462, label %after_if.us.6, label %true_block.us.6

true_block.us.6:                                  ; preds = %after_if.us.5
  %463 = load ptr, ptr %35, align 8
  %464 = getelementptr i64, ptr %463, i64 19
  %465 = atomicrmw add ptr %464, i64 1 seq_cst, align 8
  br label %after_if.us.6

after_if.us.6:                                    ; preds = %true_block.us.6, %after_if.us.5
  %466 = load ptr, ptr %53, align 8
  %uglygep52 = getelementptr i8, ptr %466, i64 28
  %uglygep53 = getelementptr i8, ptr %uglygep52, i64 %312
  %467 = load i32, ptr %uglygep53, align 4
  %468 = sext i32 %467 to i64
  %469 = load ptr, ptr %56, align 8
  %470 = getelementptr i64, ptr %469, i64 %468
  %471 = load i64, ptr %470, align 8
  %472 = uitofp i64 %471 to double
  %473 = add i32 %467, 512
  %474 = sext i32 %473 to i64
  %475 = getelementptr i64, ptr %469, i64 %474
  %476 = load i64, ptr %475, align 8
  %477 = uitofp i64 %476 to double
  %478 = fdiv double %472, %477
  %479 = atomicrmw add ptr %37, i64 1 seq_cst, align 8
  %480 = fptrunc double %478 to float
  %481 = load ptr, ptr %57, align 8
  %482 = getelementptr float, ptr %481, i64 %468
  %483 = load float, ptr %482, align 4
  %484 = fcmp ueq float %483, %480
  br i1 %484, label %after_if.us.7, label %true_block.us.7

true_block.us.7:                                  ; preds = %after_if.us.6
  %485 = load ptr, ptr %35, align 8
  %486 = getelementptr i64, ptr %485, i64 19
  %487 = atomicrmw add ptr %486, i64 1 seq_cst, align 8
  br label %after_if.us.7

after_if.us.7:                                    ; preds = %true_block.us.7, %after_if.us.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %loop_body_tail.loopexit, label %for_loop_body.us

for_loop_body:                                    ; preds = %after_if3.1, %for_loop_body.preheader47
  %indvars.iv35 = phi i64 [ %indvars.iv.next36.1, %after_if3.1 ], [ %indvars.iv35.unr, %for_loop_body.preheader47 ]
  %488 = load ptr, ptr %53, align 8
  %489 = shl i64 %indvars.iv35, 2
  %uglygep = getelementptr i8, ptr %488, i64 %489
  %490 = load i32, ptr %uglygep, align 4
  %491 = load ptr, ptr %54, align 8
  %492 = load i32, ptr %55, align 4
  %493 = sext i32 %492 to i64
  %494 = sext i32 %490 to i64
  %495 = add nsw i64 %493, %494
  %496 = getelementptr i32, ptr %491, i64 %495
  %497 = load i32, ptr %496, align 4
  %498 = load ptr, ptr %56, align 8
  %499 = getelementptr i64, ptr %498, i64 %494
  %500 = load i64, ptr %499, align 8
  %501 = uitofp i64 %500 to double
  %502 = add i32 %490, 512
  %503 = sext i32 %502 to i64
  %504 = getelementptr i64, ptr %498, i64 %503
  %505 = load i64, ptr %504, align 8
  %506 = uitofp i64 %505 to double
  %507 = fdiv double %501, %506
  %508 = atomicrmw add ptr %37, i64 1 seq_cst, align 8
  %509 = fptrunc double %507 to float
  %510 = load ptr, ptr %57, align 8
  %511 = getelementptr float, ptr %510, i64 %494
  %512 = load float, ptr %511, align 4
  %513 = fcmp ueq float %512, %509
  br i1 %513, label %after_if, label %true_block

true_block:                                       ; preds = %for_loop_body
  %514 = load ptr, ptr %35, align 8
  %515 = getelementptr i64, ptr %514, i64 19
  %516 = atomicrmw add ptr %515, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %517 = load ptr, ptr %58, align 8
  %518 = load i32, ptr %59, align 4
  %519 = sext i32 %518 to i64
  %520 = mul nsw i64 %519, 3
  %521 = sext i32 %497 to i64
  %522 = add nsw i64 %520, %521
  %523 = getelementptr double, ptr %517, i64 %522
  %524 = load double, ptr %523, align 8
  %525 = add i32 %497, 1024
  %526 = load ptr, ptr %56, align 8
  %527 = sext i32 %525 to i64
  %528 = getelementptr i64, ptr %526, i64 %527
  %529 = load i64, ptr %528, align 8
  %.not32 = icmp eq i64 %529, 0
  br i1 %.not32, label %after_if3, label %true_block1

true_block1:                                      ; preds = %after_if
  %530 = fmul double %49, %507
  %531 = load ptr, ptr %35, align 8
  %532 = getelementptr i64, ptr %531, i64 2
  %533 = atomicrmw add ptr %532, i64 1 seq_cst, align 8
  %534 = load ptr, ptr %38, align 8
  %535 = load i32, ptr %40, align 4
  %536 = sext i32 %535 to i64
  %537 = getelementptr double, ptr %534, i64 %29
  %538 = load double, ptr %537, align 8
  %539 = add nsw i64 %536, %29
  %540 = getelementptr double, ptr %534, i64 %539
  %541 = load double, ptr %540, align 8
  %542 = shl nsw i64 %536, 1
  %543 = add nsw i64 %542, %29
  %544 = getelementptr double, ptr %534, i64 %543
  %545 = load double, ptr %544, align 8
  %546 = load ptr, ptr %58, align 8
  %547 = load i32, ptr %59, align 4
  %548 = sext i32 %547 to i64
  %549 = getelementptr double, ptr %546, i64 %521
  %550 = load double, ptr %549, align 8
  %551 = add nsw i64 %548, %521
  %552 = getelementptr double, ptr %546, i64 %551
  %553 = load double, ptr %552, align 8
  %554 = shl nsw i64 %548, 1
  %555 = add nsw i64 %554, %521
  %556 = getelementptr double, ptr %546, i64 %555
  %557 = load double, ptr %556, align 8
  %558 = fsub double %550, %538
  %559 = fsub double %553, %541
  %560 = fsub double %557, %545
  %561 = fmul double %558, %558
  %562 = fmul double %559, %559
  %563 = fadd double %561, %562
  %564 = fmul double %560, %560
  %565 = fadd double %563, %564
  %566 = fcmp ogt double %565, 0.000000e+00
  %.0.i8 = select i1 %566, double 1.000000e+00, double 0.000000e+00
  %567 = fsub double 1.000000e+00, %.0.i8
  %568 = fadd double %565, %567
  %sqrt = tail call double @llvm.sqrt.f64(double %568)
  %569 = fdiv double 1.000000e+00, %sqrt
  %570 = fmul double %569, %569
  %571 = fmul double %569, %570
  %572 = fsub double %524, %530
  %573 = fcmp one double %572, 0.000000e+00
  %.0.i = select i1 %573, double 1.000000e+00, double 0.000000e+00
  %574 = load double, ptr %48, align 8
  %575 = fmul double %530, %574
  %576 = fmul double %524, %571
  %577 = fmul double %575, %576
  %578 = fmul double %.0.i, %.0.i8
  %579 = fmul double %578, %577
  %580 = fmul double %558, %579
  %581 = fmul double %559, %579
  %582 = fmul double %560, %579
  %583 = bitcast double %530 to i64
  %584 = and i64 %583, 9223372036854775807
  %585 = and i64 %583, 9218868437227405312
  %586 = icmp eq i64 %584, 0
  %587 = icmp ne i64 %585, 0
  %588 = icmp ne i64 %585, 9218868437227405312
  %589 = and i1 %587, %588
  %590 = or i1 %586, %589
  br i1 %590, label %after_if6, label %true_block4

after_if3:                                        ; preds = %after_if30, %after_if
  %591 = load ptr, ptr %53, align 8
  %uglygep49 = getelementptr i8, ptr %591, i64 4
  %uglygep50 = getelementptr i8, ptr %uglygep49, i64 %489
  %592 = load i32, ptr %uglygep50, align 4
  %593 = load ptr, ptr %54, align 8
  %594 = load i32, ptr %55, align 4
  %595 = sext i32 %594 to i64
  %596 = sext i32 %592 to i64
  %597 = add nsw i64 %595, %596
  %598 = getelementptr i32, ptr %593, i64 %597
  %599 = load i32, ptr %598, align 4
  %600 = load ptr, ptr %56, align 8
  %601 = getelementptr i64, ptr %600, i64 %596
  %602 = load i64, ptr %601, align 8
  %603 = uitofp i64 %602 to double
  %604 = add i32 %592, 512
  %605 = sext i32 %604 to i64
  %606 = getelementptr i64, ptr %600, i64 %605
  %607 = load i64, ptr %606, align 8
  %608 = uitofp i64 %607 to double
  %609 = fdiv double %603, %608
  %610 = atomicrmw add ptr %37, i64 1 seq_cst, align 8
  %611 = fptrunc double %609 to float
  %612 = load ptr, ptr %57, align 8
  %613 = getelementptr float, ptr %612, i64 %596
  %614 = load float, ptr %613, align 4
  %615 = fcmp ueq float %614, %611
  br i1 %615, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if3
  %616 = load ptr, ptr %35, align 8
  %617 = getelementptr i64, ptr %616, i64 19
  %618 = atomicrmw add ptr %617, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if3
  %619 = load ptr, ptr %58, align 8
  %620 = load i32, ptr %59, align 4
  %621 = sext i32 %620 to i64
  %622 = mul nsw i64 %621, 3
  %623 = sext i32 %599 to i64
  %624 = add nsw i64 %622, %623
  %625 = getelementptr double, ptr %619, i64 %624
  %626 = load double, ptr %625, align 8
  %627 = add i32 %599, 1024
  %628 = load ptr, ptr %56, align 8
  %629 = sext i32 %627 to i64
  %630 = getelementptr i64, ptr %628, i64 %629
  %631 = load i64, ptr %630, align 8
  %.not32.1 = icmp eq i64 %631, 0
  br i1 %.not32.1, label %after_if3.1, label %true_block1.1

true_block1.1:                                    ; preds = %after_if.1
  %632 = fmul double %49, %609
  %633 = load ptr, ptr %35, align 8
  %634 = getelementptr i64, ptr %633, i64 2
  %635 = atomicrmw add ptr %634, i64 1 seq_cst, align 8
  %636 = load ptr, ptr %38, align 8
  %637 = load i32, ptr %40, align 4
  %638 = sext i32 %637 to i64
  %639 = getelementptr double, ptr %636, i64 %29
  %640 = load double, ptr %639, align 8
  %641 = add nsw i64 %638, %29
  %642 = getelementptr double, ptr %636, i64 %641
  %643 = load double, ptr %642, align 8
  %644 = shl nsw i64 %638, 1
  %645 = add nsw i64 %644, %29
  %646 = getelementptr double, ptr %636, i64 %645
  %647 = load double, ptr %646, align 8
  %648 = load ptr, ptr %58, align 8
  %649 = load i32, ptr %59, align 4
  %650 = sext i32 %649 to i64
  %651 = getelementptr double, ptr %648, i64 %623
  %652 = load double, ptr %651, align 8
  %653 = add nsw i64 %650, %623
  %654 = getelementptr double, ptr %648, i64 %653
  %655 = load double, ptr %654, align 8
  %656 = shl nsw i64 %650, 1
  %657 = add nsw i64 %656, %623
  %658 = getelementptr double, ptr %648, i64 %657
  %659 = load double, ptr %658, align 8
  %660 = fsub double %652, %640
  %661 = fsub double %655, %643
  %662 = fsub double %659, %647
  %663 = fmul double %660, %660
  %664 = fmul double %661, %661
  %665 = fadd double %663, %664
  %666 = fmul double %662, %662
  %667 = fadd double %665, %666
  %668 = fcmp ogt double %667, 0.000000e+00
  %.0.i8.1 = select i1 %668, double 1.000000e+00, double 0.000000e+00
  %669 = fsub double 1.000000e+00, %.0.i8.1
  %670 = fadd double %667, %669
  %sqrt.1 = tail call double @llvm.sqrt.f64(double %670)
  %671 = fdiv double 1.000000e+00, %sqrt.1
  %672 = fmul double %671, %671
  %673 = fmul double %671, %672
  %674 = fsub double %626, %632
  %675 = fcmp one double %674, 0.000000e+00
  %.0.i.1 = select i1 %675, double 1.000000e+00, double 0.000000e+00
  %676 = load double, ptr %48, align 8
  %677 = fmul double %632, %676
  %678 = fmul double %626, %673
  %679 = fmul double %677, %678
  %680 = fmul double %.0.i.1, %.0.i8.1
  %681 = fmul double %680, %679
  %682 = fmul double %660, %681
  %683 = fmul double %661, %681
  %684 = fmul double %662, %681
  %685 = bitcast double %632 to i64
  %686 = and i64 %685, 9223372036854775807
  %687 = and i64 %685, 9218868437227405312
  %688 = icmp eq i64 %686, 0
  %689 = icmp ne i64 %687, 0
  %690 = icmp ne i64 %687, 9218868437227405312
  %691 = and i1 %689, %690
  %692 = or i1 %688, %691
  br i1 %692, label %after_if6.1, label %true_block4.1

true_block4.1:                                    ; preds = %true_block1.1
  %693 = load ptr, ptr %35, align 8
  %694 = getelementptr i64, ptr %693, i64 19
  %695 = atomicrmw add ptr %694, i64 1 seq_cst, align 8
  br label %after_if6.1

after_if6.1:                                      ; preds = %true_block4.1, %true_block1.1
  %696 = bitcast double %626 to i64
  %697 = and i64 %696, 9223372036854775807
  %698 = and i64 %696, 9218868437227405312
  %699 = icmp eq i64 %697, 0
  %700 = icmp ne i64 %698, 0
  %701 = icmp ne i64 %698, 9218868437227405312
  %702 = and i1 %700, %701
  %703 = or i1 %699, %702
  br i1 %703, label %after_if9.1, label %true_block7.1

true_block7.1:                                    ; preds = %after_if6.1
  %704 = load ptr, ptr %35, align 8
  %705 = getelementptr i64, ptr %704, i64 19
  %706 = atomicrmw add ptr %705, i64 1 seq_cst, align 8
  br label %after_if9.1

after_if9.1:                                      ; preds = %true_block7.1, %after_if6.1
  %707 = bitcast double %667 to i64
  %708 = and i64 %707, 9223372036854775807
  %709 = and i64 %707, 9218868437227405312
  %710 = icmp eq i64 %708, 0
  %711 = icmp ne i64 %709, 0
  %712 = icmp ne i64 %709, 9218868437227405312
  %713 = and i1 %711, %712
  %714 = or i1 %710, %713
  br i1 %714, label %after_if12.1, label %true_block10.1

true_block10.1:                                   ; preds = %after_if9.1
  %715 = load ptr, ptr %35, align 8
  %716 = getelementptr i64, ptr %715, i64 19
  %717 = atomicrmw add ptr %716, i64 1 seq_cst, align 8
  br label %after_if12.1

after_if12.1:                                     ; preds = %true_block10.1, %after_if9.1
  %718 = bitcast double %671 to i64
  %719 = and i64 %718, 9223372036854775807
  %720 = and i64 %718, 9218868437227405312
  %721 = icmp eq i64 %719, 0
  %722 = icmp ne i64 %720, 0
  %723 = icmp ne i64 %720, 9218868437227405312
  %724 = and i1 %722, %723
  %725 = or i1 %721, %724
  br i1 %725, label %after_if15.1, label %true_block13.1

true_block13.1:                                   ; preds = %after_if12.1
  %726 = load ptr, ptr %35, align 8
  %727 = getelementptr i64, ptr %726, i64 19
  %728 = atomicrmw add ptr %727, i64 1 seq_cst, align 8
  br label %after_if15.1

after_if15.1:                                     ; preds = %true_block13.1, %after_if12.1
  %729 = bitcast double %673 to i64
  %730 = and i64 %729, 9223372036854775807
  %731 = and i64 %729, 9218868437227405312
  %732 = icmp eq i64 %730, 0
  %733 = icmp ne i64 %731, 0
  %734 = icmp ne i64 %731, 9218868437227405312
  %735 = and i1 %733, %734
  %736 = or i1 %732, %735
  br i1 %736, label %after_if18.1, label %true_block16.1

true_block16.1:                                   ; preds = %after_if15.1
  %737 = load ptr, ptr %35, align 8
  %738 = getelementptr i64, ptr %737, i64 19
  %739 = atomicrmw add ptr %738, i64 1 seq_cst, align 8
  br label %after_if18.1

after_if18.1:                                     ; preds = %true_block16.1, %after_if15.1
  %740 = bitcast double %681 to i64
  %741 = and i64 %740, 9223372036854775807
  %742 = and i64 %740, 9218868437227405312
  %743 = icmp eq i64 %741, 0
  %744 = icmp ne i64 %742, 0
  %745 = icmp ne i64 %742, 9218868437227405312
  %746 = and i1 %744, %745
  %747 = or i1 %743, %746
  br i1 %747, label %after_if21.1, label %true_block19.1

true_block19.1:                                   ; preds = %after_if18.1
  %748 = load ptr, ptr %35, align 8
  %749 = getelementptr i64, ptr %748, i64 19
  %750 = atomicrmw add ptr %749, i64 1 seq_cst, align 8
  br label %after_if21.1

after_if21.1:                                     ; preds = %true_block19.1, %after_if18.1
  %751 = bitcast double %682 to i64
  %752 = and i64 %751, 9223372036854775807
  %753 = and i64 %751, 9218868437227405312
  %754 = icmp eq i64 %752, 0
  %755 = icmp ne i64 %753, 0
  %756 = icmp ne i64 %753, 9218868437227405312
  %757 = and i1 %755, %756
  %758 = or i1 %754, %757
  br i1 %758, label %after_if24.1, label %true_block22.1

true_block22.1:                                   ; preds = %after_if21.1
  %759 = load ptr, ptr %35, align 8
  %760 = getelementptr i64, ptr %759, i64 19
  %761 = atomicrmw add ptr %760, i64 1 seq_cst, align 8
  br label %after_if24.1

after_if24.1:                                     ; preds = %true_block22.1, %after_if21.1
  %762 = bitcast double %683 to i64
  %763 = and i64 %762, 9223372036854775807
  %764 = and i64 %762, 9218868437227405312
  %765 = icmp eq i64 %763, 0
  %766 = icmp ne i64 %764, 0
  %767 = icmp ne i64 %764, 9218868437227405312
  %768 = and i1 %766, %767
  %769 = or i1 %765, %768
  br i1 %769, label %after_if27.1, label %true_block25.1

true_block25.1:                                   ; preds = %after_if24.1
  %770 = load ptr, ptr %35, align 8
  %771 = getelementptr i64, ptr %770, i64 19
  %772 = atomicrmw add ptr %771, i64 1 seq_cst, align 8
  br label %after_if27.1

after_if27.1:                                     ; preds = %true_block25.1, %after_if24.1
  %773 = bitcast double %684 to i64
  %774 = and i64 %773, 9223372036854775807
  %775 = and i64 %773, 9218868437227405312
  %776 = icmp eq i64 %774, 0
  %777 = icmp ne i64 %775, 0
  %778 = icmp ne i64 %775, 9218868437227405312
  %779 = and i1 %777, %778
  %780 = or i1 %776, %779
  br i1 %780, label %after_if30.1, label %true_block28.1

true_block28.1:                                   ; preds = %after_if27.1
  %781 = load ptr, ptr %35, align 8
  %782 = getelementptr i64, ptr %781, i64 19
  %783 = atomicrmw add ptr %782, i64 1 seq_cst, align 8
  br label %after_if30.1

after_if30.1:                                     ; preds = %true_block28.1, %after_if27.1
  %784 = load ptr, ptr %38, align 8
  %785 = load i32, ptr %40, align 4
  %786 = sext i32 %785 to i64
  %787 = shl nsw i64 %786, 3
  %788 = add nsw i64 %787, %29
  %789 = getelementptr double, ptr %784, i64 %788
  %790 = load double, ptr %789, align 8
  %791 = fadd double %682, %790
  store double %791, ptr %789, align 8
  %792 = load ptr, ptr %38, align 8
  %793 = load i32, ptr %40, align 4
  %794 = sext i32 %793 to i64
  %795 = mul nsw i64 %794, 9
  %796 = add nsw i64 %795, %29
  %797 = getelementptr double, ptr %792, i64 %796
  %798 = load double, ptr %797, align 8
  %799 = fadd double %683, %798
  store double %799, ptr %797, align 8
  %800 = load ptr, ptr %38, align 8
  %801 = load i32, ptr %40, align 4
  %802 = sext i32 %801 to i64
  %803 = mul nsw i64 %802, 10
  %804 = add nsw i64 %803, %29
  %805 = getelementptr double, ptr %800, i64 %804
  %806 = load double, ptr %805, align 8
  %807 = fadd double %684, %806
  store double %807, ptr %805, align 8
  br label %after_if3.1

after_if3.1:                                      ; preds = %after_if30.1, %after_if.1
  %indvars.iv.next36.1 = add nsw i64 %indvars.iv35, 2
  %exitcond39.not.1 = icmp eq i64 %wide.trip.count, %indvars.iv.next36.1
  br i1 %exitcond39.not.1, label %loop_body_tail.loopexit48, label %for_loop_body

true_block4:                                      ; preds = %true_block1
  %808 = load ptr, ptr %35, align 8
  %809 = getelementptr i64, ptr %808, i64 19
  %810 = atomicrmw add ptr %809, i64 1 seq_cst, align 8
  br label %after_if6

after_if6:                                        ; preds = %true_block4, %true_block1
  %811 = bitcast double %524 to i64
  %812 = and i64 %811, 9223372036854775807
  %813 = and i64 %811, 9218868437227405312
  %814 = icmp eq i64 %812, 0
  %815 = icmp ne i64 %813, 0
  %816 = icmp ne i64 %813, 9218868437227405312
  %817 = and i1 %815, %816
  %818 = or i1 %814, %817
  br i1 %818, label %after_if9, label %true_block7

true_block7:                                      ; preds = %after_if6
  %819 = load ptr, ptr %35, align 8
  %820 = getelementptr i64, ptr %819, i64 19
  %821 = atomicrmw add ptr %820, i64 1 seq_cst, align 8
  br label %after_if9

after_if9:                                        ; preds = %true_block7, %after_if6
  %822 = bitcast double %565 to i64
  %823 = and i64 %822, 9223372036854775807
  %824 = and i64 %822, 9218868437227405312
  %825 = icmp eq i64 %823, 0
  %826 = icmp ne i64 %824, 0
  %827 = icmp ne i64 %824, 9218868437227405312
  %828 = and i1 %826, %827
  %829 = or i1 %825, %828
  br i1 %829, label %after_if12, label %true_block10

true_block10:                                     ; preds = %after_if9
  %830 = load ptr, ptr %35, align 8
  %831 = getelementptr i64, ptr %830, i64 19
  %832 = atomicrmw add ptr %831, i64 1 seq_cst, align 8
  br label %after_if12

after_if12:                                       ; preds = %true_block10, %after_if9
  %833 = bitcast double %569 to i64
  %834 = and i64 %833, 9223372036854775807
  %835 = and i64 %833, 9218868437227405312
  %836 = icmp eq i64 %834, 0
  %837 = icmp ne i64 %835, 0
  %838 = icmp ne i64 %835, 9218868437227405312
  %839 = and i1 %837, %838
  %840 = or i1 %836, %839
  br i1 %840, label %after_if15, label %true_block13

true_block13:                                     ; preds = %after_if12
  %841 = load ptr, ptr %35, align 8
  %842 = getelementptr i64, ptr %841, i64 19
  %843 = atomicrmw add ptr %842, i64 1 seq_cst, align 8
  br label %after_if15

after_if15:                                       ; preds = %true_block13, %after_if12
  %844 = bitcast double %571 to i64
  %845 = and i64 %844, 9223372036854775807
  %846 = and i64 %844, 9218868437227405312
  %847 = icmp eq i64 %845, 0
  %848 = icmp ne i64 %846, 0
  %849 = icmp ne i64 %846, 9218868437227405312
  %850 = and i1 %848, %849
  %851 = or i1 %847, %850
  br i1 %851, label %after_if18, label %true_block16

true_block16:                                     ; preds = %after_if15
  %852 = load ptr, ptr %35, align 8
  %853 = getelementptr i64, ptr %852, i64 19
  %854 = atomicrmw add ptr %853, i64 1 seq_cst, align 8
  br label %after_if18

after_if18:                                       ; preds = %true_block16, %after_if15
  %855 = bitcast double %579 to i64
  %856 = and i64 %855, 9223372036854775807
  %857 = and i64 %855, 9218868437227405312
  %858 = icmp eq i64 %856, 0
  %859 = icmp ne i64 %857, 0
  %860 = icmp ne i64 %857, 9218868437227405312
  %861 = and i1 %859, %860
  %862 = or i1 %858, %861
  br i1 %862, label %after_if21, label %true_block19

true_block19:                                     ; preds = %after_if18
  %863 = load ptr, ptr %35, align 8
  %864 = getelementptr i64, ptr %863, i64 19
  %865 = atomicrmw add ptr %864, i64 1 seq_cst, align 8
  br label %after_if21

after_if21:                                       ; preds = %true_block19, %after_if18
  %866 = bitcast double %580 to i64
  %867 = and i64 %866, 9223372036854775807
  %868 = and i64 %866, 9218868437227405312
  %869 = icmp eq i64 %867, 0
  %870 = icmp ne i64 %868, 0
  %871 = icmp ne i64 %868, 9218868437227405312
  %872 = and i1 %870, %871
  %873 = or i1 %869, %872
  br i1 %873, label %after_if24, label %true_block22

true_block22:                                     ; preds = %after_if21
  %874 = load ptr, ptr %35, align 8
  %875 = getelementptr i64, ptr %874, i64 19
  %876 = atomicrmw add ptr %875, i64 1 seq_cst, align 8
  br label %after_if24

after_if24:                                       ; preds = %true_block22, %after_if21
  %877 = bitcast double %581 to i64
  %878 = and i64 %877, 9223372036854775807
  %879 = and i64 %877, 9218868437227405312
  %880 = icmp eq i64 %878, 0
  %881 = icmp ne i64 %879, 0
  %882 = icmp ne i64 %879, 9218868437227405312
  %883 = and i1 %881, %882
  %884 = or i1 %880, %883
  br i1 %884, label %after_if27, label %true_block25

true_block25:                                     ; preds = %after_if24
  %885 = load ptr, ptr %35, align 8
  %886 = getelementptr i64, ptr %885, i64 19
  %887 = atomicrmw add ptr %886, i64 1 seq_cst, align 8
  br label %after_if27

after_if27:                                       ; preds = %true_block25, %after_if24
  %888 = bitcast double %582 to i64
  %889 = and i64 %888, 9223372036854775807
  %890 = and i64 %888, 9218868437227405312
  %891 = icmp eq i64 %889, 0
  %892 = icmp ne i64 %890, 0
  %893 = icmp ne i64 %890, 9218868437227405312
  %894 = and i1 %892, %893
  %895 = or i1 %891, %894
  br i1 %895, label %after_if30, label %true_block28

true_block28:                                     ; preds = %after_if27
  %896 = load ptr, ptr %35, align 8
  %897 = getelementptr i64, ptr %896, i64 19
  %898 = atomicrmw add ptr %897, i64 1 seq_cst, align 8
  br label %after_if30

after_if30:                                       ; preds = %true_block28, %after_if27
  %899 = load ptr, ptr %38, align 8
  %900 = load i32, ptr %40, align 4
  %901 = sext i32 %900 to i64
  %902 = shl nsw i64 %901, 3
  %903 = add nsw i64 %902, %29
  %904 = getelementptr double, ptr %899, i64 %903
  %905 = load double, ptr %904, align 8
  %906 = fadd double %580, %905
  store double %906, ptr %904, align 8
  %907 = load ptr, ptr %38, align 8
  %908 = load i32, ptr %40, align 4
  %909 = sext i32 %908 to i64
  %910 = mul nsw i64 %909, 9
  %911 = add nsw i64 %910, %29
  %912 = getelementptr double, ptr %907, i64 %911
  %913 = load double, ptr %912, align 8
  %914 = fadd double %581, %913
  store double %914, ptr %912, align 8
  %915 = load ptr, ptr %38, align 8
  %916 = load i32, ptr %40, align 4
  %917 = sext i32 %916 to i64
  %918 = mul nsw i64 %917, 10
  %919 = add nsw i64 %918, %29
  %920 = getelementptr double, ptr %915, i64 %919
  %921 = load double, ptr %920, align 8
  %922 = fadd double %582, %921
  store double %922, ptr %920, align 8
  br label %after_if3
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.sqrt.f64(double) #3

; Function Attrs: argmemonly mustprogress nofree norecurse nosync nounwind willreturn
define internal fastcc void @S54_refine_coordinates(ptr nocapture readonly %0, ptr nocapture writeonly %1, i32 %2) unnamed_addr #4 {
entry:
  %3 = and i32 %2, 3
  %4 = load i32, ptr %0, align 4
  %5 = shl i32 %4, 2
  %6 = or i32 %5, %3
  store i32 %6, ptr %1, align 4
  %7 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 1
  %8 = load i32, ptr %7, align 4
  %9 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 1
  store i32 %8, ptr %9, align 4
  %10 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 2
  %11 = load i32, ptr %10, align 4
  %12 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 2
  store i32 %11, ptr %12, align 4
  %13 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 3
  %14 = load i32, ptr %13, align 4
  %15 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 3
  store i32 %14, ptr %15, align 4
  %16 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 4
  %17 = load i32, ptr %16, align 4
  %18 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 4
  store i32 %17, ptr %18, align 4
  %19 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 5
  %20 = load i32, ptr %19, align 4
  %21 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 5
  store i32 %20, ptr %21, align 4
  %22 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 6
  %23 = load i32, ptr %22, align 4
  %24 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 6
  store i32 %23, ptr %24, align 4
  %25 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 7
  %26 = load i32, ptr %25, align 4
  %27 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 7
  store i32 %26, ptr %27, align 4
  %28 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 8
  %29 = load i32, ptr %28, align 4
  %30 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 8
  store i32 %29, ptr %30, align 4
  %31 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 9
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 9
  store i32 %32, ptr %33, align 4
  %34 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 10
  %35 = load i32, ptr %34, align 4
  %36 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 10
  store i32 %35, ptr %36, align 4
  %37 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 11
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 11
  store i32 %38, ptr %39, align 4
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #5

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn writeonly
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #6

; Function Attrs: noinline nounwind optnone uwtable
define internal fastcc void @taichi_assert_format(ptr noundef %0, i1 noundef zeroext %1, ptr noundef %2) unnamed_addr #7 {
  %4 = alloca ptr, align 8
  %5 = alloca i8, align 1
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca ptr, align 8
  %9 = alloca %class.anon, align 8
  store ptr %0, ptr %4, align 8
  %10 = zext i1 %1 to i8
  store i8 %10, ptr %5, align 1
  store ptr %2, ptr %6, align 8
  store i32 0, ptr %7, align 4
  store ptr null, ptr %8, align 8
  %11 = load i8, ptr %5, align 1
  %12 = trunc i8 %11 to i1
  %13 = zext i1 %12 to i32
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %15, label %16

15:                                               ; preds = %3
  br label %69

16:                                               ; preds = %3
  %17 = load ptr, ptr %4, align 8
  %18 = getelementptr inbounds %struct.LLVMRuntime, ptr %17, i32 0, i32 24
  %19 = load i64, ptr %18, align 8
  %20 = icmp ne i64 %19, 0
  br i1 %20, label %69, label %21

21:                                               ; preds = %16
  %22 = load ptr, ptr %4, align 8
  %23 = getelementptr inbounds %struct.LLVMRuntime, ptr %22, i32 0, i32 23
  %24 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 0
  store ptr %4, ptr %24, align 8
  %25 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 1
  store ptr %6, ptr %25, align 8
  %26 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 2
  store ptr %7, ptr %26, align 8
  %27 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 3
  store ptr %8, ptr %27, align 8
  br label %28

28:                                               ; preds = %28, %21
  %29 = atomicrmw volatile xchg ptr %23, i32 1 seq_cst, align 4
  %30 = icmp eq i32 %29, 1
  br i1 %30, label %28, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i:                        ; preds = %28
  %31 = load ptr, ptr %9, align 8
  %32 = load ptr, ptr %31, align 8
  %33 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 24
  %34 = load i64, ptr %33, align 8
  %.not.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i, label %35, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

35:                                               ; preds = %mutex_lock_i32.exit.i.i.i
  store i64 1, ptr %33, align 8
  %36 = load ptr, ptr %9, align 8
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr inbounds %struct.LLVMRuntime, ptr %37, i64 0, i32 21
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %38, i8 0, i64 2048, i1 false)
  %39 = load ptr, ptr %9, align 8
  %40 = load ptr, ptr %39, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 21
  %42 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 1
  %43 = load ptr, ptr %42, align 8
  %44 = load ptr, ptr %43, align 8
  %45 = load i8, ptr %44, align 1
  %.not5.i.i.i.i.i = icmp eq i8 %45, 0
  br i1 %.not5.i.i.i.i.i, label %taichi_strlen.exit.thread.i.i.i.i, label %.lr.ph.i.i.i.i.i.preheader

.lr.ph.i.i.i.i.i.preheader:                       ; preds = %35
  br label %.lr.ph.i.i.i.i.i

.lr.ph.i.i.i.i.i:                                 ; preds = %.lr.ph.i.i.i.i.i, %.lr.ph.i.i.i.i.i.preheader
  %.07.i.i.i.i.i = phi ptr [ %47, %.lr.ph.i.i.i.i.i ], [ %44, %.lr.ph.i.i.i.i.i.preheader ]
  %.046.i.i.i.i.i = phi i64 [ %46, %.lr.ph.i.i.i.i.i ], [ 0, %.lr.ph.i.i.i.i.i.preheader ]
  %46 = add i64 %.046.i.i.i.i.i, 1
  %47 = getelementptr inbounds i8, ptr %.07.i.i.i.i.i, i64 1
  %48 = load i8, ptr %47, align 1
  %.not.i.i.i.i.i = icmp eq i8 %48, 0
  br i1 %.not.i.i.i.i.i, label %taichi_strlen.exit.i.i.i.i, label %.lr.ph.i.i.i.i.i, !llvm.loop !13

taichi_strlen.exit.i.i.i.i:                       ; preds = %.lr.ph.i.i.i.i.i
  %.lcssa = phi i64 [ %46, %.lr.ph.i.i.i.i.i ]
  %49 = call i64 @llvm.umin.i64(i64 %.lcssa, i64 2047)
  br label %taichi_strlen.exit.thread.i.i.i.i

taichi_strlen.exit.thread.i.i.i.i:                ; preds = %taichi_strlen.exit.i.i.i.i, %35
  %50 = phi i64 [ 0, %35 ], [ %49, %taichi_strlen.exit.i.i.i.i ]
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %41, ptr nonnull align 1 %44, i64 %50, i1 false)
  %51 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 2
  %52 = load ptr, ptr %51, align 8
  %53 = load i32, ptr %52, align 4
  %54 = icmp sgt i32 %53, 0
  br i1 %54, label %.lr.ph.i.i.i.i, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

.lr.ph.i.i.i.i:                                   ; preds = %taichi_strlen.exit.thread.i.i.i.i
  %55 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 3
  br label %56

56:                                               ; preds = %56, %.lr.ph.i.i.i.i
  %indvars.iv.i.i.i.i = phi i64 [ 0, %.lr.ph.i.i.i.i ], [ %indvars.iv.next.i.i.i.i, %56 ]
  %57 = load ptr, ptr %55, align 8
  %58 = load ptr, ptr %57, align 8
  %59 = getelementptr inbounds i64, ptr %58, i64 %indvars.iv.i.i.i.i
  %60 = load i64, ptr %59, align 8
  %61 = load ptr, ptr %9, align 8
  %62 = load ptr, ptr %61, align 8
  %63 = getelementptr inbounds %struct.LLVMRuntime, ptr %62, i64 0, i32 22, i64 %indvars.iv.i.i.i.i
  store i64 %60, ptr %63, align 8
  %indvars.iv.next.i.i.i.i = add nuw nsw i64 %indvars.iv.i.i.i.i, 1
  %64 = load ptr, ptr %51, align 8
  %65 = load i32, ptr %64, align 4
  %66 = sext i32 %65 to i64
  %67 = icmp slt i64 %indvars.iv.next.i.i.i.i, %66
  br i1 %67, label %56, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", !llvm.loop !14

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit": ; preds = %56
  br label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit": ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", %taichi_strlen.exit.thread.i.i.i.i, %mutex_lock_i32.exit.i.i.i
  %68 = atomicrmw volatile xchg ptr %23, i32 0 seq_cst, align 4
  br label %69

69:                                               ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit", %16, %15
  ret void
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_struct_for_block_helper(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #8 {
_ZN11ListManager3getI7ElementEERT_i.exit:
  %3 = alloca %struct.RuntimeContext.1942, align 8
  %4 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 4
  %5 = load i32, ptr %4, align 4
  %6 = sdiv i32 %2, %5
  %7 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  %8 = load i32, ptr %7, align 8
  %9 = sdiv i32 %8, %5
  %10 = srem i32 %2, %5
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  %12 = load ptr, ptr %11, align 8
  %13 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %14 = load i32, ptr %13, align 8
  %15 = ashr i32 %6, %14
  %16 = sext i32 %15 to i64
  %17 = lshr i64 %16, 9
  %18 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %17
  %19 = load atomic i64, ptr %18 acquire, align 8
  %.not.i.i.i = icmp ne i64 %19, 0
  tail call void @llvm.assume(i1 %.not.i.i.i)
  %20 = inttoptr i64 %19 to ptr
  %21 = and i64 %16, 511
  %22 = getelementptr inbounds ptr, ptr %20, i64 %21
  %23 = load atomic i64, ptr %22 acquire, align 8
  %24 = inttoptr i64 %23 to ptr
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %26 = load i64, ptr %25, align 8
  %27 = load i32, ptr %13, align 8
  %notmask.i.i = shl nsw i32 -1, %27
  %28 = xor i32 %notmask.i.i, -1
  %29 = and i32 %6, %28
  %30 = sext i32 %29 to i64
  %31 = mul i64 %26, %30
  %32 = getelementptr inbounds i8, ptr %24, i64 %31
  %33 = getelementptr inbounds %0, ptr %32, i64 0, i32 1
  %34 = load i32, ptr %33, align 8
  %35 = mul nsw i32 %10, %9
  %36 = add nsw i32 %34, %35
  %37 = add nsw i32 %10, 1
  %38 = mul nsw i32 %37, %9
  %39 = add nsw i32 %34, %38
  %40 = getelementptr inbounds %0, ptr %32, i64 0, i32 1, i64 1
  %41 = load i32, ptr %40, align 4
  %42 = tail call i32 @llvm.smin.i32(i32 %41, i32 %39)
  %43 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  %44 = load i64, ptr %43, align 8
  %45 = alloca i8, i64 %44, align 8
  %46 = load ptr, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %3, ptr noundef nonnull align 8 dereferenceable(32) %46, i64 32, i1 false)
  %47 = getelementptr inbounds %struct.RuntimeContext.1942, ptr %3, i64 0, i32 2
  store i32 %1, ptr %47, align 8
  %48 = icmp slt i32 %36, %42
  br i1 %48, label %49, label %75

49:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit
  %50 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = load ptr, ptr %11, align 8
  %53 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 3
  %54 = load i32, ptr %53, align 8
  %55 = ashr i32 %6, %54
  %56 = sext i32 %55 to i64
  %57 = lshr i64 %56, 9
  %58 = getelementptr inbounds [256 x ptr], ptr %52, i64 0, i64 %57
  %59 = load atomic i64, ptr %58 acquire, align 8
  %.not.i.i.i24 = icmp eq i64 %59, 0
  br i1 %.not.i.i.i24, label %_ZN11ListManager3getI7ElementEERT_i.exit26, label %60

60:                                               ; preds = %49
  %61 = inttoptr i64 %59 to ptr
  %62 = and i64 %56, 511
  %63 = getelementptr inbounds ptr, ptr %61, i64 %62
  %64 = load atomic i64, ptr %63 acquire, align 8
  %65 = inttoptr i64 %64 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit26

_ZN11ListManager3getI7ElementEERT_i.exit26:       ; preds = %60, %49
  %66 = phi ptr [ %65, %60 ], [ null, %49 ]
  %67 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 1
  %68 = load i64, ptr %67, align 8
  %69 = load i32, ptr %53, align 8
  %notmask.i.i25 = shl nsw i32 -1, %69
  %70 = xor i32 %notmask.i.i25, -1
  %71 = and i32 %6, %70
  %72 = sext i32 %71 to i64
  %73 = mul i64 %68, %72
  %74 = getelementptr inbounds i8, ptr %66, i64 %73
  call void %51(ptr noundef nonnull %3, ptr noundef nonnull %45, ptr noundef nonnull %74, i32 noundef %36, i32 noundef %42) #1
  br label %75

75:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit26, %_ZN11ListManager3getI7ElementEERT_i.exit
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i64 @llvm.umin.i64(i64, i64) #9

; Function Attrs: inaccessiblememonly nocallback nofree nosync nounwind willreturn
declare void @llvm.assume(i1 noundef) #10

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #9

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #11

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #11

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { nofree nounwind }
attributes #3 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #4 = { argmemonly mustprogress nofree norecurse nosync nounwind willreturn }
attributes #5 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #6 = { argmemonly mustprogress nocallback nofree nounwind willreturn writeonly }
attributes #7 = { noinline nounwind optnone uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #10 = { inaccessiblememonly nocallback nofree nosync nounwind willreturn }
attributes #11 = { argmemonly nocallback nofree nosync nounwind willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !12}
!12 = !{!"llvm.loop.unroll.disable"}
!13 = distinct !{!13, !7}
!14 = distinct !{!14, !7}
