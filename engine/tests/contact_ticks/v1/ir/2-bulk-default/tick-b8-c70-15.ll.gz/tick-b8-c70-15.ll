; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct.RuntimeContext.990 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }
%struct.range_task_helper_context = type { ptr, ptr, ptr, ptr, i64, i32, i32, i32, i32 }

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @geometry_source_order_5_selection_25_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %0, i64 0, i32 3
  %2 = load i32, ptr %1, align 4
  %3 = getelementptr inbounds %struct.RuntimeContext.990, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  store i32 %2, ptr %6, align 4
  ret void
}

; Function Attrs: nounwind
define void @geometry_source_order_5_selection_25_kernel_1_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.990, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = getelementptr inbounds %struct.RuntimeContext.990, ptr %0, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  %7 = load i32, ptr %6, align 4
  %8 = add i32 %7, 1
  %9 = sdiv i32 %8, 2
  %10 = icmp slt i32 %8, 0
  %11 = shl nsw i32 %9, 1
  %12 = icmp ne i32 %11, %8
  %13 = and i1 %10, %12
  %.neg = sext i1 %13 to i32
  %14 = add nsw i32 %9, %.neg
  %15 = tail call i32 @llvm.smax.i32(i32 %14, i32 512)
  %16 = mul i32 %15, %2
  %17 = add i32 %16, %15
  %18 = tail call i32 @llvm.smin.i32(i32 %7, i32 %17)
  %19 = icmp slt i32 %16, %18
  br i1 %19, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %20 = load ptr, ptr %0, align 8
  %21 = getelementptr { { i32, i32 }, ptr }, ptr %20, i64 0, i32 1
  %22 = getelementptr { { i32, i32 }, ptr }, ptr %20, i64 0, i32 0, i32 1
  %23 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %20, i64 0, i32 1, i32 1
  %24 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %20, i64 0, i32 2, i32 1
  %25 = sext i32 %16 to i64
  %wide.trip.count30 = sext i32 %18 to i64
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_for3, %for_loop_body.lr.ph
  %indvars.iv27 = phi i64 [ %25, %for_loop_body.lr.ph ], [ %indvars.iv.next28, %after_for3 ]
  %26 = load ptr, ptr %21, align 8
  %27 = load i32, ptr %22, align 4
  %28 = sext i32 %27 to i64
  %29 = getelementptr i32, ptr %26, i64 %indvars.iv27
  %30 = load i32, ptr %29, align 4
  %31 = add nsw i64 %indvars.iv27, %28
  %32 = getelementptr i32, ptr %26, i64 %31
  %33 = load i32, ptr %32, align 4
  %34 = tail call i32 @llvm.smin.i32(i32 %30, i32 %33)
  %35 = zext i32 %34 to i64
  %36 = shl nuw i64 %35, 32
  %37 = tail call i32 @llvm.smax.i32(i32 %30, i32 %33)
  %38 = sext i32 %37 to i64
  %39 = add i64 %36, %38
  %40 = load i32, ptr %6, align 4
  %41 = icmp sgt i32 %40, 0
  br i1 %41, label %for_loop_body1.preheader, label %after_for3

for_loop_body1.preheader:                         ; preds = %for_loop_body
  %wide.trip.count = zext i32 %40 to i64
  %min.iters.check = icmp ult i32 %40, 8
  br i1 %min.iters.check, label %for_loop_body1.preheader43, label %vector.ph

vector.ph:                                        ; preds = %for_loop_body1.preheader
  %n.vec = and i64 %wide.trip.count, 4294967288
  %broadcast.splatinsert = insertelement <8 x i64> poison, i64 %39, i64 0
  %broadcast.splat = shufflevector <8 x i64> %broadcast.splatinsert, <8 x i64> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert39 = insertelement <8 x i64> poison, i64 %indvars.iv27, i64 0
  %broadcast.splat40 = shufflevector <8 x i64> %broadcast.splatinsert39, <8 x i64> poison, <8 x i32> zeroinitializer
  %42 = add nsw i64 %n.vec, -8
  %43 = lshr exact i64 %42, 3
  %44 = add nuw nsw i64 %43, 1
  %xtraiter = and i64 %44, 7
  %45 = icmp ult i64 %42, 56
  br i1 %45, label %middle.block.unr-lcssa, label %vector.ph.new

vector.ph.new:                                    ; preds = %vector.ph
  %unroll_iter = and i64 %44, 4611686018427387896
  %uglygep = getelementptr i8, ptr %26, i64 224
  %46 = shl nsw i64 %28, 2
  %uglygep76 = getelementptr i8, ptr %uglygep, i64 %46
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph.new
  %lsr.iv = phi i64 [ %lsr.iv.next, %vector.body ], [ %unroll_iter, %vector.ph.new ]
  %index = phi i64 [ 0, %vector.ph.new ], [ %index.next.7, %vector.body ]
  %vec.ind = phi <8 x i64> [ <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, %vector.ph.new ], [ %vec.ind.next.7, %vector.body ]
  %vec.phi = phi <8 x i32> [ zeroinitializer, %vector.ph.new ], [ %183, %vector.body ]
  %vec.phi36 = phi <8 x i32> [ zeroinitializer, %vector.ph.new ], [ %181, %vector.body ]
  %vec.phi37 = phi <8 x i32> [ zeroinitializer, %vector.ph.new ], [ %179, %vector.body ]
  %47 = shl i64 %index, 2
  %uglygep74 = getelementptr i8, ptr %uglygep, i64 %47
  %uglygep75 = getelementptr i8, ptr %uglygep74, i64 -224
  %wide.load = load <8 x i32>, ptr %uglygep75, align 4
  %uglygep90 = getelementptr i8, ptr %uglygep76, i64 %47
  %uglygep91 = getelementptr i8, ptr %uglygep90, i64 -224
  %wide.load38 = load <8 x i32>, ptr %uglygep91, align 4
  %48 = call <8 x i32> @llvm.smin.v8i32(<8 x i32> %wide.load, <8 x i32> %wide.load38)
  %49 = zext <8 x i32> %48 to <8 x i64>
  %50 = shl nuw <8 x i64> %49, <i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32>
  %51 = call <8 x i32> @llvm.smax.v8i32(<8 x i32> %wide.load, <8 x i32> %wide.load38)
  %52 = sext <8 x i32> %51 to <8 x i64>
  %53 = add <8 x i64> %50, %52
  %54 = icmp eq <8 x i64> %53, %broadcast.splat
  %55 = icmp slt <8 x i64> %vec.ind, %broadcast.splat40
  %56 = and <8 x i1> %55, %54
  %57 = icmp slt <8 x i64> %53, %broadcast.splat
  %58 = or <8 x i1> %57, %56
  %59 = zext <8 x i1> %58 to <8 x i32>
  %60 = add <8 x i32> %vec.phi37, %59
  %61 = zext <8 x i1> %54 to <8 x i32>
  %62 = add <8 x i32> %vec.phi36, %61
  %63 = zext <8 x i1> %56 to <8 x i32>
  %64 = add <8 x i32> %vec.phi, %63
  %vec.ind.next = add <8 x i64> %vec.ind, <i64 8, i64 8, i64 8, i64 8, i64 8, i64 8, i64 8, i64 8>
  %uglygep72 = getelementptr i8, ptr %uglygep74, i64 -192
  %wide.load.1 = load <8 x i32>, ptr %uglygep72, align 4
  %uglygep88 = getelementptr i8, ptr %uglygep90, i64 -192
  %wide.load38.1 = load <8 x i32>, ptr %uglygep88, align 4
  %65 = call <8 x i32> @llvm.smin.v8i32(<8 x i32> %wide.load.1, <8 x i32> %wide.load38.1)
  %66 = zext <8 x i32> %65 to <8 x i64>
  %67 = shl nuw <8 x i64> %66, <i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32>
  %68 = call <8 x i32> @llvm.smax.v8i32(<8 x i32> %wide.load.1, <8 x i32> %wide.load38.1)
  %69 = sext <8 x i32> %68 to <8 x i64>
  %70 = add <8 x i64> %67, %69
  %71 = icmp eq <8 x i64> %70, %broadcast.splat
  %72 = icmp slt <8 x i64> %vec.ind.next, %broadcast.splat40
  %73 = and <8 x i1> %72, %71
  %74 = icmp slt <8 x i64> %70, %broadcast.splat
  %75 = or <8 x i1> %74, %73
  %76 = zext <8 x i1> %75 to <8 x i32>
  %77 = add <8 x i32> %60, %76
  %78 = zext <8 x i1> %71 to <8 x i32>
  %79 = add <8 x i32> %62, %78
  %80 = zext <8 x i1> %73 to <8 x i32>
  %81 = add <8 x i32> %64, %80
  %vec.ind.next.1 = add <8 x i64> %vec.ind, <i64 16, i64 16, i64 16, i64 16, i64 16, i64 16, i64 16, i64 16>
  %uglygep70 = getelementptr i8, ptr %uglygep74, i64 -160
  %wide.load.2 = load <8 x i32>, ptr %uglygep70, align 4
  %uglygep86 = getelementptr i8, ptr %uglygep90, i64 -160
  %wide.load38.2 = load <8 x i32>, ptr %uglygep86, align 4
  %82 = call <8 x i32> @llvm.smin.v8i32(<8 x i32> %wide.load.2, <8 x i32> %wide.load38.2)
  %83 = zext <8 x i32> %82 to <8 x i64>
  %84 = shl nuw <8 x i64> %83, <i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32>
  %85 = call <8 x i32> @llvm.smax.v8i32(<8 x i32> %wide.load.2, <8 x i32> %wide.load38.2)
  %86 = sext <8 x i32> %85 to <8 x i64>
  %87 = add <8 x i64> %84, %86
  %88 = icmp eq <8 x i64> %87, %broadcast.splat
  %89 = icmp slt <8 x i64> %vec.ind.next.1, %broadcast.splat40
  %90 = and <8 x i1> %89, %88
  %91 = icmp slt <8 x i64> %87, %broadcast.splat
  %92 = or <8 x i1> %91, %90
  %93 = zext <8 x i1> %92 to <8 x i32>
  %94 = add <8 x i32> %77, %93
  %95 = zext <8 x i1> %88 to <8 x i32>
  %96 = add <8 x i32> %79, %95
  %97 = zext <8 x i1> %90 to <8 x i32>
  %98 = add <8 x i32> %81, %97
  %vec.ind.next.2 = add <8 x i64> %vec.ind, <i64 24, i64 24, i64 24, i64 24, i64 24, i64 24, i64 24, i64 24>
  %uglygep68 = getelementptr i8, ptr %uglygep74, i64 -128
  %wide.load.3 = load <8 x i32>, ptr %uglygep68, align 4
  %uglygep84 = getelementptr i8, ptr %uglygep90, i64 -128
  %wide.load38.3 = load <8 x i32>, ptr %uglygep84, align 4
  %99 = call <8 x i32> @llvm.smin.v8i32(<8 x i32> %wide.load.3, <8 x i32> %wide.load38.3)
  %100 = zext <8 x i32> %99 to <8 x i64>
  %101 = shl nuw <8 x i64> %100, <i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32>
  %102 = call <8 x i32> @llvm.smax.v8i32(<8 x i32> %wide.load.3, <8 x i32> %wide.load38.3)
  %103 = sext <8 x i32> %102 to <8 x i64>
  %104 = add <8 x i64> %101, %103
  %105 = icmp eq <8 x i64> %104, %broadcast.splat
  %106 = icmp slt <8 x i64> %vec.ind.next.2, %broadcast.splat40
  %107 = and <8 x i1> %106, %105
  %108 = icmp slt <8 x i64> %104, %broadcast.splat
  %109 = or <8 x i1> %108, %107
  %110 = zext <8 x i1> %109 to <8 x i32>
  %111 = add <8 x i32> %94, %110
  %112 = zext <8 x i1> %105 to <8 x i32>
  %113 = add <8 x i32> %96, %112
  %114 = zext <8 x i1> %107 to <8 x i32>
  %115 = add <8 x i32> %98, %114
  %vec.ind.next.3 = add <8 x i64> %vec.ind, <i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32>
  %uglygep66 = getelementptr i8, ptr %uglygep74, i64 -96
  %wide.load.4 = load <8 x i32>, ptr %uglygep66, align 4
  %uglygep82 = getelementptr i8, ptr %uglygep90, i64 -96
  %wide.load38.4 = load <8 x i32>, ptr %uglygep82, align 4
  %116 = call <8 x i32> @llvm.smin.v8i32(<8 x i32> %wide.load.4, <8 x i32> %wide.load38.4)
  %117 = zext <8 x i32> %116 to <8 x i64>
  %118 = shl nuw <8 x i64> %117, <i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32>
  %119 = call <8 x i32> @llvm.smax.v8i32(<8 x i32> %wide.load.4, <8 x i32> %wide.load38.4)
  %120 = sext <8 x i32> %119 to <8 x i64>
  %121 = add <8 x i64> %118, %120
  %122 = icmp eq <8 x i64> %121, %broadcast.splat
  %123 = icmp slt <8 x i64> %vec.ind.next.3, %broadcast.splat40
  %124 = and <8 x i1> %123, %122
  %125 = icmp slt <8 x i64> %121, %broadcast.splat
  %126 = or <8 x i1> %125, %124
  %127 = zext <8 x i1> %126 to <8 x i32>
  %128 = add <8 x i32> %111, %127
  %129 = zext <8 x i1> %122 to <8 x i32>
  %130 = add <8 x i32> %113, %129
  %131 = zext <8 x i1> %124 to <8 x i32>
  %132 = add <8 x i32> %115, %131
  %vec.ind.next.4 = add <8 x i64> %vec.ind, <i64 40, i64 40, i64 40, i64 40, i64 40, i64 40, i64 40, i64 40>
  %uglygep64 = getelementptr i8, ptr %uglygep74, i64 -64
  %wide.load.5 = load <8 x i32>, ptr %uglygep64, align 4
  %uglygep80 = getelementptr i8, ptr %uglygep90, i64 -64
  %wide.load38.5 = load <8 x i32>, ptr %uglygep80, align 4
  %133 = call <8 x i32> @llvm.smin.v8i32(<8 x i32> %wide.load.5, <8 x i32> %wide.load38.5)
  %134 = zext <8 x i32> %133 to <8 x i64>
  %135 = shl nuw <8 x i64> %134, <i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32>
  %136 = call <8 x i32> @llvm.smax.v8i32(<8 x i32> %wide.load.5, <8 x i32> %wide.load38.5)
  %137 = sext <8 x i32> %136 to <8 x i64>
  %138 = add <8 x i64> %135, %137
  %139 = icmp eq <8 x i64> %138, %broadcast.splat
  %140 = icmp slt <8 x i64> %vec.ind.next.4, %broadcast.splat40
  %141 = and <8 x i1> %140, %139
  %142 = icmp slt <8 x i64> %138, %broadcast.splat
  %143 = or <8 x i1> %142, %141
  %144 = zext <8 x i1> %143 to <8 x i32>
  %145 = add <8 x i32> %128, %144
  %146 = zext <8 x i1> %139 to <8 x i32>
  %147 = add <8 x i32> %130, %146
  %148 = zext <8 x i1> %141 to <8 x i32>
  %149 = add <8 x i32> %132, %148
  %vec.ind.next.5 = add <8 x i64> %vec.ind, <i64 48, i64 48, i64 48, i64 48, i64 48, i64 48, i64 48, i64 48>
  %uglygep62 = getelementptr i8, ptr %uglygep74, i64 -32
  %wide.load.6 = load <8 x i32>, ptr %uglygep62, align 4
  %uglygep78 = getelementptr i8, ptr %uglygep90, i64 -32
  %wide.load38.6 = load <8 x i32>, ptr %uglygep78, align 4
  %150 = call <8 x i32> @llvm.smin.v8i32(<8 x i32> %wide.load.6, <8 x i32> %wide.load38.6)
  %151 = zext <8 x i32> %150 to <8 x i64>
  %152 = shl nuw <8 x i64> %151, <i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32>
  %153 = call <8 x i32> @llvm.smax.v8i32(<8 x i32> %wide.load.6, <8 x i32> %wide.load38.6)
  %154 = sext <8 x i32> %153 to <8 x i64>
  %155 = add <8 x i64> %152, %154
  %156 = icmp eq <8 x i64> %155, %broadcast.splat
  %157 = icmp slt <8 x i64> %vec.ind.next.5, %broadcast.splat40
  %158 = and <8 x i1> %157, %156
  %159 = icmp slt <8 x i64> %155, %broadcast.splat
  %160 = or <8 x i1> %159, %158
  %161 = zext <8 x i1> %160 to <8 x i32>
  %162 = add <8 x i32> %145, %161
  %163 = zext <8 x i1> %156 to <8 x i32>
  %164 = add <8 x i32> %147, %163
  %165 = zext <8 x i1> %158 to <8 x i32>
  %166 = add <8 x i32> %149, %165
  %vec.ind.next.6 = add <8 x i64> %vec.ind, <i64 56, i64 56, i64 56, i64 56, i64 56, i64 56, i64 56, i64 56>
  %wide.load.7 = load <8 x i32>, ptr %uglygep74, align 4
  %wide.load38.7 = load <8 x i32>, ptr %uglygep90, align 4
  %167 = call <8 x i32> @llvm.smin.v8i32(<8 x i32> %wide.load.7, <8 x i32> %wide.load38.7)
  %168 = zext <8 x i32> %167 to <8 x i64>
  %169 = shl nuw <8 x i64> %168, <i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32>
  %170 = call <8 x i32> @llvm.smax.v8i32(<8 x i32> %wide.load.7, <8 x i32> %wide.load38.7)
  %171 = sext <8 x i32> %170 to <8 x i64>
  %172 = add <8 x i64> %169, %171
  %173 = icmp eq <8 x i64> %172, %broadcast.splat
  %174 = icmp slt <8 x i64> %vec.ind.next.6, %broadcast.splat40
  %175 = and <8 x i1> %174, %173
  %176 = icmp slt <8 x i64> %172, %broadcast.splat
  %177 = or <8 x i1> %176, %175
  %178 = zext <8 x i1> %177 to <8 x i32>
  %179 = add <8 x i32> %162, %178
  %180 = zext <8 x i1> %173 to <8 x i32>
  %181 = add <8 x i32> %164, %180
  %182 = zext <8 x i1> %175 to <8 x i32>
  %183 = add <8 x i32> %166, %182
  %index.next.7 = add i64 %index, 64
  %vec.ind.next.7 = add <8 x i64> %vec.ind, <i64 64, i64 64, i64 64, i64 64, i64 64, i64 64, i64 64, i64 64>
  %lsr.iv.next = add i64 %lsr.iv, -8
  %niter.ncmp.7 = icmp eq i64 %lsr.iv.next, 0
  br i1 %niter.ncmp.7, label %middle.block.unr-lcssa.loopexit, label %vector.body, !llvm.loop !6

middle.block.unr-lcssa.loopexit:                  ; preds = %vector.body
  br label %middle.block.unr-lcssa

middle.block.unr-lcssa:                           ; preds = %middle.block.unr-lcssa.loopexit, %vector.ph
  %.lcssa45.ph = phi <8 x i32> [ undef, %vector.ph ], [ %179, %middle.block.unr-lcssa.loopexit ]
  %.lcssa44.ph = phi <8 x i32> [ undef, %vector.ph ], [ %181, %middle.block.unr-lcssa.loopexit ]
  %.lcssa.ph = phi <8 x i32> [ undef, %vector.ph ], [ %183, %middle.block.unr-lcssa.loopexit ]
  %index.unr = phi i64 [ 0, %vector.ph ], [ %index.next.7, %middle.block.unr-lcssa.loopexit ]
  %vec.ind.unr = phi <8 x i64> [ <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, %vector.ph ], [ %vec.ind.next.7, %middle.block.unr-lcssa.loopexit ]
  %vec.phi.unr = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %183, %middle.block.unr-lcssa.loopexit ]
  %vec.phi36.unr = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %181, %middle.block.unr-lcssa.loopexit ]
  %vec.phi37.unr = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %179, %middle.block.unr-lcssa.loopexit ]
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %middle.block, label %vector.body.epil.preheader

vector.body.epil.preheader:                       ; preds = %middle.block.unr-lcssa
  %184 = add i64 %index.unr, %28
  %185 = shl i64 %184, 2
  %uglygep92 = getelementptr i8, ptr %26, i64 %185
  %186 = shl i64 %index.unr, 2
  %uglygep96 = getelementptr i8, ptr %26, i64 %186
  %187 = shl nuw nsw i64 %xtraiter, 5
  br label %vector.body.epil

vector.body.epil:                                 ; preds = %vector.body.epil, %vector.body.epil.preheader
  %lsr.iv93 = phi i64 [ 0, %vector.body.epil.preheader ], [ %lsr.iv.next94, %vector.body.epil ]
  %vec.ind.epil = phi <8 x i64> [ %vec.ind.next.epil, %vector.body.epil ], [ %vec.ind.unr, %vector.body.epil.preheader ]
  %vec.phi.epil = phi <8 x i32> [ %204, %vector.body.epil ], [ %vec.phi.unr, %vector.body.epil.preheader ]
  %vec.phi36.epil = phi <8 x i32> [ %202, %vector.body.epil ], [ %vec.phi36.unr, %vector.body.epil.preheader ]
  %vec.phi37.epil = phi <8 x i32> [ %200, %vector.body.epil ], [ %vec.phi37.unr, %vector.body.epil.preheader ]
  %uglygep97 = getelementptr i8, ptr %uglygep96, i64 %lsr.iv93
  %wide.load.epil = load <8 x i32>, ptr %uglygep97, align 4
  %uglygep95 = getelementptr i8, ptr %uglygep92, i64 %lsr.iv93
  %wide.load38.epil = load <8 x i32>, ptr %uglygep95, align 4
  %188 = call <8 x i32> @llvm.smin.v8i32(<8 x i32> %wide.load.epil, <8 x i32> %wide.load38.epil)
  %189 = zext <8 x i32> %188 to <8 x i64>
  %190 = shl nuw <8 x i64> %189, <i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32>
  %191 = call <8 x i32> @llvm.smax.v8i32(<8 x i32> %wide.load.epil, <8 x i32> %wide.load38.epil)
  %192 = sext <8 x i32> %191 to <8 x i64>
  %193 = add <8 x i64> %190, %192
  %194 = icmp eq <8 x i64> %193, %broadcast.splat
  %195 = icmp slt <8 x i64> %vec.ind.epil, %broadcast.splat40
  %196 = and <8 x i1> %195, %194
  %197 = icmp slt <8 x i64> %193, %broadcast.splat
  %198 = or <8 x i1> %197, %196
  %199 = zext <8 x i1> %198 to <8 x i32>
  %200 = add <8 x i32> %vec.phi37.epil, %199
  %201 = zext <8 x i1> %194 to <8 x i32>
  %202 = add <8 x i32> %vec.phi36.epil, %201
  %203 = zext <8 x i1> %196 to <8 x i32>
  %204 = add <8 x i32> %vec.phi.epil, %203
  %vec.ind.next.epil = add <8 x i64> %vec.ind.epil, <i64 8, i64 8, i64 8, i64 8, i64 8, i64 8, i64 8, i64 8>
  %lsr.iv.next94 = add nuw nsw i64 %lsr.iv93, 32
  %epil.iter.cmp.not = icmp eq i64 %187, %lsr.iv.next94
  br i1 %epil.iter.cmp.not, label %middle.block.loopexit, label %vector.body.epil, !llvm.loop !8

middle.block.loopexit:                            ; preds = %vector.body.epil
  br label %middle.block

middle.block:                                     ; preds = %middle.block.loopexit, %middle.block.unr-lcssa
  %.lcssa45 = phi <8 x i32> [ %.lcssa45.ph, %middle.block.unr-lcssa ], [ %200, %middle.block.loopexit ]
  %.lcssa44 = phi <8 x i32> [ %.lcssa44.ph, %middle.block.unr-lcssa ], [ %202, %middle.block.loopexit ]
  %.lcssa = phi <8 x i32> [ %.lcssa.ph, %middle.block.unr-lcssa ], [ %204, %middle.block.loopexit ]
  %205 = call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %.lcssa45)
  %206 = call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %.lcssa44)
  %207 = call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %.lcssa)
  %cmp.n = icmp eq i64 %n.vec, %wide.trip.count
  br i1 %cmp.n, label %after_for3, label %for_loop_body1.preheader43

for_loop_body1.preheader43:                       ; preds = %middle.block, %for_loop_body1.preheader
  %indvars.iv.ph = phi i64 [ 0, %for_loop_body1.preheader ], [ %n.vec, %middle.block ]
  %.01319.ph = phi i32 [ 0, %for_loop_body1.preheader ], [ %207, %middle.block ]
  %.01418.ph = phi i32 [ 0, %for_loop_body1.preheader ], [ %206, %middle.block ]
  %.01517.ph = phi i32 [ 0, %for_loop_body1.preheader ], [ %205, %middle.block ]
  %208 = shl nsw i64 %28, 2
  %uglygep98 = getelementptr i8, ptr %26, i64 %208
  br label %for_loop_body1

after_for.loopexit:                               ; preds = %after_for3
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %allocs
  ret void

for_loop_body1:                                   ; preds = %for_loop_body1, %for_loop_body1.preheader43
  %indvars.iv = phi i64 [ %indvars.iv.next, %for_loop_body1 ], [ %indvars.iv.ph, %for_loop_body1.preheader43 ]
  %.01319 = phi i32 [ %228, %for_loop_body1 ], [ %.01319.ph, %for_loop_body1.preheader43 ]
  %.01418 = phi i32 [ %226, %for_loop_body1 ], [ %.01418.ph, %for_loop_body1.preheader43 ]
  %.01517 = phi i32 [ %224, %for_loop_body1 ], [ %.01517.ph, %for_loop_body1.preheader43 ]
  %209 = shl i64 %indvars.iv, 2
  %uglygep100 = getelementptr i8, ptr %26, i64 %209
  %210 = load i32, ptr %uglygep100, align 4
  %uglygep99 = getelementptr i8, ptr %uglygep98, i64 %209
  %211 = load i32, ptr %uglygep99, align 4
  %212 = tail call i32 @llvm.smin.i32(i32 %210, i32 %211)
  %213 = zext i32 %212 to i64
  %214 = shl nuw i64 %213, 32
  %215 = tail call i32 @llvm.smax.i32(i32 %210, i32 %211)
  %216 = sext i32 %215 to i64
  %217 = add i64 %214, %216
  %218 = icmp eq i64 %217, %39
  %219 = icmp slt i64 %indvars.iv, %indvars.iv27
  %220 = and i1 %219, %218
  %221 = icmp slt i64 %217, %39
  %222 = or i1 %221, %220
  %223 = zext i1 %222 to i32
  %224 = add i32 %.01517, %223
  %225 = zext i1 %218 to i32
  %226 = add i32 %.01418, %225
  %227 = zext i1 %220 to i32
  %228 = add i32 %.01319, %227
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %wide.trip.count, %indvars.iv.next
  br i1 %exitcond.not, label %after_for3.loopexit, label %for_loop_body1, !llvm.loop !10

after_for3.loopexit:                              ; preds = %for_loop_body1
  br label %after_for3

after_for3:                                       ; preds = %after_for3.loopexit, %middle.block, %for_loop_body
  %.015.lcssa = phi i32 [ 0, %for_loop_body ], [ %205, %middle.block ], [ %224, %after_for3.loopexit ]
  %.014.lcssa = phi i32 [ 0, %for_loop_body ], [ %206, %middle.block ], [ %226, %after_for3.loopexit ]
  %.013.lcssa = phi i32 [ 0, %for_loop_body ], [ %207, %middle.block ], [ %228, %after_for3.loopexit ]
  %229 = load ptr, ptr %23, align 8
  %230 = sext i32 %.015.lcssa to i64
  %231 = getelementptr i32, ptr %229, i64 %230
  %232 = trunc i64 %indvars.iv27 to i32
  store i32 %232, ptr %231, align 4
  %233 = add i32 %.014.lcssa, %.015.lcssa
  %234 = sub i32 %233, %.013.lcssa
  %235 = load ptr, ptr %24, align 8
  %236 = getelementptr i32, ptr %235, i64 %230
  store i32 %234, ptr %236, align 4
  %indvars.iv.next28 = add nsw i64 %indvars.iv27, 1
  %exitcond31.not = icmp eq i64 %indvars.iv.next28, %wide.trip.count30
  br i1 %exitcond31.not, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_parallel_range_for_task(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #3 {
  %4 = alloca %struct.RuntimeContext.990, align 8
  %.sroa.0.0.copyload = load ptr, ptr %0, align 8
  %.sroa.4.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 8
  %.sroa.4.0.copyload = load ptr, ptr %.sroa.4.0..sroa_idx, align 8
  %.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 16
  %.sroa.5.0.copyload = load ptr, ptr %.sroa.5.0..sroa_idx, align 8
  %.sroa.7.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 24
  %.sroa.7.0.copyload = load ptr, ptr %.sroa.7.0..sroa_idx, align 8
  %.sroa.8.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 32
  %.sroa.8.0.copyload = load i64, ptr %.sroa.8.0..sroa_idx, align 8
  %.sroa.9.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 40
  %.sroa.9.0.copyload = load i32, ptr %.sroa.9.0..sroa_idx, align 8
  %.sroa.12.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 44
  %.sroa.12.0.copyload = load i32, ptr %.sroa.12.0..sroa_idx, align 4
  %.sroa.15.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 48
  %.sroa.15.0.copyload = load i32, ptr %.sroa.15.0..sroa_idx, align 8
  %.sroa.17.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 52
  %.sroa.17.0.copyload = load i32, ptr %.sroa.17.0..sroa_idx, align 4
  %5 = alloca i8, i64 %.sroa.8.0.copyload, align 8
  %.not = icmp eq ptr %.sroa.4.0.copyload, null
  br i1 %.not, label %7, label %6

6:                                                ; preds = %3
  call void %.sroa.4.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %7

7:                                                ; preds = %6, %3
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %4, ptr noundef nonnull align 8 dereferenceable(32) %.sroa.0.0.copyload, i64 32, i1 false)
  %8 = getelementptr inbounds %struct.RuntimeContext.990, ptr %4, i64 0, i32 2
  store i32 %1, ptr %8, align 8
  switch i32 %.sroa.17.0.copyload, label %.loopexit [
    i32 1, label %9
    i32 -1, label %17
  ]

9:                                                ; preds = %7
  %10 = mul nsw i32 %.sroa.15.0.copyload, %2
  %11 = add nsw i32 %10, %.sroa.9.0.copyload
  %12 = add nsw i32 %11, %.sroa.15.0.copyload
  %13 = call i32 @llvm.smin.i32(i32 %.sroa.12.0.copyload, i32 %12)
  %14 = icmp slt i32 %11, %13
  br i1 %14, label %.lr.ph.preheader, label %.loopexit

.lr.ph.preheader:                                 ; preds = %9
  br label %.lr.ph

.lr.ph:                                           ; preds = %.lr.ph, %.lr.ph.preheader
  %.02039 = phi i32 [ %15, %.lr.ph ], [ %11, %.lr.ph.preheader ]
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.02039) #1
  %15 = add nsw i32 %.02039, 1
  %16 = icmp slt i32 %15, %13
  br i1 %16, label %.lr.ph, label %.loopexit.loopexit, !llvm.loop !12

17:                                               ; preds = %7
  %18 = mul nsw i32 %.sroa.15.0.copyload, %2
  %19 = sub nsw i32 %.sroa.12.0.copyload, %18
  %20 = mul nsw i32 %19, %.sroa.15.0.copyload
  %21 = call i32 @llvm.smax.i32(i32 %.sroa.9.0.copyload, i32 %20)
  %.not25.not40 = icmp sgt i32 %19, %21
  br i1 %.not25.not40, label %.lr.ph42.preheader, label %.loopexit

.lr.ph42.preheader:                               ; preds = %17
  br label %.lr.ph42

.lr.ph42:                                         ; preds = %.lr.ph42, %.lr.ph42.preheader
  %.0.in41 = phi i32 [ %.0, %.lr.ph42 ], [ %19, %.lr.ph42.preheader ]
  %.0 = add nsw i32 %.0.in41, -1
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.0) #1
  %.not25.not = icmp sgt i32 %.0, %21
  br i1 %.not25.not, label %.lr.ph42, label %.loopexit.loopexit47, !llvm.loop !14

.loopexit.loopexit:                               ; preds = %.lr.ph
  br label %.loopexit

.loopexit.loopexit47:                             ; preds = %.lr.ph42
  br label %.loopexit

.loopexit:                                        ; preds = %.loopexit.loopexit47, %.loopexit.loopexit, %17, %9, %7
  %.not24 = icmp eq ptr %.sroa.7.0.copyload, null
  br i1 %.not24, label %23, label %22

22:                                               ; preds = %.loopexit
  call void %.sroa.7.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %23

23:                                               ; preds = %22, %.loopexit
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #5

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smax.i32(i32, i32) #5

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #6

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #6

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare <8 x i32> @llvm.smin.v8i32(<8 x i32>, <8 x i32>) #7

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare <8 x i32> @llvm.smax.v8i32(<8 x i32>, <8 x i32>) #7

; Function Attrs: nocallback nofree nosync nounwind readnone willreturn
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #8

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { nofree nosync nounwind }
attributes #3 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #5 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #6 = { argmemonly nocallback nofree nosync nounwind willreturn }
attributes #7 = { nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #8 = { nocallback nofree nosync nounwind readnone willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.isvectorized", i32 1}
!8 = distinct !{!8, !9}
!9 = !{!"llvm.loop.unroll.disable"}
!10 = distinct !{!10, !11, !7}
!11 = !{!"llvm.loop.unroll.runtime.disable"}
!12 = distinct !{!12, !13}
!13 = !{!"llvm.loop.mustprogress"}
!14 = distinct !{!14, !13}
