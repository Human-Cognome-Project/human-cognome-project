; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct.range_task_helper_context = type { ptr, ptr, ptr, ptr, i64, i32, i32, i32, i32 }
%struct.RuntimeContext.998 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }

; Function Attrs: nounwind
define void @tick_geometry_reset_25_kernel_0_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.998, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { i32 }, ptr }, ptr %7, i64 0, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %10 = xor i64 %9, -1
  %11 = add nsw i64 %10, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %9, %for_loop_body.prol.preheader ]
  %12 = load ptr, ptr %8, align 8
  %13 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep20 = getelementptr i8, ptr %12, i64 %13
  store i32 0, ptr %uglygep20, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !6

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %9, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %14 = icmp ult i64 %11, 7
  br i1 %14, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %for_loop_body ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %15 = load ptr, ptr %8, align 8
  %16 = shl i64 %indvars.iv, 2
  %uglygep17 = getelementptr i8, ptr %15, i64 %16
  store i32 0, ptr %uglygep17, align 4
  %17 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %17, i64 4
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %16
  store i32 0, ptr %uglygep19, align 4
  %18 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %18, i64 8
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %16
  store i32 0, ptr %uglygep16, align 4
  %19 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %19, i64 12
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %16
  store i32 0, ptr %uglygep14, align 4
  %20 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %20, i64 16
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %16
  store i32 0, ptr %uglygep12, align 4
  %21 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %21, i64 20
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %16
  store i32 0, ptr %uglygep10, align 4
  %22 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %22, i64 24
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %16
  store i32 0, ptr %uglygep8, align 4
  %23 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %23, i64 28
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %16
  store i32 0, ptr %uglygep6, align 4
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @tick_geometry_reset_25_kernel_1_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.1, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.998, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.1(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 1, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %10 = xor i64 %9, -1
  %11 = add nsw i64 %10, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %9, %for_loop_body.prol.preheader ]
  %12 = load ptr, ptr %8, align 8
  %13 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep20 = getelementptr i8, ptr %12, i64 %13
  store i32 0, ptr %uglygep20, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !8

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %9, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %14 = icmp ult i64 %11, 7
  br i1 %14, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %for_loop_body ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %15 = load ptr, ptr %8, align 8
  %16 = shl i64 %indvars.iv, 2
  %uglygep17 = getelementptr i8, ptr %15, i64 %16
  store i32 0, ptr %uglygep17, align 4
  %17 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %17, i64 4
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %16
  store i32 0, ptr %uglygep19, align 4
  %18 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %18, i64 8
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %16
  store i32 0, ptr %uglygep16, align 4
  %19 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %19, i64 12
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %16
  store i32 0, ptr %uglygep14, align 4
  %20 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %20, i64 16
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %16
  store i32 0, ptr %uglygep12, align 4
  %21 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %21, i64 20
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %16
  store i32 0, ptr %uglygep10, align 4
  %22 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %22, i64 24
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %16
  store i32 0, ptr %uglygep8, align 4
  %23 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %23, i64 28
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %16
  store i32 0, ptr %uglygep6, align 4
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @tick_geometry_reset_25_kernel_2_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.2, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.998, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.2(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 1, i32 1
  %9 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 1, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv6 = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next7, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = add nsw i64 %indvars.iv.prol, %15
  %17 = getelementptr i32, ptr %13, i64 %16
  store i32 0, ptr %17, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next7 = add nsw i64 %lsr.iv6, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next7, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !9

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %18 = icmp ult i64 %12, 7
  br i1 %18, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  %19 = sub i64 0, %wide.trip.count
  %20 = add nsw i64 %indvars.iv.unr, 7
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %lsr.iv = phi i64 [ %20, %for_loop_body.preheader ], [ %lsr.iv.next, %for_loop_body ]
  %21 = load ptr, ptr %8, align 8
  %22 = load i32, ptr %9, align 4
  %23 = sext i32 %22 to i64
  %24 = add i64 %lsr.iv, %23
  %25 = getelementptr i32, ptr %21, i64 %24
  %26 = getelementptr i32, ptr %25, i64 -7
  store i32 0, ptr %26, align 4
  %27 = load ptr, ptr %8, align 8
  %28 = load i32, ptr %9, align 4
  %29 = sext i32 %28 to i64
  %30 = add i64 %lsr.iv, %29
  %31 = getelementptr i32, ptr %27, i64 %30
  %32 = getelementptr i32, ptr %31, i64 -6
  store i32 0, ptr %32, align 4
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = add i64 %lsr.iv, %35
  %37 = getelementptr i32, ptr %33, i64 %36
  %38 = getelementptr i32, ptr %37, i64 -5
  store i32 0, ptr %38, align 4
  %39 = load ptr, ptr %8, align 8
  %40 = load i32, ptr %9, align 4
  %41 = sext i32 %40 to i64
  %42 = add i64 %lsr.iv, %41
  %43 = getelementptr i32, ptr %39, i64 %42
  %44 = getelementptr i32, ptr %43, i64 -4
  store i32 0, ptr %44, align 4
  %45 = load ptr, ptr %8, align 8
  %46 = load i32, ptr %9, align 4
  %47 = sext i32 %46 to i64
  %48 = add i64 %lsr.iv, %47
  %49 = getelementptr i32, ptr %45, i64 %48
  %50 = getelementptr i32, ptr %49, i64 -3
  store i32 0, ptr %50, align 4
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = add i64 %lsr.iv, %53
  %55 = getelementptr i32, ptr %51, i64 %54
  %56 = getelementptr i32, ptr %55, i64 -2
  store i32 0, ptr %56, align 4
  %57 = load ptr, ptr %8, align 8
  %58 = load i32, ptr %9, align 4
  %59 = sext i32 %58 to i64
  %60 = add i64 %lsr.iv, %59
  %61 = getelementptr i32, ptr %57, i64 %60
  %62 = getelementptr i32, ptr %61, i64 -1
  store i32 0, ptr %62, align 4
  %63 = load ptr, ptr %8, align 8
  %64 = load i32, ptr %9, align 4
  %65 = sext i32 %64 to i64
  %66 = add nsw i64 %lsr.iv, %65
  %67 = getelementptr i32, ptr %63, i64 %66
  store i32 0, ptr %67, align 4
  %lsr.iv.next = add i64 %lsr.iv, 8
  %68 = add i64 %19, %lsr.iv.next
  %exitcond.not.7 = icmp eq i64 %68, 7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @tick_geometry_reset_25_kernel_3_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.3, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.998, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.3(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 1, i32 1
  %9 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 1, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = shl nsw i64 %15, 3
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  store i32 0, ptr %uglygep29, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !10

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %18 = icmp ult i64 %12, 7
  br i1 %18, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %for_loop_body ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %19 = load ptr, ptr %8, align 8
  %20 = load i32, ptr %9, align 4
  %21 = sext i32 %20 to i64
  %22 = shl nsw i64 %21, 3
  %uglygep23 = getelementptr i8, ptr %19, i64 %22
  %23 = shl i64 %indvars.iv, 2
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %23
  store i32 0, ptr %uglygep24, align 4
  %24 = load ptr, ptr %8, align 8
  %25 = load i32, ptr %9, align 4
  %26 = sext i32 %25 to i64
  %27 = shl nsw i64 %26, 3
  %uglygep25 = getelementptr i8, ptr %24, i64 %27
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %23
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 4
  store i32 0, ptr %uglygep27, align 4
  %28 = load ptr, ptr %8, align 8
  %29 = load i32, ptr %9, align 4
  %30 = sext i32 %29 to i64
  %31 = shl nsw i64 %30, 3
  %uglygep20 = getelementptr i8, ptr %28, i64 %31
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %23
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 8
  store i32 0, ptr %uglygep22, align 4
  %32 = load ptr, ptr %8, align 8
  %33 = load i32, ptr %9, align 4
  %34 = sext i32 %33 to i64
  %35 = shl nsw i64 %34, 3
  %uglygep17 = getelementptr i8, ptr %32, i64 %35
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %23
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 12
  store i32 0, ptr %uglygep19, align 4
  %36 = load ptr, ptr %8, align 8
  %37 = load i32, ptr %9, align 4
  %38 = sext i32 %37 to i64
  %39 = shl nsw i64 %38, 3
  %uglygep14 = getelementptr i8, ptr %36, i64 %39
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %23
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 16
  store i32 0, ptr %uglygep16, align 4
  %40 = load ptr, ptr %8, align 8
  %41 = load i32, ptr %9, align 4
  %42 = sext i32 %41 to i64
  %43 = shl nsw i64 %42, 3
  %uglygep11 = getelementptr i8, ptr %40, i64 %43
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %23
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 20
  store i32 0, ptr %uglygep13, align 4
  %44 = load ptr, ptr %8, align 8
  %45 = load i32, ptr %9, align 4
  %46 = sext i32 %45 to i64
  %47 = shl nsw i64 %46, 3
  %uglygep8 = getelementptr i8, ptr %44, i64 %47
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %23
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 24
  store i32 0, ptr %uglygep10, align 4
  %48 = load ptr, ptr %8, align 8
  %49 = load i32, ptr %9, align 4
  %50 = sext i32 %49 to i64
  %51 = shl nsw i64 %50, 3
  %uglygep = getelementptr i8, ptr %48, i64 %51
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %23
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 28
  store i32 0, ptr %uglygep7, align 4
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @tick_geometry_reset_25_kernel_4_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.4, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.998, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.4(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 1, i32 1
  %9 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 1, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = mul nsw i64 %15, 12
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  store i32 0, ptr %uglygep29, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !11

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %18 = icmp ult i64 %12, 7
  br i1 %18, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %for_loop_body ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %19 = load ptr, ptr %8, align 8
  %20 = load i32, ptr %9, align 4
  %21 = sext i32 %20 to i64
  %22 = mul nsw i64 %21, 12
  %uglygep23 = getelementptr i8, ptr %19, i64 %22
  %23 = shl i64 %indvars.iv, 2
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %23
  store i32 0, ptr %uglygep24, align 4
  %24 = load ptr, ptr %8, align 8
  %25 = load i32, ptr %9, align 4
  %26 = sext i32 %25 to i64
  %27 = mul nsw i64 %26, 12
  %uglygep25 = getelementptr i8, ptr %24, i64 %27
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %23
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 4
  store i32 0, ptr %uglygep27, align 4
  %28 = load ptr, ptr %8, align 8
  %29 = load i32, ptr %9, align 4
  %30 = sext i32 %29 to i64
  %31 = mul nsw i64 %30, 12
  %uglygep20 = getelementptr i8, ptr %28, i64 %31
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %23
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 8
  store i32 0, ptr %uglygep22, align 4
  %32 = load ptr, ptr %8, align 8
  %33 = load i32, ptr %9, align 4
  %34 = sext i32 %33 to i64
  %35 = mul nsw i64 %34, 12
  %uglygep17 = getelementptr i8, ptr %32, i64 %35
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %23
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 12
  store i32 0, ptr %uglygep19, align 4
  %36 = load ptr, ptr %8, align 8
  %37 = load i32, ptr %9, align 4
  %38 = sext i32 %37 to i64
  %39 = mul nsw i64 %38, 12
  %uglygep14 = getelementptr i8, ptr %36, i64 %39
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %23
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 16
  store i32 0, ptr %uglygep16, align 4
  %40 = load ptr, ptr %8, align 8
  %41 = load i32, ptr %9, align 4
  %42 = sext i32 %41 to i64
  %43 = mul nsw i64 %42, 12
  %uglygep11 = getelementptr i8, ptr %40, i64 %43
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %23
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 20
  store i32 0, ptr %uglygep13, align 4
  %44 = load ptr, ptr %8, align 8
  %45 = load i32, ptr %9, align 4
  %46 = sext i32 %45 to i64
  %47 = mul nsw i64 %46, 12
  %uglygep8 = getelementptr i8, ptr %44, i64 %47
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %23
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 24
  store i32 0, ptr %uglygep10, align 4
  %48 = load ptr, ptr %8, align 8
  %49 = load i32, ptr %9, align 4
  %50 = sext i32 %49 to i64
  %51 = mul nsw i64 %50, 12
  %uglygep = getelementptr i8, ptr %48, i64 %51
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %23
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 28
  store i32 0, ptr %uglygep7, align 4
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @tick_geometry_reset_25_kernel_5_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.5, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.998, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.5(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 2, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %10 = xor i64 %9, -1
  %11 = add nsw i64 %10, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %9, %for_loop_body.prol.preheader ]
  %12 = load ptr, ptr %8, align 8
  %13 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep20 = getelementptr i8, ptr %12, i64 %13
  store i32 0, ptr %uglygep20, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !12

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %9, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %14 = icmp ult i64 %11, 7
  br i1 %14, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %for_loop_body ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %15 = load ptr, ptr %8, align 8
  %16 = shl i64 %indvars.iv, 2
  %uglygep17 = getelementptr i8, ptr %15, i64 %16
  store i32 0, ptr %uglygep17, align 4
  %17 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %17, i64 4
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %16
  store i32 0, ptr %uglygep19, align 4
  %18 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %18, i64 8
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %16
  store i32 0, ptr %uglygep16, align 4
  %19 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %19, i64 12
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %16
  store i32 0, ptr %uglygep14, align 4
  %20 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %20, i64 16
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %16
  store i32 0, ptr %uglygep12, align 4
  %21 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %21, i64 20
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %16
  store i32 0, ptr %uglygep10, align 4
  %22 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %22, i64 24
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %16
  store i32 0, ptr %uglygep8, align 4
  %23 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %23, i64 28
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %16
  store i32 0, ptr %uglygep6, align 4
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @tick_geometry_reset_25_kernel_6_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.6, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.998, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.6(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 2, i32 1
  %9 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 2, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv6 = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next7, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = add nsw i64 %indvars.iv.prol, %15
  %17 = getelementptr i32, ptr %13, i64 %16
  store i32 0, ptr %17, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next7 = add nsw i64 %lsr.iv6, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next7, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !13

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %18 = icmp ult i64 %12, 7
  br i1 %18, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  %19 = sub i64 0, %wide.trip.count
  %20 = add nsw i64 %indvars.iv.unr, 7
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %lsr.iv = phi i64 [ %20, %for_loop_body.preheader ], [ %lsr.iv.next, %for_loop_body ]
  %21 = load ptr, ptr %8, align 8
  %22 = load i32, ptr %9, align 4
  %23 = sext i32 %22 to i64
  %24 = add i64 %lsr.iv, %23
  %25 = getelementptr i32, ptr %21, i64 %24
  %26 = getelementptr i32, ptr %25, i64 -7
  store i32 0, ptr %26, align 4
  %27 = load ptr, ptr %8, align 8
  %28 = load i32, ptr %9, align 4
  %29 = sext i32 %28 to i64
  %30 = add i64 %lsr.iv, %29
  %31 = getelementptr i32, ptr %27, i64 %30
  %32 = getelementptr i32, ptr %31, i64 -6
  store i32 0, ptr %32, align 4
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = add i64 %lsr.iv, %35
  %37 = getelementptr i32, ptr %33, i64 %36
  %38 = getelementptr i32, ptr %37, i64 -5
  store i32 0, ptr %38, align 4
  %39 = load ptr, ptr %8, align 8
  %40 = load i32, ptr %9, align 4
  %41 = sext i32 %40 to i64
  %42 = add i64 %lsr.iv, %41
  %43 = getelementptr i32, ptr %39, i64 %42
  %44 = getelementptr i32, ptr %43, i64 -4
  store i32 0, ptr %44, align 4
  %45 = load ptr, ptr %8, align 8
  %46 = load i32, ptr %9, align 4
  %47 = sext i32 %46 to i64
  %48 = add i64 %lsr.iv, %47
  %49 = getelementptr i32, ptr %45, i64 %48
  %50 = getelementptr i32, ptr %49, i64 -3
  store i32 0, ptr %50, align 4
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = add i64 %lsr.iv, %53
  %55 = getelementptr i32, ptr %51, i64 %54
  %56 = getelementptr i32, ptr %55, i64 -2
  store i32 0, ptr %56, align 4
  %57 = load ptr, ptr %8, align 8
  %58 = load i32, ptr %9, align 4
  %59 = sext i32 %58 to i64
  %60 = add i64 %lsr.iv, %59
  %61 = getelementptr i32, ptr %57, i64 %60
  %62 = getelementptr i32, ptr %61, i64 -1
  store i32 0, ptr %62, align 4
  %63 = load ptr, ptr %8, align 8
  %64 = load i32, ptr %9, align 4
  %65 = sext i32 %64 to i64
  %66 = add nsw i64 %lsr.iv, %65
  %67 = getelementptr i32, ptr %63, i64 %66
  store i32 0, ptr %67, align 4
  %lsr.iv.next = add i64 %lsr.iv, 8
  %68 = add i64 %19, %lsr.iv.next
  %exitcond.not.7 = icmp eq i64 %68, 7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @tick_geometry_reset_25_kernel_7_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.7, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.998, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.7(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 3, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %10 = xor i64 %9, -1
  %11 = add nsw i64 %10, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %9, %for_loop_body.prol.preheader ]
  %12 = load ptr, ptr %8, align 8
  %13 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep20 = getelementptr i8, ptr %12, i64 %13
  store i32 0, ptr %uglygep20, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !14

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %9, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %14 = icmp ult i64 %11, 7
  br i1 %14, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %for_loop_body ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %15 = load ptr, ptr %8, align 8
  %16 = shl i64 %indvars.iv, 2
  %uglygep17 = getelementptr i8, ptr %15, i64 %16
  store i32 0, ptr %uglygep17, align 4
  %17 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %17, i64 4
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %16
  store i32 0, ptr %uglygep19, align 4
  %18 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %18, i64 8
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %16
  store i32 0, ptr %uglygep16, align 4
  %19 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %19, i64 12
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %16
  store i32 0, ptr %uglygep14, align 4
  %20 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %20, i64 16
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %16
  store i32 0, ptr %uglygep12, align 4
  %21 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %21, i64 20
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %16
  store i32 0, ptr %uglygep10, align 4
  %22 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %22, i64 24
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %16
  store i32 0, ptr %uglygep8, align 4
  %23 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %23, i64 28
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %16
  store i32 0, ptr %uglygep6, align 4
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @tick_geometry_reset_25_kernel_8_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.8, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.998, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.8(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 4, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %10 = xor i64 %9, -1
  %11 = add nsw i64 %10, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %9, %for_loop_body.prol.preheader ]
  %12 = load ptr, ptr %8, align 8
  %13 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep20 = getelementptr i8, ptr %12, i64 %13
  store i32 0, ptr %uglygep20, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !15

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %9, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %14 = icmp ult i64 %11, 7
  br i1 %14, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %for_loop_body ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %15 = load ptr, ptr %8, align 8
  %16 = shl i64 %indvars.iv, 2
  %uglygep17 = getelementptr i8, ptr %15, i64 %16
  store i32 0, ptr %uglygep17, align 4
  %17 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %17, i64 4
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %16
  store i32 0, ptr %uglygep19, align 4
  %18 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %18, i64 8
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %16
  store i32 0, ptr %uglygep16, align 4
  %19 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %19, i64 12
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %16
  store i32 0, ptr %uglygep14, align 4
  %20 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %20, i64 16
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %16
  store i32 0, ptr %uglygep12, align 4
  %21 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %21, i64 20
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %16
  store i32 0, ptr %uglygep10, align 4
  %22 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %22, i64 24
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %16
  store i32 0, ptr %uglygep8, align 4
  %23 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %23, i64 28
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %16
  store i32 0, ptr %uglygep6, align 4
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @tick_geometry_reset_25_kernel_9_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.9, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.998, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.9(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 5, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %10 = xor i64 %9, -1
  %11 = add nsw i64 %10, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %9, %for_loop_body.prol.preheader ]
  %12 = load ptr, ptr %8, align 8
  %13 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep20 = getelementptr i8, ptr %12, i64 %13
  store i32 0, ptr %uglygep20, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !16

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %9, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %14 = icmp ult i64 %11, 7
  br i1 %14, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %for_loop_body ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %15 = load ptr, ptr %8, align 8
  %16 = shl i64 %indvars.iv, 2
  %uglygep17 = getelementptr i8, ptr %15, i64 %16
  store i32 0, ptr %uglygep17, align 4
  %17 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %17, i64 4
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %16
  store i32 0, ptr %uglygep19, align 4
  %18 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %18, i64 8
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %16
  store i32 0, ptr %uglygep16, align 4
  %19 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %19, i64 12
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %16
  store i32 0, ptr %uglygep14, align 4
  %20 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %20, i64 16
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %16
  store i32 0, ptr %uglygep12, align 4
  %21 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %21, i64 20
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %16
  store i32 0, ptr %uglygep10, align 4
  %22 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %22, i64 24
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %16
  store i32 0, ptr %uglygep8, align 4
  %23 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %23, i64 28
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %16
  store i32 0, ptr %uglygep6, align 4
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @tick_geometry_reset_25_kernel_10_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.10, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.998, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.10(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 6, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %10 = xor i64 %9, -1
  %11 = add nsw i64 %10, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %9, %for_loop_body.prol.preheader ]
  %12 = load ptr, ptr %8, align 8
  %13 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep20 = getelementptr i8, ptr %12, i64 %13
  store i32 0, ptr %uglygep20, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !17

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %9, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %14 = icmp ult i64 %11, 7
  br i1 %14, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %for_loop_body ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %15 = load ptr, ptr %8, align 8
  %16 = shl i64 %indvars.iv, 2
  %uglygep17 = getelementptr i8, ptr %15, i64 %16
  store i32 0, ptr %uglygep17, align 4
  %17 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %17, i64 4
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %16
  store i32 0, ptr %uglygep19, align 4
  %18 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %18, i64 8
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %16
  store i32 0, ptr %uglygep16, align 4
  %19 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %19, i64 12
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %16
  store i32 0, ptr %uglygep14, align 4
  %20 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %20, i64 16
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %16
  store i32 0, ptr %uglygep12, align 4
  %21 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %21, i64 20
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %16
  store i32 0, ptr %uglygep10, align 4
  %22 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %22, i64 24
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %16
  store i32 0, ptr %uglygep8, align 4
  %23 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %23, i64 28
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %16
  store i32 0, ptr %uglygep6, align 4
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @tick_geometry_reset_25_kernel_11_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.11, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.998, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.11(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 7, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %10 = xor i64 %9, -1
  %11 = add nsw i64 %10, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %9, %for_loop_body.prol.preheader ]
  %12 = load ptr, ptr %8, align 8
  %13 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep20 = getelementptr i8, ptr %12, i64 %13
  store i32 0, ptr %uglygep20, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !18

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %9, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %14 = icmp ult i64 %11, 7
  br i1 %14, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %for_loop_body ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %15 = load ptr, ptr %8, align 8
  %16 = shl i64 %indvars.iv, 2
  %uglygep17 = getelementptr i8, ptr %15, i64 %16
  store i32 0, ptr %uglygep17, align 4
  %17 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %17, i64 4
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %16
  store i32 0, ptr %uglygep19, align 4
  %18 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %18, i64 8
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %16
  store i32 0, ptr %uglygep16, align 4
  %19 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %19, i64 12
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %16
  store i32 0, ptr %uglygep14, align 4
  %20 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %20, i64 16
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %16
  store i32 0, ptr %uglygep12, align 4
  %21 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %21, i64 20
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %16
  store i32 0, ptr %uglygep10, align 4
  %22 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %22, i64 24
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %16
  store i32 0, ptr %uglygep8, align 4
  %23 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %23, i64 28
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %16
  store i32 0, ptr %uglygep6, align 4
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @tick_geometry_reset_25_kernel_12_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.12, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.998, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.12(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 8, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %10 = xor i64 %9, -1
  %11 = add nsw i64 %10, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %9, %for_loop_body.prol.preheader ]
  %12 = load ptr, ptr %8, align 8
  %13 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep20 = getelementptr i8, ptr %12, i64 %13
  store i32 0, ptr %uglygep20, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !19

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %9, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %14 = icmp ult i64 %11, 7
  br i1 %14, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %for_loop_body ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %15 = load ptr, ptr %8, align 8
  %16 = shl i64 %indvars.iv, 2
  %uglygep17 = getelementptr i8, ptr %15, i64 %16
  store i32 0, ptr %uglygep17, align 4
  %17 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %17, i64 4
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %16
  store i32 0, ptr %uglygep19, align 4
  %18 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %18, i64 8
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %16
  store i32 0, ptr %uglygep16, align 4
  %19 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %19, i64 12
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %16
  store i32 0, ptr %uglygep14, align 4
  %20 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %20, i64 16
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %16
  store i32 0, ptr %uglygep12, align 4
  %21 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %21, i64 20
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %16
  store i32 0, ptr %uglygep10, align 4
  %22 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %22, i64 24
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %16
  store i32 0, ptr %uglygep8, align 4
  %23 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %23, i64 28
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %16
  store i32 0, ptr %uglygep6, align 4
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @tick_geometry_reset_25_kernel_13_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.13, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.998, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.13(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 8, i32 1
  %9 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 8, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv6 = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next7, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = add nsw i64 %indvars.iv.prol, %15
  %17 = getelementptr i32, ptr %13, i64 %16
  store i32 0, ptr %17, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next7 = add nsw i64 %lsr.iv6, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next7, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !20

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %18 = icmp ult i64 %12, 7
  br i1 %18, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  %19 = sub i64 0, %wide.trip.count
  %20 = add nsw i64 %indvars.iv.unr, 7
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %lsr.iv = phi i64 [ %20, %for_loop_body.preheader ], [ %lsr.iv.next, %for_loop_body ]
  %21 = load ptr, ptr %8, align 8
  %22 = load i32, ptr %9, align 4
  %23 = sext i32 %22 to i64
  %24 = add i64 %lsr.iv, %23
  %25 = getelementptr i32, ptr %21, i64 %24
  %26 = getelementptr i32, ptr %25, i64 -7
  store i32 0, ptr %26, align 4
  %27 = load ptr, ptr %8, align 8
  %28 = load i32, ptr %9, align 4
  %29 = sext i32 %28 to i64
  %30 = add i64 %lsr.iv, %29
  %31 = getelementptr i32, ptr %27, i64 %30
  %32 = getelementptr i32, ptr %31, i64 -6
  store i32 0, ptr %32, align 4
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = add i64 %lsr.iv, %35
  %37 = getelementptr i32, ptr %33, i64 %36
  %38 = getelementptr i32, ptr %37, i64 -5
  store i32 0, ptr %38, align 4
  %39 = load ptr, ptr %8, align 8
  %40 = load i32, ptr %9, align 4
  %41 = sext i32 %40 to i64
  %42 = add i64 %lsr.iv, %41
  %43 = getelementptr i32, ptr %39, i64 %42
  %44 = getelementptr i32, ptr %43, i64 -4
  store i32 0, ptr %44, align 4
  %45 = load ptr, ptr %8, align 8
  %46 = load i32, ptr %9, align 4
  %47 = sext i32 %46 to i64
  %48 = add i64 %lsr.iv, %47
  %49 = getelementptr i32, ptr %45, i64 %48
  %50 = getelementptr i32, ptr %49, i64 -3
  store i32 0, ptr %50, align 4
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = add i64 %lsr.iv, %53
  %55 = getelementptr i32, ptr %51, i64 %54
  %56 = getelementptr i32, ptr %55, i64 -2
  store i32 0, ptr %56, align 4
  %57 = load ptr, ptr %8, align 8
  %58 = load i32, ptr %9, align 4
  %59 = sext i32 %58 to i64
  %60 = add i64 %lsr.iv, %59
  %61 = getelementptr i32, ptr %57, i64 %60
  %62 = getelementptr i32, ptr %61, i64 -1
  store i32 0, ptr %62, align 4
  %63 = load ptr, ptr %8, align 8
  %64 = load i32, ptr %9, align 4
  %65 = sext i32 %64 to i64
  %66 = add nsw i64 %lsr.iv, %65
  %67 = getelementptr i32, ptr %63, i64 %66
  store i32 0, ptr %67, align 4
  %lsr.iv.next = add i64 %lsr.iv, 8
  %68 = add i64 %19, %lsr.iv.next
  %exitcond.not.7 = icmp eq i64 %68, 7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @tick_geometry_reset_25_kernel_14_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.14, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.998, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.14(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 8, i32 1
  %9 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 8, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = shl nsw i64 %15, 3
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  store i32 0, ptr %uglygep29, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !21

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %18 = icmp ult i64 %12, 7
  br i1 %18, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %for_loop_body ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %19 = load ptr, ptr %8, align 8
  %20 = load i32, ptr %9, align 4
  %21 = sext i32 %20 to i64
  %22 = shl nsw i64 %21, 3
  %uglygep23 = getelementptr i8, ptr %19, i64 %22
  %23 = shl i64 %indvars.iv, 2
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %23
  store i32 0, ptr %uglygep24, align 4
  %24 = load ptr, ptr %8, align 8
  %25 = load i32, ptr %9, align 4
  %26 = sext i32 %25 to i64
  %27 = shl nsw i64 %26, 3
  %uglygep25 = getelementptr i8, ptr %24, i64 %27
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %23
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 4
  store i32 0, ptr %uglygep27, align 4
  %28 = load ptr, ptr %8, align 8
  %29 = load i32, ptr %9, align 4
  %30 = sext i32 %29 to i64
  %31 = shl nsw i64 %30, 3
  %uglygep20 = getelementptr i8, ptr %28, i64 %31
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %23
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 8
  store i32 0, ptr %uglygep22, align 4
  %32 = load ptr, ptr %8, align 8
  %33 = load i32, ptr %9, align 4
  %34 = sext i32 %33 to i64
  %35 = shl nsw i64 %34, 3
  %uglygep17 = getelementptr i8, ptr %32, i64 %35
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %23
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 12
  store i32 0, ptr %uglygep19, align 4
  %36 = load ptr, ptr %8, align 8
  %37 = load i32, ptr %9, align 4
  %38 = sext i32 %37 to i64
  %39 = shl nsw i64 %38, 3
  %uglygep14 = getelementptr i8, ptr %36, i64 %39
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %23
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 16
  store i32 0, ptr %uglygep16, align 4
  %40 = load ptr, ptr %8, align 8
  %41 = load i32, ptr %9, align 4
  %42 = sext i32 %41 to i64
  %43 = shl nsw i64 %42, 3
  %uglygep11 = getelementptr i8, ptr %40, i64 %43
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %23
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 20
  store i32 0, ptr %uglygep13, align 4
  %44 = load ptr, ptr %8, align 8
  %45 = load i32, ptr %9, align 4
  %46 = sext i32 %45 to i64
  %47 = shl nsw i64 %46, 3
  %uglygep8 = getelementptr i8, ptr %44, i64 %47
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %23
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 24
  store i32 0, ptr %uglygep10, align 4
  %48 = load ptr, ptr %8, align 8
  %49 = load i32, ptr %9, align 4
  %50 = sext i32 %49 to i64
  %51 = shl nsw i64 %50, 3
  %uglygep = getelementptr i8, ptr %48, i64 %51
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %23
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 28
  store i32 0, ptr %uglygep7, align 4
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @tick_geometry_reset_25_kernel_15_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.15, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.998, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.15(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 8, i32 1
  %9 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 8, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = mul nsw i64 %15, 12
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  store i32 0, ptr %uglygep29, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !22

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %18 = icmp ult i64 %12, 7
  br i1 %18, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %for_loop_body ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %19 = load ptr, ptr %8, align 8
  %20 = load i32, ptr %9, align 4
  %21 = sext i32 %20 to i64
  %22 = mul nsw i64 %21, 12
  %uglygep23 = getelementptr i8, ptr %19, i64 %22
  %23 = shl i64 %indvars.iv, 2
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %23
  store i32 0, ptr %uglygep24, align 4
  %24 = load ptr, ptr %8, align 8
  %25 = load i32, ptr %9, align 4
  %26 = sext i32 %25 to i64
  %27 = mul nsw i64 %26, 12
  %uglygep25 = getelementptr i8, ptr %24, i64 %27
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %23
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 4
  store i32 0, ptr %uglygep27, align 4
  %28 = load ptr, ptr %8, align 8
  %29 = load i32, ptr %9, align 4
  %30 = sext i32 %29 to i64
  %31 = mul nsw i64 %30, 12
  %uglygep20 = getelementptr i8, ptr %28, i64 %31
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %23
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 8
  store i32 0, ptr %uglygep22, align 4
  %32 = load ptr, ptr %8, align 8
  %33 = load i32, ptr %9, align 4
  %34 = sext i32 %33 to i64
  %35 = mul nsw i64 %34, 12
  %uglygep17 = getelementptr i8, ptr %32, i64 %35
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %23
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 12
  store i32 0, ptr %uglygep19, align 4
  %36 = load ptr, ptr %8, align 8
  %37 = load i32, ptr %9, align 4
  %38 = sext i32 %37 to i64
  %39 = mul nsw i64 %38, 12
  %uglygep14 = getelementptr i8, ptr %36, i64 %39
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %23
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 16
  store i32 0, ptr %uglygep16, align 4
  %40 = load ptr, ptr %8, align 8
  %41 = load i32, ptr %9, align 4
  %42 = sext i32 %41 to i64
  %43 = mul nsw i64 %42, 12
  %uglygep11 = getelementptr i8, ptr %40, i64 %43
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %23
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 20
  store i32 0, ptr %uglygep13, align 4
  %44 = load ptr, ptr %8, align 8
  %45 = load i32, ptr %9, align 4
  %46 = sext i32 %45 to i64
  %47 = mul nsw i64 %46, 12
  %uglygep8 = getelementptr i8, ptr %44, i64 %47
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %23
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 24
  store i32 0, ptr %uglygep10, align 4
  %48 = load ptr, ptr %8, align 8
  %49 = load i32, ptr %9, align 4
  %50 = sext i32 %49 to i64
  %51 = mul nsw i64 %50, 12
  %uglygep = getelementptr i8, ptr %48, i64 %51
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %23
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 28
  store i32 0, ptr %uglygep7, align 4
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @tick_geometry_reset_25_kernel_16_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.16, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.998, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.16(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 9, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %10 = xor i64 %9, -1
  %11 = add nsw i64 %10, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %9, %for_loop_body.prol.preheader ]
  %12 = load ptr, ptr %8, align 8
  %13 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep20 = getelementptr i8, ptr %12, i64 %13
  store i32 0, ptr %uglygep20, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !23

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %9, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %14 = icmp ult i64 %11, 7
  br i1 %14, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %for_loop_body ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %15 = load ptr, ptr %8, align 8
  %16 = shl i64 %indvars.iv, 2
  %uglygep17 = getelementptr i8, ptr %15, i64 %16
  store i32 0, ptr %uglygep17, align 4
  %17 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %17, i64 4
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %16
  store i32 0, ptr %uglygep19, align 4
  %18 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %18, i64 8
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %16
  store i32 0, ptr %uglygep16, align 4
  %19 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %19, i64 12
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %16
  store i32 0, ptr %uglygep14, align 4
  %20 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %20, i64 16
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %16
  store i32 0, ptr %uglygep12, align 4
  %21 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %21, i64 20
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %16
  store i32 0, ptr %uglygep10, align 4
  %22 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %22, i64 24
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %16
  store i32 0, ptr %uglygep8, align 4
  %23 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %23, i64 28
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %16
  store i32 0, ptr %uglygep6, align 4
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @tick_geometry_reset_25_kernel_17_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.17, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.998, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.17(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 9, i32 1
  %9 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 9, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv6 = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next7, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = add nsw i64 %indvars.iv.prol, %15
  %17 = getelementptr i32, ptr %13, i64 %16
  store i32 0, ptr %17, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next7 = add nsw i64 %lsr.iv6, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next7, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !24

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %18 = icmp ult i64 %12, 7
  br i1 %18, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  %19 = sub i64 0, %wide.trip.count
  %20 = add nsw i64 %indvars.iv.unr, 7
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %lsr.iv = phi i64 [ %20, %for_loop_body.preheader ], [ %lsr.iv.next, %for_loop_body ]
  %21 = load ptr, ptr %8, align 8
  %22 = load i32, ptr %9, align 4
  %23 = sext i32 %22 to i64
  %24 = add i64 %lsr.iv, %23
  %25 = getelementptr i32, ptr %21, i64 %24
  %26 = getelementptr i32, ptr %25, i64 -7
  store i32 0, ptr %26, align 4
  %27 = load ptr, ptr %8, align 8
  %28 = load i32, ptr %9, align 4
  %29 = sext i32 %28 to i64
  %30 = add i64 %lsr.iv, %29
  %31 = getelementptr i32, ptr %27, i64 %30
  %32 = getelementptr i32, ptr %31, i64 -6
  store i32 0, ptr %32, align 4
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = add i64 %lsr.iv, %35
  %37 = getelementptr i32, ptr %33, i64 %36
  %38 = getelementptr i32, ptr %37, i64 -5
  store i32 0, ptr %38, align 4
  %39 = load ptr, ptr %8, align 8
  %40 = load i32, ptr %9, align 4
  %41 = sext i32 %40 to i64
  %42 = add i64 %lsr.iv, %41
  %43 = getelementptr i32, ptr %39, i64 %42
  %44 = getelementptr i32, ptr %43, i64 -4
  store i32 0, ptr %44, align 4
  %45 = load ptr, ptr %8, align 8
  %46 = load i32, ptr %9, align 4
  %47 = sext i32 %46 to i64
  %48 = add i64 %lsr.iv, %47
  %49 = getelementptr i32, ptr %45, i64 %48
  %50 = getelementptr i32, ptr %49, i64 -3
  store i32 0, ptr %50, align 4
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = add i64 %lsr.iv, %53
  %55 = getelementptr i32, ptr %51, i64 %54
  %56 = getelementptr i32, ptr %55, i64 -2
  store i32 0, ptr %56, align 4
  %57 = load ptr, ptr %8, align 8
  %58 = load i32, ptr %9, align 4
  %59 = sext i32 %58 to i64
  %60 = add i64 %lsr.iv, %59
  %61 = getelementptr i32, ptr %57, i64 %60
  %62 = getelementptr i32, ptr %61, i64 -1
  store i32 0, ptr %62, align 4
  %63 = load ptr, ptr %8, align 8
  %64 = load i32, ptr %9, align 4
  %65 = sext i32 %64 to i64
  %66 = add nsw i64 %lsr.iv, %65
  %67 = getelementptr i32, ptr %63, i64 %66
  store i32 0, ptr %67, align 4
  %lsr.iv.next = add i64 %lsr.iv, 8
  %68 = add i64 %19, %lsr.iv.next
  %exitcond.not.7 = icmp eq i64 %68, 7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @tick_geometry_reset_25_kernel_18_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.18, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.998, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.18(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 10, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %10 = xor i64 %9, -1
  %11 = add nsw i64 %10, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %9, %for_loop_body.prol.preheader ]
  %12 = load ptr, ptr %8, align 8
  %13 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep20 = getelementptr i8, ptr %12, i64 %13
  store i32 0, ptr %uglygep20, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !25

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %9, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %14 = icmp ult i64 %11, 7
  br i1 %14, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %for_loop_body ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %15 = load ptr, ptr %8, align 8
  %16 = shl i64 %indvars.iv, 2
  %uglygep17 = getelementptr i8, ptr %15, i64 %16
  store i32 0, ptr %uglygep17, align 4
  %17 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %17, i64 4
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %16
  store i32 0, ptr %uglygep19, align 4
  %18 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %18, i64 8
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %16
  store i32 0, ptr %uglygep16, align 4
  %19 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %19, i64 12
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %16
  store i32 0, ptr %uglygep14, align 4
  %20 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %20, i64 16
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %16
  store i32 0, ptr %uglygep12, align 4
  %21 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %21, i64 20
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %16
  store i32 0, ptr %uglygep10, align 4
  %22 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %22, i64 24
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %16
  store i32 0, ptr %uglygep8, align 4
  %23 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %23, i64 28
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %16
  store i32 0, ptr %uglygep6, align 4
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @tick_geometry_reset_25_kernel_19_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.19, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.998, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.19(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 10, i32 1
  %9 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 10, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv6 = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next7, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = add nsw i64 %indvars.iv.prol, %15
  %17 = getelementptr i32, ptr %13, i64 %16
  store i32 0, ptr %17, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next7 = add nsw i64 %lsr.iv6, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next7, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !26

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %18 = icmp ult i64 %12, 7
  br i1 %18, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  %19 = sub i64 0, %wide.trip.count
  %20 = add nsw i64 %indvars.iv.unr, 7
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %lsr.iv = phi i64 [ %20, %for_loop_body.preheader ], [ %lsr.iv.next, %for_loop_body ]
  %21 = load ptr, ptr %8, align 8
  %22 = load i32, ptr %9, align 4
  %23 = sext i32 %22 to i64
  %24 = add i64 %lsr.iv, %23
  %25 = getelementptr i32, ptr %21, i64 %24
  %26 = getelementptr i32, ptr %25, i64 -7
  store i32 0, ptr %26, align 4
  %27 = load ptr, ptr %8, align 8
  %28 = load i32, ptr %9, align 4
  %29 = sext i32 %28 to i64
  %30 = add i64 %lsr.iv, %29
  %31 = getelementptr i32, ptr %27, i64 %30
  %32 = getelementptr i32, ptr %31, i64 -6
  store i32 0, ptr %32, align 4
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = add i64 %lsr.iv, %35
  %37 = getelementptr i32, ptr %33, i64 %36
  %38 = getelementptr i32, ptr %37, i64 -5
  store i32 0, ptr %38, align 4
  %39 = load ptr, ptr %8, align 8
  %40 = load i32, ptr %9, align 4
  %41 = sext i32 %40 to i64
  %42 = add i64 %lsr.iv, %41
  %43 = getelementptr i32, ptr %39, i64 %42
  %44 = getelementptr i32, ptr %43, i64 -4
  store i32 0, ptr %44, align 4
  %45 = load ptr, ptr %8, align 8
  %46 = load i32, ptr %9, align 4
  %47 = sext i32 %46 to i64
  %48 = add i64 %lsr.iv, %47
  %49 = getelementptr i32, ptr %45, i64 %48
  %50 = getelementptr i32, ptr %49, i64 -3
  store i32 0, ptr %50, align 4
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = add i64 %lsr.iv, %53
  %55 = getelementptr i32, ptr %51, i64 %54
  %56 = getelementptr i32, ptr %55, i64 -2
  store i32 0, ptr %56, align 4
  %57 = load ptr, ptr %8, align 8
  %58 = load i32, ptr %9, align 4
  %59 = sext i32 %58 to i64
  %60 = add i64 %lsr.iv, %59
  %61 = getelementptr i32, ptr %57, i64 %60
  %62 = getelementptr i32, ptr %61, i64 -1
  store i32 0, ptr %62, align 4
  %63 = load ptr, ptr %8, align 8
  %64 = load i32, ptr %9, align 4
  %65 = sext i32 %64 to i64
  %66 = add nsw i64 %lsr.iv, %65
  %67 = getelementptr i32, ptr %63, i64 %66
  store i32 0, ptr %67, align 4
  %lsr.iv.next = add i64 %lsr.iv, 8
  %68 = add i64 %19, %lsr.iv.next
  %exitcond.not.7 = icmp eq i64 %68, 7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @tick_geometry_reset_25_kernel_20_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.20, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.998, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.20(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 16)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 11, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.lr.ph
  %indvars.iv = phi i64 [ %9, %for_loop_body.lr.ph ], [ %indvars.iv.next.7, %for_loop_body ]
  %10 = load ptr, ptr %8, align 8
  %11 = shl i64 %indvars.iv, 3
  %uglygep19 = getelementptr i8, ptr %10, i64 %11
  store i64 0, ptr %uglygep19, align 8
  %12 = load ptr, ptr %8, align 8
  %uglygep17 = getelementptr i8, ptr %12, i64 8
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %11
  store i64 0, ptr %uglygep18, align 8
  %13 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %13, i64 16
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %11
  store i64 0, ptr %uglygep16, align 8
  %14 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %14, i64 24
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %11
  store i64 0, ptr %uglygep14, align 8
  %15 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %15, i64 32
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %11
  store i64 0, ptr %uglygep12, align 8
  %16 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %16, i64 40
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %11
  store i64 0, ptr %uglygep10, align 8
  %17 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %17, i64 48
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %11
  store i64 0, ptr %uglygep8, align 8
  %18 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %18, i64 56
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %11
  store i64 0, ptr %uglygep6, align 8
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @tick_geometry_reset_25_kernel_21_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.21, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.998, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.21(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 4)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 12, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %10 = xor i64 %9, -1
  %11 = add nsw i64 %10, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 4
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %9, %for_loop_body.prol.preheader ]
  %12 = load ptr, ptr %8, align 8
  %13 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep20 = getelementptr i8, ptr %12, i64 %13
  store double 0.000000e+00, ptr %uglygep20, align 8
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !27

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %9, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %14 = icmp ult i64 %11, 7
  br i1 %14, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %for_loop_body ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %15 = load ptr, ptr %8, align 8
  %16 = shl i64 %indvars.iv, 3
  %uglygep17 = getelementptr i8, ptr %15, i64 %16
  store double 0.000000e+00, ptr %uglygep17, align 8
  %17 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %17, i64 8
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %16
  store double 0.000000e+00, ptr %uglygep19, align 8
  %18 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %18, i64 16
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %16
  store double 0.000000e+00, ptr %uglygep16, align 8
  %19 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %19, i64 24
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %16
  store double 0.000000e+00, ptr %uglygep14, align 8
  %20 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %20, i64 32
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %16
  store double 0.000000e+00, ptr %uglygep12, align 8
  %21 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %21, i64 40
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %16
  store double 0.000000e+00, ptr %uglygep10, align 8
  %22 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %22, i64 48
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %16
  store double 0.000000e+00, ptr %uglygep8, align 8
  %23 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %23, i64 56
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %16
  store double 0.000000e+00, ptr %uglygep6, align 8
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_parallel_range_for_task(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #2 {
  %4 = alloca %struct.RuntimeContext.998, align 8
  %.sroa.0.0.copyload = load ptr, ptr %0, align 8
  %.sroa.4.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 8
  %.sroa.4.0.copyload = load ptr, ptr %.sroa.4.0..sroa_idx, align 8
  %.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 16
  %.sroa.5.0.copyload = load ptr, ptr %.sroa.5.0..sroa_idx, align 8
  %.sroa.7.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 24
  %.sroa.7.0.copyload = load ptr, ptr %.sroa.7.0..sroa_idx, align 8
  %.sroa.8.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 32
  %.sroa.8.0.copyload = load i64, ptr %.sroa.8.0..sroa_idx, align 8
  %.sroa.9.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 40
  %.sroa.9.0.copyload = load i32, ptr %.sroa.9.0..sroa_idx, align 8
  %.sroa.12.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 44
  %.sroa.12.0.copyload = load i32, ptr %.sroa.12.0..sroa_idx, align 4
  %.sroa.15.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 48
  %.sroa.15.0.copyload = load i32, ptr %.sroa.15.0..sroa_idx, align 8
  %.sroa.17.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 52
  %.sroa.17.0.copyload = load i32, ptr %.sroa.17.0..sroa_idx, align 4
  %5 = alloca i8, i64 %.sroa.8.0.copyload, align 8
  %.not = icmp eq ptr %.sroa.4.0.copyload, null
  br i1 %.not, label %7, label %6

6:                                                ; preds = %3
  call void %.sroa.4.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #0
  br label %7

7:                                                ; preds = %6, %3
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %4, ptr noundef nonnull align 8 dereferenceable(32) %.sroa.0.0.copyload, i64 32, i1 false)
  %8 = getelementptr inbounds %struct.RuntimeContext.998, ptr %4, i64 0, i32 2
  store i32 %1, ptr %8, align 8
  switch i32 %.sroa.17.0.copyload, label %.loopexit [
    i32 1, label %9
    i32 -1, label %17
  ]

9:                                                ; preds = %7
  %10 = mul nsw i32 %.sroa.15.0.copyload, %2
  %11 = add nsw i32 %10, %.sroa.9.0.copyload
  %12 = add nsw i32 %11, %.sroa.15.0.copyload
  %13 = call i32 @llvm.smin.i32(i32 %.sroa.12.0.copyload, i32 %12)
  %14 = icmp slt i32 %11, %13
  br i1 %14, label %.lr.ph.preheader, label %.loopexit

.lr.ph.preheader:                                 ; preds = %9
  br label %.lr.ph

.lr.ph:                                           ; preds = %.lr.ph, %.lr.ph.preheader
  %.02039 = phi i32 [ %15, %.lr.ph ], [ %11, %.lr.ph.preheader ]
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.02039) #0
  %15 = add nsw i32 %.02039, 1
  %16 = icmp slt i32 %15, %13
  br i1 %16, label %.lr.ph, label %.loopexit.loopexit, !llvm.loop !28

17:                                               ; preds = %7
  %18 = mul nsw i32 %.sroa.15.0.copyload, %2
  %19 = sub nsw i32 %.sroa.12.0.copyload, %18
  %20 = mul nsw i32 %19, %.sroa.15.0.copyload
  %21 = call i32 @llvm.smax.i32(i32 %.sroa.9.0.copyload, i32 %20)
  %.not25.not40 = icmp sgt i32 %19, %21
  br i1 %.not25.not40, label %.lr.ph42.preheader, label %.loopexit

.lr.ph42.preheader:                               ; preds = %17
  br label %.lr.ph42

.lr.ph42:                                         ; preds = %.lr.ph42, %.lr.ph42.preheader
  %.0.in41 = phi i32 [ %.0, %.lr.ph42 ], [ %19, %.lr.ph42.preheader ]
  %.0 = add nsw i32 %.0.in41, -1
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.0) #0
  %.not25.not = icmp sgt i32 %.0, %21
  br i1 %.not25.not, label %.lr.ph42, label %.loopexit.loopexit47, !llvm.loop !30

.loopexit.loopexit:                               ; preds = %.lr.ph
  br label %.loopexit

.loopexit.loopexit47:                             ; preds = %.lr.ph42
  br label %.loopexit

.loopexit:                                        ; preds = %.loopexit.loopexit47, %.loopexit.loopexit, %17, %9, %7
  %.not24 = icmp eq ptr %.sroa.7.0.copyload, null
  br i1 %.not24, label %23, label %22

22:                                               ; preds = %.loopexit
  call void %.sroa.7.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #0
  br label %23

23:                                               ; preds = %22, %.loopexit
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #4

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #5

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #5

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smax.i32(i32, i32) #6

attributes #0 = { nounwind }
attributes #1 = { nofree nosync nounwind }
attributes #2 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #4 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #5 = { argmemonly nocallback nofree nosync nounwind willreturn }
attributes #6 = { nocallback nofree nosync nounwind readnone speculatable willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.unroll.disable"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
!13 = distinct !{!13, !7}
!14 = distinct !{!14, !7}
!15 = distinct !{!15, !7}
!16 = distinct !{!16, !7}
!17 = distinct !{!17, !7}
!18 = distinct !{!18, !7}
!19 = distinct !{!19, !7}
!20 = distinct !{!20, !7}
!21 = distinct !{!21, !7}
!22 = distinct !{!22, !7}
!23 = distinct !{!23, !7}
!24 = distinct !{!24, !7}
!25 = distinct !{!25, !7}
!26 = distinct !{!26, !7}
!27 = distinct !{!27, !7}
!28 = distinct !{!28, !29}
!29 = !{!"llvm.loop.mustprogress"}
!30 = distinct !{!30, !29}
