; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%0 = type { ptr, [2 x i32], %struct.PhysicalCoordinates.762 }
%1 = type { %2, %2 }
%2 = type { [4 x i64], [4 x ptr] }
%struct.RuntimeContext.765 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }
%struct.ListManager = type { [256 x ptr], i64, i64, i32, i32, i32, ptr }
%struct.PhysicalCoordinates.762 = type { [12 x i32] }
%struct.cpu_block_task_helper_context = type { ptr, ptr, ptr, i32, i32, i64 }
%class.anon = type { ptr, ptr, ptr, ptr }

@.str = private unnamed_addr constant [28 x i8] c"Out of pre-allocated memory\00", align 1
@.str.2 = private unnamed_addr constant [28 x i8] c"List manager out of chunks.\00", align 1

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @field_centroid_25_kernel_0_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.765, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 27
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @field_centroid_25_kernel_1_listgen_S27pointer(ptr %context) local_unnamed_addr #1 {
.lr.ph.i:
  %.sroa.2.i = alloca { [2 x i32], %struct.PhysicalCoordinates.762 }, align 8
  %0 = alloca %0, align 8
  %1 = getelementptr inbounds %struct.RuntimeContext.765, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 23
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %4, i64 27
  %8 = load ptr, ptr %7, align 8
  %9 = load atomic i64, ptr %6 acquire, align 8
  %.not.i.i.i.i = icmp ne i64 %9, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i)
  %10 = inttoptr i64 %9 to ptr
  %11 = load atomic i64, ptr %10 acquire, align 8
  %12 = inttoptr i64 %11 to ptr
  %.sroa.0.0.copyload.i = load ptr, ptr %12, align 8
  %.sroa.2.0..sroa_idx.i = getelementptr inbounds i8, ptr %12, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.i, ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.0..sroa_idx.i, i64 56, i1 false)
  %getch.i = getelementptr %1, ptr %.sroa.0.0.copyload.i, i64 0, i32 1
  %13 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %.sroa.2.16.sroa_idx.i = getelementptr inbounds i8, ptr %.sroa.2.i, i64 8
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %16 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 4
  %17 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 6
  %18 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 2
  %19 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  store ptr %getch.i, ptr %0, align 8
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %0, i64 8
  store <2 x i32> <i32 0, i32 4>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %13, ptr noundef nonnull align 8 dereferenceable(48) %.sroa.2.16.sroa_idx.i, i64 48, i1 false)
  %20 = atomicrmw volatile add ptr %14, i32 1 seq_cst, align 4
  %21 = load i32, ptr %15, align 8
  %22 = ashr i32 %20, %21
  %23 = icmp ugt i32 %22, 131071
  br i1 %23, label %24, label %26

24:                                               ; preds = %.lr.ph.i
  %25 = load ptr, ptr %17, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %25, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

26:                                               ; preds = %.lr.ph.i
  %27 = zext i32 %22 to i64
  %28 = lshr i64 %27, 9
  %29 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %28
  %30 = load atomic i64, ptr %29 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %30, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %26
  %31 = inttoptr i64 %30 to ptr
  %32 = and i64 %27, 511
  %33 = getelementptr inbounds ptr, ptr %31, i64 %32
  %34 = load atomic i64, ptr %33 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %26
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %35 = atomicrmw volatile xchg ptr %16, i32 1 seq_cst, align 4
  %36 = icmp eq i32 %35, 1
  br i1 %36, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %37 = load atomic i64, ptr %29 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %37, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %39, label %73

39:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %40 = load ptr, ptr %17, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1
  %42 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 28
  %43 = atomicrmw volatile add ptr %42, i64 4096 seq_cst, align 8
  %44 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 2
  %45 = load i64, ptr %44, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %45, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %66, label %46

46:                                               ; preds = %39
  %47 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 26
  br label %48

48:                                               ; preds = %48, %46
  %49 = atomicrmw volatile xchg ptr %47, i32 1 seq_cst, align 4
  %50 = icmp eq i32 %49, 1
  br i1 %50, label %48, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %48
  %51 = load ptr, ptr %41, align 8
  %52 = ptrtoint ptr %51 to i64
  %53 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 1
  %54 = load ptr, ptr %53, align 8
  %55 = ptrtoint ptr %54 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %52
  %56 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %57 = or i64 %56, 4096
  %58 = add i64 %57, %52
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %58, %55
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %59

59:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %60 = add i64 %56, %52
  %61 = inttoptr i64 %60 to ptr
  %62 = getelementptr i8, ptr %51, i64 %56
  %63 = getelementptr inbounds i8, ptr %62, i64 4096
  store ptr %63, ptr %41, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %59, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %61, %59 ]
  %64 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %65 = atomicrmw volatile xchg ptr %47, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %40, i1 noundef zeroext %64, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

66:                                               ; preds = %39
  %67 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 2
  %68 = load ptr, ptr %67, align 8
  %69 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 6
  %70 = load ptr, ptr %69, align 8
  %71 = tail call noundef ptr %68(ptr noundef %70, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %66, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %71, %66 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %72 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %72, ptr %29 release, align 8
  br label %73

73:                                               ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %38, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %74 = and i32 %22, 511
  %75 = zext i32 %74 to i64
  %76 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %75
  %77 = load atomic i64, ptr %76 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %77, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %78, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

78:                                               ; preds = %73
  %79 = load ptr, ptr %17, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1
  %81 = load i64, ptr %18, align 8
  %82 = load i64, ptr %19, align 8
  %83 = mul i64 %82, %81
  %84 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 28
  %85 = atomicrmw volatile add ptr %84, i64 %83 seq_cst, align 8
  %86 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 2
  %87 = load i64, ptr %86, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %87, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %107, label %88

88:                                               ; preds = %78
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 26
  br label %90

90:                                               ; preds = %90, %88
  %91 = atomicrmw volatile xchg ptr %89, i32 1 seq_cst, align 4
  %92 = icmp eq i32 %91, 1
  br i1 %92, label %90, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %90
  %93 = load ptr, ptr %80, align 8
  %94 = ptrtoint ptr %93 to i64
  %95 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 1
  %96 = load ptr, ptr %95, align 8
  %97 = ptrtoint ptr %96 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %94
  %98 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %99 = add i64 %98, %83
  %100 = add i64 %99, %94
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %100, %97
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %101

101:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %102 = add i64 %98, %94
  %103 = inttoptr i64 %102 to ptr
  %104 = getelementptr inbounds i8, ptr %93, i64 %99
  store ptr %104, ptr %80, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %101, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %103, %101 ]
  %105 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %106 = atomicrmw volatile xchg ptr %89, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %79, i1 noundef zeroext %105, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

107:                                              ; preds = %78
  %108 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 2
  %109 = load ptr, ptr %108, align 8
  %110 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 6
  %111 = load ptr, ptr %110, align 8
  %112 = tail call noundef ptr %109(ptr noundef %111, i64 noundef %83, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %107, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %112, %107 ]
  %113 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %113, ptr %76 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %73
  %114 = atomicrmw volatile xchg ptr %16, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %24
  %115 = load i32, ptr %15, align 8
  %116 = ashr i32 %20, %115
  %117 = sext i32 %116 to i64
  %118 = lshr i64 %117, 9
  %119 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %118
  %120 = load atomic i64, ptr %119 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %120, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %121

121:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %122 = inttoptr i64 %120 to ptr
  %123 = and i64 %117, 511
  %124 = getelementptr inbounds ptr, ptr %122, i64 %123
  %125 = load atomic i64, ptr %124 acquire, align 8
  %126 = inttoptr i64 %125 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %121, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %127 = phi ptr [ %126, %121 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %128 = load i64, ptr %19, align 8
  %129 = load i32, ptr %15, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %129
  %130 = xor i32 %notmask.i.i.i.i, -1
  %131 = and i32 %20, %130
  %132 = sext i32 %131 to i64
  %133 = mul i64 %128, %132
  %134 = getelementptr inbounds i8, ptr %127, i64 %133
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %134, ptr nonnull align 8 %0, i64 %128, i1 false)
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @field_centroid_25_kernel_2_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.765, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 28
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @field_centroid_25_kernel_3_listgen_S28bitmasked(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %0, align 8
  %1 = alloca %struct.PhysicalCoordinates.762, align 4
  %2 = alloca %0, align 8
  %3 = getelementptr inbounds %struct.RuntimeContext.765, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %2)
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 13
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %6, i64 27
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %10 = load i32, ptr %9, align 8
  %11 = getelementptr inbounds ptr, ptr %6, i64 28
  %12 = load ptr, ptr %11, align 8
  %13 = icmp sgt i32 %10, 0
  br i1 %13, label %.lr.ph61.i, label %element_listgen_nonroot.exit

.lr.ph61.i:                                       ; preds = %entry
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  %16 = getelementptr inbounds %0, ptr %0, i64 0, i32 1
  %17 = getelementptr inbounds %0, ptr %0, i64 0, i32 1, i64 1
  %18 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %19 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %20 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 5
  %21 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %22 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 4
  %23 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 6
  %24 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 2
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %2, i64 8
  br label %26

26:                                               ; preds = %._crit_edge.i, %.lr.ph61.i
  %.04359.i = phi i32 [ 0, %.lr.ph61.i ], [ %172, %._crit_edge.i ]
  %27 = load i32, ptr %14, align 8
  %28 = lshr i32 %.04359.i, %27
  %29 = sext i32 %28 to i64
  %30 = lshr i64 %29, 9
  %31 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %30
  %32 = load atomic i64, ptr %31 acquire, align 8
  %.not.i.i.i.i = icmp eq i64 %32, 0
  br i1 %.not.i.i.i.i, label %_ZN11ListManager3getI7ElementEERT_i.exit.i, label %33

33:                                               ; preds = %26
  %34 = inttoptr i64 %32 to ptr
  %35 = and i64 %29, 511
  %36 = getelementptr inbounds ptr, ptr %34, i64 %35
  %37 = load atomic i64, ptr %36 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit.i

_ZN11ListManager3getI7ElementEERT_i.exit.i:       ; preds = %33, %26
  %39 = phi ptr [ %38, %33 ], [ null, %26 ]
  %40 = load i64, ptr %15, align 8
  %41 = load i32, ptr %14, align 8
  %notmask.i.i.i = shl nsw i32 -1, %41
  %42 = xor i32 %notmask.i.i.i, -1
  %43 = and i32 %.04359.i, %42
  %44 = zext i32 %43 to i64
  %45 = mul i64 %40, %44
  %46 = getelementptr inbounds i8, ptr %39, i64 %45
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %0, ptr noundef nonnull align 8 dereferenceable(64) %46, i64 64, i1 false)
  %47 = load i32, ptr %16, align 8
  %48 = load i32, ptr %17, align 4
  %49 = icmp slt i32 %47, %48
  br i1 %49, label %.lr.ph58.i.preheader, label %._crit_edge.i

.lr.ph58.i.preheader:                             ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit.i
  br label %.lr.ph58.i

.lr.ph58.i:                                       ; preds = %.loopexit.i, %.lr.ph58.i.preheader
  %.04457.i = phi i32 [ %171, %.loopexit.i ], [ %47, %.lr.ph58.i.preheader ]
  call fastcc void @S27_refine_coordinates(ptr noundef nonnull %18, ptr noundef nonnull %1, i32 noundef %.04457.i) #1
  %50 = load ptr, ptr %0, align 8
  %51 = shl i32 %.04457.i, 3
  %52 = sext i32 %51 to i64
  %53 = getelementptr i8, ptr %50, i64 %52
  %54 = getelementptr inbounds i8, ptr %53, i64 32
  %55 = load ptr, ptr %54, align 8
  %.not = icmp eq ptr %55, null
  br i1 %.not, label %.loopexit.i, label %.lr.ph.i

.lr.ph.i:                                         ; preds = %.lr.ph58.i
  store ptr %55, ptr %2, align 8
  store <2 x i32> <i32 0, i32 32>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %19, ptr noundef nonnull align 4 dereferenceable(48) %1, i64 48, i1 false)
  %56 = atomicrmw volatile add ptr %20, i32 1 seq_cst, align 4
  %57 = load i32, ptr %21, align 8
  %58 = ashr i32 %56, %57
  %59 = icmp ugt i32 %58, 131071
  br i1 %59, label %60, label %62

60:                                               ; preds = %.lr.ph.i
  %61 = load ptr, ptr %23, align 8
  call fastcc void @taichi_assert_format(ptr noundef %61, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

62:                                               ; preds = %.lr.ph.i
  %63 = zext i32 %58 to i64
  %64 = lshr i64 %63, 9
  %65 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %64
  %66 = load atomic i64, ptr %65 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %66, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %62
  %67 = inttoptr i64 %66 to ptr
  %68 = and i64 %63, 511
  %69 = getelementptr inbounds ptr, ptr %67, i64 %68
  %70 = load atomic i64, ptr %69 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %70, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %62
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %71 = atomicrmw volatile xchg ptr %22, i32 1 seq_cst, align 4
  %72 = icmp eq i32 %71, 1
  br i1 %72, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %73 = load atomic i64, ptr %65 acquire, align 8
  %74 = inttoptr i64 %73 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %73, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %75, label %109

75:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %76 = load ptr, ptr %23, align 8
  %77 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1
  %78 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 28
  %79 = atomicrmw volatile add ptr %78, i64 4096 seq_cst, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 2
  %81 = load i64, ptr %80, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %81, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %102, label %82

82:                                               ; preds = %75
  %83 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 26
  br label %84

84:                                               ; preds = %84, %82
  %85 = atomicrmw volatile xchg ptr %83, i32 1 seq_cst, align 4
  %86 = icmp eq i32 %85, 1
  br i1 %86, label %84, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %84
  %87 = load ptr, ptr %77, align 8
  %88 = ptrtoint ptr %87 to i64
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 1
  %90 = load ptr, ptr %89, align 8
  %91 = ptrtoint ptr %90 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %88
  %92 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %93 = or i64 %92, 4096
  %94 = add i64 %93, %88
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %94, %91
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %95

95:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %96 = add i64 %92, %88
  %97 = inttoptr i64 %96 to ptr
  %98 = getelementptr i8, ptr %87, i64 %92
  %99 = getelementptr inbounds i8, ptr %98, i64 4096
  store ptr %99, ptr %77, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %95, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %97, %95 ]
  %100 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %101 = atomicrmw volatile xchg ptr %83, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %76, i1 noundef zeroext %100, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

102:                                              ; preds = %75
  %103 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 2
  %104 = load ptr, ptr %103, align 8
  %105 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 6
  %106 = load ptr, ptr %105, align 8
  %107 = call noundef ptr %104(ptr noundef %106, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %102, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %107, %102 ]
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %108 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %108, ptr %65 release, align 8
  br label %109

109:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %74, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %110 = and i32 %58, 511
  %111 = zext i32 %110 to i64
  %112 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %111
  %113 = load atomic i64, ptr %112 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %113, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %114, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

114:                                              ; preds = %109
  %115 = load ptr, ptr %23, align 8
  %116 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1
  %117 = load i64, ptr %24, align 8
  %118 = load i64, ptr %25, align 8
  %119 = mul i64 %118, %117
  %120 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 28
  %121 = atomicrmw volatile add ptr %120, i64 %119 seq_cst, align 8
  %122 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 2
  %123 = load i64, ptr %122, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %123, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %143, label %124

124:                                              ; preds = %114
  %125 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 26
  br label %126

126:                                              ; preds = %126, %124
  %127 = atomicrmw volatile xchg ptr %125, i32 1 seq_cst, align 4
  %128 = icmp eq i32 %127, 1
  br i1 %128, label %126, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %126
  %129 = load ptr, ptr %116, align 8
  %130 = ptrtoint ptr %129 to i64
  %131 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 1
  %132 = load ptr, ptr %131, align 8
  %133 = ptrtoint ptr %132 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %130
  %134 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %135 = add i64 %134, %119
  %136 = add i64 %135, %130
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %136, %133
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %137

137:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %138 = add i64 %134, %130
  %139 = inttoptr i64 %138 to ptr
  %140 = getelementptr inbounds i8, ptr %129, i64 %135
  store ptr %140, ptr %116, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %137, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %139, %137 ]
  %141 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %142 = atomicrmw volatile xchg ptr %125, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %115, i1 noundef zeroext %141, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

143:                                              ; preds = %114
  %144 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 2
  %145 = load ptr, ptr %144, align 8
  %146 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 6
  %147 = load ptr, ptr %146, align 8
  %148 = call noundef ptr %145(ptr noundef %147, i64 noundef %119, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %143, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %148, %143 ]
  %149 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %149, ptr %112 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %109
  %150 = atomicrmw volatile xchg ptr %22, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %60
  %151 = load i32, ptr %21, align 8
  %152 = ashr i32 %56, %151
  %153 = sext i32 %152 to i64
  %154 = lshr i64 %153, 9
  %155 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %154
  %156 = load atomic i64, ptr %155 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %156, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %157

157:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %158 = inttoptr i64 %156 to ptr
  %159 = and i64 %153, 511
  %160 = getelementptr inbounds ptr, ptr %158, i64 %159
  %161 = load atomic i64, ptr %160 acquire, align 8
  %162 = inttoptr i64 %161 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %157, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %163 = phi ptr [ %162, %157 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %164 = load i64, ptr %25, align 8
  %165 = load i32, ptr %21, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %165
  %166 = xor i32 %notmask.i.i.i.i, -1
  %167 = and i32 %56, %166
  %168 = sext i32 %167 to i64
  %169 = mul i64 %164, %168
  %170 = getelementptr inbounds i8, ptr %163, i64 %169
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %170, ptr nonnull align 8 %2, i64 %164, i1 false)
  br label %.loopexit.i, !llvm.loop !8

.loopexit.i:                                      ; preds = %_ZN11ListManager6appendEPv.exit.i, %.lr.ph58.i
  %171 = add i32 %.04457.i, 1
  %exitcond.not.i = icmp eq i32 %171, %48
  br i1 %exitcond.not.i, label %._crit_edge.i.loopexit, label %.lr.ph58.i, !llvm.loop !9

._crit_edge.i.loopexit:                           ; preds = %.loopexit.i
  br label %._crit_edge.i

._crit_edge.i:                                    ; preds = %._crit_edge.i.loopexit, %_ZN11ListManager3getI7ElementEERT_i.exit.i
  %172 = add nuw nsw i32 %.04359.i, 1
  %exitcond63.not.i = icmp eq i32 %172, %10
  br i1 %exitcond63.not.i, label %element_listgen_nonroot.exit.loopexit, label %26, !llvm.loop !10

element_listgen_nonroot.exit.loopexit:            ; preds = %._crit_edge.i
  br label %element_listgen_nonroot.exit

element_listgen_nonroot.exit:                     ; preds = %element_listgen_nonroot.exit.loopexit, %entry
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %2)
  ret void
}

; Function Attrs: nounwind
define void @field_centroid_25_kernel_4_struct_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.cpu_block_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.RuntimeContext.765, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 28
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds %struct.ListManager, ptr %6, i64 0, i32 5
  %8 = load i32, ptr %7, align 8
  store ptr %context, ptr %0, align 8
  %9 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  store ptr @function_body, ptr %9, align 8
  %10 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  store ptr %6, ptr %10, align 8
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  store <2 x i32> <i32 32, i32 8>, ptr %11, align 8
  %12 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  store i64 1, ptr %12, align 8
  %13 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 12
  %14 = load ptr, ptr %13, align 8
  %15 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 11
  %16 = load ptr, ptr %15, align 8
  %17 = shl nsw i32 %8, 3
  call void %14(ptr noundef %16, i32 noundef %17, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_struct_for_block_helper) #1
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree norecurse nounwind
define internal void @function_body(ptr %0, ptr nocapture readnone %1, ptr nocapture readonly %2, i32 %3, i32 %4) #2 {
allocs:
  %5 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %6 = icmp slt i32 %3, %4
  br i1 %6, label %loop_body.preheader, label %func_exit

loop_body.preheader:                              ; preds = %allocs
  br label %loop_body

loop_body:                                        ; preds = %loop_body_tail, %loop_body.preheader
  %.01848 = phi i32 [ %17, %loop_body_tail ], [ %3, %loop_body.preheader ]
  %7 = load ptr, ptr %2, align 8
  %8 = getelementptr inbounds i8, ptr %7, i64 32
  %9 = sdiv i32 %.01848, 8
  %10 = sext i32 %9 to i64
  %11 = getelementptr inbounds i8, ptr %8, i64 %10
  %12 = load i8, ptr %11, align 1
  %13 = zext i8 %12 to i32
  %14 = and i32 %.01848, 7
  %15 = shl nuw nsw i32 1, %14
  %16 = and i32 %15, %13
  %.not = icmp eq i32 %16, 0
  br i1 %.not, label %loop_body_tail, label %struct_for_body_body

loop_body_tail:                                   ; preds = %after_for, %loop_body
  %17 = add nsw i32 %.01848, 1
  %exitcond53.not = icmp eq i32 %17, %4
  br i1 %exitcond53.not, label %func_exit.loopexit, label %loop_body

func_exit.loopexit:                               ; preds = %loop_body_tail
  br label %func_exit

func_exit:                                        ; preds = %func_exit.loopexit, %allocs
  ret void

struct_for_body_body:                             ; preds = %loop_body
  %18 = load i32, ptr %5, align 4
  %19 = shl i32 %18, 5
  %20 = and i32 %.01848, 31
  %21 = or i32 %19, %20
  %22 = load ptr, ptr %0, align 8
  %23 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %22, i64 0, i32 3, i32 1
  %24 = load ptr, ptr %23, align 8
  %25 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %22, i64 0, i32 3, i32 0, i32 1
  %26 = load i32, ptr %25, align 4
  %27 = sext i32 %26 to i64
  %28 = shl nsw i64 %27, 2
  %29 = sext i32 %21 to i64
  %30 = add nsw i64 %28, %29
  %31 = getelementptr double, ptr %24, i64 %30
  %32 = mul nsw i64 %27, 5
  %33 = add nsw i64 %32, %29
  %34 = getelementptr double, ptr %24, i64 %33
  %35 = mul nsw i64 %27, 6
  %36 = add nsw i64 %35, %29
  %37 = getelementptr double, ptr %24, i64 %36
  %38 = mul nsw i64 %27, 7
  %39 = add nsw i64 %38, %29
  %40 = getelementptr double, ptr %24, i64 %39
  %41 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %22, i64 0, i32 7, i32 1
  %42 = load ptr, ptr %41, align 8
  %43 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %22, i64 0, i32 7, i32 0, i32 1
  %44 = getelementptr double, ptr %42, i64 %29
  store double 0.000000e+00, ptr %44, align 8
  %45 = load ptr, ptr %41, align 8
  %46 = load i32, ptr %43, align 4
  %47 = sext i32 %46 to i64
  %48 = add nsw i64 %47, %29
  %49 = getelementptr double, ptr %45, i64 %48
  store double 0.000000e+00, ptr %49, align 8
  %50 = load ptr, ptr %41, align 8
  %51 = load i32, ptr %43, align 4
  %52 = sext i32 %51 to i64
  %53 = shl nsw i64 %52, 1
  %54 = add nsw i64 %53, %29
  %55 = getelementptr double, ptr %50, i64 %54
  store double 0.000000e+00, ptr %55, align 8
  %56 = load ptr, ptr %0, align 8
  %57 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %56, i64 0, i32 10, i32 1
  %58 = load ptr, ptr %57, align 8
  %59 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %56, i64 0, i32 10, i32 0, i32 1
  %60 = load i32, ptr %59, align 4
  %61 = sext i32 %60 to i64
  %62 = getelementptr i32, ptr %58, i64 %29
  %63 = load i32, ptr %62, align 4
  %64 = add nsw i64 %61, %29
  %65 = getelementptr i32, ptr %58, i64 %64
  %66 = load i32, ptr %65, align 4
  %67 = icmp slt i32 %63, %66
  br i1 %67, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %struct_for_body_body
  %68 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %56, i64 0, i32 11, i32 1
  %69 = load ptr, ptr %68, align 8
  %70 = sext i32 %63 to i64
  %71 = getelementptr i32, ptr %69, i64 %70
  %72 = load i32, ptr %71, align 4
  %73 = getelementptr { { i32, i32 }, ptr }, ptr %56, i64 0, i32 1
  %74 = load ptr, ptr %73, align 8
  %75 = sext i32 %72 to i64
  %76 = getelementptr i32, ptr %74, i64 %75
  %77 = load i32, ptr %76, align 4
  %78 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %56, i64 0, i32 2, i32 1
  %79 = load ptr, ptr %78, align 8
  %80 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %56, i64 0, i32 2, i32 0, i32 1
  %81 = sext i32 %77 to i64
  %82 = getelementptr double, ptr %79, i64 %81
  %83 = load double, ptr %82, align 8
  store double %83, ptr %44, align 8
  %84 = load ptr, ptr %78, align 8
  %85 = load i32, ptr %80, align 4
  %86 = sext i32 %85 to i64
  %87 = add nsw i64 %86, %81
  %88 = getelementptr double, ptr %84, i64 %87
  %89 = load double, ptr %88, align 8
  store double %89, ptr %49, align 8
  %90 = load ptr, ptr %78, align 8
  %91 = load i32, ptr %80, align 4
  %92 = sext i32 %91 to i64
  %93 = shl nsw i64 %92, 1
  %94 = add nsw i64 %93, %81
  %95 = getelementptr double, ptr %90, i64 %94
  %96 = load double, ptr %95, align 8
  store double %96, ptr %55, align 8
  %.pre = load ptr, ptr %0, align 8
  %97 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %.pre, i64 0, i32 8, i32 1
  %98 = load ptr, ptr %97, align 8
  %99 = getelementptr i64, ptr %98, i64 12
  %100 = load double, ptr %44, align 8
  %101 = load double, ptr %49, align 8
  %102 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %.pre, i64 0, i32 11, i32 1
  %103 = getelementptr { { i32, i32 }, ptr }, ptr %.pre, i64 0, i32 1
  %104 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %.pre, i64 0, i32 12, i32 1
  %105 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %.pre, i64 0, i32 2, i32 1
  %106 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %.pre, i64 0, i32 2, i32 0, i32 1
  %wide.trip.count = sext i32 %66 to i64
  %107 = sub nsw i64 %wide.trip.count, %70
  %108 = xor i64 %70, -1
  %109 = add nsw i64 %108, %wide.trip.count
  %xtraiter = and i64 %107, 7
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if3.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if3.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if3.prol ], [ %70, %for_loop_body.prol.preheader ]
  %.01443.prol = phi double [ %160, %after_if3.prol ], [ 0.000000e+00, %for_loop_body.prol.preheader ]
  %.01542.prol = phi double [ %159, %after_if3.prol ], [ 0.000000e+00, %for_loop_body.prol.preheader ]
  %.01641.prol = phi double [ %152, %after_if3.prol ], [ 0.000000e+00, %for_loop_body.prol.preheader ]
  %.01740.prol = phi double [ %146, %after_if3.prol ], [ 0.000000e+00, %for_loop_body.prol.preheader ]
  %110 = load ptr, ptr %102, align 8
  %111 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep = getelementptr i8, ptr %110, i64 %111
  %112 = load i32, ptr %uglygep, align 4
  %113 = load ptr, ptr %103, align 8
  %114 = sext i32 %112 to i64
  %115 = getelementptr i32, ptr %113, i64 %114
  %116 = load i32, ptr %115, align 4
  %117 = load ptr, ptr %104, align 8
  %118 = getelementptr i64, ptr %117, i64 %114
  %119 = load i64, ptr %118, align 8
  %120 = uitofp i64 %119 to double
  %121 = add i32 %112, 512
  %122 = sext i32 %121 to i64
  %123 = getelementptr i64, ptr %117, i64 %122
  %124 = load i64, ptr %123, align 8
  %125 = uitofp i64 %124 to double
  %126 = fdiv double %120, %125
  %127 = atomicrmw add ptr %99, i64 1 seq_cst, align 8
  %128 = load ptr, ptr %105, align 8
  %129 = load i32, ptr %106, align 4
  %130 = sext i32 %129 to i64
  %131 = mul nsw i64 %130, 6
  %132 = sext i32 %116 to i64
  %133 = add nsw i64 %131, %132
  %134 = getelementptr double, ptr %128, i64 %133
  %135 = load double, ptr %134, align 8
  %136 = fmul double %126, %135
  %137 = fcmp ugt double %136, 0.000000e+00
  br i1 %137, label %after_if3.prol, label %true_block1.prol

true_block1.prol:                                 ; preds = %for_loop_body.prol
  %138 = load ptr, ptr %97, align 8
  %139 = getelementptr i64, ptr %138, i64 19
  %140 = atomicrmw add ptr %139, i64 1 seq_cst, align 8
  %.pre54.prol = load ptr, ptr %105, align 8
  %.pre55.prol = load i32, ptr %106, align 4
  %.pre56.prol = sext i32 %.pre55.prol to i64
  br label %after_if3.prol

after_if3.prol:                                   ; preds = %true_block1.prol, %for_loop_body.prol
  %.pre-phi.prol = phi i64 [ %130, %for_loop_body.prol ], [ %.pre56.prol, %true_block1.prol ]
  %141 = phi ptr [ %128, %for_loop_body.prol ], [ %.pre54.prol, %true_block1.prol ]
  %142 = getelementptr double, ptr %141, i64 %132
  %143 = load double, ptr %142, align 8
  %144 = fsub double %143, %100
  %145 = fmul double %136, %144
  %146 = fadd double %.01740.prol, %145
  %147 = add nsw i64 %.pre-phi.prol, %132
  %148 = getelementptr double, ptr %141, i64 %147
  %149 = load double, ptr %148, align 8
  %150 = fsub double %149, %101
  %151 = fmul double %136, %150
  %152 = fadd double %.01641.prol, %151
  %153 = shl nsw i64 %.pre-phi.prol, 1
  %154 = add nsw i64 %153, %132
  %155 = getelementptr double, ptr %141, i64 %154
  %156 = load double, ptr %155, align 8
  %157 = fsub double %156, %96
  %158 = fmul double %136, %157
  %159 = fadd double %.01542.prol, %158
  %160 = fadd double %.01443.prol, %136
  %indvars.iv.next.prol = add nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !11

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if3.prol
  %161 = add i64 %70, %xtraiter
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %.lcssa65.unr = phi double [ undef, %for_loop_body.lr.ph ], [ %146, %for_loop_body.prol.loopexit.loopexit ]
  %.lcssa64.unr = phi double [ undef, %for_loop_body.lr.ph ], [ %152, %for_loop_body.prol.loopexit.loopexit ]
  %.lcssa63.unr = phi double [ undef, %for_loop_body.lr.ph ], [ %159, %for_loop_body.prol.loopexit.loopexit ]
  %.lcssa.unr = phi double [ undef, %for_loop_body.lr.ph ], [ %160, %for_loop_body.prol.loopexit.loopexit ]
  %indvars.iv.unr = phi i64 [ %70, %for_loop_body.lr.ph ], [ %161, %for_loop_body.prol.loopexit.loopexit ]
  %.01443.unr = phi double [ 0.000000e+00, %for_loop_body.lr.ph ], [ %160, %for_loop_body.prol.loopexit.loopexit ]
  %.01542.unr = phi double [ 0.000000e+00, %for_loop_body.lr.ph ], [ %159, %for_loop_body.prol.loopexit.loopexit ]
  %.01641.unr = phi double [ 0.000000e+00, %for_loop_body.lr.ph ], [ %152, %for_loop_body.prol.loopexit.loopexit ]
  %.01740.unr = phi double [ 0.000000e+00, %for_loop_body.lr.ph ], [ %146, %for_loop_body.prol.loopexit.loopexit ]
  %162 = icmp ult i64 %109, 7
  br i1 %162, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if3.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if3.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %.01443 = phi double [ %563, %after_if3.7 ], [ %.01443.unr, %for_loop_body.preheader ]
  %.01542 = phi double [ %562, %after_if3.7 ], [ %.01542.unr, %for_loop_body.preheader ]
  %.01641 = phi double [ %555, %after_if3.7 ], [ %.01641.unr, %for_loop_body.preheader ]
  %.01740 = phi double [ %549, %after_if3.7 ], [ %.01740.unr, %for_loop_body.preheader ]
  %163 = load ptr, ptr %102, align 8
  %164 = shl i64 %indvars.iv, 2
  %uglygep86 = getelementptr i8, ptr %163, i64 %164
  %165 = load i32, ptr %uglygep86, align 4
  %166 = load ptr, ptr %103, align 8
  %167 = sext i32 %165 to i64
  %168 = getelementptr i32, ptr %166, i64 %167
  %169 = load i32, ptr %168, align 4
  %170 = load ptr, ptr %104, align 8
  %171 = getelementptr i64, ptr %170, i64 %167
  %172 = load i64, ptr %171, align 8
  %173 = uitofp i64 %172 to double
  %174 = add i32 %165, 512
  %175 = sext i32 %174 to i64
  %176 = getelementptr i64, ptr %170, i64 %175
  %177 = load i64, ptr %176, align 8
  %178 = uitofp i64 %177 to double
  %179 = fdiv double %173, %178
  %180 = atomicrmw add ptr %99, i64 1 seq_cst, align 8
  %181 = load ptr, ptr %105, align 8
  %182 = load i32, ptr %106, align 4
  %183 = sext i32 %182 to i64
  %184 = mul nsw i64 %183, 6
  %185 = sext i32 %169 to i64
  %186 = add nsw i64 %184, %185
  %187 = getelementptr double, ptr %181, i64 %186
  %188 = load double, ptr %187, align 8
  %189 = fmul double %179, %188
  %190 = fcmp ugt double %189, 0.000000e+00
  br i1 %190, label %after_if3, label %true_block1

after_for.loopexit:                               ; preds = %after_if3.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %struct_for_body_body
  %.017.lcssa = phi double [ 0.000000e+00, %struct_for_body_body ], [ %.lcssa65.unr, %for_loop_body.prol.loopexit ], [ %549, %after_for.loopexit ]
  %.016.lcssa = phi double [ 0.000000e+00, %struct_for_body_body ], [ %.lcssa64.unr, %for_loop_body.prol.loopexit ], [ %555, %after_for.loopexit ]
  %.015.lcssa = phi double [ 0.000000e+00, %struct_for_body_body ], [ %.lcssa63.unr, %for_loop_body.prol.loopexit ], [ %562, %after_for.loopexit ]
  %.014.lcssa = phi double [ 0.000000e+00, %struct_for_body_body ], [ %.lcssa.unr, %for_loop_body.prol.loopexit ], [ %563, %after_for.loopexit ]
  store double %.014.lcssa, ptr %40, align 8
  store double %.015.lcssa, ptr %37, align 8
  store double %.016.lcssa, ptr %34, align 8
  store double %.017.lcssa, ptr %31, align 8
  br label %loop_body_tail

true_block1:                                      ; preds = %for_loop_body
  %191 = load ptr, ptr %97, align 8
  %192 = getelementptr i64, ptr %191, i64 19
  %193 = atomicrmw add ptr %192, i64 1 seq_cst, align 8
  %.pre54 = load ptr, ptr %105, align 8
  %.pre55 = load i32, ptr %106, align 4
  %.pre56 = sext i32 %.pre55 to i64
  br label %after_if3

after_if3:                                        ; preds = %true_block1, %for_loop_body
  %.pre-phi = phi i64 [ %183, %for_loop_body ], [ %.pre56, %true_block1 ]
  %194 = phi ptr [ %181, %for_loop_body ], [ %.pre54, %true_block1 ]
  %195 = getelementptr double, ptr %194, i64 %185
  %196 = load double, ptr %195, align 8
  %197 = fsub double %196, %100
  %198 = fmul double %189, %197
  %199 = fadd double %.01740, %198
  %200 = add nsw i64 %.pre-phi, %185
  %201 = getelementptr double, ptr %194, i64 %200
  %202 = load double, ptr %201, align 8
  %203 = fsub double %202, %101
  %204 = fmul double %189, %203
  %205 = fadd double %.01641, %204
  %206 = shl nsw i64 %.pre-phi, 1
  %207 = add nsw i64 %206, %185
  %208 = getelementptr double, ptr %194, i64 %207
  %209 = load double, ptr %208, align 8
  %210 = fsub double %209, %96
  %211 = fmul double %189, %210
  %212 = fadd double %.01542, %211
  %213 = fadd double %.01443, %189
  %214 = load ptr, ptr %102, align 8
  %uglygep87 = getelementptr i8, ptr %214, i64 4
  %uglygep88 = getelementptr i8, ptr %uglygep87, i64 %164
  %215 = load i32, ptr %uglygep88, align 4
  %216 = load ptr, ptr %103, align 8
  %217 = sext i32 %215 to i64
  %218 = getelementptr i32, ptr %216, i64 %217
  %219 = load i32, ptr %218, align 4
  %220 = load ptr, ptr %104, align 8
  %221 = getelementptr i64, ptr %220, i64 %217
  %222 = load i64, ptr %221, align 8
  %223 = uitofp i64 %222 to double
  %224 = add i32 %215, 512
  %225 = sext i32 %224 to i64
  %226 = getelementptr i64, ptr %220, i64 %225
  %227 = load i64, ptr %226, align 8
  %228 = uitofp i64 %227 to double
  %229 = fdiv double %223, %228
  %230 = atomicrmw add ptr %99, i64 1 seq_cst, align 8
  %231 = load ptr, ptr %105, align 8
  %232 = load i32, ptr %106, align 4
  %233 = sext i32 %232 to i64
  %234 = mul nsw i64 %233, 6
  %235 = sext i32 %219 to i64
  %236 = add nsw i64 %234, %235
  %237 = getelementptr double, ptr %231, i64 %236
  %238 = load double, ptr %237, align 8
  %239 = fmul double %229, %238
  %240 = fcmp ugt double %239, 0.000000e+00
  br i1 %240, label %after_if3.1, label %true_block1.1

true_block1.1:                                    ; preds = %after_if3
  %241 = load ptr, ptr %97, align 8
  %242 = getelementptr i64, ptr %241, i64 19
  %243 = atomicrmw add ptr %242, i64 1 seq_cst, align 8
  %.pre54.1 = load ptr, ptr %105, align 8
  %.pre55.1 = load i32, ptr %106, align 4
  %.pre56.1 = sext i32 %.pre55.1 to i64
  br label %after_if3.1

after_if3.1:                                      ; preds = %true_block1.1, %after_if3
  %.pre-phi.1 = phi i64 [ %233, %after_if3 ], [ %.pre56.1, %true_block1.1 ]
  %244 = phi ptr [ %231, %after_if3 ], [ %.pre54.1, %true_block1.1 ]
  %245 = getelementptr double, ptr %244, i64 %235
  %246 = load double, ptr %245, align 8
  %247 = fsub double %246, %100
  %248 = fmul double %239, %247
  %249 = fadd double %199, %248
  %250 = add nsw i64 %.pre-phi.1, %235
  %251 = getelementptr double, ptr %244, i64 %250
  %252 = load double, ptr %251, align 8
  %253 = fsub double %252, %101
  %254 = fmul double %239, %253
  %255 = fadd double %205, %254
  %256 = shl nsw i64 %.pre-phi.1, 1
  %257 = add nsw i64 %256, %235
  %258 = getelementptr double, ptr %244, i64 %257
  %259 = load double, ptr %258, align 8
  %260 = fsub double %259, %96
  %261 = fmul double %239, %260
  %262 = fadd double %212, %261
  %263 = fadd double %213, %239
  %264 = load ptr, ptr %102, align 8
  %uglygep84 = getelementptr i8, ptr %264, i64 8
  %uglygep85 = getelementptr i8, ptr %uglygep84, i64 %164
  %265 = load i32, ptr %uglygep85, align 4
  %266 = load ptr, ptr %103, align 8
  %267 = sext i32 %265 to i64
  %268 = getelementptr i32, ptr %266, i64 %267
  %269 = load i32, ptr %268, align 4
  %270 = load ptr, ptr %104, align 8
  %271 = getelementptr i64, ptr %270, i64 %267
  %272 = load i64, ptr %271, align 8
  %273 = uitofp i64 %272 to double
  %274 = add i32 %265, 512
  %275 = sext i32 %274 to i64
  %276 = getelementptr i64, ptr %270, i64 %275
  %277 = load i64, ptr %276, align 8
  %278 = uitofp i64 %277 to double
  %279 = fdiv double %273, %278
  %280 = atomicrmw add ptr %99, i64 1 seq_cst, align 8
  %281 = load ptr, ptr %105, align 8
  %282 = load i32, ptr %106, align 4
  %283 = sext i32 %282 to i64
  %284 = mul nsw i64 %283, 6
  %285 = sext i32 %269 to i64
  %286 = add nsw i64 %284, %285
  %287 = getelementptr double, ptr %281, i64 %286
  %288 = load double, ptr %287, align 8
  %289 = fmul double %279, %288
  %290 = fcmp ugt double %289, 0.000000e+00
  br i1 %290, label %after_if3.2, label %true_block1.2

true_block1.2:                                    ; preds = %after_if3.1
  %291 = load ptr, ptr %97, align 8
  %292 = getelementptr i64, ptr %291, i64 19
  %293 = atomicrmw add ptr %292, i64 1 seq_cst, align 8
  %.pre54.2 = load ptr, ptr %105, align 8
  %.pre55.2 = load i32, ptr %106, align 4
  %.pre56.2 = sext i32 %.pre55.2 to i64
  br label %after_if3.2

after_if3.2:                                      ; preds = %true_block1.2, %after_if3.1
  %.pre-phi.2 = phi i64 [ %283, %after_if3.1 ], [ %.pre56.2, %true_block1.2 ]
  %294 = phi ptr [ %281, %after_if3.1 ], [ %.pre54.2, %true_block1.2 ]
  %295 = getelementptr double, ptr %294, i64 %285
  %296 = load double, ptr %295, align 8
  %297 = fsub double %296, %100
  %298 = fmul double %289, %297
  %299 = fadd double %249, %298
  %300 = add nsw i64 %.pre-phi.2, %285
  %301 = getelementptr double, ptr %294, i64 %300
  %302 = load double, ptr %301, align 8
  %303 = fsub double %302, %101
  %304 = fmul double %289, %303
  %305 = fadd double %255, %304
  %306 = shl nsw i64 %.pre-phi.2, 1
  %307 = add nsw i64 %306, %285
  %308 = getelementptr double, ptr %294, i64 %307
  %309 = load double, ptr %308, align 8
  %310 = fsub double %309, %96
  %311 = fmul double %289, %310
  %312 = fadd double %262, %311
  %313 = fadd double %263, %289
  %314 = load ptr, ptr %102, align 8
  %uglygep82 = getelementptr i8, ptr %314, i64 12
  %uglygep83 = getelementptr i8, ptr %uglygep82, i64 %164
  %315 = load i32, ptr %uglygep83, align 4
  %316 = load ptr, ptr %103, align 8
  %317 = sext i32 %315 to i64
  %318 = getelementptr i32, ptr %316, i64 %317
  %319 = load i32, ptr %318, align 4
  %320 = load ptr, ptr %104, align 8
  %321 = getelementptr i64, ptr %320, i64 %317
  %322 = load i64, ptr %321, align 8
  %323 = uitofp i64 %322 to double
  %324 = add i32 %315, 512
  %325 = sext i32 %324 to i64
  %326 = getelementptr i64, ptr %320, i64 %325
  %327 = load i64, ptr %326, align 8
  %328 = uitofp i64 %327 to double
  %329 = fdiv double %323, %328
  %330 = atomicrmw add ptr %99, i64 1 seq_cst, align 8
  %331 = load ptr, ptr %105, align 8
  %332 = load i32, ptr %106, align 4
  %333 = sext i32 %332 to i64
  %334 = mul nsw i64 %333, 6
  %335 = sext i32 %319 to i64
  %336 = add nsw i64 %334, %335
  %337 = getelementptr double, ptr %331, i64 %336
  %338 = load double, ptr %337, align 8
  %339 = fmul double %329, %338
  %340 = fcmp ugt double %339, 0.000000e+00
  br i1 %340, label %after_if3.3, label %true_block1.3

true_block1.3:                                    ; preds = %after_if3.2
  %341 = load ptr, ptr %97, align 8
  %342 = getelementptr i64, ptr %341, i64 19
  %343 = atomicrmw add ptr %342, i64 1 seq_cst, align 8
  %.pre54.3 = load ptr, ptr %105, align 8
  %.pre55.3 = load i32, ptr %106, align 4
  %.pre56.3 = sext i32 %.pre55.3 to i64
  br label %after_if3.3

after_if3.3:                                      ; preds = %true_block1.3, %after_if3.2
  %.pre-phi.3 = phi i64 [ %333, %after_if3.2 ], [ %.pre56.3, %true_block1.3 ]
  %344 = phi ptr [ %331, %after_if3.2 ], [ %.pre54.3, %true_block1.3 ]
  %345 = getelementptr double, ptr %344, i64 %335
  %346 = load double, ptr %345, align 8
  %347 = fsub double %346, %100
  %348 = fmul double %339, %347
  %349 = fadd double %299, %348
  %350 = add nsw i64 %.pre-phi.3, %335
  %351 = getelementptr double, ptr %344, i64 %350
  %352 = load double, ptr %351, align 8
  %353 = fsub double %352, %101
  %354 = fmul double %339, %353
  %355 = fadd double %305, %354
  %356 = shl nsw i64 %.pre-phi.3, 1
  %357 = add nsw i64 %356, %335
  %358 = getelementptr double, ptr %344, i64 %357
  %359 = load double, ptr %358, align 8
  %360 = fsub double %359, %96
  %361 = fmul double %339, %360
  %362 = fadd double %312, %361
  %363 = fadd double %313, %339
  %364 = load ptr, ptr %102, align 8
  %uglygep80 = getelementptr i8, ptr %364, i64 16
  %uglygep81 = getelementptr i8, ptr %uglygep80, i64 %164
  %365 = load i32, ptr %uglygep81, align 4
  %366 = load ptr, ptr %103, align 8
  %367 = sext i32 %365 to i64
  %368 = getelementptr i32, ptr %366, i64 %367
  %369 = load i32, ptr %368, align 4
  %370 = load ptr, ptr %104, align 8
  %371 = getelementptr i64, ptr %370, i64 %367
  %372 = load i64, ptr %371, align 8
  %373 = uitofp i64 %372 to double
  %374 = add i32 %365, 512
  %375 = sext i32 %374 to i64
  %376 = getelementptr i64, ptr %370, i64 %375
  %377 = load i64, ptr %376, align 8
  %378 = uitofp i64 %377 to double
  %379 = fdiv double %373, %378
  %380 = atomicrmw add ptr %99, i64 1 seq_cst, align 8
  %381 = load ptr, ptr %105, align 8
  %382 = load i32, ptr %106, align 4
  %383 = sext i32 %382 to i64
  %384 = mul nsw i64 %383, 6
  %385 = sext i32 %369 to i64
  %386 = add nsw i64 %384, %385
  %387 = getelementptr double, ptr %381, i64 %386
  %388 = load double, ptr %387, align 8
  %389 = fmul double %379, %388
  %390 = fcmp ugt double %389, 0.000000e+00
  br i1 %390, label %after_if3.4, label %true_block1.4

true_block1.4:                                    ; preds = %after_if3.3
  %391 = load ptr, ptr %97, align 8
  %392 = getelementptr i64, ptr %391, i64 19
  %393 = atomicrmw add ptr %392, i64 1 seq_cst, align 8
  %.pre54.4 = load ptr, ptr %105, align 8
  %.pre55.4 = load i32, ptr %106, align 4
  %.pre56.4 = sext i32 %.pre55.4 to i64
  br label %after_if3.4

after_if3.4:                                      ; preds = %true_block1.4, %after_if3.3
  %.pre-phi.4 = phi i64 [ %383, %after_if3.3 ], [ %.pre56.4, %true_block1.4 ]
  %394 = phi ptr [ %381, %after_if3.3 ], [ %.pre54.4, %true_block1.4 ]
  %395 = getelementptr double, ptr %394, i64 %385
  %396 = load double, ptr %395, align 8
  %397 = fsub double %396, %100
  %398 = fmul double %389, %397
  %399 = fadd double %349, %398
  %400 = add nsw i64 %.pre-phi.4, %385
  %401 = getelementptr double, ptr %394, i64 %400
  %402 = load double, ptr %401, align 8
  %403 = fsub double %402, %101
  %404 = fmul double %389, %403
  %405 = fadd double %355, %404
  %406 = shl nsw i64 %.pre-phi.4, 1
  %407 = add nsw i64 %406, %385
  %408 = getelementptr double, ptr %394, i64 %407
  %409 = load double, ptr %408, align 8
  %410 = fsub double %409, %96
  %411 = fmul double %389, %410
  %412 = fadd double %362, %411
  %413 = fadd double %363, %389
  %414 = load ptr, ptr %102, align 8
  %uglygep78 = getelementptr i8, ptr %414, i64 20
  %uglygep79 = getelementptr i8, ptr %uglygep78, i64 %164
  %415 = load i32, ptr %uglygep79, align 4
  %416 = load ptr, ptr %103, align 8
  %417 = sext i32 %415 to i64
  %418 = getelementptr i32, ptr %416, i64 %417
  %419 = load i32, ptr %418, align 4
  %420 = load ptr, ptr %104, align 8
  %421 = getelementptr i64, ptr %420, i64 %417
  %422 = load i64, ptr %421, align 8
  %423 = uitofp i64 %422 to double
  %424 = add i32 %415, 512
  %425 = sext i32 %424 to i64
  %426 = getelementptr i64, ptr %420, i64 %425
  %427 = load i64, ptr %426, align 8
  %428 = uitofp i64 %427 to double
  %429 = fdiv double %423, %428
  %430 = atomicrmw add ptr %99, i64 1 seq_cst, align 8
  %431 = load ptr, ptr %105, align 8
  %432 = load i32, ptr %106, align 4
  %433 = sext i32 %432 to i64
  %434 = mul nsw i64 %433, 6
  %435 = sext i32 %419 to i64
  %436 = add nsw i64 %434, %435
  %437 = getelementptr double, ptr %431, i64 %436
  %438 = load double, ptr %437, align 8
  %439 = fmul double %429, %438
  %440 = fcmp ugt double %439, 0.000000e+00
  br i1 %440, label %after_if3.5, label %true_block1.5

true_block1.5:                                    ; preds = %after_if3.4
  %441 = load ptr, ptr %97, align 8
  %442 = getelementptr i64, ptr %441, i64 19
  %443 = atomicrmw add ptr %442, i64 1 seq_cst, align 8
  %.pre54.5 = load ptr, ptr %105, align 8
  %.pre55.5 = load i32, ptr %106, align 4
  %.pre56.5 = sext i32 %.pre55.5 to i64
  br label %after_if3.5

after_if3.5:                                      ; preds = %true_block1.5, %after_if3.4
  %.pre-phi.5 = phi i64 [ %433, %after_if3.4 ], [ %.pre56.5, %true_block1.5 ]
  %444 = phi ptr [ %431, %after_if3.4 ], [ %.pre54.5, %true_block1.5 ]
  %445 = getelementptr double, ptr %444, i64 %435
  %446 = load double, ptr %445, align 8
  %447 = fsub double %446, %100
  %448 = fmul double %439, %447
  %449 = fadd double %399, %448
  %450 = add nsw i64 %.pre-phi.5, %435
  %451 = getelementptr double, ptr %444, i64 %450
  %452 = load double, ptr %451, align 8
  %453 = fsub double %452, %101
  %454 = fmul double %439, %453
  %455 = fadd double %405, %454
  %456 = shl nsw i64 %.pre-phi.5, 1
  %457 = add nsw i64 %456, %435
  %458 = getelementptr double, ptr %444, i64 %457
  %459 = load double, ptr %458, align 8
  %460 = fsub double %459, %96
  %461 = fmul double %439, %460
  %462 = fadd double %412, %461
  %463 = fadd double %413, %439
  %464 = load ptr, ptr %102, align 8
  %uglygep76 = getelementptr i8, ptr %464, i64 24
  %uglygep77 = getelementptr i8, ptr %uglygep76, i64 %164
  %465 = load i32, ptr %uglygep77, align 4
  %466 = load ptr, ptr %103, align 8
  %467 = sext i32 %465 to i64
  %468 = getelementptr i32, ptr %466, i64 %467
  %469 = load i32, ptr %468, align 4
  %470 = load ptr, ptr %104, align 8
  %471 = getelementptr i64, ptr %470, i64 %467
  %472 = load i64, ptr %471, align 8
  %473 = uitofp i64 %472 to double
  %474 = add i32 %465, 512
  %475 = sext i32 %474 to i64
  %476 = getelementptr i64, ptr %470, i64 %475
  %477 = load i64, ptr %476, align 8
  %478 = uitofp i64 %477 to double
  %479 = fdiv double %473, %478
  %480 = atomicrmw add ptr %99, i64 1 seq_cst, align 8
  %481 = load ptr, ptr %105, align 8
  %482 = load i32, ptr %106, align 4
  %483 = sext i32 %482 to i64
  %484 = mul nsw i64 %483, 6
  %485 = sext i32 %469 to i64
  %486 = add nsw i64 %484, %485
  %487 = getelementptr double, ptr %481, i64 %486
  %488 = load double, ptr %487, align 8
  %489 = fmul double %479, %488
  %490 = fcmp ugt double %489, 0.000000e+00
  br i1 %490, label %after_if3.6, label %true_block1.6

true_block1.6:                                    ; preds = %after_if3.5
  %491 = load ptr, ptr %97, align 8
  %492 = getelementptr i64, ptr %491, i64 19
  %493 = atomicrmw add ptr %492, i64 1 seq_cst, align 8
  %.pre54.6 = load ptr, ptr %105, align 8
  %.pre55.6 = load i32, ptr %106, align 4
  %.pre56.6 = sext i32 %.pre55.6 to i64
  br label %after_if3.6

after_if3.6:                                      ; preds = %true_block1.6, %after_if3.5
  %.pre-phi.6 = phi i64 [ %483, %after_if3.5 ], [ %.pre56.6, %true_block1.6 ]
  %494 = phi ptr [ %481, %after_if3.5 ], [ %.pre54.6, %true_block1.6 ]
  %495 = getelementptr double, ptr %494, i64 %485
  %496 = load double, ptr %495, align 8
  %497 = fsub double %496, %100
  %498 = fmul double %489, %497
  %499 = fadd double %449, %498
  %500 = add nsw i64 %.pre-phi.6, %485
  %501 = getelementptr double, ptr %494, i64 %500
  %502 = load double, ptr %501, align 8
  %503 = fsub double %502, %101
  %504 = fmul double %489, %503
  %505 = fadd double %455, %504
  %506 = shl nsw i64 %.pre-phi.6, 1
  %507 = add nsw i64 %506, %485
  %508 = getelementptr double, ptr %494, i64 %507
  %509 = load double, ptr %508, align 8
  %510 = fsub double %509, %96
  %511 = fmul double %489, %510
  %512 = fadd double %462, %511
  %513 = fadd double %463, %489
  %514 = load ptr, ptr %102, align 8
  %uglygep74 = getelementptr i8, ptr %514, i64 28
  %uglygep75 = getelementptr i8, ptr %uglygep74, i64 %164
  %515 = load i32, ptr %uglygep75, align 4
  %516 = load ptr, ptr %103, align 8
  %517 = sext i32 %515 to i64
  %518 = getelementptr i32, ptr %516, i64 %517
  %519 = load i32, ptr %518, align 4
  %520 = load ptr, ptr %104, align 8
  %521 = getelementptr i64, ptr %520, i64 %517
  %522 = load i64, ptr %521, align 8
  %523 = uitofp i64 %522 to double
  %524 = add i32 %515, 512
  %525 = sext i32 %524 to i64
  %526 = getelementptr i64, ptr %520, i64 %525
  %527 = load i64, ptr %526, align 8
  %528 = uitofp i64 %527 to double
  %529 = fdiv double %523, %528
  %530 = atomicrmw add ptr %99, i64 1 seq_cst, align 8
  %531 = load ptr, ptr %105, align 8
  %532 = load i32, ptr %106, align 4
  %533 = sext i32 %532 to i64
  %534 = mul nsw i64 %533, 6
  %535 = sext i32 %519 to i64
  %536 = add nsw i64 %534, %535
  %537 = getelementptr double, ptr %531, i64 %536
  %538 = load double, ptr %537, align 8
  %539 = fmul double %529, %538
  %540 = fcmp ugt double %539, 0.000000e+00
  br i1 %540, label %after_if3.7, label %true_block1.7

true_block1.7:                                    ; preds = %after_if3.6
  %541 = load ptr, ptr %97, align 8
  %542 = getelementptr i64, ptr %541, i64 19
  %543 = atomicrmw add ptr %542, i64 1 seq_cst, align 8
  %.pre54.7 = load ptr, ptr %105, align 8
  %.pre55.7 = load i32, ptr %106, align 4
  %.pre56.7 = sext i32 %.pre55.7 to i64
  br label %after_if3.7

after_if3.7:                                      ; preds = %true_block1.7, %after_if3.6
  %.pre-phi.7 = phi i64 [ %533, %after_if3.6 ], [ %.pre56.7, %true_block1.7 ]
  %544 = phi ptr [ %531, %after_if3.6 ], [ %.pre54.7, %true_block1.7 ]
  %545 = getelementptr double, ptr %544, i64 %535
  %546 = load double, ptr %545, align 8
  %547 = fsub double %546, %100
  %548 = fmul double %539, %547
  %549 = fadd double %499, %548
  %550 = add nsw i64 %.pre-phi.7, %535
  %551 = getelementptr double, ptr %544, i64 %550
  %552 = load double, ptr %551, align 8
  %553 = fsub double %552, %101
  %554 = fmul double %539, %553
  %555 = fadd double %505, %554
  %556 = shl nsw i64 %.pre-phi.7, 1
  %557 = add nsw i64 %556, %535
  %558 = getelementptr double, ptr %544, i64 %557
  %559 = load double, ptr %558, align 8
  %560 = fsub double %559, %96
  %561 = fmul double %539, %560
  %562 = fadd double %512, %561
  %563 = fadd double %513, %539
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: argmemonly mustprogress nofree norecurse nosync nounwind willreturn
define internal fastcc void @S27_refine_coordinates(ptr nocapture readonly %0, ptr nocapture writeonly %1, i32 %2) unnamed_addr #3 {
entry:
  %3 = and i32 %2, 3
  %4 = load i32, ptr %0, align 4
  %5 = shl i32 %4, 2
  %6 = or i32 %5, %3
  store i32 %6, ptr %1, align 4
  %7 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 1
  %8 = load i32, ptr %7, align 4
  %9 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 1
  store i32 %8, ptr %9, align 4
  %10 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 2
  %11 = load i32, ptr %10, align 4
  %12 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 2
  store i32 %11, ptr %12, align 4
  %13 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 3
  %14 = load i32, ptr %13, align 4
  %15 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 3
  store i32 %14, ptr %15, align 4
  %16 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 4
  %17 = load i32, ptr %16, align 4
  %18 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 4
  store i32 %17, ptr %18, align 4
  %19 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 5
  %20 = load i32, ptr %19, align 4
  %21 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 5
  store i32 %20, ptr %21, align 4
  %22 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 6
  %23 = load i32, ptr %22, align 4
  %24 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 6
  store i32 %23, ptr %24, align 4
  %25 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 7
  %26 = load i32, ptr %25, align 4
  %27 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 7
  store i32 %26, ptr %27, align 4
  %28 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 8
  %29 = load i32, ptr %28, align 4
  %30 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 8
  store i32 %29, ptr %30, align 4
  %31 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 9
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 9
  store i32 %32, ptr %33, align 4
  %34 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 10
  %35 = load i32, ptr %34, align 4
  %36 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 10
  store i32 %35, ptr %36, align 4
  %37 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 11
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 11
  store i32 %38, ptr %39, align 4
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #4

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn writeonly
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #5

; Function Attrs: noinline nounwind optnone uwtable
define internal fastcc void @taichi_assert_format(ptr noundef %0, i1 noundef zeroext %1, ptr noundef %2) unnamed_addr #6 {
  %4 = alloca ptr, align 8
  %5 = alloca i8, align 1
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca ptr, align 8
  %9 = alloca %class.anon, align 8
  store ptr %0, ptr %4, align 8
  %10 = zext i1 %1 to i8
  store i8 %10, ptr %5, align 1
  store ptr %2, ptr %6, align 8
  store i32 0, ptr %7, align 4
  store ptr null, ptr %8, align 8
  %11 = load i8, ptr %5, align 1
  %12 = trunc i8 %11 to i1
  %13 = zext i1 %12 to i32
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %15, label %16

15:                                               ; preds = %3
  br label %69

16:                                               ; preds = %3
  %17 = load ptr, ptr %4, align 8
  %18 = getelementptr inbounds %struct.LLVMRuntime, ptr %17, i32 0, i32 24
  %19 = load i64, ptr %18, align 8
  %20 = icmp ne i64 %19, 0
  br i1 %20, label %69, label %21

21:                                               ; preds = %16
  %22 = load ptr, ptr %4, align 8
  %23 = getelementptr inbounds %struct.LLVMRuntime, ptr %22, i32 0, i32 23
  %24 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 0
  store ptr %4, ptr %24, align 8
  %25 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 1
  store ptr %6, ptr %25, align 8
  %26 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 2
  store ptr %7, ptr %26, align 8
  %27 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 3
  store ptr %8, ptr %27, align 8
  br label %28

28:                                               ; preds = %28, %21
  %29 = atomicrmw volatile xchg ptr %23, i32 1 seq_cst, align 4
  %30 = icmp eq i32 %29, 1
  br i1 %30, label %28, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i:                        ; preds = %28
  %31 = load ptr, ptr %9, align 8
  %32 = load ptr, ptr %31, align 8
  %33 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 24
  %34 = load i64, ptr %33, align 8
  %.not.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i, label %35, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

35:                                               ; preds = %mutex_lock_i32.exit.i.i.i
  store i64 1, ptr %33, align 8
  %36 = load ptr, ptr %9, align 8
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr inbounds %struct.LLVMRuntime, ptr %37, i64 0, i32 21
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %38, i8 0, i64 2048, i1 false)
  %39 = load ptr, ptr %9, align 8
  %40 = load ptr, ptr %39, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 21
  %42 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 1
  %43 = load ptr, ptr %42, align 8
  %44 = load ptr, ptr %43, align 8
  %45 = load i8, ptr %44, align 1
  %.not5.i.i.i.i.i = icmp eq i8 %45, 0
  br i1 %.not5.i.i.i.i.i, label %taichi_strlen.exit.thread.i.i.i.i, label %.lr.ph.i.i.i.i.i.preheader

.lr.ph.i.i.i.i.i.preheader:                       ; preds = %35
  br label %.lr.ph.i.i.i.i.i

.lr.ph.i.i.i.i.i:                                 ; preds = %.lr.ph.i.i.i.i.i, %.lr.ph.i.i.i.i.i.preheader
  %.07.i.i.i.i.i = phi ptr [ %47, %.lr.ph.i.i.i.i.i ], [ %44, %.lr.ph.i.i.i.i.i.preheader ]
  %.046.i.i.i.i.i = phi i64 [ %46, %.lr.ph.i.i.i.i.i ], [ 0, %.lr.ph.i.i.i.i.i.preheader ]
  %46 = add i64 %.046.i.i.i.i.i, 1
  %47 = getelementptr inbounds i8, ptr %.07.i.i.i.i.i, i64 1
  %48 = load i8, ptr %47, align 1
  %.not.i.i.i.i.i = icmp eq i8 %48, 0
  br i1 %.not.i.i.i.i.i, label %taichi_strlen.exit.i.i.i.i, label %.lr.ph.i.i.i.i.i, !llvm.loop !13

taichi_strlen.exit.i.i.i.i:                       ; preds = %.lr.ph.i.i.i.i.i
  %.lcssa = phi i64 [ %46, %.lr.ph.i.i.i.i.i ]
  %49 = call i64 @llvm.umin.i64(i64 %.lcssa, i64 2047)
  br label %taichi_strlen.exit.thread.i.i.i.i

taichi_strlen.exit.thread.i.i.i.i:                ; preds = %taichi_strlen.exit.i.i.i.i, %35
  %50 = phi i64 [ 0, %35 ], [ %49, %taichi_strlen.exit.i.i.i.i ]
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %41, ptr nonnull align 1 %44, i64 %50, i1 false)
  %51 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 2
  %52 = load ptr, ptr %51, align 8
  %53 = load i32, ptr %52, align 4
  %54 = icmp sgt i32 %53, 0
  br i1 %54, label %.lr.ph.i.i.i.i, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

.lr.ph.i.i.i.i:                                   ; preds = %taichi_strlen.exit.thread.i.i.i.i
  %55 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 3
  br label %56

56:                                               ; preds = %56, %.lr.ph.i.i.i.i
  %indvars.iv.i.i.i.i = phi i64 [ 0, %.lr.ph.i.i.i.i ], [ %indvars.iv.next.i.i.i.i, %56 ]
  %57 = load ptr, ptr %55, align 8
  %58 = load ptr, ptr %57, align 8
  %59 = getelementptr inbounds i64, ptr %58, i64 %indvars.iv.i.i.i.i
  %60 = load i64, ptr %59, align 8
  %61 = load ptr, ptr %9, align 8
  %62 = load ptr, ptr %61, align 8
  %63 = getelementptr inbounds %struct.LLVMRuntime, ptr %62, i64 0, i32 22, i64 %indvars.iv.i.i.i.i
  store i64 %60, ptr %63, align 8
  %indvars.iv.next.i.i.i.i = add nuw nsw i64 %indvars.iv.i.i.i.i, 1
  %64 = load ptr, ptr %51, align 8
  %65 = load i32, ptr %64, align 4
  %66 = sext i32 %65 to i64
  %67 = icmp slt i64 %indvars.iv.next.i.i.i.i, %66
  br i1 %67, label %56, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", !llvm.loop !14

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit": ; preds = %56
  br label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit": ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", %taichi_strlen.exit.thread.i.i.i.i, %mutex_lock_i32.exit.i.i.i
  %68 = atomicrmw volatile xchg ptr %23, i32 0 seq_cst, align 4
  br label %69

69:                                               ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit", %16, %15
  ret void
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_struct_for_block_helper(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #7 {
_ZN11ListManager3getI7ElementEERT_i.exit:
  %3 = alloca %struct.RuntimeContext.765, align 8
  %4 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 4
  %5 = load i32, ptr %4, align 4
  %6 = sdiv i32 %2, %5
  %7 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  %8 = load i32, ptr %7, align 8
  %9 = sdiv i32 %8, %5
  %10 = srem i32 %2, %5
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  %12 = load ptr, ptr %11, align 8
  %13 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %14 = load i32, ptr %13, align 8
  %15 = ashr i32 %6, %14
  %16 = sext i32 %15 to i64
  %17 = lshr i64 %16, 9
  %18 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %17
  %19 = load atomic i64, ptr %18 acquire, align 8
  %.not.i.i.i = icmp ne i64 %19, 0
  tail call void @llvm.assume(i1 %.not.i.i.i)
  %20 = inttoptr i64 %19 to ptr
  %21 = and i64 %16, 511
  %22 = getelementptr inbounds ptr, ptr %20, i64 %21
  %23 = load atomic i64, ptr %22 acquire, align 8
  %24 = inttoptr i64 %23 to ptr
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %26 = load i64, ptr %25, align 8
  %27 = load i32, ptr %13, align 8
  %notmask.i.i = shl nsw i32 -1, %27
  %28 = xor i32 %notmask.i.i, -1
  %29 = and i32 %6, %28
  %30 = sext i32 %29 to i64
  %31 = mul i64 %26, %30
  %32 = getelementptr inbounds i8, ptr %24, i64 %31
  %33 = getelementptr inbounds %0, ptr %32, i64 0, i32 1
  %34 = load i32, ptr %33, align 8
  %35 = mul nsw i32 %10, %9
  %36 = add nsw i32 %34, %35
  %37 = add nsw i32 %10, 1
  %38 = mul nsw i32 %37, %9
  %39 = add nsw i32 %34, %38
  %40 = getelementptr inbounds %0, ptr %32, i64 0, i32 1, i64 1
  %41 = load i32, ptr %40, align 4
  %42 = tail call i32 @llvm.smin.i32(i32 %41, i32 %39)
  %43 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  %44 = load i64, ptr %43, align 8
  %45 = alloca i8, i64 %44, align 8
  %46 = load ptr, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %3, ptr noundef nonnull align 8 dereferenceable(32) %46, i64 32, i1 false)
  %47 = getelementptr inbounds %struct.RuntimeContext.765, ptr %3, i64 0, i32 2
  store i32 %1, ptr %47, align 8
  %48 = icmp slt i32 %36, %42
  br i1 %48, label %49, label %75

49:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit
  %50 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = load ptr, ptr %11, align 8
  %53 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 3
  %54 = load i32, ptr %53, align 8
  %55 = ashr i32 %6, %54
  %56 = sext i32 %55 to i64
  %57 = lshr i64 %56, 9
  %58 = getelementptr inbounds [256 x ptr], ptr %52, i64 0, i64 %57
  %59 = load atomic i64, ptr %58 acquire, align 8
  %.not.i.i.i24 = icmp eq i64 %59, 0
  br i1 %.not.i.i.i24, label %_ZN11ListManager3getI7ElementEERT_i.exit26, label %60

60:                                               ; preds = %49
  %61 = inttoptr i64 %59 to ptr
  %62 = and i64 %56, 511
  %63 = getelementptr inbounds ptr, ptr %61, i64 %62
  %64 = load atomic i64, ptr %63 acquire, align 8
  %65 = inttoptr i64 %64 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit26

_ZN11ListManager3getI7ElementEERT_i.exit26:       ; preds = %60, %49
  %66 = phi ptr [ %65, %60 ], [ null, %49 ]
  %67 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 1
  %68 = load i64, ptr %67, align 8
  %69 = load i32, ptr %53, align 8
  %notmask.i.i25 = shl nsw i32 -1, %69
  %70 = xor i32 %notmask.i.i25, -1
  %71 = and i32 %6, %70
  %72 = sext i32 %71 to i64
  %73 = mul i64 %68, %72
  %74 = getelementptr inbounds i8, ptr %66, i64 %73
  call void %51(ptr noundef nonnull %3, ptr noundef nonnull %45, ptr noundef nonnull %74, i32 noundef %36, i32 noundef %42) #1
  br label %75

75:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit26, %_ZN11ListManager3getI7ElementEERT_i.exit
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i64 @llvm.umin.i64(i64, i64) #8

; Function Attrs: inaccessiblememonly nocallback nofree nosync nounwind willreturn
declare void @llvm.assume(i1 noundef) #9

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #8

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #10

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #10

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { nofree norecurse nounwind }
attributes #3 = { argmemonly mustprogress nofree norecurse nosync nounwind willreturn }
attributes #4 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #5 = { argmemonly mustprogress nocallback nofree nounwind willreturn writeonly }
attributes #6 = { noinline nounwind optnone uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #9 = { inaccessiblememonly nocallback nofree nosync nounwind willreturn }
attributes #10 = { argmemonly nocallback nofree nosync nounwind willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !12}
!12 = !{!"llvm.loop.unroll.disable"}
!13 = distinct !{!13, !7}
!14 = distinct !{!14, !7}
