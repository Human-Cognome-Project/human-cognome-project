; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct.range_task_helper_context = type { ptr, ptr, ptr, ptr, i64, i32, i32, i32, i32 }
%struct.RuntimeContext.1165 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @tick_numeric_check_25_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %0, i64 0, i32 9, i32 1
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr i64, ptr %2, i64 1
  store i64 0, ptr %3, align 8
  ret void
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_1_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %10 = xor i64 %9, -1
  %11 = add nsw i64 %10, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %9, %for_loop_body.prol.preheader ]
  %12 = load ptr, ptr %8, align 8
  %13 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep20 = getelementptr i8, ptr %12, i64 %13
  %14 = load i64, ptr %uglygep20, align 8
  %15 = and i64 %14, 9223372036854775807
  %16 = and i64 %14, 9218868437227405312
  %17 = icmp eq i64 %15, 0
  %18 = icmp ne i64 %16, 0
  %19 = icmp ne i64 %16, 9218868437227405312
  %20 = and i1 %18, %19
  %21 = or i1 %17, %20
  br i1 %21, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %22 = load ptr, ptr %0, align 8
  %23 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %22, i64 0, i32 9, i32 1
  %24 = load ptr, ptr %23, align 8
  %25 = getelementptr i64, ptr %24, i64 1
  %26 = atomicrmw add ptr %25, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !6

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %27 = add i64 %xtraiter, %9
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %9, %for_loop_body.lr.ph ], [ %27, %for_loop_body.prol.loopexit.loopexit ]
  %28 = icmp ult i64 %11, 7
  br i1 %28, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %29 = load ptr, ptr %8, align 8
  %30 = shl i64 %indvars.iv, 3
  %uglygep17 = getelementptr i8, ptr %29, i64 %30
  %31 = load i64, ptr %uglygep17, align 8
  %32 = and i64 %31, 9223372036854775807
  %33 = and i64 %31, 9218868437227405312
  %34 = icmp eq i64 %32, 0
  %35 = icmp ne i64 %33, 0
  %36 = icmp ne i64 %33, 9218868437227405312
  %37 = and i1 %35, %36
  %38 = or i1 %34, %37
  br i1 %38, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %39 = load ptr, ptr %0, align 8
  %40 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %39, i64 0, i32 9, i32 1
  %41 = load ptr, ptr %40, align 8
  %42 = getelementptr i64, ptr %41, i64 1
  %43 = atomicrmw add ptr %42, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %44 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %44, i64 8
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %30
  %45 = load i64, ptr %uglygep19, align 8
  %46 = and i64 %45, 9223372036854775807
  %47 = and i64 %45, 9218868437227405312
  %48 = icmp eq i64 %46, 0
  %49 = icmp ne i64 %47, 0
  %50 = icmp ne i64 %47, 9218868437227405312
  %51 = and i1 %49, %50
  %52 = or i1 %48, %51
  br i1 %52, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %53 = load ptr, ptr %0, align 8
  %54 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %53, i64 0, i32 9, i32 1
  %55 = load ptr, ptr %54, align 8
  %56 = getelementptr i64, ptr %55, i64 1
  %57 = atomicrmw add ptr %56, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %58 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %58, i64 16
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %30
  %59 = load i64, ptr %uglygep16, align 8
  %60 = and i64 %59, 9223372036854775807
  %61 = and i64 %59, 9218868437227405312
  %62 = icmp eq i64 %60, 0
  %63 = icmp ne i64 %61, 0
  %64 = icmp ne i64 %61, 9218868437227405312
  %65 = and i1 %63, %64
  %66 = or i1 %62, %65
  br i1 %66, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %67 = load ptr, ptr %0, align 8
  %68 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %67, i64 0, i32 9, i32 1
  %69 = load ptr, ptr %68, align 8
  %70 = getelementptr i64, ptr %69, i64 1
  %71 = atomicrmw add ptr %70, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %72 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %72, i64 24
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %30
  %73 = load i64, ptr %uglygep14, align 8
  %74 = and i64 %73, 9223372036854775807
  %75 = and i64 %73, 9218868437227405312
  %76 = icmp eq i64 %74, 0
  %77 = icmp ne i64 %75, 0
  %78 = icmp ne i64 %75, 9218868437227405312
  %79 = and i1 %77, %78
  %80 = or i1 %76, %79
  br i1 %80, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %81 = load ptr, ptr %0, align 8
  %82 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %81, i64 0, i32 9, i32 1
  %83 = load ptr, ptr %82, align 8
  %84 = getelementptr i64, ptr %83, i64 1
  %85 = atomicrmw add ptr %84, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %86 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %86, i64 32
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %30
  %87 = load i64, ptr %uglygep12, align 8
  %88 = and i64 %87, 9223372036854775807
  %89 = and i64 %87, 9218868437227405312
  %90 = icmp eq i64 %88, 0
  %91 = icmp ne i64 %89, 0
  %92 = icmp ne i64 %89, 9218868437227405312
  %93 = and i1 %91, %92
  %94 = or i1 %90, %93
  br i1 %94, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %95 = load ptr, ptr %0, align 8
  %96 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %95, i64 0, i32 9, i32 1
  %97 = load ptr, ptr %96, align 8
  %98 = getelementptr i64, ptr %97, i64 1
  %99 = atomicrmw add ptr %98, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %100 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %100, i64 40
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %30
  %101 = load i64, ptr %uglygep10, align 8
  %102 = and i64 %101, 9223372036854775807
  %103 = and i64 %101, 9218868437227405312
  %104 = icmp eq i64 %102, 0
  %105 = icmp ne i64 %103, 0
  %106 = icmp ne i64 %103, 9218868437227405312
  %107 = and i1 %105, %106
  %108 = or i1 %104, %107
  br i1 %108, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %109 = load ptr, ptr %0, align 8
  %110 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %109, i64 0, i32 9, i32 1
  %111 = load ptr, ptr %110, align 8
  %112 = getelementptr i64, ptr %111, i64 1
  %113 = atomicrmw add ptr %112, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %114 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %114, i64 48
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %30
  %115 = load i64, ptr %uglygep8, align 8
  %116 = and i64 %115, 9223372036854775807
  %117 = and i64 %115, 9218868437227405312
  %118 = icmp eq i64 %116, 0
  %119 = icmp ne i64 %117, 0
  %120 = icmp ne i64 %117, 9218868437227405312
  %121 = and i1 %119, %120
  %122 = or i1 %118, %121
  br i1 %122, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %123 = load ptr, ptr %0, align 8
  %124 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %123, i64 0, i32 9, i32 1
  %125 = load ptr, ptr %124, align 8
  %126 = getelementptr i64, ptr %125, i64 1
  %127 = atomicrmw add ptr %126, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %128 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %128, i64 56
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %30
  %129 = load i64, ptr %uglygep6, align 8
  %130 = and i64 %129, 9223372036854775807
  %131 = and i64 %129, 9218868437227405312
  %132 = icmp eq i64 %130, 0
  %133 = icmp ne i64 %131, 0
  %134 = icmp ne i64 %131, 9218868437227405312
  %135 = and i1 %133, %134
  %136 = or i1 %132, %135
  br i1 %136, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %137 = load ptr, ptr %0, align 8
  %138 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %137, i64 0, i32 9, i32 1
  %139 = load ptr, ptr %138, align 8
  %140 = getelementptr i64, ptr %139, i64 1
  %141 = atomicrmw add ptr %140, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_2_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.1, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.1(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 1
  %9 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv6 = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next7, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = add nsw i64 %indvars.iv.prol, %15
  %17 = getelementptr double, ptr %13, i64 %16
  %18 = load i64, ptr %17, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next7 = add nsw i64 %lsr.iv6, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next7, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !8

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  %33 = sub i64 0, %wide.trip.count
  %34 = add nsw i64 %indvars.iv.unr, 7
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %lsr.iv = phi i64 [ %34, %for_loop_body.preheader ], [ %lsr.iv.next, %after_if.7 ]
  %35 = load ptr, ptr %8, align 8
  %36 = load i32, ptr %9, align 4
  %37 = sext i32 %36 to i64
  %38 = add i64 %lsr.iv, %37
  %39 = getelementptr double, ptr %35, i64 %38
  %40 = getelementptr double, ptr %39, i64 -7
  %41 = load i64, ptr %40, align 8
  %42 = and i64 %41, 9223372036854775807
  %43 = and i64 %41, 9218868437227405312
  %44 = icmp eq i64 %42, 0
  %45 = icmp ne i64 %43, 0
  %46 = icmp ne i64 %43, 9218868437227405312
  %47 = and i1 %45, %46
  %48 = or i1 %44, %47
  br i1 %48, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %49 = load ptr, ptr %0, align 8
  %50 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %49, i64 0, i32 9, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = getelementptr i64, ptr %51, i64 1
  %53 = atomicrmw add ptr %52, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %54 = load ptr, ptr %8, align 8
  %55 = load i32, ptr %9, align 4
  %56 = sext i32 %55 to i64
  %57 = add i64 %lsr.iv, %56
  %58 = getelementptr double, ptr %54, i64 %57
  %59 = getelementptr double, ptr %58, i64 -6
  %60 = load i64, ptr %59, align 8
  %61 = and i64 %60, 9223372036854775807
  %62 = and i64 %60, 9218868437227405312
  %63 = icmp eq i64 %61, 0
  %64 = icmp ne i64 %62, 0
  %65 = icmp ne i64 %62, 9218868437227405312
  %66 = and i1 %64, %65
  %67 = or i1 %63, %66
  br i1 %67, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %68 = load ptr, ptr %0, align 8
  %69 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %68, i64 0, i32 9, i32 1
  %70 = load ptr, ptr %69, align 8
  %71 = getelementptr i64, ptr %70, i64 1
  %72 = atomicrmw add ptr %71, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %73 = load ptr, ptr %8, align 8
  %74 = load i32, ptr %9, align 4
  %75 = sext i32 %74 to i64
  %76 = add i64 %lsr.iv, %75
  %77 = getelementptr double, ptr %73, i64 %76
  %78 = getelementptr double, ptr %77, i64 -5
  %79 = load i64, ptr %78, align 8
  %80 = and i64 %79, 9223372036854775807
  %81 = and i64 %79, 9218868437227405312
  %82 = icmp eq i64 %80, 0
  %83 = icmp ne i64 %81, 0
  %84 = icmp ne i64 %81, 9218868437227405312
  %85 = and i1 %83, %84
  %86 = or i1 %82, %85
  br i1 %86, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %87 = load ptr, ptr %0, align 8
  %88 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %87, i64 0, i32 9, i32 1
  %89 = load ptr, ptr %88, align 8
  %90 = getelementptr i64, ptr %89, i64 1
  %91 = atomicrmw add ptr %90, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %92 = load ptr, ptr %8, align 8
  %93 = load i32, ptr %9, align 4
  %94 = sext i32 %93 to i64
  %95 = add i64 %lsr.iv, %94
  %96 = getelementptr double, ptr %92, i64 %95
  %97 = getelementptr double, ptr %96, i64 -4
  %98 = load i64, ptr %97, align 8
  %99 = and i64 %98, 9223372036854775807
  %100 = and i64 %98, 9218868437227405312
  %101 = icmp eq i64 %99, 0
  %102 = icmp ne i64 %100, 0
  %103 = icmp ne i64 %100, 9218868437227405312
  %104 = and i1 %102, %103
  %105 = or i1 %101, %104
  br i1 %105, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %106 = load ptr, ptr %0, align 8
  %107 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %106, i64 0, i32 9, i32 1
  %108 = load ptr, ptr %107, align 8
  %109 = getelementptr i64, ptr %108, i64 1
  %110 = atomicrmw add ptr %109, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %111 = load ptr, ptr %8, align 8
  %112 = load i32, ptr %9, align 4
  %113 = sext i32 %112 to i64
  %114 = add i64 %lsr.iv, %113
  %115 = getelementptr double, ptr %111, i64 %114
  %116 = getelementptr double, ptr %115, i64 -3
  %117 = load i64, ptr %116, align 8
  %118 = and i64 %117, 9223372036854775807
  %119 = and i64 %117, 9218868437227405312
  %120 = icmp eq i64 %118, 0
  %121 = icmp ne i64 %119, 0
  %122 = icmp ne i64 %119, 9218868437227405312
  %123 = and i1 %121, %122
  %124 = or i1 %120, %123
  br i1 %124, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %125 = load ptr, ptr %0, align 8
  %126 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %125, i64 0, i32 9, i32 1
  %127 = load ptr, ptr %126, align 8
  %128 = getelementptr i64, ptr %127, i64 1
  %129 = atomicrmw add ptr %128, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %130 = load ptr, ptr %8, align 8
  %131 = load i32, ptr %9, align 4
  %132 = sext i32 %131 to i64
  %133 = add i64 %lsr.iv, %132
  %134 = getelementptr double, ptr %130, i64 %133
  %135 = getelementptr double, ptr %134, i64 -2
  %136 = load i64, ptr %135, align 8
  %137 = and i64 %136, 9223372036854775807
  %138 = and i64 %136, 9218868437227405312
  %139 = icmp eq i64 %137, 0
  %140 = icmp ne i64 %138, 0
  %141 = icmp ne i64 %138, 9218868437227405312
  %142 = and i1 %140, %141
  %143 = or i1 %139, %142
  br i1 %143, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %144 = load ptr, ptr %0, align 8
  %145 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %144, i64 0, i32 9, i32 1
  %146 = load ptr, ptr %145, align 8
  %147 = getelementptr i64, ptr %146, i64 1
  %148 = atomicrmw add ptr %147, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %149 = load ptr, ptr %8, align 8
  %150 = load i32, ptr %9, align 4
  %151 = sext i32 %150 to i64
  %152 = add i64 %lsr.iv, %151
  %153 = getelementptr double, ptr %149, i64 %152
  %154 = getelementptr double, ptr %153, i64 -1
  %155 = load i64, ptr %154, align 8
  %156 = and i64 %155, 9223372036854775807
  %157 = and i64 %155, 9218868437227405312
  %158 = icmp eq i64 %156, 0
  %159 = icmp ne i64 %157, 0
  %160 = icmp ne i64 %157, 9218868437227405312
  %161 = and i1 %159, %160
  %162 = or i1 %158, %161
  br i1 %162, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %163 = load ptr, ptr %0, align 8
  %164 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %163, i64 0, i32 9, i32 1
  %165 = load ptr, ptr %164, align 8
  %166 = getelementptr i64, ptr %165, i64 1
  %167 = atomicrmw add ptr %166, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %168 = load ptr, ptr %8, align 8
  %169 = load i32, ptr %9, align 4
  %170 = sext i32 %169 to i64
  %171 = add nsw i64 %lsr.iv, %170
  %172 = getelementptr double, ptr %168, i64 %171
  %173 = load i64, ptr %172, align 8
  %174 = and i64 %173, 9223372036854775807
  %175 = and i64 %173, 9218868437227405312
  %176 = icmp eq i64 %174, 0
  %177 = icmp ne i64 %175, 0
  %178 = icmp ne i64 %175, 9218868437227405312
  %179 = and i1 %177, %178
  %180 = or i1 %176, %179
  br i1 %180, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %181 = load ptr, ptr %0, align 8
  %182 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %181, i64 0, i32 9, i32 1
  %183 = load ptr, ptr %182, align 8
  %184 = getelementptr i64, ptr %183, i64 1
  %185 = atomicrmw add ptr %184, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %lsr.iv.next = add i64 %lsr.iv, 8
  %186 = add i64 %33, %lsr.iv.next
  %exitcond.not.7 = icmp eq i64 %186, 7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_3_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.2, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.2(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 1
  %9 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = shl nsw i64 %15, 4
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !9

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = shl nsw i64 %35, 4
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = shl nsw i64 %53, 4
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = shl nsw i64 %70, 4
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = shl nsw i64 %87, 4
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = shl nsw i64 %104, 4
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = shl nsw i64 %121, 4
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = shl nsw i64 %138, 4
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = shl nsw i64 %155, 4
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_4_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.3, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.3(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 1
  %9 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = mul nsw i64 %15, 24
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !10

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = mul nsw i64 %35, 24
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = mul nsw i64 %53, 24
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = mul nsw i64 %70, 24
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = mul nsw i64 %87, 24
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = mul nsw i64 %104, 24
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = mul nsw i64 %121, 24
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = mul nsw i64 %138, 24
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = mul nsw i64 %155, 24
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_5_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.4, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.4(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 1
  %9 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = shl nsw i64 %15, 5
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !11

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = shl nsw i64 %35, 5
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = shl nsw i64 %53, 5
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = shl nsw i64 %70, 5
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = shl nsw i64 %87, 5
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = shl nsw i64 %104, 5
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = shl nsw i64 %121, 5
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = shl nsw i64 %138, 5
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = shl nsw i64 %155, 5
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_6_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.5, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.5(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 1
  %9 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = mul nsw i64 %15, 40
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !12

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = mul nsw i64 %35, 40
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = mul nsw i64 %53, 40
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = mul nsw i64 %70, 40
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = mul nsw i64 %87, 40
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = mul nsw i64 %104, 40
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = mul nsw i64 %121, 40
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = mul nsw i64 %138, 40
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = mul nsw i64 %155, 40
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_7_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.6, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.6(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 1
  %9 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = mul nsw i64 %15, 48
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !13

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = mul nsw i64 %35, 48
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = mul nsw i64 %53, 48
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = mul nsw i64 %70, 48
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = mul nsw i64 %87, 48
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = mul nsw i64 %104, 48
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = mul nsw i64 %121, 48
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = mul nsw i64 %138, 48
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = mul nsw i64 %155, 48
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_8_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.7, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.7(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 1
  %9 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = mul nsw i64 %15, 56
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !14

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = mul nsw i64 %35, 56
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = mul nsw i64 %53, 56
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = mul nsw i64 %70, 56
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = mul nsw i64 %87, 56
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = mul nsw i64 %104, 56
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = mul nsw i64 %121, 56
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = mul nsw i64 %138, 56
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = mul nsw i64 %155, 56
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_9_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.8, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.8(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 1
  %9 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = shl nsw i64 %15, 6
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !15

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = shl nsw i64 %35, 6
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = shl nsw i64 %53, 6
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = shl nsw i64 %70, 6
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = shl nsw i64 %87, 6
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = shl nsw i64 %104, 6
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = shl nsw i64 %121, 6
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = shl nsw i64 %138, 6
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = shl nsw i64 %155, 6
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_10_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.9, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.9(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 1
  %9 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = mul nsw i64 %15, 72
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !16

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = mul nsw i64 %35, 72
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = mul nsw i64 %53, 72
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = mul nsw i64 %70, 72
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = mul nsw i64 %87, 72
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = mul nsw i64 %104, 72
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = mul nsw i64 %121, 72
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = mul nsw i64 %138, 72
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = mul nsw i64 %155, 72
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_11_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.10, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.10(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 1
  %9 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = mul nsw i64 %15, 80
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !17

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = mul nsw i64 %35, 80
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = mul nsw i64 %53, 80
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = mul nsw i64 %70, 80
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = mul nsw i64 %87, 80
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = mul nsw i64 %104, 80
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = mul nsw i64 %121, 80
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = mul nsw i64 %138, 80
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = mul nsw i64 %155, 80
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_12_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.11, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.11(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 1, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %10 = xor i64 %9, -1
  %11 = add nsw i64 %10, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %9, %for_loop_body.prol.preheader ]
  %12 = load ptr, ptr %8, align 8
  %13 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep20 = getelementptr i8, ptr %12, i64 %13
  %14 = load i64, ptr %uglygep20, align 8
  %15 = and i64 %14, 9223372036854775807
  %16 = and i64 %14, 9218868437227405312
  %17 = icmp eq i64 %15, 0
  %18 = icmp ne i64 %16, 0
  %19 = icmp ne i64 %16, 9218868437227405312
  %20 = and i1 %18, %19
  %21 = or i1 %17, %20
  br i1 %21, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %22 = load ptr, ptr %0, align 8
  %23 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %22, i64 0, i32 9, i32 1
  %24 = load ptr, ptr %23, align 8
  %25 = getelementptr i64, ptr %24, i64 1
  %26 = atomicrmw add ptr %25, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !18

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %27 = add i64 %xtraiter, %9
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %9, %for_loop_body.lr.ph ], [ %27, %for_loop_body.prol.loopexit.loopexit ]
  %28 = icmp ult i64 %11, 7
  br i1 %28, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %29 = load ptr, ptr %8, align 8
  %30 = shl i64 %indvars.iv, 3
  %uglygep17 = getelementptr i8, ptr %29, i64 %30
  %31 = load i64, ptr %uglygep17, align 8
  %32 = and i64 %31, 9223372036854775807
  %33 = and i64 %31, 9218868437227405312
  %34 = icmp eq i64 %32, 0
  %35 = icmp ne i64 %33, 0
  %36 = icmp ne i64 %33, 9218868437227405312
  %37 = and i1 %35, %36
  %38 = or i1 %34, %37
  br i1 %38, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %39 = load ptr, ptr %0, align 8
  %40 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %39, i64 0, i32 9, i32 1
  %41 = load ptr, ptr %40, align 8
  %42 = getelementptr i64, ptr %41, i64 1
  %43 = atomicrmw add ptr %42, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %44 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %44, i64 8
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %30
  %45 = load i64, ptr %uglygep19, align 8
  %46 = and i64 %45, 9223372036854775807
  %47 = and i64 %45, 9218868437227405312
  %48 = icmp eq i64 %46, 0
  %49 = icmp ne i64 %47, 0
  %50 = icmp ne i64 %47, 9218868437227405312
  %51 = and i1 %49, %50
  %52 = or i1 %48, %51
  br i1 %52, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %53 = load ptr, ptr %0, align 8
  %54 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %53, i64 0, i32 9, i32 1
  %55 = load ptr, ptr %54, align 8
  %56 = getelementptr i64, ptr %55, i64 1
  %57 = atomicrmw add ptr %56, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %58 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %58, i64 16
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %30
  %59 = load i64, ptr %uglygep16, align 8
  %60 = and i64 %59, 9223372036854775807
  %61 = and i64 %59, 9218868437227405312
  %62 = icmp eq i64 %60, 0
  %63 = icmp ne i64 %61, 0
  %64 = icmp ne i64 %61, 9218868437227405312
  %65 = and i1 %63, %64
  %66 = or i1 %62, %65
  br i1 %66, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %67 = load ptr, ptr %0, align 8
  %68 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %67, i64 0, i32 9, i32 1
  %69 = load ptr, ptr %68, align 8
  %70 = getelementptr i64, ptr %69, i64 1
  %71 = atomicrmw add ptr %70, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %72 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %72, i64 24
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %30
  %73 = load i64, ptr %uglygep14, align 8
  %74 = and i64 %73, 9223372036854775807
  %75 = and i64 %73, 9218868437227405312
  %76 = icmp eq i64 %74, 0
  %77 = icmp ne i64 %75, 0
  %78 = icmp ne i64 %75, 9218868437227405312
  %79 = and i1 %77, %78
  %80 = or i1 %76, %79
  br i1 %80, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %81 = load ptr, ptr %0, align 8
  %82 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %81, i64 0, i32 9, i32 1
  %83 = load ptr, ptr %82, align 8
  %84 = getelementptr i64, ptr %83, i64 1
  %85 = atomicrmw add ptr %84, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %86 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %86, i64 32
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %30
  %87 = load i64, ptr %uglygep12, align 8
  %88 = and i64 %87, 9223372036854775807
  %89 = and i64 %87, 9218868437227405312
  %90 = icmp eq i64 %88, 0
  %91 = icmp ne i64 %89, 0
  %92 = icmp ne i64 %89, 9218868437227405312
  %93 = and i1 %91, %92
  %94 = or i1 %90, %93
  br i1 %94, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %95 = load ptr, ptr %0, align 8
  %96 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %95, i64 0, i32 9, i32 1
  %97 = load ptr, ptr %96, align 8
  %98 = getelementptr i64, ptr %97, i64 1
  %99 = atomicrmw add ptr %98, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %100 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %100, i64 40
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %30
  %101 = load i64, ptr %uglygep10, align 8
  %102 = and i64 %101, 9223372036854775807
  %103 = and i64 %101, 9218868437227405312
  %104 = icmp eq i64 %102, 0
  %105 = icmp ne i64 %103, 0
  %106 = icmp ne i64 %103, 9218868437227405312
  %107 = and i1 %105, %106
  %108 = or i1 %104, %107
  br i1 %108, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %109 = load ptr, ptr %0, align 8
  %110 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %109, i64 0, i32 9, i32 1
  %111 = load ptr, ptr %110, align 8
  %112 = getelementptr i64, ptr %111, i64 1
  %113 = atomicrmw add ptr %112, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %114 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %114, i64 48
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %30
  %115 = load i64, ptr %uglygep8, align 8
  %116 = and i64 %115, 9223372036854775807
  %117 = and i64 %115, 9218868437227405312
  %118 = icmp eq i64 %116, 0
  %119 = icmp ne i64 %117, 0
  %120 = icmp ne i64 %117, 9218868437227405312
  %121 = and i1 %119, %120
  %122 = or i1 %118, %121
  br i1 %122, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %123 = load ptr, ptr %0, align 8
  %124 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %123, i64 0, i32 9, i32 1
  %125 = load ptr, ptr %124, align 8
  %126 = getelementptr i64, ptr %125, i64 1
  %127 = atomicrmw add ptr %126, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %128 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %128, i64 56
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %30
  %129 = load i64, ptr %uglygep6, align 8
  %130 = and i64 %129, 9223372036854775807
  %131 = and i64 %129, 9218868437227405312
  %132 = icmp eq i64 %130, 0
  %133 = icmp ne i64 %131, 0
  %134 = icmp ne i64 %131, 9218868437227405312
  %135 = and i1 %133, %134
  %136 = or i1 %132, %135
  br i1 %136, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %137 = load ptr, ptr %0, align 8
  %138 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %137, i64 0, i32 9, i32 1
  %139 = load ptr, ptr %138, align 8
  %140 = getelementptr i64, ptr %139, i64 1
  %141 = atomicrmw add ptr %140, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_13_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.12, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.12(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 1, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 1, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv6 = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next7, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = add nsw i64 %indvars.iv.prol, %15
  %17 = getelementptr double, ptr %13, i64 %16
  %18 = load i64, ptr %17, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next7 = add nsw i64 %lsr.iv6, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next7, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !19

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  %33 = sub i64 0, %wide.trip.count
  %34 = add nsw i64 %indvars.iv.unr, 7
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %lsr.iv = phi i64 [ %34, %for_loop_body.preheader ], [ %lsr.iv.next, %after_if.7 ]
  %35 = load ptr, ptr %8, align 8
  %36 = load i32, ptr %9, align 4
  %37 = sext i32 %36 to i64
  %38 = add i64 %lsr.iv, %37
  %39 = getelementptr double, ptr %35, i64 %38
  %40 = getelementptr double, ptr %39, i64 -7
  %41 = load i64, ptr %40, align 8
  %42 = and i64 %41, 9223372036854775807
  %43 = and i64 %41, 9218868437227405312
  %44 = icmp eq i64 %42, 0
  %45 = icmp ne i64 %43, 0
  %46 = icmp ne i64 %43, 9218868437227405312
  %47 = and i1 %45, %46
  %48 = or i1 %44, %47
  br i1 %48, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %49 = load ptr, ptr %0, align 8
  %50 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %49, i64 0, i32 9, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = getelementptr i64, ptr %51, i64 1
  %53 = atomicrmw add ptr %52, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %54 = load ptr, ptr %8, align 8
  %55 = load i32, ptr %9, align 4
  %56 = sext i32 %55 to i64
  %57 = add i64 %lsr.iv, %56
  %58 = getelementptr double, ptr %54, i64 %57
  %59 = getelementptr double, ptr %58, i64 -6
  %60 = load i64, ptr %59, align 8
  %61 = and i64 %60, 9223372036854775807
  %62 = and i64 %60, 9218868437227405312
  %63 = icmp eq i64 %61, 0
  %64 = icmp ne i64 %62, 0
  %65 = icmp ne i64 %62, 9218868437227405312
  %66 = and i1 %64, %65
  %67 = or i1 %63, %66
  br i1 %67, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %68 = load ptr, ptr %0, align 8
  %69 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %68, i64 0, i32 9, i32 1
  %70 = load ptr, ptr %69, align 8
  %71 = getelementptr i64, ptr %70, i64 1
  %72 = atomicrmw add ptr %71, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %73 = load ptr, ptr %8, align 8
  %74 = load i32, ptr %9, align 4
  %75 = sext i32 %74 to i64
  %76 = add i64 %lsr.iv, %75
  %77 = getelementptr double, ptr %73, i64 %76
  %78 = getelementptr double, ptr %77, i64 -5
  %79 = load i64, ptr %78, align 8
  %80 = and i64 %79, 9223372036854775807
  %81 = and i64 %79, 9218868437227405312
  %82 = icmp eq i64 %80, 0
  %83 = icmp ne i64 %81, 0
  %84 = icmp ne i64 %81, 9218868437227405312
  %85 = and i1 %83, %84
  %86 = or i1 %82, %85
  br i1 %86, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %87 = load ptr, ptr %0, align 8
  %88 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %87, i64 0, i32 9, i32 1
  %89 = load ptr, ptr %88, align 8
  %90 = getelementptr i64, ptr %89, i64 1
  %91 = atomicrmw add ptr %90, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %92 = load ptr, ptr %8, align 8
  %93 = load i32, ptr %9, align 4
  %94 = sext i32 %93 to i64
  %95 = add i64 %lsr.iv, %94
  %96 = getelementptr double, ptr %92, i64 %95
  %97 = getelementptr double, ptr %96, i64 -4
  %98 = load i64, ptr %97, align 8
  %99 = and i64 %98, 9223372036854775807
  %100 = and i64 %98, 9218868437227405312
  %101 = icmp eq i64 %99, 0
  %102 = icmp ne i64 %100, 0
  %103 = icmp ne i64 %100, 9218868437227405312
  %104 = and i1 %102, %103
  %105 = or i1 %101, %104
  br i1 %105, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %106 = load ptr, ptr %0, align 8
  %107 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %106, i64 0, i32 9, i32 1
  %108 = load ptr, ptr %107, align 8
  %109 = getelementptr i64, ptr %108, i64 1
  %110 = atomicrmw add ptr %109, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %111 = load ptr, ptr %8, align 8
  %112 = load i32, ptr %9, align 4
  %113 = sext i32 %112 to i64
  %114 = add i64 %lsr.iv, %113
  %115 = getelementptr double, ptr %111, i64 %114
  %116 = getelementptr double, ptr %115, i64 -3
  %117 = load i64, ptr %116, align 8
  %118 = and i64 %117, 9223372036854775807
  %119 = and i64 %117, 9218868437227405312
  %120 = icmp eq i64 %118, 0
  %121 = icmp ne i64 %119, 0
  %122 = icmp ne i64 %119, 9218868437227405312
  %123 = and i1 %121, %122
  %124 = or i1 %120, %123
  br i1 %124, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %125 = load ptr, ptr %0, align 8
  %126 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %125, i64 0, i32 9, i32 1
  %127 = load ptr, ptr %126, align 8
  %128 = getelementptr i64, ptr %127, i64 1
  %129 = atomicrmw add ptr %128, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %130 = load ptr, ptr %8, align 8
  %131 = load i32, ptr %9, align 4
  %132 = sext i32 %131 to i64
  %133 = add i64 %lsr.iv, %132
  %134 = getelementptr double, ptr %130, i64 %133
  %135 = getelementptr double, ptr %134, i64 -2
  %136 = load i64, ptr %135, align 8
  %137 = and i64 %136, 9223372036854775807
  %138 = and i64 %136, 9218868437227405312
  %139 = icmp eq i64 %137, 0
  %140 = icmp ne i64 %138, 0
  %141 = icmp ne i64 %138, 9218868437227405312
  %142 = and i1 %140, %141
  %143 = or i1 %139, %142
  br i1 %143, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %144 = load ptr, ptr %0, align 8
  %145 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %144, i64 0, i32 9, i32 1
  %146 = load ptr, ptr %145, align 8
  %147 = getelementptr i64, ptr %146, i64 1
  %148 = atomicrmw add ptr %147, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %149 = load ptr, ptr %8, align 8
  %150 = load i32, ptr %9, align 4
  %151 = sext i32 %150 to i64
  %152 = add i64 %lsr.iv, %151
  %153 = getelementptr double, ptr %149, i64 %152
  %154 = getelementptr double, ptr %153, i64 -1
  %155 = load i64, ptr %154, align 8
  %156 = and i64 %155, 9223372036854775807
  %157 = and i64 %155, 9218868437227405312
  %158 = icmp eq i64 %156, 0
  %159 = icmp ne i64 %157, 0
  %160 = icmp ne i64 %157, 9218868437227405312
  %161 = and i1 %159, %160
  %162 = or i1 %158, %161
  br i1 %162, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %163 = load ptr, ptr %0, align 8
  %164 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %163, i64 0, i32 9, i32 1
  %165 = load ptr, ptr %164, align 8
  %166 = getelementptr i64, ptr %165, i64 1
  %167 = atomicrmw add ptr %166, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %168 = load ptr, ptr %8, align 8
  %169 = load i32, ptr %9, align 4
  %170 = sext i32 %169 to i64
  %171 = add nsw i64 %lsr.iv, %170
  %172 = getelementptr double, ptr %168, i64 %171
  %173 = load i64, ptr %172, align 8
  %174 = and i64 %173, 9223372036854775807
  %175 = and i64 %173, 9218868437227405312
  %176 = icmp eq i64 %174, 0
  %177 = icmp ne i64 %175, 0
  %178 = icmp ne i64 %175, 9218868437227405312
  %179 = and i1 %177, %178
  %180 = or i1 %176, %179
  br i1 %180, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %181 = load ptr, ptr %0, align 8
  %182 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %181, i64 0, i32 9, i32 1
  %183 = load ptr, ptr %182, align 8
  %184 = getelementptr i64, ptr %183, i64 1
  %185 = atomicrmw add ptr %184, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %lsr.iv.next = add i64 %lsr.iv, 8
  %186 = add i64 %33, %lsr.iv.next
  %exitcond.not.7 = icmp eq i64 %186, 7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_14_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.13, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.13(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 1, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 1, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = shl nsw i64 %15, 4
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !20

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = shl nsw i64 %35, 4
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = shl nsw i64 %53, 4
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = shl nsw i64 %70, 4
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = shl nsw i64 %87, 4
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = shl nsw i64 %104, 4
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = shl nsw i64 %121, 4
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = shl nsw i64 %138, 4
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = shl nsw i64 %155, 4
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_15_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.14, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.14(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 1, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 1, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = mul nsw i64 %15, 24
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !21

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = mul nsw i64 %35, 24
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = mul nsw i64 %53, 24
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = mul nsw i64 %70, 24
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = mul nsw i64 %87, 24
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = mul nsw i64 %104, 24
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = mul nsw i64 %121, 24
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = mul nsw i64 %138, 24
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = mul nsw i64 %155, 24
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_16_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.15, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.15(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 1, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 1, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = shl nsw i64 %15, 5
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !22

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = shl nsw i64 %35, 5
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = shl nsw i64 %53, 5
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = shl nsw i64 %70, 5
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = shl nsw i64 %87, 5
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = shl nsw i64 %104, 5
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = shl nsw i64 %121, 5
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = shl nsw i64 %138, 5
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = shl nsw i64 %155, 5
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_17_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.16, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.16(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 1, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 1, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = mul nsw i64 %15, 40
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !23

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = mul nsw i64 %35, 40
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = mul nsw i64 %53, 40
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = mul nsw i64 %70, 40
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = mul nsw i64 %87, 40
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = mul nsw i64 %104, 40
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = mul nsw i64 %121, 40
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = mul nsw i64 %138, 40
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = mul nsw i64 %155, 40
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_18_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.17, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.17(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 1, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 1, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = mul nsw i64 %15, 48
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !24

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = mul nsw i64 %35, 48
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = mul nsw i64 %53, 48
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = mul nsw i64 %70, 48
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = mul nsw i64 %87, 48
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = mul nsw i64 %104, 48
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = mul nsw i64 %121, 48
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = mul nsw i64 %138, 48
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = mul nsw i64 %155, 48
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_19_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.18, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.18(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 1, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 1, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = mul nsw i64 %15, 56
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !25

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = mul nsw i64 %35, 56
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = mul nsw i64 %53, 56
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = mul nsw i64 %70, 56
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = mul nsw i64 %87, 56
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = mul nsw i64 %104, 56
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = mul nsw i64 %121, 56
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = mul nsw i64 %138, 56
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = mul nsw i64 %155, 56
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_20_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.19, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.19(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 1)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 2, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %10 = xor i64 %9, -1
  %11 = add nsw i64 %10, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 1
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %12 = load ptr, ptr %8, align 8
  %13 = shl nsw i64 %9, 3
  %uglygep20 = getelementptr i8, ptr %12, i64 %13
  %14 = load i64, ptr %uglygep20, align 8
  %15 = and i64 %14, 9223372036854775807
  %16 = and i64 %14, 9218868437227405312
  %17 = icmp eq i64 %15, 0
  %18 = icmp ne i64 %16, 0
  %19 = icmp ne i64 %16, 9218868437227405312
  %20 = and i1 %18, %19
  %21 = or i1 %17, %20
  br i1 %21, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %22 = load ptr, ptr %0, align 8
  %23 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %22, i64 0, i32 9, i32 1
  %24 = load ptr, ptr %23, align 8
  %25 = getelementptr i64, ptr %24, i64 1
  %26 = atomicrmw add ptr %25, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  br i1 true, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !26

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %27 = add nuw nsw i64 %9, 1
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %9, %for_loop_body.lr.ph ], [ %27, %for_loop_body.prol.loopexit.loopexit ]
  %28 = icmp ult i64 %11, 7
  br i1 %28, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %29 = load ptr, ptr %8, align 8
  %30 = shl i64 %indvars.iv, 3
  %uglygep17 = getelementptr i8, ptr %29, i64 %30
  %31 = load i64, ptr %uglygep17, align 8
  %32 = and i64 %31, 9223372036854775807
  %33 = and i64 %31, 9218868437227405312
  %34 = icmp eq i64 %32, 0
  %35 = icmp ne i64 %33, 0
  %36 = icmp ne i64 %33, 9218868437227405312
  %37 = and i1 %35, %36
  %38 = or i1 %34, %37
  br i1 %38, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %39 = load ptr, ptr %0, align 8
  %40 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %39, i64 0, i32 9, i32 1
  %41 = load ptr, ptr %40, align 8
  %42 = getelementptr i64, ptr %41, i64 1
  %43 = atomicrmw add ptr %42, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %44 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %44, i64 8
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %30
  %45 = load i64, ptr %uglygep19, align 8
  %46 = and i64 %45, 9223372036854775807
  %47 = and i64 %45, 9218868437227405312
  %48 = icmp eq i64 %46, 0
  %49 = icmp ne i64 %47, 0
  %50 = icmp ne i64 %47, 9218868437227405312
  %51 = and i1 %49, %50
  %52 = or i1 %48, %51
  br i1 %52, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %53 = load ptr, ptr %0, align 8
  %54 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %53, i64 0, i32 9, i32 1
  %55 = load ptr, ptr %54, align 8
  %56 = getelementptr i64, ptr %55, i64 1
  %57 = atomicrmw add ptr %56, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %58 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %58, i64 16
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %30
  %59 = load i64, ptr %uglygep16, align 8
  %60 = and i64 %59, 9223372036854775807
  %61 = and i64 %59, 9218868437227405312
  %62 = icmp eq i64 %60, 0
  %63 = icmp ne i64 %61, 0
  %64 = icmp ne i64 %61, 9218868437227405312
  %65 = and i1 %63, %64
  %66 = or i1 %62, %65
  br i1 %66, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %67 = load ptr, ptr %0, align 8
  %68 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %67, i64 0, i32 9, i32 1
  %69 = load ptr, ptr %68, align 8
  %70 = getelementptr i64, ptr %69, i64 1
  %71 = atomicrmw add ptr %70, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %72 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %72, i64 24
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %30
  %73 = load i64, ptr %uglygep14, align 8
  %74 = and i64 %73, 9223372036854775807
  %75 = and i64 %73, 9218868437227405312
  %76 = icmp eq i64 %74, 0
  %77 = icmp ne i64 %75, 0
  %78 = icmp ne i64 %75, 9218868437227405312
  %79 = and i1 %77, %78
  %80 = or i1 %76, %79
  br i1 %80, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %81 = load ptr, ptr %0, align 8
  %82 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %81, i64 0, i32 9, i32 1
  %83 = load ptr, ptr %82, align 8
  %84 = getelementptr i64, ptr %83, i64 1
  %85 = atomicrmw add ptr %84, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %86 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %86, i64 32
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %30
  %87 = load i64, ptr %uglygep12, align 8
  %88 = and i64 %87, 9223372036854775807
  %89 = and i64 %87, 9218868437227405312
  %90 = icmp eq i64 %88, 0
  %91 = icmp ne i64 %89, 0
  %92 = icmp ne i64 %89, 9218868437227405312
  %93 = and i1 %91, %92
  %94 = or i1 %90, %93
  br i1 %94, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %95 = load ptr, ptr %0, align 8
  %96 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %95, i64 0, i32 9, i32 1
  %97 = load ptr, ptr %96, align 8
  %98 = getelementptr i64, ptr %97, i64 1
  %99 = atomicrmw add ptr %98, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %100 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %100, i64 40
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %30
  %101 = load i64, ptr %uglygep10, align 8
  %102 = and i64 %101, 9223372036854775807
  %103 = and i64 %101, 9218868437227405312
  %104 = icmp eq i64 %102, 0
  %105 = icmp ne i64 %103, 0
  %106 = icmp ne i64 %103, 9218868437227405312
  %107 = and i1 %105, %106
  %108 = or i1 %104, %107
  br i1 %108, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %109 = load ptr, ptr %0, align 8
  %110 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %109, i64 0, i32 9, i32 1
  %111 = load ptr, ptr %110, align 8
  %112 = getelementptr i64, ptr %111, i64 1
  %113 = atomicrmw add ptr %112, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %114 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %114, i64 48
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %30
  %115 = load i64, ptr %uglygep8, align 8
  %116 = and i64 %115, 9223372036854775807
  %117 = and i64 %115, 9218868437227405312
  %118 = icmp eq i64 %116, 0
  %119 = icmp ne i64 %117, 0
  %120 = icmp ne i64 %117, 9218868437227405312
  %121 = and i1 %119, %120
  %122 = or i1 %118, %121
  br i1 %122, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %123 = load ptr, ptr %0, align 8
  %124 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %123, i64 0, i32 9, i32 1
  %125 = load ptr, ptr %124, align 8
  %126 = getelementptr i64, ptr %125, i64 1
  %127 = atomicrmw add ptr %126, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %128 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %128, i64 56
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %30
  %129 = load i64, ptr %uglygep6, align 8
  %130 = and i64 %129, 9223372036854775807
  %131 = and i64 %129, 9218868437227405312
  %132 = icmp eq i64 %130, 0
  %133 = icmp ne i64 %131, 0
  %134 = icmp ne i64 %131, 9218868437227405312
  %135 = and i1 %133, %134
  %136 = or i1 %132, %135
  br i1 %136, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %137 = load ptr, ptr %0, align 8
  %138 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %137, i64 0, i32 9, i32 1
  %139 = load ptr, ptr %138, align 8
  %140 = getelementptr i64, ptr %139, i64 1
  %141 = atomicrmw add ptr %140, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_21_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.20, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.20(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 3, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %10 = xor i64 %9, -1
  %11 = add nsw i64 %10, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %9, %for_loop_body.prol.preheader ]
  %12 = load ptr, ptr %8, align 8
  %13 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep20 = getelementptr i8, ptr %12, i64 %13
  %14 = load i64, ptr %uglygep20, align 8
  %15 = and i64 %14, 9223372036854775807
  %16 = and i64 %14, 9218868437227405312
  %17 = icmp eq i64 %15, 0
  %18 = icmp ne i64 %16, 0
  %19 = icmp ne i64 %16, 9218868437227405312
  %20 = and i1 %18, %19
  %21 = or i1 %17, %20
  br i1 %21, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %22 = load ptr, ptr %0, align 8
  %23 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %22, i64 0, i32 9, i32 1
  %24 = load ptr, ptr %23, align 8
  %25 = getelementptr i64, ptr %24, i64 1
  %26 = atomicrmw add ptr %25, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !27

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %27 = add i64 %xtraiter, %9
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %9, %for_loop_body.lr.ph ], [ %27, %for_loop_body.prol.loopexit.loopexit ]
  %28 = icmp ult i64 %11, 7
  br i1 %28, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %29 = load ptr, ptr %8, align 8
  %30 = shl i64 %indvars.iv, 3
  %uglygep17 = getelementptr i8, ptr %29, i64 %30
  %31 = load i64, ptr %uglygep17, align 8
  %32 = and i64 %31, 9223372036854775807
  %33 = and i64 %31, 9218868437227405312
  %34 = icmp eq i64 %32, 0
  %35 = icmp ne i64 %33, 0
  %36 = icmp ne i64 %33, 9218868437227405312
  %37 = and i1 %35, %36
  %38 = or i1 %34, %37
  br i1 %38, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %39 = load ptr, ptr %0, align 8
  %40 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %39, i64 0, i32 9, i32 1
  %41 = load ptr, ptr %40, align 8
  %42 = getelementptr i64, ptr %41, i64 1
  %43 = atomicrmw add ptr %42, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %44 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %44, i64 8
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %30
  %45 = load i64, ptr %uglygep19, align 8
  %46 = and i64 %45, 9223372036854775807
  %47 = and i64 %45, 9218868437227405312
  %48 = icmp eq i64 %46, 0
  %49 = icmp ne i64 %47, 0
  %50 = icmp ne i64 %47, 9218868437227405312
  %51 = and i1 %49, %50
  %52 = or i1 %48, %51
  br i1 %52, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %53 = load ptr, ptr %0, align 8
  %54 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %53, i64 0, i32 9, i32 1
  %55 = load ptr, ptr %54, align 8
  %56 = getelementptr i64, ptr %55, i64 1
  %57 = atomicrmw add ptr %56, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %58 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %58, i64 16
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %30
  %59 = load i64, ptr %uglygep16, align 8
  %60 = and i64 %59, 9223372036854775807
  %61 = and i64 %59, 9218868437227405312
  %62 = icmp eq i64 %60, 0
  %63 = icmp ne i64 %61, 0
  %64 = icmp ne i64 %61, 9218868437227405312
  %65 = and i1 %63, %64
  %66 = or i1 %62, %65
  br i1 %66, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %67 = load ptr, ptr %0, align 8
  %68 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %67, i64 0, i32 9, i32 1
  %69 = load ptr, ptr %68, align 8
  %70 = getelementptr i64, ptr %69, i64 1
  %71 = atomicrmw add ptr %70, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %72 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %72, i64 24
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %30
  %73 = load i64, ptr %uglygep14, align 8
  %74 = and i64 %73, 9223372036854775807
  %75 = and i64 %73, 9218868437227405312
  %76 = icmp eq i64 %74, 0
  %77 = icmp ne i64 %75, 0
  %78 = icmp ne i64 %75, 9218868437227405312
  %79 = and i1 %77, %78
  %80 = or i1 %76, %79
  br i1 %80, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %81 = load ptr, ptr %0, align 8
  %82 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %81, i64 0, i32 9, i32 1
  %83 = load ptr, ptr %82, align 8
  %84 = getelementptr i64, ptr %83, i64 1
  %85 = atomicrmw add ptr %84, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %86 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %86, i64 32
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %30
  %87 = load i64, ptr %uglygep12, align 8
  %88 = and i64 %87, 9223372036854775807
  %89 = and i64 %87, 9218868437227405312
  %90 = icmp eq i64 %88, 0
  %91 = icmp ne i64 %89, 0
  %92 = icmp ne i64 %89, 9218868437227405312
  %93 = and i1 %91, %92
  %94 = or i1 %90, %93
  br i1 %94, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %95 = load ptr, ptr %0, align 8
  %96 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %95, i64 0, i32 9, i32 1
  %97 = load ptr, ptr %96, align 8
  %98 = getelementptr i64, ptr %97, i64 1
  %99 = atomicrmw add ptr %98, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %100 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %100, i64 40
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %30
  %101 = load i64, ptr %uglygep10, align 8
  %102 = and i64 %101, 9223372036854775807
  %103 = and i64 %101, 9218868437227405312
  %104 = icmp eq i64 %102, 0
  %105 = icmp ne i64 %103, 0
  %106 = icmp ne i64 %103, 9218868437227405312
  %107 = and i1 %105, %106
  %108 = or i1 %104, %107
  br i1 %108, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %109 = load ptr, ptr %0, align 8
  %110 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %109, i64 0, i32 9, i32 1
  %111 = load ptr, ptr %110, align 8
  %112 = getelementptr i64, ptr %111, i64 1
  %113 = atomicrmw add ptr %112, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %114 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %114, i64 48
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %30
  %115 = load i64, ptr %uglygep8, align 8
  %116 = and i64 %115, 9223372036854775807
  %117 = and i64 %115, 9218868437227405312
  %118 = icmp eq i64 %116, 0
  %119 = icmp ne i64 %117, 0
  %120 = icmp ne i64 %117, 9218868437227405312
  %121 = and i1 %119, %120
  %122 = or i1 %118, %121
  br i1 %122, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %123 = load ptr, ptr %0, align 8
  %124 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %123, i64 0, i32 9, i32 1
  %125 = load ptr, ptr %124, align 8
  %126 = getelementptr i64, ptr %125, i64 1
  %127 = atomicrmw add ptr %126, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %128 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %128, i64 56
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %30
  %129 = load i64, ptr %uglygep6, align 8
  %130 = and i64 %129, 9223372036854775807
  %131 = and i64 %129, 9218868437227405312
  %132 = icmp eq i64 %130, 0
  %133 = icmp ne i64 %131, 0
  %134 = icmp ne i64 %131, 9218868437227405312
  %135 = and i1 %133, %134
  %136 = or i1 %132, %135
  br i1 %136, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %137 = load ptr, ptr %0, align 8
  %138 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %137, i64 0, i32 9, i32 1
  %139 = load ptr, ptr %138, align 8
  %140 = getelementptr i64, ptr %139, i64 1
  %141 = atomicrmw add ptr %140, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_22_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.21, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.21(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 4, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %10 = xor i64 %9, -1
  %11 = add nsw i64 %10, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %9, %for_loop_body.prol.preheader ]
  %12 = load ptr, ptr %8, align 8
  %13 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep20 = getelementptr i8, ptr %12, i64 %13
  %14 = load i64, ptr %uglygep20, align 8
  %15 = and i64 %14, 9223372036854775807
  %16 = and i64 %14, 9218868437227405312
  %17 = icmp eq i64 %15, 0
  %18 = icmp ne i64 %16, 0
  %19 = icmp ne i64 %16, 9218868437227405312
  %20 = and i1 %18, %19
  %21 = or i1 %17, %20
  br i1 %21, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %22 = load ptr, ptr %0, align 8
  %23 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %22, i64 0, i32 9, i32 1
  %24 = load ptr, ptr %23, align 8
  %25 = getelementptr i64, ptr %24, i64 1
  %26 = atomicrmw add ptr %25, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !28

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %27 = add i64 %xtraiter, %9
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %9, %for_loop_body.lr.ph ], [ %27, %for_loop_body.prol.loopexit.loopexit ]
  %28 = icmp ult i64 %11, 7
  br i1 %28, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %29 = load ptr, ptr %8, align 8
  %30 = shl i64 %indvars.iv, 3
  %uglygep17 = getelementptr i8, ptr %29, i64 %30
  %31 = load i64, ptr %uglygep17, align 8
  %32 = and i64 %31, 9223372036854775807
  %33 = and i64 %31, 9218868437227405312
  %34 = icmp eq i64 %32, 0
  %35 = icmp ne i64 %33, 0
  %36 = icmp ne i64 %33, 9218868437227405312
  %37 = and i1 %35, %36
  %38 = or i1 %34, %37
  br i1 %38, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %39 = load ptr, ptr %0, align 8
  %40 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %39, i64 0, i32 9, i32 1
  %41 = load ptr, ptr %40, align 8
  %42 = getelementptr i64, ptr %41, i64 1
  %43 = atomicrmw add ptr %42, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %44 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %44, i64 8
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %30
  %45 = load i64, ptr %uglygep19, align 8
  %46 = and i64 %45, 9223372036854775807
  %47 = and i64 %45, 9218868437227405312
  %48 = icmp eq i64 %46, 0
  %49 = icmp ne i64 %47, 0
  %50 = icmp ne i64 %47, 9218868437227405312
  %51 = and i1 %49, %50
  %52 = or i1 %48, %51
  br i1 %52, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %53 = load ptr, ptr %0, align 8
  %54 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %53, i64 0, i32 9, i32 1
  %55 = load ptr, ptr %54, align 8
  %56 = getelementptr i64, ptr %55, i64 1
  %57 = atomicrmw add ptr %56, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %58 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %58, i64 16
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %30
  %59 = load i64, ptr %uglygep16, align 8
  %60 = and i64 %59, 9223372036854775807
  %61 = and i64 %59, 9218868437227405312
  %62 = icmp eq i64 %60, 0
  %63 = icmp ne i64 %61, 0
  %64 = icmp ne i64 %61, 9218868437227405312
  %65 = and i1 %63, %64
  %66 = or i1 %62, %65
  br i1 %66, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %67 = load ptr, ptr %0, align 8
  %68 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %67, i64 0, i32 9, i32 1
  %69 = load ptr, ptr %68, align 8
  %70 = getelementptr i64, ptr %69, i64 1
  %71 = atomicrmw add ptr %70, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %72 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %72, i64 24
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %30
  %73 = load i64, ptr %uglygep14, align 8
  %74 = and i64 %73, 9223372036854775807
  %75 = and i64 %73, 9218868437227405312
  %76 = icmp eq i64 %74, 0
  %77 = icmp ne i64 %75, 0
  %78 = icmp ne i64 %75, 9218868437227405312
  %79 = and i1 %77, %78
  %80 = or i1 %76, %79
  br i1 %80, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %81 = load ptr, ptr %0, align 8
  %82 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %81, i64 0, i32 9, i32 1
  %83 = load ptr, ptr %82, align 8
  %84 = getelementptr i64, ptr %83, i64 1
  %85 = atomicrmw add ptr %84, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %86 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %86, i64 32
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %30
  %87 = load i64, ptr %uglygep12, align 8
  %88 = and i64 %87, 9223372036854775807
  %89 = and i64 %87, 9218868437227405312
  %90 = icmp eq i64 %88, 0
  %91 = icmp ne i64 %89, 0
  %92 = icmp ne i64 %89, 9218868437227405312
  %93 = and i1 %91, %92
  %94 = or i1 %90, %93
  br i1 %94, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %95 = load ptr, ptr %0, align 8
  %96 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %95, i64 0, i32 9, i32 1
  %97 = load ptr, ptr %96, align 8
  %98 = getelementptr i64, ptr %97, i64 1
  %99 = atomicrmw add ptr %98, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %100 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %100, i64 40
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %30
  %101 = load i64, ptr %uglygep10, align 8
  %102 = and i64 %101, 9223372036854775807
  %103 = and i64 %101, 9218868437227405312
  %104 = icmp eq i64 %102, 0
  %105 = icmp ne i64 %103, 0
  %106 = icmp ne i64 %103, 9218868437227405312
  %107 = and i1 %105, %106
  %108 = or i1 %104, %107
  br i1 %108, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %109 = load ptr, ptr %0, align 8
  %110 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %109, i64 0, i32 9, i32 1
  %111 = load ptr, ptr %110, align 8
  %112 = getelementptr i64, ptr %111, i64 1
  %113 = atomicrmw add ptr %112, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %114 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %114, i64 48
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %30
  %115 = load i64, ptr %uglygep8, align 8
  %116 = and i64 %115, 9223372036854775807
  %117 = and i64 %115, 9218868437227405312
  %118 = icmp eq i64 %116, 0
  %119 = icmp ne i64 %117, 0
  %120 = icmp ne i64 %117, 9218868437227405312
  %121 = and i1 %119, %120
  %122 = or i1 %118, %121
  br i1 %122, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %123 = load ptr, ptr %0, align 8
  %124 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %123, i64 0, i32 9, i32 1
  %125 = load ptr, ptr %124, align 8
  %126 = getelementptr i64, ptr %125, i64 1
  %127 = atomicrmw add ptr %126, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %128 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %128, i64 56
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %30
  %129 = load i64, ptr %uglygep6, align 8
  %130 = and i64 %129, 9223372036854775807
  %131 = and i64 %129, 9218868437227405312
  %132 = icmp eq i64 %130, 0
  %133 = icmp ne i64 %131, 0
  %134 = icmp ne i64 %131, 9218868437227405312
  %135 = and i1 %133, %134
  %136 = or i1 %132, %135
  br i1 %136, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %137 = load ptr, ptr %0, align 8
  %138 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %137, i64 0, i32 9, i32 1
  %139 = load ptr, ptr %138, align 8
  %140 = getelementptr i64, ptr %139, i64 1
  %141 = atomicrmw add ptr %140, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_23_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.22, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.22(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 4, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 4, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv6 = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next7, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = add nsw i64 %indvars.iv.prol, %15
  %17 = getelementptr double, ptr %13, i64 %16
  %18 = load i64, ptr %17, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next7 = add nsw i64 %lsr.iv6, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next7, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !29

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  %33 = sub i64 0, %wide.trip.count
  %34 = add nsw i64 %indvars.iv.unr, 7
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %lsr.iv = phi i64 [ %34, %for_loop_body.preheader ], [ %lsr.iv.next, %after_if.7 ]
  %35 = load ptr, ptr %8, align 8
  %36 = load i32, ptr %9, align 4
  %37 = sext i32 %36 to i64
  %38 = add i64 %lsr.iv, %37
  %39 = getelementptr double, ptr %35, i64 %38
  %40 = getelementptr double, ptr %39, i64 -7
  %41 = load i64, ptr %40, align 8
  %42 = and i64 %41, 9223372036854775807
  %43 = and i64 %41, 9218868437227405312
  %44 = icmp eq i64 %42, 0
  %45 = icmp ne i64 %43, 0
  %46 = icmp ne i64 %43, 9218868437227405312
  %47 = and i1 %45, %46
  %48 = or i1 %44, %47
  br i1 %48, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %49 = load ptr, ptr %0, align 8
  %50 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %49, i64 0, i32 9, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = getelementptr i64, ptr %51, i64 1
  %53 = atomicrmw add ptr %52, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %54 = load ptr, ptr %8, align 8
  %55 = load i32, ptr %9, align 4
  %56 = sext i32 %55 to i64
  %57 = add i64 %lsr.iv, %56
  %58 = getelementptr double, ptr %54, i64 %57
  %59 = getelementptr double, ptr %58, i64 -6
  %60 = load i64, ptr %59, align 8
  %61 = and i64 %60, 9223372036854775807
  %62 = and i64 %60, 9218868437227405312
  %63 = icmp eq i64 %61, 0
  %64 = icmp ne i64 %62, 0
  %65 = icmp ne i64 %62, 9218868437227405312
  %66 = and i1 %64, %65
  %67 = or i1 %63, %66
  br i1 %67, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %68 = load ptr, ptr %0, align 8
  %69 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %68, i64 0, i32 9, i32 1
  %70 = load ptr, ptr %69, align 8
  %71 = getelementptr i64, ptr %70, i64 1
  %72 = atomicrmw add ptr %71, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %73 = load ptr, ptr %8, align 8
  %74 = load i32, ptr %9, align 4
  %75 = sext i32 %74 to i64
  %76 = add i64 %lsr.iv, %75
  %77 = getelementptr double, ptr %73, i64 %76
  %78 = getelementptr double, ptr %77, i64 -5
  %79 = load i64, ptr %78, align 8
  %80 = and i64 %79, 9223372036854775807
  %81 = and i64 %79, 9218868437227405312
  %82 = icmp eq i64 %80, 0
  %83 = icmp ne i64 %81, 0
  %84 = icmp ne i64 %81, 9218868437227405312
  %85 = and i1 %83, %84
  %86 = or i1 %82, %85
  br i1 %86, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %87 = load ptr, ptr %0, align 8
  %88 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %87, i64 0, i32 9, i32 1
  %89 = load ptr, ptr %88, align 8
  %90 = getelementptr i64, ptr %89, i64 1
  %91 = atomicrmw add ptr %90, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %92 = load ptr, ptr %8, align 8
  %93 = load i32, ptr %9, align 4
  %94 = sext i32 %93 to i64
  %95 = add i64 %lsr.iv, %94
  %96 = getelementptr double, ptr %92, i64 %95
  %97 = getelementptr double, ptr %96, i64 -4
  %98 = load i64, ptr %97, align 8
  %99 = and i64 %98, 9223372036854775807
  %100 = and i64 %98, 9218868437227405312
  %101 = icmp eq i64 %99, 0
  %102 = icmp ne i64 %100, 0
  %103 = icmp ne i64 %100, 9218868437227405312
  %104 = and i1 %102, %103
  %105 = or i1 %101, %104
  br i1 %105, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %106 = load ptr, ptr %0, align 8
  %107 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %106, i64 0, i32 9, i32 1
  %108 = load ptr, ptr %107, align 8
  %109 = getelementptr i64, ptr %108, i64 1
  %110 = atomicrmw add ptr %109, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %111 = load ptr, ptr %8, align 8
  %112 = load i32, ptr %9, align 4
  %113 = sext i32 %112 to i64
  %114 = add i64 %lsr.iv, %113
  %115 = getelementptr double, ptr %111, i64 %114
  %116 = getelementptr double, ptr %115, i64 -3
  %117 = load i64, ptr %116, align 8
  %118 = and i64 %117, 9223372036854775807
  %119 = and i64 %117, 9218868437227405312
  %120 = icmp eq i64 %118, 0
  %121 = icmp ne i64 %119, 0
  %122 = icmp ne i64 %119, 9218868437227405312
  %123 = and i1 %121, %122
  %124 = or i1 %120, %123
  br i1 %124, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %125 = load ptr, ptr %0, align 8
  %126 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %125, i64 0, i32 9, i32 1
  %127 = load ptr, ptr %126, align 8
  %128 = getelementptr i64, ptr %127, i64 1
  %129 = atomicrmw add ptr %128, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %130 = load ptr, ptr %8, align 8
  %131 = load i32, ptr %9, align 4
  %132 = sext i32 %131 to i64
  %133 = add i64 %lsr.iv, %132
  %134 = getelementptr double, ptr %130, i64 %133
  %135 = getelementptr double, ptr %134, i64 -2
  %136 = load i64, ptr %135, align 8
  %137 = and i64 %136, 9223372036854775807
  %138 = and i64 %136, 9218868437227405312
  %139 = icmp eq i64 %137, 0
  %140 = icmp ne i64 %138, 0
  %141 = icmp ne i64 %138, 9218868437227405312
  %142 = and i1 %140, %141
  %143 = or i1 %139, %142
  br i1 %143, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %144 = load ptr, ptr %0, align 8
  %145 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %144, i64 0, i32 9, i32 1
  %146 = load ptr, ptr %145, align 8
  %147 = getelementptr i64, ptr %146, i64 1
  %148 = atomicrmw add ptr %147, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %149 = load ptr, ptr %8, align 8
  %150 = load i32, ptr %9, align 4
  %151 = sext i32 %150 to i64
  %152 = add i64 %lsr.iv, %151
  %153 = getelementptr double, ptr %149, i64 %152
  %154 = getelementptr double, ptr %153, i64 -1
  %155 = load i64, ptr %154, align 8
  %156 = and i64 %155, 9223372036854775807
  %157 = and i64 %155, 9218868437227405312
  %158 = icmp eq i64 %156, 0
  %159 = icmp ne i64 %157, 0
  %160 = icmp ne i64 %157, 9218868437227405312
  %161 = and i1 %159, %160
  %162 = or i1 %158, %161
  br i1 %162, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %163 = load ptr, ptr %0, align 8
  %164 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %163, i64 0, i32 9, i32 1
  %165 = load ptr, ptr %164, align 8
  %166 = getelementptr i64, ptr %165, i64 1
  %167 = atomicrmw add ptr %166, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %168 = load ptr, ptr %8, align 8
  %169 = load i32, ptr %9, align 4
  %170 = sext i32 %169 to i64
  %171 = add nsw i64 %lsr.iv, %170
  %172 = getelementptr double, ptr %168, i64 %171
  %173 = load i64, ptr %172, align 8
  %174 = and i64 %173, 9223372036854775807
  %175 = and i64 %173, 9218868437227405312
  %176 = icmp eq i64 %174, 0
  %177 = icmp ne i64 %175, 0
  %178 = icmp ne i64 %175, 9218868437227405312
  %179 = and i1 %177, %178
  %180 = or i1 %176, %179
  br i1 %180, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %181 = load ptr, ptr %0, align 8
  %182 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %181, i64 0, i32 9, i32 1
  %183 = load ptr, ptr %182, align 8
  %184 = getelementptr i64, ptr %183, i64 1
  %185 = atomicrmw add ptr %184, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %lsr.iv.next = add i64 %lsr.iv, 8
  %186 = add i64 %33, %lsr.iv.next
  %exitcond.not.7 = icmp eq i64 %186, 7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_24_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.23, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.23(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 4, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 4, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = shl nsw i64 %15, 4
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !30

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = shl nsw i64 %35, 4
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = shl nsw i64 %53, 4
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = shl nsw i64 %70, 4
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = shl nsw i64 %87, 4
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = shl nsw i64 %104, 4
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = shl nsw i64 %121, 4
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = shl nsw i64 %138, 4
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = shl nsw i64 %155, 4
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_25_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.24, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.24(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 5, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %10 = xor i64 %9, -1
  %11 = add nsw i64 %10, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %9, %for_loop_body.prol.preheader ]
  %12 = load ptr, ptr %8, align 8
  %13 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep20 = getelementptr i8, ptr %12, i64 %13
  %14 = load i64, ptr %uglygep20, align 8
  %15 = and i64 %14, 9223372036854775807
  %16 = and i64 %14, 9218868437227405312
  %17 = icmp eq i64 %15, 0
  %18 = icmp ne i64 %16, 0
  %19 = icmp ne i64 %16, 9218868437227405312
  %20 = and i1 %18, %19
  %21 = or i1 %17, %20
  br i1 %21, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %22 = load ptr, ptr %0, align 8
  %23 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %22, i64 0, i32 9, i32 1
  %24 = load ptr, ptr %23, align 8
  %25 = getelementptr i64, ptr %24, i64 1
  %26 = atomicrmw add ptr %25, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !31

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %27 = add i64 %xtraiter, %9
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %9, %for_loop_body.lr.ph ], [ %27, %for_loop_body.prol.loopexit.loopexit ]
  %28 = icmp ult i64 %11, 7
  br i1 %28, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %29 = load ptr, ptr %8, align 8
  %30 = shl i64 %indvars.iv, 3
  %uglygep17 = getelementptr i8, ptr %29, i64 %30
  %31 = load i64, ptr %uglygep17, align 8
  %32 = and i64 %31, 9223372036854775807
  %33 = and i64 %31, 9218868437227405312
  %34 = icmp eq i64 %32, 0
  %35 = icmp ne i64 %33, 0
  %36 = icmp ne i64 %33, 9218868437227405312
  %37 = and i1 %35, %36
  %38 = or i1 %34, %37
  br i1 %38, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %39 = load ptr, ptr %0, align 8
  %40 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %39, i64 0, i32 9, i32 1
  %41 = load ptr, ptr %40, align 8
  %42 = getelementptr i64, ptr %41, i64 1
  %43 = atomicrmw add ptr %42, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %44 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %44, i64 8
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %30
  %45 = load i64, ptr %uglygep19, align 8
  %46 = and i64 %45, 9223372036854775807
  %47 = and i64 %45, 9218868437227405312
  %48 = icmp eq i64 %46, 0
  %49 = icmp ne i64 %47, 0
  %50 = icmp ne i64 %47, 9218868437227405312
  %51 = and i1 %49, %50
  %52 = or i1 %48, %51
  br i1 %52, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %53 = load ptr, ptr %0, align 8
  %54 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %53, i64 0, i32 9, i32 1
  %55 = load ptr, ptr %54, align 8
  %56 = getelementptr i64, ptr %55, i64 1
  %57 = atomicrmw add ptr %56, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %58 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %58, i64 16
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %30
  %59 = load i64, ptr %uglygep16, align 8
  %60 = and i64 %59, 9223372036854775807
  %61 = and i64 %59, 9218868437227405312
  %62 = icmp eq i64 %60, 0
  %63 = icmp ne i64 %61, 0
  %64 = icmp ne i64 %61, 9218868437227405312
  %65 = and i1 %63, %64
  %66 = or i1 %62, %65
  br i1 %66, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %67 = load ptr, ptr %0, align 8
  %68 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %67, i64 0, i32 9, i32 1
  %69 = load ptr, ptr %68, align 8
  %70 = getelementptr i64, ptr %69, i64 1
  %71 = atomicrmw add ptr %70, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %72 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %72, i64 24
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %30
  %73 = load i64, ptr %uglygep14, align 8
  %74 = and i64 %73, 9223372036854775807
  %75 = and i64 %73, 9218868437227405312
  %76 = icmp eq i64 %74, 0
  %77 = icmp ne i64 %75, 0
  %78 = icmp ne i64 %75, 9218868437227405312
  %79 = and i1 %77, %78
  %80 = or i1 %76, %79
  br i1 %80, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %81 = load ptr, ptr %0, align 8
  %82 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %81, i64 0, i32 9, i32 1
  %83 = load ptr, ptr %82, align 8
  %84 = getelementptr i64, ptr %83, i64 1
  %85 = atomicrmw add ptr %84, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %86 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %86, i64 32
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %30
  %87 = load i64, ptr %uglygep12, align 8
  %88 = and i64 %87, 9223372036854775807
  %89 = and i64 %87, 9218868437227405312
  %90 = icmp eq i64 %88, 0
  %91 = icmp ne i64 %89, 0
  %92 = icmp ne i64 %89, 9218868437227405312
  %93 = and i1 %91, %92
  %94 = or i1 %90, %93
  br i1 %94, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %95 = load ptr, ptr %0, align 8
  %96 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %95, i64 0, i32 9, i32 1
  %97 = load ptr, ptr %96, align 8
  %98 = getelementptr i64, ptr %97, i64 1
  %99 = atomicrmw add ptr %98, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %100 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %100, i64 40
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %30
  %101 = load i64, ptr %uglygep10, align 8
  %102 = and i64 %101, 9223372036854775807
  %103 = and i64 %101, 9218868437227405312
  %104 = icmp eq i64 %102, 0
  %105 = icmp ne i64 %103, 0
  %106 = icmp ne i64 %103, 9218868437227405312
  %107 = and i1 %105, %106
  %108 = or i1 %104, %107
  br i1 %108, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %109 = load ptr, ptr %0, align 8
  %110 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %109, i64 0, i32 9, i32 1
  %111 = load ptr, ptr %110, align 8
  %112 = getelementptr i64, ptr %111, i64 1
  %113 = atomicrmw add ptr %112, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %114 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %114, i64 48
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %30
  %115 = load i64, ptr %uglygep8, align 8
  %116 = and i64 %115, 9223372036854775807
  %117 = and i64 %115, 9218868437227405312
  %118 = icmp eq i64 %116, 0
  %119 = icmp ne i64 %117, 0
  %120 = icmp ne i64 %117, 9218868437227405312
  %121 = and i1 %119, %120
  %122 = or i1 %118, %121
  br i1 %122, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %123 = load ptr, ptr %0, align 8
  %124 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %123, i64 0, i32 9, i32 1
  %125 = load ptr, ptr %124, align 8
  %126 = getelementptr i64, ptr %125, i64 1
  %127 = atomicrmw add ptr %126, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %128 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %128, i64 56
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %30
  %129 = load i64, ptr %uglygep6, align 8
  %130 = and i64 %129, 9223372036854775807
  %131 = and i64 %129, 9218868437227405312
  %132 = icmp eq i64 %130, 0
  %133 = icmp ne i64 %131, 0
  %134 = icmp ne i64 %131, 9218868437227405312
  %135 = and i1 %133, %134
  %136 = or i1 %132, %135
  br i1 %136, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %137 = load ptr, ptr %0, align 8
  %138 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %137, i64 0, i32 9, i32 1
  %139 = load ptr, ptr %138, align 8
  %140 = getelementptr i64, ptr %139, i64 1
  %141 = atomicrmw add ptr %140, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_26_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.25, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.25(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 5, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 5, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv6 = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next7, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = add nsw i64 %indvars.iv.prol, %15
  %17 = getelementptr double, ptr %13, i64 %16
  %18 = load i64, ptr %17, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next7 = add nsw i64 %lsr.iv6, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next7, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !32

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  %33 = sub i64 0, %wide.trip.count
  %34 = add nsw i64 %indvars.iv.unr, 7
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %lsr.iv = phi i64 [ %34, %for_loop_body.preheader ], [ %lsr.iv.next, %after_if.7 ]
  %35 = load ptr, ptr %8, align 8
  %36 = load i32, ptr %9, align 4
  %37 = sext i32 %36 to i64
  %38 = add i64 %lsr.iv, %37
  %39 = getelementptr double, ptr %35, i64 %38
  %40 = getelementptr double, ptr %39, i64 -7
  %41 = load i64, ptr %40, align 8
  %42 = and i64 %41, 9223372036854775807
  %43 = and i64 %41, 9218868437227405312
  %44 = icmp eq i64 %42, 0
  %45 = icmp ne i64 %43, 0
  %46 = icmp ne i64 %43, 9218868437227405312
  %47 = and i1 %45, %46
  %48 = or i1 %44, %47
  br i1 %48, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %49 = load ptr, ptr %0, align 8
  %50 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %49, i64 0, i32 9, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = getelementptr i64, ptr %51, i64 1
  %53 = atomicrmw add ptr %52, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %54 = load ptr, ptr %8, align 8
  %55 = load i32, ptr %9, align 4
  %56 = sext i32 %55 to i64
  %57 = add i64 %lsr.iv, %56
  %58 = getelementptr double, ptr %54, i64 %57
  %59 = getelementptr double, ptr %58, i64 -6
  %60 = load i64, ptr %59, align 8
  %61 = and i64 %60, 9223372036854775807
  %62 = and i64 %60, 9218868437227405312
  %63 = icmp eq i64 %61, 0
  %64 = icmp ne i64 %62, 0
  %65 = icmp ne i64 %62, 9218868437227405312
  %66 = and i1 %64, %65
  %67 = or i1 %63, %66
  br i1 %67, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %68 = load ptr, ptr %0, align 8
  %69 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %68, i64 0, i32 9, i32 1
  %70 = load ptr, ptr %69, align 8
  %71 = getelementptr i64, ptr %70, i64 1
  %72 = atomicrmw add ptr %71, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %73 = load ptr, ptr %8, align 8
  %74 = load i32, ptr %9, align 4
  %75 = sext i32 %74 to i64
  %76 = add i64 %lsr.iv, %75
  %77 = getelementptr double, ptr %73, i64 %76
  %78 = getelementptr double, ptr %77, i64 -5
  %79 = load i64, ptr %78, align 8
  %80 = and i64 %79, 9223372036854775807
  %81 = and i64 %79, 9218868437227405312
  %82 = icmp eq i64 %80, 0
  %83 = icmp ne i64 %81, 0
  %84 = icmp ne i64 %81, 9218868437227405312
  %85 = and i1 %83, %84
  %86 = or i1 %82, %85
  br i1 %86, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %87 = load ptr, ptr %0, align 8
  %88 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %87, i64 0, i32 9, i32 1
  %89 = load ptr, ptr %88, align 8
  %90 = getelementptr i64, ptr %89, i64 1
  %91 = atomicrmw add ptr %90, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %92 = load ptr, ptr %8, align 8
  %93 = load i32, ptr %9, align 4
  %94 = sext i32 %93 to i64
  %95 = add i64 %lsr.iv, %94
  %96 = getelementptr double, ptr %92, i64 %95
  %97 = getelementptr double, ptr %96, i64 -4
  %98 = load i64, ptr %97, align 8
  %99 = and i64 %98, 9223372036854775807
  %100 = and i64 %98, 9218868437227405312
  %101 = icmp eq i64 %99, 0
  %102 = icmp ne i64 %100, 0
  %103 = icmp ne i64 %100, 9218868437227405312
  %104 = and i1 %102, %103
  %105 = or i1 %101, %104
  br i1 %105, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %106 = load ptr, ptr %0, align 8
  %107 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %106, i64 0, i32 9, i32 1
  %108 = load ptr, ptr %107, align 8
  %109 = getelementptr i64, ptr %108, i64 1
  %110 = atomicrmw add ptr %109, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %111 = load ptr, ptr %8, align 8
  %112 = load i32, ptr %9, align 4
  %113 = sext i32 %112 to i64
  %114 = add i64 %lsr.iv, %113
  %115 = getelementptr double, ptr %111, i64 %114
  %116 = getelementptr double, ptr %115, i64 -3
  %117 = load i64, ptr %116, align 8
  %118 = and i64 %117, 9223372036854775807
  %119 = and i64 %117, 9218868437227405312
  %120 = icmp eq i64 %118, 0
  %121 = icmp ne i64 %119, 0
  %122 = icmp ne i64 %119, 9218868437227405312
  %123 = and i1 %121, %122
  %124 = or i1 %120, %123
  br i1 %124, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %125 = load ptr, ptr %0, align 8
  %126 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %125, i64 0, i32 9, i32 1
  %127 = load ptr, ptr %126, align 8
  %128 = getelementptr i64, ptr %127, i64 1
  %129 = atomicrmw add ptr %128, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %130 = load ptr, ptr %8, align 8
  %131 = load i32, ptr %9, align 4
  %132 = sext i32 %131 to i64
  %133 = add i64 %lsr.iv, %132
  %134 = getelementptr double, ptr %130, i64 %133
  %135 = getelementptr double, ptr %134, i64 -2
  %136 = load i64, ptr %135, align 8
  %137 = and i64 %136, 9223372036854775807
  %138 = and i64 %136, 9218868437227405312
  %139 = icmp eq i64 %137, 0
  %140 = icmp ne i64 %138, 0
  %141 = icmp ne i64 %138, 9218868437227405312
  %142 = and i1 %140, %141
  %143 = or i1 %139, %142
  br i1 %143, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %144 = load ptr, ptr %0, align 8
  %145 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %144, i64 0, i32 9, i32 1
  %146 = load ptr, ptr %145, align 8
  %147 = getelementptr i64, ptr %146, i64 1
  %148 = atomicrmw add ptr %147, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %149 = load ptr, ptr %8, align 8
  %150 = load i32, ptr %9, align 4
  %151 = sext i32 %150 to i64
  %152 = add i64 %lsr.iv, %151
  %153 = getelementptr double, ptr %149, i64 %152
  %154 = getelementptr double, ptr %153, i64 -1
  %155 = load i64, ptr %154, align 8
  %156 = and i64 %155, 9223372036854775807
  %157 = and i64 %155, 9218868437227405312
  %158 = icmp eq i64 %156, 0
  %159 = icmp ne i64 %157, 0
  %160 = icmp ne i64 %157, 9218868437227405312
  %161 = and i1 %159, %160
  %162 = or i1 %158, %161
  br i1 %162, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %163 = load ptr, ptr %0, align 8
  %164 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %163, i64 0, i32 9, i32 1
  %165 = load ptr, ptr %164, align 8
  %166 = getelementptr i64, ptr %165, i64 1
  %167 = atomicrmw add ptr %166, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %168 = load ptr, ptr %8, align 8
  %169 = load i32, ptr %9, align 4
  %170 = sext i32 %169 to i64
  %171 = add nsw i64 %lsr.iv, %170
  %172 = getelementptr double, ptr %168, i64 %171
  %173 = load i64, ptr %172, align 8
  %174 = and i64 %173, 9223372036854775807
  %175 = and i64 %173, 9218868437227405312
  %176 = icmp eq i64 %174, 0
  %177 = icmp ne i64 %175, 0
  %178 = icmp ne i64 %175, 9218868437227405312
  %179 = and i1 %177, %178
  %180 = or i1 %176, %179
  br i1 %180, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %181 = load ptr, ptr %0, align 8
  %182 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %181, i64 0, i32 9, i32 1
  %183 = load ptr, ptr %182, align 8
  %184 = getelementptr i64, ptr %183, i64 1
  %185 = atomicrmw add ptr %184, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %lsr.iv.next = add i64 %lsr.iv, 8
  %186 = add i64 %33, %lsr.iv.next
  %exitcond.not.7 = icmp eq i64 %186, 7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_27_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.26, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.26(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 5, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 5, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = shl nsw i64 %15, 4
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !33

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = shl nsw i64 %35, 4
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = shl nsw i64 %53, 4
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = shl nsw i64 %70, 4
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = shl nsw i64 %87, 4
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = shl nsw i64 %104, 4
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = shl nsw i64 %121, 4
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = shl nsw i64 %138, 4
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = shl nsw i64 %155, 4
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_28_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.27, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.27(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 5, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 5, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = mul nsw i64 %15, 24
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !34

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = mul nsw i64 %35, 24
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = mul nsw i64 %53, 24
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = mul nsw i64 %70, 24
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = mul nsw i64 %87, 24
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = mul nsw i64 %104, 24
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = mul nsw i64 %121, 24
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = mul nsw i64 %138, 24
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = mul nsw i64 %155, 24
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_29_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.28, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.28(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 5, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 5, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = shl nsw i64 %15, 5
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !35

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = shl nsw i64 %35, 5
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = shl nsw i64 %53, 5
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = shl nsw i64 %70, 5
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = shl nsw i64 %87, 5
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = shl nsw i64 %104, 5
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = shl nsw i64 %121, 5
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = shl nsw i64 %138, 5
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = shl nsw i64 %155, 5
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_30_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.29, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.29(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 5, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 5, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = mul nsw i64 %15, 40
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !36

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = mul nsw i64 %35, 40
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = mul nsw i64 %53, 40
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = mul nsw i64 %70, 40
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = mul nsw i64 %87, 40
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = mul nsw i64 %104, 40
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = mul nsw i64 %121, 40
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = mul nsw i64 %138, 40
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = mul nsw i64 %155, 40
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_31_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.30, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.30(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 11)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 6, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %10 = xor i64 %9, -1
  %11 = add nsw i64 %10, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 3
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %9, %for_loop_body.prol.preheader ]
  %12 = load ptr, ptr %8, align 8
  %13 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep20 = getelementptr i8, ptr %12, i64 %13
  %14 = load i64, ptr %uglygep20, align 8
  %15 = and i64 %14, 9223372036854775807
  %16 = and i64 %14, 9218868437227405312
  %17 = icmp eq i64 %15, 0
  %18 = icmp ne i64 %16, 0
  %19 = icmp ne i64 %16, 9218868437227405312
  %20 = and i1 %18, %19
  %21 = or i1 %17, %20
  br i1 %21, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %22 = load ptr, ptr %0, align 8
  %23 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %22, i64 0, i32 9, i32 1
  %24 = load ptr, ptr %23, align 8
  %25 = getelementptr i64, ptr %24, i64 1
  %26 = atomicrmw add ptr %25, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !37

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %27 = add i64 %9, %xtraiter
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %9, %for_loop_body.lr.ph ], [ %27, %for_loop_body.prol.loopexit.loopexit ]
  %28 = icmp ult i64 %11, 7
  br i1 %28, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %29 = load ptr, ptr %8, align 8
  %30 = shl i64 %indvars.iv, 3
  %uglygep17 = getelementptr i8, ptr %29, i64 %30
  %31 = load i64, ptr %uglygep17, align 8
  %32 = and i64 %31, 9223372036854775807
  %33 = and i64 %31, 9218868437227405312
  %34 = icmp eq i64 %32, 0
  %35 = icmp ne i64 %33, 0
  %36 = icmp ne i64 %33, 9218868437227405312
  %37 = and i1 %35, %36
  %38 = or i1 %34, %37
  br i1 %38, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %39 = load ptr, ptr %0, align 8
  %40 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %39, i64 0, i32 9, i32 1
  %41 = load ptr, ptr %40, align 8
  %42 = getelementptr i64, ptr %41, i64 1
  %43 = atomicrmw add ptr %42, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %44 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %44, i64 8
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %30
  %45 = load i64, ptr %uglygep19, align 8
  %46 = and i64 %45, 9223372036854775807
  %47 = and i64 %45, 9218868437227405312
  %48 = icmp eq i64 %46, 0
  %49 = icmp ne i64 %47, 0
  %50 = icmp ne i64 %47, 9218868437227405312
  %51 = and i1 %49, %50
  %52 = or i1 %48, %51
  br i1 %52, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %53 = load ptr, ptr %0, align 8
  %54 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %53, i64 0, i32 9, i32 1
  %55 = load ptr, ptr %54, align 8
  %56 = getelementptr i64, ptr %55, i64 1
  %57 = atomicrmw add ptr %56, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %58 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %58, i64 16
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %30
  %59 = load i64, ptr %uglygep16, align 8
  %60 = and i64 %59, 9223372036854775807
  %61 = and i64 %59, 9218868437227405312
  %62 = icmp eq i64 %60, 0
  %63 = icmp ne i64 %61, 0
  %64 = icmp ne i64 %61, 9218868437227405312
  %65 = and i1 %63, %64
  %66 = or i1 %62, %65
  br i1 %66, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %67 = load ptr, ptr %0, align 8
  %68 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %67, i64 0, i32 9, i32 1
  %69 = load ptr, ptr %68, align 8
  %70 = getelementptr i64, ptr %69, i64 1
  %71 = atomicrmw add ptr %70, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %72 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %72, i64 24
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %30
  %73 = load i64, ptr %uglygep14, align 8
  %74 = and i64 %73, 9223372036854775807
  %75 = and i64 %73, 9218868437227405312
  %76 = icmp eq i64 %74, 0
  %77 = icmp ne i64 %75, 0
  %78 = icmp ne i64 %75, 9218868437227405312
  %79 = and i1 %77, %78
  %80 = or i1 %76, %79
  br i1 %80, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %81 = load ptr, ptr %0, align 8
  %82 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %81, i64 0, i32 9, i32 1
  %83 = load ptr, ptr %82, align 8
  %84 = getelementptr i64, ptr %83, i64 1
  %85 = atomicrmw add ptr %84, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %86 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %86, i64 32
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %30
  %87 = load i64, ptr %uglygep12, align 8
  %88 = and i64 %87, 9223372036854775807
  %89 = and i64 %87, 9218868437227405312
  %90 = icmp eq i64 %88, 0
  %91 = icmp ne i64 %89, 0
  %92 = icmp ne i64 %89, 9218868437227405312
  %93 = and i1 %91, %92
  %94 = or i1 %90, %93
  br i1 %94, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %95 = load ptr, ptr %0, align 8
  %96 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %95, i64 0, i32 9, i32 1
  %97 = load ptr, ptr %96, align 8
  %98 = getelementptr i64, ptr %97, i64 1
  %99 = atomicrmw add ptr %98, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %100 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %100, i64 40
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %30
  %101 = load i64, ptr %uglygep10, align 8
  %102 = and i64 %101, 9223372036854775807
  %103 = and i64 %101, 9218868437227405312
  %104 = icmp eq i64 %102, 0
  %105 = icmp ne i64 %103, 0
  %106 = icmp ne i64 %103, 9218868437227405312
  %107 = and i1 %105, %106
  %108 = or i1 %104, %107
  br i1 %108, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %109 = load ptr, ptr %0, align 8
  %110 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %109, i64 0, i32 9, i32 1
  %111 = load ptr, ptr %110, align 8
  %112 = getelementptr i64, ptr %111, i64 1
  %113 = atomicrmw add ptr %112, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %114 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %114, i64 48
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %30
  %115 = load i64, ptr %uglygep8, align 8
  %116 = and i64 %115, 9223372036854775807
  %117 = and i64 %115, 9218868437227405312
  %118 = icmp eq i64 %116, 0
  %119 = icmp ne i64 %117, 0
  %120 = icmp ne i64 %117, 9218868437227405312
  %121 = and i1 %119, %120
  %122 = or i1 %118, %121
  br i1 %122, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %123 = load ptr, ptr %0, align 8
  %124 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %123, i64 0, i32 9, i32 1
  %125 = load ptr, ptr %124, align 8
  %126 = getelementptr i64, ptr %125, i64 1
  %127 = atomicrmw add ptr %126, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %128 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %128, i64 56
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %30
  %129 = load i64, ptr %uglygep6, align 8
  %130 = and i64 %129, 9223372036854775807
  %131 = and i64 %129, 9218868437227405312
  %132 = icmp eq i64 %130, 0
  %133 = icmp ne i64 %131, 0
  %134 = icmp ne i64 %131, 9218868437227405312
  %135 = and i1 %133, %134
  %136 = or i1 %132, %135
  br i1 %136, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %137 = load ptr, ptr %0, align 8
  %138 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %137, i64 0, i32 9, i32 1
  %139 = load ptr, ptr %138, align 8
  %140 = getelementptr i64, ptr %139, i64 1
  %141 = atomicrmw add ptr %140, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_32_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.31, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.31(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 7, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %10 = xor i64 %9, -1
  %11 = add nsw i64 %10, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %9, %for_loop_body.prol.preheader ]
  %12 = load ptr, ptr %8, align 8
  %13 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep20 = getelementptr i8, ptr %12, i64 %13
  %14 = load i64, ptr %uglygep20, align 8
  %15 = and i64 %14, 9223372036854775807
  %16 = and i64 %14, 9218868437227405312
  %17 = icmp eq i64 %15, 0
  %18 = icmp ne i64 %16, 0
  %19 = icmp ne i64 %16, 9218868437227405312
  %20 = and i1 %18, %19
  %21 = or i1 %17, %20
  br i1 %21, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %22 = load ptr, ptr %0, align 8
  %23 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %22, i64 0, i32 9, i32 1
  %24 = load ptr, ptr %23, align 8
  %25 = getelementptr i64, ptr %24, i64 1
  %26 = atomicrmw add ptr %25, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !38

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %27 = add i64 %xtraiter, %9
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %9, %for_loop_body.lr.ph ], [ %27, %for_loop_body.prol.loopexit.loopexit ]
  %28 = icmp ult i64 %11, 7
  br i1 %28, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %29 = load ptr, ptr %8, align 8
  %30 = shl i64 %indvars.iv, 3
  %uglygep17 = getelementptr i8, ptr %29, i64 %30
  %31 = load i64, ptr %uglygep17, align 8
  %32 = and i64 %31, 9223372036854775807
  %33 = and i64 %31, 9218868437227405312
  %34 = icmp eq i64 %32, 0
  %35 = icmp ne i64 %33, 0
  %36 = icmp ne i64 %33, 9218868437227405312
  %37 = and i1 %35, %36
  %38 = or i1 %34, %37
  br i1 %38, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %39 = load ptr, ptr %0, align 8
  %40 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %39, i64 0, i32 9, i32 1
  %41 = load ptr, ptr %40, align 8
  %42 = getelementptr i64, ptr %41, i64 1
  %43 = atomicrmw add ptr %42, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %44 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %44, i64 8
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %30
  %45 = load i64, ptr %uglygep19, align 8
  %46 = and i64 %45, 9223372036854775807
  %47 = and i64 %45, 9218868437227405312
  %48 = icmp eq i64 %46, 0
  %49 = icmp ne i64 %47, 0
  %50 = icmp ne i64 %47, 9218868437227405312
  %51 = and i1 %49, %50
  %52 = or i1 %48, %51
  br i1 %52, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %53 = load ptr, ptr %0, align 8
  %54 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %53, i64 0, i32 9, i32 1
  %55 = load ptr, ptr %54, align 8
  %56 = getelementptr i64, ptr %55, i64 1
  %57 = atomicrmw add ptr %56, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %58 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %58, i64 16
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %30
  %59 = load i64, ptr %uglygep16, align 8
  %60 = and i64 %59, 9223372036854775807
  %61 = and i64 %59, 9218868437227405312
  %62 = icmp eq i64 %60, 0
  %63 = icmp ne i64 %61, 0
  %64 = icmp ne i64 %61, 9218868437227405312
  %65 = and i1 %63, %64
  %66 = or i1 %62, %65
  br i1 %66, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %67 = load ptr, ptr %0, align 8
  %68 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %67, i64 0, i32 9, i32 1
  %69 = load ptr, ptr %68, align 8
  %70 = getelementptr i64, ptr %69, i64 1
  %71 = atomicrmw add ptr %70, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %72 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %72, i64 24
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %30
  %73 = load i64, ptr %uglygep14, align 8
  %74 = and i64 %73, 9223372036854775807
  %75 = and i64 %73, 9218868437227405312
  %76 = icmp eq i64 %74, 0
  %77 = icmp ne i64 %75, 0
  %78 = icmp ne i64 %75, 9218868437227405312
  %79 = and i1 %77, %78
  %80 = or i1 %76, %79
  br i1 %80, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %81 = load ptr, ptr %0, align 8
  %82 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %81, i64 0, i32 9, i32 1
  %83 = load ptr, ptr %82, align 8
  %84 = getelementptr i64, ptr %83, i64 1
  %85 = atomicrmw add ptr %84, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %86 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %86, i64 32
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %30
  %87 = load i64, ptr %uglygep12, align 8
  %88 = and i64 %87, 9223372036854775807
  %89 = and i64 %87, 9218868437227405312
  %90 = icmp eq i64 %88, 0
  %91 = icmp ne i64 %89, 0
  %92 = icmp ne i64 %89, 9218868437227405312
  %93 = and i1 %91, %92
  %94 = or i1 %90, %93
  br i1 %94, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %95 = load ptr, ptr %0, align 8
  %96 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %95, i64 0, i32 9, i32 1
  %97 = load ptr, ptr %96, align 8
  %98 = getelementptr i64, ptr %97, i64 1
  %99 = atomicrmw add ptr %98, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %100 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %100, i64 40
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %30
  %101 = load i64, ptr %uglygep10, align 8
  %102 = and i64 %101, 9223372036854775807
  %103 = and i64 %101, 9218868437227405312
  %104 = icmp eq i64 %102, 0
  %105 = icmp ne i64 %103, 0
  %106 = icmp ne i64 %103, 9218868437227405312
  %107 = and i1 %105, %106
  %108 = or i1 %104, %107
  br i1 %108, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %109 = load ptr, ptr %0, align 8
  %110 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %109, i64 0, i32 9, i32 1
  %111 = load ptr, ptr %110, align 8
  %112 = getelementptr i64, ptr %111, i64 1
  %113 = atomicrmw add ptr %112, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %114 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %114, i64 48
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %30
  %115 = load i64, ptr %uglygep8, align 8
  %116 = and i64 %115, 9223372036854775807
  %117 = and i64 %115, 9218868437227405312
  %118 = icmp eq i64 %116, 0
  %119 = icmp ne i64 %117, 0
  %120 = icmp ne i64 %117, 9218868437227405312
  %121 = and i1 %119, %120
  %122 = or i1 %118, %121
  br i1 %122, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %123 = load ptr, ptr %0, align 8
  %124 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %123, i64 0, i32 9, i32 1
  %125 = load ptr, ptr %124, align 8
  %126 = getelementptr i64, ptr %125, i64 1
  %127 = atomicrmw add ptr %126, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %128 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %128, i64 56
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %30
  %129 = load i64, ptr %uglygep6, align 8
  %130 = and i64 %129, 9223372036854775807
  %131 = and i64 %129, 9218868437227405312
  %132 = icmp eq i64 %130, 0
  %133 = icmp ne i64 %131, 0
  %134 = icmp ne i64 %131, 9218868437227405312
  %135 = and i1 %133, %134
  %136 = or i1 %132, %135
  br i1 %136, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %137 = load ptr, ptr %0, align 8
  %138 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %137, i64 0, i32 9, i32 1
  %139 = load ptr, ptr %138, align 8
  %140 = getelementptr i64, ptr %139, i64 1
  %141 = atomicrmw add ptr %140, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_33_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.32, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.32(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 7, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 7, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv6 = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next7, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = add nsw i64 %indvars.iv.prol, %15
  %17 = getelementptr double, ptr %13, i64 %16
  %18 = load i64, ptr %17, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next7 = add nsw i64 %lsr.iv6, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next7, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !39

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  %33 = sub i64 0, %wide.trip.count
  %34 = add nsw i64 %indvars.iv.unr, 7
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %lsr.iv = phi i64 [ %34, %for_loop_body.preheader ], [ %lsr.iv.next, %after_if.7 ]
  %35 = load ptr, ptr %8, align 8
  %36 = load i32, ptr %9, align 4
  %37 = sext i32 %36 to i64
  %38 = add i64 %lsr.iv, %37
  %39 = getelementptr double, ptr %35, i64 %38
  %40 = getelementptr double, ptr %39, i64 -7
  %41 = load i64, ptr %40, align 8
  %42 = and i64 %41, 9223372036854775807
  %43 = and i64 %41, 9218868437227405312
  %44 = icmp eq i64 %42, 0
  %45 = icmp ne i64 %43, 0
  %46 = icmp ne i64 %43, 9218868437227405312
  %47 = and i1 %45, %46
  %48 = or i1 %44, %47
  br i1 %48, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %49 = load ptr, ptr %0, align 8
  %50 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %49, i64 0, i32 9, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = getelementptr i64, ptr %51, i64 1
  %53 = atomicrmw add ptr %52, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %54 = load ptr, ptr %8, align 8
  %55 = load i32, ptr %9, align 4
  %56 = sext i32 %55 to i64
  %57 = add i64 %lsr.iv, %56
  %58 = getelementptr double, ptr %54, i64 %57
  %59 = getelementptr double, ptr %58, i64 -6
  %60 = load i64, ptr %59, align 8
  %61 = and i64 %60, 9223372036854775807
  %62 = and i64 %60, 9218868437227405312
  %63 = icmp eq i64 %61, 0
  %64 = icmp ne i64 %62, 0
  %65 = icmp ne i64 %62, 9218868437227405312
  %66 = and i1 %64, %65
  %67 = or i1 %63, %66
  br i1 %67, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %68 = load ptr, ptr %0, align 8
  %69 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %68, i64 0, i32 9, i32 1
  %70 = load ptr, ptr %69, align 8
  %71 = getelementptr i64, ptr %70, i64 1
  %72 = atomicrmw add ptr %71, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %73 = load ptr, ptr %8, align 8
  %74 = load i32, ptr %9, align 4
  %75 = sext i32 %74 to i64
  %76 = add i64 %lsr.iv, %75
  %77 = getelementptr double, ptr %73, i64 %76
  %78 = getelementptr double, ptr %77, i64 -5
  %79 = load i64, ptr %78, align 8
  %80 = and i64 %79, 9223372036854775807
  %81 = and i64 %79, 9218868437227405312
  %82 = icmp eq i64 %80, 0
  %83 = icmp ne i64 %81, 0
  %84 = icmp ne i64 %81, 9218868437227405312
  %85 = and i1 %83, %84
  %86 = or i1 %82, %85
  br i1 %86, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %87 = load ptr, ptr %0, align 8
  %88 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %87, i64 0, i32 9, i32 1
  %89 = load ptr, ptr %88, align 8
  %90 = getelementptr i64, ptr %89, i64 1
  %91 = atomicrmw add ptr %90, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %92 = load ptr, ptr %8, align 8
  %93 = load i32, ptr %9, align 4
  %94 = sext i32 %93 to i64
  %95 = add i64 %lsr.iv, %94
  %96 = getelementptr double, ptr %92, i64 %95
  %97 = getelementptr double, ptr %96, i64 -4
  %98 = load i64, ptr %97, align 8
  %99 = and i64 %98, 9223372036854775807
  %100 = and i64 %98, 9218868437227405312
  %101 = icmp eq i64 %99, 0
  %102 = icmp ne i64 %100, 0
  %103 = icmp ne i64 %100, 9218868437227405312
  %104 = and i1 %102, %103
  %105 = or i1 %101, %104
  br i1 %105, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %106 = load ptr, ptr %0, align 8
  %107 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %106, i64 0, i32 9, i32 1
  %108 = load ptr, ptr %107, align 8
  %109 = getelementptr i64, ptr %108, i64 1
  %110 = atomicrmw add ptr %109, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %111 = load ptr, ptr %8, align 8
  %112 = load i32, ptr %9, align 4
  %113 = sext i32 %112 to i64
  %114 = add i64 %lsr.iv, %113
  %115 = getelementptr double, ptr %111, i64 %114
  %116 = getelementptr double, ptr %115, i64 -3
  %117 = load i64, ptr %116, align 8
  %118 = and i64 %117, 9223372036854775807
  %119 = and i64 %117, 9218868437227405312
  %120 = icmp eq i64 %118, 0
  %121 = icmp ne i64 %119, 0
  %122 = icmp ne i64 %119, 9218868437227405312
  %123 = and i1 %121, %122
  %124 = or i1 %120, %123
  br i1 %124, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %125 = load ptr, ptr %0, align 8
  %126 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %125, i64 0, i32 9, i32 1
  %127 = load ptr, ptr %126, align 8
  %128 = getelementptr i64, ptr %127, i64 1
  %129 = atomicrmw add ptr %128, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %130 = load ptr, ptr %8, align 8
  %131 = load i32, ptr %9, align 4
  %132 = sext i32 %131 to i64
  %133 = add i64 %lsr.iv, %132
  %134 = getelementptr double, ptr %130, i64 %133
  %135 = getelementptr double, ptr %134, i64 -2
  %136 = load i64, ptr %135, align 8
  %137 = and i64 %136, 9223372036854775807
  %138 = and i64 %136, 9218868437227405312
  %139 = icmp eq i64 %137, 0
  %140 = icmp ne i64 %138, 0
  %141 = icmp ne i64 %138, 9218868437227405312
  %142 = and i1 %140, %141
  %143 = or i1 %139, %142
  br i1 %143, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %144 = load ptr, ptr %0, align 8
  %145 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %144, i64 0, i32 9, i32 1
  %146 = load ptr, ptr %145, align 8
  %147 = getelementptr i64, ptr %146, i64 1
  %148 = atomicrmw add ptr %147, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %149 = load ptr, ptr %8, align 8
  %150 = load i32, ptr %9, align 4
  %151 = sext i32 %150 to i64
  %152 = add i64 %lsr.iv, %151
  %153 = getelementptr double, ptr %149, i64 %152
  %154 = getelementptr double, ptr %153, i64 -1
  %155 = load i64, ptr %154, align 8
  %156 = and i64 %155, 9223372036854775807
  %157 = and i64 %155, 9218868437227405312
  %158 = icmp eq i64 %156, 0
  %159 = icmp ne i64 %157, 0
  %160 = icmp ne i64 %157, 9218868437227405312
  %161 = and i1 %159, %160
  %162 = or i1 %158, %161
  br i1 %162, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %163 = load ptr, ptr %0, align 8
  %164 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %163, i64 0, i32 9, i32 1
  %165 = load ptr, ptr %164, align 8
  %166 = getelementptr i64, ptr %165, i64 1
  %167 = atomicrmw add ptr %166, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %168 = load ptr, ptr %8, align 8
  %169 = load i32, ptr %9, align 4
  %170 = sext i32 %169 to i64
  %171 = add nsw i64 %lsr.iv, %170
  %172 = getelementptr double, ptr %168, i64 %171
  %173 = load i64, ptr %172, align 8
  %174 = and i64 %173, 9223372036854775807
  %175 = and i64 %173, 9218868437227405312
  %176 = icmp eq i64 %174, 0
  %177 = icmp ne i64 %175, 0
  %178 = icmp ne i64 %175, 9218868437227405312
  %179 = and i1 %177, %178
  %180 = or i1 %176, %179
  br i1 %180, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %181 = load ptr, ptr %0, align 8
  %182 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %181, i64 0, i32 9, i32 1
  %183 = load ptr, ptr %182, align 8
  %184 = getelementptr i64, ptr %183, i64 1
  %185 = atomicrmw add ptr %184, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %lsr.iv.next = add i64 %lsr.iv, 8
  %186 = add i64 %33, %lsr.iv.next
  %exitcond.not.7 = icmp eq i64 %186, 7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_34_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.33, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.33(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 7, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 7, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = shl nsw i64 %15, 4
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !40

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = shl nsw i64 %35, 4
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = shl nsw i64 %53, 4
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = shl nsw i64 %70, 4
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = shl nsw i64 %87, 4
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = shl nsw i64 %104, 4
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = shl nsw i64 %121, 4
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = shl nsw i64 %138, 4
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = shl nsw i64 %155, 4
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_35_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.34, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.34(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 7, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 7, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = mul nsw i64 %15, 24
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !41

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = mul nsw i64 %35, 24
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = mul nsw i64 %53, 24
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = mul nsw i64 %70, 24
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = mul nsw i64 %87, 24
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = mul nsw i64 %104, 24
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = mul nsw i64 %121, 24
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = mul nsw i64 %138, 24
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = mul nsw i64 %155, 24
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_36_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.35, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.35(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 7, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 7, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = shl nsw i64 %15, 5
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !42

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = shl nsw i64 %35, 5
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = shl nsw i64 %53, 5
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = shl nsw i64 %70, 5
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = shl nsw i64 %87, 5
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = shl nsw i64 %104, 5
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = shl nsw i64 %121, 5
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = shl nsw i64 %138, 5
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = shl nsw i64 %155, 5
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_37_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.36, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.36(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 7, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 7, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = mul nsw i64 %15, 40
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !43

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = mul nsw i64 %35, 40
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = mul nsw i64 %53, 40
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = mul nsw i64 %70, 40
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = mul nsw i64 %87, 40
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = mul nsw i64 %104, 40
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = mul nsw i64 %121, 40
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = mul nsw i64 %138, 40
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = mul nsw i64 %155, 40
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_38_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.37, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.37(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 7, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 7, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = mul nsw i64 %15, 48
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !44

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = mul nsw i64 %35, 48
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = mul nsw i64 %53, 48
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = mul nsw i64 %70, 48
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = mul nsw i64 %87, 48
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = mul nsw i64 %104, 48
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = mul nsw i64 %121, 48
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = mul nsw i64 %138, 48
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = mul nsw i64 %155, 48
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_39_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.38, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.38(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 7, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 7, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = mul nsw i64 %15, 56
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !45

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = mul nsw i64 %35, 56
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = mul nsw i64 %53, 56
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = mul nsw i64 %70, 56
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = mul nsw i64 %87, 56
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = mul nsw i64 %104, 56
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = mul nsw i64 %121, 56
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = mul nsw i64 %138, 56
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = mul nsw i64 %155, 56
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_40_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.39, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.39(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 8, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %10 = xor i64 %9, -1
  %11 = add nsw i64 %10, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %9, %for_loop_body.prol.preheader ]
  %12 = load ptr, ptr %8, align 8
  %13 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep20 = getelementptr i8, ptr %12, i64 %13
  %14 = load i64, ptr %uglygep20, align 8
  %15 = and i64 %14, 9223372036854775807
  %16 = and i64 %14, 9218868437227405312
  %17 = icmp eq i64 %15, 0
  %18 = icmp ne i64 %16, 0
  %19 = icmp ne i64 %16, 9218868437227405312
  %20 = and i1 %18, %19
  %21 = or i1 %17, %20
  br i1 %21, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %22 = load ptr, ptr %0, align 8
  %23 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %22, i64 0, i32 9, i32 1
  %24 = load ptr, ptr %23, align 8
  %25 = getelementptr i64, ptr %24, i64 1
  %26 = atomicrmw add ptr %25, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !46

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %27 = add i64 %xtraiter, %9
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %9, %for_loop_body.lr.ph ], [ %27, %for_loop_body.prol.loopexit.loopexit ]
  %28 = icmp ult i64 %11, 7
  br i1 %28, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %29 = load ptr, ptr %8, align 8
  %30 = shl i64 %indvars.iv, 3
  %uglygep17 = getelementptr i8, ptr %29, i64 %30
  %31 = load i64, ptr %uglygep17, align 8
  %32 = and i64 %31, 9223372036854775807
  %33 = and i64 %31, 9218868437227405312
  %34 = icmp eq i64 %32, 0
  %35 = icmp ne i64 %33, 0
  %36 = icmp ne i64 %33, 9218868437227405312
  %37 = and i1 %35, %36
  %38 = or i1 %34, %37
  br i1 %38, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %39 = load ptr, ptr %0, align 8
  %40 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %39, i64 0, i32 9, i32 1
  %41 = load ptr, ptr %40, align 8
  %42 = getelementptr i64, ptr %41, i64 1
  %43 = atomicrmw add ptr %42, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %44 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %44, i64 8
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %30
  %45 = load i64, ptr %uglygep19, align 8
  %46 = and i64 %45, 9223372036854775807
  %47 = and i64 %45, 9218868437227405312
  %48 = icmp eq i64 %46, 0
  %49 = icmp ne i64 %47, 0
  %50 = icmp ne i64 %47, 9218868437227405312
  %51 = and i1 %49, %50
  %52 = or i1 %48, %51
  br i1 %52, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %53 = load ptr, ptr %0, align 8
  %54 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %53, i64 0, i32 9, i32 1
  %55 = load ptr, ptr %54, align 8
  %56 = getelementptr i64, ptr %55, i64 1
  %57 = atomicrmw add ptr %56, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %58 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %58, i64 16
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %30
  %59 = load i64, ptr %uglygep16, align 8
  %60 = and i64 %59, 9223372036854775807
  %61 = and i64 %59, 9218868437227405312
  %62 = icmp eq i64 %60, 0
  %63 = icmp ne i64 %61, 0
  %64 = icmp ne i64 %61, 9218868437227405312
  %65 = and i1 %63, %64
  %66 = or i1 %62, %65
  br i1 %66, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %67 = load ptr, ptr %0, align 8
  %68 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %67, i64 0, i32 9, i32 1
  %69 = load ptr, ptr %68, align 8
  %70 = getelementptr i64, ptr %69, i64 1
  %71 = atomicrmw add ptr %70, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %72 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %72, i64 24
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %30
  %73 = load i64, ptr %uglygep14, align 8
  %74 = and i64 %73, 9223372036854775807
  %75 = and i64 %73, 9218868437227405312
  %76 = icmp eq i64 %74, 0
  %77 = icmp ne i64 %75, 0
  %78 = icmp ne i64 %75, 9218868437227405312
  %79 = and i1 %77, %78
  %80 = or i1 %76, %79
  br i1 %80, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %81 = load ptr, ptr %0, align 8
  %82 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %81, i64 0, i32 9, i32 1
  %83 = load ptr, ptr %82, align 8
  %84 = getelementptr i64, ptr %83, i64 1
  %85 = atomicrmw add ptr %84, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %86 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %86, i64 32
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %30
  %87 = load i64, ptr %uglygep12, align 8
  %88 = and i64 %87, 9223372036854775807
  %89 = and i64 %87, 9218868437227405312
  %90 = icmp eq i64 %88, 0
  %91 = icmp ne i64 %89, 0
  %92 = icmp ne i64 %89, 9218868437227405312
  %93 = and i1 %91, %92
  %94 = or i1 %90, %93
  br i1 %94, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %95 = load ptr, ptr %0, align 8
  %96 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %95, i64 0, i32 9, i32 1
  %97 = load ptr, ptr %96, align 8
  %98 = getelementptr i64, ptr %97, i64 1
  %99 = atomicrmw add ptr %98, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %100 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %100, i64 40
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %30
  %101 = load i64, ptr %uglygep10, align 8
  %102 = and i64 %101, 9223372036854775807
  %103 = and i64 %101, 9218868437227405312
  %104 = icmp eq i64 %102, 0
  %105 = icmp ne i64 %103, 0
  %106 = icmp ne i64 %103, 9218868437227405312
  %107 = and i1 %105, %106
  %108 = or i1 %104, %107
  br i1 %108, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %109 = load ptr, ptr %0, align 8
  %110 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %109, i64 0, i32 9, i32 1
  %111 = load ptr, ptr %110, align 8
  %112 = getelementptr i64, ptr %111, i64 1
  %113 = atomicrmw add ptr %112, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %114 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %114, i64 48
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %30
  %115 = load i64, ptr %uglygep8, align 8
  %116 = and i64 %115, 9223372036854775807
  %117 = and i64 %115, 9218868437227405312
  %118 = icmp eq i64 %116, 0
  %119 = icmp ne i64 %117, 0
  %120 = icmp ne i64 %117, 9218868437227405312
  %121 = and i1 %119, %120
  %122 = or i1 %118, %121
  br i1 %122, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %123 = load ptr, ptr %0, align 8
  %124 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %123, i64 0, i32 9, i32 1
  %125 = load ptr, ptr %124, align 8
  %126 = getelementptr i64, ptr %125, i64 1
  %127 = atomicrmw add ptr %126, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %128 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %128, i64 56
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %30
  %129 = load i64, ptr %uglygep6, align 8
  %130 = and i64 %129, 9223372036854775807
  %131 = and i64 %129, 9218868437227405312
  %132 = icmp eq i64 %130, 0
  %133 = icmp ne i64 %131, 0
  %134 = icmp ne i64 %131, 9218868437227405312
  %135 = and i1 %133, %134
  %136 = or i1 %132, %135
  br i1 %136, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %137 = load ptr, ptr %0, align 8
  %138 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %137, i64 0, i32 9, i32 1
  %139 = load ptr, ptr %138, align 8
  %140 = getelementptr i64, ptr %139, i64 1
  %141 = atomicrmw add ptr %140, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_41_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.40, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.40(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 8, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 8, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv6 = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next7, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = add nsw i64 %indvars.iv.prol, %15
  %17 = getelementptr double, ptr %13, i64 %16
  %18 = load i64, ptr %17, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next7 = add nsw i64 %lsr.iv6, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next7, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !47

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  %33 = sub i64 0, %wide.trip.count
  %34 = add nsw i64 %indvars.iv.unr, 7
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %lsr.iv = phi i64 [ %34, %for_loop_body.preheader ], [ %lsr.iv.next, %after_if.7 ]
  %35 = load ptr, ptr %8, align 8
  %36 = load i32, ptr %9, align 4
  %37 = sext i32 %36 to i64
  %38 = add i64 %lsr.iv, %37
  %39 = getelementptr double, ptr %35, i64 %38
  %40 = getelementptr double, ptr %39, i64 -7
  %41 = load i64, ptr %40, align 8
  %42 = and i64 %41, 9223372036854775807
  %43 = and i64 %41, 9218868437227405312
  %44 = icmp eq i64 %42, 0
  %45 = icmp ne i64 %43, 0
  %46 = icmp ne i64 %43, 9218868437227405312
  %47 = and i1 %45, %46
  %48 = or i1 %44, %47
  br i1 %48, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %49 = load ptr, ptr %0, align 8
  %50 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %49, i64 0, i32 9, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = getelementptr i64, ptr %51, i64 1
  %53 = atomicrmw add ptr %52, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %54 = load ptr, ptr %8, align 8
  %55 = load i32, ptr %9, align 4
  %56 = sext i32 %55 to i64
  %57 = add i64 %lsr.iv, %56
  %58 = getelementptr double, ptr %54, i64 %57
  %59 = getelementptr double, ptr %58, i64 -6
  %60 = load i64, ptr %59, align 8
  %61 = and i64 %60, 9223372036854775807
  %62 = and i64 %60, 9218868437227405312
  %63 = icmp eq i64 %61, 0
  %64 = icmp ne i64 %62, 0
  %65 = icmp ne i64 %62, 9218868437227405312
  %66 = and i1 %64, %65
  %67 = or i1 %63, %66
  br i1 %67, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %68 = load ptr, ptr %0, align 8
  %69 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %68, i64 0, i32 9, i32 1
  %70 = load ptr, ptr %69, align 8
  %71 = getelementptr i64, ptr %70, i64 1
  %72 = atomicrmw add ptr %71, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %73 = load ptr, ptr %8, align 8
  %74 = load i32, ptr %9, align 4
  %75 = sext i32 %74 to i64
  %76 = add i64 %lsr.iv, %75
  %77 = getelementptr double, ptr %73, i64 %76
  %78 = getelementptr double, ptr %77, i64 -5
  %79 = load i64, ptr %78, align 8
  %80 = and i64 %79, 9223372036854775807
  %81 = and i64 %79, 9218868437227405312
  %82 = icmp eq i64 %80, 0
  %83 = icmp ne i64 %81, 0
  %84 = icmp ne i64 %81, 9218868437227405312
  %85 = and i1 %83, %84
  %86 = or i1 %82, %85
  br i1 %86, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %87 = load ptr, ptr %0, align 8
  %88 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %87, i64 0, i32 9, i32 1
  %89 = load ptr, ptr %88, align 8
  %90 = getelementptr i64, ptr %89, i64 1
  %91 = atomicrmw add ptr %90, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %92 = load ptr, ptr %8, align 8
  %93 = load i32, ptr %9, align 4
  %94 = sext i32 %93 to i64
  %95 = add i64 %lsr.iv, %94
  %96 = getelementptr double, ptr %92, i64 %95
  %97 = getelementptr double, ptr %96, i64 -4
  %98 = load i64, ptr %97, align 8
  %99 = and i64 %98, 9223372036854775807
  %100 = and i64 %98, 9218868437227405312
  %101 = icmp eq i64 %99, 0
  %102 = icmp ne i64 %100, 0
  %103 = icmp ne i64 %100, 9218868437227405312
  %104 = and i1 %102, %103
  %105 = or i1 %101, %104
  br i1 %105, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %106 = load ptr, ptr %0, align 8
  %107 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %106, i64 0, i32 9, i32 1
  %108 = load ptr, ptr %107, align 8
  %109 = getelementptr i64, ptr %108, i64 1
  %110 = atomicrmw add ptr %109, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %111 = load ptr, ptr %8, align 8
  %112 = load i32, ptr %9, align 4
  %113 = sext i32 %112 to i64
  %114 = add i64 %lsr.iv, %113
  %115 = getelementptr double, ptr %111, i64 %114
  %116 = getelementptr double, ptr %115, i64 -3
  %117 = load i64, ptr %116, align 8
  %118 = and i64 %117, 9223372036854775807
  %119 = and i64 %117, 9218868437227405312
  %120 = icmp eq i64 %118, 0
  %121 = icmp ne i64 %119, 0
  %122 = icmp ne i64 %119, 9218868437227405312
  %123 = and i1 %121, %122
  %124 = or i1 %120, %123
  br i1 %124, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %125 = load ptr, ptr %0, align 8
  %126 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %125, i64 0, i32 9, i32 1
  %127 = load ptr, ptr %126, align 8
  %128 = getelementptr i64, ptr %127, i64 1
  %129 = atomicrmw add ptr %128, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %130 = load ptr, ptr %8, align 8
  %131 = load i32, ptr %9, align 4
  %132 = sext i32 %131 to i64
  %133 = add i64 %lsr.iv, %132
  %134 = getelementptr double, ptr %130, i64 %133
  %135 = getelementptr double, ptr %134, i64 -2
  %136 = load i64, ptr %135, align 8
  %137 = and i64 %136, 9223372036854775807
  %138 = and i64 %136, 9218868437227405312
  %139 = icmp eq i64 %137, 0
  %140 = icmp ne i64 %138, 0
  %141 = icmp ne i64 %138, 9218868437227405312
  %142 = and i1 %140, %141
  %143 = or i1 %139, %142
  br i1 %143, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %144 = load ptr, ptr %0, align 8
  %145 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %144, i64 0, i32 9, i32 1
  %146 = load ptr, ptr %145, align 8
  %147 = getelementptr i64, ptr %146, i64 1
  %148 = atomicrmw add ptr %147, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %149 = load ptr, ptr %8, align 8
  %150 = load i32, ptr %9, align 4
  %151 = sext i32 %150 to i64
  %152 = add i64 %lsr.iv, %151
  %153 = getelementptr double, ptr %149, i64 %152
  %154 = getelementptr double, ptr %153, i64 -1
  %155 = load i64, ptr %154, align 8
  %156 = and i64 %155, 9223372036854775807
  %157 = and i64 %155, 9218868437227405312
  %158 = icmp eq i64 %156, 0
  %159 = icmp ne i64 %157, 0
  %160 = icmp ne i64 %157, 9218868437227405312
  %161 = and i1 %159, %160
  %162 = or i1 %158, %161
  br i1 %162, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %163 = load ptr, ptr %0, align 8
  %164 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %163, i64 0, i32 9, i32 1
  %165 = load ptr, ptr %164, align 8
  %166 = getelementptr i64, ptr %165, i64 1
  %167 = atomicrmw add ptr %166, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %168 = load ptr, ptr %8, align 8
  %169 = load i32, ptr %9, align 4
  %170 = sext i32 %169 to i64
  %171 = add nsw i64 %lsr.iv, %170
  %172 = getelementptr double, ptr %168, i64 %171
  %173 = load i64, ptr %172, align 8
  %174 = and i64 %173, 9223372036854775807
  %175 = and i64 %173, 9218868437227405312
  %176 = icmp eq i64 %174, 0
  %177 = icmp ne i64 %175, 0
  %178 = icmp ne i64 %175, 9218868437227405312
  %179 = and i1 %177, %178
  %180 = or i1 %176, %179
  br i1 %180, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %181 = load ptr, ptr %0, align 8
  %182 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %181, i64 0, i32 9, i32 1
  %183 = load ptr, ptr %182, align 8
  %184 = getelementptr i64, ptr %183, i64 1
  %185 = atomicrmw add ptr %184, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %lsr.iv.next = add i64 %lsr.iv, 8
  %186 = add i64 %33, %lsr.iv.next
  %exitcond.not.7 = icmp eq i64 %186, 7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_42_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.41, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.41(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 8, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 8, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = shl nsw i64 %15, 4
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !48

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = shl nsw i64 %35, 4
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = shl nsw i64 %53, 4
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = shl nsw i64 %70, 4
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = shl nsw i64 %87, 4
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = shl nsw i64 %104, 4
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = shl nsw i64 %121, 4
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = shl nsw i64 %138, 4
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = shl nsw i64 %155, 4
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nounwind
define void @tick_numeric_check_25_kernel_43_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.42, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.42(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 8, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 8, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %11 = xor i64 %10, -1
  %12 = add nsw i64 %11, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %10, %for_loop_body.prol.preheader ]
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = mul nsw i64 %15, 24
  %uglygep28 = getelementptr i8, ptr %13, i64 %16
  %17 = shl nsw i64 %indvars.iv.prol, 3
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 %17
  %18 = load i64, ptr %uglygep29, align 8
  %19 = and i64 %18, 9223372036854775807
  %20 = and i64 %18, 9218868437227405312
  %21 = icmp eq i64 %19, 0
  %22 = icmp ne i64 %20, 0
  %23 = icmp ne i64 %20, 9218868437227405312
  %24 = and i1 %22, %23
  %25 = or i1 %21, %24
  br i1 %25, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %26 = load ptr, ptr %0, align 8
  %27 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %26, i64 0, i32 9, i32 1
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr i64, ptr %28, i64 1
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !49

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %31 = add i64 %xtraiter, %10
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %10, %for_loop_body.lr.ph ], [ %31, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %12, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = mul nsw i64 %35, 24
  %uglygep23 = getelementptr i8, ptr %33, i64 %36
  %37 = shl i64 %indvars.iv, 3
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %37
  %38 = load i64, ptr %uglygep24, align 8
  %39 = and i64 %38, 9223372036854775807
  %40 = and i64 %38, 9218868437227405312
  %41 = icmp eq i64 %39, 0
  %42 = icmp ne i64 %40, 0
  %43 = icmp ne i64 %40, 9218868437227405312
  %44 = and i1 %42, %43
  %45 = or i1 %41, %44
  br i1 %45, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %46, i64 0, i32 9, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr i64, ptr %48, i64 1
  %50 = atomicrmw add ptr %49, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %51 = load ptr, ptr %8, align 8
  %52 = load i32, ptr %9, align 4
  %53 = sext i32 %52 to i64
  %54 = mul nsw i64 %53, 24
  %uglygep25 = getelementptr i8, ptr %51, i64 %54
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %37
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %55 = load i64, ptr %uglygep27, align 8
  %56 = and i64 %55, 9223372036854775807
  %57 = and i64 %55, 9218868437227405312
  %58 = icmp eq i64 %56, 0
  %59 = icmp ne i64 %57, 0
  %60 = icmp ne i64 %57, 9218868437227405312
  %61 = and i1 %59, %60
  %62 = or i1 %58, %61
  br i1 %62, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %63 = load ptr, ptr %0, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %63, i64 0, i32 9, i32 1
  %65 = load ptr, ptr %64, align 8
  %66 = getelementptr i64, ptr %65, i64 1
  %67 = atomicrmw add ptr %66, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %68 = load ptr, ptr %8, align 8
  %69 = load i32, ptr %9, align 4
  %70 = sext i32 %69 to i64
  %71 = mul nsw i64 %70, 24
  %uglygep20 = getelementptr i8, ptr %68, i64 %71
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %37
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 16
  %72 = load i64, ptr %uglygep22, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %80 = load ptr, ptr %0, align 8
  %81 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %80, i64 0, i32 9, i32 1
  %82 = load ptr, ptr %81, align 8
  %83 = getelementptr i64, ptr %82, i64 1
  %84 = atomicrmw add ptr %83, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = mul nsw i64 %87, 24
  %uglygep17 = getelementptr i8, ptr %85, i64 %88
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %37
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 24
  %89 = load i64, ptr %uglygep19, align 8
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %97, i64 0, i32 9, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr i64, ptr %99, i64 1
  %101 = atomicrmw add ptr %100, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %102 = load ptr, ptr %8, align 8
  %103 = load i32, ptr %9, align 4
  %104 = sext i32 %103 to i64
  %105 = mul nsw i64 %104, 24
  %uglygep14 = getelementptr i8, ptr %102, i64 %105
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %37
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 32
  %106 = load i64, ptr %uglygep16, align 8
  %107 = and i64 %106, 9223372036854775807
  %108 = and i64 %106, 9218868437227405312
  %109 = icmp eq i64 %107, 0
  %110 = icmp ne i64 %108, 0
  %111 = icmp ne i64 %108, 9218868437227405312
  %112 = and i1 %110, %111
  %113 = or i1 %109, %112
  br i1 %113, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %114 = load ptr, ptr %0, align 8
  %115 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %114, i64 0, i32 9, i32 1
  %116 = load ptr, ptr %115, align 8
  %117 = getelementptr i64, ptr %116, i64 1
  %118 = atomicrmw add ptr %117, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %119 = load ptr, ptr %8, align 8
  %120 = load i32, ptr %9, align 4
  %121 = sext i32 %120 to i64
  %122 = mul nsw i64 %121, 24
  %uglygep11 = getelementptr i8, ptr %119, i64 %122
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %37
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 40
  %123 = load i64, ptr %uglygep13, align 8
  %124 = and i64 %123, 9223372036854775807
  %125 = and i64 %123, 9218868437227405312
  %126 = icmp eq i64 %124, 0
  %127 = icmp ne i64 %125, 0
  %128 = icmp ne i64 %125, 9218868437227405312
  %129 = and i1 %127, %128
  %130 = or i1 %126, %129
  br i1 %130, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %131 = load ptr, ptr %0, align 8
  %132 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %131, i64 0, i32 9, i32 1
  %133 = load ptr, ptr %132, align 8
  %134 = getelementptr i64, ptr %133, i64 1
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %136 = load ptr, ptr %8, align 8
  %137 = load i32, ptr %9, align 4
  %138 = sext i32 %137 to i64
  %139 = mul nsw i64 %138, 24
  %uglygep8 = getelementptr i8, ptr %136, i64 %139
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %37
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 48
  %140 = load i64, ptr %uglygep10, align 8
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %148, i64 0, i32 9, i32 1
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr i64, ptr %150, i64 1
  %152 = atomicrmw add ptr %151, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %153 = load ptr, ptr %8, align 8
  %154 = load i32, ptr %9, align 4
  %155 = sext i32 %154 to i64
  %156 = mul nsw i64 %155, 24
  %uglygep = getelementptr i8, ptr %153, i64 %156
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %37
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 56
  %157 = load i64, ptr %uglygep7, align 8
  %158 = and i64 %157, 9223372036854775807
  %159 = and i64 %157, 9218868437227405312
  %160 = icmp eq i64 %158, 0
  %161 = icmp ne i64 %159, 0
  %162 = icmp ne i64 %159, 9218868437227405312
  %163 = and i1 %161, %162
  %164 = or i1 %160, %163
  br i1 %164, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %165 = load ptr, ptr %0, align 8
  %166 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %165, i64 0, i32 9, i32 1
  %167 = load ptr, ptr %166, align 8
  %168 = getelementptr i64, ptr %167, i64 1
  %169 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_parallel_range_for_task(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #3 {
  %4 = alloca %struct.RuntimeContext.1165, align 8
  %.sroa.0.0.copyload = load ptr, ptr %0, align 8
  %.sroa.4.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 8
  %.sroa.4.0.copyload = load ptr, ptr %.sroa.4.0..sroa_idx, align 8
  %.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 16
  %.sroa.5.0.copyload = load ptr, ptr %.sroa.5.0..sroa_idx, align 8
  %.sroa.7.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 24
  %.sroa.7.0.copyload = load ptr, ptr %.sroa.7.0..sroa_idx, align 8
  %.sroa.8.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 32
  %.sroa.8.0.copyload = load i64, ptr %.sroa.8.0..sroa_idx, align 8
  %.sroa.9.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 40
  %.sroa.9.0.copyload = load i32, ptr %.sroa.9.0..sroa_idx, align 8
  %.sroa.12.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 44
  %.sroa.12.0.copyload = load i32, ptr %.sroa.12.0..sroa_idx, align 4
  %.sroa.15.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 48
  %.sroa.15.0.copyload = load i32, ptr %.sroa.15.0..sroa_idx, align 8
  %.sroa.17.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 52
  %.sroa.17.0.copyload = load i32, ptr %.sroa.17.0..sroa_idx, align 4
  %5 = alloca i8, i64 %.sroa.8.0.copyload, align 8
  %.not = icmp eq ptr %.sroa.4.0.copyload, null
  br i1 %.not, label %7, label %6

6:                                                ; preds = %3
  call void %.sroa.4.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %7

7:                                                ; preds = %6, %3
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %4, ptr noundef nonnull align 8 dereferenceable(32) %.sroa.0.0.copyload, i64 32, i1 false)
  %8 = getelementptr inbounds %struct.RuntimeContext.1165, ptr %4, i64 0, i32 2
  store i32 %1, ptr %8, align 8
  switch i32 %.sroa.17.0.copyload, label %.loopexit [
    i32 1, label %9
    i32 -1, label %17
  ]

9:                                                ; preds = %7
  %10 = mul nsw i32 %.sroa.15.0.copyload, %2
  %11 = add nsw i32 %10, %.sroa.9.0.copyload
  %12 = add nsw i32 %11, %.sroa.15.0.copyload
  %13 = call i32 @llvm.smin.i32(i32 %.sroa.12.0.copyload, i32 %12)
  %14 = icmp slt i32 %11, %13
  br i1 %14, label %.lr.ph.preheader, label %.loopexit

.lr.ph.preheader:                                 ; preds = %9
  br label %.lr.ph

.lr.ph:                                           ; preds = %.lr.ph, %.lr.ph.preheader
  %.02039 = phi i32 [ %15, %.lr.ph ], [ %11, %.lr.ph.preheader ]
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.02039) #1
  %15 = add nsw i32 %.02039, 1
  %16 = icmp slt i32 %15, %13
  br i1 %16, label %.lr.ph, label %.loopexit.loopexit, !llvm.loop !50

17:                                               ; preds = %7
  %18 = mul nsw i32 %.sroa.15.0.copyload, %2
  %19 = sub nsw i32 %.sroa.12.0.copyload, %18
  %20 = mul nsw i32 %19, %.sroa.15.0.copyload
  %21 = call i32 @llvm.smax.i32(i32 %.sroa.9.0.copyload, i32 %20)
  %.not25.not40 = icmp sgt i32 %19, %21
  br i1 %.not25.not40, label %.lr.ph42.preheader, label %.loopexit

.lr.ph42.preheader:                               ; preds = %17
  br label %.lr.ph42

.lr.ph42:                                         ; preds = %.lr.ph42, %.lr.ph42.preheader
  %.0.in41 = phi i32 [ %.0, %.lr.ph42 ], [ %19, %.lr.ph42.preheader ]
  %.0 = add nsw i32 %.0.in41, -1
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.0) #1
  %.not25.not = icmp sgt i32 %.0, %21
  br i1 %.not25.not, label %.lr.ph42, label %.loopexit.loopexit47, !llvm.loop !52

.loopexit.loopexit:                               ; preds = %.lr.ph
  br label %.loopexit

.loopexit.loopexit47:                             ; preds = %.lr.ph42
  br label %.loopexit

.loopexit:                                        ; preds = %.loopexit.loopexit47, %.loopexit.loopexit, %17, %9, %7
  %.not24 = icmp eq ptr %.sroa.7.0.copyload, null
  br i1 %.not24, label %23, label %22

22:                                               ; preds = %.loopexit
  call void %.sroa.7.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %23

23:                                               ; preds = %22, %.loopexit
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #5

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #6

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #6

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smax.i32(i32, i32) #7

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { nofree nounwind }
attributes #3 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #5 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #6 = { argmemonly nocallback nofree nosync nounwind willreturn }
attributes #7 = { nocallback nofree nosync nounwind readnone speculatable willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.unroll.disable"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
!13 = distinct !{!13, !7}
!14 = distinct !{!14, !7}
!15 = distinct !{!15, !7}
!16 = distinct !{!16, !7}
!17 = distinct !{!17, !7}
!18 = distinct !{!18, !7}
!19 = distinct !{!19, !7}
!20 = distinct !{!20, !7}
!21 = distinct !{!21, !7}
!22 = distinct !{!22, !7}
!23 = distinct !{!23, !7}
!24 = distinct !{!24, !7}
!25 = distinct !{!25, !7}
!26 = distinct !{!26, !7}
!27 = distinct !{!27, !7}
!28 = distinct !{!28, !7}
!29 = distinct !{!29, !7}
!30 = distinct !{!30, !7}
!31 = distinct !{!31, !7}
!32 = distinct !{!32, !7}
!33 = distinct !{!33, !7}
!34 = distinct !{!34, !7}
!35 = distinct !{!35, !7}
!36 = distinct !{!36, !7}
!37 = distinct !{!37, !7}
!38 = distinct !{!38, !7}
!39 = distinct !{!39, !7}
!40 = distinct !{!40, !7}
!41 = distinct !{!41, !7}
!42 = distinct !{!42, !7}
!43 = distinct !{!43, !7}
!44 = distinct !{!44, !7}
!45 = distinct !{!45, !7}
!46 = distinct !{!46, !7}
!47 = distinct !{!47, !7}
!48 = distinct !{!48, !7}
!49 = distinct !{!49, !7}
!50 = distinct !{!50, !51}
!51 = !{!"llvm.loop.mustprogress"}
!52 = distinct !{!52, !51}
