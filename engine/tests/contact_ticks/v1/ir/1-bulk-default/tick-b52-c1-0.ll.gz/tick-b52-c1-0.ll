; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%0 = type { ptr, [2 x i32], %struct.PhysicalCoordinates.1918 }
%1 = type { %2, %2 }
%2 = type { [4 x i64], [4 x ptr] }
%struct.RuntimeContext.1905 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }
%struct.ListManager = type { [256 x ptr], i64, i64, i32, i32, i32, ptr }
%struct.PhysicalCoordinates.1918 = type { [12 x i32] }
%struct.cpu_block_task_helper_context = type { ptr, ptr, ptr, i32, i32, i64 }
%struct.range_task_helper_context = type { ptr, ptr, ptr, ptr, i64, i32, i32, i32, i32 }
%class.anon = type { ptr, ptr, ptr, ptr }

@.str = private unnamed_addr constant [28 x i8] c"Out of pre-allocated memory\00", align 1
@.str.2 = private unnamed_addr constant [28 x i8] c"List manager out of chunks.\00", align 1

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @field_clear_55_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %0, i64 0, i32 5
  %2 = load i32, ptr %1, align 4
  %3 = getelementptr inbounds %struct.RuntimeContext.1905, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  store i32 %2, ptr %6, align 4
  %7 = load ptr, ptr %context, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %7, i64 0, i32 7
  %9 = load i32, ptr %8, align 4
  %10 = load ptr, ptr %3, align 8
  %11 = getelementptr inbounds %struct.LLVMRuntime, ptr %10, i64 0, i32 16
  %12 = load ptr, ptr %11, align 8
  %13 = getelementptr inbounds i8, ptr %12, i64 4
  store i32 %9, ptr %13, align 4
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @field_clear_55_kernel_1_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.1905, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 54
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @field_clear_55_kernel_2_listgen_S54pointer(ptr %context) local_unnamed_addr #1 {
.lr.ph.i:
  %.sroa.2.i = alloca { [2 x i32], %struct.PhysicalCoordinates.1918 }, align 8
  %0 = alloca %0, align 8
  %1 = getelementptr inbounds %struct.RuntimeContext.1905, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 53
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %4, i64 54
  %8 = load ptr, ptr %7, align 8
  %9 = load atomic i64, ptr %6 acquire, align 8
  %.not.i.i.i.i = icmp ne i64 %9, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i)
  %10 = inttoptr i64 %9 to ptr
  %11 = load atomic i64, ptr %10 acquire, align 8
  %12 = inttoptr i64 %11 to ptr
  %.sroa.0.0.copyload.i = load ptr, ptr %12, align 8
  %.sroa.2.0..sroa_idx.i = getelementptr inbounds i8, ptr %12, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.i, ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.0..sroa_idx.i, i64 56, i1 false)
  %13 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %.sroa.2.16.sroa_idx.i = getelementptr inbounds i8, ptr %.sroa.2.i, i64 8
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %16 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 4
  %17 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 6
  %18 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 2
  %19 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  store ptr %.sroa.0.0.copyload.i, ptr %0, align 8
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %0, i64 8
  store <2 x i32> <i32 0, i32 4>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %13, ptr noundef nonnull align 8 dereferenceable(48) %.sroa.2.16.sroa_idx.i, i64 48, i1 false)
  %20 = atomicrmw volatile add ptr %14, i32 1 seq_cst, align 4
  %21 = load i32, ptr %15, align 8
  %22 = ashr i32 %20, %21
  %23 = icmp ugt i32 %22, 131071
  br i1 %23, label %24, label %26

24:                                               ; preds = %.lr.ph.i
  %25 = load ptr, ptr %17, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %25, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

26:                                               ; preds = %.lr.ph.i
  %27 = zext i32 %22 to i64
  %28 = lshr i64 %27, 9
  %29 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %28
  %30 = load atomic i64, ptr %29 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %30, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %26
  %31 = inttoptr i64 %30 to ptr
  %32 = and i64 %27, 511
  %33 = getelementptr inbounds ptr, ptr %31, i64 %32
  %34 = load atomic i64, ptr %33 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %26
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %35 = atomicrmw volatile xchg ptr %16, i32 1 seq_cst, align 4
  %36 = icmp eq i32 %35, 1
  br i1 %36, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %37 = load atomic i64, ptr %29 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %37, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %39, label %73

39:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %40 = load ptr, ptr %17, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1
  %42 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 28
  %43 = atomicrmw volatile add ptr %42, i64 4096 seq_cst, align 8
  %44 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 2
  %45 = load i64, ptr %44, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %45, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %66, label %46

46:                                               ; preds = %39
  %47 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 26
  br label %48

48:                                               ; preds = %48, %46
  %49 = atomicrmw volatile xchg ptr %47, i32 1 seq_cst, align 4
  %50 = icmp eq i32 %49, 1
  br i1 %50, label %48, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %48
  %51 = load ptr, ptr %41, align 8
  %52 = ptrtoint ptr %51 to i64
  %53 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 1
  %54 = load ptr, ptr %53, align 8
  %55 = ptrtoint ptr %54 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %52
  %56 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %57 = or i64 %56, 4096
  %58 = add i64 %57, %52
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %58, %55
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %59

59:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %60 = add i64 %56, %52
  %61 = inttoptr i64 %60 to ptr
  %62 = getelementptr i8, ptr %51, i64 %56
  %63 = getelementptr inbounds i8, ptr %62, i64 4096
  store ptr %63, ptr %41, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %59, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %61, %59 ]
  %64 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %65 = atomicrmw volatile xchg ptr %47, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %40, i1 noundef zeroext %64, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

66:                                               ; preds = %39
  %67 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 2
  %68 = load ptr, ptr %67, align 8
  %69 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 6
  %70 = load ptr, ptr %69, align 8
  %71 = tail call noundef ptr %68(ptr noundef %70, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %66, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %71, %66 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %72 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %72, ptr %29 release, align 8
  br label %73

73:                                               ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %38, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %74 = and i32 %22, 511
  %75 = zext i32 %74 to i64
  %76 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %75
  %77 = load atomic i64, ptr %76 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %77, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %78, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

78:                                               ; preds = %73
  %79 = load ptr, ptr %17, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1
  %81 = load i64, ptr %18, align 8
  %82 = load i64, ptr %19, align 8
  %83 = mul i64 %82, %81
  %84 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 28
  %85 = atomicrmw volatile add ptr %84, i64 %83 seq_cst, align 8
  %86 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 2
  %87 = load i64, ptr %86, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %87, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %107, label %88

88:                                               ; preds = %78
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 26
  br label %90

90:                                               ; preds = %90, %88
  %91 = atomicrmw volatile xchg ptr %89, i32 1 seq_cst, align 4
  %92 = icmp eq i32 %91, 1
  br i1 %92, label %90, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %90
  %93 = load ptr, ptr %80, align 8
  %94 = ptrtoint ptr %93 to i64
  %95 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 1
  %96 = load ptr, ptr %95, align 8
  %97 = ptrtoint ptr %96 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %94
  %98 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %99 = add i64 %98, %83
  %100 = add i64 %99, %94
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %100, %97
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %101

101:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %102 = add i64 %98, %94
  %103 = inttoptr i64 %102 to ptr
  %104 = getelementptr inbounds i8, ptr %93, i64 %99
  store ptr %104, ptr %80, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %101, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %103, %101 ]
  %105 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %106 = atomicrmw volatile xchg ptr %89, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %79, i1 noundef zeroext %105, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

107:                                              ; preds = %78
  %108 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 2
  %109 = load ptr, ptr %108, align 8
  %110 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 6
  %111 = load ptr, ptr %110, align 8
  %112 = tail call noundef ptr %109(ptr noundef %111, i64 noundef %83, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %107, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %112, %107 ]
  %113 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %113, ptr %76 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %73
  %114 = atomicrmw volatile xchg ptr %16, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %24
  %115 = load i32, ptr %15, align 8
  %116 = ashr i32 %20, %115
  %117 = sext i32 %116 to i64
  %118 = lshr i64 %117, 9
  %119 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %118
  %120 = load atomic i64, ptr %119 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %120, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %121

121:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %122 = inttoptr i64 %120 to ptr
  %123 = and i64 %117, 511
  %124 = getelementptr inbounds ptr, ptr %122, i64 %123
  %125 = load atomic i64, ptr %124 acquire, align 8
  %126 = inttoptr i64 %125 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %121, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %127 = phi ptr [ %126, %121 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %128 = load i64, ptr %19, align 8
  %129 = load i32, ptr %15, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %129
  %130 = xor i32 %notmask.i.i.i.i, -1
  %131 = and i32 %20, %130
  %132 = sext i32 %131 to i64
  %133 = mul i64 %128, %132
  %134 = getelementptr inbounds i8, ptr %127, i64 %133
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %134, ptr nonnull align 8 %0, i64 %128, i1 false)
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @field_clear_55_kernel_3_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.1905, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 55
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @field_clear_55_kernel_4_listgen_S55bitmasked(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %0, align 8
  %1 = alloca %struct.PhysicalCoordinates.1918, align 4
  %2 = alloca %0, align 8
  %3 = getelementptr inbounds %struct.RuntimeContext.1905, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %2)
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 13
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %6, i64 54
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %10 = load i32, ptr %9, align 8
  %11 = getelementptr inbounds ptr, ptr %6, i64 55
  %12 = load ptr, ptr %11, align 8
  %13 = icmp sgt i32 %10, 0
  br i1 %13, label %.lr.ph61.i, label %element_listgen_nonroot.exit

.lr.ph61.i:                                       ; preds = %entry
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  %16 = getelementptr inbounds %0, ptr %0, i64 0, i32 1
  %17 = getelementptr inbounds %0, ptr %0, i64 0, i32 1, i64 1
  %18 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %19 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %20 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 5
  %21 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %22 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 4
  %23 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 6
  %24 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 2
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %2, i64 8
  br label %26

26:                                               ; preds = %._crit_edge.i, %.lr.ph61.i
  %.04359.i = phi i32 [ 0, %.lr.ph61.i ], [ %172, %._crit_edge.i ]
  %27 = load i32, ptr %14, align 8
  %28 = lshr i32 %.04359.i, %27
  %29 = sext i32 %28 to i64
  %30 = lshr i64 %29, 9
  %31 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %30
  %32 = load atomic i64, ptr %31 acquire, align 8
  %.not.i.i.i.i = icmp eq i64 %32, 0
  br i1 %.not.i.i.i.i, label %_ZN11ListManager3getI7ElementEERT_i.exit.i, label %33

33:                                               ; preds = %26
  %34 = inttoptr i64 %32 to ptr
  %35 = and i64 %29, 511
  %36 = getelementptr inbounds ptr, ptr %34, i64 %35
  %37 = load atomic i64, ptr %36 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit.i

_ZN11ListManager3getI7ElementEERT_i.exit.i:       ; preds = %33, %26
  %39 = phi ptr [ %38, %33 ], [ null, %26 ]
  %40 = load i64, ptr %15, align 8
  %41 = load i32, ptr %14, align 8
  %notmask.i.i.i = shl nsw i32 -1, %41
  %42 = xor i32 %notmask.i.i.i, -1
  %43 = and i32 %.04359.i, %42
  %44 = zext i32 %43 to i64
  %45 = mul i64 %40, %44
  %46 = getelementptr inbounds i8, ptr %39, i64 %45
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %0, ptr noundef nonnull align 8 dereferenceable(64) %46, i64 64, i1 false)
  %47 = load i32, ptr %16, align 8
  %48 = load i32, ptr %17, align 4
  %49 = icmp slt i32 %47, %48
  br i1 %49, label %.lr.ph58.i.preheader, label %._crit_edge.i

.lr.ph58.i.preheader:                             ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit.i
  br label %.lr.ph58.i

.lr.ph58.i:                                       ; preds = %.loopexit.i, %.lr.ph58.i.preheader
  %.04457.i = phi i32 [ %171, %.loopexit.i ], [ %47, %.lr.ph58.i.preheader ]
  call fastcc void @S54_refine_coordinates(ptr noundef nonnull %18, ptr noundef nonnull %1, i32 noundef %.04457.i) #1
  %50 = load ptr, ptr %0, align 8
  %51 = shl i32 %.04457.i, 3
  %52 = sext i32 %51 to i64
  %53 = getelementptr i8, ptr %50, i64 %52
  %54 = getelementptr inbounds i8, ptr %53, i64 32
  %55 = load ptr, ptr %54, align 8
  %.not = icmp eq ptr %55, null
  br i1 %.not, label %.loopexit.i, label %.lr.ph.i

.lr.ph.i:                                         ; preds = %.lr.ph58.i
  store ptr %55, ptr %2, align 8
  store <2 x i32> <i32 0, i32 32>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %19, ptr noundef nonnull align 4 dereferenceable(48) %1, i64 48, i1 false)
  %56 = atomicrmw volatile add ptr %20, i32 1 seq_cst, align 4
  %57 = load i32, ptr %21, align 8
  %58 = ashr i32 %56, %57
  %59 = icmp ugt i32 %58, 131071
  br i1 %59, label %60, label %62

60:                                               ; preds = %.lr.ph.i
  %61 = load ptr, ptr %23, align 8
  call fastcc void @taichi_assert_format(ptr noundef %61, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

62:                                               ; preds = %.lr.ph.i
  %63 = zext i32 %58 to i64
  %64 = lshr i64 %63, 9
  %65 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %64
  %66 = load atomic i64, ptr %65 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %66, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %62
  %67 = inttoptr i64 %66 to ptr
  %68 = and i64 %63, 511
  %69 = getelementptr inbounds ptr, ptr %67, i64 %68
  %70 = load atomic i64, ptr %69 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %70, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %62
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %71 = atomicrmw volatile xchg ptr %22, i32 1 seq_cst, align 4
  %72 = icmp eq i32 %71, 1
  br i1 %72, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %73 = load atomic i64, ptr %65 acquire, align 8
  %74 = inttoptr i64 %73 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %73, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %75, label %109

75:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %76 = load ptr, ptr %23, align 8
  %77 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1
  %78 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 28
  %79 = atomicrmw volatile add ptr %78, i64 4096 seq_cst, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 2
  %81 = load i64, ptr %80, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %81, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %102, label %82

82:                                               ; preds = %75
  %83 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 26
  br label %84

84:                                               ; preds = %84, %82
  %85 = atomicrmw volatile xchg ptr %83, i32 1 seq_cst, align 4
  %86 = icmp eq i32 %85, 1
  br i1 %86, label %84, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %84
  %87 = load ptr, ptr %77, align 8
  %88 = ptrtoint ptr %87 to i64
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 1
  %90 = load ptr, ptr %89, align 8
  %91 = ptrtoint ptr %90 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %88
  %92 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %93 = or i64 %92, 4096
  %94 = add i64 %93, %88
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %94, %91
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %95

95:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %96 = add i64 %92, %88
  %97 = inttoptr i64 %96 to ptr
  %98 = getelementptr i8, ptr %87, i64 %92
  %99 = getelementptr inbounds i8, ptr %98, i64 4096
  store ptr %99, ptr %77, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %95, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %97, %95 ]
  %100 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %101 = atomicrmw volatile xchg ptr %83, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %76, i1 noundef zeroext %100, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

102:                                              ; preds = %75
  %103 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 2
  %104 = load ptr, ptr %103, align 8
  %105 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 6
  %106 = load ptr, ptr %105, align 8
  %107 = call noundef ptr %104(ptr noundef %106, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %102, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %107, %102 ]
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %108 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %108, ptr %65 release, align 8
  br label %109

109:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %74, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %110 = and i32 %58, 511
  %111 = zext i32 %110 to i64
  %112 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %111
  %113 = load atomic i64, ptr %112 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %113, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %114, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

114:                                              ; preds = %109
  %115 = load ptr, ptr %23, align 8
  %116 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1
  %117 = load i64, ptr %24, align 8
  %118 = load i64, ptr %25, align 8
  %119 = mul i64 %118, %117
  %120 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 28
  %121 = atomicrmw volatile add ptr %120, i64 %119 seq_cst, align 8
  %122 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 2
  %123 = load i64, ptr %122, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %123, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %143, label %124

124:                                              ; preds = %114
  %125 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 26
  br label %126

126:                                              ; preds = %126, %124
  %127 = atomicrmw volatile xchg ptr %125, i32 1 seq_cst, align 4
  %128 = icmp eq i32 %127, 1
  br i1 %128, label %126, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %126
  %129 = load ptr, ptr %116, align 8
  %130 = ptrtoint ptr %129 to i64
  %131 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 1
  %132 = load ptr, ptr %131, align 8
  %133 = ptrtoint ptr %132 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %130
  %134 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %135 = add i64 %134, %119
  %136 = add i64 %135, %130
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %136, %133
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %137

137:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %138 = add i64 %134, %130
  %139 = inttoptr i64 %138 to ptr
  %140 = getelementptr inbounds i8, ptr %129, i64 %135
  store ptr %140, ptr %116, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %137, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %139, %137 ]
  %141 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %142 = atomicrmw volatile xchg ptr %125, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %115, i1 noundef zeroext %141, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

143:                                              ; preds = %114
  %144 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 2
  %145 = load ptr, ptr %144, align 8
  %146 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 6
  %147 = load ptr, ptr %146, align 8
  %148 = call noundef ptr %145(ptr noundef %147, i64 noundef %119, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %143, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %148, %143 ]
  %149 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %149, ptr %112 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %109
  %150 = atomicrmw volatile xchg ptr %22, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %60
  %151 = load i32, ptr %21, align 8
  %152 = ashr i32 %56, %151
  %153 = sext i32 %152 to i64
  %154 = lshr i64 %153, 9
  %155 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %154
  %156 = load atomic i64, ptr %155 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %156, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %157

157:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %158 = inttoptr i64 %156 to ptr
  %159 = and i64 %153, 511
  %160 = getelementptr inbounds ptr, ptr %158, i64 %159
  %161 = load atomic i64, ptr %160 acquire, align 8
  %162 = inttoptr i64 %161 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %157, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %163 = phi ptr [ %162, %157 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %164 = load i64, ptr %25, align 8
  %165 = load i32, ptr %21, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %165
  %166 = xor i32 %notmask.i.i.i.i, -1
  %167 = and i32 %56, %166
  %168 = sext i32 %167 to i64
  %169 = mul i64 %164, %168
  %170 = getelementptr inbounds i8, ptr %163, i64 %169
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %170, ptr nonnull align 8 %2, i64 %164, i1 false)
  br label %.loopexit.i, !llvm.loop !8

.loopexit.i:                                      ; preds = %_ZN11ListManager6appendEPv.exit.i, %.lr.ph58.i
  %171 = add i32 %.04457.i, 1
  %exitcond.not.i = icmp eq i32 %171, %48
  br i1 %exitcond.not.i, label %._crit_edge.i.loopexit, label %.lr.ph58.i, !llvm.loop !9

._crit_edge.i.loopexit:                           ; preds = %.loopexit.i
  br label %._crit_edge.i

._crit_edge.i:                                    ; preds = %._crit_edge.i.loopexit, %_ZN11ListManager3getI7ElementEERT_i.exit.i
  %172 = add nuw nsw i32 %.04359.i, 1
  %exitcond63.not.i = icmp eq i32 %172, %10
  br i1 %exitcond63.not.i, label %element_listgen_nonroot.exit.loopexit, label %26, !llvm.loop !10

element_listgen_nonroot.exit.loopexit:            ; preds = %._crit_edge.i
  br label %element_listgen_nonroot.exit

element_listgen_nonroot.exit:                     ; preds = %element_listgen_nonroot.exit.loopexit, %entry
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %2)
  ret void
}

; Function Attrs: nounwind
define void @field_clear_55_kernel_5_struct_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.cpu_block_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.RuntimeContext.1905, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 55
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds %struct.ListManager, ptr %6, i64 0, i32 5
  %8 = load i32, ptr %7, align 8
  store ptr %context, ptr %0, align 8
  %9 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  store ptr @function_body, ptr %9, align 8
  %10 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  store ptr %6, ptr %10, align 8
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  store <2 x i32> <i32 32, i32 8>, ptr %11, align 8
  %12 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  store i64 1, ptr %12, align 8
  %13 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 12
  %14 = load ptr, ptr %13, align 8
  %15 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 11
  %16 = load ptr, ptr %15, align 8
  %17 = shl nsw i32 %8, 3
  call void %14(ptr noundef %16, i32 noundef %17, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_struct_for_block_helper) #1
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind
define internal void @function_body(ptr %0, ptr nocapture readnone %1, ptr nocapture readonly %2, i32 %3, i32 %4) #2 {
allocs:
  %5 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %6 = icmp sgt i32 %4, %3
  br i1 %6, label %loop_body.preheader, label %func_exit

loop_body.preheader:                              ; preds = %allocs
  %.pre25 = load ptr, ptr %2, align 8
  %7 = sub i32 %4, %3
  %8 = xor i32 %3, -1
  %9 = add i32 %8, %4
  %xtraiter = and i32 %7, 7
  %lcmp.mod.not = icmp eq i32 %xtraiter, 0
  br i1 %lcmp.mod.not, label %loop_body.prol.loopexit, label %loop_body.prol.preheader

loop_body.prol.preheader:                         ; preds = %loop_body.preheader
  br label %loop_body.prol

loop_body.prol:                                   ; preds = %loop_body_tail.prol, %loop_body.prol.preheader
  %lsr.iv27 = phi i32 [ %xtraiter, %loop_body.prol.preheader ], [ %lsr.iv.next28, %loop_body_tail.prol ]
  %10 = phi ptr [ %46, %loop_body_tail.prol ], [ %.pre25, %loop_body.prol.preheader ]
  %.024.prol = phi i32 [ %47, %loop_body_tail.prol ], [ %3, %loop_body.prol.preheader ]
  %11 = getelementptr inbounds i8, ptr %10, i64 32
  %12 = sdiv i32 %.024.prol, 8
  %13 = sext i32 %12 to i64
  %14 = getelementptr inbounds i8, ptr %11, i64 %13
  %15 = load i8, ptr %14, align 1
  %16 = zext i8 %15 to i32
  %17 = and i32 %.024.prol, 7
  %18 = shl nuw nsw i32 1, %17
  %19 = and i32 %18, %16
  %.not.prol = icmp eq i32 %19, 0
  br i1 %.not.prol, label %loop_body_tail.prol, label %struct_for_body_body.prol

struct_for_body_body.prol:                        ; preds = %loop_body.prol
  %20 = load i32, ptr %5, align 4
  %21 = shl i32 %20, 5
  %22 = and i32 %.024.prol, 31
  %23 = or i32 %21, %22
  %24 = load ptr, ptr %0, align 8
  %25 = getelementptr { { i32, i32 }, ptr }, ptr %24, i64 0, i32 1
  %26 = load ptr, ptr %25, align 8
  %27 = getelementptr { { i32, i32 }, ptr }, ptr %24, i64 0, i32 0, i32 1
  %28 = load i32, ptr %27, align 4
  %29 = sext i32 %28 to i64
  %30 = shl nsw i64 %29, 3
  %31 = sext i32 %23 to i64
  %32 = add nsw i64 %30, %31
  %33 = getelementptr double, ptr %26, i64 %32
  store double 0.000000e+00, ptr %33, align 8
  %34 = load ptr, ptr %25, align 8
  %35 = load i32, ptr %27, align 4
  %36 = sext i32 %35 to i64
  %37 = mul nsw i64 %36, 9
  %38 = add nsw i64 %37, %31
  %39 = getelementptr double, ptr %34, i64 %38
  store double 0.000000e+00, ptr %39, align 8
  %40 = load ptr, ptr %25, align 8
  %41 = load i32, ptr %27, align 4
  %42 = sext i32 %41 to i64
  %43 = mul nsw i64 %42, 10
  %44 = add nsw i64 %43, %31
  %45 = getelementptr double, ptr %40, i64 %44
  store double 0.000000e+00, ptr %45, align 8
  %.pre.prol = load ptr, ptr %2, align 8
  br label %loop_body_tail.prol

loop_body_tail.prol:                              ; preds = %struct_for_body_body.prol, %loop_body.prol
  %46 = phi ptr [ %.pre.prol, %struct_for_body_body.prol ], [ %10, %loop_body.prol ]
  %47 = add i32 %.024.prol, 1
  %lsr.iv.next28 = add nsw i32 %lsr.iv27, -1
  %prol.iter.cmp.not = icmp eq i32 %lsr.iv.next28, 0
  br i1 %prol.iter.cmp.not, label %loop_body.prol.loopexit.loopexit, label %loop_body.prol, !llvm.loop !11

loop_body.prol.loopexit.loopexit:                 ; preds = %loop_body_tail.prol
  br label %loop_body.prol.loopexit

loop_body.prol.loopexit:                          ; preds = %loop_body.prol.loopexit.loopexit, %loop_body.preheader
  %.unr = phi ptr [ %.pre25, %loop_body.preheader ], [ %46, %loop_body.prol.loopexit.loopexit ]
  %.024.unr = phi i32 [ %3, %loop_body.preheader ], [ %47, %loop_body.prol.loopexit.loopexit ]
  %48 = icmp ult i32 %9, 7
  br i1 %48, label %func_exit, label %loop_body.preheader.new

loop_body.preheader.new:                          ; preds = %loop_body.prol.loopexit
  %49 = and i32 %.024.unr, 7
  %50 = add i32 %.024.unr, 1
  %51 = and i32 %50, 7
  %52 = add i32 %.024.unr, 2
  %53 = and i32 %52, 7
  %54 = add i32 %.024.unr, 3
  %55 = and i32 %54, 7
  %56 = xor i32 %49, 4
  %57 = add i32 %.024.unr, 5
  %58 = and i32 %57, 7
  %59 = add i32 %.024.unr, 6
  %60 = and i32 %59, 7
  %61 = add i32 %.024.unr, 7
  %62 = and i32 %61, 7
  %63 = shl nuw nsw i32 1, %49
  %64 = shl nuw nsw i32 1, %51
  %65 = shl nuw nsw i32 1, %53
  %66 = shl nuw nsw i32 1, %55
  %67 = shl nuw nsw i32 1, %56
  %68 = shl nuw nsw i32 1, %58
  %69 = shl nuw nsw i32 1, %60
  %70 = shl nuw nsw i32 1, %62
  br label %loop_body

loop_body:                                        ; preds = %loop_body_tail.7, %loop_body.preheader.new
  %lsr.iv = phi i32 [ %lsr.iv.next, %loop_body_tail.7 ], [ %61, %loop_body.preheader.new ]
  %71 = phi ptr [ %.unr, %loop_body.preheader.new ], [ %331, %loop_body_tail.7 ]
  %72 = add i32 %lsr.iv, -7
  %73 = getelementptr inbounds i8, ptr %71, i64 32
  %74 = sdiv i32 %72, 8
  %75 = sext i32 %74 to i64
  %76 = getelementptr inbounds i8, ptr %73, i64 %75
  %77 = load i8, ptr %76, align 1
  %78 = zext i8 %77 to i32
  %79 = and i32 %63, %78
  %.not = icmp eq i32 %79, 0
  br i1 %.not, label %loop_body_tail, label %struct_for_body_body

loop_body_tail:                                   ; preds = %struct_for_body_body, %loop_body
  %80 = phi ptr [ %.pre, %struct_for_body_body ], [ %71, %loop_body ]
  %81 = add i32 %lsr.iv, -6
  %82 = getelementptr inbounds i8, ptr %80, i64 32
  %83 = add i32 %72, 1
  %84 = sdiv i32 %83, 8
  %85 = sext i32 %84 to i64
  %86 = getelementptr inbounds i8, ptr %82, i64 %85
  %87 = load i8, ptr %86, align 1
  %88 = zext i8 %87 to i32
  %89 = and i32 %64, %88
  %.not.1 = icmp eq i32 %89, 0
  br i1 %.not.1, label %loop_body_tail.1, label %struct_for_body_body.1

struct_for_body_body.1:                           ; preds = %loop_body_tail
  %90 = load i32, ptr %5, align 4
  %91 = shl i32 %90, 5
  %92 = and i32 %81, 31
  %93 = or i32 %91, %92
  %94 = load ptr, ptr %0, align 8
  %95 = getelementptr { { i32, i32 }, ptr }, ptr %94, i64 0, i32 1
  %96 = load ptr, ptr %95, align 8
  %97 = getelementptr { { i32, i32 }, ptr }, ptr %94, i64 0, i32 0, i32 1
  %98 = load i32, ptr %97, align 4
  %99 = sext i32 %98 to i64
  %100 = shl nsw i64 %99, 3
  %101 = sext i32 %93 to i64
  %102 = add nsw i64 %100, %101
  %103 = getelementptr double, ptr %96, i64 %102
  store double 0.000000e+00, ptr %103, align 8
  %104 = load ptr, ptr %95, align 8
  %105 = load i32, ptr %97, align 4
  %106 = sext i32 %105 to i64
  %107 = mul nsw i64 %106, 9
  %108 = add nsw i64 %107, %101
  %109 = getelementptr double, ptr %104, i64 %108
  store double 0.000000e+00, ptr %109, align 8
  %110 = load ptr, ptr %95, align 8
  %111 = load i32, ptr %97, align 4
  %112 = sext i32 %111 to i64
  %113 = mul nsw i64 %112, 10
  %114 = add nsw i64 %113, %101
  %115 = getelementptr double, ptr %110, i64 %114
  store double 0.000000e+00, ptr %115, align 8
  %.pre.1 = load ptr, ptr %2, align 8
  br label %loop_body_tail.1

loop_body_tail.1:                                 ; preds = %struct_for_body_body.1, %loop_body_tail
  %116 = phi ptr [ %.pre.1, %struct_for_body_body.1 ], [ %80, %loop_body_tail ]
  %117 = add i32 %lsr.iv, -5
  %118 = getelementptr inbounds i8, ptr %116, i64 32
  %119 = add i32 %83, 1
  %120 = sdiv i32 %119, 8
  %121 = sext i32 %120 to i64
  %122 = getelementptr inbounds i8, ptr %118, i64 %121
  %123 = load i8, ptr %122, align 1
  %124 = zext i8 %123 to i32
  %125 = and i32 %65, %124
  %.not.2 = icmp eq i32 %125, 0
  br i1 %.not.2, label %loop_body_tail.2, label %struct_for_body_body.2

struct_for_body_body.2:                           ; preds = %loop_body_tail.1
  %126 = load i32, ptr %5, align 4
  %127 = shl i32 %126, 5
  %128 = and i32 %117, 31
  %129 = or i32 %127, %128
  %130 = load ptr, ptr %0, align 8
  %131 = getelementptr { { i32, i32 }, ptr }, ptr %130, i64 0, i32 1
  %132 = load ptr, ptr %131, align 8
  %133 = getelementptr { { i32, i32 }, ptr }, ptr %130, i64 0, i32 0, i32 1
  %134 = load i32, ptr %133, align 4
  %135 = sext i32 %134 to i64
  %136 = shl nsw i64 %135, 3
  %137 = sext i32 %129 to i64
  %138 = add nsw i64 %136, %137
  %139 = getelementptr double, ptr %132, i64 %138
  store double 0.000000e+00, ptr %139, align 8
  %140 = load ptr, ptr %131, align 8
  %141 = load i32, ptr %133, align 4
  %142 = sext i32 %141 to i64
  %143 = mul nsw i64 %142, 9
  %144 = add nsw i64 %143, %137
  %145 = getelementptr double, ptr %140, i64 %144
  store double 0.000000e+00, ptr %145, align 8
  %146 = load ptr, ptr %131, align 8
  %147 = load i32, ptr %133, align 4
  %148 = sext i32 %147 to i64
  %149 = mul nsw i64 %148, 10
  %150 = add nsw i64 %149, %137
  %151 = getelementptr double, ptr %146, i64 %150
  store double 0.000000e+00, ptr %151, align 8
  %.pre.2 = load ptr, ptr %2, align 8
  br label %loop_body_tail.2

loop_body_tail.2:                                 ; preds = %struct_for_body_body.2, %loop_body_tail.1
  %152 = phi ptr [ %.pre.2, %struct_for_body_body.2 ], [ %116, %loop_body_tail.1 ]
  %153 = add i32 %lsr.iv, -4
  %154 = getelementptr inbounds i8, ptr %152, i64 32
  %155 = add i32 %119, 1
  %156 = sdiv i32 %155, 8
  %157 = sext i32 %156 to i64
  %158 = getelementptr inbounds i8, ptr %154, i64 %157
  %159 = load i8, ptr %158, align 1
  %160 = zext i8 %159 to i32
  %161 = and i32 %66, %160
  %.not.3 = icmp eq i32 %161, 0
  br i1 %.not.3, label %loop_body_tail.3, label %struct_for_body_body.3

struct_for_body_body.3:                           ; preds = %loop_body_tail.2
  %162 = load i32, ptr %5, align 4
  %163 = shl i32 %162, 5
  %164 = and i32 %153, 31
  %165 = or i32 %163, %164
  %166 = load ptr, ptr %0, align 8
  %167 = getelementptr { { i32, i32 }, ptr }, ptr %166, i64 0, i32 1
  %168 = load ptr, ptr %167, align 8
  %169 = getelementptr { { i32, i32 }, ptr }, ptr %166, i64 0, i32 0, i32 1
  %170 = load i32, ptr %169, align 4
  %171 = sext i32 %170 to i64
  %172 = shl nsw i64 %171, 3
  %173 = sext i32 %165 to i64
  %174 = add nsw i64 %172, %173
  %175 = getelementptr double, ptr %168, i64 %174
  store double 0.000000e+00, ptr %175, align 8
  %176 = load ptr, ptr %167, align 8
  %177 = load i32, ptr %169, align 4
  %178 = sext i32 %177 to i64
  %179 = mul nsw i64 %178, 9
  %180 = add nsw i64 %179, %173
  %181 = getelementptr double, ptr %176, i64 %180
  store double 0.000000e+00, ptr %181, align 8
  %182 = load ptr, ptr %167, align 8
  %183 = load i32, ptr %169, align 4
  %184 = sext i32 %183 to i64
  %185 = mul nsw i64 %184, 10
  %186 = add nsw i64 %185, %173
  %187 = getelementptr double, ptr %182, i64 %186
  store double 0.000000e+00, ptr %187, align 8
  %.pre.3 = load ptr, ptr %2, align 8
  br label %loop_body_tail.3

loop_body_tail.3:                                 ; preds = %struct_for_body_body.3, %loop_body_tail.2
  %188 = phi ptr [ %.pre.3, %struct_for_body_body.3 ], [ %152, %loop_body_tail.2 ]
  %189 = add i32 %lsr.iv, -3
  %190 = getelementptr inbounds i8, ptr %188, i64 32
  %191 = add i32 %155, 1
  %192 = sdiv i32 %191, 8
  %193 = sext i32 %192 to i64
  %194 = getelementptr inbounds i8, ptr %190, i64 %193
  %195 = load i8, ptr %194, align 1
  %196 = zext i8 %195 to i32
  %197 = and i32 %67, %196
  %.not.4 = icmp eq i32 %197, 0
  br i1 %.not.4, label %loop_body_tail.4, label %struct_for_body_body.4

struct_for_body_body.4:                           ; preds = %loop_body_tail.3
  %198 = load i32, ptr %5, align 4
  %199 = shl i32 %198, 5
  %200 = and i32 %189, 31
  %201 = or i32 %199, %200
  %202 = load ptr, ptr %0, align 8
  %203 = getelementptr { { i32, i32 }, ptr }, ptr %202, i64 0, i32 1
  %204 = load ptr, ptr %203, align 8
  %205 = getelementptr { { i32, i32 }, ptr }, ptr %202, i64 0, i32 0, i32 1
  %206 = load i32, ptr %205, align 4
  %207 = sext i32 %206 to i64
  %208 = shl nsw i64 %207, 3
  %209 = sext i32 %201 to i64
  %210 = add nsw i64 %208, %209
  %211 = getelementptr double, ptr %204, i64 %210
  store double 0.000000e+00, ptr %211, align 8
  %212 = load ptr, ptr %203, align 8
  %213 = load i32, ptr %205, align 4
  %214 = sext i32 %213 to i64
  %215 = mul nsw i64 %214, 9
  %216 = add nsw i64 %215, %209
  %217 = getelementptr double, ptr %212, i64 %216
  store double 0.000000e+00, ptr %217, align 8
  %218 = load ptr, ptr %203, align 8
  %219 = load i32, ptr %205, align 4
  %220 = sext i32 %219 to i64
  %221 = mul nsw i64 %220, 10
  %222 = add nsw i64 %221, %209
  %223 = getelementptr double, ptr %218, i64 %222
  store double 0.000000e+00, ptr %223, align 8
  %.pre.4 = load ptr, ptr %2, align 8
  br label %loop_body_tail.4

loop_body_tail.4:                                 ; preds = %struct_for_body_body.4, %loop_body_tail.3
  %224 = phi ptr [ %.pre.4, %struct_for_body_body.4 ], [ %188, %loop_body_tail.3 ]
  %225 = add i32 %lsr.iv, -2
  %226 = getelementptr inbounds i8, ptr %224, i64 32
  %227 = add i32 %191, 1
  %228 = sdiv i32 %227, 8
  %229 = sext i32 %228 to i64
  %230 = getelementptr inbounds i8, ptr %226, i64 %229
  %231 = load i8, ptr %230, align 1
  %232 = zext i8 %231 to i32
  %233 = and i32 %68, %232
  %.not.5 = icmp eq i32 %233, 0
  br i1 %.not.5, label %loop_body_tail.5, label %struct_for_body_body.5

struct_for_body_body.5:                           ; preds = %loop_body_tail.4
  %234 = load i32, ptr %5, align 4
  %235 = shl i32 %234, 5
  %236 = and i32 %225, 31
  %237 = or i32 %235, %236
  %238 = load ptr, ptr %0, align 8
  %239 = getelementptr { { i32, i32 }, ptr }, ptr %238, i64 0, i32 1
  %240 = load ptr, ptr %239, align 8
  %241 = getelementptr { { i32, i32 }, ptr }, ptr %238, i64 0, i32 0, i32 1
  %242 = load i32, ptr %241, align 4
  %243 = sext i32 %242 to i64
  %244 = shl nsw i64 %243, 3
  %245 = sext i32 %237 to i64
  %246 = add nsw i64 %244, %245
  %247 = getelementptr double, ptr %240, i64 %246
  store double 0.000000e+00, ptr %247, align 8
  %248 = load ptr, ptr %239, align 8
  %249 = load i32, ptr %241, align 4
  %250 = sext i32 %249 to i64
  %251 = mul nsw i64 %250, 9
  %252 = add nsw i64 %251, %245
  %253 = getelementptr double, ptr %248, i64 %252
  store double 0.000000e+00, ptr %253, align 8
  %254 = load ptr, ptr %239, align 8
  %255 = load i32, ptr %241, align 4
  %256 = sext i32 %255 to i64
  %257 = mul nsw i64 %256, 10
  %258 = add nsw i64 %257, %245
  %259 = getelementptr double, ptr %254, i64 %258
  store double 0.000000e+00, ptr %259, align 8
  %.pre.5 = load ptr, ptr %2, align 8
  br label %loop_body_tail.5

loop_body_tail.5:                                 ; preds = %struct_for_body_body.5, %loop_body_tail.4
  %260 = phi ptr [ %.pre.5, %struct_for_body_body.5 ], [ %224, %loop_body_tail.4 ]
  %261 = add i32 %lsr.iv, -1
  %262 = getelementptr inbounds i8, ptr %260, i64 32
  %263 = add i32 %227, 1
  %264 = sdiv i32 %263, 8
  %265 = sext i32 %264 to i64
  %266 = getelementptr inbounds i8, ptr %262, i64 %265
  %267 = load i8, ptr %266, align 1
  %268 = zext i8 %267 to i32
  %269 = and i32 %69, %268
  %.not.6 = icmp eq i32 %269, 0
  br i1 %.not.6, label %loop_body_tail.6, label %struct_for_body_body.6

struct_for_body_body.6:                           ; preds = %loop_body_tail.5
  %270 = load i32, ptr %5, align 4
  %271 = shl i32 %270, 5
  %272 = and i32 %261, 31
  %273 = or i32 %271, %272
  %274 = load ptr, ptr %0, align 8
  %275 = getelementptr { { i32, i32 }, ptr }, ptr %274, i64 0, i32 1
  %276 = load ptr, ptr %275, align 8
  %277 = getelementptr { { i32, i32 }, ptr }, ptr %274, i64 0, i32 0, i32 1
  %278 = load i32, ptr %277, align 4
  %279 = sext i32 %278 to i64
  %280 = shl nsw i64 %279, 3
  %281 = sext i32 %273 to i64
  %282 = add nsw i64 %280, %281
  %283 = getelementptr double, ptr %276, i64 %282
  store double 0.000000e+00, ptr %283, align 8
  %284 = load ptr, ptr %275, align 8
  %285 = load i32, ptr %277, align 4
  %286 = sext i32 %285 to i64
  %287 = mul nsw i64 %286, 9
  %288 = add nsw i64 %287, %281
  %289 = getelementptr double, ptr %284, i64 %288
  store double 0.000000e+00, ptr %289, align 8
  %290 = load ptr, ptr %275, align 8
  %291 = load i32, ptr %277, align 4
  %292 = sext i32 %291 to i64
  %293 = mul nsw i64 %292, 10
  %294 = add nsw i64 %293, %281
  %295 = getelementptr double, ptr %290, i64 %294
  store double 0.000000e+00, ptr %295, align 8
  %.pre.6 = load ptr, ptr %2, align 8
  br label %loop_body_tail.6

loop_body_tail.6:                                 ; preds = %struct_for_body_body.6, %loop_body_tail.5
  %296 = phi ptr [ %.pre.6, %struct_for_body_body.6 ], [ %260, %loop_body_tail.5 ]
  %297 = getelementptr inbounds i8, ptr %296, i64 32
  %298 = add i32 %263, 1
  %299 = sdiv i32 %298, 8
  %300 = sext i32 %299 to i64
  %301 = getelementptr inbounds i8, ptr %297, i64 %300
  %302 = load i8, ptr %301, align 1
  %303 = zext i8 %302 to i32
  %304 = and i32 %70, %303
  %.not.7 = icmp eq i32 %304, 0
  br i1 %.not.7, label %loop_body_tail.7, label %struct_for_body_body.7

struct_for_body_body.7:                           ; preds = %loop_body_tail.6
  %305 = load i32, ptr %5, align 4
  %306 = shl i32 %305, 5
  %307 = and i32 %lsr.iv, 31
  %308 = or i32 %306, %307
  %309 = load ptr, ptr %0, align 8
  %310 = getelementptr { { i32, i32 }, ptr }, ptr %309, i64 0, i32 1
  %311 = load ptr, ptr %310, align 8
  %312 = getelementptr { { i32, i32 }, ptr }, ptr %309, i64 0, i32 0, i32 1
  %313 = load i32, ptr %312, align 4
  %314 = sext i32 %313 to i64
  %315 = shl nsw i64 %314, 3
  %316 = sext i32 %308 to i64
  %317 = add nsw i64 %315, %316
  %318 = getelementptr double, ptr %311, i64 %317
  store double 0.000000e+00, ptr %318, align 8
  %319 = load ptr, ptr %310, align 8
  %320 = load i32, ptr %312, align 4
  %321 = sext i32 %320 to i64
  %322 = mul nsw i64 %321, 9
  %323 = add nsw i64 %322, %316
  %324 = getelementptr double, ptr %319, i64 %323
  store double 0.000000e+00, ptr %324, align 8
  %325 = load ptr, ptr %310, align 8
  %326 = load i32, ptr %312, align 4
  %327 = sext i32 %326 to i64
  %328 = mul nsw i64 %327, 10
  %329 = add nsw i64 %328, %316
  %330 = getelementptr double, ptr %325, i64 %329
  store double 0.000000e+00, ptr %330, align 8
  %.pre.7 = load ptr, ptr %2, align 8
  br label %loop_body_tail.7

loop_body_tail.7:                                 ; preds = %struct_for_body_body.7, %loop_body_tail.6
  %331 = phi ptr [ %.pre.7, %struct_for_body_body.7 ], [ %296, %loop_body_tail.6 ]
  %lsr.iv.next = add i32 %lsr.iv, 8
  %332 = add i32 %298, 1
  %exitcond.not.7 = icmp eq i32 %332, %4
  br i1 %exitcond.not.7, label %func_exit.loopexit, label %loop_body

func_exit.loopexit:                               ; preds = %loop_body_tail.7
  br label %func_exit

func_exit:                                        ; preds = %func_exit.loopexit, %loop_body.prol.loopexit, %allocs
  ret void

struct_for_body_body:                             ; preds = %loop_body
  %333 = load i32, ptr %5, align 4
  %334 = shl i32 %333, 5
  %335 = and i32 %72, 31
  %336 = or i32 %334, %335
  %337 = load ptr, ptr %0, align 8
  %338 = getelementptr { { i32, i32 }, ptr }, ptr %337, i64 0, i32 1
  %339 = load ptr, ptr %338, align 8
  %340 = getelementptr { { i32, i32 }, ptr }, ptr %337, i64 0, i32 0, i32 1
  %341 = load i32, ptr %340, align 4
  %342 = sext i32 %341 to i64
  %343 = shl nsw i64 %342, 3
  %344 = sext i32 %336 to i64
  %345 = add nsw i64 %343, %344
  %346 = getelementptr double, ptr %339, i64 %345
  store double 0.000000e+00, ptr %346, align 8
  %347 = load ptr, ptr %338, align 8
  %348 = load i32, ptr %340, align 4
  %349 = sext i32 %348 to i64
  %350 = mul nsw i64 %349, 9
  %351 = add nsw i64 %350, %344
  %352 = getelementptr double, ptr %347, i64 %351
  store double 0.000000e+00, ptr %352, align 8
  %353 = load ptr, ptr %338, align 8
  %354 = load i32, ptr %340, align 4
  %355 = sext i32 %354 to i64
  %356 = mul nsw i64 %355, 10
  %357 = add nsw i64 %356, %344
  %358 = getelementptr double, ptr %353, i64 %357
  store double 0.000000e+00, ptr %358, align 8
  %.pre = load ptr, ptr %2, align 8
  br label %loop_body_tail
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @field_clear_55_kernel_6_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.1905, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 57
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @field_clear_55_kernel_7_listgen_S57pointer(ptr %context) local_unnamed_addr #1 {
.lr.ph.i:
  %.sroa.2.i = alloca { [2 x i32], %struct.PhysicalCoordinates.1918 }, align 8
  %0 = alloca %0, align 8
  %1 = getelementptr inbounds %struct.RuntimeContext.1905, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 53
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %4, i64 57
  %8 = load ptr, ptr %7, align 8
  %9 = load atomic i64, ptr %6 acquire, align 8
  %.not.i.i.i.i = icmp ne i64 %9, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i)
  %10 = inttoptr i64 %9 to ptr
  %11 = load atomic i64, ptr %10 acquire, align 8
  %12 = inttoptr i64 %11 to ptr
  %.sroa.0.0.copyload.i = load ptr, ptr %12, align 8
  %.sroa.2.0..sroa_idx.i = getelementptr inbounds i8, ptr %12, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.i, ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.0..sroa_idx.i, i64 56, i1 false)
  %getch.i = getelementptr %1, ptr %.sroa.0.0.copyload.i, i64 0, i32 1
  %13 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %.sroa.2.16.sroa_idx.i = getelementptr inbounds i8, ptr %.sroa.2.i, i64 8
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %16 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 4
  %17 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 6
  %18 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 2
  %19 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  store ptr %getch.i, ptr %0, align 8
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %0, i64 8
  store <2 x i32> <i32 0, i32 4>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %13, ptr noundef nonnull align 8 dereferenceable(48) %.sroa.2.16.sroa_idx.i, i64 48, i1 false)
  %20 = atomicrmw volatile add ptr %14, i32 1 seq_cst, align 4
  %21 = load i32, ptr %15, align 8
  %22 = ashr i32 %20, %21
  %23 = icmp ugt i32 %22, 131071
  br i1 %23, label %24, label %26

24:                                               ; preds = %.lr.ph.i
  %25 = load ptr, ptr %17, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %25, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

26:                                               ; preds = %.lr.ph.i
  %27 = zext i32 %22 to i64
  %28 = lshr i64 %27, 9
  %29 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %28
  %30 = load atomic i64, ptr %29 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %30, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %26
  %31 = inttoptr i64 %30 to ptr
  %32 = and i64 %27, 511
  %33 = getelementptr inbounds ptr, ptr %31, i64 %32
  %34 = load atomic i64, ptr %33 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %26
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %35 = atomicrmw volatile xchg ptr %16, i32 1 seq_cst, align 4
  %36 = icmp eq i32 %35, 1
  br i1 %36, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %37 = load atomic i64, ptr %29 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %37, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %39, label %73

39:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %40 = load ptr, ptr %17, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1
  %42 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 28
  %43 = atomicrmw volatile add ptr %42, i64 4096 seq_cst, align 8
  %44 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 2
  %45 = load i64, ptr %44, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %45, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %66, label %46

46:                                               ; preds = %39
  %47 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 26
  br label %48

48:                                               ; preds = %48, %46
  %49 = atomicrmw volatile xchg ptr %47, i32 1 seq_cst, align 4
  %50 = icmp eq i32 %49, 1
  br i1 %50, label %48, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %48
  %51 = load ptr, ptr %41, align 8
  %52 = ptrtoint ptr %51 to i64
  %53 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 1
  %54 = load ptr, ptr %53, align 8
  %55 = ptrtoint ptr %54 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %52
  %56 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %57 = or i64 %56, 4096
  %58 = add i64 %57, %52
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %58, %55
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %59

59:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %60 = add i64 %56, %52
  %61 = inttoptr i64 %60 to ptr
  %62 = getelementptr i8, ptr %51, i64 %56
  %63 = getelementptr inbounds i8, ptr %62, i64 4096
  store ptr %63, ptr %41, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %59, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %61, %59 ]
  %64 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %65 = atomicrmw volatile xchg ptr %47, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %40, i1 noundef zeroext %64, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

66:                                               ; preds = %39
  %67 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 2
  %68 = load ptr, ptr %67, align 8
  %69 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 6
  %70 = load ptr, ptr %69, align 8
  %71 = tail call noundef ptr %68(ptr noundef %70, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %66, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %71, %66 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %72 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %72, ptr %29 release, align 8
  br label %73

73:                                               ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %38, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %74 = and i32 %22, 511
  %75 = zext i32 %74 to i64
  %76 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %75
  %77 = load atomic i64, ptr %76 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %77, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %78, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

78:                                               ; preds = %73
  %79 = load ptr, ptr %17, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1
  %81 = load i64, ptr %18, align 8
  %82 = load i64, ptr %19, align 8
  %83 = mul i64 %82, %81
  %84 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 28
  %85 = atomicrmw volatile add ptr %84, i64 %83 seq_cst, align 8
  %86 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 2
  %87 = load i64, ptr %86, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %87, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %107, label %88

88:                                               ; preds = %78
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 26
  br label %90

90:                                               ; preds = %90, %88
  %91 = atomicrmw volatile xchg ptr %89, i32 1 seq_cst, align 4
  %92 = icmp eq i32 %91, 1
  br i1 %92, label %90, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %90
  %93 = load ptr, ptr %80, align 8
  %94 = ptrtoint ptr %93 to i64
  %95 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 1
  %96 = load ptr, ptr %95, align 8
  %97 = ptrtoint ptr %96 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %94
  %98 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %99 = add i64 %98, %83
  %100 = add i64 %99, %94
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %100, %97
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %101

101:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %102 = add i64 %98, %94
  %103 = inttoptr i64 %102 to ptr
  %104 = getelementptr inbounds i8, ptr %93, i64 %99
  store ptr %104, ptr %80, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %101, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %103, %101 ]
  %105 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %106 = atomicrmw volatile xchg ptr %89, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %79, i1 noundef zeroext %105, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

107:                                              ; preds = %78
  %108 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 2
  %109 = load ptr, ptr %108, align 8
  %110 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 6
  %111 = load ptr, ptr %110, align 8
  %112 = tail call noundef ptr %109(ptr noundef %111, i64 noundef %83, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %107, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %112, %107 ]
  %113 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %113, ptr %76 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %73
  %114 = atomicrmw volatile xchg ptr %16, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %24
  %115 = load i32, ptr %15, align 8
  %116 = ashr i32 %20, %115
  %117 = sext i32 %116 to i64
  %118 = lshr i64 %117, 9
  %119 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %118
  %120 = load atomic i64, ptr %119 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %120, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %121

121:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %122 = inttoptr i64 %120 to ptr
  %123 = and i64 %117, 511
  %124 = getelementptr inbounds ptr, ptr %122, i64 %123
  %125 = load atomic i64, ptr %124 acquire, align 8
  %126 = inttoptr i64 %125 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %121, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %127 = phi ptr [ %126, %121 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %128 = load i64, ptr %19, align 8
  %129 = load i32, ptr %15, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %129
  %130 = xor i32 %notmask.i.i.i.i, -1
  %131 = and i32 %20, %130
  %132 = sext i32 %131 to i64
  %133 = mul i64 %128, %132
  %134 = getelementptr inbounds i8, ptr %127, i64 %133
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %134, ptr nonnull align 8 %0, i64 %128, i1 false)
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @field_clear_55_kernel_8_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.1905, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 58
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @field_clear_55_kernel_9_listgen_S58bitmasked(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %0, align 8
  %1 = alloca %struct.PhysicalCoordinates.1918, align 4
  %2 = alloca %0, align 8
  %3 = getelementptr inbounds %struct.RuntimeContext.1905, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %2)
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 13
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %6, i64 57
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %10 = load i32, ptr %9, align 8
  %11 = getelementptr inbounds ptr, ptr %6, i64 58
  %12 = load ptr, ptr %11, align 8
  %13 = icmp sgt i32 %10, 0
  br i1 %13, label %.lr.ph61.i, label %element_listgen_nonroot.exit

.lr.ph61.i:                                       ; preds = %entry
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  %16 = getelementptr inbounds %0, ptr %0, i64 0, i32 1
  %17 = getelementptr inbounds %0, ptr %0, i64 0, i32 1, i64 1
  %18 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %19 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %20 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 5
  %21 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %22 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 4
  %23 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 6
  %24 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 2
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %2, i64 8
  br label %26

26:                                               ; preds = %._crit_edge.i, %.lr.ph61.i
  %.04359.i = phi i32 [ 0, %.lr.ph61.i ], [ %172, %._crit_edge.i ]
  %27 = load i32, ptr %14, align 8
  %28 = lshr i32 %.04359.i, %27
  %29 = sext i32 %28 to i64
  %30 = lshr i64 %29, 9
  %31 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %30
  %32 = load atomic i64, ptr %31 acquire, align 8
  %.not.i.i.i.i = icmp eq i64 %32, 0
  br i1 %.not.i.i.i.i, label %_ZN11ListManager3getI7ElementEERT_i.exit.i, label %33

33:                                               ; preds = %26
  %34 = inttoptr i64 %32 to ptr
  %35 = and i64 %29, 511
  %36 = getelementptr inbounds ptr, ptr %34, i64 %35
  %37 = load atomic i64, ptr %36 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit.i

_ZN11ListManager3getI7ElementEERT_i.exit.i:       ; preds = %33, %26
  %39 = phi ptr [ %38, %33 ], [ null, %26 ]
  %40 = load i64, ptr %15, align 8
  %41 = load i32, ptr %14, align 8
  %notmask.i.i.i = shl nsw i32 -1, %41
  %42 = xor i32 %notmask.i.i.i, -1
  %43 = and i32 %.04359.i, %42
  %44 = zext i32 %43 to i64
  %45 = mul i64 %40, %44
  %46 = getelementptr inbounds i8, ptr %39, i64 %45
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %0, ptr noundef nonnull align 8 dereferenceable(64) %46, i64 64, i1 false)
  %47 = load i32, ptr %16, align 8
  %48 = load i32, ptr %17, align 4
  %49 = icmp slt i32 %47, %48
  br i1 %49, label %.lr.ph58.i.preheader, label %._crit_edge.i

.lr.ph58.i.preheader:                             ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit.i
  br label %.lr.ph58.i

.lr.ph58.i:                                       ; preds = %.loopexit.i, %.lr.ph58.i.preheader
  %.04457.i = phi i32 [ %171, %.loopexit.i ], [ %47, %.lr.ph58.i.preheader ]
  call fastcc void @S57_refine_coordinates(ptr noundef nonnull %18, ptr noundef nonnull %1, i32 noundef %.04457.i) #1
  %50 = load ptr, ptr %0, align 8
  %51 = shl i32 %.04457.i, 3
  %52 = sext i32 %51 to i64
  %53 = getelementptr i8, ptr %50, i64 %52
  %54 = getelementptr inbounds i8, ptr %53, i64 32
  %55 = load ptr, ptr %54, align 8
  %.not = icmp eq ptr %55, null
  br i1 %.not, label %.loopexit.i, label %.lr.ph.i

.lr.ph.i:                                         ; preds = %.lr.ph58.i
  store ptr %55, ptr %2, align 8
  store <2 x i32> <i32 0, i32 32>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %19, ptr noundef nonnull align 4 dereferenceable(48) %1, i64 48, i1 false)
  %56 = atomicrmw volatile add ptr %20, i32 1 seq_cst, align 4
  %57 = load i32, ptr %21, align 8
  %58 = ashr i32 %56, %57
  %59 = icmp ugt i32 %58, 131071
  br i1 %59, label %60, label %62

60:                                               ; preds = %.lr.ph.i
  %61 = load ptr, ptr %23, align 8
  call fastcc void @taichi_assert_format(ptr noundef %61, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

62:                                               ; preds = %.lr.ph.i
  %63 = zext i32 %58 to i64
  %64 = lshr i64 %63, 9
  %65 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %64
  %66 = load atomic i64, ptr %65 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %66, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %62
  %67 = inttoptr i64 %66 to ptr
  %68 = and i64 %63, 511
  %69 = getelementptr inbounds ptr, ptr %67, i64 %68
  %70 = load atomic i64, ptr %69 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %70, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %62
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %71 = atomicrmw volatile xchg ptr %22, i32 1 seq_cst, align 4
  %72 = icmp eq i32 %71, 1
  br i1 %72, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %73 = load atomic i64, ptr %65 acquire, align 8
  %74 = inttoptr i64 %73 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %73, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %75, label %109

75:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %76 = load ptr, ptr %23, align 8
  %77 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1
  %78 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 28
  %79 = atomicrmw volatile add ptr %78, i64 4096 seq_cst, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 2
  %81 = load i64, ptr %80, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %81, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %102, label %82

82:                                               ; preds = %75
  %83 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 26
  br label %84

84:                                               ; preds = %84, %82
  %85 = atomicrmw volatile xchg ptr %83, i32 1 seq_cst, align 4
  %86 = icmp eq i32 %85, 1
  br i1 %86, label %84, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %84
  %87 = load ptr, ptr %77, align 8
  %88 = ptrtoint ptr %87 to i64
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 1
  %90 = load ptr, ptr %89, align 8
  %91 = ptrtoint ptr %90 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %88
  %92 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %93 = or i64 %92, 4096
  %94 = add i64 %93, %88
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %94, %91
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %95

95:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %96 = add i64 %92, %88
  %97 = inttoptr i64 %96 to ptr
  %98 = getelementptr i8, ptr %87, i64 %92
  %99 = getelementptr inbounds i8, ptr %98, i64 4096
  store ptr %99, ptr %77, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %95, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %97, %95 ]
  %100 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %101 = atomicrmw volatile xchg ptr %83, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %76, i1 noundef zeroext %100, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

102:                                              ; preds = %75
  %103 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 2
  %104 = load ptr, ptr %103, align 8
  %105 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 6
  %106 = load ptr, ptr %105, align 8
  %107 = call noundef ptr %104(ptr noundef %106, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %102, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %107, %102 ]
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %108 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %108, ptr %65 release, align 8
  br label %109

109:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %74, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %110 = and i32 %58, 511
  %111 = zext i32 %110 to i64
  %112 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %111
  %113 = load atomic i64, ptr %112 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %113, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %114, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

114:                                              ; preds = %109
  %115 = load ptr, ptr %23, align 8
  %116 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1
  %117 = load i64, ptr %24, align 8
  %118 = load i64, ptr %25, align 8
  %119 = mul i64 %118, %117
  %120 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 28
  %121 = atomicrmw volatile add ptr %120, i64 %119 seq_cst, align 8
  %122 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 2
  %123 = load i64, ptr %122, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %123, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %143, label %124

124:                                              ; preds = %114
  %125 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 26
  br label %126

126:                                              ; preds = %126, %124
  %127 = atomicrmw volatile xchg ptr %125, i32 1 seq_cst, align 4
  %128 = icmp eq i32 %127, 1
  br i1 %128, label %126, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %126
  %129 = load ptr, ptr %116, align 8
  %130 = ptrtoint ptr %129 to i64
  %131 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 1
  %132 = load ptr, ptr %131, align 8
  %133 = ptrtoint ptr %132 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %130
  %134 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %135 = add i64 %134, %119
  %136 = add i64 %135, %130
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %136, %133
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %137

137:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %138 = add i64 %134, %130
  %139 = inttoptr i64 %138 to ptr
  %140 = getelementptr inbounds i8, ptr %129, i64 %135
  store ptr %140, ptr %116, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %137, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %139, %137 ]
  %141 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %142 = atomicrmw volatile xchg ptr %125, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %115, i1 noundef zeroext %141, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

143:                                              ; preds = %114
  %144 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 2
  %145 = load ptr, ptr %144, align 8
  %146 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 6
  %147 = load ptr, ptr %146, align 8
  %148 = call noundef ptr %145(ptr noundef %147, i64 noundef %119, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %143, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %148, %143 ]
  %149 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %149, ptr %112 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %109
  %150 = atomicrmw volatile xchg ptr %22, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %60
  %151 = load i32, ptr %21, align 8
  %152 = ashr i32 %56, %151
  %153 = sext i32 %152 to i64
  %154 = lshr i64 %153, 9
  %155 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %154
  %156 = load atomic i64, ptr %155 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %156, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %157

157:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %158 = inttoptr i64 %156 to ptr
  %159 = and i64 %153, 511
  %160 = getelementptr inbounds ptr, ptr %158, i64 %159
  %161 = load atomic i64, ptr %160 acquire, align 8
  %162 = inttoptr i64 %161 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %157, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %163 = phi ptr [ %162, %157 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %164 = load i64, ptr %25, align 8
  %165 = load i32, ptr %21, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %165
  %166 = xor i32 %notmask.i.i.i.i, -1
  %167 = and i32 %56, %166
  %168 = sext i32 %167 to i64
  %169 = mul i64 %164, %168
  %170 = getelementptr inbounds i8, ptr %163, i64 %169
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %170, ptr nonnull align 8 %2, i64 %164, i1 false)
  br label %.loopexit.i, !llvm.loop !8

.loopexit.i:                                      ; preds = %_ZN11ListManager6appendEPv.exit.i, %.lr.ph58.i
  %171 = add i32 %.04457.i, 1
  %exitcond.not.i = icmp eq i32 %171, %48
  br i1 %exitcond.not.i, label %._crit_edge.i.loopexit, label %.lr.ph58.i, !llvm.loop !9

._crit_edge.i.loopexit:                           ; preds = %.loopexit.i
  br label %._crit_edge.i

._crit_edge.i:                                    ; preds = %._crit_edge.i.loopexit, %_ZN11ListManager3getI7ElementEERT_i.exit.i
  %172 = add nuw nsw i32 %.04359.i, 1
  %exitcond63.not.i = icmp eq i32 %172, %10
  br i1 %exitcond63.not.i, label %element_listgen_nonroot.exit.loopexit, label %26, !llvm.loop !10

element_listgen_nonroot.exit.loopexit:            ; preds = %._crit_edge.i
  br label %element_listgen_nonroot.exit

element_listgen_nonroot.exit:                     ; preds = %element_listgen_nonroot.exit.loopexit, %entry
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %2)
  ret void
}

; Function Attrs: nounwind
define void @field_clear_55_kernel_10_struct_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.cpu_block_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.RuntimeContext.1905, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 58
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds %struct.ListManager, ptr %6, i64 0, i32 5
  %8 = load i32, ptr %7, align 8
  store ptr %context, ptr %0, align 8
  %9 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  store ptr @function_body.1, ptr %9, align 8
  %10 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  store ptr %6, ptr %10, align 8
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  store <2 x i32> <i32 32, i32 8>, ptr %11, align 8
  %12 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  store i64 1, ptr %12, align 8
  %13 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 12
  %14 = load ptr, ptr %13, align 8
  %15 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 11
  %16 = load ptr, ptr %15, align 8
  %17 = shl nsw i32 %8, 3
  call void %14(ptr noundef %16, i32 noundef %17, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_struct_for_block_helper) #1
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind
define internal void @function_body.1(ptr %0, ptr nocapture readnone %1, ptr nocapture readonly %2, i32 %3, i32 %4) #2 {
allocs:
  %5 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %6 = icmp sgt i32 %4, %3
  br i1 %6, label %loop_body.lr.ph, label %func_exit

loop_body.lr.ph:                                  ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.1905, ptr %0, i64 0, i32 1
  %8 = sub i32 %4, %3
  %9 = xor i32 %3, -1
  %10 = add i32 %9, %4
  %xtraiter = and i32 %8, 3
  %lcmp.mod.not = icmp eq i32 %xtraiter, 0
  br i1 %lcmp.mod.not, label %loop_body.prol.loopexit, label %loop_body.prol.preheader

loop_body.prol.preheader:                         ; preds = %loop_body.lr.ph
  br label %loop_body.prol

loop_body.prol:                                   ; preds = %loop_body_tail.prol, %loop_body.prol.preheader
  %lsr.iv = phi i32 [ %xtraiter, %loop_body.prol.preheader ], [ %lsr.iv.next, %loop_body_tail.prol ]
  %.025.prol = phi i32 [ %76, %loop_body_tail.prol ], [ %3, %loop_body.prol.preheader ]
  %11 = load ptr, ptr %2, align 8
  %12 = getelementptr inbounds i8, ptr %11, i64 32
  %13 = sdiv i32 %.025.prol, 8
  %14 = sext i32 %13 to i64
  %15 = getelementptr inbounds i8, ptr %12, i64 %14
  %16 = load i8, ptr %15, align 1
  %17 = zext i8 %16 to i32
  %18 = and i32 %.025.prol, 7
  %19 = shl nuw nsw i32 1, %18
  %20 = and i32 %19, %17
  %.not24.prol = icmp eq i32 %20, 0
  br i1 %.not24.prol, label %loop_body_tail.prol, label %struct_for_body_body.prol

struct_for_body_body.prol:                        ; preds = %loop_body.prol
  %21 = load i32, ptr %5, align 4
  %22 = shl i32 %21, 5
  %23 = and i32 %.025.prol, 31
  %24 = or i32 %22, %23
  %25 = load ptr, ptr %0, align 8
  %26 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %25, i64 0, i32 1, i32 1
  %27 = load ptr, ptr %26, align 8
  %28 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %25, i64 0, i32 1, i32 0, i32 1
  %29 = load i32, ptr %28, align 4
  %30 = sext i32 %29 to i64
  %31 = shl nsw i64 %30, 2
  %32 = sext i32 %24 to i64
  %33 = add nsw i64 %31, %32
  %34 = getelementptr double, ptr %27, i64 %33
  store double 0.000000e+00, ptr %34, align 8
  %35 = load ptr, ptr %26, align 8
  %36 = load i32, ptr %28, align 4
  %37 = sext i32 %36 to i64
  %38 = mul nsw i64 %37, 5
  %39 = add nsw i64 %38, %32
  %40 = getelementptr double, ptr %35, i64 %39
  store double 0.000000e+00, ptr %40, align 8
  %41 = load ptr, ptr %26, align 8
  %42 = load i32, ptr %28, align 4
  %43 = sext i32 %42 to i64
  %44 = mul nsw i64 %43, 6
  %45 = add nsw i64 %44, %32
  %46 = getelementptr double, ptr %41, i64 %45
  store double 0.000000e+00, ptr %46, align 8
  %47 = load ptr, ptr %7, align 8
  %48 = getelementptr inbounds %struct.LLVMRuntime, ptr %47, i64 0, i32 16
  %49 = load ptr, ptr %48, align 8
  %50 = load i32, ptr %49, align 4
  %.not.prol = icmp eq i32 %50, 0
  br i1 %.not.prol, label %loop_body_tail.prol, label %true_block.prol

true_block.prol:                                  ; preds = %struct_for_body_body.prol
  %51 = load ptr, ptr %26, align 8
  %52 = load i32, ptr %28, align 4
  %53 = sext i32 %52 to i64
  %54 = mul nsw i64 %53, 7
  %55 = add nsw i64 %54, %32
  %56 = getelementptr double, ptr %51, i64 %55
  store double 0.000000e+00, ptr %56, align 8
  %57 = load ptr, ptr %26, align 8
  %58 = getelementptr double, ptr %57, i64 %32
  store double 0.000000e+00, ptr %58, align 8
  %59 = load ptr, ptr %26, align 8
  %60 = load i32, ptr %28, align 4
  %61 = sext i32 %60 to i64
  %62 = add nsw i64 %61, %32
  %63 = getelementptr double, ptr %59, i64 %62
  store double 0.000000e+00, ptr %63, align 8
  %64 = load ptr, ptr %26, align 8
  %65 = load i32, ptr %28, align 4
  %66 = sext i32 %65 to i64
  %67 = shl nsw i64 %66, 1
  %68 = add nsw i64 %67, %32
  %69 = getelementptr double, ptr %64, i64 %68
  store double 0.000000e+00, ptr %69, align 8
  %70 = load ptr, ptr %26, align 8
  %71 = load i32, ptr %28, align 4
  %72 = sext i32 %71 to i64
  %73 = mul nsw i64 %72, 3
  %74 = add nsw i64 %73, %32
  %75 = getelementptr double, ptr %70, i64 %74
  store double 0.000000e+00, ptr %75, align 8
  br label %loop_body_tail.prol

loop_body_tail.prol:                              ; preds = %true_block.prol, %struct_for_body_body.prol, %loop_body.prol
  %76 = add i32 %.025.prol, 1
  %lsr.iv.next = add nsw i32 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i32 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %loop_body.prol.loopexit.loopexit, label %loop_body.prol, !llvm.loop !13

loop_body.prol.loopexit.loopexit:                 ; preds = %loop_body_tail.prol
  br label %loop_body.prol.loopexit

loop_body.prol.loopexit:                          ; preds = %loop_body.prol.loopexit.loopexit, %loop_body.lr.ph
  %.025.unr = phi i32 [ %3, %loop_body.lr.ph ], [ %76, %loop_body.prol.loopexit.loopexit ]
  %77 = icmp ult i32 %10, 3
  br i1 %77, label %func_exit, label %loop_body.preheader

loop_body.preheader:                              ; preds = %loop_body.prol.loopexit
  br label %loop_body

loop_body:                                        ; preds = %loop_body_tail.3, %loop_body.preheader
  %.025 = phi i32 [ %288, %loop_body_tail.3 ], [ %.025.unr, %loop_body.preheader ]
  %78 = load ptr, ptr %2, align 8
  %79 = getelementptr inbounds i8, ptr %78, i64 32
  %80 = sdiv i32 %.025, 8
  %81 = sext i32 %80 to i64
  %82 = getelementptr inbounds i8, ptr %79, i64 %81
  %83 = load i8, ptr %82, align 1
  %84 = zext i8 %83 to i32
  %85 = and i32 %.025, 7
  %86 = shl nuw nsw i32 1, %85
  %87 = and i32 %86, %84
  %.not24 = icmp eq i32 %87, 0
  br i1 %.not24, label %loop_body_tail, label %struct_for_body_body

loop_body_tail:                                   ; preds = %true_block, %struct_for_body_body, %loop_body
  %88 = add i32 %.025, 1
  %89 = load ptr, ptr %2, align 8
  %90 = getelementptr inbounds i8, ptr %89, i64 32
  %91 = sdiv i32 %88, 8
  %92 = sext i32 %91 to i64
  %93 = getelementptr inbounds i8, ptr %90, i64 %92
  %94 = load i8, ptr %93, align 1
  %95 = zext i8 %94 to i32
  %96 = and i32 %88, 7
  %97 = shl nuw nsw i32 1, %96
  %98 = and i32 %97, %95
  %.not24.1 = icmp eq i32 %98, 0
  br i1 %.not24.1, label %loop_body_tail.1, label %struct_for_body_body.1

struct_for_body_body.1:                           ; preds = %loop_body_tail
  %99 = load i32, ptr %5, align 4
  %100 = shl i32 %99, 5
  %101 = and i32 %88, 31
  %102 = or i32 %100, %101
  %103 = load ptr, ptr %0, align 8
  %104 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %103, i64 0, i32 1, i32 1
  %105 = load ptr, ptr %104, align 8
  %106 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %103, i64 0, i32 1, i32 0, i32 1
  %107 = load i32, ptr %106, align 4
  %108 = sext i32 %107 to i64
  %109 = shl nsw i64 %108, 2
  %110 = sext i32 %102 to i64
  %111 = add nsw i64 %109, %110
  %112 = getelementptr double, ptr %105, i64 %111
  store double 0.000000e+00, ptr %112, align 8
  %113 = load ptr, ptr %104, align 8
  %114 = load i32, ptr %106, align 4
  %115 = sext i32 %114 to i64
  %116 = mul nsw i64 %115, 5
  %117 = add nsw i64 %116, %110
  %118 = getelementptr double, ptr %113, i64 %117
  store double 0.000000e+00, ptr %118, align 8
  %119 = load ptr, ptr %104, align 8
  %120 = load i32, ptr %106, align 4
  %121 = sext i32 %120 to i64
  %122 = mul nsw i64 %121, 6
  %123 = add nsw i64 %122, %110
  %124 = getelementptr double, ptr %119, i64 %123
  store double 0.000000e+00, ptr %124, align 8
  %125 = load ptr, ptr %7, align 8
  %126 = getelementptr inbounds %struct.LLVMRuntime, ptr %125, i64 0, i32 16
  %127 = load ptr, ptr %126, align 8
  %128 = load i32, ptr %127, align 4
  %.not.1 = icmp eq i32 %128, 0
  br i1 %.not.1, label %loop_body_tail.1, label %true_block.1

true_block.1:                                     ; preds = %struct_for_body_body.1
  %129 = load ptr, ptr %104, align 8
  %130 = load i32, ptr %106, align 4
  %131 = sext i32 %130 to i64
  %132 = mul nsw i64 %131, 7
  %133 = add nsw i64 %132, %110
  %134 = getelementptr double, ptr %129, i64 %133
  store double 0.000000e+00, ptr %134, align 8
  %135 = load ptr, ptr %104, align 8
  %136 = getelementptr double, ptr %135, i64 %110
  store double 0.000000e+00, ptr %136, align 8
  %137 = load ptr, ptr %104, align 8
  %138 = load i32, ptr %106, align 4
  %139 = sext i32 %138 to i64
  %140 = add nsw i64 %139, %110
  %141 = getelementptr double, ptr %137, i64 %140
  store double 0.000000e+00, ptr %141, align 8
  %142 = load ptr, ptr %104, align 8
  %143 = load i32, ptr %106, align 4
  %144 = sext i32 %143 to i64
  %145 = shl nsw i64 %144, 1
  %146 = add nsw i64 %145, %110
  %147 = getelementptr double, ptr %142, i64 %146
  store double 0.000000e+00, ptr %147, align 8
  %148 = load ptr, ptr %104, align 8
  %149 = load i32, ptr %106, align 4
  %150 = sext i32 %149 to i64
  %151 = mul nsw i64 %150, 3
  %152 = add nsw i64 %151, %110
  %153 = getelementptr double, ptr %148, i64 %152
  store double 0.000000e+00, ptr %153, align 8
  br label %loop_body_tail.1

loop_body_tail.1:                                 ; preds = %true_block.1, %struct_for_body_body.1, %loop_body_tail
  %154 = add i32 %.025, 2
  %155 = load ptr, ptr %2, align 8
  %156 = getelementptr inbounds i8, ptr %155, i64 32
  %157 = add i32 %88, 1
  %158 = sdiv i32 %157, 8
  %159 = sext i32 %158 to i64
  %160 = getelementptr inbounds i8, ptr %156, i64 %159
  %161 = load i8, ptr %160, align 1
  %162 = zext i8 %161 to i32
  %163 = and i32 %154, 7
  %164 = shl nuw nsw i32 1, %163
  %165 = and i32 %164, %162
  %.not24.2 = icmp eq i32 %165, 0
  br i1 %.not24.2, label %loop_body_tail.2, label %struct_for_body_body.2

struct_for_body_body.2:                           ; preds = %loop_body_tail.1
  %166 = load i32, ptr %5, align 4
  %167 = shl i32 %166, 5
  %168 = and i32 %154, 31
  %169 = or i32 %167, %168
  %170 = load ptr, ptr %0, align 8
  %171 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %170, i64 0, i32 1, i32 1
  %172 = load ptr, ptr %171, align 8
  %173 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %170, i64 0, i32 1, i32 0, i32 1
  %174 = load i32, ptr %173, align 4
  %175 = sext i32 %174 to i64
  %176 = shl nsw i64 %175, 2
  %177 = sext i32 %169 to i64
  %178 = add nsw i64 %176, %177
  %179 = getelementptr double, ptr %172, i64 %178
  store double 0.000000e+00, ptr %179, align 8
  %180 = load ptr, ptr %171, align 8
  %181 = load i32, ptr %173, align 4
  %182 = sext i32 %181 to i64
  %183 = mul nsw i64 %182, 5
  %184 = add nsw i64 %183, %177
  %185 = getelementptr double, ptr %180, i64 %184
  store double 0.000000e+00, ptr %185, align 8
  %186 = load ptr, ptr %171, align 8
  %187 = load i32, ptr %173, align 4
  %188 = sext i32 %187 to i64
  %189 = mul nsw i64 %188, 6
  %190 = add nsw i64 %189, %177
  %191 = getelementptr double, ptr %186, i64 %190
  store double 0.000000e+00, ptr %191, align 8
  %192 = load ptr, ptr %7, align 8
  %193 = getelementptr inbounds %struct.LLVMRuntime, ptr %192, i64 0, i32 16
  %194 = load ptr, ptr %193, align 8
  %195 = load i32, ptr %194, align 4
  %.not.2 = icmp eq i32 %195, 0
  br i1 %.not.2, label %loop_body_tail.2, label %true_block.2

true_block.2:                                     ; preds = %struct_for_body_body.2
  %196 = load ptr, ptr %171, align 8
  %197 = load i32, ptr %173, align 4
  %198 = sext i32 %197 to i64
  %199 = mul nsw i64 %198, 7
  %200 = add nsw i64 %199, %177
  %201 = getelementptr double, ptr %196, i64 %200
  store double 0.000000e+00, ptr %201, align 8
  %202 = load ptr, ptr %171, align 8
  %203 = getelementptr double, ptr %202, i64 %177
  store double 0.000000e+00, ptr %203, align 8
  %204 = load ptr, ptr %171, align 8
  %205 = load i32, ptr %173, align 4
  %206 = sext i32 %205 to i64
  %207 = add nsw i64 %206, %177
  %208 = getelementptr double, ptr %204, i64 %207
  store double 0.000000e+00, ptr %208, align 8
  %209 = load ptr, ptr %171, align 8
  %210 = load i32, ptr %173, align 4
  %211 = sext i32 %210 to i64
  %212 = shl nsw i64 %211, 1
  %213 = add nsw i64 %212, %177
  %214 = getelementptr double, ptr %209, i64 %213
  store double 0.000000e+00, ptr %214, align 8
  %215 = load ptr, ptr %171, align 8
  %216 = load i32, ptr %173, align 4
  %217 = sext i32 %216 to i64
  %218 = mul nsw i64 %217, 3
  %219 = add nsw i64 %218, %177
  %220 = getelementptr double, ptr %215, i64 %219
  store double 0.000000e+00, ptr %220, align 8
  br label %loop_body_tail.2

loop_body_tail.2:                                 ; preds = %true_block.2, %struct_for_body_body.2, %loop_body_tail.1
  %221 = add i32 %.025, 3
  %222 = load ptr, ptr %2, align 8
  %223 = getelementptr inbounds i8, ptr %222, i64 32
  %224 = add i32 %157, 1
  %225 = sdiv i32 %224, 8
  %226 = sext i32 %225 to i64
  %227 = getelementptr inbounds i8, ptr %223, i64 %226
  %228 = load i8, ptr %227, align 1
  %229 = zext i8 %228 to i32
  %230 = and i32 %221, 7
  %231 = shl nuw nsw i32 1, %230
  %232 = and i32 %231, %229
  %.not24.3 = icmp eq i32 %232, 0
  br i1 %.not24.3, label %loop_body_tail.3, label %struct_for_body_body.3

struct_for_body_body.3:                           ; preds = %loop_body_tail.2
  %233 = load i32, ptr %5, align 4
  %234 = shl i32 %233, 5
  %235 = and i32 %221, 31
  %236 = or i32 %234, %235
  %237 = load ptr, ptr %0, align 8
  %238 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %237, i64 0, i32 1, i32 1
  %239 = load ptr, ptr %238, align 8
  %240 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %237, i64 0, i32 1, i32 0, i32 1
  %241 = load i32, ptr %240, align 4
  %242 = sext i32 %241 to i64
  %243 = shl nsw i64 %242, 2
  %244 = sext i32 %236 to i64
  %245 = add nsw i64 %243, %244
  %246 = getelementptr double, ptr %239, i64 %245
  store double 0.000000e+00, ptr %246, align 8
  %247 = load ptr, ptr %238, align 8
  %248 = load i32, ptr %240, align 4
  %249 = sext i32 %248 to i64
  %250 = mul nsw i64 %249, 5
  %251 = add nsw i64 %250, %244
  %252 = getelementptr double, ptr %247, i64 %251
  store double 0.000000e+00, ptr %252, align 8
  %253 = load ptr, ptr %238, align 8
  %254 = load i32, ptr %240, align 4
  %255 = sext i32 %254 to i64
  %256 = mul nsw i64 %255, 6
  %257 = add nsw i64 %256, %244
  %258 = getelementptr double, ptr %253, i64 %257
  store double 0.000000e+00, ptr %258, align 8
  %259 = load ptr, ptr %7, align 8
  %260 = getelementptr inbounds %struct.LLVMRuntime, ptr %259, i64 0, i32 16
  %261 = load ptr, ptr %260, align 8
  %262 = load i32, ptr %261, align 4
  %.not.3 = icmp eq i32 %262, 0
  br i1 %.not.3, label %loop_body_tail.3, label %true_block.3

true_block.3:                                     ; preds = %struct_for_body_body.3
  %263 = load ptr, ptr %238, align 8
  %264 = load i32, ptr %240, align 4
  %265 = sext i32 %264 to i64
  %266 = mul nsw i64 %265, 7
  %267 = add nsw i64 %266, %244
  %268 = getelementptr double, ptr %263, i64 %267
  store double 0.000000e+00, ptr %268, align 8
  %269 = load ptr, ptr %238, align 8
  %270 = getelementptr double, ptr %269, i64 %244
  store double 0.000000e+00, ptr %270, align 8
  %271 = load ptr, ptr %238, align 8
  %272 = load i32, ptr %240, align 4
  %273 = sext i32 %272 to i64
  %274 = add nsw i64 %273, %244
  %275 = getelementptr double, ptr %271, i64 %274
  store double 0.000000e+00, ptr %275, align 8
  %276 = load ptr, ptr %238, align 8
  %277 = load i32, ptr %240, align 4
  %278 = sext i32 %277 to i64
  %279 = shl nsw i64 %278, 1
  %280 = add nsw i64 %279, %244
  %281 = getelementptr double, ptr %276, i64 %280
  store double 0.000000e+00, ptr %281, align 8
  %282 = load ptr, ptr %238, align 8
  %283 = load i32, ptr %240, align 4
  %284 = sext i32 %283 to i64
  %285 = mul nsw i64 %284, 3
  %286 = add nsw i64 %285, %244
  %287 = getelementptr double, ptr %282, i64 %286
  store double 0.000000e+00, ptr %287, align 8
  br label %loop_body_tail.3

loop_body_tail.3:                                 ; preds = %true_block.3, %struct_for_body_body.3, %loop_body_tail.2
  %288 = add i32 %224, 1
  %exitcond.not.3 = icmp eq i32 %288, %4
  br i1 %exitcond.not.3, label %func_exit.loopexit, label %loop_body

func_exit.loopexit:                               ; preds = %loop_body_tail.3
  br label %func_exit

func_exit:                                        ; preds = %func_exit.loopexit, %loop_body.prol.loopexit, %allocs
  ret void

struct_for_body_body:                             ; preds = %loop_body
  %289 = load i32, ptr %5, align 4
  %290 = shl i32 %289, 5
  %291 = and i32 %.025, 31
  %292 = or i32 %290, %291
  %293 = load ptr, ptr %0, align 8
  %294 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %293, i64 0, i32 1, i32 1
  %295 = load ptr, ptr %294, align 8
  %296 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %293, i64 0, i32 1, i32 0, i32 1
  %297 = load i32, ptr %296, align 4
  %298 = sext i32 %297 to i64
  %299 = shl nsw i64 %298, 2
  %300 = sext i32 %292 to i64
  %301 = add nsw i64 %299, %300
  %302 = getelementptr double, ptr %295, i64 %301
  store double 0.000000e+00, ptr %302, align 8
  %303 = load ptr, ptr %294, align 8
  %304 = load i32, ptr %296, align 4
  %305 = sext i32 %304 to i64
  %306 = mul nsw i64 %305, 5
  %307 = add nsw i64 %306, %300
  %308 = getelementptr double, ptr %303, i64 %307
  store double 0.000000e+00, ptr %308, align 8
  %309 = load ptr, ptr %294, align 8
  %310 = load i32, ptr %296, align 4
  %311 = sext i32 %310 to i64
  %312 = mul nsw i64 %311, 6
  %313 = add nsw i64 %312, %300
  %314 = getelementptr double, ptr %309, i64 %313
  store double 0.000000e+00, ptr %314, align 8
  %315 = load ptr, ptr %7, align 8
  %316 = getelementptr inbounds %struct.LLVMRuntime, ptr %315, i64 0, i32 16
  %317 = load ptr, ptr %316, align 8
  %318 = load i32, ptr %317, align 4
  %.not = icmp eq i32 %318, 0
  br i1 %.not, label %loop_body_tail, label %true_block

true_block:                                       ; preds = %struct_for_body_body
  %319 = load ptr, ptr %294, align 8
  %320 = load i32, ptr %296, align 4
  %321 = sext i32 %320 to i64
  %322 = mul nsw i64 %321, 7
  %323 = add nsw i64 %322, %300
  %324 = getelementptr double, ptr %319, i64 %323
  store double 0.000000e+00, ptr %324, align 8
  %325 = load ptr, ptr %294, align 8
  %326 = getelementptr double, ptr %325, i64 %300
  store double 0.000000e+00, ptr %326, align 8
  %327 = load ptr, ptr %294, align 8
  %328 = load i32, ptr %296, align 4
  %329 = sext i32 %328 to i64
  %330 = add nsw i64 %329, %300
  %331 = getelementptr double, ptr %327, i64 %330
  store double 0.000000e+00, ptr %331, align 8
  %332 = load ptr, ptr %294, align 8
  %333 = load i32, ptr %296, align 4
  %334 = sext i32 %333 to i64
  %335 = shl nsw i64 %334, 1
  %336 = add nsw i64 %335, %300
  %337 = getelementptr double, ptr %332, i64 %336
  store double 0.000000e+00, ptr %337, align 8
  %338 = load ptr, ptr %294, align 8
  %339 = load i32, ptr %296, align 4
  %340 = sext i32 %339 to i64
  %341 = mul nsw i64 %340, 3
  %342 = add nsw i64 %341, %300
  %343 = getelementptr double, ptr %338, i64 %342
  store double 0.000000e+00, ptr %343, align 8
  br label %loop_body_tail
}

; Function Attrs: nounwind
define void @field_clear_55_kernel_11_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.2, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1905, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.2(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #3 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 1)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.1905, ptr %0, i64 0, i32 1
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.LLVMRuntime, ptr %8, i64 0, i32 16
  %10 = load ptr, ptr %9, align 8
  %11 = load i32, ptr %10, align 4
  %12 = icmp eq i32 %11, 0
  br i1 %12, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.lr.ph
  %13 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %14 = xor i64 %13, -1
  %15 = add nsw i64 %14, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 1
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.preheader
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %16 = load ptr, ptr %7, align 8
  %17 = getelementptr inbounds %struct.LLVMRuntime, ptr %16, i64 0, i32 16
  %18 = load ptr, ptr %17, align 8
  %19 = load i32, ptr %18, align 4
  %.not.prol = icmp eq i32 %19, 0
  br i1 %.not.prol, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %20 = load ptr, ptr %0, align 8
  %21 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %20, i64 0, i32 4, i32 1
  %22 = load ptr, ptr %21, align 8
  %23 = shl nsw i64 %13, 3
  %uglygep22 = getelementptr i8, ptr %22, i64 %23
  store double 0.000000e+00, ptr %uglygep22, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %indvars.iv.next.prol = add nuw nsw i64 %13, 1
  br i1 true, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !14

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.preheader
  %indvars.iv.unr = phi i64 [ %13, %for_loop_body.preheader ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %24 = icmp ult i64 %15, 7
  br i1 %24, label %after_for, label %for_loop_body.preheader7

for_loop_body.preheader7:                         ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader7
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %after_if.7 ], [ %indvars.iv.unr, %for_loop_body.preheader7 ]
  %25 = load ptr, ptr %7, align 8
  %26 = getelementptr inbounds %struct.LLVMRuntime, ptr %25, i64 0, i32 16
  %27 = load ptr, ptr %26, align 8
  %28 = load i32, ptr %27, align 4
  %.not = icmp eq i32 %28, 0
  br i1 %.not, label %after_if, label %true_block

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %for_loop_body.lr.ph, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %29 = load ptr, ptr %0, align 8
  %30 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %29, i64 0, i32 4, i32 1
  %31 = load ptr, ptr %30, align 8
  %32 = shl i64 %indvars.iv, 3
  %uglygep19 = getelementptr i8, ptr %31, i64 %32
  store double 0.000000e+00, ptr %uglygep19, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %33 = load ptr, ptr %7, align 8
  %34 = getelementptr inbounds %struct.LLVMRuntime, ptr %33, i64 0, i32 16
  %35 = load ptr, ptr %34, align 8
  %36 = load i32, ptr %35, align 4
  %.not.1 = icmp eq i32 %36, 0
  br i1 %.not.1, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %37 = load ptr, ptr %0, align 8
  %38 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %37, i64 0, i32 4, i32 1
  %39 = load ptr, ptr %38, align 8
  %uglygep20 = getelementptr i8, ptr %39, i64 8
  %40 = shl i64 %indvars.iv, 3
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 %40
  store double 0.000000e+00, ptr %uglygep21, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if
  %41 = load ptr, ptr %7, align 8
  %42 = getelementptr inbounds %struct.LLVMRuntime, ptr %41, i64 0, i32 16
  %43 = load ptr, ptr %42, align 8
  %44 = load i32, ptr %43, align 4
  %.not.2 = icmp eq i32 %44, 0
  br i1 %.not.2, label %after_if.2, label %true_block.2

true_block.2:                                     ; preds = %after_if.1
  %45 = load ptr, ptr %0, align 8
  %46 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %45, i64 0, i32 4, i32 1
  %47 = load ptr, ptr %46, align 8
  %uglygep17 = getelementptr i8, ptr %47, i64 16
  %48 = shl i64 %indvars.iv, 3
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %48
  store double 0.000000e+00, ptr %uglygep18, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %true_block.2, %after_if.1
  %49 = load ptr, ptr %7, align 8
  %50 = getelementptr inbounds %struct.LLVMRuntime, ptr %49, i64 0, i32 16
  %51 = load ptr, ptr %50, align 8
  %52 = load i32, ptr %51, align 4
  %.not.3 = icmp eq i32 %52, 0
  br i1 %.not.3, label %after_if.3, label %true_block.3

true_block.3:                                     ; preds = %after_if.2
  %53 = load ptr, ptr %0, align 8
  %54 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %53, i64 0, i32 4, i32 1
  %55 = load ptr, ptr %54, align 8
  %uglygep15 = getelementptr i8, ptr %55, i64 24
  %56 = shl i64 %indvars.iv, 3
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %56
  store double 0.000000e+00, ptr %uglygep16, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %true_block.3, %after_if.2
  %57 = load ptr, ptr %7, align 8
  %58 = getelementptr inbounds %struct.LLVMRuntime, ptr %57, i64 0, i32 16
  %59 = load ptr, ptr %58, align 8
  %60 = load i32, ptr %59, align 4
  %.not.4 = icmp eq i32 %60, 0
  br i1 %.not.4, label %after_if.4, label %true_block.4

true_block.4:                                     ; preds = %after_if.3
  %61 = load ptr, ptr %0, align 8
  %62 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %61, i64 0, i32 4, i32 1
  %63 = load ptr, ptr %62, align 8
  %uglygep13 = getelementptr i8, ptr %63, i64 32
  %64 = shl i64 %indvars.iv, 3
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %64
  store double 0.000000e+00, ptr %uglygep14, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %true_block.4, %after_if.3
  %65 = load ptr, ptr %7, align 8
  %66 = getelementptr inbounds %struct.LLVMRuntime, ptr %65, i64 0, i32 16
  %67 = load ptr, ptr %66, align 8
  %68 = load i32, ptr %67, align 4
  %.not.5 = icmp eq i32 %68, 0
  br i1 %.not.5, label %after_if.5, label %true_block.5

true_block.5:                                     ; preds = %after_if.4
  %69 = load ptr, ptr %0, align 8
  %70 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %69, i64 0, i32 4, i32 1
  %71 = load ptr, ptr %70, align 8
  %uglygep11 = getelementptr i8, ptr %71, i64 40
  %72 = shl i64 %indvars.iv, 3
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %72
  store double 0.000000e+00, ptr %uglygep12, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %true_block.5, %after_if.4
  %73 = load ptr, ptr %7, align 8
  %74 = getelementptr inbounds %struct.LLVMRuntime, ptr %73, i64 0, i32 16
  %75 = load ptr, ptr %74, align 8
  %76 = load i32, ptr %75, align 4
  %.not.6 = icmp eq i32 %76, 0
  br i1 %.not.6, label %after_if.6, label %true_block.6

true_block.6:                                     ; preds = %after_if.5
  %77 = load ptr, ptr %0, align 8
  %78 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %77, i64 0, i32 4, i32 1
  %79 = load ptr, ptr %78, align 8
  %uglygep9 = getelementptr i8, ptr %79, i64 48
  %80 = shl i64 %indvars.iv, 3
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %80
  store double 0.000000e+00, ptr %uglygep10, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %true_block.6, %after_if.5
  %81 = load ptr, ptr %7, align 8
  %82 = getelementptr inbounds %struct.LLVMRuntime, ptr %81, i64 0, i32 16
  %83 = load ptr, ptr %82, align 8
  %84 = load i32, ptr %83, align 4
  %.not.7 = icmp eq i32 %84, 0
  br i1 %.not.7, label %after_if.7, label %true_block.7

true_block.7:                                     ; preds = %after_if.6
  %85 = load ptr, ptr %0, align 8
  %86 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %85, i64 0, i32 4, i32 1
  %87 = load ptr, ptr %86, align 8
  %uglygep = getelementptr i8, ptr %87, i64 56
  %88 = shl i64 %indvars.iv, 3
  %uglygep8 = getelementptr i8, ptr %uglygep, i64 %88
  store double 0.000000e+00, ptr %uglygep8, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %true_block.7, %after_if.6
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nofree norecurse nosync nounwind
define void @field_clear_55_kernel_12_serial(ptr %context) local_unnamed_addr #2 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.1905, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 16
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 4
  %5 = load i32, ptr %4, align 4
  %6 = icmp sgt i32 %5, 0
  br i1 %6, label %for_loop_body.preheader, label %after_for

for_loop_body.preheader:                          ; preds = %entry
  %wide.trip.count = zext i32 %5 to i64
  %7 = add nsw i64 %wide.trip.count, -1
  %xtraiter = and i64 %wide.trip.count, 7
  %8 = icmp ult i64 %7, 7
  br i1 %8, label %after_for.loopexit.unr-lcssa, label %for_loop_body.preheader.new

for_loop_body.preheader.new:                      ; preds = %for_loop_body.preheader
  %9 = lshr i64 %wide.trip.count, 3
  %10 = mul nsw i64 %9, -8
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader.new
  %lsr.iv9 = phi i64 [ %lsr.iv.next10, %for_loop_body ], [ 3, %for_loop_body.preheader.new ]
  %11 = load ptr, ptr %context, align 8
  %12 = getelementptr { { i32, i32 }, ptr }, ptr %11, i64 0, i32 1
  %13 = load ptr, ptr %12, align 8
  %14 = getelementptr { { i32, i32 }, ptr }, ptr %11, i64 0, i32 0, i32 1
  %15 = shl i64 %lsr.iv9, 3
  %uglygep71 = getelementptr i8, ptr %13, i64 %15
  %uglygep72 = getelementptr i8, ptr %uglygep71, i64 -24
  %16 = load double, ptr %uglygep72, align 8
  %17 = bitcast double %16 to i64
  %18 = and i64 %17, 9218868437227405312
  %19 = icmp ne i64 %18, 9218868437227405312
  %20 = select i1 %19, double %16, double 0.000000e+00
  %21 = bitcast double %20 to i64
  %22 = and i64 %21, 9218868437227405312
  %23 = icmp ne i64 %22, 9218868437227405312
  %24 = and i1 %19, %23
  %25 = select i1 %24, double %20, double 0.000000e+00
  store double %25, ptr %uglygep72, align 8
  %26 = load ptr, ptr %12, align 8
  %27 = load i32, ptr %14, align 4
  %28 = sext i32 %27 to i64
  %29 = add i64 %lsr.iv9, %28
  %30 = getelementptr double, ptr %26, i64 %29
  %31 = getelementptr double, ptr %30, i64 -3
  %32 = load double, ptr %31, align 8
  %33 = bitcast double %32 to i64
  %34 = and i64 %33, 9218868437227405312
  %35 = icmp ne i64 %34, 9218868437227405312
  %36 = select i1 %35, double %32, double 0.000000e+00
  %37 = bitcast double %36 to i64
  %38 = and i64 %37, 9218868437227405312
  %39 = icmp ne i64 %38, 9218868437227405312
  %40 = and i1 %35, %39
  %41 = select i1 %40, double %36, double 0.000000e+00
  store double %41, ptr %31, align 8
  %42 = load ptr, ptr %12, align 8
  %43 = load i32, ptr %14, align 4
  %44 = sext i32 %43 to i64
  %45 = shl nsw i64 %44, 4
  %uglygep68 = getelementptr i8, ptr %42, i64 %45
  %uglygep69 = getelementptr i8, ptr %uglygep68, i64 %15
  %uglygep70 = getelementptr i8, ptr %uglygep69, i64 -24
  %46 = load double, ptr %uglygep70, align 8
  %47 = bitcast double %46 to i64
  %48 = and i64 %47, 9218868437227405312
  %49 = icmp ne i64 %48, 9218868437227405312
  %50 = select i1 %49, double %46, double 0.000000e+00
  %51 = bitcast double %50 to i64
  %52 = and i64 %51, 9218868437227405312
  %53 = icmp ne i64 %52, 9218868437227405312
  %54 = and i1 %49, %53
  %55 = select i1 %54, double %50, double 0.000000e+00
  store double %55, ptr %uglygep70, align 8
  %56 = load ptr, ptr %context, align 8
  %57 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %56, i64 0, i32 4, i32 1
  %58 = load ptr, ptr %57, align 8
  %59 = load double, ptr %58, align 8
  %60 = load ptr, ptr %12, align 8
  %61 = load i32, ptr %14, align 4
  %62 = sext i32 %61 to i64
  %63 = mul nsw i64 %62, 48
  %uglygep65 = getelementptr i8, ptr %60, i64 %63
  %uglygep66 = getelementptr i8, ptr %uglygep65, i64 %15
  %uglygep67 = getelementptr i8, ptr %uglygep66, i64 -24
  %64 = load double, ptr %uglygep67, align 8
  %65 = fadd double %59, %64
  store double %65, ptr %58, align 8
  %66 = load ptr, ptr %context, align 8
  %67 = getelementptr { { i32, i32 }, ptr }, ptr %66, i64 0, i32 1
  %68 = load ptr, ptr %67, align 8
  %69 = getelementptr { { i32, i32 }, ptr }, ptr %66, i64 0, i32 0, i32 1
  %uglygep48 = getelementptr i8, ptr %68, i64 %15
  %uglygep49 = getelementptr i8, ptr %uglygep48, i64 -16
  %70 = load double, ptr %uglygep49, align 8
  %71 = bitcast double %70 to i64
  %72 = and i64 %71, 9218868437227405312
  %73 = icmp ne i64 %72, 9218868437227405312
  %74 = select i1 %73, double %70, double 0.000000e+00
  %75 = bitcast double %74 to i64
  %76 = and i64 %75, 9218868437227405312
  %77 = icmp ne i64 %76, 9218868437227405312
  %78 = and i1 %73, %77
  %79 = select i1 %78, double %74, double 0.000000e+00
  store double %79, ptr %uglygep49, align 8
  %80 = load ptr, ptr %67, align 8
  %81 = load i32, ptr %69, align 4
  %82 = sext i32 %81 to i64
  %83 = add i64 %lsr.iv9, %82
  %84 = getelementptr double, ptr %80, i64 %83
  %85 = getelementptr double, ptr %84, i64 -2
  %86 = load double, ptr %85, align 8
  %87 = bitcast double %86 to i64
  %88 = and i64 %87, 9218868437227405312
  %89 = icmp ne i64 %88, 9218868437227405312
  %90 = select i1 %89, double %86, double 0.000000e+00
  %91 = bitcast double %90 to i64
  %92 = and i64 %91, 9218868437227405312
  %93 = icmp ne i64 %92, 9218868437227405312
  %94 = and i1 %89, %93
  %95 = select i1 %94, double %90, double 0.000000e+00
  store double %95, ptr %85, align 8
  %96 = load ptr, ptr %67, align 8
  %97 = load i32, ptr %69, align 4
  %98 = sext i32 %97 to i64
  %99 = shl nsw i64 %98, 4
  %uglygep50 = getelementptr i8, ptr %96, i64 %99
  %uglygep51 = getelementptr i8, ptr %uglygep50, i64 %15
  %uglygep52 = getelementptr i8, ptr %uglygep51, i64 -16
  %100 = load double, ptr %uglygep52, align 8
  %101 = bitcast double %100 to i64
  %102 = and i64 %101, 9218868437227405312
  %103 = icmp ne i64 %102, 9218868437227405312
  %104 = select i1 %103, double %100, double 0.000000e+00
  %105 = bitcast double %104 to i64
  %106 = and i64 %105, 9218868437227405312
  %107 = icmp ne i64 %106, 9218868437227405312
  %108 = and i1 %103, %107
  %109 = select i1 %108, double %104, double 0.000000e+00
  store double %109, ptr %uglygep52, align 8
  %110 = load ptr, ptr %context, align 8
  %111 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %110, i64 0, i32 4, i32 1
  %112 = load ptr, ptr %111, align 8
  %113 = load double, ptr %112, align 8
  %114 = load ptr, ptr %67, align 8
  %115 = load i32, ptr %69, align 4
  %116 = sext i32 %115 to i64
  %117 = mul nsw i64 %116, 48
  %uglygep53 = getelementptr i8, ptr %114, i64 %117
  %uglygep54 = getelementptr i8, ptr %uglygep53, i64 %15
  %uglygep55 = getelementptr i8, ptr %uglygep54, i64 -16
  %118 = load double, ptr %uglygep55, align 8
  %119 = fadd double %113, %118
  store double %119, ptr %112, align 8
  %120 = load ptr, ptr %context, align 8
  %121 = getelementptr { { i32, i32 }, ptr }, ptr %120, i64 0, i32 1
  %122 = load ptr, ptr %121, align 8
  %123 = getelementptr { { i32, i32 }, ptr }, ptr %120, i64 0, i32 0, i32 1
  %uglygep40 = getelementptr i8, ptr %122, i64 %15
  %uglygep41 = getelementptr i8, ptr %uglygep40, i64 -8
  %124 = load double, ptr %uglygep41, align 8
  %125 = bitcast double %124 to i64
  %126 = and i64 %125, 9218868437227405312
  %127 = icmp ne i64 %126, 9218868437227405312
  %128 = select i1 %127, double %124, double 0.000000e+00
  %129 = bitcast double %128 to i64
  %130 = and i64 %129, 9218868437227405312
  %131 = icmp ne i64 %130, 9218868437227405312
  %132 = and i1 %127, %131
  %133 = select i1 %132, double %128, double 0.000000e+00
  store double %133, ptr %uglygep41, align 8
  %134 = load ptr, ptr %121, align 8
  %135 = load i32, ptr %123, align 4
  %136 = sext i32 %135 to i64
  %137 = add i64 %lsr.iv9, %136
  %138 = getelementptr double, ptr %134, i64 %137
  %139 = getelementptr double, ptr %138, i64 -1
  %140 = load double, ptr %139, align 8
  %141 = bitcast double %140 to i64
  %142 = and i64 %141, 9218868437227405312
  %143 = icmp ne i64 %142, 9218868437227405312
  %144 = select i1 %143, double %140, double 0.000000e+00
  %145 = bitcast double %144 to i64
  %146 = and i64 %145, 9218868437227405312
  %147 = icmp ne i64 %146, 9218868437227405312
  %148 = and i1 %143, %147
  %149 = select i1 %148, double %144, double 0.000000e+00
  store double %149, ptr %139, align 8
  %150 = load ptr, ptr %121, align 8
  %151 = load i32, ptr %123, align 4
  %152 = sext i32 %151 to i64
  %153 = shl nsw i64 %152, 4
  %uglygep42 = getelementptr i8, ptr %150, i64 %153
  %uglygep43 = getelementptr i8, ptr %uglygep42, i64 %15
  %uglygep44 = getelementptr i8, ptr %uglygep43, i64 -8
  %154 = load double, ptr %uglygep44, align 8
  %155 = bitcast double %154 to i64
  %156 = and i64 %155, 9218868437227405312
  %157 = icmp ne i64 %156, 9218868437227405312
  %158 = select i1 %157, double %154, double 0.000000e+00
  %159 = bitcast double %158 to i64
  %160 = and i64 %159, 9218868437227405312
  %161 = icmp ne i64 %160, 9218868437227405312
  %162 = and i1 %157, %161
  %163 = select i1 %162, double %158, double 0.000000e+00
  store double %163, ptr %uglygep44, align 8
  %164 = load ptr, ptr %context, align 8
  %165 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %164, i64 0, i32 4, i32 1
  %166 = load ptr, ptr %165, align 8
  %167 = load double, ptr %166, align 8
  %168 = load ptr, ptr %121, align 8
  %169 = load i32, ptr %123, align 4
  %170 = sext i32 %169 to i64
  %171 = mul nsw i64 %170, 48
  %uglygep45 = getelementptr i8, ptr %168, i64 %171
  %uglygep46 = getelementptr i8, ptr %uglygep45, i64 %15
  %uglygep47 = getelementptr i8, ptr %uglygep46, i64 -8
  %172 = load double, ptr %uglygep47, align 8
  %173 = fadd double %167, %172
  store double %173, ptr %166, align 8
  %174 = load ptr, ptr %context, align 8
  %175 = getelementptr { { i32, i32 }, ptr }, ptr %174, i64 0, i32 1
  %176 = load ptr, ptr %175, align 8
  %177 = getelementptr { { i32, i32 }, ptr }, ptr %174, i64 0, i32 0, i32 1
  %uglygep35 = getelementptr i8, ptr %176, i64 %15
  %178 = load double, ptr %uglygep35, align 8
  %179 = bitcast double %178 to i64
  %180 = and i64 %179, 9218868437227405312
  %181 = icmp ne i64 %180, 9218868437227405312
  %182 = select i1 %181, double %178, double 0.000000e+00
  %183 = bitcast double %182 to i64
  %184 = and i64 %183, 9218868437227405312
  %185 = icmp ne i64 %184, 9218868437227405312
  %186 = and i1 %181, %185
  %187 = select i1 %186, double %182, double 0.000000e+00
  store double %187, ptr %uglygep35, align 8
  %188 = load ptr, ptr %175, align 8
  %189 = load i32, ptr %177, align 4
  %190 = sext i32 %189 to i64
  %191 = add nsw i64 %lsr.iv9, %190
  %192 = getelementptr double, ptr %188, i64 %191
  %193 = load double, ptr %192, align 8
  %194 = bitcast double %193 to i64
  %195 = and i64 %194, 9218868437227405312
  %196 = icmp ne i64 %195, 9218868437227405312
  %197 = select i1 %196, double %193, double 0.000000e+00
  %198 = bitcast double %197 to i64
  %199 = and i64 %198, 9218868437227405312
  %200 = icmp ne i64 %199, 9218868437227405312
  %201 = and i1 %196, %200
  %202 = select i1 %201, double %197, double 0.000000e+00
  store double %202, ptr %192, align 8
  %203 = load ptr, ptr %175, align 8
  %204 = load i32, ptr %177, align 4
  %205 = sext i32 %204 to i64
  %206 = shl nsw i64 %205, 4
  %uglygep36 = getelementptr i8, ptr %203, i64 %206
  %uglygep37 = getelementptr i8, ptr %uglygep36, i64 %15
  %207 = load double, ptr %uglygep37, align 8
  %208 = bitcast double %207 to i64
  %209 = and i64 %208, 9218868437227405312
  %210 = icmp ne i64 %209, 9218868437227405312
  %211 = select i1 %210, double %207, double 0.000000e+00
  %212 = bitcast double %211 to i64
  %213 = and i64 %212, 9218868437227405312
  %214 = icmp ne i64 %213, 9218868437227405312
  %215 = and i1 %210, %214
  %216 = select i1 %215, double %211, double 0.000000e+00
  store double %216, ptr %uglygep37, align 8
  %217 = load ptr, ptr %context, align 8
  %218 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %217, i64 0, i32 4, i32 1
  %219 = load ptr, ptr %218, align 8
  %220 = load double, ptr %219, align 8
  %221 = load ptr, ptr %175, align 8
  %222 = load i32, ptr %177, align 4
  %223 = sext i32 %222 to i64
  %224 = mul nsw i64 %223, 48
  %uglygep38 = getelementptr i8, ptr %221, i64 %224
  %uglygep39 = getelementptr i8, ptr %uglygep38, i64 %15
  %225 = load double, ptr %uglygep39, align 8
  %226 = fadd double %220, %225
  store double %226, ptr %219, align 8
  %227 = load ptr, ptr %context, align 8
  %228 = getelementptr { { i32, i32 }, ptr }, ptr %227, i64 0, i32 1
  %229 = load ptr, ptr %228, align 8
  %230 = getelementptr { { i32, i32 }, ptr }, ptr %227, i64 0, i32 0, i32 1
  %uglygep27 = getelementptr i8, ptr %229, i64 %15
  %uglygep28 = getelementptr i8, ptr %uglygep27, i64 8
  %231 = load double, ptr %uglygep28, align 8
  %232 = bitcast double %231 to i64
  %233 = and i64 %232, 9218868437227405312
  %234 = icmp ne i64 %233, 9218868437227405312
  %235 = select i1 %234, double %231, double 0.000000e+00
  %236 = bitcast double %235 to i64
  %237 = and i64 %236, 9218868437227405312
  %238 = icmp ne i64 %237, 9218868437227405312
  %239 = and i1 %234, %238
  %240 = select i1 %239, double %235, double 0.000000e+00
  store double %240, ptr %uglygep28, align 8
  %241 = load ptr, ptr %228, align 8
  %242 = load i32, ptr %230, align 4
  %243 = sext i32 %242 to i64
  %244 = add i64 %lsr.iv9, %243
  %245 = getelementptr double, ptr %241, i64 %244
  %246 = getelementptr double, ptr %245, i64 1
  %247 = load double, ptr %246, align 8
  %248 = bitcast double %247 to i64
  %249 = and i64 %248, 9218868437227405312
  %250 = icmp ne i64 %249, 9218868437227405312
  %251 = select i1 %250, double %247, double 0.000000e+00
  %252 = bitcast double %251 to i64
  %253 = and i64 %252, 9218868437227405312
  %254 = icmp ne i64 %253, 9218868437227405312
  %255 = and i1 %250, %254
  %256 = select i1 %255, double %251, double 0.000000e+00
  store double %256, ptr %246, align 8
  %257 = load ptr, ptr %228, align 8
  %258 = load i32, ptr %230, align 4
  %259 = sext i32 %258 to i64
  %260 = shl nsw i64 %259, 4
  %uglygep29 = getelementptr i8, ptr %257, i64 %260
  %uglygep30 = getelementptr i8, ptr %uglygep29, i64 %15
  %uglygep31 = getelementptr i8, ptr %uglygep30, i64 8
  %261 = load double, ptr %uglygep31, align 8
  %262 = bitcast double %261 to i64
  %263 = and i64 %262, 9218868437227405312
  %264 = icmp ne i64 %263, 9218868437227405312
  %265 = select i1 %264, double %261, double 0.000000e+00
  %266 = bitcast double %265 to i64
  %267 = and i64 %266, 9218868437227405312
  %268 = icmp ne i64 %267, 9218868437227405312
  %269 = and i1 %264, %268
  %270 = select i1 %269, double %265, double 0.000000e+00
  store double %270, ptr %uglygep31, align 8
  %271 = load ptr, ptr %context, align 8
  %272 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %271, i64 0, i32 4, i32 1
  %273 = load ptr, ptr %272, align 8
  %274 = load double, ptr %273, align 8
  %275 = load ptr, ptr %228, align 8
  %276 = load i32, ptr %230, align 4
  %277 = sext i32 %276 to i64
  %278 = mul nsw i64 %277, 48
  %uglygep32 = getelementptr i8, ptr %275, i64 %278
  %uglygep33 = getelementptr i8, ptr %uglygep32, i64 %15
  %uglygep34 = getelementptr i8, ptr %uglygep33, i64 8
  %279 = load double, ptr %uglygep34, align 8
  %280 = fadd double %274, %279
  store double %280, ptr %273, align 8
  %281 = load ptr, ptr %context, align 8
  %282 = getelementptr { { i32, i32 }, ptr }, ptr %281, i64 0, i32 1
  %283 = load ptr, ptr %282, align 8
  %284 = getelementptr { { i32, i32 }, ptr }, ptr %281, i64 0, i32 0, i32 1
  %uglygep19 = getelementptr i8, ptr %283, i64 %15
  %uglygep20 = getelementptr i8, ptr %uglygep19, i64 16
  %285 = load double, ptr %uglygep20, align 8
  %286 = bitcast double %285 to i64
  %287 = and i64 %286, 9218868437227405312
  %288 = icmp ne i64 %287, 9218868437227405312
  %289 = select i1 %288, double %285, double 0.000000e+00
  %290 = bitcast double %289 to i64
  %291 = and i64 %290, 9218868437227405312
  %292 = icmp ne i64 %291, 9218868437227405312
  %293 = and i1 %288, %292
  %294 = select i1 %293, double %289, double 0.000000e+00
  store double %294, ptr %uglygep20, align 8
  %295 = load ptr, ptr %282, align 8
  %296 = load i32, ptr %284, align 4
  %297 = sext i32 %296 to i64
  %298 = add i64 %lsr.iv9, %297
  %299 = getelementptr double, ptr %295, i64 %298
  %300 = getelementptr double, ptr %299, i64 2
  %301 = load double, ptr %300, align 8
  %302 = bitcast double %301 to i64
  %303 = and i64 %302, 9218868437227405312
  %304 = icmp ne i64 %303, 9218868437227405312
  %305 = select i1 %304, double %301, double 0.000000e+00
  %306 = bitcast double %305 to i64
  %307 = and i64 %306, 9218868437227405312
  %308 = icmp ne i64 %307, 9218868437227405312
  %309 = and i1 %304, %308
  %310 = select i1 %309, double %305, double 0.000000e+00
  store double %310, ptr %300, align 8
  %311 = load ptr, ptr %282, align 8
  %312 = load i32, ptr %284, align 4
  %313 = sext i32 %312 to i64
  %314 = shl nsw i64 %313, 4
  %uglygep21 = getelementptr i8, ptr %311, i64 %314
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 %15
  %uglygep23 = getelementptr i8, ptr %uglygep22, i64 16
  %315 = load double, ptr %uglygep23, align 8
  %316 = bitcast double %315 to i64
  %317 = and i64 %316, 9218868437227405312
  %318 = icmp ne i64 %317, 9218868437227405312
  %319 = select i1 %318, double %315, double 0.000000e+00
  %320 = bitcast double %319 to i64
  %321 = and i64 %320, 9218868437227405312
  %322 = icmp ne i64 %321, 9218868437227405312
  %323 = and i1 %318, %322
  %324 = select i1 %323, double %319, double 0.000000e+00
  store double %324, ptr %uglygep23, align 8
  %325 = load ptr, ptr %context, align 8
  %326 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %325, i64 0, i32 4, i32 1
  %327 = load ptr, ptr %326, align 8
  %328 = load double, ptr %327, align 8
  %329 = load ptr, ptr %282, align 8
  %330 = load i32, ptr %284, align 4
  %331 = sext i32 %330 to i64
  %332 = mul nsw i64 %331, 48
  %uglygep24 = getelementptr i8, ptr %329, i64 %332
  %uglygep25 = getelementptr i8, ptr %uglygep24, i64 %15
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 16
  %333 = load double, ptr %uglygep26, align 8
  %334 = fadd double %328, %333
  store double %334, ptr %327, align 8
  %335 = load ptr, ptr %context, align 8
  %336 = getelementptr { { i32, i32 }, ptr }, ptr %335, i64 0, i32 1
  %337 = load ptr, ptr %336, align 8
  %338 = getelementptr { { i32, i32 }, ptr }, ptr %335, i64 0, i32 0, i32 1
  %uglygep11 = getelementptr i8, ptr %337, i64 %15
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 24
  %339 = load double, ptr %uglygep12, align 8
  %340 = bitcast double %339 to i64
  %341 = and i64 %340, 9218868437227405312
  %342 = icmp ne i64 %341, 9218868437227405312
  %343 = select i1 %342, double %339, double 0.000000e+00
  %344 = bitcast double %343 to i64
  %345 = and i64 %344, 9218868437227405312
  %346 = icmp ne i64 %345, 9218868437227405312
  %347 = and i1 %342, %346
  %348 = select i1 %347, double %343, double 0.000000e+00
  store double %348, ptr %uglygep12, align 8
  %349 = load ptr, ptr %336, align 8
  %350 = load i32, ptr %338, align 4
  %351 = sext i32 %350 to i64
  %352 = add i64 %lsr.iv9, %351
  %353 = getelementptr double, ptr %349, i64 %352
  %354 = getelementptr double, ptr %353, i64 3
  %355 = load double, ptr %354, align 8
  %356 = bitcast double %355 to i64
  %357 = and i64 %356, 9218868437227405312
  %358 = icmp ne i64 %357, 9218868437227405312
  %359 = select i1 %358, double %355, double 0.000000e+00
  %360 = bitcast double %359 to i64
  %361 = and i64 %360, 9218868437227405312
  %362 = icmp ne i64 %361, 9218868437227405312
  %363 = and i1 %358, %362
  %364 = select i1 %363, double %359, double 0.000000e+00
  store double %364, ptr %354, align 8
  %365 = load ptr, ptr %336, align 8
  %366 = load i32, ptr %338, align 4
  %367 = sext i32 %366 to i64
  %368 = shl nsw i64 %367, 4
  %uglygep13 = getelementptr i8, ptr %365, i64 %368
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %15
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 24
  %369 = load double, ptr %uglygep15, align 8
  %370 = bitcast double %369 to i64
  %371 = and i64 %370, 9218868437227405312
  %372 = icmp ne i64 %371, 9218868437227405312
  %373 = select i1 %372, double %369, double 0.000000e+00
  %374 = bitcast double %373 to i64
  %375 = and i64 %374, 9218868437227405312
  %376 = icmp ne i64 %375, 9218868437227405312
  %377 = and i1 %372, %376
  %378 = select i1 %377, double %373, double 0.000000e+00
  store double %378, ptr %uglygep15, align 8
  %379 = load ptr, ptr %context, align 8
  %380 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %379, i64 0, i32 4, i32 1
  %381 = load ptr, ptr %380, align 8
  %382 = load double, ptr %381, align 8
  %383 = load ptr, ptr %336, align 8
  %384 = load i32, ptr %338, align 4
  %385 = sext i32 %384 to i64
  %386 = mul nsw i64 %385, 48
  %uglygep16 = getelementptr i8, ptr %383, i64 %386
  %uglygep17 = getelementptr i8, ptr %uglygep16, i64 %15
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 24
  %387 = load double, ptr %uglygep18, align 8
  %388 = fadd double %382, %387
  store double %388, ptr %381, align 8
  %389 = load ptr, ptr %context, align 8
  %390 = getelementptr { { i32, i32 }, ptr }, ptr %389, i64 0, i32 1
  %391 = load ptr, ptr %390, align 8
  %392 = getelementptr { { i32, i32 }, ptr }, ptr %389, i64 0, i32 0, i32 1
  %uglygep56 = getelementptr i8, ptr %391, i64 56
  %uglygep57 = getelementptr i8, ptr %uglygep56, i64 %15
  %uglygep58 = getelementptr i8, ptr %uglygep57, i64 -24
  %393 = load double, ptr %uglygep58, align 8
  %394 = bitcast double %393 to i64
  %395 = and i64 %394, 9218868437227405312
  %396 = icmp ne i64 %395, 9218868437227405312
  %397 = select i1 %396, double %393, double 0.000000e+00
  %398 = bitcast double %397 to i64
  %399 = and i64 %398, 9218868437227405312
  %400 = icmp ne i64 %399, 9218868437227405312
  %401 = and i1 %396, %400
  %402 = select i1 %401, double %397, double 0.000000e+00
  store double %402, ptr %uglygep58, align 8
  %403 = load ptr, ptr %390, align 8
  %404 = load i32, ptr %392, align 4
  %405 = sext i32 %404 to i64
  %406 = add i64 %lsr.iv9, %405
  %407 = getelementptr double, ptr %403, i64 %406
  %408 = getelementptr double, ptr %407, i64 4
  %409 = load double, ptr %408, align 8
  %410 = bitcast double %409 to i64
  %411 = and i64 %410, 9218868437227405312
  %412 = icmp ne i64 %411, 9218868437227405312
  %413 = select i1 %412, double %409, double 0.000000e+00
  %414 = bitcast double %413 to i64
  %415 = and i64 %414, 9218868437227405312
  %416 = icmp ne i64 %415, 9218868437227405312
  %417 = and i1 %412, %416
  %418 = select i1 %417, double %413, double 0.000000e+00
  store double %418, ptr %408, align 8
  %419 = load ptr, ptr %390, align 8
  %420 = load i32, ptr %392, align 4
  %421 = sext i32 %420 to i64
  %422 = shl nsw i64 %421, 4
  %uglygep59 = getelementptr i8, ptr %419, i64 %422
  %uglygep60 = getelementptr i8, ptr %uglygep59, i64 %15
  %uglygep61 = getelementptr i8, ptr %uglygep60, i64 32
  %423 = load double, ptr %uglygep61, align 8
  %424 = bitcast double %423 to i64
  %425 = and i64 %424, 9218868437227405312
  %426 = icmp ne i64 %425, 9218868437227405312
  %427 = select i1 %426, double %423, double 0.000000e+00
  %428 = bitcast double %427 to i64
  %429 = and i64 %428, 9218868437227405312
  %430 = icmp ne i64 %429, 9218868437227405312
  %431 = and i1 %426, %430
  %432 = select i1 %431, double %427, double 0.000000e+00
  store double %432, ptr %uglygep61, align 8
  %433 = load ptr, ptr %context, align 8
  %434 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %433, i64 0, i32 4, i32 1
  %435 = load ptr, ptr %434, align 8
  %436 = load double, ptr %435, align 8
  %437 = load ptr, ptr %390, align 8
  %438 = load i32, ptr %392, align 4
  %439 = sext i32 %438 to i64
  %440 = mul nsw i64 %439, 48
  %uglygep62 = getelementptr i8, ptr %437, i64 %440
  %uglygep63 = getelementptr i8, ptr %uglygep62, i64 %15
  %uglygep64 = getelementptr i8, ptr %uglygep63, i64 32
  %441 = load double, ptr %uglygep64, align 8
  %442 = fadd double %436, %441
  store double %442, ptr %435, align 8
  %lsr.iv.next10 = add nuw i64 %lsr.iv9, 8
  %443 = add i64 %10, %lsr.iv.next10
  %niter.ncmp.7 = icmp eq i64 %443, 3
  br i1 %niter.ncmp.7, label %after_for.loopexit.unr-lcssa.loopexit, label %for_loop_body

after_for.loopexit.unr-lcssa.loopexit:            ; preds = %for_loop_body
  %444 = add i64 %lsr.iv.next10, -3
  br label %after_for.loopexit.unr-lcssa

after_for.loopexit.unr-lcssa:                     ; preds = %after_for.loopexit.unr-lcssa.loopexit, %for_loop_body.preheader
  %indvars.iv.unr = phi i64 [ 0, %for_loop_body.preheader ], [ %444, %after_for.loopexit.unr-lcssa.loopexit ]
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %after_for, label %for_loop_body.epil.preheader

for_loop_body.epil.preheader:                     ; preds = %after_for.loopexit.unr-lcssa
  br label %for_loop_body.epil

for_loop_body.epil:                               ; preds = %for_loop_body.epil, %for_loop_body.epil.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.epil.preheader ], [ %lsr.iv.next, %for_loop_body.epil ]
  %indvars.iv.epil = phi i64 [ %indvars.iv.next.epil, %for_loop_body.epil ], [ %indvars.iv.unr, %for_loop_body.epil.preheader ]
  %445 = load ptr, ptr %context, align 8
  %446 = getelementptr { { i32, i32 }, ptr }, ptr %445, i64 0, i32 1
  %447 = load ptr, ptr %446, align 8
  %448 = getelementptr { { i32, i32 }, ptr }, ptr %445, i64 0, i32 0, i32 1
  %449 = shl i64 %indvars.iv.epil, 3
  %uglygep8 = getelementptr i8, ptr %447, i64 %449
  %450 = load double, ptr %uglygep8, align 8
  %451 = bitcast double %450 to i64
  %452 = and i64 %451, 9218868437227405312
  %453 = icmp ne i64 %452, 9218868437227405312
  %454 = select i1 %453, double %450, double 0.000000e+00
  %455 = bitcast double %454 to i64
  %456 = and i64 %455, 9218868437227405312
  %457 = icmp ne i64 %456, 9218868437227405312
  %458 = and i1 %453, %457
  %459 = select i1 %458, double %454, double 0.000000e+00
  store double %459, ptr %uglygep8, align 8
  %460 = load ptr, ptr %446, align 8
  %461 = load i32, ptr %448, align 4
  %462 = sext i32 %461 to i64
  %463 = add nsw i64 %indvars.iv.epil, %462
  %464 = getelementptr double, ptr %460, i64 %463
  %465 = load double, ptr %464, align 8
  %466 = bitcast double %465 to i64
  %467 = and i64 %466, 9218868437227405312
  %468 = icmp ne i64 %467, 9218868437227405312
  %469 = select i1 %468, double %465, double 0.000000e+00
  %470 = bitcast double %469 to i64
  %471 = and i64 %470, 9218868437227405312
  %472 = icmp ne i64 %471, 9218868437227405312
  %473 = and i1 %468, %472
  %474 = select i1 %473, double %469, double 0.000000e+00
  store double %474, ptr %464, align 8
  %475 = load ptr, ptr %446, align 8
  %476 = load i32, ptr %448, align 4
  %477 = sext i32 %476 to i64
  %478 = shl nsw i64 %477, 4
  %uglygep6 = getelementptr i8, ptr %475, i64 %478
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 %449
  %479 = load double, ptr %uglygep7, align 8
  %480 = bitcast double %479 to i64
  %481 = and i64 %480, 9218868437227405312
  %482 = icmp ne i64 %481, 9218868437227405312
  %483 = select i1 %482, double %479, double 0.000000e+00
  %484 = bitcast double %483 to i64
  %485 = and i64 %484, 9218868437227405312
  %486 = icmp ne i64 %485, 9218868437227405312
  %487 = and i1 %482, %486
  %488 = select i1 %487, double %483, double 0.000000e+00
  store double %488, ptr %uglygep7, align 8
  %489 = load ptr, ptr %context, align 8
  %490 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, i32, { { i32 }, ptr }, i32, { { i32, i32 }, ptr }, i32 }, ptr %489, i64 0, i32 4, i32 1
  %491 = load ptr, ptr %490, align 8
  %492 = load double, ptr %491, align 8
  %493 = load ptr, ptr %446, align 8
  %494 = load i32, ptr %448, align 4
  %495 = sext i32 %494 to i64
  %496 = mul nsw i64 %495, 48
  %uglygep = getelementptr i8, ptr %493, i64 %496
  %uglygep5 = getelementptr i8, ptr %uglygep, i64 %449
  %497 = load double, ptr %uglygep5, align 8
  %498 = fadd double %492, %497
  store double %498, ptr %491, align 8
  %indvars.iv.next.epil = add nuw nsw i64 %indvars.iv.epil, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %epil.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %epil.iter.cmp.not, label %after_for.loopexit, label %for_loop_body.epil, !llvm.loop !15

after_for.loopexit:                               ; preds = %for_loop_body.epil
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %after_for.loopexit.unr-lcssa, %entry
  ret void
}

; Function Attrs: argmemonly mustprogress nofree norecurse nosync nounwind willreturn
define internal fastcc void @S54_refine_coordinates(ptr nocapture readonly %0, ptr nocapture writeonly %1, i32 %2) unnamed_addr #4 {
entry:
  %3 = and i32 %2, 3
  %4 = load i32, ptr %0, align 4
  %5 = shl i32 %4, 2
  %6 = or i32 %5, %3
  store i32 %6, ptr %1, align 4
  %7 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 1
  %8 = load i32, ptr %7, align 4
  %9 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 1
  store i32 %8, ptr %9, align 4
  %10 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 2
  %11 = load i32, ptr %10, align 4
  %12 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 2
  store i32 %11, ptr %12, align 4
  %13 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 3
  %14 = load i32, ptr %13, align 4
  %15 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 3
  store i32 %14, ptr %15, align 4
  %16 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 4
  %17 = load i32, ptr %16, align 4
  %18 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 4
  store i32 %17, ptr %18, align 4
  %19 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 5
  %20 = load i32, ptr %19, align 4
  %21 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 5
  store i32 %20, ptr %21, align 4
  %22 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 6
  %23 = load i32, ptr %22, align 4
  %24 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 6
  store i32 %23, ptr %24, align 4
  %25 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 7
  %26 = load i32, ptr %25, align 4
  %27 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 7
  store i32 %26, ptr %27, align 4
  %28 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 8
  %29 = load i32, ptr %28, align 4
  %30 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 8
  store i32 %29, ptr %30, align 4
  %31 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 9
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 9
  store i32 %32, ptr %33, align 4
  %34 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 10
  %35 = load i32, ptr %34, align 4
  %36 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 10
  store i32 %35, ptr %36, align 4
  %37 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 11
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 11
  store i32 %38, ptr %39, align 4
  ret void
}

; Function Attrs: argmemonly mustprogress nofree norecurse nosync nounwind willreturn
define internal fastcc void @S57_refine_coordinates(ptr nocapture readonly %0, ptr nocapture writeonly %1, i32 %2) unnamed_addr #4 {
entry:
  %3 = and i32 %2, 3
  %4 = load i32, ptr %0, align 4
  %5 = shl i32 %4, 2
  %6 = or i32 %5, %3
  store i32 %6, ptr %1, align 4
  %7 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 1
  %8 = load i32, ptr %7, align 4
  %9 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 1
  store i32 %8, ptr %9, align 4
  %10 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 2
  %11 = load i32, ptr %10, align 4
  %12 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 2
  store i32 %11, ptr %12, align 4
  %13 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 3
  %14 = load i32, ptr %13, align 4
  %15 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 3
  store i32 %14, ptr %15, align 4
  %16 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 4
  %17 = load i32, ptr %16, align 4
  %18 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 4
  store i32 %17, ptr %18, align 4
  %19 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 5
  %20 = load i32, ptr %19, align 4
  %21 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 5
  store i32 %20, ptr %21, align 4
  %22 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 6
  %23 = load i32, ptr %22, align 4
  %24 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 6
  store i32 %23, ptr %24, align 4
  %25 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 7
  %26 = load i32, ptr %25, align 4
  %27 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 7
  store i32 %26, ptr %27, align 4
  %28 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 8
  %29 = load i32, ptr %28, align 4
  %30 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 8
  store i32 %29, ptr %30, align 4
  %31 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 9
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 9
  store i32 %32, ptr %33, align 4
  %34 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 10
  %35 = load i32, ptr %34, align 4
  %36 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 10
  store i32 %35, ptr %36, align 4
  %37 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 11
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 11
  store i32 %38, ptr %39, align 4
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #5

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn writeonly
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #6

; Function Attrs: noinline nounwind optnone uwtable
define internal fastcc void @taichi_assert_format(ptr noundef %0, i1 noundef zeroext %1, ptr noundef %2) unnamed_addr #7 {
  %4 = alloca ptr, align 8
  %5 = alloca i8, align 1
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca ptr, align 8
  %9 = alloca %class.anon, align 8
  store ptr %0, ptr %4, align 8
  %10 = zext i1 %1 to i8
  store i8 %10, ptr %5, align 1
  store ptr %2, ptr %6, align 8
  store i32 0, ptr %7, align 4
  store ptr null, ptr %8, align 8
  %11 = load i8, ptr %5, align 1
  %12 = trunc i8 %11 to i1
  %13 = zext i1 %12 to i32
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %15, label %16

15:                                               ; preds = %3
  br label %69

16:                                               ; preds = %3
  %17 = load ptr, ptr %4, align 8
  %18 = getelementptr inbounds %struct.LLVMRuntime, ptr %17, i32 0, i32 24
  %19 = load i64, ptr %18, align 8
  %20 = icmp ne i64 %19, 0
  br i1 %20, label %69, label %21

21:                                               ; preds = %16
  %22 = load ptr, ptr %4, align 8
  %23 = getelementptr inbounds %struct.LLVMRuntime, ptr %22, i32 0, i32 23
  %24 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 0
  store ptr %4, ptr %24, align 8
  %25 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 1
  store ptr %6, ptr %25, align 8
  %26 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 2
  store ptr %7, ptr %26, align 8
  %27 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 3
  store ptr %8, ptr %27, align 8
  br label %28

28:                                               ; preds = %28, %21
  %29 = atomicrmw volatile xchg ptr %23, i32 1 seq_cst, align 4
  %30 = icmp eq i32 %29, 1
  br i1 %30, label %28, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i:                        ; preds = %28
  %31 = load ptr, ptr %9, align 8
  %32 = load ptr, ptr %31, align 8
  %33 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 24
  %34 = load i64, ptr %33, align 8
  %.not.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i, label %35, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

35:                                               ; preds = %mutex_lock_i32.exit.i.i.i
  store i64 1, ptr %33, align 8
  %36 = load ptr, ptr %9, align 8
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr inbounds %struct.LLVMRuntime, ptr %37, i64 0, i32 21
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %38, i8 0, i64 2048, i1 false)
  %39 = load ptr, ptr %9, align 8
  %40 = load ptr, ptr %39, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 21
  %42 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 1
  %43 = load ptr, ptr %42, align 8
  %44 = load ptr, ptr %43, align 8
  %45 = load i8, ptr %44, align 1
  %.not5.i.i.i.i.i = icmp eq i8 %45, 0
  br i1 %.not5.i.i.i.i.i, label %taichi_strlen.exit.thread.i.i.i.i, label %.lr.ph.i.i.i.i.i.preheader

.lr.ph.i.i.i.i.i.preheader:                       ; preds = %35
  br label %.lr.ph.i.i.i.i.i

.lr.ph.i.i.i.i.i:                                 ; preds = %.lr.ph.i.i.i.i.i, %.lr.ph.i.i.i.i.i.preheader
  %.07.i.i.i.i.i = phi ptr [ %47, %.lr.ph.i.i.i.i.i ], [ %44, %.lr.ph.i.i.i.i.i.preheader ]
  %.046.i.i.i.i.i = phi i64 [ %46, %.lr.ph.i.i.i.i.i ], [ 0, %.lr.ph.i.i.i.i.i.preheader ]
  %46 = add i64 %.046.i.i.i.i.i, 1
  %47 = getelementptr inbounds i8, ptr %.07.i.i.i.i.i, i64 1
  %48 = load i8, ptr %47, align 1
  %.not.i.i.i.i.i = icmp eq i8 %48, 0
  br i1 %.not.i.i.i.i.i, label %taichi_strlen.exit.i.i.i.i, label %.lr.ph.i.i.i.i.i, !llvm.loop !16

taichi_strlen.exit.i.i.i.i:                       ; preds = %.lr.ph.i.i.i.i.i
  %.lcssa = phi i64 [ %46, %.lr.ph.i.i.i.i.i ]
  %49 = call i64 @llvm.umin.i64(i64 %.lcssa, i64 2047)
  br label %taichi_strlen.exit.thread.i.i.i.i

taichi_strlen.exit.thread.i.i.i.i:                ; preds = %taichi_strlen.exit.i.i.i.i, %35
  %50 = phi i64 [ 0, %35 ], [ %49, %taichi_strlen.exit.i.i.i.i ]
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %41, ptr nonnull align 1 %44, i64 %50, i1 false)
  %51 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 2
  %52 = load ptr, ptr %51, align 8
  %53 = load i32, ptr %52, align 4
  %54 = icmp sgt i32 %53, 0
  br i1 %54, label %.lr.ph.i.i.i.i, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

.lr.ph.i.i.i.i:                                   ; preds = %taichi_strlen.exit.thread.i.i.i.i
  %55 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 3
  br label %56

56:                                               ; preds = %56, %.lr.ph.i.i.i.i
  %indvars.iv.i.i.i.i = phi i64 [ 0, %.lr.ph.i.i.i.i ], [ %indvars.iv.next.i.i.i.i, %56 ]
  %57 = load ptr, ptr %55, align 8
  %58 = load ptr, ptr %57, align 8
  %59 = getelementptr inbounds i64, ptr %58, i64 %indvars.iv.i.i.i.i
  %60 = load i64, ptr %59, align 8
  %61 = load ptr, ptr %9, align 8
  %62 = load ptr, ptr %61, align 8
  %63 = getelementptr inbounds %struct.LLVMRuntime, ptr %62, i64 0, i32 22, i64 %indvars.iv.i.i.i.i
  store i64 %60, ptr %63, align 8
  %indvars.iv.next.i.i.i.i = add nuw nsw i64 %indvars.iv.i.i.i.i, 1
  %64 = load ptr, ptr %51, align 8
  %65 = load i32, ptr %64, align 4
  %66 = sext i32 %65 to i64
  %67 = icmp slt i64 %indvars.iv.next.i.i.i.i, %66
  br i1 %67, label %56, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", !llvm.loop !17

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit": ; preds = %56
  br label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit": ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", %taichi_strlen.exit.thread.i.i.i.i, %mutex_lock_i32.exit.i.i.i
  %68 = atomicrmw volatile xchg ptr %23, i32 0 seq_cst, align 4
  br label %69

69:                                               ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit", %16, %15
  ret void
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_struct_for_block_helper(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #8 {
_ZN11ListManager3getI7ElementEERT_i.exit:
  %3 = alloca %struct.RuntimeContext.1905, align 8
  %4 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 4
  %5 = load i32, ptr %4, align 4
  %6 = sdiv i32 %2, %5
  %7 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  %8 = load i32, ptr %7, align 8
  %9 = sdiv i32 %8, %5
  %10 = srem i32 %2, %5
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  %12 = load ptr, ptr %11, align 8
  %13 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %14 = load i32, ptr %13, align 8
  %15 = ashr i32 %6, %14
  %16 = sext i32 %15 to i64
  %17 = lshr i64 %16, 9
  %18 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %17
  %19 = load atomic i64, ptr %18 acquire, align 8
  %.not.i.i.i = icmp ne i64 %19, 0
  tail call void @llvm.assume(i1 %.not.i.i.i)
  %20 = inttoptr i64 %19 to ptr
  %21 = and i64 %16, 511
  %22 = getelementptr inbounds ptr, ptr %20, i64 %21
  %23 = load atomic i64, ptr %22 acquire, align 8
  %24 = inttoptr i64 %23 to ptr
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %26 = load i64, ptr %25, align 8
  %27 = load i32, ptr %13, align 8
  %notmask.i.i = shl nsw i32 -1, %27
  %28 = xor i32 %notmask.i.i, -1
  %29 = and i32 %6, %28
  %30 = sext i32 %29 to i64
  %31 = mul i64 %26, %30
  %32 = getelementptr inbounds i8, ptr %24, i64 %31
  %33 = getelementptr inbounds %0, ptr %32, i64 0, i32 1
  %34 = load i32, ptr %33, align 8
  %35 = mul nsw i32 %10, %9
  %36 = add nsw i32 %34, %35
  %37 = add nsw i32 %10, 1
  %38 = mul nsw i32 %37, %9
  %39 = add nsw i32 %34, %38
  %40 = getelementptr inbounds %0, ptr %32, i64 0, i32 1, i64 1
  %41 = load i32, ptr %40, align 4
  %42 = tail call i32 @llvm.smin.i32(i32 %41, i32 %39)
  %43 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  %44 = load i64, ptr %43, align 8
  %45 = alloca i8, i64 %44, align 8
  %46 = load ptr, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %3, ptr noundef nonnull align 8 dereferenceable(32) %46, i64 32, i1 false)
  %47 = getelementptr inbounds %struct.RuntimeContext.1905, ptr %3, i64 0, i32 2
  store i32 %1, ptr %47, align 8
  %48 = icmp slt i32 %36, %42
  br i1 %48, label %49, label %75

49:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit
  %50 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = load ptr, ptr %11, align 8
  %53 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 3
  %54 = load i32, ptr %53, align 8
  %55 = ashr i32 %6, %54
  %56 = sext i32 %55 to i64
  %57 = lshr i64 %56, 9
  %58 = getelementptr inbounds [256 x ptr], ptr %52, i64 0, i64 %57
  %59 = load atomic i64, ptr %58 acquire, align 8
  %.not.i.i.i24 = icmp eq i64 %59, 0
  br i1 %.not.i.i.i24, label %_ZN11ListManager3getI7ElementEERT_i.exit26, label %60

60:                                               ; preds = %49
  %61 = inttoptr i64 %59 to ptr
  %62 = and i64 %56, 511
  %63 = getelementptr inbounds ptr, ptr %61, i64 %62
  %64 = load atomic i64, ptr %63 acquire, align 8
  %65 = inttoptr i64 %64 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit26

_ZN11ListManager3getI7ElementEERT_i.exit26:       ; preds = %60, %49
  %66 = phi ptr [ %65, %60 ], [ null, %49 ]
  %67 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 1
  %68 = load i64, ptr %67, align 8
  %69 = load i32, ptr %53, align 8
  %notmask.i.i25 = shl nsw i32 -1, %69
  %70 = xor i32 %notmask.i.i25, -1
  %71 = and i32 %6, %70
  %72 = sext i32 %71 to i64
  %73 = mul i64 %68, %72
  %74 = getelementptr inbounds i8, ptr %66, i64 %73
  call void %51(ptr noundef nonnull %3, ptr noundef nonnull %45, ptr noundef nonnull %74, i32 noundef %36, i32 noundef %42) #1
  br label %75

75:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit26, %_ZN11ListManager3getI7ElementEERT_i.exit
  ret void
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_parallel_range_for_task(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #8 {
  %4 = alloca %struct.RuntimeContext.1905, align 8
  %.sroa.0.0.copyload = load ptr, ptr %0, align 8
  %.sroa.4.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 8
  %.sroa.4.0.copyload = load ptr, ptr %.sroa.4.0..sroa_idx, align 8
  %.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 16
  %.sroa.5.0.copyload = load ptr, ptr %.sroa.5.0..sroa_idx, align 8
  %.sroa.7.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 24
  %.sroa.7.0.copyload = load ptr, ptr %.sroa.7.0..sroa_idx, align 8
  %.sroa.8.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 32
  %.sroa.8.0.copyload = load i64, ptr %.sroa.8.0..sroa_idx, align 8
  %.sroa.9.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 40
  %.sroa.9.0.copyload = load i32, ptr %.sroa.9.0..sroa_idx, align 8
  %.sroa.12.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 44
  %.sroa.12.0.copyload = load i32, ptr %.sroa.12.0..sroa_idx, align 4
  %.sroa.15.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 48
  %.sroa.15.0.copyload = load i32, ptr %.sroa.15.0..sroa_idx, align 8
  %.sroa.17.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 52
  %.sroa.17.0.copyload = load i32, ptr %.sroa.17.0..sroa_idx, align 4
  %5 = alloca i8, i64 %.sroa.8.0.copyload, align 8
  %.not = icmp eq ptr %.sroa.4.0.copyload, null
  br i1 %.not, label %7, label %6

6:                                                ; preds = %3
  call void %.sroa.4.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %7

7:                                                ; preds = %6, %3
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %4, ptr noundef nonnull align 8 dereferenceable(32) %.sroa.0.0.copyload, i64 32, i1 false)
  %8 = getelementptr inbounds %struct.RuntimeContext.1905, ptr %4, i64 0, i32 2
  store i32 %1, ptr %8, align 8
  switch i32 %.sroa.17.0.copyload, label %.loopexit [
    i32 1, label %9
    i32 -1, label %17
  ]

9:                                                ; preds = %7
  %10 = mul nsw i32 %.sroa.15.0.copyload, %2
  %11 = add nsw i32 %10, %.sroa.9.0.copyload
  %12 = add nsw i32 %11, %.sroa.15.0.copyload
  %13 = call i32 @llvm.smin.i32(i32 %.sroa.12.0.copyload, i32 %12)
  %14 = icmp slt i32 %11, %13
  br i1 %14, label %.lr.ph.preheader, label %.loopexit

.lr.ph.preheader:                                 ; preds = %9
  br label %.lr.ph

.lr.ph:                                           ; preds = %.lr.ph, %.lr.ph.preheader
  %.02039 = phi i32 [ %15, %.lr.ph ], [ %11, %.lr.ph.preheader ]
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.02039) #1
  %15 = add nsw i32 %.02039, 1
  %16 = icmp slt i32 %15, %13
  br i1 %16, label %.lr.ph, label %.loopexit.loopexit, !llvm.loop !18

17:                                               ; preds = %7
  %18 = mul nsw i32 %.sroa.15.0.copyload, %2
  %19 = sub nsw i32 %.sroa.12.0.copyload, %18
  %20 = mul nsw i32 %19, %.sroa.15.0.copyload
  %21 = call i32 @llvm.smax.i32(i32 %.sroa.9.0.copyload, i32 %20)
  %.not25.not40 = icmp sgt i32 %19, %21
  br i1 %.not25.not40, label %.lr.ph42.preheader, label %.loopexit

.lr.ph42.preheader:                               ; preds = %17
  br label %.lr.ph42

.lr.ph42:                                         ; preds = %.lr.ph42, %.lr.ph42.preheader
  %.0.in41 = phi i32 [ %.0, %.lr.ph42 ], [ %19, %.lr.ph42.preheader ]
  %.0 = add nsw i32 %.0.in41, -1
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.0) #1
  %.not25.not = icmp sgt i32 %.0, %21
  br i1 %.not25.not, label %.lr.ph42, label %.loopexit.loopexit47, !llvm.loop !19

.loopexit.loopexit:                               ; preds = %.lr.ph
  br label %.loopexit

.loopexit.loopexit47:                             ; preds = %.lr.ph42
  br label %.loopexit

.loopexit:                                        ; preds = %.loopexit.loopexit47, %.loopexit.loopexit, %17, %9, %7
  %.not24 = icmp eq ptr %.sroa.7.0.copyload, null
  br i1 %.not24, label %23, label %22

22:                                               ; preds = %.loopexit
  call void %.sroa.7.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %23

23:                                               ; preds = %22, %.loopexit
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #9

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i64 @llvm.umin.i64(i64, i64) #10

; Function Attrs: inaccessiblememonly nocallback nofree nosync nounwind willreturn
declare void @llvm.assume(i1 noundef) #11

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #12

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #12

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smax.i32(i32, i32) #10

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { nofree norecurse nosync nounwind }
attributes #3 = { nofree nosync nounwind }
attributes #4 = { argmemonly mustprogress nofree norecurse nosync nounwind willreturn }
attributes #5 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #6 = { argmemonly mustprogress nocallback nofree nounwind willreturn writeonly }
attributes #7 = { noinline nounwind optnone uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #10 = { nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #11 = { inaccessiblememonly nocallback nofree nosync nounwind willreturn }
attributes #12 = { argmemonly nocallback nofree nosync nounwind willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !12}
!12 = !{!"llvm.loop.unroll.disable"}
!13 = distinct !{!13, !12}
!14 = distinct !{!14, !12}
!15 = distinct !{!15, !12}
!16 = distinct !{!16, !7}
!17 = distinct !{!17, !7}
!18 = distinct !{!18, !7}
!19 = distinct !{!19, !7}
