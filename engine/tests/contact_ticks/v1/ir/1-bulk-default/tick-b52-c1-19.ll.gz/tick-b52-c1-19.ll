; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%0 = type { ptr, [2 x i32], %struct.PhysicalCoordinates.2238 }
%1 = type { [1048576 x %2], %3, %4 }
%2 = type { i8 }
%3 = type { [128 x i64], [128 x ptr] }
%4 = type { [4 x i32], [128 x %5] }
%5 = type { i32, i64 }
%6 = type { [70 x %2], %3, %4 }
%struct.RuntimeContext.2230 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }
%struct.range_task_helper_context = type { ptr, ptr, ptr, ptr, i64, i32, i32, i32, i32 }
%struct.ListManager = type { [256 x ptr], i64, i64, i32, i32, i32, ptr }
%struct.PhysicalCoordinates.2238 = type { [12 x i32] }
%struct.cpu_block_task_helper_context = type { ptr, ptr, ptr, i32, i32, i64 }
%class.anon = type { ptr, ptr, ptr, ptr }

@.str = private unnamed_addr constant [28 x i8] c"Out of pre-allocated memory\00", align 1
@.str.2 = private unnamed_addr constant [28 x i8] c"List manager out of chunks.\00", align 1

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @geometry_collect_35_selection_55_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %0, i64 0, i32 8
  %2 = load i32, ptr %1, align 4
  %3 = getelementptr inbounds %struct.RuntimeContext.2230, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 4
  store i32 %2, ptr %7, align 4
  %8 = load ptr, ptr %context, align 8
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %8, i64 0, i32 9
  %10 = load i32, ptr %9, align 4
  %11 = load ptr, ptr %3, align 8
  %12 = getelementptr inbounds %struct.LLVMRuntime, ptr %11, i64 0, i32 16
  %13 = load ptr, ptr %12, align 8
  store i32 %10, ptr %13, align 4
  %14 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %0, i64 0, i32 4, i32 1
  %15 = load ptr, ptr %14, align 8
  store i64 0, ptr %15, align 8
  %16 = load ptr, ptr %14, align 8
  %17 = getelementptr i64, ptr %16, i64 1
  store i64 0, ptr %17, align 8
  %18 = load ptr, ptr %14, align 8
  %19 = getelementptr i64, ptr %18, i64 2
  %20 = getelementptr i64, ptr %18, i64 3
  store i64 0, ptr %20, align 8
  %21 = load ptr, ptr %14, align 8
  %22 = getelementptr i64, ptr %21, i64 4
  store i64 0, ptr %22, align 8
  %23 = load ptr, ptr %14, align 8
  %24 = getelementptr i64, ptr %23, i64 5
  store i64 0, ptr %24, align 8
  %25 = load ptr, ptr %14, align 8
  %26 = getelementptr i64, ptr %25, i64 7
  store i64 0, ptr %26, align 8
  %27 = load ptr, ptr %14, align 8
  %28 = getelementptr i64, ptr %27, i64 8
  store i64 0, ptr %28, align 8
  %29 = load ptr, ptr %14, align 8
  %30 = getelementptr i64, ptr %29, i64 9
  %31 = getelementptr i64, ptr %29, i64 10
  store i64 0, ptr %31, align 8
  %32 = load ptr, ptr %14, align 8
  %33 = getelementptr i64, ptr %32, i64 11
  store i64 0, ptr %33, align 8
  %34 = load ptr, ptr %14, align 8
  %35 = getelementptr i64, ptr %34, i64 12
  store i64 0, ptr %35, align 8
  %36 = load ptr, ptr %14, align 8
  %37 = getelementptr i64, ptr %36, i64 13
  store i64 0, ptr %37, align 8
  %38 = load ptr, ptr %14, align 8
  %39 = getelementptr i64, ptr %38, i64 14
  store i64 0, ptr %39, align 8
  %40 = load ptr, ptr %14, align 8
  %41 = getelementptr i64, ptr %40, i64 15
  store i64 0, ptr %41, align 8
  %42 = sext i32 %10 to i64
  store i64 %42, ptr %19, align 8
  store i64 70, ptr %30, align 8
  ret void
}

; Function Attrs: nounwind
define void @geometry_collect_35_selection_55_kernel_1_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.2230, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %7, i64 0, i32 3, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %10 = xor i64 %9, -1
  %11 = add nsw i64 %10, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %9, %for_loop_body.prol.preheader ]
  %12 = load ptr, ptr %8, align 8
  %13 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep20 = getelementptr i8, ptr %12, i64 %13
  store i32 0, ptr %uglygep20, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !6

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %9, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %14 = icmp ult i64 %11, 7
  br i1 %14, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %for_loop_body ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %15 = load ptr, ptr %8, align 8
  %16 = shl i64 %indvars.iv, 2
  %uglygep17 = getelementptr i8, ptr %15, i64 %16
  store i32 0, ptr %uglygep17, align 4
  %17 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %17, i64 4
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %16
  store i32 0, ptr %uglygep19, align 4
  %18 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %18, i64 8
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %16
  store i32 0, ptr %uglygep16, align 4
  %19 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %19, i64 12
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %16
  store i32 0, ptr %uglygep14, align 4
  %20 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %20, i64 16
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %16
  store i32 0, ptr %uglygep12, align 4
  %21 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %21, i64 20
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %16
  store i32 0, ptr %uglygep10, align 4
  %22 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %22, i64 24
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %16
  store i32 0, ptr %uglygep8, align 4
  %23 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %23, i64 28
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %16
  store i32 0, ptr %uglygep6, align 4
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @geometry_collect_35_selection_55_kernel_2_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.2230, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 35
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @geometry_collect_35_selection_55_kernel_3_listgen_S35bitmasked(ptr %context) local_unnamed_addr #1 {
.lr.ph.i:
  %.sroa.2.i = alloca { [2 x i32], %struct.PhysicalCoordinates.2238 }, align 8
  %0 = alloca %0, align 8
  %1 = getelementptr inbounds %struct.RuntimeContext.2230, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 30
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %4, i64 35
  %8 = load ptr, ptr %7, align 8
  %9 = load atomic i64, ptr %6 acquire, align 8
  %.not.i.i.i.i = icmp ne i64 %9, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i)
  %10 = inttoptr i64 %9 to ptr
  %11 = load atomic i64, ptr %10 acquire, align 8
  %12 = inttoptr i64 %11 to ptr
  %.sroa.0.0.copyload.i = load ptr, ptr %12, align 8
  %.sroa.2.0..sroa_idx.i = getelementptr inbounds i8, ptr %12, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.i, ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.0..sroa_idx.i, i64 56, i1 false)
  %getch.i = getelementptr %1, ptr %.sroa.0.0.copyload.i, i64 0, i32 2
  %13 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %.sroa.2.16.sroa_idx.i = getelementptr inbounds i8, ptr %.sroa.2.i, i64 8
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %16 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 4
  %17 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 6
  %18 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 2
  %19 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  store ptr %getch.i, ptr %0, align 8
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %0, i64 8
  store <2 x i32> <i32 0, i32 128>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %13, ptr noundef nonnull align 8 dereferenceable(48) %.sroa.2.16.sroa_idx.i, i64 48, i1 false)
  %20 = atomicrmw volatile add ptr %14, i32 1 seq_cst, align 4
  %21 = load i32, ptr %15, align 8
  %22 = ashr i32 %20, %21
  %23 = icmp ugt i32 %22, 131071
  br i1 %23, label %24, label %26

24:                                               ; preds = %.lr.ph.i
  %25 = load ptr, ptr %17, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %25, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

26:                                               ; preds = %.lr.ph.i
  %27 = zext i32 %22 to i64
  %28 = lshr i64 %27, 9
  %29 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %28
  %30 = load atomic i64, ptr %29 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %30, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %26
  %31 = inttoptr i64 %30 to ptr
  %32 = and i64 %27, 511
  %33 = getelementptr inbounds ptr, ptr %31, i64 %32
  %34 = load atomic i64, ptr %33 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %26
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %35 = atomicrmw volatile xchg ptr %16, i32 1 seq_cst, align 4
  %36 = icmp eq i32 %35, 1
  br i1 %36, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !8

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %37 = load atomic i64, ptr %29 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %37, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %39, label %73

39:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %40 = load ptr, ptr %17, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1
  %42 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 28
  %43 = atomicrmw volatile add ptr %42, i64 4096 seq_cst, align 8
  %44 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 2
  %45 = load i64, ptr %44, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %45, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %66, label %46

46:                                               ; preds = %39
  %47 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 26
  br label %48

48:                                               ; preds = %48, %46
  %49 = atomicrmw volatile xchg ptr %47, i32 1 seq_cst, align 4
  %50 = icmp eq i32 %49, 1
  br i1 %50, label %48, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !8

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %48
  %51 = load ptr, ptr %41, align 8
  %52 = ptrtoint ptr %51 to i64
  %53 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 1
  %54 = load ptr, ptr %53, align 8
  %55 = ptrtoint ptr %54 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %52
  %56 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %57 = or i64 %56, 4096
  %58 = add i64 %57, %52
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %58, %55
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %59

59:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %60 = add i64 %56, %52
  %61 = inttoptr i64 %60 to ptr
  %62 = getelementptr i8, ptr %51, i64 %56
  %63 = getelementptr inbounds i8, ptr %62, i64 4096
  store ptr %63, ptr %41, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %59, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %61, %59 ]
  %64 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %65 = atomicrmw volatile xchg ptr %47, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %40, i1 noundef zeroext %64, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

66:                                               ; preds = %39
  %67 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 2
  %68 = load ptr, ptr %67, align 8
  %69 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 6
  %70 = load ptr, ptr %69, align 8
  %71 = tail call noundef ptr %68(ptr noundef %70, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %66, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %71, %66 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %72 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %72, ptr %29 release, align 8
  br label %73

73:                                               ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %38, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %74 = and i32 %22, 511
  %75 = zext i32 %74 to i64
  %76 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %75
  %77 = load atomic i64, ptr %76 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %77, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %78, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

78:                                               ; preds = %73
  %79 = load ptr, ptr %17, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1
  %81 = load i64, ptr %18, align 8
  %82 = load i64, ptr %19, align 8
  %83 = mul i64 %82, %81
  %84 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 28
  %85 = atomicrmw volatile add ptr %84, i64 %83 seq_cst, align 8
  %86 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 2
  %87 = load i64, ptr %86, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %87, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %107, label %88

88:                                               ; preds = %78
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 26
  br label %90

90:                                               ; preds = %90, %88
  %91 = atomicrmw volatile xchg ptr %89, i32 1 seq_cst, align 4
  %92 = icmp eq i32 %91, 1
  br i1 %92, label %90, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !8

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %90
  %93 = load ptr, ptr %80, align 8
  %94 = ptrtoint ptr %93 to i64
  %95 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 1
  %96 = load ptr, ptr %95, align 8
  %97 = ptrtoint ptr %96 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %94
  %98 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %99 = add i64 %98, %83
  %100 = add i64 %99, %94
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %100, %97
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %101

101:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %102 = add i64 %98, %94
  %103 = inttoptr i64 %102 to ptr
  %104 = getelementptr inbounds i8, ptr %93, i64 %99
  store ptr %104, ptr %80, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %101, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %103, %101 ]
  %105 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %106 = atomicrmw volatile xchg ptr %89, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %79, i1 noundef zeroext %105, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

107:                                              ; preds = %78
  %108 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 2
  %109 = load ptr, ptr %108, align 8
  %110 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 6
  %111 = load ptr, ptr %110, align 8
  %112 = tail call noundef ptr %109(ptr noundef %111, i64 noundef %83, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %107, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %112, %107 ]
  %113 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %113, ptr %76 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %73
  %114 = atomicrmw volatile xchg ptr %16, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %24
  %115 = load i32, ptr %15, align 8
  %116 = ashr i32 %20, %115
  %117 = sext i32 %116 to i64
  %118 = lshr i64 %117, 9
  %119 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %118
  %120 = load atomic i64, ptr %119 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %120, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %121

121:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %122 = inttoptr i64 %120 to ptr
  %123 = and i64 %117, 511
  %124 = getelementptr inbounds ptr, ptr %122, i64 %123
  %125 = load atomic i64, ptr %124 acquire, align 8
  %126 = inttoptr i64 %125 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %121, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %127 = phi ptr [ %126, %121 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %128 = load i64, ptr %19, align 8
  %129 = load i32, ptr %15, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %129
  %130 = xor i32 %notmask.i.i.i.i, -1
  %131 = and i32 %20, %130
  %132 = sext i32 %131 to i64
  %133 = mul i64 %128, %132
  %134 = getelementptr inbounds i8, ptr %127, i64 %133
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %134, ptr nonnull align 8 %0, i64 %128, i1 false)
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  ret void
}

; Function Attrs: nounwind
define void @geometry_collect_35_selection_55_kernel_4_struct_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.cpu_block_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.RuntimeContext.2230, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 35
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds %struct.ListManager, ptr %6, i64 0, i32 5
  %8 = load i32, ptr %7, align 8
  store ptr %context, ptr %0, align 8
  %9 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  store ptr @function_body.1, ptr %9, align 8
  %10 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  store ptr %6, ptr %10, align 8
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  store <2 x i32> <i32 128, i32 128>, ptr %11, align 8
  %12 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  store i64 1, ptr %12, align 8
  %13 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 12
  %14 = load ptr, ptr %13, align 8
  %15 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 11
  %16 = load ptr, ptr %15, align 8
  %17 = shl nsw i32 %8, 7
  call void %14(ptr noundef %16, i32 noundef %17, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_struct_for_block_helper) #1
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree norecurse nounwind
define internal void @function_body.1(ptr %0, ptr nocapture readnone %1, ptr nocapture readonly %2, i32 %3, i32 %4) #3 {
allocs:
  %5 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %6 = icmp sgt i32 %4, %3
  br i1 %6, label %loop_body.lr.ph, label %func_exit

loop_body.lr.ph:                                  ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.2230, ptr %0, i64 0, i32 1
  %8 = sub i32 %4, %3
  %9 = xor i32 %3, -1
  %10 = add i32 %9, %4
  %xtraiter = and i32 %8, 7
  %lcmp.mod.not = icmp eq i32 %xtraiter, 0
  br i1 %lcmp.mod.not, label %loop_body.prol.loopexit, label %loop_body.prol.preheader

loop_body.prol.preheader:                         ; preds = %loop_body.lr.ph
  br label %loop_body.prol

loop_body.prol:                                   ; preds = %loop_body_tail.prol, %loop_body.prol.preheader
  %lsr.iv45 = phi i32 [ %xtraiter, %loop_body.prol.preheader ], [ %lsr.iv.next46, %loop_body_tail.prol ]
  %.044.prol = phi i32 [ %63, %loop_body_tail.prol ], [ %3, %loop_body.prol.preheader ]
  %11 = load ptr, ptr %2, align 8
  %12 = getelementptr inbounds i8, ptr %11, i64 2048
  %13 = sdiv i32 %.044.prol, 8
  %14 = sext i32 %13 to i64
  %15 = getelementptr inbounds i8, ptr %12, i64 %14
  %16 = load i8, ptr %15, align 1
  %17 = zext i8 %16 to i32
  %18 = and i32 %.044.prol, 7
  %19 = shl nuw nsw i32 1, %18
  %20 = and i32 %19, %17
  %.not.prol = icmp eq i32 %20, 0
  br i1 %.not.prol, label %loop_body_tail.prol, label %struct_for_body_body.prol

struct_for_body_body.prol:                        ; preds = %loop_body.prol
  %21 = and i32 %.044.prol, 127
  %22 = load i32, ptr %5, align 4
  %23 = shl i32 %22, 7
  %24 = or i32 %23, %21
  %25 = load ptr, ptr %0, align 8
  %26 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %25, i64 0, i32 3, i32 1
  %27 = load ptr, ptr %26, align 8
  %28 = sext i32 %24 to i64
  %29 = getelementptr i32, ptr %27, i64 %28
  store i32 1, ptr %29, align 4
  %30 = load ptr, ptr %0, align 8
  %31 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %30, i64 0, i32 4, i32 1
  %32 = load ptr, ptr %31, align 8
  %33 = getelementptr i64, ptr %32, i64 8
  %34 = atomicrmw add ptr %33, i64 1 seq_cst, align 8
  %35 = load ptr, ptr %7, align 8
  %36 = getelementptr inbounds %struct.LLVMRuntime, ptr %35, i64 0, i32 7
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr inbounds ptr, ptr %37, i64 5
  %39 = load ptr, ptr %38, align 8
  %40 = lshr i32 %24, 2
  %41 = and i32 %40, 1073741816
  %42 = zext i32 %41 to i64
  %43 = getelementptr i8, ptr %39, i64 %42
  %44 = getelementptr inbounds i8, ptr %43, i64 32
  %45 = load ptr, ptr %44, align 8
  %46 = icmp eq ptr %45, null
  br i1 %46, label %47, label %Pointer_lookup_element.exit.prol

47:                                               ; preds = %struct_for_body_body.prol
  %48 = getelementptr inbounds %struct.LLVMRuntime, ptr %35, i64 0, i32 15
  %49 = load ptr, ptr %48, align 8
  %50 = getelementptr inbounds ptr, ptr %49, i64 54
  %51 = load ptr, ptr %50, align 8
  br label %Pointer_lookup_element.exit.prol

Pointer_lookup_element.exit.prol:                 ; preds = %47, %struct_for_body_body.prol
  %.0.i.prol = phi ptr [ %51, %47 ], [ %45, %struct_for_body_body.prol ]
  %52 = getelementptr inbounds i8, ptr %.0.i.prol, i64 32
  %53 = lshr i32 %.044.prol, 3
  %54 = and i32 %53, 3
  %55 = zext i32 %54 to i64
  %56 = getelementptr inbounds i8, ptr %52, i64 %55
  %57 = load i8, ptr %56, align 1
  %58 = zext i8 %57 to i32
  %59 = and i32 %19, %58
  %.not43.prol = icmp eq i32 %59, 0
  br i1 %.not43.prol, label %loop_body_tail.prol, label %true_block.prol

true_block.prol:                                  ; preds = %Pointer_lookup_element.exit.prol
  %60 = load ptr, ptr %31, align 8
  %61 = getelementptr i64, ptr %60, i64 1
  %62 = atomicrmw add ptr %61, i64 1 seq_cst, align 8
  br label %loop_body_tail.prol

loop_body_tail.prol:                              ; preds = %true_block.prol, %Pointer_lookup_element.exit.prol, %loop_body.prol
  %63 = add i32 %.044.prol, 1
  %lsr.iv.next46 = add nsw i32 %lsr.iv45, -1
  %prol.iter.cmp.not = icmp eq i32 %lsr.iv.next46, 0
  br i1 %prol.iter.cmp.not, label %loop_body.prol.loopexit.loopexit, label %loop_body.prol, !llvm.loop !10

loop_body.prol.loopexit.loopexit:                 ; preds = %loop_body_tail.prol
  br label %loop_body.prol.loopexit

loop_body.prol.loopexit:                          ; preds = %loop_body.prol.loopexit.loopexit, %loop_body.lr.ph
  %.044.unr = phi i32 [ %3, %loop_body.lr.ph ], [ %63, %loop_body.prol.loopexit.loopexit ]
  %64 = icmp ult i32 %10, 7
  br i1 %64, label %func_exit, label %loop_body.lr.ph.new

loop_body.lr.ph.new:                              ; preds = %loop_body.prol.loopexit
  %65 = and i32 %.044.unr, 7
  %66 = add i32 %.044.unr, 1
  %67 = and i32 %66, 7
  %68 = add i32 %.044.unr, 2
  %69 = and i32 %68, 7
  %70 = add i32 %.044.unr, 3
  %71 = and i32 %70, 7
  %72 = xor i32 %65, 4
  %73 = add i32 %.044.unr, 5
  %74 = and i32 %73, 7
  %75 = add i32 %.044.unr, 6
  %76 = and i32 %75, 7
  %77 = add i32 %.044.unr, 7
  %78 = and i32 %77, 7
  %79 = shl nuw nsw i32 1, %65
  %80 = shl nuw nsw i32 1, %67
  %81 = shl nuw nsw i32 1, %69
  %82 = shl nuw nsw i32 1, %71
  %83 = shl nuw nsw i32 1, %72
  %84 = shl nuw nsw i32 1, %74
  %85 = shl nuw nsw i32 1, %76
  %86 = shl nuw nsw i32 1, %78
  br label %loop_body

loop_body:                                        ; preds = %loop_body_tail.7, %loop_body.lr.ph.new
  %lsr.iv = phi i32 [ %lsr.iv.next, %loop_body_tail.7 ], [ %77, %loop_body.lr.ph.new ]
  %87 = add i32 %lsr.iv, -7
  %88 = load ptr, ptr %2, align 8
  %89 = getelementptr inbounds i8, ptr %88, i64 2048
  %90 = sdiv i32 %87, 8
  %91 = sext i32 %90 to i64
  %92 = getelementptr inbounds i8, ptr %89, i64 %91
  %93 = load i8, ptr %92, align 1
  %94 = zext i8 %93 to i32
  %95 = and i32 %79, %94
  %.not = icmp eq i32 %95, 0
  br i1 %.not, label %loop_body_tail, label %struct_for_body_body

loop_body_tail:                                   ; preds = %true_block, %Pointer_lookup_element.exit, %loop_body
  %96 = add i32 %lsr.iv, -6
  %97 = load ptr, ptr %2, align 8
  %98 = getelementptr inbounds i8, ptr %97, i64 2048
  %99 = add i32 %87, 1
  %100 = sdiv i32 %99, 8
  %101 = sext i32 %100 to i64
  %102 = getelementptr inbounds i8, ptr %98, i64 %101
  %103 = load i8, ptr %102, align 1
  %104 = zext i8 %103 to i32
  %105 = and i32 %80, %104
  %.not.1 = icmp eq i32 %105, 0
  br i1 %.not.1, label %loop_body_tail.1, label %struct_for_body_body.1

struct_for_body_body.1:                           ; preds = %loop_body_tail
  %106 = and i32 %96, 127
  %107 = load i32, ptr %5, align 4
  %108 = shl i32 %107, 7
  %109 = or i32 %108, %106
  %110 = load ptr, ptr %0, align 8
  %111 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %110, i64 0, i32 3, i32 1
  %112 = load ptr, ptr %111, align 8
  %113 = sext i32 %109 to i64
  %114 = getelementptr i32, ptr %112, i64 %113
  store i32 1, ptr %114, align 4
  %115 = load ptr, ptr %0, align 8
  %116 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %115, i64 0, i32 4, i32 1
  %117 = load ptr, ptr %116, align 8
  %118 = getelementptr i64, ptr %117, i64 8
  %119 = atomicrmw add ptr %118, i64 1 seq_cst, align 8
  %120 = load ptr, ptr %7, align 8
  %121 = getelementptr inbounds %struct.LLVMRuntime, ptr %120, i64 0, i32 7
  %122 = load ptr, ptr %121, align 8
  %123 = getelementptr inbounds ptr, ptr %122, i64 5
  %124 = load ptr, ptr %123, align 8
  %125 = lshr i32 %109, 2
  %126 = and i32 %125, 1073741816
  %127 = zext i32 %126 to i64
  %128 = getelementptr i8, ptr %124, i64 %127
  %129 = getelementptr inbounds i8, ptr %128, i64 32
  %130 = load ptr, ptr %129, align 8
  %131 = icmp eq ptr %130, null
  br i1 %131, label %132, label %Pointer_lookup_element.exit.1

132:                                              ; preds = %struct_for_body_body.1
  %133 = getelementptr inbounds %struct.LLVMRuntime, ptr %120, i64 0, i32 15
  %134 = load ptr, ptr %133, align 8
  %135 = getelementptr inbounds ptr, ptr %134, i64 54
  %136 = load ptr, ptr %135, align 8
  br label %Pointer_lookup_element.exit.1

Pointer_lookup_element.exit.1:                    ; preds = %132, %struct_for_body_body.1
  %.0.i.1 = phi ptr [ %136, %132 ], [ %130, %struct_for_body_body.1 ]
  %137 = getelementptr inbounds i8, ptr %.0.i.1, i64 32
  %138 = lshr i32 %96, 3
  %139 = and i32 %138, 3
  %140 = zext i32 %139 to i64
  %141 = getelementptr inbounds i8, ptr %137, i64 %140
  %142 = load i8, ptr %141, align 1
  %143 = zext i8 %142 to i32
  %144 = and i32 %80, %143
  %.not43.1 = icmp eq i32 %144, 0
  br i1 %.not43.1, label %loop_body_tail.1, label %true_block.1

true_block.1:                                     ; preds = %Pointer_lookup_element.exit.1
  %145 = load ptr, ptr %116, align 8
  %146 = getelementptr i64, ptr %145, i64 1
  %147 = atomicrmw add ptr %146, i64 1 seq_cst, align 8
  br label %loop_body_tail.1

loop_body_tail.1:                                 ; preds = %true_block.1, %Pointer_lookup_element.exit.1, %loop_body_tail
  %148 = add i32 %lsr.iv, -5
  %149 = load ptr, ptr %2, align 8
  %150 = getelementptr inbounds i8, ptr %149, i64 2048
  %151 = add i32 %99, 1
  %152 = sdiv i32 %151, 8
  %153 = sext i32 %152 to i64
  %154 = getelementptr inbounds i8, ptr %150, i64 %153
  %155 = load i8, ptr %154, align 1
  %156 = zext i8 %155 to i32
  %157 = and i32 %81, %156
  %.not.2 = icmp eq i32 %157, 0
  br i1 %.not.2, label %loop_body_tail.2, label %struct_for_body_body.2

struct_for_body_body.2:                           ; preds = %loop_body_tail.1
  %158 = and i32 %148, 127
  %159 = load i32, ptr %5, align 4
  %160 = shl i32 %159, 7
  %161 = or i32 %160, %158
  %162 = load ptr, ptr %0, align 8
  %163 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %162, i64 0, i32 3, i32 1
  %164 = load ptr, ptr %163, align 8
  %165 = sext i32 %161 to i64
  %166 = getelementptr i32, ptr %164, i64 %165
  store i32 1, ptr %166, align 4
  %167 = load ptr, ptr %0, align 8
  %168 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %167, i64 0, i32 4, i32 1
  %169 = load ptr, ptr %168, align 8
  %170 = getelementptr i64, ptr %169, i64 8
  %171 = atomicrmw add ptr %170, i64 1 seq_cst, align 8
  %172 = load ptr, ptr %7, align 8
  %173 = getelementptr inbounds %struct.LLVMRuntime, ptr %172, i64 0, i32 7
  %174 = load ptr, ptr %173, align 8
  %175 = getelementptr inbounds ptr, ptr %174, i64 5
  %176 = load ptr, ptr %175, align 8
  %177 = lshr i32 %161, 2
  %178 = and i32 %177, 1073741816
  %179 = zext i32 %178 to i64
  %180 = getelementptr i8, ptr %176, i64 %179
  %181 = getelementptr inbounds i8, ptr %180, i64 32
  %182 = load ptr, ptr %181, align 8
  %183 = icmp eq ptr %182, null
  br i1 %183, label %184, label %Pointer_lookup_element.exit.2

184:                                              ; preds = %struct_for_body_body.2
  %185 = getelementptr inbounds %struct.LLVMRuntime, ptr %172, i64 0, i32 15
  %186 = load ptr, ptr %185, align 8
  %187 = getelementptr inbounds ptr, ptr %186, i64 54
  %188 = load ptr, ptr %187, align 8
  br label %Pointer_lookup_element.exit.2

Pointer_lookup_element.exit.2:                    ; preds = %184, %struct_for_body_body.2
  %.0.i.2 = phi ptr [ %188, %184 ], [ %182, %struct_for_body_body.2 ]
  %189 = getelementptr inbounds i8, ptr %.0.i.2, i64 32
  %190 = lshr i32 %148, 3
  %191 = and i32 %190, 3
  %192 = zext i32 %191 to i64
  %193 = getelementptr inbounds i8, ptr %189, i64 %192
  %194 = load i8, ptr %193, align 1
  %195 = zext i8 %194 to i32
  %196 = and i32 %81, %195
  %.not43.2 = icmp eq i32 %196, 0
  br i1 %.not43.2, label %loop_body_tail.2, label %true_block.2

true_block.2:                                     ; preds = %Pointer_lookup_element.exit.2
  %197 = load ptr, ptr %168, align 8
  %198 = getelementptr i64, ptr %197, i64 1
  %199 = atomicrmw add ptr %198, i64 1 seq_cst, align 8
  br label %loop_body_tail.2

loop_body_tail.2:                                 ; preds = %true_block.2, %Pointer_lookup_element.exit.2, %loop_body_tail.1
  %200 = add i32 %lsr.iv, -4
  %201 = load ptr, ptr %2, align 8
  %202 = getelementptr inbounds i8, ptr %201, i64 2048
  %203 = add i32 %151, 1
  %204 = sdiv i32 %203, 8
  %205 = sext i32 %204 to i64
  %206 = getelementptr inbounds i8, ptr %202, i64 %205
  %207 = load i8, ptr %206, align 1
  %208 = zext i8 %207 to i32
  %209 = and i32 %82, %208
  %.not.3 = icmp eq i32 %209, 0
  br i1 %.not.3, label %loop_body_tail.3, label %struct_for_body_body.3

struct_for_body_body.3:                           ; preds = %loop_body_tail.2
  %210 = and i32 %200, 127
  %211 = load i32, ptr %5, align 4
  %212 = shl i32 %211, 7
  %213 = or i32 %212, %210
  %214 = load ptr, ptr %0, align 8
  %215 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %214, i64 0, i32 3, i32 1
  %216 = load ptr, ptr %215, align 8
  %217 = sext i32 %213 to i64
  %218 = getelementptr i32, ptr %216, i64 %217
  store i32 1, ptr %218, align 4
  %219 = load ptr, ptr %0, align 8
  %220 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %219, i64 0, i32 4, i32 1
  %221 = load ptr, ptr %220, align 8
  %222 = getelementptr i64, ptr %221, i64 8
  %223 = atomicrmw add ptr %222, i64 1 seq_cst, align 8
  %224 = load ptr, ptr %7, align 8
  %225 = getelementptr inbounds %struct.LLVMRuntime, ptr %224, i64 0, i32 7
  %226 = load ptr, ptr %225, align 8
  %227 = getelementptr inbounds ptr, ptr %226, i64 5
  %228 = load ptr, ptr %227, align 8
  %229 = lshr i32 %213, 2
  %230 = and i32 %229, 1073741816
  %231 = zext i32 %230 to i64
  %232 = getelementptr i8, ptr %228, i64 %231
  %233 = getelementptr inbounds i8, ptr %232, i64 32
  %234 = load ptr, ptr %233, align 8
  %235 = icmp eq ptr %234, null
  br i1 %235, label %236, label %Pointer_lookup_element.exit.3

236:                                              ; preds = %struct_for_body_body.3
  %237 = getelementptr inbounds %struct.LLVMRuntime, ptr %224, i64 0, i32 15
  %238 = load ptr, ptr %237, align 8
  %239 = getelementptr inbounds ptr, ptr %238, i64 54
  %240 = load ptr, ptr %239, align 8
  br label %Pointer_lookup_element.exit.3

Pointer_lookup_element.exit.3:                    ; preds = %236, %struct_for_body_body.3
  %.0.i.3 = phi ptr [ %240, %236 ], [ %234, %struct_for_body_body.3 ]
  %241 = getelementptr inbounds i8, ptr %.0.i.3, i64 32
  %242 = lshr i32 %200, 3
  %243 = and i32 %242, 3
  %244 = zext i32 %243 to i64
  %245 = getelementptr inbounds i8, ptr %241, i64 %244
  %246 = load i8, ptr %245, align 1
  %247 = zext i8 %246 to i32
  %248 = and i32 %82, %247
  %.not43.3 = icmp eq i32 %248, 0
  br i1 %.not43.3, label %loop_body_tail.3, label %true_block.3

true_block.3:                                     ; preds = %Pointer_lookup_element.exit.3
  %249 = load ptr, ptr %220, align 8
  %250 = getelementptr i64, ptr %249, i64 1
  %251 = atomicrmw add ptr %250, i64 1 seq_cst, align 8
  br label %loop_body_tail.3

loop_body_tail.3:                                 ; preds = %true_block.3, %Pointer_lookup_element.exit.3, %loop_body_tail.2
  %252 = add i32 %lsr.iv, -3
  %253 = load ptr, ptr %2, align 8
  %254 = getelementptr inbounds i8, ptr %253, i64 2048
  %255 = add i32 %203, 1
  %256 = sdiv i32 %255, 8
  %257 = sext i32 %256 to i64
  %258 = getelementptr inbounds i8, ptr %254, i64 %257
  %259 = load i8, ptr %258, align 1
  %260 = zext i8 %259 to i32
  %261 = and i32 %83, %260
  %.not.4 = icmp eq i32 %261, 0
  br i1 %.not.4, label %loop_body_tail.4, label %struct_for_body_body.4

struct_for_body_body.4:                           ; preds = %loop_body_tail.3
  %262 = and i32 %252, 127
  %263 = load i32, ptr %5, align 4
  %264 = shl i32 %263, 7
  %265 = or i32 %264, %262
  %266 = load ptr, ptr %0, align 8
  %267 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %266, i64 0, i32 3, i32 1
  %268 = load ptr, ptr %267, align 8
  %269 = sext i32 %265 to i64
  %270 = getelementptr i32, ptr %268, i64 %269
  store i32 1, ptr %270, align 4
  %271 = load ptr, ptr %0, align 8
  %272 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %271, i64 0, i32 4, i32 1
  %273 = load ptr, ptr %272, align 8
  %274 = getelementptr i64, ptr %273, i64 8
  %275 = atomicrmw add ptr %274, i64 1 seq_cst, align 8
  %276 = load ptr, ptr %7, align 8
  %277 = getelementptr inbounds %struct.LLVMRuntime, ptr %276, i64 0, i32 7
  %278 = load ptr, ptr %277, align 8
  %279 = getelementptr inbounds ptr, ptr %278, i64 5
  %280 = load ptr, ptr %279, align 8
  %281 = lshr i32 %265, 2
  %282 = and i32 %281, 1073741816
  %283 = zext i32 %282 to i64
  %284 = getelementptr i8, ptr %280, i64 %283
  %285 = getelementptr inbounds i8, ptr %284, i64 32
  %286 = load ptr, ptr %285, align 8
  %287 = icmp eq ptr %286, null
  br i1 %287, label %288, label %Pointer_lookup_element.exit.4

288:                                              ; preds = %struct_for_body_body.4
  %289 = getelementptr inbounds %struct.LLVMRuntime, ptr %276, i64 0, i32 15
  %290 = load ptr, ptr %289, align 8
  %291 = getelementptr inbounds ptr, ptr %290, i64 54
  %292 = load ptr, ptr %291, align 8
  br label %Pointer_lookup_element.exit.4

Pointer_lookup_element.exit.4:                    ; preds = %288, %struct_for_body_body.4
  %.0.i.4 = phi ptr [ %292, %288 ], [ %286, %struct_for_body_body.4 ]
  %293 = getelementptr inbounds i8, ptr %.0.i.4, i64 32
  %294 = lshr i32 %252, 3
  %295 = and i32 %294, 3
  %296 = zext i32 %295 to i64
  %297 = getelementptr inbounds i8, ptr %293, i64 %296
  %298 = load i8, ptr %297, align 1
  %299 = zext i8 %298 to i32
  %300 = and i32 %83, %299
  %.not43.4 = icmp eq i32 %300, 0
  br i1 %.not43.4, label %loop_body_tail.4, label %true_block.4

true_block.4:                                     ; preds = %Pointer_lookup_element.exit.4
  %301 = load ptr, ptr %272, align 8
  %302 = getelementptr i64, ptr %301, i64 1
  %303 = atomicrmw add ptr %302, i64 1 seq_cst, align 8
  br label %loop_body_tail.4

loop_body_tail.4:                                 ; preds = %true_block.4, %Pointer_lookup_element.exit.4, %loop_body_tail.3
  %304 = add i32 %lsr.iv, -2
  %305 = load ptr, ptr %2, align 8
  %306 = getelementptr inbounds i8, ptr %305, i64 2048
  %307 = add i32 %255, 1
  %308 = sdiv i32 %307, 8
  %309 = sext i32 %308 to i64
  %310 = getelementptr inbounds i8, ptr %306, i64 %309
  %311 = load i8, ptr %310, align 1
  %312 = zext i8 %311 to i32
  %313 = and i32 %84, %312
  %.not.5 = icmp eq i32 %313, 0
  br i1 %.not.5, label %loop_body_tail.5, label %struct_for_body_body.5

struct_for_body_body.5:                           ; preds = %loop_body_tail.4
  %314 = and i32 %304, 127
  %315 = load i32, ptr %5, align 4
  %316 = shl i32 %315, 7
  %317 = or i32 %316, %314
  %318 = load ptr, ptr %0, align 8
  %319 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %318, i64 0, i32 3, i32 1
  %320 = load ptr, ptr %319, align 8
  %321 = sext i32 %317 to i64
  %322 = getelementptr i32, ptr %320, i64 %321
  store i32 1, ptr %322, align 4
  %323 = load ptr, ptr %0, align 8
  %324 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %323, i64 0, i32 4, i32 1
  %325 = load ptr, ptr %324, align 8
  %326 = getelementptr i64, ptr %325, i64 8
  %327 = atomicrmw add ptr %326, i64 1 seq_cst, align 8
  %328 = load ptr, ptr %7, align 8
  %329 = getelementptr inbounds %struct.LLVMRuntime, ptr %328, i64 0, i32 7
  %330 = load ptr, ptr %329, align 8
  %331 = getelementptr inbounds ptr, ptr %330, i64 5
  %332 = load ptr, ptr %331, align 8
  %333 = lshr i32 %317, 2
  %334 = and i32 %333, 1073741816
  %335 = zext i32 %334 to i64
  %336 = getelementptr i8, ptr %332, i64 %335
  %337 = getelementptr inbounds i8, ptr %336, i64 32
  %338 = load ptr, ptr %337, align 8
  %339 = icmp eq ptr %338, null
  br i1 %339, label %340, label %Pointer_lookup_element.exit.5

340:                                              ; preds = %struct_for_body_body.5
  %341 = getelementptr inbounds %struct.LLVMRuntime, ptr %328, i64 0, i32 15
  %342 = load ptr, ptr %341, align 8
  %343 = getelementptr inbounds ptr, ptr %342, i64 54
  %344 = load ptr, ptr %343, align 8
  br label %Pointer_lookup_element.exit.5

Pointer_lookup_element.exit.5:                    ; preds = %340, %struct_for_body_body.5
  %.0.i.5 = phi ptr [ %344, %340 ], [ %338, %struct_for_body_body.5 ]
  %345 = getelementptr inbounds i8, ptr %.0.i.5, i64 32
  %346 = lshr i32 %304, 3
  %347 = and i32 %346, 3
  %348 = zext i32 %347 to i64
  %349 = getelementptr inbounds i8, ptr %345, i64 %348
  %350 = load i8, ptr %349, align 1
  %351 = zext i8 %350 to i32
  %352 = and i32 %84, %351
  %.not43.5 = icmp eq i32 %352, 0
  br i1 %.not43.5, label %loop_body_tail.5, label %true_block.5

true_block.5:                                     ; preds = %Pointer_lookup_element.exit.5
  %353 = load ptr, ptr %324, align 8
  %354 = getelementptr i64, ptr %353, i64 1
  %355 = atomicrmw add ptr %354, i64 1 seq_cst, align 8
  br label %loop_body_tail.5

loop_body_tail.5:                                 ; preds = %true_block.5, %Pointer_lookup_element.exit.5, %loop_body_tail.4
  %356 = add i32 %lsr.iv, -1
  %357 = load ptr, ptr %2, align 8
  %358 = getelementptr inbounds i8, ptr %357, i64 2048
  %359 = add i32 %307, 1
  %360 = sdiv i32 %359, 8
  %361 = sext i32 %360 to i64
  %362 = getelementptr inbounds i8, ptr %358, i64 %361
  %363 = load i8, ptr %362, align 1
  %364 = zext i8 %363 to i32
  %365 = and i32 %85, %364
  %.not.6 = icmp eq i32 %365, 0
  br i1 %.not.6, label %loop_body_tail.6, label %struct_for_body_body.6

struct_for_body_body.6:                           ; preds = %loop_body_tail.5
  %366 = and i32 %356, 127
  %367 = load i32, ptr %5, align 4
  %368 = shl i32 %367, 7
  %369 = or i32 %368, %366
  %370 = load ptr, ptr %0, align 8
  %371 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %370, i64 0, i32 3, i32 1
  %372 = load ptr, ptr %371, align 8
  %373 = sext i32 %369 to i64
  %374 = getelementptr i32, ptr %372, i64 %373
  store i32 1, ptr %374, align 4
  %375 = load ptr, ptr %0, align 8
  %376 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %375, i64 0, i32 4, i32 1
  %377 = load ptr, ptr %376, align 8
  %378 = getelementptr i64, ptr %377, i64 8
  %379 = atomicrmw add ptr %378, i64 1 seq_cst, align 8
  %380 = load ptr, ptr %7, align 8
  %381 = getelementptr inbounds %struct.LLVMRuntime, ptr %380, i64 0, i32 7
  %382 = load ptr, ptr %381, align 8
  %383 = getelementptr inbounds ptr, ptr %382, i64 5
  %384 = load ptr, ptr %383, align 8
  %385 = lshr i32 %369, 2
  %386 = and i32 %385, 1073741816
  %387 = zext i32 %386 to i64
  %388 = getelementptr i8, ptr %384, i64 %387
  %389 = getelementptr inbounds i8, ptr %388, i64 32
  %390 = load ptr, ptr %389, align 8
  %391 = icmp eq ptr %390, null
  br i1 %391, label %392, label %Pointer_lookup_element.exit.6

392:                                              ; preds = %struct_for_body_body.6
  %393 = getelementptr inbounds %struct.LLVMRuntime, ptr %380, i64 0, i32 15
  %394 = load ptr, ptr %393, align 8
  %395 = getelementptr inbounds ptr, ptr %394, i64 54
  %396 = load ptr, ptr %395, align 8
  br label %Pointer_lookup_element.exit.6

Pointer_lookup_element.exit.6:                    ; preds = %392, %struct_for_body_body.6
  %.0.i.6 = phi ptr [ %396, %392 ], [ %390, %struct_for_body_body.6 ]
  %397 = getelementptr inbounds i8, ptr %.0.i.6, i64 32
  %398 = lshr i32 %356, 3
  %399 = and i32 %398, 3
  %400 = zext i32 %399 to i64
  %401 = getelementptr inbounds i8, ptr %397, i64 %400
  %402 = load i8, ptr %401, align 1
  %403 = zext i8 %402 to i32
  %404 = and i32 %85, %403
  %.not43.6 = icmp eq i32 %404, 0
  br i1 %.not43.6, label %loop_body_tail.6, label %true_block.6

true_block.6:                                     ; preds = %Pointer_lookup_element.exit.6
  %405 = load ptr, ptr %376, align 8
  %406 = getelementptr i64, ptr %405, i64 1
  %407 = atomicrmw add ptr %406, i64 1 seq_cst, align 8
  br label %loop_body_tail.6

loop_body_tail.6:                                 ; preds = %true_block.6, %Pointer_lookup_element.exit.6, %loop_body_tail.5
  %408 = load ptr, ptr %2, align 8
  %409 = getelementptr inbounds i8, ptr %408, i64 2048
  %410 = add i32 %359, 1
  %411 = sdiv i32 %410, 8
  %412 = sext i32 %411 to i64
  %413 = getelementptr inbounds i8, ptr %409, i64 %412
  %414 = load i8, ptr %413, align 1
  %415 = zext i8 %414 to i32
  %416 = and i32 %86, %415
  %.not.7 = icmp eq i32 %416, 0
  br i1 %.not.7, label %loop_body_tail.7, label %struct_for_body_body.7

struct_for_body_body.7:                           ; preds = %loop_body_tail.6
  %417 = and i32 %lsr.iv, 127
  %418 = load i32, ptr %5, align 4
  %419 = shl i32 %418, 7
  %420 = or i32 %419, %417
  %421 = load ptr, ptr %0, align 8
  %422 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %421, i64 0, i32 3, i32 1
  %423 = load ptr, ptr %422, align 8
  %424 = sext i32 %420 to i64
  %425 = getelementptr i32, ptr %423, i64 %424
  store i32 1, ptr %425, align 4
  %426 = load ptr, ptr %0, align 8
  %427 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %426, i64 0, i32 4, i32 1
  %428 = load ptr, ptr %427, align 8
  %429 = getelementptr i64, ptr %428, i64 8
  %430 = atomicrmw add ptr %429, i64 1 seq_cst, align 8
  %431 = load ptr, ptr %7, align 8
  %432 = getelementptr inbounds %struct.LLVMRuntime, ptr %431, i64 0, i32 7
  %433 = load ptr, ptr %432, align 8
  %434 = getelementptr inbounds ptr, ptr %433, i64 5
  %435 = load ptr, ptr %434, align 8
  %436 = lshr i32 %420, 2
  %437 = and i32 %436, 1073741816
  %438 = zext i32 %437 to i64
  %439 = getelementptr i8, ptr %435, i64 %438
  %440 = getelementptr inbounds i8, ptr %439, i64 32
  %441 = load ptr, ptr %440, align 8
  %442 = icmp eq ptr %441, null
  br i1 %442, label %443, label %Pointer_lookup_element.exit.7

443:                                              ; preds = %struct_for_body_body.7
  %444 = getelementptr inbounds %struct.LLVMRuntime, ptr %431, i64 0, i32 15
  %445 = load ptr, ptr %444, align 8
  %446 = getelementptr inbounds ptr, ptr %445, i64 54
  %447 = load ptr, ptr %446, align 8
  br label %Pointer_lookup_element.exit.7

Pointer_lookup_element.exit.7:                    ; preds = %443, %struct_for_body_body.7
  %.0.i.7 = phi ptr [ %447, %443 ], [ %441, %struct_for_body_body.7 ]
  %448 = getelementptr inbounds i8, ptr %.0.i.7, i64 32
  %449 = lshr i32 %lsr.iv, 3
  %450 = and i32 %449, 3
  %451 = zext i32 %450 to i64
  %452 = getelementptr inbounds i8, ptr %448, i64 %451
  %453 = load i8, ptr %452, align 1
  %454 = zext i8 %453 to i32
  %455 = and i32 %86, %454
  %.not43.7 = icmp eq i32 %455, 0
  br i1 %.not43.7, label %loop_body_tail.7, label %true_block.7

true_block.7:                                     ; preds = %Pointer_lookup_element.exit.7
  %456 = load ptr, ptr %427, align 8
  %457 = getelementptr i64, ptr %456, i64 1
  %458 = atomicrmw add ptr %457, i64 1 seq_cst, align 8
  br label %loop_body_tail.7

loop_body_tail.7:                                 ; preds = %true_block.7, %Pointer_lookup_element.exit.7, %loop_body_tail.6
  %lsr.iv.next = add i32 %lsr.iv, 8
  %459 = add i32 %410, 1
  %exitcond.not.7 = icmp eq i32 %459, %4
  br i1 %exitcond.not.7, label %func_exit.loopexit, label %loop_body

func_exit.loopexit:                               ; preds = %loop_body_tail.7
  br label %func_exit

func_exit:                                        ; preds = %func_exit.loopexit, %loop_body.prol.loopexit, %allocs
  ret void

struct_for_body_body:                             ; preds = %loop_body
  %460 = and i32 %87, 127
  %461 = load i32, ptr %5, align 4
  %462 = shl i32 %461, 7
  %463 = or i32 %462, %460
  %464 = load ptr, ptr %0, align 8
  %465 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %464, i64 0, i32 3, i32 1
  %466 = load ptr, ptr %465, align 8
  %467 = sext i32 %463 to i64
  %468 = getelementptr i32, ptr %466, i64 %467
  store i32 1, ptr %468, align 4
  %469 = load ptr, ptr %0, align 8
  %470 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %469, i64 0, i32 4, i32 1
  %471 = load ptr, ptr %470, align 8
  %472 = getelementptr i64, ptr %471, i64 8
  %473 = atomicrmw add ptr %472, i64 1 seq_cst, align 8
  %474 = load ptr, ptr %7, align 8
  %475 = getelementptr inbounds %struct.LLVMRuntime, ptr %474, i64 0, i32 7
  %476 = load ptr, ptr %475, align 8
  %477 = getelementptr inbounds ptr, ptr %476, i64 5
  %478 = load ptr, ptr %477, align 8
  %479 = lshr i32 %463, 2
  %480 = and i32 %479, 1073741816
  %481 = zext i32 %480 to i64
  %482 = getelementptr i8, ptr %478, i64 %481
  %483 = getelementptr inbounds i8, ptr %482, i64 32
  %484 = load ptr, ptr %483, align 8
  %485 = icmp eq ptr %484, null
  br i1 %485, label %486, label %Pointer_lookup_element.exit

486:                                              ; preds = %struct_for_body_body
  %487 = getelementptr inbounds %struct.LLVMRuntime, ptr %474, i64 0, i32 15
  %488 = load ptr, ptr %487, align 8
  %489 = getelementptr inbounds ptr, ptr %488, i64 54
  %490 = load ptr, ptr %489, align 8
  br label %Pointer_lookup_element.exit

Pointer_lookup_element.exit:                      ; preds = %486, %struct_for_body_body
  %.0.i = phi ptr [ %490, %486 ], [ %484, %struct_for_body_body ]
  %491 = getelementptr inbounds i8, ptr %.0.i, i64 32
  %492 = lshr i32 %87, 3
  %493 = and i32 %492, 3
  %494 = zext i32 %493 to i64
  %495 = getelementptr inbounds i8, ptr %491, i64 %494
  %496 = load i8, ptr %495, align 1
  %497 = zext i8 %496 to i32
  %498 = and i32 %79, %497
  %.not43 = icmp eq i32 %498, 0
  br i1 %.not43, label %loop_body_tail, label %true_block

true_block:                                       ; preds = %Pointer_lookup_element.exit
  %499 = load ptr, ptr %470, align 8
  %500 = getelementptr i64, ptr %499, i64 1
  %501 = atomicrmw add ptr %500, i64 1 seq_cst, align 8
  br label %loop_body_tail
}

; Function Attrs: nofree norecurse nosync nounwind
define void @geometry_collect_35_selection_55_kernel_5_serial(ptr nocapture readonly %context) local_unnamed_addr #4 {
entry:
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.1, %entry
  %indvars.iv = phi i64 [ 0, %entry ], [ %indvars.iv.next.1, %after_if.1 ]
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %0, i64 0, i32 3, i32 1
  %2 = load ptr, ptr %1, align 8
  %3 = shl nuw nsw i64 %indvars.iv, 2
  %uglygep36 = getelementptr i8, ptr %2, i64 %3
  %4 = load i32, ptr %uglygep36, align 4
  %.not = icmp eq i32 %4, 0
  br i1 %.not, label %after_if, label %true_block

after_for:                                        ; preds = %after_if.1
  ret void

true_block:                                       ; preds = %for_loop_body
  %5 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %0, i64 0, i32 4, i32 1
  %6 = load ptr, ptr %5, align 8
  %7 = load i64, ptr %6, align 8
  %sext = shl i64 %7, 32
  %8 = ashr exact i64 %sext, 32
  %9 = getelementptr i32, ptr %2, i64 %8
  %tmp28 = trunc i64 %indvars.iv to i32
  store i32 %tmp28, ptr %9, align 4
  %10 = add i64 %7, 1
  store i64 %10, ptr %6, align 8
  %11 = load ptr, ptr %context, align 8
  %12 = getelementptr { { i32, i32 }, ptr }, ptr %11, i64 0, i32 1
  %13 = load ptr, ptr %12, align 8
  %14 = getelementptr { { i32, i32 }, ptr }, ptr %11, i64 0, i32 0, i32 1
  %15 = shl nuw nsw i64 %indvars.iv, 3
  %uglygep35 = getelementptr i8, ptr %13, i64 %15
  %16 = load i64, ptr %uglygep35, align 8
  %17 = and i64 %16, 9223372036854775807
  %18 = and i64 %16, 9218868437227405312
  %19 = icmp eq i64 %17, 0
  %20 = icmp ne i64 %18, 0
  %21 = icmp ne i64 %18, 9218868437227405312
  %22 = and i1 %20, %21
  %23 = or i1 %19, %22
  br i1 %23, label %after_if3, label %true_block1

after_if:                                         ; preds = %true_block16, %after_if15, %for_loop_body
  %24 = load ptr, ptr %context, align 8
  %25 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %24, i64 0, i32 3, i32 1
  %26 = load ptr, ptr %25, align 8
  %uglygep = getelementptr i8, ptr %26, i64 4
  %uglygep16 = getelementptr i8, ptr %uglygep, i64 %3
  %27 = load i32, ptr %uglygep16, align 4
  %.not.1 = icmp eq i32 %27, 0
  br i1 %.not.1, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %28 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %24, i64 0, i32 4, i32 1
  %29 = load ptr, ptr %28, align 8
  %30 = load i64, ptr %29, align 8
  %sext.1 = shl i64 %30, 32
  %31 = ashr exact i64 %sext.1, 32
  %32 = getelementptr i32, ptr %26, i64 %31
  %33 = add nuw nsw i64 %indvars.iv, 1
  %tmp = trunc i64 %33 to i32
  store i32 %tmp, ptr %32, align 4
  %34 = add i64 %30, 1
  store i64 %34, ptr %29, align 8
  %35 = load ptr, ptr %context, align 8
  %36 = getelementptr { { i32, i32 }, ptr }, ptr %35, i64 0, i32 1
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr { { i32, i32 }, ptr }, ptr %35, i64 0, i32 0, i32 1
  %uglygep17 = getelementptr i8, ptr %37, i64 8
  %39 = shl nuw nsw i64 %indvars.iv, 3
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %39
  %40 = load i64, ptr %uglygep18, align 8
  %41 = and i64 %40, 9223372036854775807
  %42 = and i64 %40, 9218868437227405312
  %43 = icmp eq i64 %41, 0
  %44 = icmp ne i64 %42, 0
  %45 = icmp ne i64 %42, 9218868437227405312
  %46 = and i1 %44, %45
  %47 = or i1 %43, %46
  br i1 %47, label %after_if3.1, label %true_block1.1

true_block1.1:                                    ; preds = %true_block.1
  %48 = load ptr, ptr %28, align 8
  %49 = getelementptr i64, ptr %48, i64 5
  %50 = load i64, ptr %49, align 8
  %51 = or i64 %50, 1
  store i64 %51, ptr %49, align 8
  %.pre.1 = load ptr, ptr %36, align 8
  br label %after_if3.1

after_if3.1:                                      ; preds = %true_block1.1, %true_block.1
  %52 = phi ptr [ %37, %true_block.1 ], [ %.pre.1, %true_block1.1 ]
  %53 = load i32, ptr %38, align 4
  %54 = sext i32 %53 to i64
  %55 = add i64 %indvars.iv, %54
  %56 = getelementptr double, ptr %52, i64 %55
  %57 = getelementptr double, ptr %56, i64 1
  %58 = load i64, ptr %57, align 8
  %59 = and i64 %58, 9223372036854775807
  %60 = and i64 %58, 9218868437227405312
  %61 = icmp eq i64 %59, 0
  %62 = icmp ne i64 %60, 0
  %63 = icmp ne i64 %60, 9218868437227405312
  %64 = and i1 %62, %63
  %65 = or i1 %61, %64
  br i1 %65, label %after_if6.1, label %true_block4.1

true_block4.1:                                    ; preds = %after_if3.1
  %66 = load ptr, ptr %28, align 8
  %67 = getelementptr i64, ptr %66, i64 5
  %68 = load i64, ptr %67, align 8
  %69 = or i64 %68, 1
  store i64 %69, ptr %67, align 8
  %.pre5.1 = load ptr, ptr %36, align 8
  %.pre6.1 = load i32, ptr %38, align 4
  %.pre11.1 = sext i32 %.pre6.1 to i64
  br label %after_if6.1

after_if6.1:                                      ; preds = %true_block4.1, %after_if3.1
  %.pre-phi.1 = phi i64 [ %54, %after_if3.1 ], [ %.pre11.1, %true_block4.1 ]
  %70 = phi ptr [ %52, %after_if3.1 ], [ %.pre5.1, %true_block4.1 ]
  %71 = shl nsw i64 %.pre-phi.1, 4
  %uglygep19 = getelementptr i8, ptr %70, i64 %71
  %uglygep20 = getelementptr i8, ptr %uglygep19, i64 %39
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 8
  %72 = load i64, ptr %uglygep21, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if9.1, label %true_block7.1

true_block7.1:                                    ; preds = %after_if6.1
  %80 = load ptr, ptr %28, align 8
  %81 = getelementptr i64, ptr %80, i64 5
  %82 = load i64, ptr %81, align 8
  %83 = or i64 %82, 1
  store i64 %83, ptr %81, align 8
  %.pre7.1 = load ptr, ptr %36, align 8
  %.pre8.1 = load i32, ptr %38, align 4
  %.pre12.1 = sext i32 %.pre8.1 to i64
  br label %after_if9.1

after_if9.1:                                      ; preds = %true_block7.1, %after_if6.1
  %.pre-phi13.1 = phi i64 [ %.pre-phi.1, %after_if6.1 ], [ %.pre12.1, %true_block7.1 ]
  %84 = phi ptr [ %70, %after_if6.1 ], [ %.pre7.1, %true_block7.1 ]
  %85 = mul nsw i64 %.pre-phi13.1, 48
  %uglygep22 = getelementptr i8, ptr %84, i64 %85
  %uglygep23 = getelementptr i8, ptr %uglygep22, i64 %39
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 8
  %86 = load double, ptr %uglygep24, align 8
  %87 = bitcast double %86 to i64
  %88 = and i64 %87, 9223372036854775807
  %89 = and i64 %87, 9218868437227405312
  %90 = icmp eq i64 %88, 0
  %91 = icmp ne i64 %89, 0
  %92 = icmp ne i64 %89, 9218868437227405312
  %93 = and i1 %91, %92
  %94 = or i1 %90, %93
  br i1 %94, label %after_if12.1, label %true_block10.1

true_block10.1:                                   ; preds = %after_if9.1
  %95 = load ptr, ptr %28, align 8
  %96 = getelementptr i64, ptr %95, i64 5
  %97 = load i64, ptr %96, align 8
  %98 = or i64 %97, 1
  store i64 %98, ptr %96, align 8
  %.pre9.1 = load ptr, ptr %36, align 8
  %.pre10.1 = load i32, ptr %38, align 4
  %.pre14.1 = sext i32 %.pre10.1 to i64
  br label %after_if12.1

after_if12.1:                                     ; preds = %true_block10.1, %after_if9.1
  %.pre-phi15.1 = phi i64 [ %.pre-phi13.1, %after_if9.1 ], [ %.pre14.1, %true_block10.1 ]
  %99 = phi ptr [ %84, %after_if9.1 ], [ %.pre9.1, %true_block10.1 ]
  %100 = mul nsw i64 %.pre-phi15.1, 56
  %uglygep25 = getelementptr i8, ptr %99, i64 %100
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %39
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %101 = load double, ptr %uglygep27, align 8
  %102 = bitcast double %101 to i64
  %103 = and i64 %102, 9223372036854775807
  %104 = and i64 %102, 9218868437227405312
  %105 = icmp eq i64 %103, 0
  %106 = icmp ne i64 %104, 0
  %107 = icmp ne i64 %104, 9218868437227405312
  %108 = and i1 %106, %107
  %109 = or i1 %105, %108
  br i1 %109, label %after_if15.1, label %true_block13.1

true_block13.1:                                   ; preds = %after_if12.1
  %110 = load ptr, ptr %28, align 8
  %111 = getelementptr i64, ptr %110, i64 5
  %112 = load i64, ptr %111, align 8
  %113 = or i64 %112, 1
  store i64 %113, ptr %111, align 8
  br label %after_if15.1

after_if15.1:                                     ; preds = %true_block13.1, %after_if12.1
  %114 = fcmp ole double %86, 0.000000e+00
  %115 = fcmp olt double %101, 0.000000e+00
  %116 = or i1 %114, %115
  br i1 %116, label %true_block16.1, label %after_if.1

true_block16.1:                                   ; preds = %after_if15.1
  %117 = load ptr, ptr %28, align 8
  %118 = getelementptr i64, ptr %117, i64 5
  %119 = load i64, ptr %118, align 8
  %120 = or i64 %119, 1
  store i64 %120, ptr %118, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block16.1, %after_if15.1, %after_if
  %indvars.iv.next.1 = add nuw nsw i64 %indvars.iv, 2
  %exitcond.not.1 = icmp eq i64 %indvars.iv.next.1, 70
  br i1 %exitcond.not.1, label %after_for, label %for_loop_body

true_block1:                                      ; preds = %true_block
  %121 = load ptr, ptr %5, align 8
  %122 = getelementptr i64, ptr %121, i64 5
  %123 = load i64, ptr %122, align 8
  %124 = or i64 %123, 1
  store i64 %124, ptr %122, align 8
  %.pre = load ptr, ptr %12, align 8
  br label %after_if3

after_if3:                                        ; preds = %true_block1, %true_block
  %125 = phi ptr [ %13, %true_block ], [ %.pre, %true_block1 ]
  %126 = load i32, ptr %14, align 4
  %127 = sext i32 %126 to i64
  %128 = add nsw i64 %indvars.iv, %127
  %129 = getelementptr double, ptr %125, i64 %128
  %130 = load i64, ptr %129, align 8
  %131 = and i64 %130, 9223372036854775807
  %132 = and i64 %130, 9218868437227405312
  %133 = icmp eq i64 %131, 0
  %134 = icmp ne i64 %132, 0
  %135 = icmp ne i64 %132, 9218868437227405312
  %136 = and i1 %134, %135
  %137 = or i1 %133, %136
  br i1 %137, label %after_if6, label %true_block4

true_block4:                                      ; preds = %after_if3
  %138 = load ptr, ptr %5, align 8
  %139 = getelementptr i64, ptr %138, i64 5
  %140 = load i64, ptr %139, align 8
  %141 = or i64 %140, 1
  store i64 %141, ptr %139, align 8
  %.pre5 = load ptr, ptr %12, align 8
  %.pre6 = load i32, ptr %14, align 4
  %.pre11 = sext i32 %.pre6 to i64
  br label %after_if6

after_if6:                                        ; preds = %true_block4, %after_if3
  %.pre-phi = phi i64 [ %127, %after_if3 ], [ %.pre11, %true_block4 ]
  %142 = phi ptr [ %125, %after_if3 ], [ %.pre5, %true_block4 ]
  %143 = shl nsw i64 %.pre-phi, 4
  %uglygep33 = getelementptr i8, ptr %142, i64 %143
  %uglygep34 = getelementptr i8, ptr %uglygep33, i64 %15
  %144 = load i64, ptr %uglygep34, align 8
  %145 = and i64 %144, 9223372036854775807
  %146 = and i64 %144, 9218868437227405312
  %147 = icmp eq i64 %145, 0
  %148 = icmp ne i64 %146, 0
  %149 = icmp ne i64 %146, 9218868437227405312
  %150 = and i1 %148, %149
  %151 = or i1 %147, %150
  br i1 %151, label %after_if9, label %true_block7

true_block7:                                      ; preds = %after_if6
  %152 = load ptr, ptr %5, align 8
  %153 = getelementptr i64, ptr %152, i64 5
  %154 = load i64, ptr %153, align 8
  %155 = or i64 %154, 1
  store i64 %155, ptr %153, align 8
  %.pre7 = load ptr, ptr %12, align 8
  %.pre8 = load i32, ptr %14, align 4
  %.pre12 = sext i32 %.pre8 to i64
  br label %after_if9

after_if9:                                        ; preds = %true_block7, %after_if6
  %.pre-phi13 = phi i64 [ %.pre-phi, %after_if6 ], [ %.pre12, %true_block7 ]
  %156 = phi ptr [ %142, %after_if6 ], [ %.pre7, %true_block7 ]
  %157 = mul nsw i64 %.pre-phi13, 48
  %uglygep31 = getelementptr i8, ptr %156, i64 %157
  %uglygep32 = getelementptr i8, ptr %uglygep31, i64 %15
  %158 = load double, ptr %uglygep32, align 8
  %159 = bitcast double %158 to i64
  %160 = and i64 %159, 9223372036854775807
  %161 = and i64 %159, 9218868437227405312
  %162 = icmp eq i64 %160, 0
  %163 = icmp ne i64 %161, 0
  %164 = icmp ne i64 %161, 9218868437227405312
  %165 = and i1 %163, %164
  %166 = or i1 %162, %165
  br i1 %166, label %after_if12, label %true_block10

true_block10:                                     ; preds = %after_if9
  %167 = load ptr, ptr %5, align 8
  %168 = getelementptr i64, ptr %167, i64 5
  %169 = load i64, ptr %168, align 8
  %170 = or i64 %169, 1
  store i64 %170, ptr %168, align 8
  %.pre9 = load ptr, ptr %12, align 8
  %.pre10 = load i32, ptr %14, align 4
  %.pre14 = sext i32 %.pre10 to i64
  br label %after_if12

after_if12:                                       ; preds = %true_block10, %after_if9
  %.pre-phi15 = phi i64 [ %.pre-phi13, %after_if9 ], [ %.pre14, %true_block10 ]
  %171 = phi ptr [ %156, %after_if9 ], [ %.pre9, %true_block10 ]
  %172 = mul nsw i64 %.pre-phi15, 56
  %uglygep29 = getelementptr i8, ptr %171, i64 %172
  %uglygep30 = getelementptr i8, ptr %uglygep29, i64 %15
  %173 = load double, ptr %uglygep30, align 8
  %174 = bitcast double %173 to i64
  %175 = and i64 %174, 9223372036854775807
  %176 = and i64 %174, 9218868437227405312
  %177 = icmp eq i64 %175, 0
  %178 = icmp ne i64 %176, 0
  %179 = icmp ne i64 %176, 9218868437227405312
  %180 = and i1 %178, %179
  %181 = or i1 %177, %180
  br i1 %181, label %after_if15, label %true_block13

true_block13:                                     ; preds = %after_if12
  %182 = load ptr, ptr %5, align 8
  %183 = getelementptr i64, ptr %182, i64 5
  %184 = load i64, ptr %183, align 8
  %185 = or i64 %184, 1
  store i64 %185, ptr %183, align 8
  br label %after_if15

after_if15:                                       ; preds = %true_block13, %after_if12
  %186 = fcmp ole double %158, 0.000000e+00
  %187 = fcmp olt double %173, 0.000000e+00
  %188 = or i1 %186, %187
  br i1 %188, label %true_block16, label %after_if

true_block16:                                     ; preds = %after_if15
  %189 = load ptr, ptr %5, align 8
  %190 = getelementptr i64, ptr %189, i64 5
  %191 = load i64, ptr %190, align 8
  %192 = or i64 %191, 1
  store i64 %192, ptr %190, align 8
  br label %after_if
}

; Function Attrs: nounwind
define void @geometry_collect_35_selection_55_kernel_6_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.2, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.2230, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.2(ptr %0, ptr nocapture readnone %1, i32 %2) #5 {
allocs:
  %3 = getelementptr inbounds %struct.RuntimeContext.2230, ptr %0, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  %7 = load i32, ptr %6, align 4
  %8 = tail call i32 @llvm.smax.i32(i32 %7, i32 512)
  %9 = mul i32 %8, %2
  %10 = add i32 %9, %8
  %11 = tail call i32 @llvm.smin.i32(i32 %7, i32 %10)
  %12 = icmp slt i32 %9, %11
  br i1 %12, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %13 = load ptr, ptr %0, align 8
  %14 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %13, i64 0, i32 2, i32 1
  %15 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %13, i64 0, i32 2, i32 0, i32 1
  %16 = sext i32 %9 to i64
  %wide.trip.count = sext i32 %11 to i64
  %17 = sub nsw i64 %wide.trip.count, %16
  %18 = xor i64 %16, -1
  %19 = add nsw i64 %18, %wide.trip.count
  %xtraiter = and i64 %17, 7
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  %20 = shl i64 %xtraiter, 2
  %21 = add nsw i64 %20, -4
  %22 = lshr i64 %21, 2
  %23 = add i64 %22, %16
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv38 = phi i64 [ %20, %for_loop_body.prol.preheader ], [ %lsr.iv.next39, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %16, %for_loop_body.prol.preheader ]
  %24 = load ptr, ptr %14, align 8
  %25 = load i32, ptr %15, align 4
  %26 = sext i32 %25 to i64
  %27 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep37 = getelementptr i8, ptr %24, i64 %27
  %28 = load i32, ptr %uglygep37, align 4
  %29 = add nsw i64 %indvars.iv.prol, %26
  %30 = getelementptr i32, ptr %24, i64 %29
  %31 = load i32, ptr %30, align 4
  %32 = icmp ult i32 %28, 70
  %33 = icmp ult i32 %31, 70
  %34 = and i1 %32, %33
  br i1 %34, label %true_block.prol, label %after_if.sink.split.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %35 = icmp ne i32 %28, %31
  %36 = load ptr, ptr %3, align 8
  %37 = getelementptr inbounds %struct.LLVMRuntime, ptr %36, i64 0, i32 7
  %38 = load ptr, ptr %37, align 8
  %39 = load ptr, ptr %38, align 8
  %40 = getelementptr %1, ptr %39, i64 0, i32 2, i32 1, i64 127
  %41 = lshr i32 %28, 3
  %42 = zext i32 %41 to i64
  %43 = getelementptr inbounds i8, ptr %40, i64 %42
  %44 = load i8, ptr %43, align 1
  %45 = zext i8 %44 to i32
  %46 = and i32 %28, 7
  %47 = shl nuw nsw i32 1, %46
  %48 = and i32 %47, %45
  %49 = icmp ne i32 %48, 0
  %50 = lshr i32 %31, 3
  %51 = zext i32 %50 to i64
  %52 = getelementptr inbounds i8, ptr %40, i64 %51
  %53 = load i8, ptr %52, align 1
  %54 = zext i8 %53 to i32
  %55 = and i32 %31, 7
  %56 = shl nuw nsw i32 1, %55
  %57 = and i32 %56, %54
  %58 = icmp ne i32 %57, 0
  %59 = and i1 %49, %58
  %60 = and i1 %35, %59
  br i1 %60, label %after_if.prol, label %after_if.sink.split.prol

after_if.sink.split.prol:                         ; preds = %true_block.prol, %for_loop_body.prol
  %61 = load ptr, ptr %0, align 8
  %62 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %61, i64 0, i32 4, i32 1
  %63 = load ptr, ptr %62, align 8
  %64 = getelementptr i64, ptr %63, i64 5
  %65 = atomicrmw or ptr %64, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %after_if.sink.split.prol, %true_block.prol
  %indvars.iv.next.prol = add nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next39 = add nsw i64 %lsr.iv38, -4
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next39, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !11

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %66 = add i64 %23, 1
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %16, %for_loop_body.lr.ph ], [ %66, %for_loop_body.prol.loopexit.loopexit ]
  %67 = icmp ult i64 %19, 7
  br i1 %67, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  %68 = sub i64 0, %wide.trip.count
  %69 = add nsw i64 %indvars.iv.unr, 7
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %lsr.iv = phi i64 [ %69, %for_loop_body.preheader ], [ %lsr.iv.next, %after_if.7 ]
  %70 = load ptr, ptr %14, align 8
  %71 = load i32, ptr %15, align 4
  %72 = sext i32 %71 to i64
  %73 = shl i64 %lsr.iv, 2
  %uglygep33 = getelementptr i8, ptr %70, i64 %73
  %uglygep34 = getelementptr i8, ptr %uglygep33, i64 -28
  %74 = load i32, ptr %uglygep34, align 4
  %75 = add i64 %lsr.iv, %72
  %76 = getelementptr i32, ptr %70, i64 %75
  %77 = getelementptr i32, ptr %76, i64 -7
  %78 = load i32, ptr %77, align 4
  %79 = icmp ult i32 %74, 70
  %80 = icmp ult i32 %78, 70
  %81 = and i1 %79, %80
  br i1 %81, label %true_block, label %after_if.sink.split

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %82 = icmp ne i32 %74, %78
  %83 = load ptr, ptr %3, align 8
  %84 = getelementptr inbounds %struct.LLVMRuntime, ptr %83, i64 0, i32 7
  %85 = load ptr, ptr %84, align 8
  %86 = load ptr, ptr %85, align 8
  %87 = getelementptr %1, ptr %86, i64 0, i32 2, i32 1, i64 127
  %88 = lshr i32 %74, 3
  %89 = zext i32 %88 to i64
  %90 = getelementptr inbounds i8, ptr %87, i64 %89
  %91 = load i8, ptr %90, align 1
  %92 = zext i8 %91 to i32
  %93 = and i32 %74, 7
  %94 = shl nuw nsw i32 1, %93
  %95 = and i32 %94, %92
  %96 = icmp ne i32 %95, 0
  %97 = lshr i32 %78, 3
  %98 = zext i32 %97 to i64
  %99 = getelementptr inbounds i8, ptr %87, i64 %98
  %100 = load i8, ptr %99, align 1
  %101 = zext i8 %100 to i32
  %102 = and i32 %78, 7
  %103 = shl nuw nsw i32 1, %102
  %104 = and i32 %103, %101
  %105 = icmp ne i32 %104, 0
  %106 = and i1 %96, %105
  %107 = and i1 %82, %106
  br i1 %107, label %after_if, label %after_if.sink.split

after_if.sink.split:                              ; preds = %true_block, %for_loop_body
  %108 = load ptr, ptr %0, align 8
  %109 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %108, i64 0, i32 4, i32 1
  %110 = load ptr, ptr %109, align 8
  %111 = getelementptr i64, ptr %110, i64 5
  %112 = atomicrmw or ptr %111, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %after_if.sink.split, %true_block
  %113 = load ptr, ptr %14, align 8
  %114 = load i32, ptr %15, align 4
  %115 = sext i32 %114 to i64
  %uglygep35 = getelementptr i8, ptr %113, i64 %73
  %uglygep36 = getelementptr i8, ptr %uglygep35, i64 -24
  %116 = load i32, ptr %uglygep36, align 4
  %117 = add i64 %lsr.iv, %115
  %118 = getelementptr i32, ptr %113, i64 %117
  %119 = getelementptr i32, ptr %118, i64 -6
  %120 = load i32, ptr %119, align 4
  %121 = icmp ult i32 %116, 70
  %122 = icmp ult i32 %120, 70
  %123 = and i1 %121, %122
  br i1 %123, label %true_block.1, label %after_if.sink.split.1

true_block.1:                                     ; preds = %after_if
  %124 = icmp ne i32 %116, %120
  %125 = load ptr, ptr %3, align 8
  %126 = getelementptr inbounds %struct.LLVMRuntime, ptr %125, i64 0, i32 7
  %127 = load ptr, ptr %126, align 8
  %128 = load ptr, ptr %127, align 8
  %129 = getelementptr %1, ptr %128, i64 0, i32 2, i32 1, i64 127
  %130 = lshr i32 %116, 3
  %131 = zext i32 %130 to i64
  %132 = getelementptr inbounds i8, ptr %129, i64 %131
  %133 = load i8, ptr %132, align 1
  %134 = zext i8 %133 to i32
  %135 = and i32 %116, 7
  %136 = shl nuw nsw i32 1, %135
  %137 = and i32 %136, %134
  %138 = icmp ne i32 %137, 0
  %139 = lshr i32 %120, 3
  %140 = zext i32 %139 to i64
  %141 = getelementptr inbounds i8, ptr %129, i64 %140
  %142 = load i8, ptr %141, align 1
  %143 = zext i8 %142 to i32
  %144 = and i32 %120, 7
  %145 = shl nuw nsw i32 1, %144
  %146 = and i32 %145, %143
  %147 = icmp ne i32 %146, 0
  %148 = and i1 %138, %147
  %149 = and i1 %124, %148
  br i1 %149, label %after_if.1, label %after_if.sink.split.1

after_if.sink.split.1:                            ; preds = %true_block.1, %after_if
  %150 = load ptr, ptr %0, align 8
  %151 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %150, i64 0, i32 4, i32 1
  %152 = load ptr, ptr %151, align 8
  %153 = getelementptr i64, ptr %152, i64 5
  %154 = atomicrmw or ptr %153, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %after_if.sink.split.1, %true_block.1
  %155 = load ptr, ptr %14, align 8
  %156 = load i32, ptr %15, align 4
  %157 = sext i32 %156 to i64
  %uglygep31 = getelementptr i8, ptr %155, i64 %73
  %uglygep32 = getelementptr i8, ptr %uglygep31, i64 -20
  %158 = load i32, ptr %uglygep32, align 4
  %159 = add i64 %lsr.iv, %157
  %160 = getelementptr i32, ptr %155, i64 %159
  %161 = getelementptr i32, ptr %160, i64 -5
  %162 = load i32, ptr %161, align 4
  %163 = icmp ult i32 %158, 70
  %164 = icmp ult i32 %162, 70
  %165 = and i1 %163, %164
  br i1 %165, label %true_block.2, label %after_if.sink.split.2

true_block.2:                                     ; preds = %after_if.1
  %166 = icmp ne i32 %158, %162
  %167 = load ptr, ptr %3, align 8
  %168 = getelementptr inbounds %struct.LLVMRuntime, ptr %167, i64 0, i32 7
  %169 = load ptr, ptr %168, align 8
  %170 = load ptr, ptr %169, align 8
  %171 = getelementptr %1, ptr %170, i64 0, i32 2, i32 1, i64 127
  %172 = lshr i32 %158, 3
  %173 = zext i32 %172 to i64
  %174 = getelementptr inbounds i8, ptr %171, i64 %173
  %175 = load i8, ptr %174, align 1
  %176 = zext i8 %175 to i32
  %177 = and i32 %158, 7
  %178 = shl nuw nsw i32 1, %177
  %179 = and i32 %178, %176
  %180 = icmp ne i32 %179, 0
  %181 = lshr i32 %162, 3
  %182 = zext i32 %181 to i64
  %183 = getelementptr inbounds i8, ptr %171, i64 %182
  %184 = load i8, ptr %183, align 1
  %185 = zext i8 %184 to i32
  %186 = and i32 %162, 7
  %187 = shl nuw nsw i32 1, %186
  %188 = and i32 %187, %185
  %189 = icmp ne i32 %188, 0
  %190 = and i1 %180, %189
  %191 = and i1 %166, %190
  br i1 %191, label %after_if.2, label %after_if.sink.split.2

after_if.sink.split.2:                            ; preds = %true_block.2, %after_if.1
  %192 = load ptr, ptr %0, align 8
  %193 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %192, i64 0, i32 4, i32 1
  %194 = load ptr, ptr %193, align 8
  %195 = getelementptr i64, ptr %194, i64 5
  %196 = atomicrmw or ptr %195, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %after_if.sink.split.2, %true_block.2
  %197 = load ptr, ptr %14, align 8
  %198 = load i32, ptr %15, align 4
  %199 = sext i32 %198 to i64
  %uglygep29 = getelementptr i8, ptr %197, i64 %73
  %uglygep30 = getelementptr i8, ptr %uglygep29, i64 -16
  %200 = load i32, ptr %uglygep30, align 4
  %201 = add i64 %lsr.iv, %199
  %202 = getelementptr i32, ptr %197, i64 %201
  %203 = getelementptr i32, ptr %202, i64 -4
  %204 = load i32, ptr %203, align 4
  %205 = icmp ult i32 %200, 70
  %206 = icmp ult i32 %204, 70
  %207 = and i1 %205, %206
  br i1 %207, label %true_block.3, label %after_if.sink.split.3

true_block.3:                                     ; preds = %after_if.2
  %208 = icmp ne i32 %200, %204
  %209 = load ptr, ptr %3, align 8
  %210 = getelementptr inbounds %struct.LLVMRuntime, ptr %209, i64 0, i32 7
  %211 = load ptr, ptr %210, align 8
  %212 = load ptr, ptr %211, align 8
  %213 = getelementptr %1, ptr %212, i64 0, i32 2, i32 1, i64 127
  %214 = lshr i32 %200, 3
  %215 = zext i32 %214 to i64
  %216 = getelementptr inbounds i8, ptr %213, i64 %215
  %217 = load i8, ptr %216, align 1
  %218 = zext i8 %217 to i32
  %219 = and i32 %200, 7
  %220 = shl nuw nsw i32 1, %219
  %221 = and i32 %220, %218
  %222 = icmp ne i32 %221, 0
  %223 = lshr i32 %204, 3
  %224 = zext i32 %223 to i64
  %225 = getelementptr inbounds i8, ptr %213, i64 %224
  %226 = load i8, ptr %225, align 1
  %227 = zext i8 %226 to i32
  %228 = and i32 %204, 7
  %229 = shl nuw nsw i32 1, %228
  %230 = and i32 %229, %227
  %231 = icmp ne i32 %230, 0
  %232 = and i1 %222, %231
  %233 = and i1 %208, %232
  br i1 %233, label %after_if.3, label %after_if.sink.split.3

after_if.sink.split.3:                            ; preds = %true_block.3, %after_if.2
  %234 = load ptr, ptr %0, align 8
  %235 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %234, i64 0, i32 4, i32 1
  %236 = load ptr, ptr %235, align 8
  %237 = getelementptr i64, ptr %236, i64 5
  %238 = atomicrmw or ptr %237, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %after_if.sink.split.3, %true_block.3
  %239 = load ptr, ptr %14, align 8
  %240 = load i32, ptr %15, align 4
  %241 = sext i32 %240 to i64
  %uglygep27 = getelementptr i8, ptr %239, i64 %73
  %uglygep28 = getelementptr i8, ptr %uglygep27, i64 -12
  %242 = load i32, ptr %uglygep28, align 4
  %243 = add i64 %lsr.iv, %241
  %244 = getelementptr i32, ptr %239, i64 %243
  %245 = getelementptr i32, ptr %244, i64 -3
  %246 = load i32, ptr %245, align 4
  %247 = icmp ult i32 %242, 70
  %248 = icmp ult i32 %246, 70
  %249 = and i1 %247, %248
  br i1 %249, label %true_block.4, label %after_if.sink.split.4

true_block.4:                                     ; preds = %after_if.3
  %250 = icmp ne i32 %242, %246
  %251 = load ptr, ptr %3, align 8
  %252 = getelementptr inbounds %struct.LLVMRuntime, ptr %251, i64 0, i32 7
  %253 = load ptr, ptr %252, align 8
  %254 = load ptr, ptr %253, align 8
  %255 = getelementptr %1, ptr %254, i64 0, i32 2, i32 1, i64 127
  %256 = lshr i32 %242, 3
  %257 = zext i32 %256 to i64
  %258 = getelementptr inbounds i8, ptr %255, i64 %257
  %259 = load i8, ptr %258, align 1
  %260 = zext i8 %259 to i32
  %261 = and i32 %242, 7
  %262 = shl nuw nsw i32 1, %261
  %263 = and i32 %262, %260
  %264 = icmp ne i32 %263, 0
  %265 = lshr i32 %246, 3
  %266 = zext i32 %265 to i64
  %267 = getelementptr inbounds i8, ptr %255, i64 %266
  %268 = load i8, ptr %267, align 1
  %269 = zext i8 %268 to i32
  %270 = and i32 %246, 7
  %271 = shl nuw nsw i32 1, %270
  %272 = and i32 %271, %269
  %273 = icmp ne i32 %272, 0
  %274 = and i1 %264, %273
  %275 = and i1 %250, %274
  br i1 %275, label %after_if.4, label %after_if.sink.split.4

after_if.sink.split.4:                            ; preds = %true_block.4, %after_if.3
  %276 = load ptr, ptr %0, align 8
  %277 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %276, i64 0, i32 4, i32 1
  %278 = load ptr, ptr %277, align 8
  %279 = getelementptr i64, ptr %278, i64 5
  %280 = atomicrmw or ptr %279, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %after_if.sink.split.4, %true_block.4
  %281 = load ptr, ptr %14, align 8
  %282 = load i32, ptr %15, align 4
  %283 = sext i32 %282 to i64
  %uglygep25 = getelementptr i8, ptr %281, i64 %73
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 -8
  %284 = load i32, ptr %uglygep26, align 4
  %285 = add i64 %lsr.iv, %283
  %286 = getelementptr i32, ptr %281, i64 %285
  %287 = getelementptr i32, ptr %286, i64 -2
  %288 = load i32, ptr %287, align 4
  %289 = icmp ult i32 %284, 70
  %290 = icmp ult i32 %288, 70
  %291 = and i1 %289, %290
  br i1 %291, label %true_block.5, label %after_if.sink.split.5

true_block.5:                                     ; preds = %after_if.4
  %292 = icmp ne i32 %284, %288
  %293 = load ptr, ptr %3, align 8
  %294 = getelementptr inbounds %struct.LLVMRuntime, ptr %293, i64 0, i32 7
  %295 = load ptr, ptr %294, align 8
  %296 = load ptr, ptr %295, align 8
  %297 = getelementptr %1, ptr %296, i64 0, i32 2, i32 1, i64 127
  %298 = lshr i32 %284, 3
  %299 = zext i32 %298 to i64
  %300 = getelementptr inbounds i8, ptr %297, i64 %299
  %301 = load i8, ptr %300, align 1
  %302 = zext i8 %301 to i32
  %303 = and i32 %284, 7
  %304 = shl nuw nsw i32 1, %303
  %305 = and i32 %304, %302
  %306 = icmp ne i32 %305, 0
  %307 = lshr i32 %288, 3
  %308 = zext i32 %307 to i64
  %309 = getelementptr inbounds i8, ptr %297, i64 %308
  %310 = load i8, ptr %309, align 1
  %311 = zext i8 %310 to i32
  %312 = and i32 %288, 7
  %313 = shl nuw nsw i32 1, %312
  %314 = and i32 %313, %311
  %315 = icmp ne i32 %314, 0
  %316 = and i1 %306, %315
  %317 = and i1 %292, %316
  br i1 %317, label %after_if.5, label %after_if.sink.split.5

after_if.sink.split.5:                            ; preds = %true_block.5, %after_if.4
  %318 = load ptr, ptr %0, align 8
  %319 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %318, i64 0, i32 4, i32 1
  %320 = load ptr, ptr %319, align 8
  %321 = getelementptr i64, ptr %320, i64 5
  %322 = atomicrmw or ptr %321, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %after_if.sink.split.5, %true_block.5
  %323 = load ptr, ptr %14, align 8
  %324 = load i32, ptr %15, align 4
  %325 = sext i32 %324 to i64
  %uglygep23 = getelementptr i8, ptr %323, i64 %73
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 -4
  %326 = load i32, ptr %uglygep24, align 4
  %327 = add i64 %lsr.iv, %325
  %328 = getelementptr i32, ptr %323, i64 %327
  %329 = getelementptr i32, ptr %328, i64 -1
  %330 = load i32, ptr %329, align 4
  %331 = icmp ult i32 %326, 70
  %332 = icmp ult i32 %330, 70
  %333 = and i1 %331, %332
  br i1 %333, label %true_block.6, label %after_if.sink.split.6

true_block.6:                                     ; preds = %after_if.5
  %334 = icmp ne i32 %326, %330
  %335 = load ptr, ptr %3, align 8
  %336 = getelementptr inbounds %struct.LLVMRuntime, ptr %335, i64 0, i32 7
  %337 = load ptr, ptr %336, align 8
  %338 = load ptr, ptr %337, align 8
  %339 = getelementptr %1, ptr %338, i64 0, i32 2, i32 1, i64 127
  %340 = lshr i32 %326, 3
  %341 = zext i32 %340 to i64
  %342 = getelementptr inbounds i8, ptr %339, i64 %341
  %343 = load i8, ptr %342, align 1
  %344 = zext i8 %343 to i32
  %345 = and i32 %326, 7
  %346 = shl nuw nsw i32 1, %345
  %347 = and i32 %346, %344
  %348 = icmp ne i32 %347, 0
  %349 = lshr i32 %330, 3
  %350 = zext i32 %349 to i64
  %351 = getelementptr inbounds i8, ptr %339, i64 %350
  %352 = load i8, ptr %351, align 1
  %353 = zext i8 %352 to i32
  %354 = and i32 %330, 7
  %355 = shl nuw nsw i32 1, %354
  %356 = and i32 %355, %353
  %357 = icmp ne i32 %356, 0
  %358 = and i1 %348, %357
  %359 = and i1 %334, %358
  br i1 %359, label %after_if.6, label %after_if.sink.split.6

after_if.sink.split.6:                            ; preds = %true_block.6, %after_if.5
  %360 = load ptr, ptr %0, align 8
  %361 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %360, i64 0, i32 4, i32 1
  %362 = load ptr, ptr %361, align 8
  %363 = getelementptr i64, ptr %362, i64 5
  %364 = atomicrmw or ptr %363, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %after_if.sink.split.6, %true_block.6
  %365 = load ptr, ptr %14, align 8
  %366 = load i32, ptr %15, align 4
  %367 = sext i32 %366 to i64
  %uglygep = getelementptr i8, ptr %365, i64 %73
  %368 = load i32, ptr %uglygep, align 4
  %369 = add nsw i64 %lsr.iv, %367
  %370 = getelementptr i32, ptr %365, i64 %369
  %371 = load i32, ptr %370, align 4
  %372 = icmp ult i32 %368, 70
  %373 = icmp ult i32 %371, 70
  %374 = and i1 %372, %373
  br i1 %374, label %true_block.7, label %after_if.sink.split.7

true_block.7:                                     ; preds = %after_if.6
  %375 = icmp ne i32 %368, %371
  %376 = load ptr, ptr %3, align 8
  %377 = getelementptr inbounds %struct.LLVMRuntime, ptr %376, i64 0, i32 7
  %378 = load ptr, ptr %377, align 8
  %379 = load ptr, ptr %378, align 8
  %380 = getelementptr %1, ptr %379, i64 0, i32 2, i32 1, i64 127
  %381 = lshr i32 %368, 3
  %382 = zext i32 %381 to i64
  %383 = getelementptr inbounds i8, ptr %380, i64 %382
  %384 = load i8, ptr %383, align 1
  %385 = zext i8 %384 to i32
  %386 = and i32 %368, 7
  %387 = shl nuw nsw i32 1, %386
  %388 = and i32 %387, %385
  %389 = icmp ne i32 %388, 0
  %390 = lshr i32 %371, 3
  %391 = zext i32 %390 to i64
  %392 = getelementptr inbounds i8, ptr %380, i64 %391
  %393 = load i8, ptr %392, align 1
  %394 = zext i8 %393 to i32
  %395 = and i32 %371, 7
  %396 = shl nuw nsw i32 1, %395
  %397 = and i32 %396, %394
  %398 = icmp ne i32 %397, 0
  %399 = and i1 %389, %398
  %400 = and i1 %375, %399
  br i1 %400, label %after_if.7, label %after_if.sink.split.7

after_if.sink.split.7:                            ; preds = %true_block.7, %after_if.6
  %401 = load ptr, ptr %0, align 8
  %402 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %401, i64 0, i32 4, i32 1
  %403 = load ptr, ptr %402, align 8
  %404 = getelementptr i64, ptr %403, i64 5
  %405 = atomicrmw or ptr %404, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %after_if.sink.split.7, %true_block.7
  %lsr.iv.next = add i64 %lsr.iv, 8
  %406 = add i64 %68, %lsr.iv.next
  %exitcond.not.7 = icmp eq i64 %406, 7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nofree norecurse nosync nounwind
define void @geometry_collect_35_selection_55_kernel_7_serial(ptr %context) local_unnamed_addr #4 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.2230, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 16
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 4
  %5 = load i32, ptr %4, align 4
  %6 = icmp sgt i32 %5, 0
  %7 = load ptr, ptr %context, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %7, i64 0, i32 4, i32 1
  %9 = load ptr, ptr %8, align 8
  %10 = load i64, ptr %9, align 8
  %11 = icmp ne i64 %10, 0
  %12 = zext i1 %11 to i64
  %13 = select i1 %6, i64 2, i64 %12
  %14 = getelementptr i64, ptr %9, i64 6
  store i64 %13, ptr %14, align 8
  br i1 %6, label %for_loop_body.preheader, label %after_for

for_loop_body.preheader:                          ; preds = %entry
  %wide.trip.count = zext i32 %5 to i64
  %15 = add nsw i64 %wide.trip.count, -1
  %xtraiter = and i64 %wide.trip.count, 3
  %16 = icmp ult i64 %15, 3
  br i1 %16, label %after_for.loopexit.unr-lcssa, label %for_loop_body.preheader.new

for_loop_body.preheader.new:                      ; preds = %for_loop_body.preheader
  %unroll_iter = and i64 %wide.trip.count, 4294967292
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.3, %for_loop_body.preheader.new
  %indvars.iv = phi i64 [ 0, %for_loop_body.preheader.new ], [ %indvars.iv.next.3, %after_if.3 ]
  %.01022 = phi double [ 0.000000e+00, %for_loop_body.preheader.new ], [ %.1.3, %after_if.3 ]
  %.01121 = phi double [ 0.000000e+00, %for_loop_body.preheader.new ], [ %.112.3, %after_if.3 ]
  %.01320 = phi double [ 0.000000e+00, %for_loop_body.preheader.new ], [ %.114.3, %after_if.3 ]
  %.01519 = phi double [ 0.000000e+00, %for_loop_body.preheader.new ], [ %.116.3, %after_if.3 ]
  %17 = load ptr, ptr %context, align 8
  %18 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %17, i64 0, i32 7, i32 1
  %19 = load ptr, ptr %18, align 8
  %20 = shl i64 %indvars.iv, 2
  %uglygep43 = getelementptr i8, ptr %19, i64 %20
  %21 = load i32, ptr %uglygep43, align 4
  %22 = icmp ult i32 %21, 70
  br i1 %22, label %true_block, label %false_block

after_for.loopexit.unr-lcssa.loopexit:            ; preds = %after_if.3
  br label %after_for.loopexit.unr-lcssa

after_for.loopexit.unr-lcssa:                     ; preds = %after_for.loopexit.unr-lcssa.loopexit, %for_loop_body.preheader
  %.116.lcssa.ph = phi double [ undef, %for_loop_body.preheader ], [ %.116.3, %after_for.loopexit.unr-lcssa.loopexit ]
  %.114.lcssa.ph = phi double [ undef, %for_loop_body.preheader ], [ %.114.3, %after_for.loopexit.unr-lcssa.loopexit ]
  %.112.lcssa.ph = phi double [ undef, %for_loop_body.preheader ], [ %.112.3, %after_for.loopexit.unr-lcssa.loopexit ]
  %.1.lcssa.ph = phi double [ undef, %for_loop_body.preheader ], [ %.1.3, %after_for.loopexit.unr-lcssa.loopexit ]
  %indvars.iv.unr = phi i64 [ 0, %for_loop_body.preheader ], [ %indvars.iv.next.3, %after_for.loopexit.unr-lcssa.loopexit ]
  %.01022.unr = phi double [ 0.000000e+00, %for_loop_body.preheader ], [ %.1.3, %after_for.loopexit.unr-lcssa.loopexit ]
  %.01121.unr = phi double [ 0.000000e+00, %for_loop_body.preheader ], [ %.112.3, %after_for.loopexit.unr-lcssa.loopexit ]
  %.01320.unr = phi double [ 0.000000e+00, %for_loop_body.preheader ], [ %.114.3, %after_for.loopexit.unr-lcssa.loopexit ]
  %.01519.unr = phi double [ 0.000000e+00, %for_loop_body.preheader ], [ %.116.3, %after_for.loopexit.unr-lcssa.loopexit ]
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %after_for, label %for_loop_body.epil.preheader

for_loop_body.epil.preheader:                     ; preds = %after_for.loopexit.unr-lcssa
  br label %for_loop_body.epil

for_loop_body.epil:                               ; preds = %after_if.epil, %for_loop_body.epil.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.epil.preheader ], [ %lsr.iv.next, %after_if.epil ]
  %indvars.iv.epil = phi i64 [ %indvars.iv.next.epil, %after_if.epil ], [ %indvars.iv.unr, %for_loop_body.epil.preheader ]
  %.01022.epil = phi double [ %.1.epil, %after_if.epil ], [ %.01022.unr, %for_loop_body.epil.preheader ]
  %.01121.epil = phi double [ %.112.epil, %after_if.epil ], [ %.01121.unr, %for_loop_body.epil.preheader ]
  %.01320.epil = phi double [ %.114.epil, %after_if.epil ], [ %.01320.unr, %for_loop_body.epil.preheader ]
  %.01519.epil = phi double [ %.116.epil, %after_if.epil ], [ %.01519.unr, %for_loop_body.epil.preheader ]
  %23 = load ptr, ptr %context, align 8
  %24 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %23, i64 0, i32 7, i32 1
  %25 = load ptr, ptr %24, align 8
  %26 = shl i64 %indvars.iv.epil, 2
  %uglygep = getelementptr i8, ptr %25, i64 %26
  %27 = load i32, ptr %uglygep, align 4
  %28 = icmp ult i32 %27, 70
  br i1 %28, label %true_block.epil, label %false_block.epil

false_block.epil:                                 ; preds = %for_loop_body.epil
  store i64 3, ptr %14, align 8
  br label %after_if.epil

true_block.epil:                                  ; preds = %for_loop_body.epil
  %29 = load ptr, ptr %0, align 8
  %30 = getelementptr inbounds %struct.LLVMRuntime, ptr %29, i64 0, i32 7
  %31 = load ptr, ptr %30, align 8
  %32 = getelementptr inbounds ptr, ptr %31, i64 1
  %33 = load ptr, ptr %32, align 8
  %34 = getelementptr %6, ptr %33, i64 0, i32 2, i32 1, i64 127
  %35 = lshr i32 %27, 3
  %36 = zext i32 %35 to i64
  %37 = getelementptr inbounds i8, ptr %34, i64 %36
  %38 = load i8, ptr %37, align 1
  %39 = zext i8 %38 to i32
  %40 = and i32 %27, 7
  %41 = shl nuw nsw i32 1, %40
  %42 = and i32 %41, %39
  %.not.epil = icmp eq i32 %42, 0
  br i1 %.not.epil, label %false_block2.epil, label %true_block1.epil

true_block1.epil:                                 ; preds = %true_block.epil
  %43 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %23, i64 0, i32 1, i32 1
  %44 = load ptr, ptr %43, align 8
  %45 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %23, i64 0, i32 1, i32 0, i32 1
  %46 = load i32, ptr %45, align 4
  %47 = sext i32 %46 to i64
  %48 = mul nsw i64 %47, 3
  %49 = zext i32 %27 to i64
  %50 = add nsw i64 %48, %49
  %51 = getelementptr double, ptr %44, i64 %50
  %52 = load double, ptr %51, align 8
  %53 = bitcast double %52 to i64
  %54 = and i64 %53, 9223372036854775807
  %55 = and i64 %53, 9218868437227405312
  %56 = icmp eq i64 %54, 0
  %57 = icmp ne i64 %55, 0
  %58 = icmp ne i64 %55, 9218868437227405312
  %59 = and i1 %57, %58
  %60 = or i1 %56, %59
  br i1 %60, label %after_if6.epil, label %true_block4.epil

true_block4.epil:                                 ; preds = %true_block1.epil
  %61 = load ptr, ptr %8, align 8
  %62 = getelementptr i64, ptr %61, i64 5
  %63 = load i64, ptr %62, align 8
  %64 = or i64 %63, 1
  store i64 %64, ptr %62, align 8
  br label %after_if6.epil

after_if6.epil:                                   ; preds = %true_block4.epil, %true_block1.epil
  %65 = fcmp ogt double %52, 0.000000e+00
  br i1 %65, label %true_block7.epil, label %false_block8.epil

false_block8.epil:                                ; preds = %after_if6.epil
  store i64 3, ptr %14, align 8
  br label %after_if.epil

true_block7.epil:                                 ; preds = %after_if6.epil
  %66 = fadd double %.01022.epil, %52
  %67 = load ptr, ptr %43, align 8
  %68 = getelementptr double, ptr %67, i64 %49
  %69 = load double, ptr %68, align 8
  %70 = bitcast double %69 to i64
  %71 = and i64 %70, 9223372036854775807
  %72 = and i64 %70, 9218868437227405312
  %73 = icmp eq i64 %71, 0
  %74 = icmp ne i64 %72, 0
  %75 = icmp ne i64 %72, 9218868437227405312
  %76 = and i1 %74, %75
  %77 = or i1 %73, %76
  br i1 %77, label %after_if12.epil, label %true_block10.epil

true_block10.epil:                                ; preds = %true_block7.epil
  %78 = load ptr, ptr %8, align 8
  %79 = getelementptr i64, ptr %78, i64 5
  %80 = load i64, ptr %79, align 8
  %81 = or i64 %80, 1
  store i64 %81, ptr %79, align 8
  %.pre.epil = load ptr, ptr %43, align 8
  br label %after_if12.epil

after_if12.epil:                                  ; preds = %true_block10.epil, %true_block7.epil
  %82 = phi ptr [ %67, %true_block7.epil ], [ %.pre.epil, %true_block10.epil ]
  %83 = load ptr, ptr %context, align 8
  %84 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %83, i64 0, i32 6, i32 1
  %85 = load ptr, ptr %84, align 8
  %86 = load double, ptr %85, align 8
  %87 = fsub double %69, %86
  %88 = fmul double %52, %87
  %89 = fadd double %.01519.epil, %88
  %90 = load i32, ptr %45, align 4
  %91 = sext i32 %90 to i64
  %92 = add nsw i64 %91, %49
  %93 = getelementptr double, ptr %82, i64 %92
  %94 = load double, ptr %93, align 8
  %95 = bitcast double %94 to i64
  %96 = and i64 %95, 9223372036854775807
  %97 = and i64 %95, 9218868437227405312
  %98 = icmp eq i64 %96, 0
  %99 = icmp ne i64 %97, 0
  %100 = icmp ne i64 %97, 9218868437227405312
  %101 = and i1 %99, %100
  %102 = or i1 %98, %101
  br i1 %102, label %after_if15.epil, label %true_block13.epil

true_block13.epil:                                ; preds = %after_if12.epil
  %103 = load ptr, ptr %8, align 8
  %104 = getelementptr i64, ptr %103, i64 5
  %105 = load i64, ptr %104, align 8
  %106 = or i64 %105, 1
  store i64 %106, ptr %104, align 8
  %.pre28.epil = load ptr, ptr %84, align 8
  %.pre29.epil = load ptr, ptr %43, align 8
  %.pre30.epil = load i32, ptr %45, align 4
  %.pre32.epil = sext i32 %.pre30.epil to i64
  br label %after_if15.epil

after_if15.epil:                                  ; preds = %true_block13.epil, %after_if12.epil
  %.pre-phi.epil = phi i64 [ %91, %after_if12.epil ], [ %.pre32.epil, %true_block13.epil ]
  %107 = phi ptr [ %82, %after_if12.epil ], [ %.pre29.epil, %true_block13.epil ]
  %108 = phi ptr [ %85, %after_if12.epil ], [ %.pre28.epil, %true_block13.epil ]
  %109 = getelementptr double, ptr %108, i64 1
  %110 = load double, ptr %109, align 8
  %111 = fsub double %94, %110
  %112 = fmul double %52, %111
  %113 = fadd double %.01320.epil, %112
  %114 = shl nsw i64 %.pre-phi.epil, 1
  %115 = add nsw i64 %114, %49
  %116 = getelementptr double, ptr %107, i64 %115
  %117 = load double, ptr %116, align 8
  %118 = bitcast double %117 to i64
  %119 = and i64 %118, 9223372036854775807
  %120 = and i64 %118, 9218868437227405312
  %121 = icmp eq i64 %119, 0
  %122 = icmp ne i64 %120, 0
  %123 = icmp ne i64 %120, 9218868437227405312
  %124 = and i1 %122, %123
  %125 = or i1 %121, %124
  br i1 %125, label %after_if18.epil, label %true_block16.epil

true_block16.epil:                                ; preds = %after_if15.epil
  %126 = load ptr, ptr %8, align 8
  %127 = getelementptr i64, ptr %126, i64 5
  %128 = load i64, ptr %127, align 8
  %129 = or i64 %128, 1
  store i64 %129, ptr %127, align 8
  %.pre31.epil = load ptr, ptr %84, align 8
  br label %after_if18.epil

after_if18.epil:                                  ; preds = %true_block16.epil, %after_if15.epil
  %130 = phi ptr [ %108, %after_if15.epil ], [ %.pre31.epil, %true_block16.epil ]
  %131 = getelementptr double, ptr %130, i64 2
  %132 = load double, ptr %131, align 8
  %133 = fsub double %117, %132
  %134 = fmul double %52, %133
  %135 = fadd double %.01121.epil, %134
  br label %after_if.epil

false_block2.epil:                                ; preds = %true_block.epil
  store i64 3, ptr %14, align 8
  br label %after_if.epil

after_if.epil:                                    ; preds = %false_block2.epil, %after_if18.epil, %false_block8.epil, %false_block.epil
  %.116.epil = phi double [ %89, %after_if18.epil ], [ %.01519.epil, %false_block8.epil ], [ %.01519.epil, %false_block2.epil ], [ %.01519.epil, %false_block.epil ]
  %.114.epil = phi double [ %113, %after_if18.epil ], [ %.01320.epil, %false_block8.epil ], [ %.01320.epil, %false_block2.epil ], [ %.01320.epil, %false_block.epil ]
  %.112.epil = phi double [ %135, %after_if18.epil ], [ %.01121.epil, %false_block8.epil ], [ %.01121.epil, %false_block2.epil ], [ %.01121.epil, %false_block.epil ]
  %.1.epil = phi double [ %66, %after_if18.epil ], [ %.01022.epil, %false_block8.epil ], [ %.01022.epil, %false_block2.epil ], [ %.01022.epil, %false_block.epil ]
  %indvars.iv.next.epil = add nuw nsw i64 %indvars.iv.epil, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %epil.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %epil.iter.cmp.not, label %after_for.loopexit, label %for_loop_body.epil, !llvm.loop !12

after_for.loopexit:                               ; preds = %after_if.epil
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %after_for.loopexit.unr-lcssa, %entry
  %.015.lcssa = phi double [ 0.000000e+00, %entry ], [ %.116.lcssa.ph, %after_for.loopexit.unr-lcssa ], [ %.116.epil, %after_for.loopexit ]
  %.013.lcssa = phi double [ 0.000000e+00, %entry ], [ %.114.lcssa.ph, %after_for.loopexit.unr-lcssa ], [ %.114.epil, %after_for.loopexit ]
  %.011.lcssa = phi double [ 0.000000e+00, %entry ], [ %.112.lcssa.ph, %after_for.loopexit.unr-lcssa ], [ %.112.epil, %after_for.loopexit ]
  %.010.lcssa = phi double [ 0.000000e+00, %entry ], [ %.1.lcssa.ph, %after_for.loopexit.unr-lcssa ], [ %.1.epil, %after_for.loopexit ]
  %136 = fcmp ogt double %.010.lcssa, 0.000000e+00
  %137 = fcmp olt double %.010.lcssa, 0.000000e+00
  %..i.op = select i1 %137, double 2.000000e+00, double 1.000000e+00
  %138 = select i1 %136, double 0.000000e+00, double %..i.op
  %139 = fadd double %.010.lcssa, %138
  %140 = bitcast double %.010.lcssa to i64
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if21, label %true_block19

true_block:                                       ; preds = %for_loop_body
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr inbounds %struct.LLVMRuntime, ptr %148, i64 0, i32 7
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr inbounds ptr, ptr %150, i64 1
  %152 = load ptr, ptr %151, align 8
  %153 = getelementptr %6, ptr %152, i64 0, i32 2, i32 1, i64 127
  %154 = lshr i32 %21, 3
  %155 = zext i32 %154 to i64
  %156 = getelementptr inbounds i8, ptr %153, i64 %155
  %157 = load i8, ptr %156, align 1
  %158 = zext i8 %157 to i32
  %159 = and i32 %21, 7
  %160 = shl nuw nsw i32 1, %159
  %161 = and i32 %160, %158
  %.not = icmp eq i32 %161, 0
  br i1 %.not, label %false_block2, label %true_block1

false_block:                                      ; preds = %for_loop_body
  store i64 3, ptr %14, align 8
  br label %after_if

after_if:                                         ; preds = %after_if18, %false_block8, %false_block2, %false_block
  %.116 = phi double [ %544, %after_if18 ], [ %.01519, %false_block8 ], [ %.01519, %false_block2 ], [ %.01519, %false_block ]
  %.114 = phi double [ %568, %after_if18 ], [ %.01320, %false_block8 ], [ %.01320, %false_block2 ], [ %.01320, %false_block ]
  %.112 = phi double [ %590, %after_if18 ], [ %.01121, %false_block8 ], [ %.01121, %false_block2 ], [ %.01121, %false_block ]
  %.1 = phi double [ %521, %after_if18 ], [ %.01022, %false_block8 ], [ %.01022, %false_block2 ], [ %.01022, %false_block ]
  %162 = load ptr, ptr %context, align 8
  %163 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %162, i64 0, i32 7, i32 1
  %164 = load ptr, ptr %163, align 8
  %uglygep39 = getelementptr i8, ptr %164, i64 4
  %uglygep40 = getelementptr i8, ptr %uglygep39, i64 %20
  %165 = load i32, ptr %uglygep40, align 4
  %166 = icmp ult i32 %165, 70
  br i1 %166, label %true_block.1, label %false_block.1

false_block.1:                                    ; preds = %after_if
  store i64 3, ptr %14, align 8
  br label %after_if.1

true_block.1:                                     ; preds = %after_if
  %167 = load ptr, ptr %0, align 8
  %168 = getelementptr inbounds %struct.LLVMRuntime, ptr %167, i64 0, i32 7
  %169 = load ptr, ptr %168, align 8
  %170 = getelementptr inbounds ptr, ptr %169, i64 1
  %171 = load ptr, ptr %170, align 8
  %172 = getelementptr %6, ptr %171, i64 0, i32 2, i32 1, i64 127
  %173 = lshr i32 %165, 3
  %174 = zext i32 %173 to i64
  %175 = getelementptr inbounds i8, ptr %172, i64 %174
  %176 = load i8, ptr %175, align 1
  %177 = zext i8 %176 to i32
  %178 = and i32 %165, 7
  %179 = shl nuw nsw i32 1, %178
  %180 = and i32 %179, %177
  %.not.1 = icmp eq i32 %180, 0
  br i1 %.not.1, label %false_block2.1, label %true_block1.1

true_block1.1:                                    ; preds = %true_block.1
  %181 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %162, i64 0, i32 1, i32 1
  %182 = load ptr, ptr %181, align 8
  %183 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %162, i64 0, i32 1, i32 0, i32 1
  %184 = load i32, ptr %183, align 4
  %185 = sext i32 %184 to i64
  %186 = mul nsw i64 %185, 3
  %187 = zext i32 %165 to i64
  %188 = add nsw i64 %186, %187
  %189 = getelementptr double, ptr %182, i64 %188
  %190 = load double, ptr %189, align 8
  %191 = bitcast double %190 to i64
  %192 = and i64 %191, 9223372036854775807
  %193 = and i64 %191, 9218868437227405312
  %194 = icmp eq i64 %192, 0
  %195 = icmp ne i64 %193, 0
  %196 = icmp ne i64 %193, 9218868437227405312
  %197 = and i1 %195, %196
  %198 = or i1 %194, %197
  br i1 %198, label %after_if6.1, label %true_block4.1

true_block4.1:                                    ; preds = %true_block1.1
  %199 = load ptr, ptr %8, align 8
  %200 = getelementptr i64, ptr %199, i64 5
  %201 = load i64, ptr %200, align 8
  %202 = or i64 %201, 1
  store i64 %202, ptr %200, align 8
  br label %after_if6.1

after_if6.1:                                      ; preds = %true_block4.1, %true_block1.1
  %203 = fcmp ogt double %190, 0.000000e+00
  br i1 %203, label %true_block7.1, label %false_block8.1

false_block8.1:                                   ; preds = %after_if6.1
  store i64 3, ptr %14, align 8
  br label %after_if.1

true_block7.1:                                    ; preds = %after_if6.1
  %204 = fadd double %.1, %190
  %205 = load ptr, ptr %181, align 8
  %206 = getelementptr double, ptr %205, i64 %187
  %207 = load double, ptr %206, align 8
  %208 = bitcast double %207 to i64
  %209 = and i64 %208, 9223372036854775807
  %210 = and i64 %208, 9218868437227405312
  %211 = icmp eq i64 %209, 0
  %212 = icmp ne i64 %210, 0
  %213 = icmp ne i64 %210, 9218868437227405312
  %214 = and i1 %212, %213
  %215 = or i1 %211, %214
  br i1 %215, label %after_if12.1, label %true_block10.1

true_block10.1:                                   ; preds = %true_block7.1
  %216 = load ptr, ptr %8, align 8
  %217 = getelementptr i64, ptr %216, i64 5
  %218 = load i64, ptr %217, align 8
  %219 = or i64 %218, 1
  store i64 %219, ptr %217, align 8
  %.pre.1 = load ptr, ptr %181, align 8
  br label %after_if12.1

after_if12.1:                                     ; preds = %true_block10.1, %true_block7.1
  %220 = phi ptr [ %205, %true_block7.1 ], [ %.pre.1, %true_block10.1 ]
  %221 = load ptr, ptr %context, align 8
  %222 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %221, i64 0, i32 6, i32 1
  %223 = load ptr, ptr %222, align 8
  %224 = load double, ptr %223, align 8
  %225 = fsub double %207, %224
  %226 = fmul double %190, %225
  %227 = fadd double %.116, %226
  %228 = load i32, ptr %183, align 4
  %229 = sext i32 %228 to i64
  %230 = add nsw i64 %229, %187
  %231 = getelementptr double, ptr %220, i64 %230
  %232 = load double, ptr %231, align 8
  %233 = bitcast double %232 to i64
  %234 = and i64 %233, 9223372036854775807
  %235 = and i64 %233, 9218868437227405312
  %236 = icmp eq i64 %234, 0
  %237 = icmp ne i64 %235, 0
  %238 = icmp ne i64 %235, 9218868437227405312
  %239 = and i1 %237, %238
  %240 = or i1 %236, %239
  br i1 %240, label %after_if15.1, label %true_block13.1

true_block13.1:                                   ; preds = %after_if12.1
  %241 = load ptr, ptr %8, align 8
  %242 = getelementptr i64, ptr %241, i64 5
  %243 = load i64, ptr %242, align 8
  %244 = or i64 %243, 1
  store i64 %244, ptr %242, align 8
  %.pre28.1 = load ptr, ptr %222, align 8
  %.pre29.1 = load ptr, ptr %181, align 8
  %.pre30.1 = load i32, ptr %183, align 4
  %.pre32.1 = sext i32 %.pre30.1 to i64
  br label %after_if15.1

after_if15.1:                                     ; preds = %true_block13.1, %after_if12.1
  %.pre-phi.1 = phi i64 [ %229, %after_if12.1 ], [ %.pre32.1, %true_block13.1 ]
  %245 = phi ptr [ %220, %after_if12.1 ], [ %.pre29.1, %true_block13.1 ]
  %246 = phi ptr [ %223, %after_if12.1 ], [ %.pre28.1, %true_block13.1 ]
  %247 = getelementptr double, ptr %246, i64 1
  %248 = load double, ptr %247, align 8
  %249 = fsub double %232, %248
  %250 = fmul double %190, %249
  %251 = fadd double %.114, %250
  %252 = shl nsw i64 %.pre-phi.1, 1
  %253 = add nsw i64 %252, %187
  %254 = getelementptr double, ptr %245, i64 %253
  %255 = load double, ptr %254, align 8
  %256 = bitcast double %255 to i64
  %257 = and i64 %256, 9223372036854775807
  %258 = and i64 %256, 9218868437227405312
  %259 = icmp eq i64 %257, 0
  %260 = icmp ne i64 %258, 0
  %261 = icmp ne i64 %258, 9218868437227405312
  %262 = and i1 %260, %261
  %263 = or i1 %259, %262
  br i1 %263, label %after_if18.1, label %true_block16.1

true_block16.1:                                   ; preds = %after_if15.1
  %264 = load ptr, ptr %8, align 8
  %265 = getelementptr i64, ptr %264, i64 5
  %266 = load i64, ptr %265, align 8
  %267 = or i64 %266, 1
  store i64 %267, ptr %265, align 8
  %.pre31.1 = load ptr, ptr %222, align 8
  br label %after_if18.1

after_if18.1:                                     ; preds = %true_block16.1, %after_if15.1
  %268 = phi ptr [ %246, %after_if15.1 ], [ %.pre31.1, %true_block16.1 ]
  %269 = getelementptr double, ptr %268, i64 2
  %270 = load double, ptr %269, align 8
  %271 = fsub double %255, %270
  %272 = fmul double %190, %271
  %273 = fadd double %.112, %272
  br label %after_if.1

false_block2.1:                                   ; preds = %true_block.1
  store i64 3, ptr %14, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %false_block2.1, %after_if18.1, %false_block8.1, %false_block.1
  %.116.1 = phi double [ %227, %after_if18.1 ], [ %.116, %false_block8.1 ], [ %.116, %false_block2.1 ], [ %.116, %false_block.1 ]
  %.114.1 = phi double [ %251, %after_if18.1 ], [ %.114, %false_block8.1 ], [ %.114, %false_block2.1 ], [ %.114, %false_block.1 ]
  %.112.1 = phi double [ %273, %after_if18.1 ], [ %.112, %false_block8.1 ], [ %.112, %false_block2.1 ], [ %.112, %false_block.1 ]
  %.1.1 = phi double [ %204, %after_if18.1 ], [ %.1, %false_block8.1 ], [ %.1, %false_block2.1 ], [ %.1, %false_block.1 ]
  %274 = load ptr, ptr %context, align 8
  %275 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %274, i64 0, i32 7, i32 1
  %276 = load ptr, ptr %275, align 8
  %uglygep37 = getelementptr i8, ptr %276, i64 8
  %uglygep38 = getelementptr i8, ptr %uglygep37, i64 %20
  %277 = load i32, ptr %uglygep38, align 4
  %278 = icmp ult i32 %277, 70
  br i1 %278, label %true_block.2, label %false_block.2

false_block.2:                                    ; preds = %after_if.1
  store i64 3, ptr %14, align 8
  br label %after_if.2

true_block.2:                                     ; preds = %after_if.1
  %279 = load ptr, ptr %0, align 8
  %280 = getelementptr inbounds %struct.LLVMRuntime, ptr %279, i64 0, i32 7
  %281 = load ptr, ptr %280, align 8
  %282 = getelementptr inbounds ptr, ptr %281, i64 1
  %283 = load ptr, ptr %282, align 8
  %284 = getelementptr %6, ptr %283, i64 0, i32 2, i32 1, i64 127
  %285 = lshr i32 %277, 3
  %286 = zext i32 %285 to i64
  %287 = getelementptr inbounds i8, ptr %284, i64 %286
  %288 = load i8, ptr %287, align 1
  %289 = zext i8 %288 to i32
  %290 = and i32 %277, 7
  %291 = shl nuw nsw i32 1, %290
  %292 = and i32 %291, %289
  %.not.2 = icmp eq i32 %292, 0
  br i1 %.not.2, label %false_block2.2, label %true_block1.2

true_block1.2:                                    ; preds = %true_block.2
  %293 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %274, i64 0, i32 1, i32 1
  %294 = load ptr, ptr %293, align 8
  %295 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %274, i64 0, i32 1, i32 0, i32 1
  %296 = load i32, ptr %295, align 4
  %297 = sext i32 %296 to i64
  %298 = mul nsw i64 %297, 3
  %299 = zext i32 %277 to i64
  %300 = add nsw i64 %298, %299
  %301 = getelementptr double, ptr %294, i64 %300
  %302 = load double, ptr %301, align 8
  %303 = bitcast double %302 to i64
  %304 = and i64 %303, 9223372036854775807
  %305 = and i64 %303, 9218868437227405312
  %306 = icmp eq i64 %304, 0
  %307 = icmp ne i64 %305, 0
  %308 = icmp ne i64 %305, 9218868437227405312
  %309 = and i1 %307, %308
  %310 = or i1 %306, %309
  br i1 %310, label %after_if6.2, label %true_block4.2

true_block4.2:                                    ; preds = %true_block1.2
  %311 = load ptr, ptr %8, align 8
  %312 = getelementptr i64, ptr %311, i64 5
  %313 = load i64, ptr %312, align 8
  %314 = or i64 %313, 1
  store i64 %314, ptr %312, align 8
  br label %after_if6.2

after_if6.2:                                      ; preds = %true_block4.2, %true_block1.2
  %315 = fcmp ogt double %302, 0.000000e+00
  br i1 %315, label %true_block7.2, label %false_block8.2

false_block8.2:                                   ; preds = %after_if6.2
  store i64 3, ptr %14, align 8
  br label %after_if.2

true_block7.2:                                    ; preds = %after_if6.2
  %316 = fadd double %.1.1, %302
  %317 = load ptr, ptr %293, align 8
  %318 = getelementptr double, ptr %317, i64 %299
  %319 = load double, ptr %318, align 8
  %320 = bitcast double %319 to i64
  %321 = and i64 %320, 9223372036854775807
  %322 = and i64 %320, 9218868437227405312
  %323 = icmp eq i64 %321, 0
  %324 = icmp ne i64 %322, 0
  %325 = icmp ne i64 %322, 9218868437227405312
  %326 = and i1 %324, %325
  %327 = or i1 %323, %326
  br i1 %327, label %after_if12.2, label %true_block10.2

true_block10.2:                                   ; preds = %true_block7.2
  %328 = load ptr, ptr %8, align 8
  %329 = getelementptr i64, ptr %328, i64 5
  %330 = load i64, ptr %329, align 8
  %331 = or i64 %330, 1
  store i64 %331, ptr %329, align 8
  %.pre.2 = load ptr, ptr %293, align 8
  br label %after_if12.2

after_if12.2:                                     ; preds = %true_block10.2, %true_block7.2
  %332 = phi ptr [ %317, %true_block7.2 ], [ %.pre.2, %true_block10.2 ]
  %333 = load ptr, ptr %context, align 8
  %334 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %333, i64 0, i32 6, i32 1
  %335 = load ptr, ptr %334, align 8
  %336 = load double, ptr %335, align 8
  %337 = fsub double %319, %336
  %338 = fmul double %302, %337
  %339 = fadd double %.116.1, %338
  %340 = load i32, ptr %295, align 4
  %341 = sext i32 %340 to i64
  %342 = add nsw i64 %341, %299
  %343 = getelementptr double, ptr %332, i64 %342
  %344 = load double, ptr %343, align 8
  %345 = bitcast double %344 to i64
  %346 = and i64 %345, 9223372036854775807
  %347 = and i64 %345, 9218868437227405312
  %348 = icmp eq i64 %346, 0
  %349 = icmp ne i64 %347, 0
  %350 = icmp ne i64 %347, 9218868437227405312
  %351 = and i1 %349, %350
  %352 = or i1 %348, %351
  br i1 %352, label %after_if15.2, label %true_block13.2

true_block13.2:                                   ; preds = %after_if12.2
  %353 = load ptr, ptr %8, align 8
  %354 = getelementptr i64, ptr %353, i64 5
  %355 = load i64, ptr %354, align 8
  %356 = or i64 %355, 1
  store i64 %356, ptr %354, align 8
  %.pre28.2 = load ptr, ptr %334, align 8
  %.pre29.2 = load ptr, ptr %293, align 8
  %.pre30.2 = load i32, ptr %295, align 4
  %.pre32.2 = sext i32 %.pre30.2 to i64
  br label %after_if15.2

after_if15.2:                                     ; preds = %true_block13.2, %after_if12.2
  %.pre-phi.2 = phi i64 [ %341, %after_if12.2 ], [ %.pre32.2, %true_block13.2 ]
  %357 = phi ptr [ %332, %after_if12.2 ], [ %.pre29.2, %true_block13.2 ]
  %358 = phi ptr [ %335, %after_if12.2 ], [ %.pre28.2, %true_block13.2 ]
  %359 = getelementptr double, ptr %358, i64 1
  %360 = load double, ptr %359, align 8
  %361 = fsub double %344, %360
  %362 = fmul double %302, %361
  %363 = fadd double %.114.1, %362
  %364 = shl nsw i64 %.pre-phi.2, 1
  %365 = add nsw i64 %364, %299
  %366 = getelementptr double, ptr %357, i64 %365
  %367 = load double, ptr %366, align 8
  %368 = bitcast double %367 to i64
  %369 = and i64 %368, 9223372036854775807
  %370 = and i64 %368, 9218868437227405312
  %371 = icmp eq i64 %369, 0
  %372 = icmp ne i64 %370, 0
  %373 = icmp ne i64 %370, 9218868437227405312
  %374 = and i1 %372, %373
  %375 = or i1 %371, %374
  br i1 %375, label %after_if18.2, label %true_block16.2

true_block16.2:                                   ; preds = %after_if15.2
  %376 = load ptr, ptr %8, align 8
  %377 = getelementptr i64, ptr %376, i64 5
  %378 = load i64, ptr %377, align 8
  %379 = or i64 %378, 1
  store i64 %379, ptr %377, align 8
  %.pre31.2 = load ptr, ptr %334, align 8
  br label %after_if18.2

after_if18.2:                                     ; preds = %true_block16.2, %after_if15.2
  %380 = phi ptr [ %358, %after_if15.2 ], [ %.pre31.2, %true_block16.2 ]
  %381 = getelementptr double, ptr %380, i64 2
  %382 = load double, ptr %381, align 8
  %383 = fsub double %367, %382
  %384 = fmul double %302, %383
  %385 = fadd double %.112.1, %384
  br label %after_if.2

false_block2.2:                                   ; preds = %true_block.2
  store i64 3, ptr %14, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %false_block2.2, %after_if18.2, %false_block8.2, %false_block.2
  %.116.2 = phi double [ %339, %after_if18.2 ], [ %.116.1, %false_block8.2 ], [ %.116.1, %false_block2.2 ], [ %.116.1, %false_block.2 ]
  %.114.2 = phi double [ %363, %after_if18.2 ], [ %.114.1, %false_block8.2 ], [ %.114.1, %false_block2.2 ], [ %.114.1, %false_block.2 ]
  %.112.2 = phi double [ %385, %after_if18.2 ], [ %.112.1, %false_block8.2 ], [ %.112.1, %false_block2.2 ], [ %.112.1, %false_block.2 ]
  %.1.2 = phi double [ %316, %after_if18.2 ], [ %.1.1, %false_block8.2 ], [ %.1.1, %false_block2.2 ], [ %.1.1, %false_block.2 ]
  %386 = load ptr, ptr %context, align 8
  %387 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %386, i64 0, i32 7, i32 1
  %388 = load ptr, ptr %387, align 8
  %uglygep41 = getelementptr i8, ptr %388, i64 12
  %uglygep42 = getelementptr i8, ptr %uglygep41, i64 %20
  %389 = load i32, ptr %uglygep42, align 4
  %390 = icmp ult i32 %389, 70
  br i1 %390, label %true_block.3, label %false_block.3

false_block.3:                                    ; preds = %after_if.2
  store i64 3, ptr %14, align 8
  br label %after_if.3

true_block.3:                                     ; preds = %after_if.2
  %391 = load ptr, ptr %0, align 8
  %392 = getelementptr inbounds %struct.LLVMRuntime, ptr %391, i64 0, i32 7
  %393 = load ptr, ptr %392, align 8
  %394 = getelementptr inbounds ptr, ptr %393, i64 1
  %395 = load ptr, ptr %394, align 8
  %396 = getelementptr %6, ptr %395, i64 0, i32 2, i32 1, i64 127
  %397 = lshr i32 %389, 3
  %398 = zext i32 %397 to i64
  %399 = getelementptr inbounds i8, ptr %396, i64 %398
  %400 = load i8, ptr %399, align 1
  %401 = zext i8 %400 to i32
  %402 = and i32 %389, 7
  %403 = shl nuw nsw i32 1, %402
  %404 = and i32 %403, %401
  %.not.3 = icmp eq i32 %404, 0
  br i1 %.not.3, label %false_block2.3, label %true_block1.3

true_block1.3:                                    ; preds = %true_block.3
  %405 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %386, i64 0, i32 1, i32 1
  %406 = load ptr, ptr %405, align 8
  %407 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %386, i64 0, i32 1, i32 0, i32 1
  %408 = load i32, ptr %407, align 4
  %409 = sext i32 %408 to i64
  %410 = mul nsw i64 %409, 3
  %411 = zext i32 %389 to i64
  %412 = add nsw i64 %410, %411
  %413 = getelementptr double, ptr %406, i64 %412
  %414 = load double, ptr %413, align 8
  %415 = bitcast double %414 to i64
  %416 = and i64 %415, 9223372036854775807
  %417 = and i64 %415, 9218868437227405312
  %418 = icmp eq i64 %416, 0
  %419 = icmp ne i64 %417, 0
  %420 = icmp ne i64 %417, 9218868437227405312
  %421 = and i1 %419, %420
  %422 = or i1 %418, %421
  br i1 %422, label %after_if6.3, label %true_block4.3

true_block4.3:                                    ; preds = %true_block1.3
  %423 = load ptr, ptr %8, align 8
  %424 = getelementptr i64, ptr %423, i64 5
  %425 = load i64, ptr %424, align 8
  %426 = or i64 %425, 1
  store i64 %426, ptr %424, align 8
  br label %after_if6.3

after_if6.3:                                      ; preds = %true_block4.3, %true_block1.3
  %427 = fcmp ogt double %414, 0.000000e+00
  br i1 %427, label %true_block7.3, label %false_block8.3

false_block8.3:                                   ; preds = %after_if6.3
  store i64 3, ptr %14, align 8
  br label %after_if.3

true_block7.3:                                    ; preds = %after_if6.3
  %428 = fadd double %.1.2, %414
  %429 = load ptr, ptr %405, align 8
  %430 = getelementptr double, ptr %429, i64 %411
  %431 = load double, ptr %430, align 8
  %432 = bitcast double %431 to i64
  %433 = and i64 %432, 9223372036854775807
  %434 = and i64 %432, 9218868437227405312
  %435 = icmp eq i64 %433, 0
  %436 = icmp ne i64 %434, 0
  %437 = icmp ne i64 %434, 9218868437227405312
  %438 = and i1 %436, %437
  %439 = or i1 %435, %438
  br i1 %439, label %after_if12.3, label %true_block10.3

true_block10.3:                                   ; preds = %true_block7.3
  %440 = load ptr, ptr %8, align 8
  %441 = getelementptr i64, ptr %440, i64 5
  %442 = load i64, ptr %441, align 8
  %443 = or i64 %442, 1
  store i64 %443, ptr %441, align 8
  %.pre.3 = load ptr, ptr %405, align 8
  br label %after_if12.3

after_if12.3:                                     ; preds = %true_block10.3, %true_block7.3
  %444 = phi ptr [ %429, %true_block7.3 ], [ %.pre.3, %true_block10.3 ]
  %445 = load ptr, ptr %context, align 8
  %446 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %445, i64 0, i32 6, i32 1
  %447 = load ptr, ptr %446, align 8
  %448 = load double, ptr %447, align 8
  %449 = fsub double %431, %448
  %450 = fmul double %414, %449
  %451 = fadd double %.116.2, %450
  %452 = load i32, ptr %407, align 4
  %453 = sext i32 %452 to i64
  %454 = add nsw i64 %453, %411
  %455 = getelementptr double, ptr %444, i64 %454
  %456 = load double, ptr %455, align 8
  %457 = bitcast double %456 to i64
  %458 = and i64 %457, 9223372036854775807
  %459 = and i64 %457, 9218868437227405312
  %460 = icmp eq i64 %458, 0
  %461 = icmp ne i64 %459, 0
  %462 = icmp ne i64 %459, 9218868437227405312
  %463 = and i1 %461, %462
  %464 = or i1 %460, %463
  br i1 %464, label %after_if15.3, label %true_block13.3

true_block13.3:                                   ; preds = %after_if12.3
  %465 = load ptr, ptr %8, align 8
  %466 = getelementptr i64, ptr %465, i64 5
  %467 = load i64, ptr %466, align 8
  %468 = or i64 %467, 1
  store i64 %468, ptr %466, align 8
  %.pre28.3 = load ptr, ptr %446, align 8
  %.pre29.3 = load ptr, ptr %405, align 8
  %.pre30.3 = load i32, ptr %407, align 4
  %.pre32.3 = sext i32 %.pre30.3 to i64
  br label %after_if15.3

after_if15.3:                                     ; preds = %true_block13.3, %after_if12.3
  %.pre-phi.3 = phi i64 [ %453, %after_if12.3 ], [ %.pre32.3, %true_block13.3 ]
  %469 = phi ptr [ %444, %after_if12.3 ], [ %.pre29.3, %true_block13.3 ]
  %470 = phi ptr [ %447, %after_if12.3 ], [ %.pre28.3, %true_block13.3 ]
  %471 = getelementptr double, ptr %470, i64 1
  %472 = load double, ptr %471, align 8
  %473 = fsub double %456, %472
  %474 = fmul double %414, %473
  %475 = fadd double %.114.2, %474
  %476 = shl nsw i64 %.pre-phi.3, 1
  %477 = add nsw i64 %476, %411
  %478 = getelementptr double, ptr %469, i64 %477
  %479 = load double, ptr %478, align 8
  %480 = bitcast double %479 to i64
  %481 = and i64 %480, 9223372036854775807
  %482 = and i64 %480, 9218868437227405312
  %483 = icmp eq i64 %481, 0
  %484 = icmp ne i64 %482, 0
  %485 = icmp ne i64 %482, 9218868437227405312
  %486 = and i1 %484, %485
  %487 = or i1 %483, %486
  br i1 %487, label %after_if18.3, label %true_block16.3

true_block16.3:                                   ; preds = %after_if15.3
  %488 = load ptr, ptr %8, align 8
  %489 = getelementptr i64, ptr %488, i64 5
  %490 = load i64, ptr %489, align 8
  %491 = or i64 %490, 1
  store i64 %491, ptr %489, align 8
  %.pre31.3 = load ptr, ptr %446, align 8
  br label %after_if18.3

after_if18.3:                                     ; preds = %true_block16.3, %after_if15.3
  %492 = phi ptr [ %470, %after_if15.3 ], [ %.pre31.3, %true_block16.3 ]
  %493 = getelementptr double, ptr %492, i64 2
  %494 = load double, ptr %493, align 8
  %495 = fsub double %479, %494
  %496 = fmul double %414, %495
  %497 = fadd double %.112.2, %496
  br label %after_if.3

false_block2.3:                                   ; preds = %true_block.3
  store i64 3, ptr %14, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %false_block2.3, %after_if18.3, %false_block8.3, %false_block.3
  %.116.3 = phi double [ %451, %after_if18.3 ], [ %.116.2, %false_block8.3 ], [ %.116.2, %false_block2.3 ], [ %.116.2, %false_block.3 ]
  %.114.3 = phi double [ %475, %after_if18.3 ], [ %.114.2, %false_block8.3 ], [ %.114.2, %false_block2.3 ], [ %.114.2, %false_block.3 ]
  %.112.3 = phi double [ %497, %after_if18.3 ], [ %.112.2, %false_block8.3 ], [ %.112.2, %false_block2.3 ], [ %.112.2, %false_block.3 ]
  %.1.3 = phi double [ %428, %after_if18.3 ], [ %.1.2, %false_block8.3 ], [ %.1.2, %false_block2.3 ], [ %.1.2, %false_block.3 ]
  %indvars.iv.next.3 = add nuw i64 %indvars.iv, 4
  %niter.ncmp.3 = icmp eq i64 %unroll_iter, %indvars.iv.next.3
  br i1 %niter.ncmp.3, label %after_for.loopexit.unr-lcssa.loopexit, label %for_loop_body

true_block1:                                      ; preds = %true_block
  %498 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %17, i64 0, i32 1, i32 1
  %499 = load ptr, ptr %498, align 8
  %500 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %17, i64 0, i32 1, i32 0, i32 1
  %501 = load i32, ptr %500, align 4
  %502 = sext i32 %501 to i64
  %503 = mul nsw i64 %502, 3
  %504 = zext i32 %21 to i64
  %505 = add nsw i64 %503, %504
  %506 = getelementptr double, ptr %499, i64 %505
  %507 = load double, ptr %506, align 8
  %508 = bitcast double %507 to i64
  %509 = and i64 %508, 9223372036854775807
  %510 = and i64 %508, 9218868437227405312
  %511 = icmp eq i64 %509, 0
  %512 = icmp ne i64 %510, 0
  %513 = icmp ne i64 %510, 9218868437227405312
  %514 = and i1 %512, %513
  %515 = or i1 %511, %514
  br i1 %515, label %after_if6, label %true_block4

false_block2:                                     ; preds = %true_block
  store i64 3, ptr %14, align 8
  br label %after_if

true_block4:                                      ; preds = %true_block1
  %516 = load ptr, ptr %8, align 8
  %517 = getelementptr i64, ptr %516, i64 5
  %518 = load i64, ptr %517, align 8
  %519 = or i64 %518, 1
  store i64 %519, ptr %517, align 8
  br label %after_if6

after_if6:                                        ; preds = %true_block4, %true_block1
  %520 = fcmp ogt double %507, 0.000000e+00
  br i1 %520, label %true_block7, label %false_block8

true_block7:                                      ; preds = %after_if6
  %521 = fadd double %.01022, %507
  %522 = load ptr, ptr %498, align 8
  %523 = getelementptr double, ptr %522, i64 %504
  %524 = load double, ptr %523, align 8
  %525 = bitcast double %524 to i64
  %526 = and i64 %525, 9223372036854775807
  %527 = and i64 %525, 9218868437227405312
  %528 = icmp eq i64 %526, 0
  %529 = icmp ne i64 %527, 0
  %530 = icmp ne i64 %527, 9218868437227405312
  %531 = and i1 %529, %530
  %532 = or i1 %528, %531
  br i1 %532, label %after_if12, label %true_block10

false_block8:                                     ; preds = %after_if6
  store i64 3, ptr %14, align 8
  br label %after_if

true_block10:                                     ; preds = %true_block7
  %533 = load ptr, ptr %8, align 8
  %534 = getelementptr i64, ptr %533, i64 5
  %535 = load i64, ptr %534, align 8
  %536 = or i64 %535, 1
  store i64 %536, ptr %534, align 8
  %.pre = load ptr, ptr %498, align 8
  br label %after_if12

after_if12:                                       ; preds = %true_block10, %true_block7
  %537 = phi ptr [ %522, %true_block7 ], [ %.pre, %true_block10 ]
  %538 = load ptr, ptr %context, align 8
  %539 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %538, i64 0, i32 6, i32 1
  %540 = load ptr, ptr %539, align 8
  %541 = load double, ptr %540, align 8
  %542 = fsub double %524, %541
  %543 = fmul double %507, %542
  %544 = fadd double %.01519, %543
  %545 = load i32, ptr %500, align 4
  %546 = sext i32 %545 to i64
  %547 = add nsw i64 %546, %504
  %548 = getelementptr double, ptr %537, i64 %547
  %549 = load double, ptr %548, align 8
  %550 = bitcast double %549 to i64
  %551 = and i64 %550, 9223372036854775807
  %552 = and i64 %550, 9218868437227405312
  %553 = icmp eq i64 %551, 0
  %554 = icmp ne i64 %552, 0
  %555 = icmp ne i64 %552, 9218868437227405312
  %556 = and i1 %554, %555
  %557 = or i1 %553, %556
  br i1 %557, label %after_if15, label %true_block13

true_block13:                                     ; preds = %after_if12
  %558 = load ptr, ptr %8, align 8
  %559 = getelementptr i64, ptr %558, i64 5
  %560 = load i64, ptr %559, align 8
  %561 = or i64 %560, 1
  store i64 %561, ptr %559, align 8
  %.pre28 = load ptr, ptr %539, align 8
  %.pre29 = load ptr, ptr %498, align 8
  %.pre30 = load i32, ptr %500, align 4
  %.pre32 = sext i32 %.pre30 to i64
  br label %after_if15

after_if15:                                       ; preds = %true_block13, %after_if12
  %.pre-phi = phi i64 [ %546, %after_if12 ], [ %.pre32, %true_block13 ]
  %562 = phi ptr [ %537, %after_if12 ], [ %.pre29, %true_block13 ]
  %563 = phi ptr [ %540, %after_if12 ], [ %.pre28, %true_block13 ]
  %564 = getelementptr double, ptr %563, i64 1
  %565 = load double, ptr %564, align 8
  %566 = fsub double %549, %565
  %567 = fmul double %507, %566
  %568 = fadd double %.01320, %567
  %569 = shl nsw i64 %.pre-phi, 1
  %570 = add nsw i64 %569, %504
  %571 = getelementptr double, ptr %562, i64 %570
  %572 = load double, ptr %571, align 8
  %573 = bitcast double %572 to i64
  %574 = and i64 %573, 9223372036854775807
  %575 = and i64 %573, 9218868437227405312
  %576 = icmp eq i64 %574, 0
  %577 = icmp ne i64 %575, 0
  %578 = icmp ne i64 %575, 9218868437227405312
  %579 = and i1 %577, %578
  %580 = or i1 %576, %579
  br i1 %580, label %after_if18, label %true_block16

true_block16:                                     ; preds = %after_if15
  %581 = load ptr, ptr %8, align 8
  %582 = getelementptr i64, ptr %581, i64 5
  %583 = load i64, ptr %582, align 8
  %584 = or i64 %583, 1
  store i64 %584, ptr %582, align 8
  %.pre31 = load ptr, ptr %539, align 8
  br label %after_if18

after_if18:                                       ; preds = %true_block16, %after_if15
  %585 = phi ptr [ %563, %after_if15 ], [ %.pre31, %true_block16 ]
  %586 = getelementptr double, ptr %585, i64 2
  %587 = load double, ptr %586, align 8
  %588 = fsub double %572, %587
  %589 = fmul double %507, %588
  %590 = fadd double %.01121, %589
  br label %after_if

true_block19:                                     ; preds = %after_for
  %591 = load ptr, ptr %8, align 8
  %592 = getelementptr i64, ptr %591, i64 5
  %593 = load i64, ptr %592, align 8
  %594 = or i64 %593, 1
  store i64 %594, ptr %592, align 8
  br label %after_if21

after_if21:                                       ; preds = %true_block19, %after_for
  %595 = load ptr, ptr %context, align 8
  %596 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %595, i64 0, i32 5, i32 1
  %597 = load ptr, ptr %596, align 8
  %598 = getelementptr double, ptr %597, i64 3
  store double %.010.lcssa, ptr %598, align 8
  %599 = load ptr, ptr %context, align 8
  %600 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %599, i64 0, i32 6, i32 1
  %601 = load ptr, ptr %600, align 8
  %602 = load double, ptr %601, align 8
  %603 = fdiv double %.015.lcssa, %139
  %604 = fadd double %603, %602
  %605 = select i1 %136, double %604, double 0.000000e+00
  %606 = bitcast double %605 to i64
  %607 = and i64 %606, 9223372036854775807
  %608 = and i64 %606, 9218868437227405312
  %609 = icmp eq i64 %607, 0
  %610 = icmp ne i64 %608, 0
  %611 = icmp ne i64 %608, 9218868437227405312
  %612 = and i1 %610, %611
  %613 = or i1 %609, %612
  br i1 %613, label %after_if24, label %true_block22

true_block22:                                     ; preds = %after_if21
  %614 = load ptr, ptr %8, align 8
  %615 = getelementptr i64, ptr %614, i64 5
  %616 = load i64, ptr %615, align 8
  %617 = or i64 %616, 1
  store i64 %617, ptr %615, align 8
  br label %after_if24

after_if24:                                       ; preds = %true_block22, %after_if21
  %618 = load ptr, ptr %596, align 8
  store double %605, ptr %618, align 8
  %619 = load ptr, ptr %600, align 8
  %620 = getelementptr double, ptr %619, i64 1
  %621 = load double, ptr %620, align 8
  %622 = fdiv double %.013.lcssa, %139
  %623 = fadd double %622, %621
  %624 = select i1 %136, double %623, double 0.000000e+00
  %625 = bitcast double %624 to i64
  %626 = and i64 %625, 9223372036854775807
  %627 = and i64 %625, 9218868437227405312
  %628 = icmp eq i64 %626, 0
  %629 = icmp ne i64 %627, 0
  %630 = icmp ne i64 %627, 9218868437227405312
  %631 = and i1 %629, %630
  %632 = or i1 %628, %631
  br i1 %632, label %after_if27, label %true_block25

true_block25:                                     ; preds = %after_if24
  %633 = load ptr, ptr %8, align 8
  %634 = getelementptr i64, ptr %633, i64 5
  %635 = load i64, ptr %634, align 8
  %636 = or i64 %635, 1
  store i64 %636, ptr %634, align 8
  br label %after_if27

after_if27:                                       ; preds = %true_block25, %after_if24
  %637 = load ptr, ptr %596, align 8
  %638 = getelementptr double, ptr %637, i64 1
  store double %624, ptr %638, align 8
  %639 = load ptr, ptr %600, align 8
  %640 = getelementptr double, ptr %639, i64 2
  %641 = load double, ptr %640, align 8
  %642 = fdiv double %.011.lcssa, %139
  %643 = fadd double %642, %641
  %644 = select i1 %136, double %643, double 0.000000e+00
  %645 = bitcast double %644 to i64
  %646 = and i64 %645, 9223372036854775807
  %647 = and i64 %645, 9218868437227405312
  %648 = icmp eq i64 %646, 0
  %649 = icmp ne i64 %647, 0
  %650 = icmp ne i64 %647, 9218868437227405312
  %651 = and i1 %649, %650
  %652 = or i1 %648, %651
  br i1 %652, label %after_if30, label %true_block28

true_block28:                                     ; preds = %after_if27
  %653 = load ptr, ptr %8, align 8
  %654 = getelementptr i64, ptr %653, i64 5
  %655 = load i64, ptr %654, align 8
  %656 = or i64 %655, 1
  store i64 %656, ptr %654, align 8
  br label %after_if30

after_if30:                                       ; preds = %true_block28, %after_if27
  %657 = load ptr, ptr %596, align 8
  %658 = getelementptr double, ptr %657, i64 2
  store double %644, ptr %658, align 8
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #6

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn writeonly
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #7

; Function Attrs: noinline nounwind optnone uwtable
define internal fastcc void @taichi_assert_format(ptr noundef %0, i1 noundef zeroext %1, ptr noundef %2) unnamed_addr #8 {
  %4 = alloca ptr, align 8
  %5 = alloca i8, align 1
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca ptr, align 8
  %9 = alloca %class.anon, align 8
  store ptr %0, ptr %4, align 8
  %10 = zext i1 %1 to i8
  store i8 %10, ptr %5, align 1
  store ptr %2, ptr %6, align 8
  store i32 0, ptr %7, align 4
  store ptr null, ptr %8, align 8
  %11 = load i8, ptr %5, align 1
  %12 = trunc i8 %11 to i1
  %13 = zext i1 %12 to i32
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %15, label %16

15:                                               ; preds = %3
  br label %69

16:                                               ; preds = %3
  %17 = load ptr, ptr %4, align 8
  %18 = getelementptr inbounds %struct.LLVMRuntime, ptr %17, i32 0, i32 24
  %19 = load i64, ptr %18, align 8
  %20 = icmp ne i64 %19, 0
  br i1 %20, label %69, label %21

21:                                               ; preds = %16
  %22 = load ptr, ptr %4, align 8
  %23 = getelementptr inbounds %struct.LLVMRuntime, ptr %22, i32 0, i32 23
  %24 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 0
  store ptr %4, ptr %24, align 8
  %25 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 1
  store ptr %6, ptr %25, align 8
  %26 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 2
  store ptr %7, ptr %26, align 8
  %27 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 3
  store ptr %8, ptr %27, align 8
  br label %28

28:                                               ; preds = %28, %21
  %29 = atomicrmw volatile xchg ptr %23, i32 1 seq_cst, align 4
  %30 = icmp eq i32 %29, 1
  br i1 %30, label %28, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !8

mutex_lock_i32.exit.i.i.i:                        ; preds = %28
  %31 = load ptr, ptr %9, align 8
  %32 = load ptr, ptr %31, align 8
  %33 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 24
  %34 = load i64, ptr %33, align 8
  %.not.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i, label %35, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

35:                                               ; preds = %mutex_lock_i32.exit.i.i.i
  store i64 1, ptr %33, align 8
  %36 = load ptr, ptr %9, align 8
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr inbounds %struct.LLVMRuntime, ptr %37, i64 0, i32 21
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %38, i8 0, i64 2048, i1 false)
  %39 = load ptr, ptr %9, align 8
  %40 = load ptr, ptr %39, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 21
  %42 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 1
  %43 = load ptr, ptr %42, align 8
  %44 = load ptr, ptr %43, align 8
  %45 = load i8, ptr %44, align 1
  %.not5.i.i.i.i.i = icmp eq i8 %45, 0
  br i1 %.not5.i.i.i.i.i, label %taichi_strlen.exit.thread.i.i.i.i, label %.lr.ph.i.i.i.i.i.preheader

.lr.ph.i.i.i.i.i.preheader:                       ; preds = %35
  br label %.lr.ph.i.i.i.i.i

.lr.ph.i.i.i.i.i:                                 ; preds = %.lr.ph.i.i.i.i.i, %.lr.ph.i.i.i.i.i.preheader
  %.07.i.i.i.i.i = phi ptr [ %47, %.lr.ph.i.i.i.i.i ], [ %44, %.lr.ph.i.i.i.i.i.preheader ]
  %.046.i.i.i.i.i = phi i64 [ %46, %.lr.ph.i.i.i.i.i ], [ 0, %.lr.ph.i.i.i.i.i.preheader ]
  %46 = add i64 %.046.i.i.i.i.i, 1
  %47 = getelementptr inbounds i8, ptr %.07.i.i.i.i.i, i64 1
  %48 = load i8, ptr %47, align 1
  %.not.i.i.i.i.i = icmp eq i8 %48, 0
  br i1 %.not.i.i.i.i.i, label %taichi_strlen.exit.i.i.i.i, label %.lr.ph.i.i.i.i.i, !llvm.loop !13

taichi_strlen.exit.i.i.i.i:                       ; preds = %.lr.ph.i.i.i.i.i
  %.lcssa = phi i64 [ %46, %.lr.ph.i.i.i.i.i ]
  %49 = call i64 @llvm.umin.i64(i64 %.lcssa, i64 2047)
  br label %taichi_strlen.exit.thread.i.i.i.i

taichi_strlen.exit.thread.i.i.i.i:                ; preds = %taichi_strlen.exit.i.i.i.i, %35
  %50 = phi i64 [ 0, %35 ], [ %49, %taichi_strlen.exit.i.i.i.i ]
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %41, ptr nonnull align 1 %44, i64 %50, i1 false)
  %51 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 2
  %52 = load ptr, ptr %51, align 8
  %53 = load i32, ptr %52, align 4
  %54 = icmp sgt i32 %53, 0
  br i1 %54, label %.lr.ph.i.i.i.i, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

.lr.ph.i.i.i.i:                                   ; preds = %taichi_strlen.exit.thread.i.i.i.i
  %55 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 3
  br label %56

56:                                               ; preds = %56, %.lr.ph.i.i.i.i
  %indvars.iv.i.i.i.i = phi i64 [ 0, %.lr.ph.i.i.i.i ], [ %indvars.iv.next.i.i.i.i, %56 ]
  %57 = load ptr, ptr %55, align 8
  %58 = load ptr, ptr %57, align 8
  %59 = getelementptr inbounds i64, ptr %58, i64 %indvars.iv.i.i.i.i
  %60 = load i64, ptr %59, align 8
  %61 = load ptr, ptr %9, align 8
  %62 = load ptr, ptr %61, align 8
  %63 = getelementptr inbounds %struct.LLVMRuntime, ptr %62, i64 0, i32 22, i64 %indvars.iv.i.i.i.i
  store i64 %60, ptr %63, align 8
  %indvars.iv.next.i.i.i.i = add nuw nsw i64 %indvars.iv.i.i.i.i, 1
  %64 = load ptr, ptr %51, align 8
  %65 = load i32, ptr %64, align 4
  %66 = sext i32 %65 to i64
  %67 = icmp slt i64 %indvars.iv.next.i.i.i.i, %66
  br i1 %67, label %56, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", !llvm.loop !14

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit": ; preds = %56
  br label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit": ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", %taichi_strlen.exit.thread.i.i.i.i, %mutex_lock_i32.exit.i.i.i
  %68 = atomicrmw volatile xchg ptr %23, i32 0 seq_cst, align 4
  br label %69

69:                                               ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit", %16, %15
  ret void
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_struct_for_block_helper(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #9 {
_ZN11ListManager3getI7ElementEERT_i.exit:
  %3 = alloca %struct.RuntimeContext.2230, align 8
  %4 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 4
  %5 = load i32, ptr %4, align 4
  %6 = sdiv i32 %2, %5
  %7 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  %8 = load i32, ptr %7, align 8
  %9 = sdiv i32 %8, %5
  %10 = srem i32 %2, %5
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  %12 = load ptr, ptr %11, align 8
  %13 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %14 = load i32, ptr %13, align 8
  %15 = ashr i32 %6, %14
  %16 = sext i32 %15 to i64
  %17 = lshr i64 %16, 9
  %18 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %17
  %19 = load atomic i64, ptr %18 acquire, align 8
  %.not.i.i.i = icmp ne i64 %19, 0
  tail call void @llvm.assume(i1 %.not.i.i.i)
  %20 = inttoptr i64 %19 to ptr
  %21 = and i64 %16, 511
  %22 = getelementptr inbounds ptr, ptr %20, i64 %21
  %23 = load atomic i64, ptr %22 acquire, align 8
  %24 = inttoptr i64 %23 to ptr
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %26 = load i64, ptr %25, align 8
  %27 = load i32, ptr %13, align 8
  %notmask.i.i = shl nsw i32 -1, %27
  %28 = xor i32 %notmask.i.i, -1
  %29 = and i32 %6, %28
  %30 = sext i32 %29 to i64
  %31 = mul i64 %26, %30
  %32 = getelementptr inbounds i8, ptr %24, i64 %31
  %33 = getelementptr inbounds %0, ptr %32, i64 0, i32 1
  %34 = load i32, ptr %33, align 8
  %35 = mul nsw i32 %10, %9
  %36 = add nsw i32 %34, %35
  %37 = add nsw i32 %10, 1
  %38 = mul nsw i32 %37, %9
  %39 = add nsw i32 %34, %38
  %40 = getelementptr inbounds %0, ptr %32, i64 0, i32 1, i64 1
  %41 = load i32, ptr %40, align 4
  %42 = tail call i32 @llvm.smin.i32(i32 %41, i32 %39)
  %43 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  %44 = load i64, ptr %43, align 8
  %45 = alloca i8, i64 %44, align 8
  %46 = load ptr, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %3, ptr noundef nonnull align 8 dereferenceable(32) %46, i64 32, i1 false)
  %47 = getelementptr inbounds %struct.RuntimeContext.2230, ptr %3, i64 0, i32 2
  store i32 %1, ptr %47, align 8
  %48 = icmp slt i32 %36, %42
  br i1 %48, label %49, label %75

49:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit
  %50 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = load ptr, ptr %11, align 8
  %53 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 3
  %54 = load i32, ptr %53, align 8
  %55 = ashr i32 %6, %54
  %56 = sext i32 %55 to i64
  %57 = lshr i64 %56, 9
  %58 = getelementptr inbounds [256 x ptr], ptr %52, i64 0, i64 %57
  %59 = load atomic i64, ptr %58 acquire, align 8
  %.not.i.i.i24 = icmp eq i64 %59, 0
  br i1 %.not.i.i.i24, label %_ZN11ListManager3getI7ElementEERT_i.exit26, label %60

60:                                               ; preds = %49
  %61 = inttoptr i64 %59 to ptr
  %62 = and i64 %56, 511
  %63 = getelementptr inbounds ptr, ptr %61, i64 %62
  %64 = load atomic i64, ptr %63 acquire, align 8
  %65 = inttoptr i64 %64 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit26

_ZN11ListManager3getI7ElementEERT_i.exit26:       ; preds = %60, %49
  %66 = phi ptr [ %65, %60 ], [ null, %49 ]
  %67 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 1
  %68 = load i64, ptr %67, align 8
  %69 = load i32, ptr %53, align 8
  %notmask.i.i25 = shl nsw i32 -1, %69
  %70 = xor i32 %notmask.i.i25, -1
  %71 = and i32 %6, %70
  %72 = sext i32 %71 to i64
  %73 = mul i64 %68, %72
  %74 = getelementptr inbounds i8, ptr %66, i64 %73
  call void %51(ptr noundef nonnull %3, ptr noundef nonnull %45, ptr noundef nonnull %74, i32 noundef %36, i32 noundef %42) #1
  br label %75

75:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit26, %_ZN11ListManager3getI7ElementEERT_i.exit
  ret void
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_parallel_range_for_task(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #9 {
  %4 = alloca %struct.RuntimeContext.2230, align 8
  %.sroa.0.0.copyload = load ptr, ptr %0, align 8
  %.sroa.4.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 8
  %.sroa.4.0.copyload = load ptr, ptr %.sroa.4.0..sroa_idx, align 8
  %.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 16
  %.sroa.5.0.copyload = load ptr, ptr %.sroa.5.0..sroa_idx, align 8
  %.sroa.7.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 24
  %.sroa.7.0.copyload = load ptr, ptr %.sroa.7.0..sroa_idx, align 8
  %.sroa.8.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 32
  %.sroa.8.0.copyload = load i64, ptr %.sroa.8.0..sroa_idx, align 8
  %.sroa.9.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 40
  %.sroa.9.0.copyload = load i32, ptr %.sroa.9.0..sroa_idx, align 8
  %.sroa.12.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 44
  %.sroa.12.0.copyload = load i32, ptr %.sroa.12.0..sroa_idx, align 4
  %.sroa.15.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 48
  %.sroa.15.0.copyload = load i32, ptr %.sroa.15.0..sroa_idx, align 8
  %.sroa.17.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 52
  %.sroa.17.0.copyload = load i32, ptr %.sroa.17.0..sroa_idx, align 4
  %5 = alloca i8, i64 %.sroa.8.0.copyload, align 8
  %.not = icmp eq ptr %.sroa.4.0.copyload, null
  br i1 %.not, label %7, label %6

6:                                                ; preds = %3
  call void %.sroa.4.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %7

7:                                                ; preds = %6, %3
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %4, ptr noundef nonnull align 8 dereferenceable(32) %.sroa.0.0.copyload, i64 32, i1 false)
  %8 = getelementptr inbounds %struct.RuntimeContext.2230, ptr %4, i64 0, i32 2
  store i32 %1, ptr %8, align 8
  switch i32 %.sroa.17.0.copyload, label %.loopexit [
    i32 1, label %9
    i32 -1, label %17
  ]

9:                                                ; preds = %7
  %10 = mul nsw i32 %.sroa.15.0.copyload, %2
  %11 = add nsw i32 %10, %.sroa.9.0.copyload
  %12 = add nsw i32 %11, %.sroa.15.0.copyload
  %13 = call i32 @llvm.smin.i32(i32 %.sroa.12.0.copyload, i32 %12)
  %14 = icmp slt i32 %11, %13
  br i1 %14, label %.lr.ph.preheader, label %.loopexit

.lr.ph.preheader:                                 ; preds = %9
  br label %.lr.ph

.lr.ph:                                           ; preds = %.lr.ph, %.lr.ph.preheader
  %.02039 = phi i32 [ %15, %.lr.ph ], [ %11, %.lr.ph.preheader ]
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.02039) #1
  %15 = add nsw i32 %.02039, 1
  %16 = icmp slt i32 %15, %13
  br i1 %16, label %.lr.ph, label %.loopexit.loopexit, !llvm.loop !15

17:                                               ; preds = %7
  %18 = mul nsw i32 %.sroa.15.0.copyload, %2
  %19 = sub nsw i32 %.sroa.12.0.copyload, %18
  %20 = mul nsw i32 %19, %.sroa.15.0.copyload
  %21 = call i32 @llvm.smax.i32(i32 %.sroa.9.0.copyload, i32 %20)
  %.not25.not40 = icmp sgt i32 %19, %21
  br i1 %.not25.not40, label %.lr.ph42.preheader, label %.loopexit

.lr.ph42.preheader:                               ; preds = %17
  br label %.lr.ph42

.lr.ph42:                                         ; preds = %.lr.ph42, %.lr.ph42.preheader
  %.0.in41 = phi i32 [ %.0, %.lr.ph42 ], [ %19, %.lr.ph42.preheader ]
  %.0 = add nsw i32 %.0.in41, -1
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.0) #1
  %.not25.not = icmp sgt i32 %.0, %21
  br i1 %.not25.not, label %.lr.ph42, label %.loopexit.loopexit47, !llvm.loop !16

.loopexit.loopexit:                               ; preds = %.lr.ph
  br label %.loopexit

.loopexit.loopexit47:                             ; preds = %.lr.ph42
  br label %.loopexit

.loopexit:                                        ; preds = %.loopexit.loopexit47, %.loopexit.loopexit, %17, %9, %7
  %.not24 = icmp eq ptr %.sroa.7.0.copyload, null
  br i1 %.not24, label %23, label %22

22:                                               ; preds = %.loopexit
  call void %.sroa.7.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %23

23:                                               ; preds = %22, %.loopexit
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #10

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smax.i32(i32, i32) #10

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #11

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #11

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i64 @llvm.umin.i64(i64, i64) #12

; Function Attrs: inaccessiblememonly nocallback nofree nosync nounwind willreturn
declare void @llvm.assume(i1 noundef) #13

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { nofree nosync nounwind }
attributes #3 = { nofree norecurse nounwind }
attributes #4 = { nofree norecurse nosync nounwind }
attributes #5 = { nofree nounwind }
attributes #6 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #7 = { argmemonly mustprogress nocallback nofree nounwind willreturn writeonly }
attributes #8 = { noinline nounwind optnone uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #11 = { argmemonly nocallback nofree nosync nounwind willreturn }
attributes #12 = { nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #13 = { inaccessiblememonly nocallback nofree nosync nounwind willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.unroll.disable"}
!8 = distinct !{!8, !9}
!9 = !{!"llvm.loop.mustprogress"}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
!13 = distinct !{!13, !9}
!14 = distinct !{!14, !9}
!15 = distinct !{!15, !9}
!16 = distinct !{!16, !9}
