; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%0 = type { ptr, [2 x i32], %struct.PhysicalCoordinates.729 }
%1 = type { %2, %2 }
%2 = type { [4 x i64], [4 x ptr] }
%struct.RuntimeContext.716 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }
%struct.ListManager = type { [256 x ptr], i64, i64, i32, i32, i32, ptr }
%struct.PhysicalCoordinates.729 = type { [12 x i32] }
%struct.cpu_block_task_helper_context = type { ptr, ptr, ptr, i32, i32, i64 }
%struct.NodeManager = type <{ ptr, i32, i32, i32, i32, ptr, ptr, ptr, i32, [4 x i8] }>
%class.anon = type { ptr, ptr, ptr, ptr }

@.str = private unnamed_addr constant [28 x i8] c"Out of pre-allocated memory\00", align 1
@.str.2 = private unnamed_addr constant [28 x i8] c"List manager out of chunks.\00", align 1

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @field_integrate_25_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, i32, double, { { i32 }, ptr }, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %0, i64 0, i32 2
  %2 = load double, ptr %1, align 8
  %3 = getelementptr inbounds %struct.RuntimeContext.716, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  store double %2, ptr %6, align 8
  %7 = load ptr, ptr %context, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, i32, double, { { i32 }, ptr }, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %7, i64 0, i32 4
  %9 = load double, ptr %8, align 8
  %10 = load ptr, ptr %3, align 8
  %11 = getelementptr inbounds %struct.LLVMRuntime, ptr %10, i64 0, i32 16
  %12 = load ptr, ptr %11, align 8
  %13 = getelementptr inbounds i8, ptr %12, i64 8
  store double %9, ptr %13, align 8
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @field_integrate_25_kernel_1_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.716, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 24
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @field_integrate_25_kernel_2_listgen_S24pointer(ptr %context) local_unnamed_addr #1 {
.lr.ph.i:
  %.sroa.2.i = alloca { [2 x i32], %struct.PhysicalCoordinates.729 }, align 8
  %0 = alloca %0, align 8
  %1 = getelementptr inbounds %struct.RuntimeContext.716, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 23
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %4, i64 24
  %8 = load ptr, ptr %7, align 8
  %9 = load atomic i64, ptr %6 acquire, align 8
  %.not.i.i.i.i = icmp ne i64 %9, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i)
  %10 = inttoptr i64 %9 to ptr
  %11 = load atomic i64, ptr %10 acquire, align 8
  %12 = inttoptr i64 %11 to ptr
  %.sroa.0.0.copyload.i = load ptr, ptr %12, align 8
  %.sroa.2.0..sroa_idx.i = getelementptr inbounds i8, ptr %12, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.i, ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.0..sroa_idx.i, i64 56, i1 false)
  %13 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %.sroa.2.16.sroa_idx.i = getelementptr inbounds i8, ptr %.sroa.2.i, i64 8
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %16 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 4
  %17 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 6
  %18 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 2
  %19 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  store ptr %.sroa.0.0.copyload.i, ptr %0, align 8
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %0, i64 8
  store <2 x i32> <i32 0, i32 4>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %13, ptr noundef nonnull align 8 dereferenceable(48) %.sroa.2.16.sroa_idx.i, i64 48, i1 false)
  %20 = atomicrmw volatile add ptr %14, i32 1 seq_cst, align 4
  %21 = load i32, ptr %15, align 8
  %22 = ashr i32 %20, %21
  %23 = icmp ugt i32 %22, 131071
  br i1 %23, label %24, label %26

24:                                               ; preds = %.lr.ph.i
  %25 = load ptr, ptr %17, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %25, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

26:                                               ; preds = %.lr.ph.i
  %27 = zext i32 %22 to i64
  %28 = lshr i64 %27, 9
  %29 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %28
  %30 = load atomic i64, ptr %29 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %30, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %26
  %31 = inttoptr i64 %30 to ptr
  %32 = and i64 %27, 511
  %33 = getelementptr inbounds ptr, ptr %31, i64 %32
  %34 = load atomic i64, ptr %33 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %26
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %35 = atomicrmw volatile xchg ptr %16, i32 1 seq_cst, align 4
  %36 = icmp eq i32 %35, 1
  br i1 %36, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %37 = load atomic i64, ptr %29 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %37, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %39, label %73

39:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %40 = load ptr, ptr %17, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1
  %42 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 28
  %43 = atomicrmw volatile add ptr %42, i64 4096 seq_cst, align 8
  %44 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 2
  %45 = load i64, ptr %44, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %45, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %66, label %46

46:                                               ; preds = %39
  %47 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 26
  br label %48

48:                                               ; preds = %48, %46
  %49 = atomicrmw volatile xchg ptr %47, i32 1 seq_cst, align 4
  %50 = icmp eq i32 %49, 1
  br i1 %50, label %48, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %48
  %51 = load ptr, ptr %41, align 8
  %52 = ptrtoint ptr %51 to i64
  %53 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 1
  %54 = load ptr, ptr %53, align 8
  %55 = ptrtoint ptr %54 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %52
  %56 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %57 = or i64 %56, 4096
  %58 = add i64 %57, %52
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %58, %55
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %59

59:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %60 = add i64 %56, %52
  %61 = inttoptr i64 %60 to ptr
  %62 = getelementptr i8, ptr %51, i64 %56
  %63 = getelementptr inbounds i8, ptr %62, i64 4096
  store ptr %63, ptr %41, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %59, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %61, %59 ]
  %64 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %65 = atomicrmw volatile xchg ptr %47, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %40, i1 noundef zeroext %64, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

66:                                               ; preds = %39
  %67 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 2
  %68 = load ptr, ptr %67, align 8
  %69 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 6
  %70 = load ptr, ptr %69, align 8
  %71 = tail call noundef ptr %68(ptr noundef %70, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %66, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %71, %66 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %72 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %72, ptr %29 release, align 8
  br label %73

73:                                               ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %38, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %74 = and i32 %22, 511
  %75 = zext i32 %74 to i64
  %76 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %75
  %77 = load atomic i64, ptr %76 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %77, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %78, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

78:                                               ; preds = %73
  %79 = load ptr, ptr %17, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1
  %81 = load i64, ptr %18, align 8
  %82 = load i64, ptr %19, align 8
  %83 = mul i64 %82, %81
  %84 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 28
  %85 = atomicrmw volatile add ptr %84, i64 %83 seq_cst, align 8
  %86 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 2
  %87 = load i64, ptr %86, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %87, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %107, label %88

88:                                               ; preds = %78
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 26
  br label %90

90:                                               ; preds = %90, %88
  %91 = atomicrmw volatile xchg ptr %89, i32 1 seq_cst, align 4
  %92 = icmp eq i32 %91, 1
  br i1 %92, label %90, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %90
  %93 = load ptr, ptr %80, align 8
  %94 = ptrtoint ptr %93 to i64
  %95 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 1
  %96 = load ptr, ptr %95, align 8
  %97 = ptrtoint ptr %96 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %94
  %98 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %99 = add i64 %98, %83
  %100 = add i64 %99, %94
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %100, %97
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %101

101:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %102 = add i64 %98, %94
  %103 = inttoptr i64 %102 to ptr
  %104 = getelementptr inbounds i8, ptr %93, i64 %99
  store ptr %104, ptr %80, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %101, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %103, %101 ]
  %105 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %106 = atomicrmw volatile xchg ptr %89, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %79, i1 noundef zeroext %105, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

107:                                              ; preds = %78
  %108 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 2
  %109 = load ptr, ptr %108, align 8
  %110 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 6
  %111 = load ptr, ptr %110, align 8
  %112 = tail call noundef ptr %109(ptr noundef %111, i64 noundef %83, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %107, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %112, %107 ]
  %113 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %113, ptr %76 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %73
  %114 = atomicrmw volatile xchg ptr %16, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %24
  %115 = load i32, ptr %15, align 8
  %116 = ashr i32 %20, %115
  %117 = sext i32 %116 to i64
  %118 = lshr i64 %117, 9
  %119 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %118
  %120 = load atomic i64, ptr %119 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %120, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %121

121:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %122 = inttoptr i64 %120 to ptr
  %123 = and i64 %117, 511
  %124 = getelementptr inbounds ptr, ptr %122, i64 %123
  %125 = load atomic i64, ptr %124 acquire, align 8
  %126 = inttoptr i64 %125 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %121, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %127 = phi ptr [ %126, %121 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %128 = load i64, ptr %19, align 8
  %129 = load i32, ptr %15, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %129
  %130 = xor i32 %notmask.i.i.i.i, -1
  %131 = and i32 %20, %130
  %132 = sext i32 %131 to i64
  %133 = mul i64 %128, %132
  %134 = getelementptr inbounds i8, ptr %127, i64 %133
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %134, ptr nonnull align 8 %0, i64 %128, i1 false)
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @field_integrate_25_kernel_3_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.716, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 25
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @field_integrate_25_kernel_4_listgen_S25bitmasked(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %0, align 8
  %1 = alloca %struct.PhysicalCoordinates.729, align 4
  %2 = alloca %0, align 8
  %3 = getelementptr inbounds %struct.RuntimeContext.716, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %2)
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 13
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %6, i64 24
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %10 = load i32, ptr %9, align 8
  %11 = getelementptr inbounds ptr, ptr %6, i64 25
  %12 = load ptr, ptr %11, align 8
  %13 = icmp sgt i32 %10, 0
  br i1 %13, label %.lr.ph61.i, label %element_listgen_nonroot.exit

.lr.ph61.i:                                       ; preds = %entry
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  %16 = getelementptr inbounds %0, ptr %0, i64 0, i32 1
  %17 = getelementptr inbounds %0, ptr %0, i64 0, i32 1, i64 1
  %18 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %19 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %20 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 5
  %21 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %22 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 4
  %23 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 6
  %24 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 2
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %2, i64 8
  br label %26

26:                                               ; preds = %._crit_edge.i, %.lr.ph61.i
  %.04359.i = phi i32 [ 0, %.lr.ph61.i ], [ %172, %._crit_edge.i ]
  %27 = load i32, ptr %14, align 8
  %28 = lshr i32 %.04359.i, %27
  %29 = sext i32 %28 to i64
  %30 = lshr i64 %29, 9
  %31 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %30
  %32 = load atomic i64, ptr %31 acquire, align 8
  %.not.i.i.i.i = icmp eq i64 %32, 0
  br i1 %.not.i.i.i.i, label %_ZN11ListManager3getI7ElementEERT_i.exit.i, label %33

33:                                               ; preds = %26
  %34 = inttoptr i64 %32 to ptr
  %35 = and i64 %29, 511
  %36 = getelementptr inbounds ptr, ptr %34, i64 %35
  %37 = load atomic i64, ptr %36 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit.i

_ZN11ListManager3getI7ElementEERT_i.exit.i:       ; preds = %33, %26
  %39 = phi ptr [ %38, %33 ], [ null, %26 ]
  %40 = load i64, ptr %15, align 8
  %41 = load i32, ptr %14, align 8
  %notmask.i.i.i = shl nsw i32 -1, %41
  %42 = xor i32 %notmask.i.i.i, -1
  %43 = and i32 %.04359.i, %42
  %44 = zext i32 %43 to i64
  %45 = mul i64 %40, %44
  %46 = getelementptr inbounds i8, ptr %39, i64 %45
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %0, ptr noundef nonnull align 8 dereferenceable(64) %46, i64 64, i1 false)
  %47 = load i32, ptr %16, align 8
  %48 = load i32, ptr %17, align 4
  %49 = icmp slt i32 %47, %48
  br i1 %49, label %.lr.ph58.i.preheader, label %._crit_edge.i

.lr.ph58.i.preheader:                             ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit.i
  br label %.lr.ph58.i

.lr.ph58.i:                                       ; preds = %.loopexit.i, %.lr.ph58.i.preheader
  %.04457.i = phi i32 [ %171, %.loopexit.i ], [ %47, %.lr.ph58.i.preheader ]
  call fastcc void @S24_refine_coordinates(ptr noundef nonnull %18, ptr noundef nonnull %1, i32 noundef %.04457.i) #1
  %50 = load ptr, ptr %0, align 8
  %51 = shl i32 %.04457.i, 3
  %52 = sext i32 %51 to i64
  %53 = getelementptr i8, ptr %50, i64 %52
  %54 = getelementptr inbounds i8, ptr %53, i64 32
  %55 = load ptr, ptr %54, align 8
  %.not = icmp eq ptr %55, null
  br i1 %.not, label %.loopexit.i, label %.lr.ph.i

.lr.ph.i:                                         ; preds = %.lr.ph58.i
  store ptr %55, ptr %2, align 8
  store <2 x i32> <i32 0, i32 32>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %19, ptr noundef nonnull align 4 dereferenceable(48) %1, i64 48, i1 false)
  %56 = atomicrmw volatile add ptr %20, i32 1 seq_cst, align 4
  %57 = load i32, ptr %21, align 8
  %58 = ashr i32 %56, %57
  %59 = icmp ugt i32 %58, 131071
  br i1 %59, label %60, label %62

60:                                               ; preds = %.lr.ph.i
  %61 = load ptr, ptr %23, align 8
  call fastcc void @taichi_assert_format(ptr noundef %61, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

62:                                               ; preds = %.lr.ph.i
  %63 = zext i32 %58 to i64
  %64 = lshr i64 %63, 9
  %65 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %64
  %66 = load atomic i64, ptr %65 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %66, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %62
  %67 = inttoptr i64 %66 to ptr
  %68 = and i64 %63, 511
  %69 = getelementptr inbounds ptr, ptr %67, i64 %68
  %70 = load atomic i64, ptr %69 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %70, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %62
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %71 = atomicrmw volatile xchg ptr %22, i32 1 seq_cst, align 4
  %72 = icmp eq i32 %71, 1
  br i1 %72, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %73 = load atomic i64, ptr %65 acquire, align 8
  %74 = inttoptr i64 %73 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %73, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %75, label %109

75:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %76 = load ptr, ptr %23, align 8
  %77 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1
  %78 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 28
  %79 = atomicrmw volatile add ptr %78, i64 4096 seq_cst, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 2
  %81 = load i64, ptr %80, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %81, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %102, label %82

82:                                               ; preds = %75
  %83 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 26
  br label %84

84:                                               ; preds = %84, %82
  %85 = atomicrmw volatile xchg ptr %83, i32 1 seq_cst, align 4
  %86 = icmp eq i32 %85, 1
  br i1 %86, label %84, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %84
  %87 = load ptr, ptr %77, align 8
  %88 = ptrtoint ptr %87 to i64
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 1
  %90 = load ptr, ptr %89, align 8
  %91 = ptrtoint ptr %90 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %88
  %92 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %93 = or i64 %92, 4096
  %94 = add i64 %93, %88
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %94, %91
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %95

95:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %96 = add i64 %92, %88
  %97 = inttoptr i64 %96 to ptr
  %98 = getelementptr i8, ptr %87, i64 %92
  %99 = getelementptr inbounds i8, ptr %98, i64 4096
  store ptr %99, ptr %77, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %95, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %97, %95 ]
  %100 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %101 = atomicrmw volatile xchg ptr %83, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %76, i1 noundef zeroext %100, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

102:                                              ; preds = %75
  %103 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 2
  %104 = load ptr, ptr %103, align 8
  %105 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 6
  %106 = load ptr, ptr %105, align 8
  %107 = call noundef ptr %104(ptr noundef %106, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %102, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %107, %102 ]
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %108 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %108, ptr %65 release, align 8
  br label %109

109:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %74, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %110 = and i32 %58, 511
  %111 = zext i32 %110 to i64
  %112 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %111
  %113 = load atomic i64, ptr %112 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %113, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %114, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

114:                                              ; preds = %109
  %115 = load ptr, ptr %23, align 8
  %116 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1
  %117 = load i64, ptr %24, align 8
  %118 = load i64, ptr %25, align 8
  %119 = mul i64 %118, %117
  %120 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 28
  %121 = atomicrmw volatile add ptr %120, i64 %119 seq_cst, align 8
  %122 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 2
  %123 = load i64, ptr %122, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %123, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %143, label %124

124:                                              ; preds = %114
  %125 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 26
  br label %126

126:                                              ; preds = %126, %124
  %127 = atomicrmw volatile xchg ptr %125, i32 1 seq_cst, align 4
  %128 = icmp eq i32 %127, 1
  br i1 %128, label %126, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %126
  %129 = load ptr, ptr %116, align 8
  %130 = ptrtoint ptr %129 to i64
  %131 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 1
  %132 = load ptr, ptr %131, align 8
  %133 = ptrtoint ptr %132 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %130
  %134 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %135 = add i64 %134, %119
  %136 = add i64 %135, %130
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %136, %133
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %137

137:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %138 = add i64 %134, %130
  %139 = inttoptr i64 %138 to ptr
  %140 = getelementptr inbounds i8, ptr %129, i64 %135
  store ptr %140, ptr %116, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %137, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %139, %137 ]
  %141 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %142 = atomicrmw volatile xchg ptr %125, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %115, i1 noundef zeroext %141, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

143:                                              ; preds = %114
  %144 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 2
  %145 = load ptr, ptr %144, align 8
  %146 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 6
  %147 = load ptr, ptr %146, align 8
  %148 = call noundef ptr %145(ptr noundef %147, i64 noundef %119, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %143, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %148, %143 ]
  %149 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %149, ptr %112 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %109
  %150 = atomicrmw volatile xchg ptr %22, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %60
  %151 = load i32, ptr %21, align 8
  %152 = ashr i32 %56, %151
  %153 = sext i32 %152 to i64
  %154 = lshr i64 %153, 9
  %155 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %154
  %156 = load atomic i64, ptr %155 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %156, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %157

157:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %158 = inttoptr i64 %156 to ptr
  %159 = and i64 %153, 511
  %160 = getelementptr inbounds ptr, ptr %158, i64 %159
  %161 = load atomic i64, ptr %160 acquire, align 8
  %162 = inttoptr i64 %161 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %157, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %163 = phi ptr [ %162, %157 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %164 = load i64, ptr %25, align 8
  %165 = load i32, ptr %21, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %165
  %166 = xor i32 %notmask.i.i.i.i, -1
  %167 = and i32 %56, %166
  %168 = sext i32 %167 to i64
  %169 = mul i64 %164, %168
  %170 = getelementptr inbounds i8, ptr %163, i64 %169
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %170, ptr nonnull align 8 %2, i64 %164, i1 false)
  br label %.loopexit.i, !llvm.loop !9

.loopexit.i:                                      ; preds = %_ZN11ListManager6appendEPv.exit.i, %.lr.ph58.i
  %171 = add i32 %.04457.i, 1
  %exitcond.not.i = icmp eq i32 %171, %48
  br i1 %exitcond.not.i, label %._crit_edge.i.loopexit, label %.lr.ph58.i, !llvm.loop !10

._crit_edge.i.loopexit:                           ; preds = %.loopexit.i
  br label %._crit_edge.i

._crit_edge.i:                                    ; preds = %._crit_edge.i.loopexit, %_ZN11ListManager3getI7ElementEERT_i.exit.i
  %172 = add nuw nsw i32 %.04359.i, 1
  %exitcond63.not.i = icmp eq i32 %172, %10
  br i1 %exitcond63.not.i, label %element_listgen_nonroot.exit.loopexit, label %26, !llvm.loop !11

element_listgen_nonroot.exit.loopexit:            ; preds = %._crit_edge.i
  br label %element_listgen_nonroot.exit

element_listgen_nonroot.exit:                     ; preds = %element_listgen_nonroot.exit.loopexit, %entry
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %2)
  ret void
}

; Function Attrs: nounwind
define void @field_integrate_25_kernel_5_struct_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.cpu_block_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.RuntimeContext.716, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 25
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds %struct.ListManager, ptr %6, i64 0, i32 5
  %8 = load i32, ptr %7, align 8
  store ptr %context, ptr %0, align 8
  %9 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  store ptr @function_body, ptr %9, align 8
  %10 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  store ptr %6, ptr %10, align 8
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  store <2 x i32> <i32 32, i32 8>, ptr %11, align 8
  %12 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  store i64 1, ptr %12, align 8
  %13 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 12
  %14 = load ptr, ptr %13, align 8
  %15 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 11
  %16 = load ptr, ptr %15, align 8
  %17 = shl nsw i32 %8, 3
  call void %14(ptr noundef %16, i32 noundef %17, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_struct_for_block_helper) #1
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %0)
  ret void
}

; Function Attrs: nounwind
define internal void @function_body(ptr %0, ptr nocapture readnone %1, ptr nocapture readonly %2, i32 %3, i32 %4) #1 {
allocs:
  %5 = alloca ptr, align 8
  %6 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %7 = icmp slt i32 %3, %4
  br i1 %7, label %loop_body.lr.ph, label %func_exit

loop_body.lr.ph:                                  ; preds = %allocs
  %8 = getelementptr inbounds %struct.RuntimeContext.716, ptr %0, i64 0, i32 1
  br label %loop_body

loop_body:                                        ; preds = %loop_body_tail, %loop_body.lr.ph
  %.0785 = phi i32 [ %3, %loop_body.lr.ph ], [ %24, %loop_body_tail ]
  %9 = and i32 %.0785, 31
  %10 = load i32, ptr %6, align 4
  %11 = load ptr, ptr %2, align 8
  %12 = getelementptr inbounds i8, ptr %11, i64 32
  %13 = sdiv i32 %.0785, 8
  %14 = sext i32 %13 to i64
  %15 = getelementptr inbounds i8, ptr %12, i64 %14
  %16 = load i8, ptr %15, align 1
  %17 = zext i8 %16 to i32
  %18 = and i32 %.0785, 7
  %19 = shl nuw nsw i32 1, %18
  %20 = and i32 %19, %17
  %.not = icmp eq i32 %20, 0
  br i1 %.not, label %loop_body_tail, label %struct_for_body_body

loop_body_tail.sink.split:                        ; preds = %after_for, %after_if55
  %.sink89 = phi i64 [ 8, %after_if55 ], [ 5, %after_for ]
  %21 = load ptr, ptr %28, align 8
  %22 = getelementptr i64, ptr %21, i64 %.sink89
  %23 = atomicrmw add ptr %22, i64 1 seq_cst, align 8
  br label %loop_body_tail

loop_body_tail:                                   ; preds = %after_for, %loop_body_tail.sink.split, %loop_body
  %24 = add nsw i32 %.0785, 1
  %exitcond87.not = icmp eq i32 %24, %4
  br i1 %exitcond87.not, label %func_exit.loopexit, label %loop_body

func_exit.loopexit:                               ; preds = %loop_body_tail
  br label %func_exit

func_exit:                                        ; preds = %func_exit.loopexit, %allocs
  ret void

struct_for_body_body:                             ; preds = %loop_body
  %25 = shl i32 %10, 5
  %26 = or i32 %25, %9
  %27 = load ptr, ptr %0, align 8
  %28 = getelementptr { { { i32, i32 }, ptr }, i32, double, { { i32 }, ptr }, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %27, i64 0, i32 8, i32 1
  %29 = load ptr, ptr %28, align 8
  %30 = atomicrmw add ptr %29, i64 1 seq_cst, align 8
  %31 = load ptr, ptr %0, align 8
  %32 = getelementptr { { i32, i32 }, ptr }, ptr %31, i64 0, i32 1
  %33 = load ptr, ptr %32, align 8
  %34 = getelementptr { { i32, i32 }, ptr }, ptr %31, i64 0, i32 0, i32 1
  %35 = load i32, ptr %34, align 4
  %36 = sext i32 %35 to i64
  %37 = sext i32 %26 to i64
  %38 = getelementptr double, ptr %33, i64 %37
  %39 = load double, ptr %38, align 8
  %40 = mul nsw i64 %36, 3
  %41 = add nsw i64 %40, %37
  %42 = getelementptr double, ptr %33, i64 %41
  %43 = load double, ptr %42, align 8
  %44 = add nsw i64 %36, %37
  %45 = getelementptr double, ptr %33, i64 %44
  %46 = load double, ptr %45, align 8
  %47 = shl nsw i64 %36, 2
  %48 = add nsw i64 %47, %37
  %49 = getelementptr double, ptr %33, i64 %48
  %50 = load double, ptr %49, align 8
  %51 = shl nsw i64 %36, 1
  %52 = add nsw i64 %51, %37
  %53 = getelementptr double, ptr %33, i64 %52
  %54 = load double, ptr %53, align 8
  %55 = mul nsw i64 %36, 5
  %56 = add nsw i64 %55, %37
  %57 = getelementptr double, ptr %33, i64 %56
  %58 = load double, ptr %57, align 8
  %59 = mul nsw i64 %36, 6
  %60 = add nsw i64 %59, %37
  %61 = getelementptr double, ptr %33, i64 %60
  %62 = load double, ptr %61, align 8
  %63 = shl nsw i64 %36, 3
  %64 = add nsw i64 %63, %37
  %65 = getelementptr double, ptr %33, i64 %64
  %66 = load double, ptr %65, align 8
  %67 = mul nsw i64 %36, 9
  %68 = add nsw i64 %67, %37
  %69 = getelementptr double, ptr %33, i64 %68
  %70 = load double, ptr %69, align 8
  %71 = mul nsw i64 %36, 10
  %72 = add nsw i64 %71, %37
  %73 = getelementptr double, ptr %33, i64 %72
  %74 = load double, ptr %73, align 8
  %75 = fcmp ogt double %62, 0.000000e+00
  %76 = fcmp olt double %62, 0.000000e+00
  %..i16 = select i1 %76, double -1.000000e+00, double 0.000000e+00
  %.0.i17 = select i1 %75, double 1.000000e+00, double %..i16
  %77 = fsub double 1.000000e+00, %.0.i17
  %78 = fadd double %62, %77
  %79 = load ptr, ptr %8, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 16
  %81 = load ptr, ptr %80, align 8
  %82 = load double, ptr %81, align 8
  %83 = fmul double %.0.i17, %82
  %84 = fdiv double %83, %78
  %85 = fmul double %66, %84
  %86 = fadd double %43, %85
  %87 = fmul double %70, %84
  %88 = fadd double %50, %87
  %89 = fmul double %74, %84
  %90 = fadd double %58, %89
  %91 = fmul double %66, %66
  %92 = fmul double %70, %70
  %93 = fadd double %91, %92
  %94 = fmul double %74, %74
  %95 = fadd double %93, %94
  %96 = tail call double @llvm.sqrt.f64(double %95)
  %97 = fmul double %86, %86
  %98 = fmul double %88, %88
  %99 = fadd double %97, %98
  %100 = fmul double %90, %90
  %101 = fadd double %100, %99
  %102 = tail call double @llvm.sqrt.f64(double %101)
  %103 = bitcast double %66 to i64
  %104 = and i64 %103, 9223372036854775807
  %105 = and i64 %103, 9218868437227405312
  %106 = icmp eq i64 %104, 0
  %107 = icmp ne i64 %105, 0
  %108 = icmp ne i64 %105, 9218868437227405312
  %109 = and i1 %107, %108
  %110 = or i1 %106, %109
  br i1 %110, label %after_if, label %true_block

true_block:                                       ; preds = %struct_for_body_body
  %111 = load ptr, ptr %28, align 8
  %112 = getelementptr i64, ptr %111, i64 19
  %113 = atomicrmw add ptr %112, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %struct_for_body_body
  %114 = bitcast double %70 to i64
  %115 = and i64 %114, 9223372036854775807
  %116 = and i64 %114, 9218868437227405312
  %117 = icmp eq i64 %115, 0
  %118 = icmp ne i64 %116, 0
  %119 = icmp ne i64 %116, 9218868437227405312
  %120 = and i1 %118, %119
  %121 = or i1 %117, %120
  br i1 %121, label %after_if3, label %true_block1

true_block1:                                      ; preds = %after_if
  %122 = load ptr, ptr %28, align 8
  %123 = getelementptr i64, ptr %122, i64 19
  %124 = atomicrmw add ptr %123, i64 1 seq_cst, align 8
  br label %after_if3

after_if3:                                        ; preds = %true_block1, %after_if
  %125 = bitcast double %74 to i64
  %126 = and i64 %125, 9223372036854775807
  %127 = and i64 %125, 9218868437227405312
  %128 = icmp eq i64 %126, 0
  %129 = icmp ne i64 %127, 0
  %130 = icmp ne i64 %127, 9218868437227405312
  %131 = and i1 %129, %130
  %132 = or i1 %128, %131
  br i1 %132, label %after_if6, label %true_block4

true_block4:                                      ; preds = %after_if3
  %133 = load ptr, ptr %28, align 8
  %134 = getelementptr i64, ptr %133, i64 19
  %135 = atomicrmw add ptr %134, i64 1 seq_cst, align 8
  br label %after_if6

after_if6:                                        ; preds = %true_block4, %after_if3
  %136 = bitcast double %96 to i64
  %137 = and i64 %136, 9223372036854775807
  %138 = and i64 %136, 9218868437227405312
  %139 = icmp eq i64 %137, 0
  %140 = icmp ne i64 %138, 0
  %141 = icmp ne i64 %138, 9218868437227405312
  %142 = and i1 %140, %141
  %143 = or i1 %139, %142
  br i1 %143, label %after_if9, label %true_block7

true_block7:                                      ; preds = %after_if6
  %144 = load ptr, ptr %28, align 8
  %145 = getelementptr i64, ptr %144, i64 19
  %146 = atomicrmw add ptr %145, i64 1 seq_cst, align 8
  br label %after_if9

after_if9:                                        ; preds = %true_block7, %after_if6
  %147 = bitcast double %102 to i64
  %148 = and i64 %147, 9223372036854775807
  %149 = and i64 %147, 9218868437227405312
  %150 = icmp eq i64 %148, 0
  %151 = icmp ne i64 %149, 0
  %152 = icmp ne i64 %149, 9218868437227405312
  %153 = and i1 %151, %152
  %154 = or i1 %150, %153
  br i1 %154, label %after_if12, label %true_block10

true_block10:                                     ; preds = %after_if9
  %155 = load ptr, ptr %28, align 8
  %156 = getelementptr i64, ptr %155, i64 19
  %157 = atomicrmw add ptr %156, i64 1 seq_cst, align 8
  br label %after_if12

after_if12:                                       ; preds = %true_block10, %after_if9
  %158 = fmul double %82, %102
  %159 = fcmp ogt double %96, 0.000000e+00
  %.0.i15 = select i1 %159, double 1.000000e+00, double 0.000000e+00
  %160 = fsub double 1.000000e+00, %.0.i15
  %161 = fadd double %96, %160
  %162 = fdiv double %158, %161
  %163 = fmul double %162, %162
  %164 = fneg double %163
  %165 = fmul double %163, %164
  %neg = fmul double %.0.i15, %165
  %166 = tail call double @exp(double noundef %neg) #1
  %167 = fmul double %86, %166
  %168 = fmul double %88, %166
  %169 = fmul double %90, %166
  %170 = load ptr, ptr %0, align 8
  %171 = getelementptr { { { i32, i32 }, ptr }, i32, double, { { i32 }, ptr }, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %170, i64 0, i32 7, i32 1
  %172 = load ptr, ptr %171, align 8
  %173 = load double, ptr %172, align 8
  %174 = fsub double %39, %173
  %175 = getelementptr double, ptr %172, i64 1
  %176 = load double, ptr %175, align 8
  %177 = fsub double %46, %176
  %178 = getelementptr double, ptr %172, i64 2
  %179 = load double, ptr %178, align 8
  %180 = fsub double %54, %179
  %181 = fmul double %174, %174
  %182 = fmul double %177, %177
  %183 = fadd double %181, %182
  %184 = fmul double %180, %180
  %185 = fadd double %183, %184
  %186 = fcmp ogt double %185, 0.000000e+00
  %.0.i14 = select i1 %186, double 1.000000e+00, double 0.000000e+00
  %187 = fsub double 1.000000e+00, %.0.i14
  %188 = fadd double %185, %187
  %sqrt = tail call double @llvm.sqrt.f64(double %188)
  %189 = fdiv double 1.000000e+00, %sqrt
  %190 = fmul double %174, %189
  %191 = fmul double %177, %189
  %192 = fmul double %180, %189
  %193 = getelementptr { { { i32, i32 }, ptr }, i32, double, { { i32 }, ptr }, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %170, i64 0, i32 3, i32 1
  %194 = load ptr, ptr %193, align 8
  %195 = load double, ptr %194, align 8
  %196 = fcmp ogt double %195, 0.000000e+00
  %197 = fcmp olt double %195, 0.000000e+00
  %..i.op = select i1 %197, double 2.000000e+00, double 1.000000e+00
  %198 = select i1 %196, double 0.000000e+00, double %..i.op
  %199 = fadd double %195, %198
  %200 = load ptr, ptr %8, align 8
  %201 = getelementptr inbounds %struct.LLVMRuntime, ptr %200, i64 0, i32 16
  %202 = load ptr, ptr %201, align 8
  %203 = getelementptr inbounds i8, ptr %202, i64 8
  %204 = load double, ptr %203, align 8
  %205 = fmul double %185, %204
  %206 = fdiv double %205, %199
  %207 = bitcast double %185 to i64
  %208 = and i64 %207, 9223372036854775807
  %209 = and i64 %207, 9218868437227405312
  %210 = icmp eq i64 %208, 0
  %211 = icmp ne i64 %209, 0
  %212 = icmp ne i64 %209, 9218868437227405312
  %213 = and i1 %211, %212
  %214 = or i1 %210, %213
  br i1 %214, label %after_if15, label %true_block13

true_block13:                                     ; preds = %after_if12
  %215 = load ptr, ptr %28, align 8
  %216 = getelementptr i64, ptr %215, i64 19
  %217 = atomicrmw add ptr %216, i64 1 seq_cst, align 8
  br label %after_if15

after_if15:                                       ; preds = %true_block13, %after_if12
  %218 = bitcast double %206 to i64
  %219 = and i64 %218, 9223372036854775807
  %220 = and i64 %218, 9218868437227405312
  %221 = icmp eq i64 %219, 0
  %222 = icmp ne i64 %220, 0
  %223 = icmp ne i64 %220, 9218868437227405312
  %224 = and i1 %222, %223
  %225 = or i1 %221, %224
  br i1 %225, label %after_if18, label %true_block16

true_block16:                                     ; preds = %after_if15
  %226 = load ptr, ptr %28, align 8
  %227 = getelementptr i64, ptr %226, i64 19
  %228 = atomicrmw add ptr %227, i64 1 seq_cst, align 8
  br label %after_if18

after_if18:                                       ; preds = %true_block16, %after_if15
  %229 = fadd double %206, -1.000000e+00
  %230 = tail call double @llvm.maxnum.f64(double %229, double 0.000000e+00)
  %neg19 = fneg double %230
  %231 = tail call double @exp(double noundef %neg19) #1
  %232 = fmul double %167, %190
  %233 = fmul double %168, %191
  %234 = fadd double %232, %233
  %235 = fmul double %169, %192
  %236 = fadd double %235, %234
  %237 = tail call double @llvm.maxnum.f64(double %236, double 0.000000e+00)
  %238 = fsub double 1.000000e+00, %231
  %239 = fmul double %237, %238
  %240 = fmul double %.0.i14, %239
  %241 = fmul double %190, %240
  %242 = fsub double %167, %241
  %243 = fmul double %191, %240
  %244 = fsub double %168, %243
  %245 = fmul double %192, %240
  %246 = fsub double %169, %245
  %247 = fcmp ogt double %82, 0.000000e+00
  %248 = fmul double %82, %242
  %249 = fadd double %39, %248
  %250 = fcmp one double %249, %39
  %251 = bitcast double %249 to i64
  %252 = and i64 %251, 9223372036854775807
  %253 = and i64 %251, 9218868437227405312
  %254 = icmp eq i64 %252, 0
  %255 = icmp ne i64 %253, 0
  %256 = icmp ne i64 %253, 9218868437227405312
  %257 = and i1 %255, %256
  %258 = or i1 %254, %257
  br i1 %258, label %after_if22, label %true_block20

true_block20:                                     ; preds = %after_if18
  %259 = load ptr, ptr %28, align 8
  %260 = getelementptr i64, ptr %259, i64 19
  %261 = atomicrmw add ptr %260, i64 1 seq_cst, align 8
  br label %after_if22

after_if22:                                       ; preds = %true_block20, %after_if18
  %262 = bitcast double %242 to i64
  %263 = and i64 %262, 9218868437227405312
  %264 = icmp eq i64 %263, 9218868437227405312
  br i1 %264, label %true_block23, label %after_if25

true_block23:                                     ; preds = %after_if22
  %265 = load ptr, ptr %28, align 8
  %266 = getelementptr i64, ptr %265, i64 19
  %267 = atomicrmw add ptr %266, i64 1 seq_cst, align 8
  br label %after_if25

after_if25:                                       ; preds = %true_block23, %after_if22
  %268 = select i1 %256, i64 %251, i64 0
  %269 = and i64 %268, 9218868437227405312
  %270 = icmp ne i64 %269, 9218868437227405312
  %271 = and i1 %256, %270
  %.op = and i64 %268, -17592186044416
  %272 = bitcast i64 %.op to double
  %273 = select i1 %271, double %272, double 0.000000e+00
  %274 = fsub double %273, %39
  %275 = load ptr, ptr %0, align 8
  %276 = getelementptr { { { i32, i32 }, ptr }, i32, double, { { i32 }, ptr }, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %275, i64 0, i32 6, i32 1
  %277 = load ptr, ptr %276, align 8
  %278 = getelementptr { { { i32, i32 }, ptr }, i32, double, { { i32 }, ptr }, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %275, i64 0, i32 6, i32 0, i32 1
  %279 = getelementptr double, ptr %277, i64 %37
  store double %274, ptr %279, align 8
  %280 = fdiv double %274, %82
  %281 = select i1 %247, double %280, double %43
  %282 = bitcast double %281 to i64
  %283 = and i64 %282, 9223372036854775807
  %284 = and i64 %282, 9218868437227405312
  %285 = icmp eq i64 %283, 0
  %286 = icmp ne i64 %284, 0
  %287 = icmp ne i64 %284, 9218868437227405312
  %288 = and i1 %286, %287
  %289 = or i1 %285, %288
  br i1 %289, label %after_if28, label %true_block26

true_block26:                                     ; preds = %after_if25
  %290 = load ptr, ptr %28, align 8
  %291 = getelementptr i64, ptr %290, i64 19
  %292 = atomicrmw add ptr %291, i64 1 seq_cst, align 8
  br label %after_if28

after_if28:                                       ; preds = %true_block26, %after_if25
  store double %281, ptr %42, align 8
  %293 = fcmp one double %273, %39
  store double %273, ptr %38, align 8
  %294 = fmul double %82, %244
  %295 = fadd double %46, %294
  %296 = fcmp one double %295, %46
  %297 = or i1 %250, %296
  %298 = bitcast double %295 to i64
  %299 = and i64 %298, 9223372036854775807
  %300 = and i64 %298, 9218868437227405312
  %301 = icmp eq i64 %299, 0
  %302 = icmp ne i64 %300, 0
  %303 = icmp ne i64 %300, 9218868437227405312
  %304 = and i1 %302, %303
  %305 = or i1 %301, %304
  br i1 %305, label %after_if31, label %true_block29

true_block29:                                     ; preds = %after_if28
  %306 = load ptr, ptr %28, align 8
  %307 = getelementptr i64, ptr %306, i64 19
  %308 = atomicrmw add ptr %307, i64 1 seq_cst, align 8
  br label %after_if31

after_if31:                                       ; preds = %true_block29, %after_if28
  %309 = bitcast double %244 to i64
  %310 = and i64 %309, 9218868437227405312
  %311 = icmp eq i64 %310, 9218868437227405312
  br i1 %311, label %true_block32, label %after_if34

true_block32:                                     ; preds = %after_if31
  %312 = load ptr, ptr %28, align 8
  %313 = getelementptr i64, ptr %312, i64 19
  %314 = atomicrmw add ptr %313, i64 1 seq_cst, align 8
  br label %after_if34

after_if34:                                       ; preds = %true_block32, %after_if31
  %315 = select i1 %303, i64 %298, i64 0
  %316 = and i64 %315, 9218868437227405312
  %317 = icmp ne i64 %316, 9218868437227405312
  %318 = and i1 %303, %317
  %.op8 = and i64 %315, -17592186044416
  %319 = bitcast i64 %.op8 to double
  %320 = select i1 %318, double %319, double 0.000000e+00
  %321 = fsub double %320, %46
  %322 = load ptr, ptr %276, align 8
  %323 = load i32, ptr %278, align 4
  %324 = sext i32 %323 to i64
  %325 = add nsw i64 %324, %37
  %326 = getelementptr double, ptr %322, i64 %325
  store double %321, ptr %326, align 8
  %327 = fdiv double %321, %82
  %328 = select i1 %247, double %327, double %50
  %329 = bitcast double %328 to i64
  %330 = and i64 %329, 9223372036854775807
  %331 = and i64 %329, 9218868437227405312
  %332 = icmp eq i64 %330, 0
  %333 = icmp ne i64 %331, 0
  %334 = icmp ne i64 %331, 9218868437227405312
  %335 = and i1 %333, %334
  %336 = or i1 %332, %335
  br i1 %336, label %after_if37, label %true_block35

true_block35:                                     ; preds = %after_if34
  %337 = load ptr, ptr %28, align 8
  %338 = getelementptr i64, ptr %337, i64 19
  %339 = atomicrmw add ptr %338, i64 1 seq_cst, align 8
  br label %after_if37

after_if37:                                       ; preds = %true_block35, %after_if34
  store double %328, ptr %49, align 8
  %340 = fcmp one double %320, %46
  %341 = or i1 %293, %340
  store double %320, ptr %45, align 8
  %342 = fmul double %82, %246
  %343 = fadd double %54, %342
  %344 = fcmp one double %343, %54
  %345 = or i1 %344, %297
  %346 = bitcast double %343 to i64
  %347 = and i64 %346, 9223372036854775807
  %348 = and i64 %346, 9218868437227405312
  %349 = icmp eq i64 %347, 0
  %350 = icmp ne i64 %348, 0
  %351 = icmp ne i64 %348, 9218868437227405312
  %352 = and i1 %350, %351
  %353 = or i1 %349, %352
  br i1 %353, label %after_if40, label %true_block38

true_block38:                                     ; preds = %after_if37
  %354 = load ptr, ptr %28, align 8
  %355 = getelementptr i64, ptr %354, i64 19
  %356 = atomicrmw add ptr %355, i64 1 seq_cst, align 8
  br label %after_if40

after_if40:                                       ; preds = %true_block38, %after_if37
  %357 = bitcast double %246 to i64
  %358 = and i64 %357, 9218868437227405312
  %359 = icmp eq i64 %358, 9218868437227405312
  br i1 %359, label %true_block41, label %after_if43

true_block41:                                     ; preds = %after_if40
  %360 = load ptr, ptr %28, align 8
  %361 = getelementptr i64, ptr %360, i64 19
  %362 = atomicrmw add ptr %361, i64 1 seq_cst, align 8
  br label %after_if43

after_if43:                                       ; preds = %true_block41, %after_if40
  %363 = select i1 %351, i64 %346, i64 0
  %364 = and i64 %363, 9218868437227405312
  %365 = icmp ne i64 %364, 9218868437227405312
  %366 = and i1 %351, %365
  %.op9 = and i64 %363, -17592186044416
  %367 = bitcast i64 %.op9 to double
  %368 = select i1 %366, double %367, double 0.000000e+00
  %369 = fsub double %368, %54
  %370 = load ptr, ptr %276, align 8
  %371 = load i32, ptr %278, align 4
  %372 = sext i32 %371 to i64
  %373 = shl nsw i64 %372, 1
  %374 = add nsw i64 %373, %37
  %375 = getelementptr double, ptr %370, i64 %374
  store double %369, ptr %375, align 8
  %376 = fdiv double %369, %82
  %377 = select i1 %247, double %376, double %58
  %378 = bitcast double %377 to i64
  %379 = and i64 %378, 9223372036854775807
  %380 = and i64 %378, 9218868437227405312
  %381 = icmp eq i64 %379, 0
  %382 = icmp ne i64 %380, 0
  %383 = icmp ne i64 %380, 9218868437227405312
  %384 = and i1 %382, %383
  %385 = or i1 %381, %384
  br i1 %385, label %after_if46, label %true_block44

true_block44:                                     ; preds = %after_if43
  %386 = load ptr, ptr %28, align 8
  %387 = getelementptr i64, ptr %386, i64 19
  %388 = atomicrmw add ptr %387, i64 1 seq_cst, align 8
  br label %after_if46

after_if46:                                       ; preds = %true_block44, %after_if43
  store double %377, ptr %57, align 8
  %389 = fcmp one double %368, %54
  %390 = or i1 %389, %341
  store double %368, ptr %53, align 8
  %391 = fmul double %281, %281
  %392 = fmul double %328, %328
  %393 = fadd double %391, %392
  %394 = fmul double %377, %377
  %395 = fadd double %394, %393
  %396 = tail call double @llvm.sqrt.f64(double %395)
  %397 = bitcast double %396 to i64
  %398 = and i64 %397, 9223372036854775807
  %399 = and i64 %397, 9218868437227405312
  %400 = icmp eq i64 %398, 0
  %401 = icmp ne i64 %399, 0
  %402 = icmp ne i64 %399, 9218868437227405312
  %403 = and i1 %401, %402
  %404 = or i1 %400, %403
  br i1 %404, label %after_if49, label %true_block47

true_block47:                                     ; preds = %after_if46
  %405 = load ptr, ptr %28, align 8
  %406 = getelementptr i64, ptr %405, i64 19
  %407 = atomicrmw add ptr %406, i64 1 seq_cst, align 8
  br label %after_if49

after_if49:                                       ; preds = %true_block47, %after_if46
  %408 = load ptr, ptr %0, align 8
  %409 = getelementptr { { { i32, i32 }, ptr }, i32, double, { { i32 }, ptr }, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %408, i64 0, i32 12, i32 1
  %410 = load ptr, ptr %409, align 8
  %411 = getelementptr double, ptr %410, i64 %37
  store double %396, ptr %411, align 8
  br i1 %390, label %after_if52, label %true_block50

true_block50:                                     ; preds = %after_if49
  %412 = load ptr, ptr %8, align 8
  %413 = getelementptr inbounds %struct.LLVMRuntime, ptr %412, i64 0, i32 7
  %414 = load ptr, ptr %413, align 8
  %415 = getelementptr inbounds ptr, ptr %414, i64 3
  %416 = load ptr, ptr %415, align 8
  %417 = shl i32 %10, 3
  %418 = and i32 %417, 1073741816
  %419 = zext i32 %418 to i64
  %420 = getelementptr i8, ptr %416, i64 %419
  %421 = getelementptr inbounds i8, ptr %420, i64 32
  %422 = load ptr, ptr %421, align 8
  %423 = icmp eq ptr %422, null
  br i1 %423, label %424, label %Pointer_lookup_element.exit12

424:                                              ; preds = %true_block50
  %425 = getelementptr inbounds %struct.LLVMRuntime, ptr %412, i64 0, i32 15
  %426 = load ptr, ptr %425, align 8
  %427 = getelementptr inbounds ptr, ptr %426, i64 24
  %428 = load ptr, ptr %427, align 8
  br label %Pointer_lookup_element.exit12

Pointer_lookup_element.exit12:                    ; preds = %424, %true_block50
  %.0.i11 = phi ptr [ %428, %424 ], [ %422, %true_block50 ]
  %429 = getelementptr inbounds i8, ptr %.0.i11, i64 32
  %430 = shl nuw i32 1, %9
  %431 = xor i32 %430, -1
  %432 = atomicrmw volatile and ptr %429, i32 %431 seq_cst, align 4
  br label %after_if52

after_if52:                                       ; preds = %Pointer_lookup_element.exit12, %after_if49
  br i1 %345, label %true_block53, label %after_if55

true_block53:                                     ; preds = %after_if52
  %433 = load ptr, ptr %28, align 8
  %434 = getelementptr i64, ptr %433, i64 18
  %435 = atomicrmw add ptr %434, i64 1 seq_cst, align 8
  br label %after_if55

after_if55:                                       ; preds = %true_block53, %after_if52
  br i1 %390, label %true_block56, label %loop_body_tail.sink.split

true_block56:                                     ; preds = %after_if55
  %436 = load ptr, ptr %0, align 8
  %437 = getelementptr { { { i32, i32 }, ptr }, i32, double, { { i32 }, ptr }, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %436, i64 0, i32 5, i32 1
  %438 = load ptr, ptr %437, align 8
  %439 = getelementptr { { { i32, i32 }, ptr }, i32, double, { { i32 }, ptr }, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %436, i64 0, i32 5, i32 0, i32 1
  %440 = getelementptr i32, ptr %438, i64 %37
  store i32 1, ptr %440, align 4
  %441 = load ptr, ptr %28, align 8
  %442 = getelementptr i64, ptr %441, i64 4
  %443 = atomicrmw add ptr %442, i64 1 seq_cst, align 8
  %444 = load ptr, ptr %0, align 8
  %445 = getelementptr { { { i32, i32 }, ptr }, i32, double, { { i32 }, ptr }, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %444, i64 0, i32 10, i32 1
  %446 = load ptr, ptr %445, align 8
  %447 = getelementptr { { { i32, i32 }, ptr }, i32, double, { { i32 }, ptr }, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %444, i64 0, i32 10, i32 0, i32 1
  %448 = load i32, ptr %447, align 4
  %449 = sext i32 %448 to i64
  %450 = getelementptr i32, ptr %446, i64 %37
  %451 = load i32, ptr %450, align 4
  %452 = add nsw i64 %449, %37
  %453 = getelementptr i32, ptr %446, i64 %452
  %454 = load i32, ptr %453, align 4
  %455 = load ptr, ptr %28, align 8
  %456 = getelementptr i64, ptr %455, i64 15
  %457 = icmp slt i32 %451, %454
  br i1 %457, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %true_block56
  %458 = getelementptr { { { i32, i32 }, ptr }, i32, double, { { i32 }, ptr }, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %444, i64 0, i32 11, i32 1
  %459 = getelementptr { { { i32, i32 }, ptr }, i32, double, { { i32 }, ptr }, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %444, i64 0, i32 9, i32 1
  %460 = getelementptr { { { i32, i32 }, ptr }, i32, double, { { i32 }, ptr }, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %444, i64 0, i32 9, i32 0, i32 1
  %461 = sext i32 %451 to i64
  %wide.trip.count = sext i32 %454 to i64
  br label %for_loop_body

for_loop_body:                                    ; preds = %Pointer_lookup_element.exit, %for_loop_body.lr.ph
  %indvars.iv = phi i64 [ %461, %for_loop_body.lr.ph ], [ %indvars.iv.next, %Pointer_lookup_element.exit ]
  %462 = load ptr, ptr %458, align 8
  %463 = getelementptr i32, ptr %462, i64 %indvars.iv
  %464 = load i32, ptr %463, align 4
  %465 = load ptr, ptr %459, align 8
  %466 = load i32, ptr %460, align 4
  %467 = sext i32 %466 to i64
  %468 = sext i32 %464 to i64
  %469 = add nsw i64 %467, %468
  %470 = getelementptr i32, ptr %465, i64 %469
  %471 = load i32, ptr %470, align 4
  %472 = sdiv i32 %471, 32
  %473 = load ptr, ptr %8, align 8
  %474 = getelementptr inbounds %struct.LLVMRuntime, ptr %473, i64 0, i32 7
  %475 = load ptr, ptr %474, align 8
  %476 = getelementptr inbounds ptr, ptr %475, i64 3
  %477 = load ptr, ptr %476, align 8
  %getch.i = getelementptr %1, ptr %477, i64 0, i32 1
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %5)
  %478 = shl nsw i32 %472, 3
  %479 = sext i32 %478 to i64
  %480 = getelementptr i8, ptr %getch.i, i64 %479
  store volatile ptr %480, ptr %5, align 8
  %481 = getelementptr inbounds i8, ptr %480, i64 32
  %482 = load volatile ptr, ptr %481, align 8
  %483 = icmp eq ptr %482, null
  br i1 %483, label %484, label %Pointer_activate.exit

484:                                              ; preds = %for_loop_body
  %.0..0..0..0..0..i = load volatile ptr, ptr %5, align 8
  %.0..0..0..0..0.2.i = load volatile ptr, ptr %5, align 8
  br label %485

485:                                              ; preds = %485, %484
  %486 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i, i32 1 seq_cst, align 4
  %487 = icmp eq i32 %486, 1
  br i1 %487, label %485, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i:                        ; preds = %485
  %488 = load volatile ptr, ptr %481, align 8
  %489 = icmp eq ptr %488, null
  br i1 %489, label %490, label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i"

490:                                              ; preds = %mutex_lock_i32.exit.i.i.i
  %491 = load ptr, ptr %8, align 8
  %492 = getelementptr inbounds %struct.LLVMRuntime, ptr %491, i64 0, i32 14
  %493 = load ptr, ptr %492, align 8
  %494 = getelementptr inbounds ptr, ptr %493, i64 27
  %495 = load ptr, ptr %494, align 8
  %496 = getelementptr inbounds %struct.NodeManager, ptr %495, i64 0, i32 4
  %497 = atomicrmw volatile add ptr %496, i32 1 seq_cst, align 4
  %498 = getelementptr inbounds %struct.NodeManager, ptr %495, i64 0, i32 5
  %499 = load ptr, ptr %498, align 8
  %500 = getelementptr inbounds %struct.ListManager, ptr %499, i64 0, i32 5
  %501 = load i32, ptr %500, align 8
  %.not.i.i.i.i.i = icmp slt i32 %497, %501
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i, label %502

502:                                              ; preds = %490
  %503 = getelementptr inbounds %struct.NodeManager, ptr %495, i64 0, i32 7
  %504 = load ptr, ptr %503, align 8
  %505 = getelementptr inbounds %struct.ListManager, ptr %504, i64 0, i32 5
  %506 = atomicrmw volatile add ptr %505, i32 1 seq_cst, align 4
  %507 = getelementptr inbounds %struct.ListManager, ptr %504, i64 0, i32 3
  %508 = load i32, ptr %507, align 8
  %509 = ashr i32 %506, %508
  %510 = icmp ugt i32 %509, 131071
  br i1 %510, label %511, label %514

511:                                              ; preds = %502
  %512 = getelementptr inbounds %struct.ListManager, ptr %504, i64 0, i32 6
  %513 = load ptr, ptr %512, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %513, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

514:                                              ; preds = %502
  %515 = zext i32 %509 to i64
  %516 = lshr i64 %515, 9
  %517 = getelementptr inbounds [256 x ptr], ptr %504, i64 0, i64 %516
  %518 = load atomic i64, ptr %517 acquire, align 8
  %.not.i.i.i4.i.i.i.i.i = icmp eq i64 %518, 0
  br i1 %.not.i.i.i4.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i:  ; preds = %514
  %519 = inttoptr i64 %518 to ptr
  %520 = and i64 %515, 511
  %521 = getelementptr inbounds ptr, ptr %519, i64 %520
  %522 = load atomic i64, ptr %521 acquire, align 8
  %.not.i.i5.i.i.i.i.i = icmp eq i64 %522, 0
  br i1 %.not.i.i5.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i, %514
  %523 = getelementptr inbounds %struct.ListManager, ptr %504, i64 0, i32 4
  br label %524

524:                                              ; preds = %524, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i
  %525 = atomicrmw volatile xchg ptr %523, i32 1 seq_cst, align 4
  %526 = icmp eq i32 %525, 1
  br i1 %526, label %524, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i:          ; preds = %524
  %527 = load atomic i64, ptr %517 acquire, align 8
  %528 = inttoptr i64 %527 to ptr
  %.not.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %527, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i, label %529, label %564

529:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i
  %530 = getelementptr inbounds %struct.ListManager, ptr %504, i64 0, i32 6
  %531 = load ptr, ptr %530, align 8
  %532 = getelementptr inbounds %struct.LLVMRuntime, ptr %531, i64 0, i32 1
  %533 = getelementptr inbounds %struct.LLVMRuntime, ptr %531, i64 0, i32 28
  %534 = atomicrmw volatile add ptr %533, i64 4096 seq_cst, align 8
  %535 = getelementptr inbounds %struct.LLVMRuntime, ptr %531, i64 0, i32 1, i32 2
  %536 = load i64, ptr %535, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %536, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i.i.i, label %557, label %537

537:                                              ; preds = %529
  %538 = getelementptr inbounds %struct.LLVMRuntime, ptr %531, i64 0, i32 26
  br label %539

539:                                              ; preds = %539, %537
  %540 = atomicrmw volatile xchg ptr %538, i32 1 seq_cst, align 4
  %541 = icmp eq i32 %540, 1
  br i1 %541, label %539, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i: ; preds = %539
  %542 = load ptr, ptr %532, align 8
  %543 = ptrtoint ptr %542 to i64
  %544 = getelementptr inbounds %struct.LLVMRuntime, ptr %531, i64 0, i32 1, i32 1
  %545 = load ptr, ptr %544, align 8
  %546 = ptrtoint ptr %545 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %543
  %547 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i, 4095
  %548 = or i64 %547, 4096
  %549 = add i64 %548, %543
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %549, %546
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i, label %550

550:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i
  %551 = add i64 %547, %543
  %552 = inttoptr i64 %551 to ptr
  %553 = getelementptr i8, ptr %542, i64 %547
  %554 = getelementptr inbounds i8, ptr %553, i64 4096
  store ptr %554, ptr %532, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i: ; preds = %550, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i ], [ %552, %550 ]
  %555 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i, true
  %556 = atomicrmw volatile xchg ptr %538, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %531, i1 noundef zeroext %555, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i

557:                                              ; preds = %529
  %558 = getelementptr inbounds %struct.LLVMRuntime, ptr %531, i64 0, i32 2
  %559 = load ptr, ptr %558, align 8
  %560 = getelementptr inbounds %struct.LLVMRuntime, ptr %531, i64 0, i32 6
  %561 = load ptr, ptr %560, align 8
  %562 = tail call noundef ptr %559(ptr noundef %561, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i: ; preds = %557, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i ], [ %562, %557 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %563 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %563, ptr %517 release, align 8
  br label %564

564:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %528, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i ]
  %565 = and i32 %509, 511
  %566 = zext i32 %565 to i64
  %567 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i.i.i, i64 %566
  %568 = load atomic i64, ptr %567 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %568, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i.i.i, label %569, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i"

569:                                              ; preds = %564
  %570 = getelementptr inbounds %struct.ListManager, ptr %504, i64 0, i32 6
  %571 = load ptr, ptr %570, align 8
  %572 = getelementptr inbounds %struct.LLVMRuntime, ptr %571, i64 0, i32 1
  %573 = getelementptr inbounds %struct.ListManager, ptr %504, i64 0, i32 2
  %574 = load i64, ptr %573, align 8
  %575 = getelementptr inbounds %struct.ListManager, ptr %504, i64 0, i32 1
  %576 = load i64, ptr %575, align 8
  %577 = mul i64 %576, %574
  %578 = getelementptr inbounds %struct.LLVMRuntime, ptr %571, i64 0, i32 28
  %579 = atomicrmw volatile add ptr %578, i64 %577 seq_cst, align 8
  %580 = getelementptr inbounds %struct.LLVMRuntime, ptr %571, i64 0, i32 1, i32 2
  %581 = load i64, ptr %580, align 8
  %.not.i.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %581, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i, label %601, label %582

582:                                              ; preds = %569
  %583 = getelementptr inbounds %struct.LLVMRuntime, ptr %571, i64 0, i32 26
  br label %584

584:                                              ; preds = %584, %582
  %585 = atomicrmw volatile xchg ptr %583, i32 1 seq_cst, align 4
  %586 = icmp eq i32 %585, 1
  br i1 %586, label %584, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i: ; preds = %584
  %587 = load ptr, ptr %572, align 8
  %588 = ptrtoint ptr %587 to i64
  %589 = getelementptr inbounds %struct.LLVMRuntime, ptr %571, i64 0, i32 1, i32 1
  %590 = load ptr, ptr %589, align 8
  %591 = ptrtoint ptr %590 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %588
  %592 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i, 4095
  %593 = add i64 %592, %577
  %594 = add i64 %593, %588
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %594, %591
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i, label %595

595:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %596 = add i64 %592, %588
  %597 = inttoptr i64 %596 to ptr
  %598 = getelementptr inbounds i8, ptr %587, i64 %593
  store ptr %598, ptr %572, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i: ; preds = %595, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %597, %595 ]
  %599 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %600 = atomicrmw volatile xchg ptr %583, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %571, i1 noundef zeroext %599, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i

601:                                              ; preds = %569
  %602 = getelementptr inbounds %struct.LLVMRuntime, ptr %571, i64 0, i32 2
  %603 = load ptr, ptr %602, align 8
  %604 = getelementptr inbounds %struct.LLVMRuntime, ptr %571, i64 0, i32 6
  %605 = load ptr, ptr %604, align 8
  %606 = tail call noundef ptr %603(ptr noundef %605, i64 noundef %577, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i: ; preds = %601, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i ], [ %606, %601 ]
  %607 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %607, ptr %567 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i, %564
  %608 = atomicrmw volatile xchg ptr %523, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i:      ; preds = %490
  %609 = getelementptr inbounds %struct.ListManager, ptr %499, i64 0, i32 3
  %610 = load i32, ptr %609, align 8
  %611 = ashr i32 %497, %610
  %612 = sext i32 %611 to i64
  %613 = lshr i64 %612, 9
  %614 = getelementptr inbounds [256 x ptr], ptr %499, i64 0, i64 %613
  %615 = load atomic i64, ptr %614 acquire, align 8
  %.not.i.i.i.i.i.i.i.i = icmp ne i64 %615, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i.i.i.i.i)
  %616 = inttoptr i64 %615 to ptr
  %617 = and i64 %612, 511
  %618 = getelementptr inbounds ptr, ptr %616, i64 %617
  %619 = load atomic i64, ptr %618 acquire, align 8
  %620 = inttoptr i64 %619 to ptr
  %621 = getelementptr inbounds %struct.ListManager, ptr %499, i64 0, i32 1
  %622 = load i64, ptr %621, align 8
  %623 = load i32, ptr %609, align 8
  %notmask.i.i.i.i.i.i.i = shl nsw i32 -1, %623
  %624 = xor i32 %notmask.i.i.i.i.i.i.i, -1
  %625 = and i32 %497, %624
  %626 = sext i32 %625 to i64
  %627 = mul i64 %622, %626
  %628 = getelementptr inbounds i8, ptr %620, i64 %627
  %629 = load i32, ptr %628, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i: ; preds = %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i, %511
  %.0.i.i.i.i.i = phi i32 [ %629, %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i ], [ %506, %511 ], [ %506, %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i ], [ %506, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i" ]
  %630 = getelementptr inbounds %struct.NodeManager, ptr %495, i64 0, i32 7
  %631 = load ptr, ptr %630, align 8
  %632 = getelementptr inbounds %struct.ListManager, ptr %631, i64 0, i32 3
  %633 = load i32, ptr %632, align 8
  %634 = ashr i32 %.0.i.i.i.i.i, %633
  %635 = sext i32 %634 to i64
  %636 = lshr i64 %635, 9
  %637 = getelementptr inbounds [256 x ptr], ptr %631, i64 0, i64 %636
  %638 = load atomic i64, ptr %637 acquire, align 8
  %.not.i.i.i.i.i.i.i = icmp eq i64 %638, 0
  br i1 %.not.i.i.i.i.i.i.i, label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i", label %639

639:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i
  %640 = inttoptr i64 %638 to ptr
  %641 = and i64 %635, 511
  %642 = getelementptr inbounds ptr, ptr %640, i64 %641
  %643 = load atomic i64, ptr %642 acquire, align 8
  %644 = inttoptr i64 %643 to ptr
  br label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i"

"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i":    ; preds = %639, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i
  %645 = phi ptr [ %644, %639 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i ]
  %646 = getelementptr inbounds %struct.ListManager, ptr %631, i64 0, i32 1
  %647 = load i64, ptr %646, align 8
  %648 = load i32, ptr %632, align 8
  %notmask.i.i.i.i.i.i = shl nsw i32 -1, %648
  %649 = xor i32 %notmask.i.i.i.i.i.i, -1
  %650 = and i32 %.0.i.i.i.i.i, %649
  %651 = sext i32 %650 to i64
  %652 = mul i64 %647, %651
  %653 = getelementptr inbounds i8, ptr %645, i64 %652
  %654 = ptrtoint ptr %653 to i64
  %655 = atomicrmw volatile xchg ptr %481, i64 %654 seq_cst, align 8
  br label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i"

"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i": ; preds = %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i", %mutex_lock_i32.exit.i.i.i
  %656 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i, i32 0 seq_cst, align 4
  br label %Pointer_activate.exit

Pointer_activate.exit:                            ; preds = %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i", %for_loop_body
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5)
  %657 = lshr i32 %471, 2
  %658 = and i32 %657, 1073741816
  %659 = zext i32 %658 to i64
  %660 = getelementptr i8, ptr %getch.i, i64 %659
  %661 = getelementptr inbounds i8, ptr %660, i64 32
  %662 = load ptr, ptr %661, align 8
  %663 = icmp eq ptr %662, null
  br i1 %663, label %664, label %Pointer_lookup_element.exit

664:                                              ; preds = %Pointer_activate.exit
  %665 = load ptr, ptr %8, align 8
  %666 = getelementptr inbounds %struct.LLVMRuntime, ptr %665, i64 0, i32 15
  %667 = load ptr, ptr %666, align 8
  %668 = getelementptr inbounds ptr, ptr %667, i64 27
  %669 = load ptr, ptr %668, align 8
  br label %Pointer_lookup_element.exit

Pointer_lookup_element.exit:                      ; preds = %664, %Pointer_activate.exit
  %.0.i = phi ptr [ %669, %664 ], [ %662, %Pointer_activate.exit ]
  %670 = and i32 %471, 31
  %671 = getelementptr inbounds i8, ptr %.0.i, i64 32
  %672 = shl nuw i32 1, %670
  %673 = atomicrmw volatile or ptr %671, i32 %672 seq_cst, align 4
  %674 = atomicrmw add ptr %456, i64 1 seq_cst, align 8
  %indvars.iv.next = add nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %indvars.iv.next, %wide.trip.count
  br i1 %exitcond.not, label %after_for.loopexit, label %for_loop_body, !llvm.loop !12

after_for.loopexit:                               ; preds = %Pointer_lookup_element.exit
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %true_block56
  %675 = load ptr, ptr %437, align 8
  %676 = load i32, ptr %439, align 4
  %677 = sext i32 %676 to i64
  %678 = add nsw i64 %677, %37
  %679 = getelementptr i32, ptr %675, i64 %678
  %680 = load i32, ptr %679, align 4
  %681 = icmp eq i32 %680, 0
  br i1 %681, label %loop_body_tail.sink.split, label %loop_body_tail
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.sqrt.f64(double) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.maxnum.f64(double, double) #2

; Function Attrs: argmemonly mustprogress nofree norecurse nosync nounwind willreturn
define internal fastcc void @S24_refine_coordinates(ptr nocapture readonly %0, ptr nocapture writeonly %1, i32 %2) unnamed_addr #3 {
entry:
  %3 = and i32 %2, 3
  %4 = load i32, ptr %0, align 4
  %5 = shl i32 %4, 2
  %6 = or i32 %5, %3
  store i32 %6, ptr %1, align 4
  %7 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 1
  %8 = load i32, ptr %7, align 4
  %9 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 1
  store i32 %8, ptr %9, align 4
  %10 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 2
  %11 = load i32, ptr %10, align 4
  %12 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 2
  store i32 %11, ptr %12, align 4
  %13 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 3
  %14 = load i32, ptr %13, align 4
  %15 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 3
  store i32 %14, ptr %15, align 4
  %16 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 4
  %17 = load i32, ptr %16, align 4
  %18 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 4
  store i32 %17, ptr %18, align 4
  %19 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 5
  %20 = load i32, ptr %19, align 4
  %21 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 5
  store i32 %20, ptr %21, align 4
  %22 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 6
  %23 = load i32, ptr %22, align 4
  %24 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 6
  store i32 %23, ptr %24, align 4
  %25 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 7
  %26 = load i32, ptr %25, align 4
  %27 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 7
  store i32 %26, ptr %27, align 4
  %28 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 8
  %29 = load i32, ptr %28, align 4
  %30 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 8
  store i32 %29, ptr %30, align 4
  %31 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 9
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 9
  store i32 %32, ptr %33, align 4
  %34 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 10
  %35 = load i32, ptr %34, align 4
  %36 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 10
  store i32 %35, ptr %36, align 4
  %37 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 11
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 11
  store i32 %38, ptr %39, align 4
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree nounwind willreturn writeonly
declare double @exp(double noundef) local_unnamed_addr #4

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #5

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn writeonly
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #6

; Function Attrs: noinline nounwind optnone uwtable
define internal fastcc void @taichi_assert_format(ptr noundef %0, i1 noundef zeroext %1, ptr noundef %2) unnamed_addr #7 {
  %4 = alloca ptr, align 8
  %5 = alloca i8, align 1
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca ptr, align 8
  %9 = alloca %class.anon, align 8
  store ptr %0, ptr %4, align 8
  %10 = zext i1 %1 to i8
  store i8 %10, ptr %5, align 1
  store ptr %2, ptr %6, align 8
  store i32 0, ptr %7, align 4
  store ptr null, ptr %8, align 8
  %11 = load i8, ptr %5, align 1
  %12 = trunc i8 %11 to i1
  %13 = zext i1 %12 to i32
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %15, label %16

15:                                               ; preds = %3
  br label %69

16:                                               ; preds = %3
  %17 = load ptr, ptr %4, align 8
  %18 = getelementptr inbounds %struct.LLVMRuntime, ptr %17, i32 0, i32 24
  %19 = load i64, ptr %18, align 8
  %20 = icmp ne i64 %19, 0
  br i1 %20, label %69, label %21

21:                                               ; preds = %16
  %22 = load ptr, ptr %4, align 8
  %23 = getelementptr inbounds %struct.LLVMRuntime, ptr %22, i32 0, i32 23
  %24 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 0
  store ptr %4, ptr %24, align 8
  %25 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 1
  store ptr %6, ptr %25, align 8
  %26 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 2
  store ptr %7, ptr %26, align 8
  %27 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 3
  store ptr %8, ptr %27, align 8
  br label %28

28:                                               ; preds = %28, %21
  %29 = atomicrmw volatile xchg ptr %23, i32 1 seq_cst, align 4
  %30 = icmp eq i32 %29, 1
  br i1 %30, label %28, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i:                        ; preds = %28
  %31 = load ptr, ptr %9, align 8
  %32 = load ptr, ptr %31, align 8
  %33 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 24
  %34 = load i64, ptr %33, align 8
  %.not.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i, label %35, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

35:                                               ; preds = %mutex_lock_i32.exit.i.i.i
  store i64 1, ptr %33, align 8
  %36 = load ptr, ptr %9, align 8
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr inbounds %struct.LLVMRuntime, ptr %37, i64 0, i32 21
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %38, i8 0, i64 2048, i1 false)
  %39 = load ptr, ptr %9, align 8
  %40 = load ptr, ptr %39, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 21
  %42 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 1
  %43 = load ptr, ptr %42, align 8
  %44 = load ptr, ptr %43, align 8
  %45 = load i8, ptr %44, align 1
  %.not5.i.i.i.i.i = icmp eq i8 %45, 0
  br i1 %.not5.i.i.i.i.i, label %taichi_strlen.exit.thread.i.i.i.i, label %.lr.ph.i.i.i.i.i.preheader

.lr.ph.i.i.i.i.i.preheader:                       ; preds = %35
  br label %.lr.ph.i.i.i.i.i

.lr.ph.i.i.i.i.i:                                 ; preds = %.lr.ph.i.i.i.i.i, %.lr.ph.i.i.i.i.i.preheader
  %.07.i.i.i.i.i = phi ptr [ %47, %.lr.ph.i.i.i.i.i ], [ %44, %.lr.ph.i.i.i.i.i.preheader ]
  %.046.i.i.i.i.i = phi i64 [ %46, %.lr.ph.i.i.i.i.i ], [ 0, %.lr.ph.i.i.i.i.i.preheader ]
  %46 = add i64 %.046.i.i.i.i.i, 1
  %47 = getelementptr inbounds i8, ptr %.07.i.i.i.i.i, i64 1
  %48 = load i8, ptr %47, align 1
  %.not.i.i.i.i.i = icmp eq i8 %48, 0
  br i1 %.not.i.i.i.i.i, label %taichi_strlen.exit.i.i.i.i, label %.lr.ph.i.i.i.i.i, !llvm.loop !13

taichi_strlen.exit.i.i.i.i:                       ; preds = %.lr.ph.i.i.i.i.i
  %.lcssa = phi i64 [ %46, %.lr.ph.i.i.i.i.i ]
  %49 = call i64 @llvm.umin.i64(i64 %.lcssa, i64 2047)
  br label %taichi_strlen.exit.thread.i.i.i.i

taichi_strlen.exit.thread.i.i.i.i:                ; preds = %taichi_strlen.exit.i.i.i.i, %35
  %50 = phi i64 [ 0, %35 ], [ %49, %taichi_strlen.exit.i.i.i.i ]
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %41, ptr nonnull align 1 %44, i64 %50, i1 false)
  %51 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 2
  %52 = load ptr, ptr %51, align 8
  %53 = load i32, ptr %52, align 4
  %54 = icmp sgt i32 %53, 0
  br i1 %54, label %.lr.ph.i.i.i.i, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

.lr.ph.i.i.i.i:                                   ; preds = %taichi_strlen.exit.thread.i.i.i.i
  %55 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 3
  br label %56

56:                                               ; preds = %56, %.lr.ph.i.i.i.i
  %indvars.iv.i.i.i.i = phi i64 [ 0, %.lr.ph.i.i.i.i ], [ %indvars.iv.next.i.i.i.i, %56 ]
  %57 = load ptr, ptr %55, align 8
  %58 = load ptr, ptr %57, align 8
  %59 = getelementptr inbounds i64, ptr %58, i64 %indvars.iv.i.i.i.i
  %60 = load i64, ptr %59, align 8
  %61 = load ptr, ptr %9, align 8
  %62 = load ptr, ptr %61, align 8
  %63 = getelementptr inbounds %struct.LLVMRuntime, ptr %62, i64 0, i32 22, i64 %indvars.iv.i.i.i.i
  store i64 %60, ptr %63, align 8
  %indvars.iv.next.i.i.i.i = add nuw nsw i64 %indvars.iv.i.i.i.i, 1
  %64 = load ptr, ptr %51, align 8
  %65 = load i32, ptr %64, align 4
  %66 = sext i32 %65 to i64
  %67 = icmp slt i64 %indvars.iv.next.i.i.i.i, %66
  br i1 %67, label %56, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", !llvm.loop !14

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit": ; preds = %56
  br label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit": ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", %taichi_strlen.exit.thread.i.i.i.i, %mutex_lock_i32.exit.i.i.i
  %68 = atomicrmw volatile xchg ptr %23, i32 0 seq_cst, align 4
  br label %69

69:                                               ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit", %16, %15
  ret void
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_struct_for_block_helper(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #8 {
_ZN11ListManager3getI7ElementEERT_i.exit:
  %3 = alloca %struct.RuntimeContext.716, align 8
  %4 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 4
  %5 = load i32, ptr %4, align 4
  %6 = sdiv i32 %2, %5
  %7 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  %8 = load i32, ptr %7, align 8
  %9 = sdiv i32 %8, %5
  %10 = srem i32 %2, %5
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  %12 = load ptr, ptr %11, align 8
  %13 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %14 = load i32, ptr %13, align 8
  %15 = ashr i32 %6, %14
  %16 = sext i32 %15 to i64
  %17 = lshr i64 %16, 9
  %18 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %17
  %19 = load atomic i64, ptr %18 acquire, align 8
  %.not.i.i.i = icmp ne i64 %19, 0
  tail call void @llvm.assume(i1 %.not.i.i.i)
  %20 = inttoptr i64 %19 to ptr
  %21 = and i64 %16, 511
  %22 = getelementptr inbounds ptr, ptr %20, i64 %21
  %23 = load atomic i64, ptr %22 acquire, align 8
  %24 = inttoptr i64 %23 to ptr
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %26 = load i64, ptr %25, align 8
  %27 = load i32, ptr %13, align 8
  %notmask.i.i = shl nsw i32 -1, %27
  %28 = xor i32 %notmask.i.i, -1
  %29 = and i32 %6, %28
  %30 = sext i32 %29 to i64
  %31 = mul i64 %26, %30
  %32 = getelementptr inbounds i8, ptr %24, i64 %31
  %33 = getelementptr inbounds %0, ptr %32, i64 0, i32 1
  %34 = load i32, ptr %33, align 8
  %35 = mul nsw i32 %10, %9
  %36 = add nsw i32 %34, %35
  %37 = add nsw i32 %10, 1
  %38 = mul nsw i32 %37, %9
  %39 = add nsw i32 %34, %38
  %40 = getelementptr inbounds %0, ptr %32, i64 0, i32 1, i64 1
  %41 = load i32, ptr %40, align 4
  %42 = tail call i32 @llvm.smin.i32(i32 %41, i32 %39)
  %43 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  %44 = load i64, ptr %43, align 8
  %45 = alloca i8, i64 %44, align 8
  %46 = load ptr, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %3, ptr noundef nonnull align 8 dereferenceable(32) %46, i64 32, i1 false)
  %47 = getelementptr inbounds %struct.RuntimeContext.716, ptr %3, i64 0, i32 2
  store i32 %1, ptr %47, align 8
  %48 = icmp slt i32 %36, %42
  br i1 %48, label %49, label %75

49:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit
  %50 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = load ptr, ptr %11, align 8
  %53 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 3
  %54 = load i32, ptr %53, align 8
  %55 = ashr i32 %6, %54
  %56 = sext i32 %55 to i64
  %57 = lshr i64 %56, 9
  %58 = getelementptr inbounds [256 x ptr], ptr %52, i64 0, i64 %57
  %59 = load atomic i64, ptr %58 acquire, align 8
  %.not.i.i.i24 = icmp eq i64 %59, 0
  br i1 %.not.i.i.i24, label %_ZN11ListManager3getI7ElementEERT_i.exit26, label %60

60:                                               ; preds = %49
  %61 = inttoptr i64 %59 to ptr
  %62 = and i64 %56, 511
  %63 = getelementptr inbounds ptr, ptr %61, i64 %62
  %64 = load atomic i64, ptr %63 acquire, align 8
  %65 = inttoptr i64 %64 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit26

_ZN11ListManager3getI7ElementEERT_i.exit26:       ; preds = %60, %49
  %66 = phi ptr [ %65, %60 ], [ null, %49 ]
  %67 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 1
  %68 = load i64, ptr %67, align 8
  %69 = load i32, ptr %53, align 8
  %notmask.i.i25 = shl nsw i32 -1, %69
  %70 = xor i32 %notmask.i.i25, -1
  %71 = and i32 %6, %70
  %72 = sext i32 %71 to i64
  %73 = mul i64 %68, %72
  %74 = getelementptr inbounds i8, ptr %66, i64 %73
  call void %51(ptr noundef nonnull %3, ptr noundef nonnull %45, ptr noundef nonnull %74, i32 noundef %36, i32 noundef %42) #1
  br label %75

75:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit26, %_ZN11ListManager3getI7ElementEERT_i.exit
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i64 @llvm.umin.i64(i64, i64) #9

; Function Attrs: inaccessiblememonly nocallback nofree nosync nounwind willreturn
declare void @llvm.assume(i1 noundef) #10

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #9

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #11

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #11

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #3 = { argmemonly mustprogress nofree norecurse nosync nounwind willreturn }
attributes #4 = { alwaysinline mustprogress nofree nounwind willreturn writeonly "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #6 = { argmemonly mustprogress nocallback nofree nounwind willreturn writeonly }
attributes #7 = { noinline nounwind optnone uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #10 = { inaccessiblememonly nocallback nofree nosync nounwind willreturn }
attributes #11 = { argmemonly nocallback nofree nosync nounwind willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7, !8}
!7 = !{!"llvm.loop.mustprogress"}
!8 = !{!"llvm.loop.unroll.disable"}
!9 = distinct !{!9, !7, !8}
!10 = distinct !{!10, !7, !8}
!11 = distinct !{!11, !7, !8}
!12 = distinct !{!12, !8}
!13 = distinct !{!13, !7, !8}
!14 = distinct !{!14, !7, !8}
