; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct.RuntimeContext.2253 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }
%struct.range_task_helper_context = type { ptr, ptr, ptr, ptr, i64, i32, i32, i32, i32 }

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @geometry_finalize_35_selection_55_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %0, i64 0, i32 9
  %2 = load i32, ptr %1, align 4
  %3 = getelementptr inbounds %struct.RuntimeContext.2253, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 4
  store i32 %2, ptr %7, align 4
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %0, i64 0, i32 8, i32 1
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr i64, ptr %9, i64 3
  %11 = load i64, ptr %10, align 8
  %12 = trunc i64 %11 to i32
  %13 = load ptr, ptr %3, align 8
  %14 = getelementptr inbounds %struct.LLVMRuntime, ptr %13, i64 0, i32 16
  %15 = load ptr, ptr %14, align 8
  store i32 %12, ptr %15, align 4
  ret void
}

; Function Attrs: nounwind
define void @geometry_finalize_35_selection_55_kernel_1_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.2253, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = getelementptr inbounds %struct.RuntimeContext.2253, ptr %0, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  %7 = load i32, ptr %6, align 4
  %8 = tail call i32 @llvm.smax.i32(i32 %7, i32 512)
  %9 = mul i32 %8, %2
  %10 = add i32 %9, %8
  %11 = tail call i32 @llvm.smin.i32(i32 %7, i32 %10)
  %12 = icmp slt i32 %9, %11
  br i1 %12, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %13 = load ptr, ptr %0, align 8
  %14 = getelementptr { { i32, i32 }, ptr }, ptr %13, i64 0, i32 1
  %15 = getelementptr { { i32, i32 }, ptr }, ptr %13, i64 0, i32 0, i32 1
  %16 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %13, i64 0, i32 3, i32 1
  %17 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %13, i64 0, i32 1, i32 1
  %18 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %13, i64 0, i32 1, i32 0, i32 1
  %19 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %13, i64 0, i32 2, i32 1
  %20 = sext i32 %9 to i64
  %wide.trip.count18 = sext i32 %11 to i64
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_for3, %for_loop_body.lr.ph
  %indvars.iv15 = phi i64 [ %20, %for_loop_body.lr.ph ], [ %indvars.iv.next16, %after_for3 ]
  %21 = load ptr, ptr %14, align 8
  %22 = load i32, ptr %15, align 4
  %23 = sext i32 %22 to i64
  %24 = mul nsw i64 %23, 3
  %25 = add nsw i64 %24, %indvars.iv15
  %26 = getelementptr i32, ptr %21, i64 %25
  %27 = load i32, ptr %26, align 4
  %28 = sext i32 %27 to i64
  %29 = load ptr, ptr %3, align 8
  %30 = getelementptr inbounds %struct.LLVMRuntime, ptr %29, i64 0, i32 16
  %31 = load ptr, ptr %30, align 8
  %32 = getelementptr inbounds i8, ptr %31, i64 4
  %33 = load i32, ptr %32, align 4
  %34 = sext i32 %33 to i64
  %35 = add nsw i64 %indvars.iv15, %34
  %36 = icmp slt i32 %27, 0
  %37 = select i1 %36, i64 %35, i64 %28
  %38 = load i32, ptr %6, align 4
  %39 = icmp sgt i32 %38, 0
  br i1 %39, label %for_loop_body1.preheader, label %after_for3

for_loop_body1.preheader:                         ; preds = %for_loop_body
  %wide.trip.count = zext i32 %38 to i64
  %min.iters.check = icmp ult i32 %38, 8
  br i1 %min.iters.check, label %for_loop_body1.preheader22, label %vector.ph

vector.ph:                                        ; preds = %for_loop_body1.preheader
  %n.vec = and i64 %wide.trip.count, 4294967288
  %broadcast.splatinsert = insertelement <8 x i64> poison, i64 %34, i64 0
  %broadcast.splat = shufflevector <8 x i64> %broadcast.splatinsert, <8 x i64> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert20 = insertelement <8 x i64> poison, i64 %37, i64 0
  %broadcast.splat21 = shufflevector <8 x i64> %broadcast.splatinsert20, <8 x i64> poison, <8 x i32> zeroinitializer
  %40 = mul nsw i64 %23, 12
  %uglygep = getelementptr i8, ptr %21, i64 %40
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %vec.ind = phi <8 x i64> [ <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, %vector.ph ], [ %vec.ind.next, %vector.body ]
  %vec.phi = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %48, %vector.body ]
  %41 = shl nuw nsw i64 %index, 2
  %uglygep25 = getelementptr i8, ptr %uglygep, i64 %41
  %wide.load = load <8 x i32>, ptr %uglygep25, align 4
  %42 = sext <8 x i32> %wide.load to <8 x i64>
  %43 = add nsw <8 x i64> %vec.ind, %broadcast.splat
  %44 = icmp slt <8 x i32> %wide.load, zeroinitializer
  %45 = select <8 x i1> %44, <8 x i64> %43, <8 x i64> %42
  %46 = icmp slt <8 x i64> %45, %broadcast.splat21
  %47 = zext <8 x i1> %46 to <8 x i32>
  %48 = add <8 x i32> %vec.phi, %47
  %index.next = add nuw nsw i64 %index, 8
  %vec.ind.next = add <8 x i64> %vec.ind, <i64 8, i64 8, i64 8, i64 8, i64 8, i64 8, i64 8, i64 8>
  %49 = icmp eq i64 %n.vec, %index.next
  br i1 %49, label %middle.block, label %vector.body, !llvm.loop !6

middle.block:                                     ; preds = %vector.body
  %50 = call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %48)
  %cmp.n = icmp eq i64 %n.vec, %wide.trip.count
  br i1 %cmp.n, label %after_for3, label %for_loop_body1.preheader22

for_loop_body1.preheader22:                       ; preds = %middle.block, %for_loop_body1.preheader
  %indvars.iv.ph = phi i64 [ 0, %for_loop_body1.preheader ], [ %n.vec, %middle.block ]
  %.0911.ph = phi i32 [ 0, %for_loop_body1.preheader ], [ %50, %middle.block ]
  %51 = mul nsw i64 %23, 12
  %uglygep26 = getelementptr i8, ptr %21, i64 %51
  br label %for_loop_body1

after_for.loopexit:                               ; preds = %after_for3
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %allocs
  ret void

for_loop_body1:                                   ; preds = %for_loop_body1, %for_loop_body1.preheader22
  %indvars.iv = phi i64 [ %indvars.iv.next, %for_loop_body1 ], [ %indvars.iv.ph, %for_loop_body1.preheader22 ]
  %.0911 = phi i32 [ %60, %for_loop_body1 ], [ %.0911.ph, %for_loop_body1.preheader22 ]
  %52 = shl i64 %indvars.iv, 2
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 %52
  %53 = load i32, ptr %uglygep27, align 4
  %54 = sext i32 %53 to i64
  %55 = add i64 %34, %indvars.iv
  %56 = icmp slt i32 %53, 0
  %57 = select i1 %56, i64 %55, i64 %54
  %58 = icmp slt i64 %57, %37
  %59 = zext i1 %58 to i32
  %60 = add i32 %.0911, %59
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %wide.trip.count, %indvars.iv.next
  br i1 %exitcond.not, label %after_for3.loopexit, label %for_loop_body1, !llvm.loop !9

after_for3.loopexit:                              ; preds = %for_loop_body1
  br label %after_for3

after_for3:                                       ; preds = %after_for3.loopexit, %middle.block, %for_loop_body
  %.09.lcssa = phi i32 [ 0, %for_loop_body ], [ %50, %middle.block ], [ %60, %after_for3.loopexit ]
  %61 = load ptr, ptr %16, align 8
  %62 = getelementptr i32, ptr %61, i64 %indvars.iv15
  store i32 %.09.lcssa, ptr %62, align 4
  %63 = load ptr, ptr %14, align 8
  %64 = getelementptr i32, ptr %63, i64 %indvars.iv15
  %65 = load i32, ptr %64, align 4
  %66 = load ptr, ptr %17, align 8
  %67 = sext i32 %.09.lcssa to i64
  %68 = getelementptr i32, ptr %66, i64 %67
  store i32 %65, ptr %68, align 4
  %69 = load ptr, ptr %14, align 8
  %70 = load i32, ptr %15, align 4
  %71 = sext i32 %70 to i64
  %72 = add nsw i64 %indvars.iv15, %71
  %73 = getelementptr i32, ptr %69, i64 %72
  %74 = load i32, ptr %73, align 4
  %75 = load ptr, ptr %17, align 8
  %76 = load i32, ptr %18, align 4
  %77 = sext i32 %76 to i64
  %78 = add nsw i64 %77, %67
  %79 = getelementptr i32, ptr %75, i64 %78
  store i32 %74, ptr %79, align 4
  %80 = load ptr, ptr %14, align 8
  %81 = load i32, ptr %15, align 4
  %82 = sext i32 %81 to i64
  %83 = shl nsw i64 %82, 1
  %84 = add nsw i64 %83, %indvars.iv15
  %85 = getelementptr i32, ptr %80, i64 %84
  %86 = load i32, ptr %85, align 4
  %87 = load ptr, ptr %19, align 8
  %88 = getelementptr i32, ptr %87, i64 %67
  store i32 %86, ptr %88, align 4
  %indvars.iv.next16 = add nsw i64 %indvars.iv15, 1
  %exitcond19.not = icmp eq i64 %indvars.iv.next16, %wide.trip.count18
  br i1 %exitcond19.not, label %after_for.loopexit, label %for_loop_body, !llvm.loop !10
}

; Function Attrs: nounwind
define void @geometry_finalize_35_selection_55_kernel_2_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.1, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.2253, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.1(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = getelementptr inbounds %struct.RuntimeContext.2253, ptr %0, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 4
  %8 = load i32, ptr %7, align 4
  %9 = tail call i32 @llvm.smax.i32(i32 %8, i32 512)
  %10 = mul i32 %9, %2
  %11 = add i32 %10, %9
  %12 = tail call i32 @llvm.smin.i32(i32 %8, i32 %11)
  %13 = icmp slt i32 %10, %12
  br i1 %13, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %14 = load ptr, ptr %0, align 8
  %15 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %14, i64 0, i32 4, i32 1
  %16 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %14, i64 0, i32 3, i32 1
  %17 = sext i32 %10 to i64
  %wide.trip.count = sext i32 %12 to i64
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.lr.ph
  %indvars.iv = phi i64 [ %17, %for_loop_body.lr.ph ], [ %indvars.iv.next, %for_loop_body ]
  %18 = load ptr, ptr %15, align 8
  %19 = shl i64 %indvars.iv, 2
  %uglygep = getelementptr i8, ptr %18, i64 %19
  %20 = load i32, ptr %uglygep, align 4
  %21 = load ptr, ptr %16, align 8
  %22 = sext i32 %20 to i64
  %23 = getelementptr i32, ptr %21, i64 %22
  %24 = load i32, ptr %23, align 4
  store i32 %24, ptr %uglygep, align 4
  %indvars.iv.next = add nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %wide.trip.count, %indvars.iv.next
  br i1 %exitcond.not, label %after_for.loopexit, label %for_loop_body, !llvm.loop !11

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @geometry_finalize_35_selection_55_kernel_3_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.2, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.2253, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.2(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %7, i64 0, i32 5, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %7, i64 0, i32 5, i32 0, i32 1
  %10 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.lr.ph
  %indvars.iv = phi i64 [ %10, %for_loop_body.lr.ph ], [ %indvars.iv.next, %for_loop_body ]
  %11 = load ptr, ptr %8, align 8
  %12 = shl i64 %indvars.iv, 2
  %uglygep = getelementptr i8, ptr %11, i64 %12
  store i32 0, ptr %uglygep, align 4
  %13 = load ptr, ptr %8, align 8
  %14 = load i32, ptr %9, align 4
  %15 = sext i32 %14 to i64
  %16 = add nsw i64 %indvars.iv, %15
  %17 = getelementptr i32, ptr %13, i64 %16
  store i32 0, ptr %17, align 4
  %18 = load ptr, ptr %8, align 8
  %19 = load i32, ptr %9, align 4
  %20 = sext i32 %19 to i64
  %21 = shl nsw i64 %20, 3
  %uglygep6 = getelementptr i8, ptr %18, i64 %21
  %uglygep7 = getelementptr i8, ptr %uglygep6, i64 %12
  store i32 0, ptr %uglygep7, align 4
  %22 = load ptr, ptr %8, align 8
  %23 = load i32, ptr %9, align 4
  %24 = sext i32 %23 to i64
  %25 = mul nsw i64 %24, 12
  %uglygep8 = getelementptr i8, ptr %22, i64 %25
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %12
  store i32 0, ptr %uglygep9, align 4
  %indvars.iv.next = add nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %wide.trip.count, %indvars.iv.next
  br i1 %exitcond.not, label %after_for.loopexit, label %for_loop_body, !llvm.loop !12

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %allocs
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind
define void @geometry_finalize_35_selection_55_kernel_4_serial(ptr nocapture readonly %context) local_unnamed_addr #3 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.2253, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 16
  %3 = load ptr, ptr %2, align 8
  %4 = load i32, ptr %3, align 4
  %5 = icmp sgt i32 %4, 0
  br i1 %5, label %for_loop_body.preheader, label %for_loop_body1.preheader

for_loop_body.preheader:                          ; preds = %entry
  %wide.trip.count38 = zext i32 %4 to i64
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %indvars.iv35 = phi i64 [ 0, %for_loop_body.preheader ], [ %indvars.iv.next36, %for_loop_body ]
  %6 = load ptr, ptr %context, align 8
  %7 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %6, i64 0, i32 1, i32 1
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %6, i64 0, i32 1, i32 0, i32 1
  %10 = shl nuw nsw i64 %indvars.iv35, 2
  %uglygep47 = getelementptr i8, ptr %8, i64 %10
  %11 = load i32, ptr %uglygep47, align 4
  %12 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %6, i64 0, i32 5, i32 1
  %13 = load ptr, ptr %12, align 8
  %14 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %6, i64 0, i32 5, i32 0, i32 1
  %15 = load i32, ptr %14, align 4
  %16 = sext i32 %15 to i64
  %17 = sext i32 %11 to i64
  %18 = add nsw i64 %16, %17
  %19 = getelementptr i32, ptr %13, i64 %18
  %20 = load i32, ptr %19, align 4
  %21 = add i32 %20, 1
  store i32 %21, ptr %19, align 4
  %22 = load ptr, ptr %7, align 8
  %23 = load i32, ptr %9, align 4
  %24 = sext i32 %23 to i64
  %25 = add nsw i64 %indvars.iv35, %24
  %26 = getelementptr i32, ptr %22, i64 %25
  %27 = load i32, ptr %26, align 4
  %28 = load ptr, ptr %12, align 8
  %29 = load i32, ptr %14, align 4
  %30 = sext i32 %29 to i64
  %31 = mul nsw i64 %30, 3
  %32 = sext i32 %27 to i64
  %33 = add nsw i64 %31, %32
  %34 = getelementptr i32, ptr %28, i64 %33
  %35 = load i32, ptr %34, align 4
  %36 = add i32 %35, 1
  store i32 %36, ptr %34, align 4
  %indvars.iv.next36 = add nuw nsw i64 %indvars.iv35, 1
  %exitcond39.not = icmp eq i64 %wide.trip.count38, %indvars.iv.next36
  br i1 %exitcond39.not, label %for_loop_body1.preheader.loopexit, label %for_loop_body, !llvm.loop !13

for_loop_body1.preheader.loopexit:                ; preds = %for_loop_body
  br label %for_loop_body1.preheader

for_loop_body1.preheader:                         ; preds = %for_loop_body1.preheader.loopexit, %entry
  br label %for_loop_body1

for_loop_body1:                                   ; preds = %for_loop_body1, %for_loop_body1.preheader
  %indvars.iv31 = phi i64 [ %indvars.iv.next32, %for_loop_body1 ], [ 0, %for_loop_body1.preheader ]
  %.01723 = phi i32 [ %50, %for_loop_body1 ], [ 0, %for_loop_body1.preheader ]
  %37 = load ptr, ptr %context, align 8
  %38 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %37, i64 0, i32 5, i32 1
  %39 = load ptr, ptr %38, align 8
  %40 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %37, i64 0, i32 5, i32 0, i32 1
  %41 = load i32, ptr %40, align 4
  %42 = sext i32 %41 to i64
  %43 = add nsw i64 %indvars.iv31, %42
  %44 = getelementptr i32, ptr %39, i64 %43
  %45 = load i32, ptr %44, align 4
  %46 = shl nuw nsw i64 %indvars.iv31, 2
  %uglygep46 = getelementptr i8, ptr %39, i64 %46
  store i32 %.01723, ptr %uglygep46, align 4
  %47 = load ptr, ptr %context, align 8
  %48 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %47, i64 0, i32 6, i32 1
  %49 = load ptr, ptr %48, align 8
  %uglygep45 = getelementptr i8, ptr %49, i64 %46
  store i32 %.01723, ptr %uglygep45, align 4
  %50 = add i32 %45, %.01723
  store i32 %50, ptr %44, align 4
  %indvars.iv.next32 = add nuw nsw i64 %indvars.iv31, 1
  %exitcond34.not = icmp eq i64 %indvars.iv.next32, 70
  br i1 %exitcond34.not, label %for_loop_body5.preheader, label %for_loop_body1, !llvm.loop !14

for_loop_body5.preheader:                         ; preds = %for_loop_body1
  br label %for_loop_body5

for_loop_body5:                                   ; preds = %for_loop_body5, %for_loop_body5.preheader
  %indvars.iv27 = phi i64 [ %indvars.iv.next28, %for_loop_body5 ], [ 0, %for_loop_body5.preheader ]
  %.01521 = phi i32 [ %69, %for_loop_body5 ], [ 0, %for_loop_body5.preheader ]
  %51 = load ptr, ptr %context, align 8
  %52 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %51, i64 0, i32 5, i32 1
  %53 = load ptr, ptr %52, align 8
  %54 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %51, i64 0, i32 5, i32 0, i32 1
  %55 = load i32, ptr %54, align 4
  %56 = sext i32 %55 to i64
  %57 = mul nsw i64 %56, 12
  %uglygep43 = getelementptr i8, ptr %53, i64 %57
  %58 = shl nuw nsw i64 %indvars.iv27, 2
  %uglygep44 = getelementptr i8, ptr %uglygep43, i64 %58
  %59 = load i32, ptr %uglygep44, align 4
  %60 = shl nsw i64 %56, 3
  %uglygep41 = getelementptr i8, ptr %53, i64 %60
  %uglygep42 = getelementptr i8, ptr %uglygep41, i64 %58
  store i32 %.01521, ptr %uglygep42, align 4
  %61 = load ptr, ptr %context, align 8
  %62 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %61, i64 0, i32 6, i32 1
  %63 = load ptr, ptr %62, align 8
  %64 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %61, i64 0, i32 6, i32 0, i32 1
  %65 = load i32, ptr %64, align 4
  %66 = sext i32 %65 to i64
  %67 = add nsw i64 %indvars.iv27, %66
  %68 = getelementptr i32, ptr %63, i64 %67
  store i32 %.01521, ptr %68, align 4
  %69 = add i32 %59, %.01521
  store i32 %69, ptr %uglygep44, align 4
  %indvars.iv.next28 = add nuw nsw i64 %indvars.iv27, 1
  %exitcond30.not = icmp eq i64 %indvars.iv.next28, 70
  br i1 %exitcond30.not, label %for_loop_test12.preheader, label %for_loop_body5, !llvm.loop !15

for_loop_test12.preheader:                        ; preds = %for_loop_body5
  br i1 %5, label %for_loop_body9.preheader, label %after_for11

for_loop_body9.preheader:                         ; preds = %for_loop_test12.preheader
  %wide.trip.count = zext i32 %4 to i64
  br label %for_loop_body9

for_loop_body9:                                   ; preds = %for_loop_body9, %for_loop_body9.preheader
  %indvars.iv = phi i64 [ 0, %for_loop_body9.preheader ], [ %indvars.iv.next, %for_loop_body9 ]
  %70 = load ptr, ptr %context, align 8
  %71 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %70, i64 0, i32 1, i32 1
  %72 = load ptr, ptr %71, align 8
  %73 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %70, i64 0, i32 1, i32 0, i32 1
  %74 = shl nuw nsw i64 %indvars.iv, 2
  %uglygep = getelementptr i8, ptr %72, i64 %74
  %75 = load i32, ptr %uglygep, align 4
  %76 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %70, i64 0, i32 6, i32 1
  %77 = load ptr, ptr %76, align 8
  %78 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %70, i64 0, i32 6, i32 0, i32 1
  %79 = sext i32 %75 to i64
  %80 = getelementptr i32, ptr %77, i64 %79
  %81 = load i32, ptr %80, align 4
  %82 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %70, i64 0, i32 7, i32 1
  %83 = load ptr, ptr %82, align 8
  %84 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %70, i64 0, i32 7, i32 0, i32 1
  %85 = sext i32 %81 to i64
  %86 = getelementptr i32, ptr %83, i64 %85
  %tmp40 = trunc i64 %indvars.iv to i32
  store i32 %tmp40, ptr %86, align 4
  %87 = add i32 %81, 1
  store i32 %87, ptr %80, align 4
  %88 = load ptr, ptr %71, align 8
  %89 = load i32, ptr %73, align 4
  %90 = sext i32 %89 to i64
  %91 = add nsw i64 %indvars.iv, %90
  %92 = getelementptr i32, ptr %88, i64 %91
  %93 = load i32, ptr %92, align 4
  %94 = load ptr, ptr %76, align 8
  %95 = load i32, ptr %78, align 4
  %96 = sext i32 %95 to i64
  %97 = sext i32 %93 to i64
  %98 = add nsw i64 %96, %97
  %99 = getelementptr i32, ptr %94, i64 %98
  %100 = load i32, ptr %99, align 4
  %101 = load ptr, ptr %82, align 8
  %102 = load i32, ptr %84, align 4
  %103 = sext i32 %102 to i64
  %104 = sext i32 %100 to i64
  %105 = add nsw i64 %103, %104
  %106 = getelementptr i32, ptr %101, i64 %105
  store i32 %tmp40, ptr %106, align 4
  %107 = add i32 %100, 1
  store i32 %107, ptr %99, align 4
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %wide.trip.count, %indvars.iv.next
  br i1 %exitcond.not, label %after_for11.loopexit, label %for_loop_body9, !llvm.loop !16

after_for11.loopexit:                             ; preds = %for_loop_body9
  br label %after_for11

after_for11:                                      ; preds = %after_for11.loopexit, %for_loop_test12.preheader
  ret void
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_parallel_range_for_task(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #4 {
  %4 = alloca %struct.RuntimeContext.2253, align 8
  %.sroa.0.0.copyload = load ptr, ptr %0, align 8
  %.sroa.4.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 8
  %.sroa.4.0.copyload = load ptr, ptr %.sroa.4.0..sroa_idx, align 8
  %.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 16
  %.sroa.5.0.copyload = load ptr, ptr %.sroa.5.0..sroa_idx, align 8
  %.sroa.7.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 24
  %.sroa.7.0.copyload = load ptr, ptr %.sroa.7.0..sroa_idx, align 8
  %.sroa.8.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 32
  %.sroa.8.0.copyload = load i64, ptr %.sroa.8.0..sroa_idx, align 8
  %.sroa.9.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 40
  %.sroa.9.0.copyload = load i32, ptr %.sroa.9.0..sroa_idx, align 8
  %.sroa.12.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 44
  %.sroa.12.0.copyload = load i32, ptr %.sroa.12.0..sroa_idx, align 4
  %.sroa.15.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 48
  %.sroa.15.0.copyload = load i32, ptr %.sroa.15.0..sroa_idx, align 8
  %.sroa.17.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 52
  %.sroa.17.0.copyload = load i32, ptr %.sroa.17.0..sroa_idx, align 4
  %5 = alloca i8, i64 %.sroa.8.0.copyload, align 8
  %.not = icmp eq ptr %.sroa.4.0.copyload, null
  br i1 %.not, label %7, label %6

6:                                                ; preds = %3
  call void %.sroa.4.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %7

7:                                                ; preds = %6, %3
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %4, ptr noundef nonnull align 8 dereferenceable(32) %.sroa.0.0.copyload, i64 32, i1 false)
  %8 = getelementptr inbounds %struct.RuntimeContext.2253, ptr %4, i64 0, i32 2
  store i32 %1, ptr %8, align 8
  switch i32 %.sroa.17.0.copyload, label %.loopexit [
    i32 1, label %9
    i32 -1, label %17
  ]

9:                                                ; preds = %7
  %10 = mul nsw i32 %.sroa.15.0.copyload, %2
  %11 = add nsw i32 %10, %.sroa.9.0.copyload
  %12 = add nsw i32 %11, %.sroa.15.0.copyload
  %13 = call i32 @llvm.smin.i32(i32 %.sroa.12.0.copyload, i32 %12)
  %14 = icmp slt i32 %11, %13
  br i1 %14, label %.lr.ph.preheader, label %.loopexit

.lr.ph.preheader:                                 ; preds = %9
  br label %.lr.ph

.lr.ph:                                           ; preds = %.lr.ph, %.lr.ph.preheader
  %.02039 = phi i32 [ %15, %.lr.ph ], [ %11, %.lr.ph.preheader ]
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.02039) #1
  %15 = add nsw i32 %.02039, 1
  %16 = icmp slt i32 %15, %13
  br i1 %16, label %.lr.ph, label %.loopexit.loopexit, !llvm.loop !17

17:                                               ; preds = %7
  %18 = mul nsw i32 %.sroa.15.0.copyload, %2
  %19 = sub nsw i32 %.sroa.12.0.copyload, %18
  %20 = mul nsw i32 %19, %.sroa.15.0.copyload
  %21 = call i32 @llvm.smax.i32(i32 %.sroa.9.0.copyload, i32 %20)
  %.not25.not40 = icmp sgt i32 %19, %21
  br i1 %.not25.not40, label %.lr.ph42.preheader, label %.loopexit

.lr.ph42.preheader:                               ; preds = %17
  br label %.lr.ph42

.lr.ph42:                                         ; preds = %.lr.ph42, %.lr.ph42.preheader
  %.0.in41 = phi i32 [ %.0, %.lr.ph42 ], [ %19, %.lr.ph42.preheader ]
  %.0 = add nsw i32 %.0.in41, -1
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.0) #1
  %.not25.not = icmp sgt i32 %.0, %21
  br i1 %.not25.not, label %.lr.ph42, label %.loopexit.loopexit47, !llvm.loop !19

.loopexit.loopexit:                               ; preds = %.lr.ph
  br label %.loopexit

.loopexit.loopexit47:                             ; preds = %.lr.ph42
  br label %.loopexit

.loopexit:                                        ; preds = %.loopexit.loopexit47, %.loopexit.loopexit, %17, %9, %7
  %.not24 = icmp eq ptr %.sroa.7.0.copyload, null
  br i1 %.not24, label %23, label %22

22:                                               ; preds = %.loopexit
  call void %.sroa.7.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %23

23:                                               ; preds = %22, %.loopexit
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #5

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #6

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smax.i32(i32, i32) #6

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #7

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #7

; Function Attrs: nocallback nofree nosync nounwind readnone willreturn
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #8

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { nofree nosync nounwind }
attributes #3 = { nofree norecurse nosync nounwind }
attributes #4 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #6 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #7 = { argmemonly nocallback nofree nosync nounwind willreturn }
attributes #8 = { nocallback nofree nosync nounwind readnone willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7, !8}
!7 = !{!"llvm.loop.unroll.disable"}
!8 = !{!"llvm.loop.isvectorized", i32 1}
!9 = distinct !{!9, !7, !8}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
!13 = distinct !{!13, !7}
!14 = distinct !{!14, !7}
!15 = distinct !{!15, !7}
!16 = distinct !{!16, !7}
!17 = distinct !{!17, !18, !7}
!18 = !{!"llvm.loop.mustprogress"}
!19 = distinct !{!19, !18, !7}
