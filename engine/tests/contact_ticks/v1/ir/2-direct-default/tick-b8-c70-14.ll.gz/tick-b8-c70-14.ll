; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%0 = type { ptr, [2 x i32], %struct.PhysicalCoordinates.978 }
%1 = type { [1048576 x %2], %3, %4 }
%2 = type { i8 }
%3 = type { [128 x i64], [128 x ptr] }
%4 = type { [4 x i32], [128 x %5] }
%5 = type { i32, i64 }
%6 = type { [70 x %2], %3, %4 }
%struct.RuntimeContext.970 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }
%struct.range_task_helper_context = type { ptr, ptr, ptr, ptr, i64, i32, i32, i32, i32 }
%struct.ListManager = type { [256 x ptr], i64, i64, i32, i32, i32, ptr }
%struct.PhysicalCoordinates.978 = type { [12 x i32] }
%struct.cpu_block_task_helper_context = type { ptr, ptr, ptr, i32, i32, i64 }
%class.anon = type { ptr, ptr, ptr, ptr }

@.str = private unnamed_addr constant [28 x i8] c"Out of pre-allocated memory\00", align 1
@.str.2 = private unnamed_addr constant [28 x i8] c"List manager out of chunks.\00", align 1

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @geometry_collect_5_selection_25_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %0, i64 0, i32 8
  %2 = load i32, ptr %1, align 4
  %3 = getelementptr inbounds %struct.RuntimeContext.970, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 4
  store i32 %2, ptr %7, align 4
  %8 = load ptr, ptr %context, align 8
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %8, i64 0, i32 9
  %10 = load i32, ptr %9, align 4
  %11 = load ptr, ptr %3, align 8
  %12 = getelementptr inbounds %struct.LLVMRuntime, ptr %11, i64 0, i32 16
  %13 = load ptr, ptr %12, align 8
  store i32 %10, ptr %13, align 4
  %14 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %0, i64 0, i32 4, i32 1
  %15 = load ptr, ptr %14, align 8
  store i64 0, ptr %15, align 8
  %16 = load ptr, ptr %14, align 8
  %17 = getelementptr i64, ptr %16, i64 1
  store i64 0, ptr %17, align 8
  %18 = load ptr, ptr %14, align 8
  %19 = getelementptr i64, ptr %18, i64 2
  %20 = getelementptr i64, ptr %18, i64 3
  store i64 0, ptr %20, align 8
  %21 = load ptr, ptr %14, align 8
  %22 = getelementptr i64, ptr %21, i64 4
  store i64 0, ptr %22, align 8
  %23 = load ptr, ptr %14, align 8
  %24 = getelementptr i64, ptr %23, i64 5
  store i64 0, ptr %24, align 8
  %25 = load ptr, ptr %14, align 8
  %26 = getelementptr i64, ptr %25, i64 7
  store i64 0, ptr %26, align 8
  %27 = load ptr, ptr %14, align 8
  %28 = getelementptr i64, ptr %27, i64 8
  store i64 0, ptr %28, align 8
  %29 = load ptr, ptr %14, align 8
  %30 = getelementptr i64, ptr %29, i64 9
  %31 = getelementptr i64, ptr %29, i64 10
  store i64 0, ptr %31, align 8
  %32 = load ptr, ptr %14, align 8
  %33 = getelementptr i64, ptr %32, i64 11
  store i64 0, ptr %33, align 8
  %34 = load ptr, ptr %14, align 8
  %35 = getelementptr i64, ptr %34, i64 12
  store i64 0, ptr %35, align 8
  %36 = load ptr, ptr %14, align 8
  %37 = getelementptr i64, ptr %36, i64 13
  store i64 0, ptr %37, align 8
  %38 = load ptr, ptr %14, align 8
  %39 = getelementptr i64, ptr %38, i64 14
  store i64 0, ptr %39, align 8
  %40 = load ptr, ptr %14, align 8
  %41 = getelementptr i64, ptr %40, i64 15
  store i64 0, ptr %41, align 8
  %42 = sext i32 %10 to i64
  store i64 %42, ptr %19, align 8
  store i64 70, ptr %30, align 8
  ret void
}

; Function Attrs: nounwind
define void @geometry_collect_5_selection_25_kernel_1_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.970, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %7, i64 0, i32 3, i32 1
  %9 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %10 = xor i64 %9, -1
  %11 = add nsw i64 %10, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %9, %for_loop_body.prol.preheader ]
  %12 = load ptr, ptr %8, align 8
  %13 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep20 = getelementptr i8, ptr %12, i64 %13
  store i32 0, ptr %uglygep20, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !6

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %9, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %14 = icmp ult i64 %11, 7
  br i1 %14, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %for_loop_body ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %15 = load ptr, ptr %8, align 8
  %16 = shl i64 %indvars.iv, 2
  %uglygep17 = getelementptr i8, ptr %15, i64 %16
  store i32 0, ptr %uglygep17, align 4
  %17 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %17, i64 4
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %16
  store i32 0, ptr %uglygep19, align 4
  %18 = load ptr, ptr %8, align 8
  %uglygep15 = getelementptr i8, ptr %18, i64 8
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %16
  store i32 0, ptr %uglygep16, align 4
  %19 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %19, i64 12
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 %16
  store i32 0, ptr %uglygep14, align 4
  %20 = load ptr, ptr %8, align 8
  %uglygep11 = getelementptr i8, ptr %20, i64 16
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 %16
  store i32 0, ptr %uglygep12, align 4
  %21 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %21, i64 20
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 %16
  store i32 0, ptr %uglygep10, align 4
  %22 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %22, i64 24
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 %16
  store i32 0, ptr %uglygep8, align 4
  %23 = load ptr, ptr %8, align 8
  %uglygep = getelementptr i8, ptr %23, i64 28
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %16
  store i32 0, ptr %uglygep6, align 4
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @geometry_collect_5_selection_25_kernel_2_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.970, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 5
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @geometry_collect_5_selection_25_kernel_3_listgen_S5bitmasked(ptr %context) local_unnamed_addr #1 {
.lr.ph.i:
  %.sroa.2.i = alloca { [2 x i32], %struct.PhysicalCoordinates.978 }, align 8
  %0 = alloca %0, align 8
  %1 = getelementptr inbounds %struct.RuntimeContext.970, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds ptr, ptr %4, i64 5
  %7 = load ptr, ptr %6, align 8
  %8 = load atomic i64, ptr %5 acquire, align 8
  %.not.i.i.i.i = icmp ne i64 %8, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i)
  %9 = inttoptr i64 %8 to ptr
  %10 = load atomic i64, ptr %9 acquire, align 8
  %11 = inttoptr i64 %10 to ptr
  %.sroa.0.0.copyload.i = load ptr, ptr %11, align 8
  %.sroa.2.0..sroa_idx.i = getelementptr inbounds i8, ptr %11, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.i, ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.0..sroa_idx.i, i64 56, i1 false)
  %getch.i = getelementptr %1, ptr %.sroa.0.0.copyload.i, i64 0, i32 2
  %12 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %.sroa.2.16.sroa_idx.i = getelementptr inbounds i8, ptr %.sroa.2.i, i64 8
  %13 = getelementptr inbounds %struct.ListManager, ptr %7, i64 0, i32 5
  %14 = getelementptr inbounds %struct.ListManager, ptr %7, i64 0, i32 3
  %15 = getelementptr inbounds %struct.ListManager, ptr %7, i64 0, i32 4
  %16 = getelementptr inbounds %struct.ListManager, ptr %7, i64 0, i32 6
  %17 = getelementptr inbounds %struct.ListManager, ptr %7, i64 0, i32 2
  %18 = getelementptr inbounds %struct.ListManager, ptr %7, i64 0, i32 1
  store ptr %getch.i, ptr %0, align 8
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %0, i64 8
  store <2 x i32> <i32 0, i32 128>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %12, ptr noundef nonnull align 8 dereferenceable(48) %.sroa.2.16.sroa_idx.i, i64 48, i1 false)
  %19 = atomicrmw volatile add ptr %13, i32 1 seq_cst, align 4
  %20 = load i32, ptr %14, align 8
  %21 = ashr i32 %19, %20
  %22 = icmp ugt i32 %21, 131071
  br i1 %22, label %23, label %25

23:                                               ; preds = %.lr.ph.i
  %24 = load ptr, ptr %16, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %24, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

25:                                               ; preds = %.lr.ph.i
  %26 = zext i32 %21 to i64
  %27 = lshr i64 %26, 9
  %28 = getelementptr inbounds [256 x ptr], ptr %7, i64 0, i64 %27
  %29 = load atomic i64, ptr %28 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %29, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %25
  %30 = inttoptr i64 %29 to ptr
  %31 = and i64 %26, 511
  %32 = getelementptr inbounds ptr, ptr %30, i64 %31
  %33 = load atomic i64, ptr %32 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %33, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %25
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %34 = atomicrmw volatile xchg ptr %15, i32 1 seq_cst, align 4
  %35 = icmp eq i32 %34, 1
  br i1 %35, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !8

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %36 = load atomic i64, ptr %28 acquire, align 8
  %37 = inttoptr i64 %36 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %36, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %38, label %72

38:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %39 = load ptr, ptr %16, align 8
  %40 = getelementptr inbounds %struct.LLVMRuntime, ptr %39, i64 0, i32 1
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %39, i64 0, i32 28
  %42 = atomicrmw volatile add ptr %41, i64 4096 seq_cst, align 8
  %43 = getelementptr inbounds %struct.LLVMRuntime, ptr %39, i64 0, i32 1, i32 2
  %44 = load i64, ptr %43, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %44, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %65, label %45

45:                                               ; preds = %38
  %46 = getelementptr inbounds %struct.LLVMRuntime, ptr %39, i64 0, i32 26
  br label %47

47:                                               ; preds = %47, %45
  %48 = atomicrmw volatile xchg ptr %46, i32 1 seq_cst, align 4
  %49 = icmp eq i32 %48, 1
  br i1 %49, label %47, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !8

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %47
  %50 = load ptr, ptr %40, align 8
  %51 = ptrtoint ptr %50 to i64
  %52 = getelementptr inbounds %struct.LLVMRuntime, ptr %39, i64 0, i32 1, i32 1
  %53 = load ptr, ptr %52, align 8
  %54 = ptrtoint ptr %53 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %51
  %55 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %56 = or i64 %55, 4096
  %57 = add i64 %56, %51
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %57, %54
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %58

58:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %59 = add i64 %55, %51
  %60 = inttoptr i64 %59 to ptr
  %61 = getelementptr i8, ptr %50, i64 %55
  %62 = getelementptr inbounds i8, ptr %61, i64 4096
  store ptr %62, ptr %40, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %58, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %60, %58 ]
  %63 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %64 = atomicrmw volatile xchg ptr %46, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %39, i1 noundef zeroext %63, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

65:                                               ; preds = %38
  %66 = getelementptr inbounds %struct.LLVMRuntime, ptr %39, i64 0, i32 2
  %67 = load ptr, ptr %66, align 8
  %68 = getelementptr inbounds %struct.LLVMRuntime, ptr %39, i64 0, i32 6
  %69 = load ptr, ptr %68, align 8
  %70 = tail call noundef ptr %67(ptr noundef %69, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %65, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %70, %65 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %71 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %71, ptr %28 release, align 8
  br label %72

72:                                               ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %37, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %73 = and i32 %21, 511
  %74 = zext i32 %73 to i64
  %75 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %74
  %76 = load atomic i64, ptr %75 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %76, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %77, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

77:                                               ; preds = %72
  %78 = load ptr, ptr %16, align 8
  %79 = getelementptr inbounds %struct.LLVMRuntime, ptr %78, i64 0, i32 1
  %80 = load i64, ptr %17, align 8
  %81 = load i64, ptr %18, align 8
  %82 = mul i64 %81, %80
  %83 = getelementptr inbounds %struct.LLVMRuntime, ptr %78, i64 0, i32 28
  %84 = atomicrmw volatile add ptr %83, i64 %82 seq_cst, align 8
  %85 = getelementptr inbounds %struct.LLVMRuntime, ptr %78, i64 0, i32 1, i32 2
  %86 = load i64, ptr %85, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %86, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %106, label %87

87:                                               ; preds = %77
  %88 = getelementptr inbounds %struct.LLVMRuntime, ptr %78, i64 0, i32 26
  br label %89

89:                                               ; preds = %89, %87
  %90 = atomicrmw volatile xchg ptr %88, i32 1 seq_cst, align 4
  %91 = icmp eq i32 %90, 1
  br i1 %91, label %89, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !8

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %89
  %92 = load ptr, ptr %79, align 8
  %93 = ptrtoint ptr %92 to i64
  %94 = getelementptr inbounds %struct.LLVMRuntime, ptr %78, i64 0, i32 1, i32 1
  %95 = load ptr, ptr %94, align 8
  %96 = ptrtoint ptr %95 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %93
  %97 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %98 = add i64 %97, %82
  %99 = add i64 %98, %93
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %99, %96
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %100

100:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %101 = add i64 %97, %93
  %102 = inttoptr i64 %101 to ptr
  %103 = getelementptr inbounds i8, ptr %92, i64 %98
  store ptr %103, ptr %79, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %100, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %102, %100 ]
  %104 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %105 = atomicrmw volatile xchg ptr %88, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %78, i1 noundef zeroext %104, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

106:                                              ; preds = %77
  %107 = getelementptr inbounds %struct.LLVMRuntime, ptr %78, i64 0, i32 2
  %108 = load ptr, ptr %107, align 8
  %109 = getelementptr inbounds %struct.LLVMRuntime, ptr %78, i64 0, i32 6
  %110 = load ptr, ptr %109, align 8
  %111 = tail call noundef ptr %108(ptr noundef %110, i64 noundef %82, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %106, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %111, %106 ]
  %112 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %112, ptr %75 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %72
  %113 = atomicrmw volatile xchg ptr %15, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %23
  %114 = load i32, ptr %14, align 8
  %115 = ashr i32 %19, %114
  %116 = sext i32 %115 to i64
  %117 = lshr i64 %116, 9
  %118 = getelementptr inbounds [256 x ptr], ptr %7, i64 0, i64 %117
  %119 = load atomic i64, ptr %118 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %119, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %120

120:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %121 = inttoptr i64 %119 to ptr
  %122 = and i64 %116, 511
  %123 = getelementptr inbounds ptr, ptr %121, i64 %122
  %124 = load atomic i64, ptr %123 acquire, align 8
  %125 = inttoptr i64 %124 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %120, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %126 = phi ptr [ %125, %120 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %127 = load i64, ptr %18, align 8
  %128 = load i32, ptr %14, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %128
  %129 = xor i32 %notmask.i.i.i.i, -1
  %130 = and i32 %19, %129
  %131 = sext i32 %130 to i64
  %132 = mul i64 %127, %131
  %133 = getelementptr inbounds i8, ptr %126, i64 %132
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %133, ptr nonnull align 8 %0, i64 %127, i1 false)
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  ret void
}

; Function Attrs: nounwind
define void @geometry_collect_5_selection_25_kernel_4_struct_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.cpu_block_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.RuntimeContext.970, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 5
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds %struct.ListManager, ptr %6, i64 0, i32 5
  %8 = load i32, ptr %7, align 8
  store ptr %context, ptr %0, align 8
  %9 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  store ptr @function_body.1, ptr %9, align 8
  %10 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  store ptr %6, ptr %10, align 8
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  store <2 x i32> <i32 128, i32 128>, ptr %11, align 8
  %12 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  store i64 1, ptr %12, align 8
  %13 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 12
  %14 = load ptr, ptr %13, align 8
  %15 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 11
  %16 = load ptr, ptr %15, align 8
  %17 = shl nsw i32 %8, 7
  call void %14(ptr noundef %16, i32 noundef %17, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_struct_for_block_helper) #1
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree norecurse nounwind
define internal void @function_body.1(ptr %0, ptr nocapture readnone %1, ptr nocapture readonly %2, i32 %3, i32 %4) #3 {
allocs:
  %5 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %6 = icmp sgt i32 %4, %3
  br i1 %6, label %loop_body.lr.ph, label %func_exit

loop_body.lr.ph:                                  ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.970, ptr %0, i64 0, i32 1
  %8 = sub i32 %4, %3
  %9 = xor i32 %3, -1
  %10 = add i32 %9, %4
  %xtraiter = and i32 %8, 7
  %lcmp.mod.not = icmp eq i32 %xtraiter, 0
  br i1 %lcmp.mod.not, label %loop_body.prol.loopexit, label %loop_body.prol.preheader

loop_body.prol.preheader:                         ; preds = %loop_body.lr.ph
  br label %loop_body.prol

loop_body.prol:                                   ; preds = %loop_body_tail.prol, %loop_body.prol.preheader
  %lsr.iv45 = phi i32 [ %xtraiter, %loop_body.prol.preheader ], [ %lsr.iv.next46, %loop_body_tail.prol ]
  %.044.prol = phi i32 [ %63, %loop_body_tail.prol ], [ %3, %loop_body.prol.preheader ]
  %11 = load ptr, ptr %2, align 8
  %12 = getelementptr inbounds i8, ptr %11, i64 2048
  %13 = sdiv i32 %.044.prol, 8
  %14 = sext i32 %13 to i64
  %15 = getelementptr inbounds i8, ptr %12, i64 %14
  %16 = load i8, ptr %15, align 1
  %17 = zext i8 %16 to i32
  %18 = and i32 %.044.prol, 7
  %19 = shl nuw nsw i32 1, %18
  %20 = and i32 %19, %17
  %.not.prol = icmp eq i32 %20, 0
  br i1 %.not.prol, label %loop_body_tail.prol, label %struct_for_body_body.prol

struct_for_body_body.prol:                        ; preds = %loop_body.prol
  %21 = and i32 %.044.prol, 127
  %22 = load i32, ptr %5, align 4
  %23 = shl i32 %22, 7
  %24 = or i32 %23, %21
  %25 = load ptr, ptr %0, align 8
  %26 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %25, i64 0, i32 3, i32 1
  %27 = load ptr, ptr %26, align 8
  %28 = sext i32 %24 to i64
  %29 = getelementptr i32, ptr %27, i64 %28
  store i32 1, ptr %29, align 4
  %30 = load ptr, ptr %0, align 8
  %31 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %30, i64 0, i32 4, i32 1
  %32 = load ptr, ptr %31, align 8
  %33 = getelementptr i64, ptr %32, i64 8
  %34 = atomicrmw add ptr %33, i64 1 seq_cst, align 8
  %35 = load ptr, ptr %7, align 8
  %36 = getelementptr inbounds %struct.LLVMRuntime, ptr %35, i64 0, i32 7
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr inbounds ptr, ptr %37, i64 3
  %39 = load ptr, ptr %38, align 8
  %40 = lshr i32 %24, 2
  %41 = and i32 %40, 1073741816
  %42 = zext i32 %41 to i64
  %43 = getelementptr i8, ptr %39, i64 %42
  %44 = getelementptr inbounds i8, ptr %43, i64 32
  %45 = load ptr, ptr %44, align 8
  %46 = icmp eq ptr %45, null
  br i1 %46, label %47, label %Pointer_lookup_element.exit.prol

47:                                               ; preds = %struct_for_body_body.prol
  %48 = getelementptr inbounds %struct.LLVMRuntime, ptr %35, i64 0, i32 15
  %49 = load ptr, ptr %48, align 8
  %50 = getelementptr inbounds ptr, ptr %49, i64 24
  %51 = load ptr, ptr %50, align 8
  br label %Pointer_lookup_element.exit.prol

Pointer_lookup_element.exit.prol:                 ; preds = %47, %struct_for_body_body.prol
  %.0.i.prol = phi ptr [ %51, %47 ], [ %45, %struct_for_body_body.prol ]
  %52 = getelementptr inbounds i8, ptr %.0.i.prol, i64 32
  %53 = lshr i32 %.044.prol, 3
  %54 = and i32 %53, 3
  %55 = zext i32 %54 to i64
  %56 = getelementptr inbounds i8, ptr %52, i64 %55
  %57 = load i8, ptr %56, align 1
  %58 = zext i8 %57 to i32
  %59 = and i32 %19, %58
  %.not43.prol = icmp eq i32 %59, 0
  br i1 %.not43.prol, label %loop_body_tail.prol, label %true_block.prol

true_block.prol:                                  ; preds = %Pointer_lookup_element.exit.prol
  %60 = load ptr, ptr %31, align 8
  %61 = getelementptr i64, ptr %60, i64 1
  %62 = atomicrmw add ptr %61, i64 1 seq_cst, align 8
  br label %loop_body_tail.prol

loop_body_tail.prol:                              ; preds = %true_block.prol, %Pointer_lookup_element.exit.prol, %loop_body.prol
  %63 = add i32 %.044.prol, 1
  %lsr.iv.next46 = add nsw i32 %lsr.iv45, -1
  %prol.iter.cmp.not = icmp eq i32 %lsr.iv.next46, 0
  br i1 %prol.iter.cmp.not, label %loop_body.prol.loopexit.loopexit, label %loop_body.prol, !llvm.loop !10

loop_body.prol.loopexit.loopexit:                 ; preds = %loop_body_tail.prol
  br label %loop_body.prol.loopexit

loop_body.prol.loopexit:                          ; preds = %loop_body.prol.loopexit.loopexit, %loop_body.lr.ph
  %.044.unr = phi i32 [ %3, %loop_body.lr.ph ], [ %63, %loop_body.prol.loopexit.loopexit ]
  %64 = icmp ult i32 %10, 7
  br i1 %64, label %func_exit, label %loop_body.lr.ph.new

loop_body.lr.ph.new:                              ; preds = %loop_body.prol.loopexit
  %65 = and i32 %.044.unr, 7
  %66 = add i32 %.044.unr, 1
  %67 = and i32 %66, 7
  %68 = add i32 %.044.unr, 2
  %69 = and i32 %68, 7
  %70 = add i32 %.044.unr, 3
  %71 = and i32 %70, 7
  %72 = xor i32 %65, 4
  %73 = add i32 %.044.unr, 5
  %74 = and i32 %73, 7
  %75 = add i32 %.044.unr, 6
  %76 = and i32 %75, 7
  %77 = add i32 %.044.unr, 7
  %78 = and i32 %77, 7
  %79 = shl nuw nsw i32 1, %65
  %80 = shl nuw nsw i32 1, %67
  %81 = shl nuw nsw i32 1, %69
  %82 = shl nuw nsw i32 1, %71
  %83 = shl nuw nsw i32 1, %72
  %84 = shl nuw nsw i32 1, %74
  %85 = shl nuw nsw i32 1, %76
  %86 = shl nuw nsw i32 1, %78
  br label %loop_body

loop_body:                                        ; preds = %loop_body_tail.7, %loop_body.lr.ph.new
  %lsr.iv = phi i32 [ %lsr.iv.next, %loop_body_tail.7 ], [ %77, %loop_body.lr.ph.new ]
  %87 = add i32 %lsr.iv, -7
  %88 = load ptr, ptr %2, align 8
  %89 = getelementptr inbounds i8, ptr %88, i64 2048
  %90 = sdiv i32 %87, 8
  %91 = sext i32 %90 to i64
  %92 = getelementptr inbounds i8, ptr %89, i64 %91
  %93 = load i8, ptr %92, align 1
  %94 = zext i8 %93 to i32
  %95 = and i32 %79, %94
  %.not = icmp eq i32 %95, 0
  br i1 %.not, label %loop_body_tail, label %struct_for_body_body

loop_body_tail:                                   ; preds = %true_block, %Pointer_lookup_element.exit, %loop_body
  %96 = add i32 %lsr.iv, -6
  %97 = load ptr, ptr %2, align 8
  %98 = getelementptr inbounds i8, ptr %97, i64 2048
  %99 = add i32 %87, 1
  %100 = sdiv i32 %99, 8
  %101 = sext i32 %100 to i64
  %102 = getelementptr inbounds i8, ptr %98, i64 %101
  %103 = load i8, ptr %102, align 1
  %104 = zext i8 %103 to i32
  %105 = and i32 %80, %104
  %.not.1 = icmp eq i32 %105, 0
  br i1 %.not.1, label %loop_body_tail.1, label %struct_for_body_body.1

struct_for_body_body.1:                           ; preds = %loop_body_tail
  %106 = and i32 %96, 127
  %107 = load i32, ptr %5, align 4
  %108 = shl i32 %107, 7
  %109 = or i32 %108, %106
  %110 = load ptr, ptr %0, align 8
  %111 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %110, i64 0, i32 3, i32 1
  %112 = load ptr, ptr %111, align 8
  %113 = sext i32 %109 to i64
  %114 = getelementptr i32, ptr %112, i64 %113
  store i32 1, ptr %114, align 4
  %115 = load ptr, ptr %0, align 8
  %116 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %115, i64 0, i32 4, i32 1
  %117 = load ptr, ptr %116, align 8
  %118 = getelementptr i64, ptr %117, i64 8
  %119 = atomicrmw add ptr %118, i64 1 seq_cst, align 8
  %120 = load ptr, ptr %7, align 8
  %121 = getelementptr inbounds %struct.LLVMRuntime, ptr %120, i64 0, i32 7
  %122 = load ptr, ptr %121, align 8
  %123 = getelementptr inbounds ptr, ptr %122, i64 3
  %124 = load ptr, ptr %123, align 8
  %125 = lshr i32 %109, 2
  %126 = and i32 %125, 1073741816
  %127 = zext i32 %126 to i64
  %128 = getelementptr i8, ptr %124, i64 %127
  %129 = getelementptr inbounds i8, ptr %128, i64 32
  %130 = load ptr, ptr %129, align 8
  %131 = icmp eq ptr %130, null
  br i1 %131, label %132, label %Pointer_lookup_element.exit.1

132:                                              ; preds = %struct_for_body_body.1
  %133 = getelementptr inbounds %struct.LLVMRuntime, ptr %120, i64 0, i32 15
  %134 = load ptr, ptr %133, align 8
  %135 = getelementptr inbounds ptr, ptr %134, i64 24
  %136 = load ptr, ptr %135, align 8
  br label %Pointer_lookup_element.exit.1

Pointer_lookup_element.exit.1:                    ; preds = %132, %struct_for_body_body.1
  %.0.i.1 = phi ptr [ %136, %132 ], [ %130, %struct_for_body_body.1 ]
  %137 = getelementptr inbounds i8, ptr %.0.i.1, i64 32
  %138 = lshr i32 %96, 3
  %139 = and i32 %138, 3
  %140 = zext i32 %139 to i64
  %141 = getelementptr inbounds i8, ptr %137, i64 %140
  %142 = load i8, ptr %141, align 1
  %143 = zext i8 %142 to i32
  %144 = and i32 %80, %143
  %.not43.1 = icmp eq i32 %144, 0
  br i1 %.not43.1, label %loop_body_tail.1, label %true_block.1

true_block.1:                                     ; preds = %Pointer_lookup_element.exit.1
  %145 = load ptr, ptr %116, align 8
  %146 = getelementptr i64, ptr %145, i64 1
  %147 = atomicrmw add ptr %146, i64 1 seq_cst, align 8
  br label %loop_body_tail.1

loop_body_tail.1:                                 ; preds = %true_block.1, %Pointer_lookup_element.exit.1, %loop_body_tail
  %148 = add i32 %lsr.iv, -5
  %149 = load ptr, ptr %2, align 8
  %150 = getelementptr inbounds i8, ptr %149, i64 2048
  %151 = add i32 %99, 1
  %152 = sdiv i32 %151, 8
  %153 = sext i32 %152 to i64
  %154 = getelementptr inbounds i8, ptr %150, i64 %153
  %155 = load i8, ptr %154, align 1
  %156 = zext i8 %155 to i32
  %157 = and i32 %81, %156
  %.not.2 = icmp eq i32 %157, 0
  br i1 %.not.2, label %loop_body_tail.2, label %struct_for_body_body.2

struct_for_body_body.2:                           ; preds = %loop_body_tail.1
  %158 = and i32 %148, 127
  %159 = load i32, ptr %5, align 4
  %160 = shl i32 %159, 7
  %161 = or i32 %160, %158
  %162 = load ptr, ptr %0, align 8
  %163 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %162, i64 0, i32 3, i32 1
  %164 = load ptr, ptr %163, align 8
  %165 = sext i32 %161 to i64
  %166 = getelementptr i32, ptr %164, i64 %165
  store i32 1, ptr %166, align 4
  %167 = load ptr, ptr %0, align 8
  %168 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %167, i64 0, i32 4, i32 1
  %169 = load ptr, ptr %168, align 8
  %170 = getelementptr i64, ptr %169, i64 8
  %171 = atomicrmw add ptr %170, i64 1 seq_cst, align 8
  %172 = load ptr, ptr %7, align 8
  %173 = getelementptr inbounds %struct.LLVMRuntime, ptr %172, i64 0, i32 7
  %174 = load ptr, ptr %173, align 8
  %175 = getelementptr inbounds ptr, ptr %174, i64 3
  %176 = load ptr, ptr %175, align 8
  %177 = lshr i32 %161, 2
  %178 = and i32 %177, 1073741816
  %179 = zext i32 %178 to i64
  %180 = getelementptr i8, ptr %176, i64 %179
  %181 = getelementptr inbounds i8, ptr %180, i64 32
  %182 = load ptr, ptr %181, align 8
  %183 = icmp eq ptr %182, null
  br i1 %183, label %184, label %Pointer_lookup_element.exit.2

184:                                              ; preds = %struct_for_body_body.2
  %185 = getelementptr inbounds %struct.LLVMRuntime, ptr %172, i64 0, i32 15
  %186 = load ptr, ptr %185, align 8
  %187 = getelementptr inbounds ptr, ptr %186, i64 24
  %188 = load ptr, ptr %187, align 8
  br label %Pointer_lookup_element.exit.2

Pointer_lookup_element.exit.2:                    ; preds = %184, %struct_for_body_body.2
  %.0.i.2 = phi ptr [ %188, %184 ], [ %182, %struct_for_body_body.2 ]
  %189 = getelementptr inbounds i8, ptr %.0.i.2, i64 32
  %190 = lshr i32 %148, 3
  %191 = and i32 %190, 3
  %192 = zext i32 %191 to i64
  %193 = getelementptr inbounds i8, ptr %189, i64 %192
  %194 = load i8, ptr %193, align 1
  %195 = zext i8 %194 to i32
  %196 = and i32 %81, %195
  %.not43.2 = icmp eq i32 %196, 0
  br i1 %.not43.2, label %loop_body_tail.2, label %true_block.2

true_block.2:                                     ; preds = %Pointer_lookup_element.exit.2
  %197 = load ptr, ptr %168, align 8
  %198 = getelementptr i64, ptr %197, i64 1
  %199 = atomicrmw add ptr %198, i64 1 seq_cst, align 8
  br label %loop_body_tail.2

loop_body_tail.2:                                 ; preds = %true_block.2, %Pointer_lookup_element.exit.2, %loop_body_tail.1
  %200 = add i32 %lsr.iv, -4
  %201 = load ptr, ptr %2, align 8
  %202 = getelementptr inbounds i8, ptr %201, i64 2048
  %203 = add i32 %151, 1
  %204 = sdiv i32 %203, 8
  %205 = sext i32 %204 to i64
  %206 = getelementptr inbounds i8, ptr %202, i64 %205
  %207 = load i8, ptr %206, align 1
  %208 = zext i8 %207 to i32
  %209 = and i32 %82, %208
  %.not.3 = icmp eq i32 %209, 0
  br i1 %.not.3, label %loop_body_tail.3, label %struct_for_body_body.3

struct_for_body_body.3:                           ; preds = %loop_body_tail.2
  %210 = and i32 %200, 127
  %211 = load i32, ptr %5, align 4
  %212 = shl i32 %211, 7
  %213 = or i32 %212, %210
  %214 = load ptr, ptr %0, align 8
  %215 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %214, i64 0, i32 3, i32 1
  %216 = load ptr, ptr %215, align 8
  %217 = sext i32 %213 to i64
  %218 = getelementptr i32, ptr %216, i64 %217
  store i32 1, ptr %218, align 4
  %219 = load ptr, ptr %0, align 8
  %220 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %219, i64 0, i32 4, i32 1
  %221 = load ptr, ptr %220, align 8
  %222 = getelementptr i64, ptr %221, i64 8
  %223 = atomicrmw add ptr %222, i64 1 seq_cst, align 8
  %224 = load ptr, ptr %7, align 8
  %225 = getelementptr inbounds %struct.LLVMRuntime, ptr %224, i64 0, i32 7
  %226 = load ptr, ptr %225, align 8
  %227 = getelementptr inbounds ptr, ptr %226, i64 3
  %228 = load ptr, ptr %227, align 8
  %229 = lshr i32 %213, 2
  %230 = and i32 %229, 1073741816
  %231 = zext i32 %230 to i64
  %232 = getelementptr i8, ptr %228, i64 %231
  %233 = getelementptr inbounds i8, ptr %232, i64 32
  %234 = load ptr, ptr %233, align 8
  %235 = icmp eq ptr %234, null
  br i1 %235, label %236, label %Pointer_lookup_element.exit.3

236:                                              ; preds = %struct_for_body_body.3
  %237 = getelementptr inbounds %struct.LLVMRuntime, ptr %224, i64 0, i32 15
  %238 = load ptr, ptr %237, align 8
  %239 = getelementptr inbounds ptr, ptr %238, i64 24
  %240 = load ptr, ptr %239, align 8
  br label %Pointer_lookup_element.exit.3

Pointer_lookup_element.exit.3:                    ; preds = %236, %struct_for_body_body.3
  %.0.i.3 = phi ptr [ %240, %236 ], [ %234, %struct_for_body_body.3 ]
  %241 = getelementptr inbounds i8, ptr %.0.i.3, i64 32
  %242 = lshr i32 %200, 3
  %243 = and i32 %242, 3
  %244 = zext i32 %243 to i64
  %245 = getelementptr inbounds i8, ptr %241, i64 %244
  %246 = load i8, ptr %245, align 1
  %247 = zext i8 %246 to i32
  %248 = and i32 %82, %247
  %.not43.3 = icmp eq i32 %248, 0
  br i1 %.not43.3, label %loop_body_tail.3, label %true_block.3

true_block.3:                                     ; preds = %Pointer_lookup_element.exit.3
  %249 = load ptr, ptr %220, align 8
  %250 = getelementptr i64, ptr %249, i64 1
  %251 = atomicrmw add ptr %250, i64 1 seq_cst, align 8
  br label %loop_body_tail.3

loop_body_tail.3:                                 ; preds = %true_block.3, %Pointer_lookup_element.exit.3, %loop_body_tail.2
  %252 = add i32 %lsr.iv, -3
  %253 = load ptr, ptr %2, align 8
  %254 = getelementptr inbounds i8, ptr %253, i64 2048
  %255 = add i32 %203, 1
  %256 = sdiv i32 %255, 8
  %257 = sext i32 %256 to i64
  %258 = getelementptr inbounds i8, ptr %254, i64 %257
  %259 = load i8, ptr %258, align 1
  %260 = zext i8 %259 to i32
  %261 = and i32 %83, %260
  %.not.4 = icmp eq i32 %261, 0
  br i1 %.not.4, label %loop_body_tail.4, label %struct_for_body_body.4

struct_for_body_body.4:                           ; preds = %loop_body_tail.3
  %262 = and i32 %252, 127
  %263 = load i32, ptr %5, align 4
  %264 = shl i32 %263, 7
  %265 = or i32 %264, %262
  %266 = load ptr, ptr %0, align 8
  %267 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %266, i64 0, i32 3, i32 1
  %268 = load ptr, ptr %267, align 8
  %269 = sext i32 %265 to i64
  %270 = getelementptr i32, ptr %268, i64 %269
  store i32 1, ptr %270, align 4
  %271 = load ptr, ptr %0, align 8
  %272 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %271, i64 0, i32 4, i32 1
  %273 = load ptr, ptr %272, align 8
  %274 = getelementptr i64, ptr %273, i64 8
  %275 = atomicrmw add ptr %274, i64 1 seq_cst, align 8
  %276 = load ptr, ptr %7, align 8
  %277 = getelementptr inbounds %struct.LLVMRuntime, ptr %276, i64 0, i32 7
  %278 = load ptr, ptr %277, align 8
  %279 = getelementptr inbounds ptr, ptr %278, i64 3
  %280 = load ptr, ptr %279, align 8
  %281 = lshr i32 %265, 2
  %282 = and i32 %281, 1073741816
  %283 = zext i32 %282 to i64
  %284 = getelementptr i8, ptr %280, i64 %283
  %285 = getelementptr inbounds i8, ptr %284, i64 32
  %286 = load ptr, ptr %285, align 8
  %287 = icmp eq ptr %286, null
  br i1 %287, label %288, label %Pointer_lookup_element.exit.4

288:                                              ; preds = %struct_for_body_body.4
  %289 = getelementptr inbounds %struct.LLVMRuntime, ptr %276, i64 0, i32 15
  %290 = load ptr, ptr %289, align 8
  %291 = getelementptr inbounds ptr, ptr %290, i64 24
  %292 = load ptr, ptr %291, align 8
  br label %Pointer_lookup_element.exit.4

Pointer_lookup_element.exit.4:                    ; preds = %288, %struct_for_body_body.4
  %.0.i.4 = phi ptr [ %292, %288 ], [ %286, %struct_for_body_body.4 ]
  %293 = getelementptr inbounds i8, ptr %.0.i.4, i64 32
  %294 = lshr i32 %252, 3
  %295 = and i32 %294, 3
  %296 = zext i32 %295 to i64
  %297 = getelementptr inbounds i8, ptr %293, i64 %296
  %298 = load i8, ptr %297, align 1
  %299 = zext i8 %298 to i32
  %300 = and i32 %83, %299
  %.not43.4 = icmp eq i32 %300, 0
  br i1 %.not43.4, label %loop_body_tail.4, label %true_block.4

true_block.4:                                     ; preds = %Pointer_lookup_element.exit.4
  %301 = load ptr, ptr %272, align 8
  %302 = getelementptr i64, ptr %301, i64 1
  %303 = atomicrmw add ptr %302, i64 1 seq_cst, align 8
  br label %loop_body_tail.4

loop_body_tail.4:                                 ; preds = %true_block.4, %Pointer_lookup_element.exit.4, %loop_body_tail.3
  %304 = add i32 %lsr.iv, -2
  %305 = load ptr, ptr %2, align 8
  %306 = getelementptr inbounds i8, ptr %305, i64 2048
  %307 = add i32 %255, 1
  %308 = sdiv i32 %307, 8
  %309 = sext i32 %308 to i64
  %310 = getelementptr inbounds i8, ptr %306, i64 %309
  %311 = load i8, ptr %310, align 1
  %312 = zext i8 %311 to i32
  %313 = and i32 %84, %312
  %.not.5 = icmp eq i32 %313, 0
  br i1 %.not.5, label %loop_body_tail.5, label %struct_for_body_body.5

struct_for_body_body.5:                           ; preds = %loop_body_tail.4
  %314 = and i32 %304, 127
  %315 = load i32, ptr %5, align 4
  %316 = shl i32 %315, 7
  %317 = or i32 %316, %314
  %318 = load ptr, ptr %0, align 8
  %319 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %318, i64 0, i32 3, i32 1
  %320 = load ptr, ptr %319, align 8
  %321 = sext i32 %317 to i64
  %322 = getelementptr i32, ptr %320, i64 %321
  store i32 1, ptr %322, align 4
  %323 = load ptr, ptr %0, align 8
  %324 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %323, i64 0, i32 4, i32 1
  %325 = load ptr, ptr %324, align 8
  %326 = getelementptr i64, ptr %325, i64 8
  %327 = atomicrmw add ptr %326, i64 1 seq_cst, align 8
  %328 = load ptr, ptr %7, align 8
  %329 = getelementptr inbounds %struct.LLVMRuntime, ptr %328, i64 0, i32 7
  %330 = load ptr, ptr %329, align 8
  %331 = getelementptr inbounds ptr, ptr %330, i64 3
  %332 = load ptr, ptr %331, align 8
  %333 = lshr i32 %317, 2
  %334 = and i32 %333, 1073741816
  %335 = zext i32 %334 to i64
  %336 = getelementptr i8, ptr %332, i64 %335
  %337 = getelementptr inbounds i8, ptr %336, i64 32
  %338 = load ptr, ptr %337, align 8
  %339 = icmp eq ptr %338, null
  br i1 %339, label %340, label %Pointer_lookup_element.exit.5

340:                                              ; preds = %struct_for_body_body.5
  %341 = getelementptr inbounds %struct.LLVMRuntime, ptr %328, i64 0, i32 15
  %342 = load ptr, ptr %341, align 8
  %343 = getelementptr inbounds ptr, ptr %342, i64 24
  %344 = load ptr, ptr %343, align 8
  br label %Pointer_lookup_element.exit.5

Pointer_lookup_element.exit.5:                    ; preds = %340, %struct_for_body_body.5
  %.0.i.5 = phi ptr [ %344, %340 ], [ %338, %struct_for_body_body.5 ]
  %345 = getelementptr inbounds i8, ptr %.0.i.5, i64 32
  %346 = lshr i32 %304, 3
  %347 = and i32 %346, 3
  %348 = zext i32 %347 to i64
  %349 = getelementptr inbounds i8, ptr %345, i64 %348
  %350 = load i8, ptr %349, align 1
  %351 = zext i8 %350 to i32
  %352 = and i32 %84, %351
  %.not43.5 = icmp eq i32 %352, 0
  br i1 %.not43.5, label %loop_body_tail.5, label %true_block.5

true_block.5:                                     ; preds = %Pointer_lookup_element.exit.5
  %353 = load ptr, ptr %324, align 8
  %354 = getelementptr i64, ptr %353, i64 1
  %355 = atomicrmw add ptr %354, i64 1 seq_cst, align 8
  br label %loop_body_tail.5

loop_body_tail.5:                                 ; preds = %true_block.5, %Pointer_lookup_element.exit.5, %loop_body_tail.4
  %356 = add i32 %lsr.iv, -1
  %357 = load ptr, ptr %2, align 8
  %358 = getelementptr inbounds i8, ptr %357, i64 2048
  %359 = add i32 %307, 1
  %360 = sdiv i32 %359, 8
  %361 = sext i32 %360 to i64
  %362 = getelementptr inbounds i8, ptr %358, i64 %361
  %363 = load i8, ptr %362, align 1
  %364 = zext i8 %363 to i32
  %365 = and i32 %85, %364
  %.not.6 = icmp eq i32 %365, 0
  br i1 %.not.6, label %loop_body_tail.6, label %struct_for_body_body.6

struct_for_body_body.6:                           ; preds = %loop_body_tail.5
  %366 = and i32 %356, 127
  %367 = load i32, ptr %5, align 4
  %368 = shl i32 %367, 7
  %369 = or i32 %368, %366
  %370 = load ptr, ptr %0, align 8
  %371 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %370, i64 0, i32 3, i32 1
  %372 = load ptr, ptr %371, align 8
  %373 = sext i32 %369 to i64
  %374 = getelementptr i32, ptr %372, i64 %373
  store i32 1, ptr %374, align 4
  %375 = load ptr, ptr %0, align 8
  %376 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %375, i64 0, i32 4, i32 1
  %377 = load ptr, ptr %376, align 8
  %378 = getelementptr i64, ptr %377, i64 8
  %379 = atomicrmw add ptr %378, i64 1 seq_cst, align 8
  %380 = load ptr, ptr %7, align 8
  %381 = getelementptr inbounds %struct.LLVMRuntime, ptr %380, i64 0, i32 7
  %382 = load ptr, ptr %381, align 8
  %383 = getelementptr inbounds ptr, ptr %382, i64 3
  %384 = load ptr, ptr %383, align 8
  %385 = lshr i32 %369, 2
  %386 = and i32 %385, 1073741816
  %387 = zext i32 %386 to i64
  %388 = getelementptr i8, ptr %384, i64 %387
  %389 = getelementptr inbounds i8, ptr %388, i64 32
  %390 = load ptr, ptr %389, align 8
  %391 = icmp eq ptr %390, null
  br i1 %391, label %392, label %Pointer_lookup_element.exit.6

392:                                              ; preds = %struct_for_body_body.6
  %393 = getelementptr inbounds %struct.LLVMRuntime, ptr %380, i64 0, i32 15
  %394 = load ptr, ptr %393, align 8
  %395 = getelementptr inbounds ptr, ptr %394, i64 24
  %396 = load ptr, ptr %395, align 8
  br label %Pointer_lookup_element.exit.6

Pointer_lookup_element.exit.6:                    ; preds = %392, %struct_for_body_body.6
  %.0.i.6 = phi ptr [ %396, %392 ], [ %390, %struct_for_body_body.6 ]
  %397 = getelementptr inbounds i8, ptr %.0.i.6, i64 32
  %398 = lshr i32 %356, 3
  %399 = and i32 %398, 3
  %400 = zext i32 %399 to i64
  %401 = getelementptr inbounds i8, ptr %397, i64 %400
  %402 = load i8, ptr %401, align 1
  %403 = zext i8 %402 to i32
  %404 = and i32 %85, %403
  %.not43.6 = icmp eq i32 %404, 0
  br i1 %.not43.6, label %loop_body_tail.6, label %true_block.6

true_block.6:                                     ; preds = %Pointer_lookup_element.exit.6
  %405 = load ptr, ptr %376, align 8
  %406 = getelementptr i64, ptr %405, i64 1
  %407 = atomicrmw add ptr %406, i64 1 seq_cst, align 8
  br label %loop_body_tail.6

loop_body_tail.6:                                 ; preds = %true_block.6, %Pointer_lookup_element.exit.6, %loop_body_tail.5
  %408 = load ptr, ptr %2, align 8
  %409 = getelementptr inbounds i8, ptr %408, i64 2048
  %410 = add i32 %359, 1
  %411 = sdiv i32 %410, 8
  %412 = sext i32 %411 to i64
  %413 = getelementptr inbounds i8, ptr %409, i64 %412
  %414 = load i8, ptr %413, align 1
  %415 = zext i8 %414 to i32
  %416 = and i32 %86, %415
  %.not.7 = icmp eq i32 %416, 0
  br i1 %.not.7, label %loop_body_tail.7, label %struct_for_body_body.7

struct_for_body_body.7:                           ; preds = %loop_body_tail.6
  %417 = and i32 %lsr.iv, 127
  %418 = load i32, ptr %5, align 4
  %419 = shl i32 %418, 7
  %420 = or i32 %419, %417
  %421 = load ptr, ptr %0, align 8
  %422 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %421, i64 0, i32 3, i32 1
  %423 = load ptr, ptr %422, align 8
  %424 = sext i32 %420 to i64
  %425 = getelementptr i32, ptr %423, i64 %424
  store i32 1, ptr %425, align 4
  %426 = load ptr, ptr %0, align 8
  %427 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %426, i64 0, i32 4, i32 1
  %428 = load ptr, ptr %427, align 8
  %429 = getelementptr i64, ptr %428, i64 8
  %430 = atomicrmw add ptr %429, i64 1 seq_cst, align 8
  %431 = load ptr, ptr %7, align 8
  %432 = getelementptr inbounds %struct.LLVMRuntime, ptr %431, i64 0, i32 7
  %433 = load ptr, ptr %432, align 8
  %434 = getelementptr inbounds ptr, ptr %433, i64 3
  %435 = load ptr, ptr %434, align 8
  %436 = lshr i32 %420, 2
  %437 = and i32 %436, 1073741816
  %438 = zext i32 %437 to i64
  %439 = getelementptr i8, ptr %435, i64 %438
  %440 = getelementptr inbounds i8, ptr %439, i64 32
  %441 = load ptr, ptr %440, align 8
  %442 = icmp eq ptr %441, null
  br i1 %442, label %443, label %Pointer_lookup_element.exit.7

443:                                              ; preds = %struct_for_body_body.7
  %444 = getelementptr inbounds %struct.LLVMRuntime, ptr %431, i64 0, i32 15
  %445 = load ptr, ptr %444, align 8
  %446 = getelementptr inbounds ptr, ptr %445, i64 24
  %447 = load ptr, ptr %446, align 8
  br label %Pointer_lookup_element.exit.7

Pointer_lookup_element.exit.7:                    ; preds = %443, %struct_for_body_body.7
  %.0.i.7 = phi ptr [ %447, %443 ], [ %441, %struct_for_body_body.7 ]
  %448 = getelementptr inbounds i8, ptr %.0.i.7, i64 32
  %449 = lshr i32 %lsr.iv, 3
  %450 = and i32 %449, 3
  %451 = zext i32 %450 to i64
  %452 = getelementptr inbounds i8, ptr %448, i64 %451
  %453 = load i8, ptr %452, align 1
  %454 = zext i8 %453 to i32
  %455 = and i32 %86, %454
  %.not43.7 = icmp eq i32 %455, 0
  br i1 %.not43.7, label %loop_body_tail.7, label %true_block.7

true_block.7:                                     ; preds = %Pointer_lookup_element.exit.7
  %456 = load ptr, ptr %427, align 8
  %457 = getelementptr i64, ptr %456, i64 1
  %458 = atomicrmw add ptr %457, i64 1 seq_cst, align 8
  br label %loop_body_tail.7

loop_body_tail.7:                                 ; preds = %true_block.7, %Pointer_lookup_element.exit.7, %loop_body_tail.6
  %lsr.iv.next = add i32 %lsr.iv, 8
  %459 = add i32 %410, 1
  %exitcond.not.7 = icmp eq i32 %459, %4
  br i1 %exitcond.not.7, label %func_exit.loopexit, label %loop_body

func_exit.loopexit:                               ; preds = %loop_body_tail.7
  br label %func_exit

func_exit:                                        ; preds = %func_exit.loopexit, %loop_body.prol.loopexit, %allocs
  ret void

struct_for_body_body:                             ; preds = %loop_body
  %460 = and i32 %87, 127
  %461 = load i32, ptr %5, align 4
  %462 = shl i32 %461, 7
  %463 = or i32 %462, %460
  %464 = load ptr, ptr %0, align 8
  %465 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %464, i64 0, i32 3, i32 1
  %466 = load ptr, ptr %465, align 8
  %467 = sext i32 %463 to i64
  %468 = getelementptr i32, ptr %466, i64 %467
  store i32 1, ptr %468, align 4
  %469 = load ptr, ptr %0, align 8
  %470 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %469, i64 0, i32 4, i32 1
  %471 = load ptr, ptr %470, align 8
  %472 = getelementptr i64, ptr %471, i64 8
  %473 = atomicrmw add ptr %472, i64 1 seq_cst, align 8
  %474 = load ptr, ptr %7, align 8
  %475 = getelementptr inbounds %struct.LLVMRuntime, ptr %474, i64 0, i32 7
  %476 = load ptr, ptr %475, align 8
  %477 = getelementptr inbounds ptr, ptr %476, i64 3
  %478 = load ptr, ptr %477, align 8
  %479 = lshr i32 %463, 2
  %480 = and i32 %479, 1073741816
  %481 = zext i32 %480 to i64
  %482 = getelementptr i8, ptr %478, i64 %481
  %483 = getelementptr inbounds i8, ptr %482, i64 32
  %484 = load ptr, ptr %483, align 8
  %485 = icmp eq ptr %484, null
  br i1 %485, label %486, label %Pointer_lookup_element.exit

486:                                              ; preds = %struct_for_body_body
  %487 = getelementptr inbounds %struct.LLVMRuntime, ptr %474, i64 0, i32 15
  %488 = load ptr, ptr %487, align 8
  %489 = getelementptr inbounds ptr, ptr %488, i64 24
  %490 = load ptr, ptr %489, align 8
  br label %Pointer_lookup_element.exit

Pointer_lookup_element.exit:                      ; preds = %486, %struct_for_body_body
  %.0.i = phi ptr [ %490, %486 ], [ %484, %struct_for_body_body ]
  %491 = getelementptr inbounds i8, ptr %.0.i, i64 32
  %492 = lshr i32 %87, 3
  %493 = and i32 %492, 3
  %494 = zext i32 %493 to i64
  %495 = getelementptr inbounds i8, ptr %491, i64 %494
  %496 = load i8, ptr %495, align 1
  %497 = zext i8 %496 to i32
  %498 = and i32 %79, %497
  %.not43 = icmp eq i32 %498, 0
  br i1 %.not43, label %loop_body_tail, label %true_block

true_block:                                       ; preds = %Pointer_lookup_element.exit
  %499 = load ptr, ptr %470, align 8
  %500 = getelementptr i64, ptr %499, i64 1
  %501 = atomicrmw add ptr %500, i64 1 seq_cst, align 8
  br label %loop_body_tail
}

; Function Attrs: nofree norecurse nosync nounwind
define void @geometry_collect_5_selection_25_kernel_5_serial(ptr nocapture readonly %context) local_unnamed_addr #4 {
entry:
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.1, %entry
  %indvars.iv = phi i64 [ 0, %entry ], [ %indvars.iv.next.1, %after_if.1 ]
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %0, i64 0, i32 3, i32 1
  %2 = load ptr, ptr %1, align 8
  %3 = shl nuw nsw i64 %indvars.iv, 2
  %uglygep36 = getelementptr i8, ptr %2, i64 %3
  %4 = load i32, ptr %uglygep36, align 4
  %.not = icmp eq i32 %4, 0
  br i1 %.not, label %after_if, label %true_block

after_for:                                        ; preds = %after_if.1
  ret void

true_block:                                       ; preds = %for_loop_body
  %5 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %0, i64 0, i32 4, i32 1
  %6 = load ptr, ptr %5, align 8
  %7 = load i64, ptr %6, align 8
  %sext = shl i64 %7, 32
  %8 = ashr exact i64 %sext, 32
  %9 = getelementptr i32, ptr %2, i64 %8
  %tmp28 = trunc i64 %indvars.iv to i32
  store i32 %tmp28, ptr %9, align 4
  %10 = add i64 %7, 1
  store i64 %10, ptr %6, align 8
  %11 = load ptr, ptr %context, align 8
  %12 = getelementptr { { i32, i32 }, ptr }, ptr %11, i64 0, i32 1
  %13 = load ptr, ptr %12, align 8
  %14 = getelementptr { { i32, i32 }, ptr }, ptr %11, i64 0, i32 0, i32 1
  %15 = shl nuw nsw i64 %indvars.iv, 3
  %uglygep35 = getelementptr i8, ptr %13, i64 %15
  %16 = load i64, ptr %uglygep35, align 8
  %17 = and i64 %16, 9223372036854775807
  %18 = and i64 %16, 9218868437227405312
  %19 = icmp eq i64 %17, 0
  %20 = icmp ne i64 %18, 0
  %21 = icmp ne i64 %18, 9218868437227405312
  %22 = and i1 %20, %21
  %23 = or i1 %19, %22
  br i1 %23, label %after_if3, label %true_block1

after_if:                                         ; preds = %true_block16, %after_if15, %for_loop_body
  %24 = load ptr, ptr %context, align 8
  %25 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %24, i64 0, i32 3, i32 1
  %26 = load ptr, ptr %25, align 8
  %uglygep = getelementptr i8, ptr %26, i64 4
  %uglygep16 = getelementptr i8, ptr %uglygep, i64 %3
  %27 = load i32, ptr %uglygep16, align 4
  %.not.1 = icmp eq i32 %27, 0
  br i1 %.not.1, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if
  %28 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %24, i64 0, i32 4, i32 1
  %29 = load ptr, ptr %28, align 8
  %30 = load i64, ptr %29, align 8
  %sext.1 = shl i64 %30, 32
  %31 = ashr exact i64 %sext.1, 32
  %32 = getelementptr i32, ptr %26, i64 %31
  %33 = add nuw nsw i64 %indvars.iv, 1
  %tmp = trunc i64 %33 to i32
  store i32 %tmp, ptr %32, align 4
  %34 = add i64 %30, 1
  store i64 %34, ptr %29, align 8
  %35 = load ptr, ptr %context, align 8
  %36 = getelementptr { { i32, i32 }, ptr }, ptr %35, i64 0, i32 1
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr { { i32, i32 }, ptr }, ptr %35, i64 0, i32 0, i32 1
  %uglygep17 = getelementptr i8, ptr %37, i64 8
  %39 = shl nuw nsw i64 %indvars.iv, 3
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 %39
  %40 = load i64, ptr %uglygep18, align 8
  %41 = and i64 %40, 9223372036854775807
  %42 = and i64 %40, 9218868437227405312
  %43 = icmp eq i64 %41, 0
  %44 = icmp ne i64 %42, 0
  %45 = icmp ne i64 %42, 9218868437227405312
  %46 = and i1 %44, %45
  %47 = or i1 %43, %46
  br i1 %47, label %after_if3.1, label %true_block1.1

true_block1.1:                                    ; preds = %true_block.1
  %48 = load ptr, ptr %28, align 8
  %49 = getelementptr i64, ptr %48, i64 5
  %50 = load i64, ptr %49, align 8
  %51 = or i64 %50, 1
  store i64 %51, ptr %49, align 8
  %.pre.1 = load ptr, ptr %36, align 8
  br label %after_if3.1

after_if3.1:                                      ; preds = %true_block1.1, %true_block.1
  %52 = phi ptr [ %37, %true_block.1 ], [ %.pre.1, %true_block1.1 ]
  %53 = load i32, ptr %38, align 4
  %54 = sext i32 %53 to i64
  %55 = add i64 %indvars.iv, %54
  %56 = getelementptr double, ptr %52, i64 %55
  %57 = getelementptr double, ptr %56, i64 1
  %58 = load i64, ptr %57, align 8
  %59 = and i64 %58, 9223372036854775807
  %60 = and i64 %58, 9218868437227405312
  %61 = icmp eq i64 %59, 0
  %62 = icmp ne i64 %60, 0
  %63 = icmp ne i64 %60, 9218868437227405312
  %64 = and i1 %62, %63
  %65 = or i1 %61, %64
  br i1 %65, label %after_if6.1, label %true_block4.1

true_block4.1:                                    ; preds = %after_if3.1
  %66 = load ptr, ptr %28, align 8
  %67 = getelementptr i64, ptr %66, i64 5
  %68 = load i64, ptr %67, align 8
  %69 = or i64 %68, 1
  store i64 %69, ptr %67, align 8
  %.pre5.1 = load ptr, ptr %36, align 8
  %.pre6.1 = load i32, ptr %38, align 4
  %.pre11.1 = sext i32 %.pre6.1 to i64
  br label %after_if6.1

after_if6.1:                                      ; preds = %true_block4.1, %after_if3.1
  %.pre-phi.1 = phi i64 [ %54, %after_if3.1 ], [ %.pre11.1, %true_block4.1 ]
  %70 = phi ptr [ %52, %after_if3.1 ], [ %.pre5.1, %true_block4.1 ]
  %71 = shl nsw i64 %.pre-phi.1, 4
  %uglygep19 = getelementptr i8, ptr %70, i64 %71
  %uglygep20 = getelementptr i8, ptr %uglygep19, i64 %39
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 8
  %72 = load i64, ptr %uglygep21, align 8
  %73 = and i64 %72, 9223372036854775807
  %74 = and i64 %72, 9218868437227405312
  %75 = icmp eq i64 %73, 0
  %76 = icmp ne i64 %74, 0
  %77 = icmp ne i64 %74, 9218868437227405312
  %78 = and i1 %76, %77
  %79 = or i1 %75, %78
  br i1 %79, label %after_if9.1, label %true_block7.1

true_block7.1:                                    ; preds = %after_if6.1
  %80 = load ptr, ptr %28, align 8
  %81 = getelementptr i64, ptr %80, i64 5
  %82 = load i64, ptr %81, align 8
  %83 = or i64 %82, 1
  store i64 %83, ptr %81, align 8
  %.pre7.1 = load ptr, ptr %36, align 8
  %.pre8.1 = load i32, ptr %38, align 4
  %.pre12.1 = sext i32 %.pre8.1 to i64
  br label %after_if9.1

after_if9.1:                                      ; preds = %true_block7.1, %after_if6.1
  %.pre-phi13.1 = phi i64 [ %.pre-phi.1, %after_if6.1 ], [ %.pre12.1, %true_block7.1 ]
  %84 = phi ptr [ %70, %after_if6.1 ], [ %.pre7.1, %true_block7.1 ]
  %85 = mul nsw i64 %.pre-phi13.1, 48
  %uglygep22 = getelementptr i8, ptr %84, i64 %85
  %uglygep23 = getelementptr i8, ptr %uglygep22, i64 %39
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 8
  %86 = load double, ptr %uglygep24, align 8
  %87 = bitcast double %86 to i64
  %88 = and i64 %87, 9223372036854775807
  %89 = and i64 %87, 9218868437227405312
  %90 = icmp eq i64 %88, 0
  %91 = icmp ne i64 %89, 0
  %92 = icmp ne i64 %89, 9218868437227405312
  %93 = and i1 %91, %92
  %94 = or i1 %90, %93
  br i1 %94, label %after_if12.1, label %true_block10.1

true_block10.1:                                   ; preds = %after_if9.1
  %95 = load ptr, ptr %28, align 8
  %96 = getelementptr i64, ptr %95, i64 5
  %97 = load i64, ptr %96, align 8
  %98 = or i64 %97, 1
  store i64 %98, ptr %96, align 8
  %.pre9.1 = load ptr, ptr %36, align 8
  %.pre10.1 = load i32, ptr %38, align 4
  %.pre14.1 = sext i32 %.pre10.1 to i64
  br label %after_if12.1

after_if12.1:                                     ; preds = %true_block10.1, %after_if9.1
  %.pre-phi15.1 = phi i64 [ %.pre-phi13.1, %after_if9.1 ], [ %.pre14.1, %true_block10.1 ]
  %99 = phi ptr [ %84, %after_if9.1 ], [ %.pre9.1, %true_block10.1 ]
  %100 = mul nsw i64 %.pre-phi15.1, 56
  %uglygep25 = getelementptr i8, ptr %99, i64 %100
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %39
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 8
  %101 = load double, ptr %uglygep27, align 8
  %102 = bitcast double %101 to i64
  %103 = and i64 %102, 9223372036854775807
  %104 = and i64 %102, 9218868437227405312
  %105 = icmp eq i64 %103, 0
  %106 = icmp ne i64 %104, 0
  %107 = icmp ne i64 %104, 9218868437227405312
  %108 = and i1 %106, %107
  %109 = or i1 %105, %108
  br i1 %109, label %after_if15.1, label %true_block13.1

true_block13.1:                                   ; preds = %after_if12.1
  %110 = load ptr, ptr %28, align 8
  %111 = getelementptr i64, ptr %110, i64 5
  %112 = load i64, ptr %111, align 8
  %113 = or i64 %112, 1
  store i64 %113, ptr %111, align 8
  br label %after_if15.1

after_if15.1:                                     ; preds = %true_block13.1, %after_if12.1
  %114 = fcmp ole double %86, 0.000000e+00
  %115 = fcmp olt double %101, 0.000000e+00
  %116 = or i1 %114, %115
  br i1 %116, label %true_block16.1, label %after_if.1

true_block16.1:                                   ; preds = %after_if15.1
  %117 = load ptr, ptr %28, align 8
  %118 = getelementptr i64, ptr %117, i64 5
  %119 = load i64, ptr %118, align 8
  %120 = or i64 %119, 1
  store i64 %120, ptr %118, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block16.1, %after_if15.1, %after_if
  %indvars.iv.next.1 = add nuw nsw i64 %indvars.iv, 2
  %exitcond.not.1 = icmp eq i64 %indvars.iv.next.1, 70
  br i1 %exitcond.not.1, label %after_for, label %for_loop_body

true_block1:                                      ; preds = %true_block
  %121 = load ptr, ptr %5, align 8
  %122 = getelementptr i64, ptr %121, i64 5
  %123 = load i64, ptr %122, align 8
  %124 = or i64 %123, 1
  store i64 %124, ptr %122, align 8
  %.pre = load ptr, ptr %12, align 8
  br label %after_if3

after_if3:                                        ; preds = %true_block1, %true_block
  %125 = phi ptr [ %13, %true_block ], [ %.pre, %true_block1 ]
  %126 = load i32, ptr %14, align 4
  %127 = sext i32 %126 to i64
  %128 = add nsw i64 %indvars.iv, %127
  %129 = getelementptr double, ptr %125, i64 %128
  %130 = load i64, ptr %129, align 8
  %131 = and i64 %130, 9223372036854775807
  %132 = and i64 %130, 9218868437227405312
  %133 = icmp eq i64 %131, 0
  %134 = icmp ne i64 %132, 0
  %135 = icmp ne i64 %132, 9218868437227405312
  %136 = and i1 %134, %135
  %137 = or i1 %133, %136
  br i1 %137, label %after_if6, label %true_block4

true_block4:                                      ; preds = %after_if3
  %138 = load ptr, ptr %5, align 8
  %139 = getelementptr i64, ptr %138, i64 5
  %140 = load i64, ptr %139, align 8
  %141 = or i64 %140, 1
  store i64 %141, ptr %139, align 8
  %.pre5 = load ptr, ptr %12, align 8
  %.pre6 = load i32, ptr %14, align 4
  %.pre11 = sext i32 %.pre6 to i64
  br label %after_if6

after_if6:                                        ; preds = %true_block4, %after_if3
  %.pre-phi = phi i64 [ %127, %after_if3 ], [ %.pre11, %true_block4 ]
  %142 = phi ptr [ %125, %after_if3 ], [ %.pre5, %true_block4 ]
  %143 = shl nsw i64 %.pre-phi, 4
  %uglygep33 = getelementptr i8, ptr %142, i64 %143
  %uglygep34 = getelementptr i8, ptr %uglygep33, i64 %15
  %144 = load i64, ptr %uglygep34, align 8
  %145 = and i64 %144, 9223372036854775807
  %146 = and i64 %144, 9218868437227405312
  %147 = icmp eq i64 %145, 0
  %148 = icmp ne i64 %146, 0
  %149 = icmp ne i64 %146, 9218868437227405312
  %150 = and i1 %148, %149
  %151 = or i1 %147, %150
  br i1 %151, label %after_if9, label %true_block7

true_block7:                                      ; preds = %after_if6
  %152 = load ptr, ptr %5, align 8
  %153 = getelementptr i64, ptr %152, i64 5
  %154 = load i64, ptr %153, align 8
  %155 = or i64 %154, 1
  store i64 %155, ptr %153, align 8
  %.pre7 = load ptr, ptr %12, align 8
  %.pre8 = load i32, ptr %14, align 4
  %.pre12 = sext i32 %.pre8 to i64
  br label %after_if9

after_if9:                                        ; preds = %true_block7, %after_if6
  %.pre-phi13 = phi i64 [ %.pre-phi, %after_if6 ], [ %.pre12, %true_block7 ]
  %156 = phi ptr [ %142, %after_if6 ], [ %.pre7, %true_block7 ]
  %157 = mul nsw i64 %.pre-phi13, 48
  %uglygep31 = getelementptr i8, ptr %156, i64 %157
  %uglygep32 = getelementptr i8, ptr %uglygep31, i64 %15
  %158 = load double, ptr %uglygep32, align 8
  %159 = bitcast double %158 to i64
  %160 = and i64 %159, 9223372036854775807
  %161 = and i64 %159, 9218868437227405312
  %162 = icmp eq i64 %160, 0
  %163 = icmp ne i64 %161, 0
  %164 = icmp ne i64 %161, 9218868437227405312
  %165 = and i1 %163, %164
  %166 = or i1 %162, %165
  br i1 %166, label %after_if12, label %true_block10

true_block10:                                     ; preds = %after_if9
  %167 = load ptr, ptr %5, align 8
  %168 = getelementptr i64, ptr %167, i64 5
  %169 = load i64, ptr %168, align 8
  %170 = or i64 %169, 1
  store i64 %170, ptr %168, align 8
  %.pre9 = load ptr, ptr %12, align 8
  %.pre10 = load i32, ptr %14, align 4
  %.pre14 = sext i32 %.pre10 to i64
  br label %after_if12

after_if12:                                       ; preds = %true_block10, %after_if9
  %.pre-phi15 = phi i64 [ %.pre-phi13, %after_if9 ], [ %.pre14, %true_block10 ]
  %171 = phi ptr [ %156, %after_if9 ], [ %.pre9, %true_block10 ]
  %172 = mul nsw i64 %.pre-phi15, 56
  %uglygep29 = getelementptr i8, ptr %171, i64 %172
  %uglygep30 = getelementptr i8, ptr %uglygep29, i64 %15
  %173 = load double, ptr %uglygep30, align 8
  %174 = bitcast double %173 to i64
  %175 = and i64 %174, 9223372036854775807
  %176 = and i64 %174, 9218868437227405312
  %177 = icmp eq i64 %175, 0
  %178 = icmp ne i64 %176, 0
  %179 = icmp ne i64 %176, 9218868437227405312
  %180 = and i1 %178, %179
  %181 = or i1 %177, %180
  br i1 %181, label %after_if15, label %true_block13

true_block13:                                     ; preds = %after_if12
  %182 = load ptr, ptr %5, align 8
  %183 = getelementptr i64, ptr %182, i64 5
  %184 = load i64, ptr %183, align 8
  %185 = or i64 %184, 1
  store i64 %185, ptr %183, align 8
  br label %after_if15

after_if15:                                       ; preds = %true_block13, %after_if12
  %186 = fcmp ole double %158, 0.000000e+00
  %187 = fcmp olt double %173, 0.000000e+00
  %188 = or i1 %186, %187
  br i1 %188, label %true_block16, label %after_if

true_block16:                                     ; preds = %after_if15
  %189 = load ptr, ptr %5, align 8
  %190 = getelementptr i64, ptr %189, i64 5
  %191 = load i64, ptr %190, align 8
  %192 = or i64 %191, 1
  store i64 %192, ptr %190, align 8
  br label %after_if
}

; Function Attrs: nounwind
define void @geometry_collect_5_selection_25_kernel_6_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.2, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.970, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body.2(ptr %0, ptr nocapture readnone %1, i32 %2) #5 {
allocs:
  %3 = getelementptr inbounds %struct.RuntimeContext.970, ptr %0, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  %7 = load i32, ptr %6, align 4
  %8 = add i32 %7, 1
  %9 = sdiv i32 %8, 2
  %10 = icmp slt i32 %8, 0
  %11 = shl nsw i32 %9, 1
  %12 = icmp ne i32 %11, %8
  %13 = and i1 %10, %12
  %.neg = sext i1 %13 to i32
  %14 = add nsw i32 %9, %.neg
  %15 = tail call i32 @llvm.smax.i32(i32 %14, i32 512)
  %16 = mul i32 %15, %2
  %17 = add i32 %16, %15
  %18 = tail call i32 @llvm.smin.i32(i32 %7, i32 %17)
  %19 = icmp slt i32 %16, %18
  br i1 %19, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %20 = load ptr, ptr %0, align 8
  %21 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %20, i64 0, i32 2, i32 1
  %22 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %20, i64 0, i32 2, i32 0, i32 1
  %23 = sext i32 %16 to i64
  %wide.trip.count = sext i32 %18 to i64
  %24 = sub nsw i64 %wide.trip.count, %23
  %25 = xor i64 %23, -1
  %26 = add nsw i64 %25, %wide.trip.count
  %xtraiter = and i64 %24, 7
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  %27 = shl i64 %xtraiter, 2
  %28 = add nsw i64 %27, -4
  %29 = lshr i64 %28, 2
  %30 = add i64 %29, %23
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %after_if.prol, %for_loop_body.prol.preheader
  %lsr.iv38 = phi i64 [ %27, %for_loop_body.prol.preheader ], [ %lsr.iv.next39, %after_if.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %after_if.prol ], [ %23, %for_loop_body.prol.preheader ]
  %31 = load ptr, ptr %21, align 8
  %32 = load i32, ptr %22, align 4
  %33 = sext i32 %32 to i64
  %34 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep37 = getelementptr i8, ptr %31, i64 %34
  %35 = load i32, ptr %uglygep37, align 4
  %36 = add nsw i64 %indvars.iv.prol, %33
  %37 = getelementptr i32, ptr %31, i64 %36
  %38 = load i32, ptr %37, align 4
  %39 = icmp ult i32 %35, 70
  %40 = icmp ult i32 %38, 70
  %41 = and i1 %39, %40
  br i1 %41, label %true_block.prol, label %after_if.sink.split.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %42 = icmp ne i32 %35, %38
  %43 = load ptr, ptr %3, align 8
  %44 = getelementptr inbounds %struct.LLVMRuntime, ptr %43, i64 0, i32 7
  %45 = load ptr, ptr %44, align 8
  %46 = load ptr, ptr %45, align 8
  %47 = getelementptr %1, ptr %46, i64 0, i32 2, i32 1, i64 127
  %48 = lshr i32 %35, 3
  %49 = zext i32 %48 to i64
  %50 = getelementptr inbounds i8, ptr %47, i64 %49
  %51 = load i8, ptr %50, align 1
  %52 = zext i8 %51 to i32
  %53 = and i32 %35, 7
  %54 = shl nuw nsw i32 1, %53
  %55 = and i32 %54, %52
  %56 = icmp ne i32 %55, 0
  %57 = lshr i32 %38, 3
  %58 = zext i32 %57 to i64
  %59 = getelementptr inbounds i8, ptr %47, i64 %58
  %60 = load i8, ptr %59, align 1
  %61 = zext i8 %60 to i32
  %62 = and i32 %38, 7
  %63 = shl nuw nsw i32 1, %62
  %64 = and i32 %63, %61
  %65 = icmp ne i32 %64, 0
  %66 = and i1 %56, %65
  %67 = and i1 %42, %66
  br i1 %67, label %after_if.prol, label %after_if.sink.split.prol

after_if.sink.split.prol:                         ; preds = %true_block.prol, %for_loop_body.prol
  %68 = load ptr, ptr %0, align 8
  %69 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %68, i64 0, i32 4, i32 1
  %70 = load ptr, ptr %69, align 8
  %71 = getelementptr i64, ptr %70, i64 5
  %72 = atomicrmw or ptr %71, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %after_if.sink.split.prol, %true_block.prol
  %indvars.iv.next.prol = add nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next39 = add nsw i64 %lsr.iv38, -4
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next39, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !11

for_loop_body.prol.loopexit.loopexit:             ; preds = %after_if.prol
  %73 = add i64 %30, 1
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %23, %for_loop_body.lr.ph ], [ %73, %for_loop_body.prol.loopexit.loopexit ]
  %74 = icmp ult i64 %26, 7
  br i1 %74, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  %75 = sub i64 0, %wide.trip.count
  %76 = add nsw i64 %indvars.iv.unr, 7
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.7, %for_loop_body.preheader
  %lsr.iv = phi i64 [ %76, %for_loop_body.preheader ], [ %lsr.iv.next, %after_if.7 ]
  %77 = load ptr, ptr %21, align 8
  %78 = load i32, ptr %22, align 4
  %79 = sext i32 %78 to i64
  %80 = shl i64 %lsr.iv, 2
  %uglygep33 = getelementptr i8, ptr %77, i64 %80
  %uglygep34 = getelementptr i8, ptr %uglygep33, i64 -28
  %81 = load i32, ptr %uglygep34, align 4
  %82 = add i64 %lsr.iv, %79
  %83 = getelementptr i32, ptr %77, i64 %82
  %84 = getelementptr i32, ptr %83, i64 -7
  %85 = load i32, ptr %84, align 4
  %86 = icmp ult i32 %81, 70
  %87 = icmp ult i32 %85, 70
  %88 = and i1 %86, %87
  br i1 %88, label %true_block, label %after_if.sink.split

after_for.loopexit:                               ; preds = %after_if.7
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %89 = icmp ne i32 %81, %85
  %90 = load ptr, ptr %3, align 8
  %91 = getelementptr inbounds %struct.LLVMRuntime, ptr %90, i64 0, i32 7
  %92 = load ptr, ptr %91, align 8
  %93 = load ptr, ptr %92, align 8
  %94 = getelementptr %1, ptr %93, i64 0, i32 2, i32 1, i64 127
  %95 = lshr i32 %81, 3
  %96 = zext i32 %95 to i64
  %97 = getelementptr inbounds i8, ptr %94, i64 %96
  %98 = load i8, ptr %97, align 1
  %99 = zext i8 %98 to i32
  %100 = and i32 %81, 7
  %101 = shl nuw nsw i32 1, %100
  %102 = and i32 %101, %99
  %103 = icmp ne i32 %102, 0
  %104 = lshr i32 %85, 3
  %105 = zext i32 %104 to i64
  %106 = getelementptr inbounds i8, ptr %94, i64 %105
  %107 = load i8, ptr %106, align 1
  %108 = zext i8 %107 to i32
  %109 = and i32 %85, 7
  %110 = shl nuw nsw i32 1, %109
  %111 = and i32 %110, %108
  %112 = icmp ne i32 %111, 0
  %113 = and i1 %103, %112
  %114 = and i1 %89, %113
  br i1 %114, label %after_if, label %after_if.sink.split

after_if.sink.split:                              ; preds = %true_block, %for_loop_body
  %115 = load ptr, ptr %0, align 8
  %116 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %115, i64 0, i32 4, i32 1
  %117 = load ptr, ptr %116, align 8
  %118 = getelementptr i64, ptr %117, i64 5
  %119 = atomicrmw or ptr %118, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %after_if.sink.split, %true_block
  %120 = load ptr, ptr %21, align 8
  %121 = load i32, ptr %22, align 4
  %122 = sext i32 %121 to i64
  %uglygep35 = getelementptr i8, ptr %120, i64 %80
  %uglygep36 = getelementptr i8, ptr %uglygep35, i64 -24
  %123 = load i32, ptr %uglygep36, align 4
  %124 = add i64 %lsr.iv, %122
  %125 = getelementptr i32, ptr %120, i64 %124
  %126 = getelementptr i32, ptr %125, i64 -6
  %127 = load i32, ptr %126, align 4
  %128 = icmp ult i32 %123, 70
  %129 = icmp ult i32 %127, 70
  %130 = and i1 %128, %129
  br i1 %130, label %true_block.1, label %after_if.sink.split.1

true_block.1:                                     ; preds = %after_if
  %131 = icmp ne i32 %123, %127
  %132 = load ptr, ptr %3, align 8
  %133 = getelementptr inbounds %struct.LLVMRuntime, ptr %132, i64 0, i32 7
  %134 = load ptr, ptr %133, align 8
  %135 = load ptr, ptr %134, align 8
  %136 = getelementptr %1, ptr %135, i64 0, i32 2, i32 1, i64 127
  %137 = lshr i32 %123, 3
  %138 = zext i32 %137 to i64
  %139 = getelementptr inbounds i8, ptr %136, i64 %138
  %140 = load i8, ptr %139, align 1
  %141 = zext i8 %140 to i32
  %142 = and i32 %123, 7
  %143 = shl nuw nsw i32 1, %142
  %144 = and i32 %143, %141
  %145 = icmp ne i32 %144, 0
  %146 = lshr i32 %127, 3
  %147 = zext i32 %146 to i64
  %148 = getelementptr inbounds i8, ptr %136, i64 %147
  %149 = load i8, ptr %148, align 1
  %150 = zext i8 %149 to i32
  %151 = and i32 %127, 7
  %152 = shl nuw nsw i32 1, %151
  %153 = and i32 %152, %150
  %154 = icmp ne i32 %153, 0
  %155 = and i1 %145, %154
  %156 = and i1 %131, %155
  br i1 %156, label %after_if.1, label %after_if.sink.split.1

after_if.sink.split.1:                            ; preds = %true_block.1, %after_if
  %157 = load ptr, ptr %0, align 8
  %158 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %157, i64 0, i32 4, i32 1
  %159 = load ptr, ptr %158, align 8
  %160 = getelementptr i64, ptr %159, i64 5
  %161 = atomicrmw or ptr %160, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %after_if.sink.split.1, %true_block.1
  %162 = load ptr, ptr %21, align 8
  %163 = load i32, ptr %22, align 4
  %164 = sext i32 %163 to i64
  %uglygep31 = getelementptr i8, ptr %162, i64 %80
  %uglygep32 = getelementptr i8, ptr %uglygep31, i64 -20
  %165 = load i32, ptr %uglygep32, align 4
  %166 = add i64 %lsr.iv, %164
  %167 = getelementptr i32, ptr %162, i64 %166
  %168 = getelementptr i32, ptr %167, i64 -5
  %169 = load i32, ptr %168, align 4
  %170 = icmp ult i32 %165, 70
  %171 = icmp ult i32 %169, 70
  %172 = and i1 %170, %171
  br i1 %172, label %true_block.2, label %after_if.sink.split.2

true_block.2:                                     ; preds = %after_if.1
  %173 = icmp ne i32 %165, %169
  %174 = load ptr, ptr %3, align 8
  %175 = getelementptr inbounds %struct.LLVMRuntime, ptr %174, i64 0, i32 7
  %176 = load ptr, ptr %175, align 8
  %177 = load ptr, ptr %176, align 8
  %178 = getelementptr %1, ptr %177, i64 0, i32 2, i32 1, i64 127
  %179 = lshr i32 %165, 3
  %180 = zext i32 %179 to i64
  %181 = getelementptr inbounds i8, ptr %178, i64 %180
  %182 = load i8, ptr %181, align 1
  %183 = zext i8 %182 to i32
  %184 = and i32 %165, 7
  %185 = shl nuw nsw i32 1, %184
  %186 = and i32 %185, %183
  %187 = icmp ne i32 %186, 0
  %188 = lshr i32 %169, 3
  %189 = zext i32 %188 to i64
  %190 = getelementptr inbounds i8, ptr %178, i64 %189
  %191 = load i8, ptr %190, align 1
  %192 = zext i8 %191 to i32
  %193 = and i32 %169, 7
  %194 = shl nuw nsw i32 1, %193
  %195 = and i32 %194, %192
  %196 = icmp ne i32 %195, 0
  %197 = and i1 %187, %196
  %198 = and i1 %173, %197
  br i1 %198, label %after_if.2, label %after_if.sink.split.2

after_if.sink.split.2:                            ; preds = %true_block.2, %after_if.1
  %199 = load ptr, ptr %0, align 8
  %200 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %199, i64 0, i32 4, i32 1
  %201 = load ptr, ptr %200, align 8
  %202 = getelementptr i64, ptr %201, i64 5
  %203 = atomicrmw or ptr %202, i64 1 seq_cst, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %after_if.sink.split.2, %true_block.2
  %204 = load ptr, ptr %21, align 8
  %205 = load i32, ptr %22, align 4
  %206 = sext i32 %205 to i64
  %uglygep29 = getelementptr i8, ptr %204, i64 %80
  %uglygep30 = getelementptr i8, ptr %uglygep29, i64 -16
  %207 = load i32, ptr %uglygep30, align 4
  %208 = add i64 %lsr.iv, %206
  %209 = getelementptr i32, ptr %204, i64 %208
  %210 = getelementptr i32, ptr %209, i64 -4
  %211 = load i32, ptr %210, align 4
  %212 = icmp ult i32 %207, 70
  %213 = icmp ult i32 %211, 70
  %214 = and i1 %212, %213
  br i1 %214, label %true_block.3, label %after_if.sink.split.3

true_block.3:                                     ; preds = %after_if.2
  %215 = icmp ne i32 %207, %211
  %216 = load ptr, ptr %3, align 8
  %217 = getelementptr inbounds %struct.LLVMRuntime, ptr %216, i64 0, i32 7
  %218 = load ptr, ptr %217, align 8
  %219 = load ptr, ptr %218, align 8
  %220 = getelementptr %1, ptr %219, i64 0, i32 2, i32 1, i64 127
  %221 = lshr i32 %207, 3
  %222 = zext i32 %221 to i64
  %223 = getelementptr inbounds i8, ptr %220, i64 %222
  %224 = load i8, ptr %223, align 1
  %225 = zext i8 %224 to i32
  %226 = and i32 %207, 7
  %227 = shl nuw nsw i32 1, %226
  %228 = and i32 %227, %225
  %229 = icmp ne i32 %228, 0
  %230 = lshr i32 %211, 3
  %231 = zext i32 %230 to i64
  %232 = getelementptr inbounds i8, ptr %220, i64 %231
  %233 = load i8, ptr %232, align 1
  %234 = zext i8 %233 to i32
  %235 = and i32 %211, 7
  %236 = shl nuw nsw i32 1, %235
  %237 = and i32 %236, %234
  %238 = icmp ne i32 %237, 0
  %239 = and i1 %229, %238
  %240 = and i1 %215, %239
  br i1 %240, label %after_if.3, label %after_if.sink.split.3

after_if.sink.split.3:                            ; preds = %true_block.3, %after_if.2
  %241 = load ptr, ptr %0, align 8
  %242 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %241, i64 0, i32 4, i32 1
  %243 = load ptr, ptr %242, align 8
  %244 = getelementptr i64, ptr %243, i64 5
  %245 = atomicrmw or ptr %244, i64 1 seq_cst, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %after_if.sink.split.3, %true_block.3
  %246 = load ptr, ptr %21, align 8
  %247 = load i32, ptr %22, align 4
  %248 = sext i32 %247 to i64
  %uglygep27 = getelementptr i8, ptr %246, i64 %80
  %uglygep28 = getelementptr i8, ptr %uglygep27, i64 -12
  %249 = load i32, ptr %uglygep28, align 4
  %250 = add i64 %lsr.iv, %248
  %251 = getelementptr i32, ptr %246, i64 %250
  %252 = getelementptr i32, ptr %251, i64 -3
  %253 = load i32, ptr %252, align 4
  %254 = icmp ult i32 %249, 70
  %255 = icmp ult i32 %253, 70
  %256 = and i1 %254, %255
  br i1 %256, label %true_block.4, label %after_if.sink.split.4

true_block.4:                                     ; preds = %after_if.3
  %257 = icmp ne i32 %249, %253
  %258 = load ptr, ptr %3, align 8
  %259 = getelementptr inbounds %struct.LLVMRuntime, ptr %258, i64 0, i32 7
  %260 = load ptr, ptr %259, align 8
  %261 = load ptr, ptr %260, align 8
  %262 = getelementptr %1, ptr %261, i64 0, i32 2, i32 1, i64 127
  %263 = lshr i32 %249, 3
  %264 = zext i32 %263 to i64
  %265 = getelementptr inbounds i8, ptr %262, i64 %264
  %266 = load i8, ptr %265, align 1
  %267 = zext i8 %266 to i32
  %268 = and i32 %249, 7
  %269 = shl nuw nsw i32 1, %268
  %270 = and i32 %269, %267
  %271 = icmp ne i32 %270, 0
  %272 = lshr i32 %253, 3
  %273 = zext i32 %272 to i64
  %274 = getelementptr inbounds i8, ptr %262, i64 %273
  %275 = load i8, ptr %274, align 1
  %276 = zext i8 %275 to i32
  %277 = and i32 %253, 7
  %278 = shl nuw nsw i32 1, %277
  %279 = and i32 %278, %276
  %280 = icmp ne i32 %279, 0
  %281 = and i1 %271, %280
  %282 = and i1 %257, %281
  br i1 %282, label %after_if.4, label %after_if.sink.split.4

after_if.sink.split.4:                            ; preds = %true_block.4, %after_if.3
  %283 = load ptr, ptr %0, align 8
  %284 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %283, i64 0, i32 4, i32 1
  %285 = load ptr, ptr %284, align 8
  %286 = getelementptr i64, ptr %285, i64 5
  %287 = atomicrmw or ptr %286, i64 1 seq_cst, align 8
  br label %after_if.4

after_if.4:                                       ; preds = %after_if.sink.split.4, %true_block.4
  %288 = load ptr, ptr %21, align 8
  %289 = load i32, ptr %22, align 4
  %290 = sext i32 %289 to i64
  %uglygep25 = getelementptr i8, ptr %288, i64 %80
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 -8
  %291 = load i32, ptr %uglygep26, align 4
  %292 = add i64 %lsr.iv, %290
  %293 = getelementptr i32, ptr %288, i64 %292
  %294 = getelementptr i32, ptr %293, i64 -2
  %295 = load i32, ptr %294, align 4
  %296 = icmp ult i32 %291, 70
  %297 = icmp ult i32 %295, 70
  %298 = and i1 %296, %297
  br i1 %298, label %true_block.5, label %after_if.sink.split.5

true_block.5:                                     ; preds = %after_if.4
  %299 = icmp ne i32 %291, %295
  %300 = load ptr, ptr %3, align 8
  %301 = getelementptr inbounds %struct.LLVMRuntime, ptr %300, i64 0, i32 7
  %302 = load ptr, ptr %301, align 8
  %303 = load ptr, ptr %302, align 8
  %304 = getelementptr %1, ptr %303, i64 0, i32 2, i32 1, i64 127
  %305 = lshr i32 %291, 3
  %306 = zext i32 %305 to i64
  %307 = getelementptr inbounds i8, ptr %304, i64 %306
  %308 = load i8, ptr %307, align 1
  %309 = zext i8 %308 to i32
  %310 = and i32 %291, 7
  %311 = shl nuw nsw i32 1, %310
  %312 = and i32 %311, %309
  %313 = icmp ne i32 %312, 0
  %314 = lshr i32 %295, 3
  %315 = zext i32 %314 to i64
  %316 = getelementptr inbounds i8, ptr %304, i64 %315
  %317 = load i8, ptr %316, align 1
  %318 = zext i8 %317 to i32
  %319 = and i32 %295, 7
  %320 = shl nuw nsw i32 1, %319
  %321 = and i32 %320, %318
  %322 = icmp ne i32 %321, 0
  %323 = and i1 %313, %322
  %324 = and i1 %299, %323
  br i1 %324, label %after_if.5, label %after_if.sink.split.5

after_if.sink.split.5:                            ; preds = %true_block.5, %after_if.4
  %325 = load ptr, ptr %0, align 8
  %326 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %325, i64 0, i32 4, i32 1
  %327 = load ptr, ptr %326, align 8
  %328 = getelementptr i64, ptr %327, i64 5
  %329 = atomicrmw or ptr %328, i64 1 seq_cst, align 8
  br label %after_if.5

after_if.5:                                       ; preds = %after_if.sink.split.5, %true_block.5
  %330 = load ptr, ptr %21, align 8
  %331 = load i32, ptr %22, align 4
  %332 = sext i32 %331 to i64
  %uglygep23 = getelementptr i8, ptr %330, i64 %80
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 -4
  %333 = load i32, ptr %uglygep24, align 4
  %334 = add i64 %lsr.iv, %332
  %335 = getelementptr i32, ptr %330, i64 %334
  %336 = getelementptr i32, ptr %335, i64 -1
  %337 = load i32, ptr %336, align 4
  %338 = icmp ult i32 %333, 70
  %339 = icmp ult i32 %337, 70
  %340 = and i1 %338, %339
  br i1 %340, label %true_block.6, label %after_if.sink.split.6

true_block.6:                                     ; preds = %after_if.5
  %341 = icmp ne i32 %333, %337
  %342 = load ptr, ptr %3, align 8
  %343 = getelementptr inbounds %struct.LLVMRuntime, ptr %342, i64 0, i32 7
  %344 = load ptr, ptr %343, align 8
  %345 = load ptr, ptr %344, align 8
  %346 = getelementptr %1, ptr %345, i64 0, i32 2, i32 1, i64 127
  %347 = lshr i32 %333, 3
  %348 = zext i32 %347 to i64
  %349 = getelementptr inbounds i8, ptr %346, i64 %348
  %350 = load i8, ptr %349, align 1
  %351 = zext i8 %350 to i32
  %352 = and i32 %333, 7
  %353 = shl nuw nsw i32 1, %352
  %354 = and i32 %353, %351
  %355 = icmp ne i32 %354, 0
  %356 = lshr i32 %337, 3
  %357 = zext i32 %356 to i64
  %358 = getelementptr inbounds i8, ptr %346, i64 %357
  %359 = load i8, ptr %358, align 1
  %360 = zext i8 %359 to i32
  %361 = and i32 %337, 7
  %362 = shl nuw nsw i32 1, %361
  %363 = and i32 %362, %360
  %364 = icmp ne i32 %363, 0
  %365 = and i1 %355, %364
  %366 = and i1 %341, %365
  br i1 %366, label %after_if.6, label %after_if.sink.split.6

after_if.sink.split.6:                            ; preds = %true_block.6, %after_if.5
  %367 = load ptr, ptr %0, align 8
  %368 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %367, i64 0, i32 4, i32 1
  %369 = load ptr, ptr %368, align 8
  %370 = getelementptr i64, ptr %369, i64 5
  %371 = atomicrmw or ptr %370, i64 1 seq_cst, align 8
  br label %after_if.6

after_if.6:                                       ; preds = %after_if.sink.split.6, %true_block.6
  %372 = load ptr, ptr %21, align 8
  %373 = load i32, ptr %22, align 4
  %374 = sext i32 %373 to i64
  %uglygep = getelementptr i8, ptr %372, i64 %80
  %375 = load i32, ptr %uglygep, align 4
  %376 = add nsw i64 %lsr.iv, %374
  %377 = getelementptr i32, ptr %372, i64 %376
  %378 = load i32, ptr %377, align 4
  %379 = icmp ult i32 %375, 70
  %380 = icmp ult i32 %378, 70
  %381 = and i1 %379, %380
  br i1 %381, label %true_block.7, label %after_if.sink.split.7

true_block.7:                                     ; preds = %after_if.6
  %382 = icmp ne i32 %375, %378
  %383 = load ptr, ptr %3, align 8
  %384 = getelementptr inbounds %struct.LLVMRuntime, ptr %383, i64 0, i32 7
  %385 = load ptr, ptr %384, align 8
  %386 = load ptr, ptr %385, align 8
  %387 = getelementptr %1, ptr %386, i64 0, i32 2, i32 1, i64 127
  %388 = lshr i32 %375, 3
  %389 = zext i32 %388 to i64
  %390 = getelementptr inbounds i8, ptr %387, i64 %389
  %391 = load i8, ptr %390, align 1
  %392 = zext i8 %391 to i32
  %393 = and i32 %375, 7
  %394 = shl nuw nsw i32 1, %393
  %395 = and i32 %394, %392
  %396 = icmp ne i32 %395, 0
  %397 = lshr i32 %378, 3
  %398 = zext i32 %397 to i64
  %399 = getelementptr inbounds i8, ptr %387, i64 %398
  %400 = load i8, ptr %399, align 1
  %401 = zext i8 %400 to i32
  %402 = and i32 %378, 7
  %403 = shl nuw nsw i32 1, %402
  %404 = and i32 %403, %401
  %405 = icmp ne i32 %404, 0
  %406 = and i1 %396, %405
  %407 = and i1 %382, %406
  br i1 %407, label %after_if.7, label %after_if.sink.split.7

after_if.sink.split.7:                            ; preds = %true_block.7, %after_if.6
  %408 = load ptr, ptr %0, align 8
  %409 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %408, i64 0, i32 4, i32 1
  %410 = load ptr, ptr %409, align 8
  %411 = getelementptr i64, ptr %410, i64 5
  %412 = atomicrmw or ptr %411, i64 1 seq_cst, align 8
  br label %after_if.7

after_if.7:                                       ; preds = %after_if.sink.split.7, %true_block.7
  %lsr.iv.next = add i64 %lsr.iv, 8
  %413 = add i64 %75, %lsr.iv.next
  %exitcond.not.7 = icmp eq i64 %413, 7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: nofree norecurse nosync nounwind
define void @geometry_collect_5_selection_25_kernel_7_serial(ptr %context) local_unnamed_addr #4 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.970, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 16
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds i8, ptr %3, i64 4
  %5 = load i32, ptr %4, align 4
  %6 = icmp sgt i32 %5, 0
  %7 = load ptr, ptr %context, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %7, i64 0, i32 4, i32 1
  %9 = load ptr, ptr %8, align 8
  %10 = load i64, ptr %9, align 8
  %11 = icmp ne i64 %10, 0
  %12 = zext i1 %11 to i64
  %13 = select i1 %6, i64 2, i64 %12
  %14 = getelementptr i64, ptr %9, i64 6
  store i64 %13, ptr %14, align 8
  br i1 %6, label %for_loop_body.preheader, label %after_for

for_loop_body.preheader:                          ; preds = %entry
  %wide.trip.count = zext i32 %5 to i64
  %15 = add nsw i64 %wide.trip.count, -1
  %xtraiter = and i64 %wide.trip.count, 3
  %16 = icmp ult i64 %15, 3
  br i1 %16, label %after_for.loopexit.unr-lcssa, label %for_loop_body.preheader.new

for_loop_body.preheader.new:                      ; preds = %for_loop_body.preheader
  %unroll_iter = and i64 %wide.trip.count, 4294967292
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if.3, %for_loop_body.preheader.new
  %indvars.iv = phi i64 [ 0, %for_loop_body.preheader.new ], [ %indvars.iv.next.3, %after_if.3 ]
  %.01022 = phi double [ 0.000000e+00, %for_loop_body.preheader.new ], [ %.1.3, %after_if.3 ]
  %.01121 = phi double [ 0.000000e+00, %for_loop_body.preheader.new ], [ %.112.3, %after_if.3 ]
  %.01320 = phi double [ 0.000000e+00, %for_loop_body.preheader.new ], [ %.114.3, %after_if.3 ]
  %.01519 = phi double [ 0.000000e+00, %for_loop_body.preheader.new ], [ %.116.3, %after_if.3 ]
  %17 = load ptr, ptr %context, align 8
  %18 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %17, i64 0, i32 7, i32 1
  %19 = load ptr, ptr %18, align 8
  %20 = shl i64 %indvars.iv, 2
  %uglygep43 = getelementptr i8, ptr %19, i64 %20
  %21 = load i32, ptr %uglygep43, align 4
  %22 = icmp ult i32 %21, 70
  br i1 %22, label %true_block, label %false_block

after_for.loopexit.unr-lcssa.loopexit:            ; preds = %after_if.3
  br label %after_for.loopexit.unr-lcssa

after_for.loopexit.unr-lcssa:                     ; preds = %after_for.loopexit.unr-lcssa.loopexit, %for_loop_body.preheader
  %.116.lcssa.ph = phi double [ undef, %for_loop_body.preheader ], [ %.116.3, %after_for.loopexit.unr-lcssa.loopexit ]
  %.114.lcssa.ph = phi double [ undef, %for_loop_body.preheader ], [ %.114.3, %after_for.loopexit.unr-lcssa.loopexit ]
  %.112.lcssa.ph = phi double [ undef, %for_loop_body.preheader ], [ %.112.3, %after_for.loopexit.unr-lcssa.loopexit ]
  %.1.lcssa.ph = phi double [ undef, %for_loop_body.preheader ], [ %.1.3, %after_for.loopexit.unr-lcssa.loopexit ]
  %indvars.iv.unr = phi i64 [ 0, %for_loop_body.preheader ], [ %indvars.iv.next.3, %after_for.loopexit.unr-lcssa.loopexit ]
  %.01022.unr = phi double [ 0.000000e+00, %for_loop_body.preheader ], [ %.1.3, %after_for.loopexit.unr-lcssa.loopexit ]
  %.01121.unr = phi double [ 0.000000e+00, %for_loop_body.preheader ], [ %.112.3, %after_for.loopexit.unr-lcssa.loopexit ]
  %.01320.unr = phi double [ 0.000000e+00, %for_loop_body.preheader ], [ %.114.3, %after_for.loopexit.unr-lcssa.loopexit ]
  %.01519.unr = phi double [ 0.000000e+00, %for_loop_body.preheader ], [ %.116.3, %after_for.loopexit.unr-lcssa.loopexit ]
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %after_for, label %for_loop_body.epil.preheader

for_loop_body.epil.preheader:                     ; preds = %after_for.loopexit.unr-lcssa
  br label %for_loop_body.epil

for_loop_body.epil:                               ; preds = %after_if.epil, %for_loop_body.epil.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body.epil.preheader ], [ %lsr.iv.next, %after_if.epil ]
  %indvars.iv.epil = phi i64 [ %indvars.iv.next.epil, %after_if.epil ], [ %indvars.iv.unr, %for_loop_body.epil.preheader ]
  %.01022.epil = phi double [ %.1.epil, %after_if.epil ], [ %.01022.unr, %for_loop_body.epil.preheader ]
  %.01121.epil = phi double [ %.112.epil, %after_if.epil ], [ %.01121.unr, %for_loop_body.epil.preheader ]
  %.01320.epil = phi double [ %.114.epil, %after_if.epil ], [ %.01320.unr, %for_loop_body.epil.preheader ]
  %.01519.epil = phi double [ %.116.epil, %after_if.epil ], [ %.01519.unr, %for_loop_body.epil.preheader ]
  %23 = load ptr, ptr %context, align 8
  %24 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %23, i64 0, i32 7, i32 1
  %25 = load ptr, ptr %24, align 8
  %26 = shl i64 %indvars.iv.epil, 2
  %uglygep = getelementptr i8, ptr %25, i64 %26
  %27 = load i32, ptr %uglygep, align 4
  %28 = icmp ult i32 %27, 70
  br i1 %28, label %true_block.epil, label %false_block.epil

false_block.epil:                                 ; preds = %for_loop_body.epil
  store i64 3, ptr %14, align 8
  br label %after_if.epil

true_block.epil:                                  ; preds = %for_loop_body.epil
  %29 = load ptr, ptr %0, align 8
  %30 = getelementptr inbounds %struct.LLVMRuntime, ptr %29, i64 0, i32 7
  %31 = load ptr, ptr %30, align 8
  %32 = getelementptr inbounds ptr, ptr %31, i64 1
  %33 = load ptr, ptr %32, align 8
  %34 = getelementptr %6, ptr %33, i64 0, i32 2, i32 1, i64 127
  %35 = lshr i32 %27, 3
  %36 = zext i32 %35 to i64
  %37 = getelementptr inbounds i8, ptr %34, i64 %36
  %38 = load i8, ptr %37, align 1
  %39 = zext i8 %38 to i32
  %40 = and i32 %27, 7
  %41 = shl nuw nsw i32 1, %40
  %42 = and i32 %41, %39
  %.not.epil = icmp eq i32 %42, 0
  br i1 %.not.epil, label %false_block2.epil, label %true_block1.epil

true_block1.epil:                                 ; preds = %true_block.epil
  %43 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %23, i64 0, i32 1, i32 1
  %44 = load ptr, ptr %43, align 8
  %45 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %23, i64 0, i32 1, i32 0, i32 1
  %46 = load i32, ptr %45, align 4
  %47 = sext i32 %46 to i64
  %48 = mul nsw i64 %47, 3
  %49 = zext i32 %27 to i64
  %50 = add nsw i64 %48, %49
  %51 = getelementptr double, ptr %44, i64 %50
  %52 = load double, ptr %51, align 8
  %53 = bitcast double %52 to i64
  %54 = and i64 %53, 9223372036854775807
  %55 = and i64 %53, 9218868437227405312
  %56 = icmp eq i64 %54, 0
  %57 = icmp ne i64 %55, 0
  %58 = icmp ne i64 %55, 9218868437227405312
  %59 = and i1 %57, %58
  %60 = or i1 %56, %59
  br i1 %60, label %after_if6.epil, label %true_block4.epil

true_block4.epil:                                 ; preds = %true_block1.epil
  %61 = load ptr, ptr %8, align 8
  %62 = getelementptr i64, ptr %61, i64 5
  %63 = load i64, ptr %62, align 8
  %64 = or i64 %63, 1
  store i64 %64, ptr %62, align 8
  br label %after_if6.epil

after_if6.epil:                                   ; preds = %true_block4.epil, %true_block1.epil
  %65 = fcmp ogt double %52, 0.000000e+00
  br i1 %65, label %true_block7.epil, label %false_block8.epil

false_block8.epil:                                ; preds = %after_if6.epil
  store i64 3, ptr %14, align 8
  br label %after_if.epil

true_block7.epil:                                 ; preds = %after_if6.epil
  %66 = fadd double %.01022.epil, %52
  %67 = load ptr, ptr %43, align 8
  %68 = getelementptr double, ptr %67, i64 %49
  %69 = load double, ptr %68, align 8
  %70 = bitcast double %69 to i64
  %71 = and i64 %70, 9223372036854775807
  %72 = and i64 %70, 9218868437227405312
  %73 = icmp eq i64 %71, 0
  %74 = icmp ne i64 %72, 0
  %75 = icmp ne i64 %72, 9218868437227405312
  %76 = and i1 %74, %75
  %77 = or i1 %73, %76
  br i1 %77, label %after_if12.epil, label %true_block10.epil

true_block10.epil:                                ; preds = %true_block7.epil
  %78 = load ptr, ptr %8, align 8
  %79 = getelementptr i64, ptr %78, i64 5
  %80 = load i64, ptr %79, align 8
  %81 = or i64 %80, 1
  store i64 %81, ptr %79, align 8
  %.pre.epil = load ptr, ptr %43, align 8
  br label %after_if12.epil

after_if12.epil:                                  ; preds = %true_block10.epil, %true_block7.epil
  %82 = phi ptr [ %67, %true_block7.epil ], [ %.pre.epil, %true_block10.epil ]
  %83 = load ptr, ptr %context, align 8
  %84 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %83, i64 0, i32 6, i32 1
  %85 = load ptr, ptr %84, align 8
  %86 = load double, ptr %85, align 8
  %87 = fsub double %69, %86
  %88 = fmul double %52, %87
  %89 = fadd double %.01519.epil, %88
  %90 = load i32, ptr %45, align 4
  %91 = sext i32 %90 to i64
  %92 = add nsw i64 %91, %49
  %93 = getelementptr double, ptr %82, i64 %92
  %94 = load double, ptr %93, align 8
  %95 = bitcast double %94 to i64
  %96 = and i64 %95, 9223372036854775807
  %97 = and i64 %95, 9218868437227405312
  %98 = icmp eq i64 %96, 0
  %99 = icmp ne i64 %97, 0
  %100 = icmp ne i64 %97, 9218868437227405312
  %101 = and i1 %99, %100
  %102 = or i1 %98, %101
  br i1 %102, label %after_if15.epil, label %true_block13.epil

true_block13.epil:                                ; preds = %after_if12.epil
  %103 = load ptr, ptr %8, align 8
  %104 = getelementptr i64, ptr %103, i64 5
  %105 = load i64, ptr %104, align 8
  %106 = or i64 %105, 1
  store i64 %106, ptr %104, align 8
  %.pre28.epil = load ptr, ptr %84, align 8
  %.pre29.epil = load ptr, ptr %43, align 8
  %.pre30.epil = load i32, ptr %45, align 4
  %.pre32.epil = sext i32 %.pre30.epil to i64
  br label %after_if15.epil

after_if15.epil:                                  ; preds = %true_block13.epil, %after_if12.epil
  %.pre-phi.epil = phi i64 [ %91, %after_if12.epil ], [ %.pre32.epil, %true_block13.epil ]
  %107 = phi ptr [ %82, %after_if12.epil ], [ %.pre29.epil, %true_block13.epil ]
  %108 = phi ptr [ %85, %after_if12.epil ], [ %.pre28.epil, %true_block13.epil ]
  %109 = getelementptr double, ptr %108, i64 1
  %110 = load double, ptr %109, align 8
  %111 = fsub double %94, %110
  %112 = fmul double %52, %111
  %113 = fadd double %.01320.epil, %112
  %114 = shl nsw i64 %.pre-phi.epil, 1
  %115 = add nsw i64 %114, %49
  %116 = getelementptr double, ptr %107, i64 %115
  %117 = load double, ptr %116, align 8
  %118 = bitcast double %117 to i64
  %119 = and i64 %118, 9223372036854775807
  %120 = and i64 %118, 9218868437227405312
  %121 = icmp eq i64 %119, 0
  %122 = icmp ne i64 %120, 0
  %123 = icmp ne i64 %120, 9218868437227405312
  %124 = and i1 %122, %123
  %125 = or i1 %121, %124
  br i1 %125, label %after_if18.epil, label %true_block16.epil

true_block16.epil:                                ; preds = %after_if15.epil
  %126 = load ptr, ptr %8, align 8
  %127 = getelementptr i64, ptr %126, i64 5
  %128 = load i64, ptr %127, align 8
  %129 = or i64 %128, 1
  store i64 %129, ptr %127, align 8
  %.pre31.epil = load ptr, ptr %84, align 8
  br label %after_if18.epil

after_if18.epil:                                  ; preds = %true_block16.epil, %after_if15.epil
  %130 = phi ptr [ %108, %after_if15.epil ], [ %.pre31.epil, %true_block16.epil ]
  %131 = getelementptr double, ptr %130, i64 2
  %132 = load double, ptr %131, align 8
  %133 = fsub double %117, %132
  %134 = fmul double %52, %133
  %135 = fadd double %.01121.epil, %134
  br label %after_if.epil

false_block2.epil:                                ; preds = %true_block.epil
  store i64 3, ptr %14, align 8
  br label %after_if.epil

after_if.epil:                                    ; preds = %false_block2.epil, %after_if18.epil, %false_block8.epil, %false_block.epil
  %.116.epil = phi double [ %89, %after_if18.epil ], [ %.01519.epil, %false_block8.epil ], [ %.01519.epil, %false_block2.epil ], [ %.01519.epil, %false_block.epil ]
  %.114.epil = phi double [ %113, %after_if18.epil ], [ %.01320.epil, %false_block8.epil ], [ %.01320.epil, %false_block2.epil ], [ %.01320.epil, %false_block.epil ]
  %.112.epil = phi double [ %135, %after_if18.epil ], [ %.01121.epil, %false_block8.epil ], [ %.01121.epil, %false_block2.epil ], [ %.01121.epil, %false_block.epil ]
  %.1.epil = phi double [ %66, %after_if18.epil ], [ %.01022.epil, %false_block8.epil ], [ %.01022.epil, %false_block2.epil ], [ %.01022.epil, %false_block.epil ]
  %indvars.iv.next.epil = add nuw nsw i64 %indvars.iv.epil, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %epil.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %epil.iter.cmp.not, label %after_for.loopexit, label %for_loop_body.epil, !llvm.loop !12

after_for.loopexit:                               ; preds = %after_if.epil
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %after_for.loopexit.unr-lcssa, %entry
  %.015.lcssa = phi double [ 0.000000e+00, %entry ], [ %.116.lcssa.ph, %after_for.loopexit.unr-lcssa ], [ %.116.epil, %after_for.loopexit ]
  %.013.lcssa = phi double [ 0.000000e+00, %entry ], [ %.114.lcssa.ph, %after_for.loopexit.unr-lcssa ], [ %.114.epil, %after_for.loopexit ]
  %.011.lcssa = phi double [ 0.000000e+00, %entry ], [ %.112.lcssa.ph, %after_for.loopexit.unr-lcssa ], [ %.112.epil, %after_for.loopexit ]
  %.010.lcssa = phi double [ 0.000000e+00, %entry ], [ %.1.lcssa.ph, %after_for.loopexit.unr-lcssa ], [ %.1.epil, %after_for.loopexit ]
  %136 = fcmp ogt double %.010.lcssa, 0.000000e+00
  %137 = fcmp olt double %.010.lcssa, 0.000000e+00
  %..i.op = select i1 %137, double 2.000000e+00, double 1.000000e+00
  %138 = select i1 %136, double 0.000000e+00, double %..i.op
  %139 = fadd double %.010.lcssa, %138
  %140 = bitcast double %.010.lcssa to i64
  %141 = and i64 %140, 9223372036854775807
  %142 = and i64 %140, 9218868437227405312
  %143 = icmp eq i64 %141, 0
  %144 = icmp ne i64 %142, 0
  %145 = icmp ne i64 %142, 9218868437227405312
  %146 = and i1 %144, %145
  %147 = or i1 %143, %146
  br i1 %147, label %after_if21, label %true_block19

true_block:                                       ; preds = %for_loop_body
  %148 = load ptr, ptr %0, align 8
  %149 = getelementptr inbounds %struct.LLVMRuntime, ptr %148, i64 0, i32 7
  %150 = load ptr, ptr %149, align 8
  %151 = getelementptr inbounds ptr, ptr %150, i64 1
  %152 = load ptr, ptr %151, align 8
  %153 = getelementptr %6, ptr %152, i64 0, i32 2, i32 1, i64 127
  %154 = lshr i32 %21, 3
  %155 = zext i32 %154 to i64
  %156 = getelementptr inbounds i8, ptr %153, i64 %155
  %157 = load i8, ptr %156, align 1
  %158 = zext i8 %157 to i32
  %159 = and i32 %21, 7
  %160 = shl nuw nsw i32 1, %159
  %161 = and i32 %160, %158
  %.not = icmp eq i32 %161, 0
  br i1 %.not, label %false_block2, label %true_block1

false_block:                                      ; preds = %for_loop_body
  store i64 3, ptr %14, align 8
  br label %after_if

after_if:                                         ; preds = %after_if18, %false_block8, %false_block2, %false_block
  %.116 = phi double [ %544, %after_if18 ], [ %.01519, %false_block8 ], [ %.01519, %false_block2 ], [ %.01519, %false_block ]
  %.114 = phi double [ %568, %after_if18 ], [ %.01320, %false_block8 ], [ %.01320, %false_block2 ], [ %.01320, %false_block ]
  %.112 = phi double [ %590, %after_if18 ], [ %.01121, %false_block8 ], [ %.01121, %false_block2 ], [ %.01121, %false_block ]
  %.1 = phi double [ %521, %after_if18 ], [ %.01022, %false_block8 ], [ %.01022, %false_block2 ], [ %.01022, %false_block ]
  %162 = load ptr, ptr %context, align 8
  %163 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %162, i64 0, i32 7, i32 1
  %164 = load ptr, ptr %163, align 8
  %uglygep39 = getelementptr i8, ptr %164, i64 4
  %uglygep40 = getelementptr i8, ptr %uglygep39, i64 %20
  %165 = load i32, ptr %uglygep40, align 4
  %166 = icmp ult i32 %165, 70
  br i1 %166, label %true_block.1, label %false_block.1

false_block.1:                                    ; preds = %after_if
  store i64 3, ptr %14, align 8
  br label %after_if.1

true_block.1:                                     ; preds = %after_if
  %167 = load ptr, ptr %0, align 8
  %168 = getelementptr inbounds %struct.LLVMRuntime, ptr %167, i64 0, i32 7
  %169 = load ptr, ptr %168, align 8
  %170 = getelementptr inbounds ptr, ptr %169, i64 1
  %171 = load ptr, ptr %170, align 8
  %172 = getelementptr %6, ptr %171, i64 0, i32 2, i32 1, i64 127
  %173 = lshr i32 %165, 3
  %174 = zext i32 %173 to i64
  %175 = getelementptr inbounds i8, ptr %172, i64 %174
  %176 = load i8, ptr %175, align 1
  %177 = zext i8 %176 to i32
  %178 = and i32 %165, 7
  %179 = shl nuw nsw i32 1, %178
  %180 = and i32 %179, %177
  %.not.1 = icmp eq i32 %180, 0
  br i1 %.not.1, label %false_block2.1, label %true_block1.1

true_block1.1:                                    ; preds = %true_block.1
  %181 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %162, i64 0, i32 1, i32 1
  %182 = load ptr, ptr %181, align 8
  %183 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %162, i64 0, i32 1, i32 0, i32 1
  %184 = load i32, ptr %183, align 4
  %185 = sext i32 %184 to i64
  %186 = mul nsw i64 %185, 3
  %187 = zext i32 %165 to i64
  %188 = add nsw i64 %186, %187
  %189 = getelementptr double, ptr %182, i64 %188
  %190 = load double, ptr %189, align 8
  %191 = bitcast double %190 to i64
  %192 = and i64 %191, 9223372036854775807
  %193 = and i64 %191, 9218868437227405312
  %194 = icmp eq i64 %192, 0
  %195 = icmp ne i64 %193, 0
  %196 = icmp ne i64 %193, 9218868437227405312
  %197 = and i1 %195, %196
  %198 = or i1 %194, %197
  br i1 %198, label %after_if6.1, label %true_block4.1

true_block4.1:                                    ; preds = %true_block1.1
  %199 = load ptr, ptr %8, align 8
  %200 = getelementptr i64, ptr %199, i64 5
  %201 = load i64, ptr %200, align 8
  %202 = or i64 %201, 1
  store i64 %202, ptr %200, align 8
  br label %after_if6.1

after_if6.1:                                      ; preds = %true_block4.1, %true_block1.1
  %203 = fcmp ogt double %190, 0.000000e+00
  br i1 %203, label %true_block7.1, label %false_block8.1

false_block8.1:                                   ; preds = %after_if6.1
  store i64 3, ptr %14, align 8
  br label %after_if.1

true_block7.1:                                    ; preds = %after_if6.1
  %204 = fadd double %.1, %190
  %205 = load ptr, ptr %181, align 8
  %206 = getelementptr double, ptr %205, i64 %187
  %207 = load double, ptr %206, align 8
  %208 = bitcast double %207 to i64
  %209 = and i64 %208, 9223372036854775807
  %210 = and i64 %208, 9218868437227405312
  %211 = icmp eq i64 %209, 0
  %212 = icmp ne i64 %210, 0
  %213 = icmp ne i64 %210, 9218868437227405312
  %214 = and i1 %212, %213
  %215 = or i1 %211, %214
  br i1 %215, label %after_if12.1, label %true_block10.1

true_block10.1:                                   ; preds = %true_block7.1
  %216 = load ptr, ptr %8, align 8
  %217 = getelementptr i64, ptr %216, i64 5
  %218 = load i64, ptr %217, align 8
  %219 = or i64 %218, 1
  store i64 %219, ptr %217, align 8
  %.pre.1 = load ptr, ptr %181, align 8
  br label %after_if12.1

after_if12.1:                                     ; preds = %true_block10.1, %true_block7.1
  %220 = phi ptr [ %205, %true_block7.1 ], [ %.pre.1, %true_block10.1 ]
  %221 = load ptr, ptr %context, align 8
  %222 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %221, i64 0, i32 6, i32 1
  %223 = load ptr, ptr %222, align 8
  %224 = load double, ptr %223, align 8
  %225 = fsub double %207, %224
  %226 = fmul double %190, %225
  %227 = fadd double %.116, %226
  %228 = load i32, ptr %183, align 4
  %229 = sext i32 %228 to i64
  %230 = add nsw i64 %229, %187
  %231 = getelementptr double, ptr %220, i64 %230
  %232 = load double, ptr %231, align 8
  %233 = bitcast double %232 to i64
  %234 = and i64 %233, 9223372036854775807
  %235 = and i64 %233, 9218868437227405312
  %236 = icmp eq i64 %234, 0
  %237 = icmp ne i64 %235, 0
  %238 = icmp ne i64 %235, 9218868437227405312
  %239 = and i1 %237, %238
  %240 = or i1 %236, %239
  br i1 %240, label %after_if15.1, label %true_block13.1

true_block13.1:                                   ; preds = %after_if12.1
  %241 = load ptr, ptr %8, align 8
  %242 = getelementptr i64, ptr %241, i64 5
  %243 = load i64, ptr %242, align 8
  %244 = or i64 %243, 1
  store i64 %244, ptr %242, align 8
  %.pre28.1 = load ptr, ptr %222, align 8
  %.pre29.1 = load ptr, ptr %181, align 8
  %.pre30.1 = load i32, ptr %183, align 4
  %.pre32.1 = sext i32 %.pre30.1 to i64
  br label %after_if15.1

after_if15.1:                                     ; preds = %true_block13.1, %after_if12.1
  %.pre-phi.1 = phi i64 [ %229, %after_if12.1 ], [ %.pre32.1, %true_block13.1 ]
  %245 = phi ptr [ %220, %after_if12.1 ], [ %.pre29.1, %true_block13.1 ]
  %246 = phi ptr [ %223, %after_if12.1 ], [ %.pre28.1, %true_block13.1 ]
  %247 = getelementptr double, ptr %246, i64 1
  %248 = load double, ptr %247, align 8
  %249 = fsub double %232, %248
  %250 = fmul double %190, %249
  %251 = fadd double %.114, %250
  %252 = shl nsw i64 %.pre-phi.1, 1
  %253 = add nsw i64 %252, %187
  %254 = getelementptr double, ptr %245, i64 %253
  %255 = load double, ptr %254, align 8
  %256 = bitcast double %255 to i64
  %257 = and i64 %256, 9223372036854775807
  %258 = and i64 %256, 9218868437227405312
  %259 = icmp eq i64 %257, 0
  %260 = icmp ne i64 %258, 0
  %261 = icmp ne i64 %258, 9218868437227405312
  %262 = and i1 %260, %261
  %263 = or i1 %259, %262
  br i1 %263, label %after_if18.1, label %true_block16.1

true_block16.1:                                   ; preds = %after_if15.1
  %264 = load ptr, ptr %8, align 8
  %265 = getelementptr i64, ptr %264, i64 5
  %266 = load i64, ptr %265, align 8
  %267 = or i64 %266, 1
  store i64 %267, ptr %265, align 8
  %.pre31.1 = load ptr, ptr %222, align 8
  br label %after_if18.1

after_if18.1:                                     ; preds = %true_block16.1, %after_if15.1
  %268 = phi ptr [ %246, %after_if15.1 ], [ %.pre31.1, %true_block16.1 ]
  %269 = getelementptr double, ptr %268, i64 2
  %270 = load double, ptr %269, align 8
  %271 = fsub double %255, %270
  %272 = fmul double %190, %271
  %273 = fadd double %.112, %272
  br label %after_if.1

false_block2.1:                                   ; preds = %true_block.1
  store i64 3, ptr %14, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %false_block2.1, %after_if18.1, %false_block8.1, %false_block.1
  %.116.1 = phi double [ %227, %after_if18.1 ], [ %.116, %false_block8.1 ], [ %.116, %false_block2.1 ], [ %.116, %false_block.1 ]
  %.114.1 = phi double [ %251, %after_if18.1 ], [ %.114, %false_block8.1 ], [ %.114, %false_block2.1 ], [ %.114, %false_block.1 ]
  %.112.1 = phi double [ %273, %after_if18.1 ], [ %.112, %false_block8.1 ], [ %.112, %false_block2.1 ], [ %.112, %false_block.1 ]
  %.1.1 = phi double [ %204, %after_if18.1 ], [ %.1, %false_block8.1 ], [ %.1, %false_block2.1 ], [ %.1, %false_block.1 ]
  %274 = load ptr, ptr %context, align 8
  %275 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %274, i64 0, i32 7, i32 1
  %276 = load ptr, ptr %275, align 8
  %uglygep37 = getelementptr i8, ptr %276, i64 8
  %uglygep38 = getelementptr i8, ptr %uglygep37, i64 %20
  %277 = load i32, ptr %uglygep38, align 4
  %278 = icmp ult i32 %277, 70
  br i1 %278, label %true_block.2, label %false_block.2

false_block.2:                                    ; preds = %after_if.1
  store i64 3, ptr %14, align 8
  br label %after_if.2

true_block.2:                                     ; preds = %after_if.1
  %279 = load ptr, ptr %0, align 8
  %280 = getelementptr inbounds %struct.LLVMRuntime, ptr %279, i64 0, i32 7
  %281 = load ptr, ptr %280, align 8
  %282 = getelementptr inbounds ptr, ptr %281, i64 1
  %283 = load ptr, ptr %282, align 8
  %284 = getelementptr %6, ptr %283, i64 0, i32 2, i32 1, i64 127
  %285 = lshr i32 %277, 3
  %286 = zext i32 %285 to i64
  %287 = getelementptr inbounds i8, ptr %284, i64 %286
  %288 = load i8, ptr %287, align 1
  %289 = zext i8 %288 to i32
  %290 = and i32 %277, 7
  %291 = shl nuw nsw i32 1, %290
  %292 = and i32 %291, %289
  %.not.2 = icmp eq i32 %292, 0
  br i1 %.not.2, label %false_block2.2, label %true_block1.2

true_block1.2:                                    ; preds = %true_block.2
  %293 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %274, i64 0, i32 1, i32 1
  %294 = load ptr, ptr %293, align 8
  %295 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %274, i64 0, i32 1, i32 0, i32 1
  %296 = load i32, ptr %295, align 4
  %297 = sext i32 %296 to i64
  %298 = mul nsw i64 %297, 3
  %299 = zext i32 %277 to i64
  %300 = add nsw i64 %298, %299
  %301 = getelementptr double, ptr %294, i64 %300
  %302 = load double, ptr %301, align 8
  %303 = bitcast double %302 to i64
  %304 = and i64 %303, 9223372036854775807
  %305 = and i64 %303, 9218868437227405312
  %306 = icmp eq i64 %304, 0
  %307 = icmp ne i64 %305, 0
  %308 = icmp ne i64 %305, 9218868437227405312
  %309 = and i1 %307, %308
  %310 = or i1 %306, %309
  br i1 %310, label %after_if6.2, label %true_block4.2

true_block4.2:                                    ; preds = %true_block1.2
  %311 = load ptr, ptr %8, align 8
  %312 = getelementptr i64, ptr %311, i64 5
  %313 = load i64, ptr %312, align 8
  %314 = or i64 %313, 1
  store i64 %314, ptr %312, align 8
  br label %after_if6.2

after_if6.2:                                      ; preds = %true_block4.2, %true_block1.2
  %315 = fcmp ogt double %302, 0.000000e+00
  br i1 %315, label %true_block7.2, label %false_block8.2

false_block8.2:                                   ; preds = %after_if6.2
  store i64 3, ptr %14, align 8
  br label %after_if.2

true_block7.2:                                    ; preds = %after_if6.2
  %316 = fadd double %.1.1, %302
  %317 = load ptr, ptr %293, align 8
  %318 = getelementptr double, ptr %317, i64 %299
  %319 = load double, ptr %318, align 8
  %320 = bitcast double %319 to i64
  %321 = and i64 %320, 9223372036854775807
  %322 = and i64 %320, 9218868437227405312
  %323 = icmp eq i64 %321, 0
  %324 = icmp ne i64 %322, 0
  %325 = icmp ne i64 %322, 9218868437227405312
  %326 = and i1 %324, %325
  %327 = or i1 %323, %326
  br i1 %327, label %after_if12.2, label %true_block10.2

true_block10.2:                                   ; preds = %true_block7.2
  %328 = load ptr, ptr %8, align 8
  %329 = getelementptr i64, ptr %328, i64 5
  %330 = load i64, ptr %329, align 8
  %331 = or i64 %330, 1
  store i64 %331, ptr %329, align 8
  %.pre.2 = load ptr, ptr %293, align 8
  br label %after_if12.2

after_if12.2:                                     ; preds = %true_block10.2, %true_block7.2
  %332 = phi ptr [ %317, %true_block7.2 ], [ %.pre.2, %true_block10.2 ]
  %333 = load ptr, ptr %context, align 8
  %334 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %333, i64 0, i32 6, i32 1
  %335 = load ptr, ptr %334, align 8
  %336 = load double, ptr %335, align 8
  %337 = fsub double %319, %336
  %338 = fmul double %302, %337
  %339 = fadd double %.116.1, %338
  %340 = load i32, ptr %295, align 4
  %341 = sext i32 %340 to i64
  %342 = add nsw i64 %341, %299
  %343 = getelementptr double, ptr %332, i64 %342
  %344 = load double, ptr %343, align 8
  %345 = bitcast double %344 to i64
  %346 = and i64 %345, 9223372036854775807
  %347 = and i64 %345, 9218868437227405312
  %348 = icmp eq i64 %346, 0
  %349 = icmp ne i64 %347, 0
  %350 = icmp ne i64 %347, 9218868437227405312
  %351 = and i1 %349, %350
  %352 = or i1 %348, %351
  br i1 %352, label %after_if15.2, label %true_block13.2

true_block13.2:                                   ; preds = %after_if12.2
  %353 = load ptr, ptr %8, align 8
  %354 = getelementptr i64, ptr %353, i64 5
  %355 = load i64, ptr %354, align 8
  %356 = or i64 %355, 1
  store i64 %356, ptr %354, align 8
  %.pre28.2 = load ptr, ptr %334, align 8
  %.pre29.2 = load ptr, ptr %293, align 8
  %.pre30.2 = load i32, ptr %295, align 4
  %.pre32.2 = sext i32 %.pre30.2 to i64
  br label %after_if15.2

after_if15.2:                                     ; preds = %true_block13.2, %after_if12.2
  %.pre-phi.2 = phi i64 [ %341, %after_if12.2 ], [ %.pre32.2, %true_block13.2 ]
  %357 = phi ptr [ %332, %after_if12.2 ], [ %.pre29.2, %true_block13.2 ]
  %358 = phi ptr [ %335, %after_if12.2 ], [ %.pre28.2, %true_block13.2 ]
  %359 = getelementptr double, ptr %358, i64 1
  %360 = load double, ptr %359, align 8
  %361 = fsub double %344, %360
  %362 = fmul double %302, %361
  %363 = fadd double %.114.1, %362
  %364 = shl nsw i64 %.pre-phi.2, 1
  %365 = add nsw i64 %364, %299
  %366 = getelementptr double, ptr %357, i64 %365
  %367 = load double, ptr %366, align 8
  %368 = bitcast double %367 to i64
  %369 = and i64 %368, 9223372036854775807
  %370 = and i64 %368, 9218868437227405312
  %371 = icmp eq i64 %369, 0
  %372 = icmp ne i64 %370, 0
  %373 = icmp ne i64 %370, 9218868437227405312
  %374 = and i1 %372, %373
  %375 = or i1 %371, %374
  br i1 %375, label %after_if18.2, label %true_block16.2

true_block16.2:                                   ; preds = %after_if15.2
  %376 = load ptr, ptr %8, align 8
  %377 = getelementptr i64, ptr %376, i64 5
  %378 = load i64, ptr %377, align 8
  %379 = or i64 %378, 1
  store i64 %379, ptr %377, align 8
  %.pre31.2 = load ptr, ptr %334, align 8
  br label %after_if18.2

after_if18.2:                                     ; preds = %true_block16.2, %after_if15.2
  %380 = phi ptr [ %358, %after_if15.2 ], [ %.pre31.2, %true_block16.2 ]
  %381 = getelementptr double, ptr %380, i64 2
  %382 = load double, ptr %381, align 8
  %383 = fsub double %367, %382
  %384 = fmul double %302, %383
  %385 = fadd double %.112.1, %384
  br label %after_if.2

false_block2.2:                                   ; preds = %true_block.2
  store i64 3, ptr %14, align 8
  br label %after_if.2

after_if.2:                                       ; preds = %false_block2.2, %after_if18.2, %false_block8.2, %false_block.2
  %.116.2 = phi double [ %339, %after_if18.2 ], [ %.116.1, %false_block8.2 ], [ %.116.1, %false_block2.2 ], [ %.116.1, %false_block.2 ]
  %.114.2 = phi double [ %363, %after_if18.2 ], [ %.114.1, %false_block8.2 ], [ %.114.1, %false_block2.2 ], [ %.114.1, %false_block.2 ]
  %.112.2 = phi double [ %385, %after_if18.2 ], [ %.112.1, %false_block8.2 ], [ %.112.1, %false_block2.2 ], [ %.112.1, %false_block.2 ]
  %.1.2 = phi double [ %316, %after_if18.2 ], [ %.1.1, %false_block8.2 ], [ %.1.1, %false_block2.2 ], [ %.1.1, %false_block.2 ]
  %386 = load ptr, ptr %context, align 8
  %387 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %386, i64 0, i32 7, i32 1
  %388 = load ptr, ptr %387, align 8
  %uglygep41 = getelementptr i8, ptr %388, i64 12
  %uglygep42 = getelementptr i8, ptr %uglygep41, i64 %20
  %389 = load i32, ptr %uglygep42, align 4
  %390 = icmp ult i32 %389, 70
  br i1 %390, label %true_block.3, label %false_block.3

false_block.3:                                    ; preds = %after_if.2
  store i64 3, ptr %14, align 8
  br label %after_if.3

true_block.3:                                     ; preds = %after_if.2
  %391 = load ptr, ptr %0, align 8
  %392 = getelementptr inbounds %struct.LLVMRuntime, ptr %391, i64 0, i32 7
  %393 = load ptr, ptr %392, align 8
  %394 = getelementptr inbounds ptr, ptr %393, i64 1
  %395 = load ptr, ptr %394, align 8
  %396 = getelementptr %6, ptr %395, i64 0, i32 2, i32 1, i64 127
  %397 = lshr i32 %389, 3
  %398 = zext i32 %397 to i64
  %399 = getelementptr inbounds i8, ptr %396, i64 %398
  %400 = load i8, ptr %399, align 1
  %401 = zext i8 %400 to i32
  %402 = and i32 %389, 7
  %403 = shl nuw nsw i32 1, %402
  %404 = and i32 %403, %401
  %.not.3 = icmp eq i32 %404, 0
  br i1 %.not.3, label %false_block2.3, label %true_block1.3

true_block1.3:                                    ; preds = %true_block.3
  %405 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %386, i64 0, i32 1, i32 1
  %406 = load ptr, ptr %405, align 8
  %407 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %386, i64 0, i32 1, i32 0, i32 1
  %408 = load i32, ptr %407, align 4
  %409 = sext i32 %408 to i64
  %410 = mul nsw i64 %409, 3
  %411 = zext i32 %389 to i64
  %412 = add nsw i64 %410, %411
  %413 = getelementptr double, ptr %406, i64 %412
  %414 = load double, ptr %413, align 8
  %415 = bitcast double %414 to i64
  %416 = and i64 %415, 9223372036854775807
  %417 = and i64 %415, 9218868437227405312
  %418 = icmp eq i64 %416, 0
  %419 = icmp ne i64 %417, 0
  %420 = icmp ne i64 %417, 9218868437227405312
  %421 = and i1 %419, %420
  %422 = or i1 %418, %421
  br i1 %422, label %after_if6.3, label %true_block4.3

true_block4.3:                                    ; preds = %true_block1.3
  %423 = load ptr, ptr %8, align 8
  %424 = getelementptr i64, ptr %423, i64 5
  %425 = load i64, ptr %424, align 8
  %426 = or i64 %425, 1
  store i64 %426, ptr %424, align 8
  br label %after_if6.3

after_if6.3:                                      ; preds = %true_block4.3, %true_block1.3
  %427 = fcmp ogt double %414, 0.000000e+00
  br i1 %427, label %true_block7.3, label %false_block8.3

false_block8.3:                                   ; preds = %after_if6.3
  store i64 3, ptr %14, align 8
  br label %after_if.3

true_block7.3:                                    ; preds = %after_if6.3
  %428 = fadd double %.1.2, %414
  %429 = load ptr, ptr %405, align 8
  %430 = getelementptr double, ptr %429, i64 %411
  %431 = load double, ptr %430, align 8
  %432 = bitcast double %431 to i64
  %433 = and i64 %432, 9223372036854775807
  %434 = and i64 %432, 9218868437227405312
  %435 = icmp eq i64 %433, 0
  %436 = icmp ne i64 %434, 0
  %437 = icmp ne i64 %434, 9218868437227405312
  %438 = and i1 %436, %437
  %439 = or i1 %435, %438
  br i1 %439, label %after_if12.3, label %true_block10.3

true_block10.3:                                   ; preds = %true_block7.3
  %440 = load ptr, ptr %8, align 8
  %441 = getelementptr i64, ptr %440, i64 5
  %442 = load i64, ptr %441, align 8
  %443 = or i64 %442, 1
  store i64 %443, ptr %441, align 8
  %.pre.3 = load ptr, ptr %405, align 8
  br label %after_if12.3

after_if12.3:                                     ; preds = %true_block10.3, %true_block7.3
  %444 = phi ptr [ %429, %true_block7.3 ], [ %.pre.3, %true_block10.3 ]
  %445 = load ptr, ptr %context, align 8
  %446 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %445, i64 0, i32 6, i32 1
  %447 = load ptr, ptr %446, align 8
  %448 = load double, ptr %447, align 8
  %449 = fsub double %431, %448
  %450 = fmul double %414, %449
  %451 = fadd double %.116.2, %450
  %452 = load i32, ptr %407, align 4
  %453 = sext i32 %452 to i64
  %454 = add nsw i64 %453, %411
  %455 = getelementptr double, ptr %444, i64 %454
  %456 = load double, ptr %455, align 8
  %457 = bitcast double %456 to i64
  %458 = and i64 %457, 9223372036854775807
  %459 = and i64 %457, 9218868437227405312
  %460 = icmp eq i64 %458, 0
  %461 = icmp ne i64 %459, 0
  %462 = icmp ne i64 %459, 9218868437227405312
  %463 = and i1 %461, %462
  %464 = or i1 %460, %463
  br i1 %464, label %after_if15.3, label %true_block13.3

true_block13.3:                                   ; preds = %after_if12.3
  %465 = load ptr, ptr %8, align 8
  %466 = getelementptr i64, ptr %465, i64 5
  %467 = load i64, ptr %466, align 8
  %468 = or i64 %467, 1
  store i64 %468, ptr %466, align 8
  %.pre28.3 = load ptr, ptr %446, align 8
  %.pre29.3 = load ptr, ptr %405, align 8
  %.pre30.3 = load i32, ptr %407, align 4
  %.pre32.3 = sext i32 %.pre30.3 to i64
  br label %after_if15.3

after_if15.3:                                     ; preds = %true_block13.3, %after_if12.3
  %.pre-phi.3 = phi i64 [ %453, %after_if12.3 ], [ %.pre32.3, %true_block13.3 ]
  %469 = phi ptr [ %444, %after_if12.3 ], [ %.pre29.3, %true_block13.3 ]
  %470 = phi ptr [ %447, %after_if12.3 ], [ %.pre28.3, %true_block13.3 ]
  %471 = getelementptr double, ptr %470, i64 1
  %472 = load double, ptr %471, align 8
  %473 = fsub double %456, %472
  %474 = fmul double %414, %473
  %475 = fadd double %.114.2, %474
  %476 = shl nsw i64 %.pre-phi.3, 1
  %477 = add nsw i64 %476, %411
  %478 = getelementptr double, ptr %469, i64 %477
  %479 = load double, ptr %478, align 8
  %480 = bitcast double %479 to i64
  %481 = and i64 %480, 9223372036854775807
  %482 = and i64 %480, 9218868437227405312
  %483 = icmp eq i64 %481, 0
  %484 = icmp ne i64 %482, 0
  %485 = icmp ne i64 %482, 9218868437227405312
  %486 = and i1 %484, %485
  %487 = or i1 %483, %486
  br i1 %487, label %after_if18.3, label %true_block16.3

true_block16.3:                                   ; preds = %after_if15.3
  %488 = load ptr, ptr %8, align 8
  %489 = getelementptr i64, ptr %488, i64 5
  %490 = load i64, ptr %489, align 8
  %491 = or i64 %490, 1
  store i64 %491, ptr %489, align 8
  %.pre31.3 = load ptr, ptr %446, align 8
  br label %after_if18.3

after_if18.3:                                     ; preds = %true_block16.3, %after_if15.3
  %492 = phi ptr [ %470, %after_if15.3 ], [ %.pre31.3, %true_block16.3 ]
  %493 = getelementptr double, ptr %492, i64 2
  %494 = load double, ptr %493, align 8
  %495 = fsub double %479, %494
  %496 = fmul double %414, %495
  %497 = fadd double %.112.2, %496
  br label %after_if.3

false_block2.3:                                   ; preds = %true_block.3
  store i64 3, ptr %14, align 8
  br label %after_if.3

after_if.3:                                       ; preds = %false_block2.3, %after_if18.3, %false_block8.3, %false_block.3
  %.116.3 = phi double [ %451, %after_if18.3 ], [ %.116.2, %false_block8.3 ], [ %.116.2, %false_block2.3 ], [ %.116.2, %false_block.3 ]
  %.114.3 = phi double [ %475, %after_if18.3 ], [ %.114.2, %false_block8.3 ], [ %.114.2, %false_block2.3 ], [ %.114.2, %false_block.3 ]
  %.112.3 = phi double [ %497, %after_if18.3 ], [ %.112.2, %false_block8.3 ], [ %.112.2, %false_block2.3 ], [ %.112.2, %false_block.3 ]
  %.1.3 = phi double [ %428, %after_if18.3 ], [ %.1.2, %false_block8.3 ], [ %.1.2, %false_block2.3 ], [ %.1.2, %false_block.3 ]
  %indvars.iv.next.3 = add nuw i64 %indvars.iv, 4
  %niter.ncmp.3 = icmp eq i64 %unroll_iter, %indvars.iv.next.3
  br i1 %niter.ncmp.3, label %after_for.loopexit.unr-lcssa.loopexit, label %for_loop_body

true_block1:                                      ; preds = %true_block
  %498 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %17, i64 0, i32 1, i32 1
  %499 = load ptr, ptr %498, align 8
  %500 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %17, i64 0, i32 1, i32 0, i32 1
  %501 = load i32, ptr %500, align 4
  %502 = sext i32 %501 to i64
  %503 = mul nsw i64 %502, 3
  %504 = zext i32 %21 to i64
  %505 = add nsw i64 %503, %504
  %506 = getelementptr double, ptr %499, i64 %505
  %507 = load double, ptr %506, align 8
  %508 = bitcast double %507 to i64
  %509 = and i64 %508, 9223372036854775807
  %510 = and i64 %508, 9218868437227405312
  %511 = icmp eq i64 %509, 0
  %512 = icmp ne i64 %510, 0
  %513 = icmp ne i64 %510, 9218868437227405312
  %514 = and i1 %512, %513
  %515 = or i1 %511, %514
  br i1 %515, label %after_if6, label %true_block4

false_block2:                                     ; preds = %true_block
  store i64 3, ptr %14, align 8
  br label %after_if

true_block4:                                      ; preds = %true_block1
  %516 = load ptr, ptr %8, align 8
  %517 = getelementptr i64, ptr %516, i64 5
  %518 = load i64, ptr %517, align 8
  %519 = or i64 %518, 1
  store i64 %519, ptr %517, align 8
  br label %after_if6

after_if6:                                        ; preds = %true_block4, %true_block1
  %520 = fcmp ogt double %507, 0.000000e+00
  br i1 %520, label %true_block7, label %false_block8

true_block7:                                      ; preds = %after_if6
  %521 = fadd double %.01022, %507
  %522 = load ptr, ptr %498, align 8
  %523 = getelementptr double, ptr %522, i64 %504
  %524 = load double, ptr %523, align 8
  %525 = bitcast double %524 to i64
  %526 = and i64 %525, 9223372036854775807
  %527 = and i64 %525, 9218868437227405312
  %528 = icmp eq i64 %526, 0
  %529 = icmp ne i64 %527, 0
  %530 = icmp ne i64 %527, 9218868437227405312
  %531 = and i1 %529, %530
  %532 = or i1 %528, %531
  br i1 %532, label %after_if12, label %true_block10

false_block8:                                     ; preds = %after_if6
  store i64 3, ptr %14, align 8
  br label %after_if

true_block10:                                     ; preds = %true_block7
  %533 = load ptr, ptr %8, align 8
  %534 = getelementptr i64, ptr %533, i64 5
  %535 = load i64, ptr %534, align 8
  %536 = or i64 %535, 1
  store i64 %536, ptr %534, align 8
  %.pre = load ptr, ptr %498, align 8
  br label %after_if12

after_if12:                                       ; preds = %true_block10, %true_block7
  %537 = phi ptr [ %522, %true_block7 ], [ %.pre, %true_block10 ]
  %538 = load ptr, ptr %context, align 8
  %539 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %538, i64 0, i32 6, i32 1
  %540 = load ptr, ptr %539, align 8
  %541 = load double, ptr %540, align 8
  %542 = fsub double %524, %541
  %543 = fmul double %507, %542
  %544 = fadd double %.01519, %543
  %545 = load i32, ptr %500, align 4
  %546 = sext i32 %545 to i64
  %547 = add nsw i64 %546, %504
  %548 = getelementptr double, ptr %537, i64 %547
  %549 = load double, ptr %548, align 8
  %550 = bitcast double %549 to i64
  %551 = and i64 %550, 9223372036854775807
  %552 = and i64 %550, 9218868437227405312
  %553 = icmp eq i64 %551, 0
  %554 = icmp ne i64 %552, 0
  %555 = icmp ne i64 %552, 9218868437227405312
  %556 = and i1 %554, %555
  %557 = or i1 %553, %556
  br i1 %557, label %after_if15, label %true_block13

true_block13:                                     ; preds = %after_if12
  %558 = load ptr, ptr %8, align 8
  %559 = getelementptr i64, ptr %558, i64 5
  %560 = load i64, ptr %559, align 8
  %561 = or i64 %560, 1
  store i64 %561, ptr %559, align 8
  %.pre28 = load ptr, ptr %539, align 8
  %.pre29 = load ptr, ptr %498, align 8
  %.pre30 = load i32, ptr %500, align 4
  %.pre32 = sext i32 %.pre30 to i64
  br label %after_if15

after_if15:                                       ; preds = %true_block13, %after_if12
  %.pre-phi = phi i64 [ %546, %after_if12 ], [ %.pre32, %true_block13 ]
  %562 = phi ptr [ %537, %after_if12 ], [ %.pre29, %true_block13 ]
  %563 = phi ptr [ %540, %after_if12 ], [ %.pre28, %true_block13 ]
  %564 = getelementptr double, ptr %563, i64 1
  %565 = load double, ptr %564, align 8
  %566 = fsub double %549, %565
  %567 = fmul double %507, %566
  %568 = fadd double %.01320, %567
  %569 = shl nsw i64 %.pre-phi, 1
  %570 = add nsw i64 %569, %504
  %571 = getelementptr double, ptr %562, i64 %570
  %572 = load double, ptr %571, align 8
  %573 = bitcast double %572 to i64
  %574 = and i64 %573, 9223372036854775807
  %575 = and i64 %573, 9218868437227405312
  %576 = icmp eq i64 %574, 0
  %577 = icmp ne i64 %575, 0
  %578 = icmp ne i64 %575, 9218868437227405312
  %579 = and i1 %577, %578
  %580 = or i1 %576, %579
  br i1 %580, label %after_if18, label %true_block16

true_block16:                                     ; preds = %after_if15
  %581 = load ptr, ptr %8, align 8
  %582 = getelementptr i64, ptr %581, i64 5
  %583 = load i64, ptr %582, align 8
  %584 = or i64 %583, 1
  store i64 %584, ptr %582, align 8
  %.pre31 = load ptr, ptr %539, align 8
  br label %after_if18

after_if18:                                       ; preds = %true_block16, %after_if15
  %585 = phi ptr [ %563, %after_if15 ], [ %.pre31, %true_block16 ]
  %586 = getelementptr double, ptr %585, i64 2
  %587 = load double, ptr %586, align 8
  %588 = fsub double %572, %587
  %589 = fmul double %507, %588
  %590 = fadd double %.01121, %589
  br label %after_if

true_block19:                                     ; preds = %after_for
  %591 = load ptr, ptr %8, align 8
  %592 = getelementptr i64, ptr %591, i64 5
  %593 = load i64, ptr %592, align 8
  %594 = or i64 %593, 1
  store i64 %594, ptr %592, align 8
  br label %after_if21

after_if21:                                       ; preds = %true_block19, %after_for
  %595 = load ptr, ptr %context, align 8
  %596 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %595, i64 0, i32 5, i32 1
  %597 = load ptr, ptr %596, align 8
  %598 = getelementptr double, ptr %597, i64 3
  store double %.010.lcssa, ptr %598, align 8
  %599 = load ptr, ptr %context, align 8
  %600 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32, i32 }, ptr %599, i64 0, i32 6, i32 1
  %601 = load ptr, ptr %600, align 8
  %602 = load double, ptr %601, align 8
  %603 = fdiv double %.015.lcssa, %139
  %604 = fadd double %603, %602
  %605 = select i1 %136, double %604, double 0.000000e+00
  %606 = bitcast double %605 to i64
  %607 = and i64 %606, 9223372036854775807
  %608 = and i64 %606, 9218868437227405312
  %609 = icmp eq i64 %607, 0
  %610 = icmp ne i64 %608, 0
  %611 = icmp ne i64 %608, 9218868437227405312
  %612 = and i1 %610, %611
  %613 = or i1 %609, %612
  br i1 %613, label %after_if24, label %true_block22

true_block22:                                     ; preds = %after_if21
  %614 = load ptr, ptr %8, align 8
  %615 = getelementptr i64, ptr %614, i64 5
  %616 = load i64, ptr %615, align 8
  %617 = or i64 %616, 1
  store i64 %617, ptr %615, align 8
  br label %after_if24

after_if24:                                       ; preds = %true_block22, %after_if21
  %618 = load ptr, ptr %596, align 8
  store double %605, ptr %618, align 8
  %619 = load ptr, ptr %600, align 8
  %620 = getelementptr double, ptr %619, i64 1
  %621 = load double, ptr %620, align 8
  %622 = fdiv double %.013.lcssa, %139
  %623 = fadd double %622, %621
  %624 = select i1 %136, double %623, double 0.000000e+00
  %625 = bitcast double %624 to i64
  %626 = and i64 %625, 9223372036854775807
  %627 = and i64 %625, 9218868437227405312
  %628 = icmp eq i64 %626, 0
  %629 = icmp ne i64 %627, 0
  %630 = icmp ne i64 %627, 9218868437227405312
  %631 = and i1 %629, %630
  %632 = or i1 %628, %631
  br i1 %632, label %after_if27, label %true_block25

true_block25:                                     ; preds = %after_if24
  %633 = load ptr, ptr %8, align 8
  %634 = getelementptr i64, ptr %633, i64 5
  %635 = load i64, ptr %634, align 8
  %636 = or i64 %635, 1
  store i64 %636, ptr %634, align 8
  br label %after_if27

after_if27:                                       ; preds = %true_block25, %after_if24
  %637 = load ptr, ptr %596, align 8
  %638 = getelementptr double, ptr %637, i64 1
  store double %624, ptr %638, align 8
  %639 = load ptr, ptr %600, align 8
  %640 = getelementptr double, ptr %639, i64 2
  %641 = load double, ptr %640, align 8
  %642 = fdiv double %.011.lcssa, %139
  %643 = fadd double %642, %641
  %644 = select i1 %136, double %643, double 0.000000e+00
  %645 = bitcast double %644 to i64
  %646 = and i64 %645, 9223372036854775807
  %647 = and i64 %645, 9218868437227405312
  %648 = icmp eq i64 %646, 0
  %649 = icmp ne i64 %647, 0
  %650 = icmp ne i64 %647, 9218868437227405312
  %651 = and i1 %649, %650
  %652 = or i1 %648, %651
  br i1 %652, label %after_if30, label %true_block28

true_block28:                                     ; preds = %after_if27
  %653 = load ptr, ptr %8, align 8
  %654 = getelementptr i64, ptr %653, i64 5
  %655 = load i64, ptr %654, align 8
  %656 = or i64 %655, 1
  store i64 %656, ptr %654, align 8
  br label %after_if30

after_if30:                                       ; preds = %true_block28, %after_if27
  %657 = load ptr, ptr %596, align 8
  %658 = getelementptr double, ptr %657, i64 2
  store double %644, ptr %658, align 8
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #6

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn writeonly
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #7

; Function Attrs: noinline nounwind optnone uwtable
define internal fastcc void @taichi_assert_format(ptr noundef %0, i1 noundef zeroext %1, ptr noundef %2) unnamed_addr #8 {
  %4 = alloca ptr, align 8
  %5 = alloca i8, align 1
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca ptr, align 8
  %9 = alloca %class.anon, align 8
  store ptr %0, ptr %4, align 8
  %10 = zext i1 %1 to i8
  store i8 %10, ptr %5, align 1
  store ptr %2, ptr %6, align 8
  store i32 0, ptr %7, align 4
  store ptr null, ptr %8, align 8
  %11 = load i8, ptr %5, align 1
  %12 = trunc i8 %11 to i1
  %13 = zext i1 %12 to i32
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %15, label %16

15:                                               ; preds = %3
  br label %69

16:                                               ; preds = %3
  %17 = load ptr, ptr %4, align 8
  %18 = getelementptr inbounds %struct.LLVMRuntime, ptr %17, i32 0, i32 24
  %19 = load i64, ptr %18, align 8
  %20 = icmp ne i64 %19, 0
  br i1 %20, label %69, label %21

21:                                               ; preds = %16
  %22 = load ptr, ptr %4, align 8
  %23 = getelementptr inbounds %struct.LLVMRuntime, ptr %22, i32 0, i32 23
  %24 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 0
  store ptr %4, ptr %24, align 8
  %25 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 1
  store ptr %6, ptr %25, align 8
  %26 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 2
  store ptr %7, ptr %26, align 8
  %27 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 3
  store ptr %8, ptr %27, align 8
  br label %28

28:                                               ; preds = %28, %21
  %29 = atomicrmw volatile xchg ptr %23, i32 1 seq_cst, align 4
  %30 = icmp eq i32 %29, 1
  br i1 %30, label %28, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !8

mutex_lock_i32.exit.i.i.i:                        ; preds = %28
  %31 = load ptr, ptr %9, align 8
  %32 = load ptr, ptr %31, align 8
  %33 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 24
  %34 = load i64, ptr %33, align 8
  %.not.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i, label %35, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

35:                                               ; preds = %mutex_lock_i32.exit.i.i.i
  store i64 1, ptr %33, align 8
  %36 = load ptr, ptr %9, align 8
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr inbounds %struct.LLVMRuntime, ptr %37, i64 0, i32 21
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %38, i8 0, i64 2048, i1 false)
  %39 = load ptr, ptr %9, align 8
  %40 = load ptr, ptr %39, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 21
  %42 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 1
  %43 = load ptr, ptr %42, align 8
  %44 = load ptr, ptr %43, align 8
  %45 = load i8, ptr %44, align 1
  %.not5.i.i.i.i.i = icmp eq i8 %45, 0
  br i1 %.not5.i.i.i.i.i, label %taichi_strlen.exit.thread.i.i.i.i, label %.lr.ph.i.i.i.i.i.preheader

.lr.ph.i.i.i.i.i.preheader:                       ; preds = %35
  br label %.lr.ph.i.i.i.i.i

.lr.ph.i.i.i.i.i:                                 ; preds = %.lr.ph.i.i.i.i.i, %.lr.ph.i.i.i.i.i.preheader
  %.07.i.i.i.i.i = phi ptr [ %47, %.lr.ph.i.i.i.i.i ], [ %44, %.lr.ph.i.i.i.i.i.preheader ]
  %.046.i.i.i.i.i = phi i64 [ %46, %.lr.ph.i.i.i.i.i ], [ 0, %.lr.ph.i.i.i.i.i.preheader ]
  %46 = add i64 %.046.i.i.i.i.i, 1
  %47 = getelementptr inbounds i8, ptr %.07.i.i.i.i.i, i64 1
  %48 = load i8, ptr %47, align 1
  %.not.i.i.i.i.i = icmp eq i8 %48, 0
  br i1 %.not.i.i.i.i.i, label %taichi_strlen.exit.i.i.i.i, label %.lr.ph.i.i.i.i.i, !llvm.loop !13

taichi_strlen.exit.i.i.i.i:                       ; preds = %.lr.ph.i.i.i.i.i
  %.lcssa = phi i64 [ %46, %.lr.ph.i.i.i.i.i ]
  %49 = call i64 @llvm.umin.i64(i64 %.lcssa, i64 2047)
  br label %taichi_strlen.exit.thread.i.i.i.i

taichi_strlen.exit.thread.i.i.i.i:                ; preds = %taichi_strlen.exit.i.i.i.i, %35
  %50 = phi i64 [ 0, %35 ], [ %49, %taichi_strlen.exit.i.i.i.i ]
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %41, ptr nonnull align 1 %44, i64 %50, i1 false)
  %51 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 2
  %52 = load ptr, ptr %51, align 8
  %53 = load i32, ptr %52, align 4
  %54 = icmp sgt i32 %53, 0
  br i1 %54, label %.lr.ph.i.i.i.i, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

.lr.ph.i.i.i.i:                                   ; preds = %taichi_strlen.exit.thread.i.i.i.i
  %55 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 3
  br label %56

56:                                               ; preds = %56, %.lr.ph.i.i.i.i
  %indvars.iv.i.i.i.i = phi i64 [ 0, %.lr.ph.i.i.i.i ], [ %indvars.iv.next.i.i.i.i, %56 ]
  %57 = load ptr, ptr %55, align 8
  %58 = load ptr, ptr %57, align 8
  %59 = getelementptr inbounds i64, ptr %58, i64 %indvars.iv.i.i.i.i
  %60 = load i64, ptr %59, align 8
  %61 = load ptr, ptr %9, align 8
  %62 = load ptr, ptr %61, align 8
  %63 = getelementptr inbounds %struct.LLVMRuntime, ptr %62, i64 0, i32 22, i64 %indvars.iv.i.i.i.i
  store i64 %60, ptr %63, align 8
  %indvars.iv.next.i.i.i.i = add nuw nsw i64 %indvars.iv.i.i.i.i, 1
  %64 = load ptr, ptr %51, align 8
  %65 = load i32, ptr %64, align 4
  %66 = sext i32 %65 to i64
  %67 = icmp slt i64 %indvars.iv.next.i.i.i.i, %66
  br i1 %67, label %56, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", !llvm.loop !14

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit": ; preds = %56
  br label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit": ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", %taichi_strlen.exit.thread.i.i.i.i, %mutex_lock_i32.exit.i.i.i
  %68 = atomicrmw volatile xchg ptr %23, i32 0 seq_cst, align 4
  br label %69

69:                                               ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit", %16, %15
  ret void
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_struct_for_block_helper(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #9 {
_ZN11ListManager3getI7ElementEERT_i.exit:
  %3 = alloca %struct.RuntimeContext.970, align 8
  %4 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 4
  %5 = load i32, ptr %4, align 4
  %6 = sdiv i32 %2, %5
  %7 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  %8 = load i32, ptr %7, align 8
  %9 = sdiv i32 %8, %5
  %10 = srem i32 %2, %5
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  %12 = load ptr, ptr %11, align 8
  %13 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %14 = load i32, ptr %13, align 8
  %15 = ashr i32 %6, %14
  %16 = sext i32 %15 to i64
  %17 = lshr i64 %16, 9
  %18 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %17
  %19 = load atomic i64, ptr %18 acquire, align 8
  %.not.i.i.i = icmp ne i64 %19, 0
  tail call void @llvm.assume(i1 %.not.i.i.i)
  %20 = inttoptr i64 %19 to ptr
  %21 = and i64 %16, 511
  %22 = getelementptr inbounds ptr, ptr %20, i64 %21
  %23 = load atomic i64, ptr %22 acquire, align 8
  %24 = inttoptr i64 %23 to ptr
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %26 = load i64, ptr %25, align 8
  %27 = load i32, ptr %13, align 8
  %notmask.i.i = shl nsw i32 -1, %27
  %28 = xor i32 %notmask.i.i, -1
  %29 = and i32 %6, %28
  %30 = sext i32 %29 to i64
  %31 = mul i64 %26, %30
  %32 = getelementptr inbounds i8, ptr %24, i64 %31
  %33 = getelementptr inbounds %0, ptr %32, i64 0, i32 1
  %34 = load i32, ptr %33, align 8
  %35 = mul nsw i32 %10, %9
  %36 = add nsw i32 %34, %35
  %37 = add nsw i32 %10, 1
  %38 = mul nsw i32 %37, %9
  %39 = add nsw i32 %34, %38
  %40 = getelementptr inbounds %0, ptr %32, i64 0, i32 1, i64 1
  %41 = load i32, ptr %40, align 4
  %42 = tail call i32 @llvm.smin.i32(i32 %41, i32 %39)
  %43 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  %44 = load i64, ptr %43, align 8
  %45 = alloca i8, i64 %44, align 8
  %46 = load ptr, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %3, ptr noundef nonnull align 8 dereferenceable(32) %46, i64 32, i1 false)
  %47 = getelementptr inbounds %struct.RuntimeContext.970, ptr %3, i64 0, i32 2
  store i32 %1, ptr %47, align 8
  %48 = icmp slt i32 %36, %42
  br i1 %48, label %49, label %75

49:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit
  %50 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = load ptr, ptr %11, align 8
  %53 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 3
  %54 = load i32, ptr %53, align 8
  %55 = ashr i32 %6, %54
  %56 = sext i32 %55 to i64
  %57 = lshr i64 %56, 9
  %58 = getelementptr inbounds [256 x ptr], ptr %52, i64 0, i64 %57
  %59 = load atomic i64, ptr %58 acquire, align 8
  %.not.i.i.i24 = icmp eq i64 %59, 0
  br i1 %.not.i.i.i24, label %_ZN11ListManager3getI7ElementEERT_i.exit26, label %60

60:                                               ; preds = %49
  %61 = inttoptr i64 %59 to ptr
  %62 = and i64 %56, 511
  %63 = getelementptr inbounds ptr, ptr %61, i64 %62
  %64 = load atomic i64, ptr %63 acquire, align 8
  %65 = inttoptr i64 %64 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit26

_ZN11ListManager3getI7ElementEERT_i.exit26:       ; preds = %60, %49
  %66 = phi ptr [ %65, %60 ], [ null, %49 ]
  %67 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 1
  %68 = load i64, ptr %67, align 8
  %69 = load i32, ptr %53, align 8
  %notmask.i.i25 = shl nsw i32 -1, %69
  %70 = xor i32 %notmask.i.i25, -1
  %71 = and i32 %6, %70
  %72 = sext i32 %71 to i64
  %73 = mul i64 %68, %72
  %74 = getelementptr inbounds i8, ptr %66, i64 %73
  call void %51(ptr noundef nonnull %3, ptr noundef nonnull %45, ptr noundef nonnull %74, i32 noundef %36, i32 noundef %42) #1
  br label %75

75:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit26, %_ZN11ListManager3getI7ElementEERT_i.exit
  ret void
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_parallel_range_for_task(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #9 {
  %4 = alloca %struct.RuntimeContext.970, align 8
  %.sroa.0.0.copyload = load ptr, ptr %0, align 8
  %.sroa.4.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 8
  %.sroa.4.0.copyload = load ptr, ptr %.sroa.4.0..sroa_idx, align 8
  %.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 16
  %.sroa.5.0.copyload = load ptr, ptr %.sroa.5.0..sroa_idx, align 8
  %.sroa.7.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 24
  %.sroa.7.0.copyload = load ptr, ptr %.sroa.7.0..sroa_idx, align 8
  %.sroa.8.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 32
  %.sroa.8.0.copyload = load i64, ptr %.sroa.8.0..sroa_idx, align 8
  %.sroa.9.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 40
  %.sroa.9.0.copyload = load i32, ptr %.sroa.9.0..sroa_idx, align 8
  %.sroa.12.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 44
  %.sroa.12.0.copyload = load i32, ptr %.sroa.12.0..sroa_idx, align 4
  %.sroa.15.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 48
  %.sroa.15.0.copyload = load i32, ptr %.sroa.15.0..sroa_idx, align 8
  %.sroa.17.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 52
  %.sroa.17.0.copyload = load i32, ptr %.sroa.17.0..sroa_idx, align 4
  %5 = alloca i8, i64 %.sroa.8.0.copyload, align 8
  %.not = icmp eq ptr %.sroa.4.0.copyload, null
  br i1 %.not, label %7, label %6

6:                                                ; preds = %3
  call void %.sroa.4.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %7

7:                                                ; preds = %6, %3
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %4, ptr noundef nonnull align 8 dereferenceable(32) %.sroa.0.0.copyload, i64 32, i1 false)
  %8 = getelementptr inbounds %struct.RuntimeContext.970, ptr %4, i64 0, i32 2
  store i32 %1, ptr %8, align 8
  switch i32 %.sroa.17.0.copyload, label %.loopexit [
    i32 1, label %9
    i32 -1, label %17
  ]

9:                                                ; preds = %7
  %10 = mul nsw i32 %.sroa.15.0.copyload, %2
  %11 = add nsw i32 %10, %.sroa.9.0.copyload
  %12 = add nsw i32 %11, %.sroa.15.0.copyload
  %13 = call i32 @llvm.smin.i32(i32 %.sroa.12.0.copyload, i32 %12)
  %14 = icmp slt i32 %11, %13
  br i1 %14, label %.lr.ph.preheader, label %.loopexit

.lr.ph.preheader:                                 ; preds = %9
  br label %.lr.ph

.lr.ph:                                           ; preds = %.lr.ph, %.lr.ph.preheader
  %.02039 = phi i32 [ %15, %.lr.ph ], [ %11, %.lr.ph.preheader ]
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.02039) #1
  %15 = add nsw i32 %.02039, 1
  %16 = icmp slt i32 %15, %13
  br i1 %16, label %.lr.ph, label %.loopexit.loopexit, !llvm.loop !15

17:                                               ; preds = %7
  %18 = mul nsw i32 %.sroa.15.0.copyload, %2
  %19 = sub nsw i32 %.sroa.12.0.copyload, %18
  %20 = mul nsw i32 %19, %.sroa.15.0.copyload
  %21 = call i32 @llvm.smax.i32(i32 %.sroa.9.0.copyload, i32 %20)
  %.not25.not40 = icmp sgt i32 %19, %21
  br i1 %.not25.not40, label %.lr.ph42.preheader, label %.loopexit

.lr.ph42.preheader:                               ; preds = %17
  br label %.lr.ph42

.lr.ph42:                                         ; preds = %.lr.ph42, %.lr.ph42.preheader
  %.0.in41 = phi i32 [ %.0, %.lr.ph42 ], [ %19, %.lr.ph42.preheader ]
  %.0 = add nsw i32 %.0.in41, -1
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.0) #1
  %.not25.not = icmp sgt i32 %.0, %21
  br i1 %.not25.not, label %.lr.ph42, label %.loopexit.loopexit47, !llvm.loop !16

.loopexit.loopexit:                               ; preds = %.lr.ph
  br label %.loopexit

.loopexit.loopexit47:                             ; preds = %.lr.ph42
  br label %.loopexit

.loopexit:                                        ; preds = %.loopexit.loopexit47, %.loopexit.loopexit, %17, %9, %7
  %.not24 = icmp eq ptr %.sroa.7.0.copyload, null
  br i1 %.not24, label %23, label %22

22:                                               ; preds = %.loopexit
  call void %.sroa.7.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %23

23:                                               ; preds = %22, %.loopexit
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #10

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smax.i32(i32, i32) #10

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #11

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #11

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i64 @llvm.umin.i64(i64, i64) #12

; Function Attrs: inaccessiblememonly nocallback nofree nosync nounwind willreturn
declare void @llvm.assume(i1 noundef) #13

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { nofree nosync nounwind }
attributes #3 = { nofree norecurse nounwind }
attributes #4 = { nofree norecurse nosync nounwind }
attributes #5 = { nofree nounwind }
attributes #6 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #7 = { argmemonly mustprogress nocallback nofree nounwind willreturn writeonly }
attributes #8 = { noinline nounwind optnone uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #11 = { argmemonly nocallback nofree nosync nounwind willreturn }
attributes #12 = { nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #13 = { inaccessiblememonly nocallback nofree nosync nounwind willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.unroll.disable"}
!8 = distinct !{!8, !9}
!9 = !{!"llvm.loop.mustprogress"}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
!13 = distinct !{!13, !9}
!14 = distinct !{!14, !9}
!15 = distinct !{!15, !9}
!16 = distinct !{!16, !9}
