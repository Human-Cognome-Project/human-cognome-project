; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct.range_task_helper_context = type { ptr, ptr, ptr, ptr, i64, i32, i32, i32, i32 }
%struct.RuntimeContext.1162 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }

; Function Attrs: nounwind
define void @tick_contact_csr_25_kernel_0_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1162, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 1
  %9 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 0, i32 1
  %10 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 2, i32 1
  %11 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 2, i32 0, i32 1
  %12 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %13 = xor i64 %12, -1
  %14 = add nsw i64 %13, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv37 = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next38, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %12, %for_loop_body.prol.preheader ]
  %15 = load ptr, ptr %8, align 8
  %16 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep36 = getelementptr i8, ptr %15, i64 %16
  %17 = load i32, ptr %uglygep36, align 4
  %18 = load ptr, ptr %10, align 8
  %uglygep35 = getelementptr i8, ptr %18, i64 %16
  store i32 %17, ptr %uglygep35, align 4
  %19 = load ptr, ptr %8, align 8
  %20 = load i32, ptr %9, align 4
  %21 = sext i32 %20 to i64
  %22 = add nsw i64 %indvars.iv.prol, %21
  %23 = getelementptr i32, ptr %19, i64 %22
  %24 = load i32, ptr %23, align 4
  %25 = load ptr, ptr %10, align 8
  %26 = load i32, ptr %11, align 4
  %27 = sext i32 %26 to i64
  %28 = add nsw i64 %indvars.iv.prol, %27
  %29 = getelementptr i32, ptr %25, i64 %28
  store i32 %24, ptr %29, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next38 = add nsw i64 %lsr.iv37, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next38, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !6

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %12, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %30 = icmp ult i64 %14, 7
  br i1 %30, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  %31 = sub i64 0, %wide.trip.count
  %32 = add nsw i64 %indvars.iv.unr, 7
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %lsr.iv = phi i64 [ %32, %for_loop_body.preheader ], [ %lsr.iv.next, %for_loop_body ]
  %33 = load ptr, ptr %8, align 8
  %34 = shl i64 %lsr.iv, 2
  %uglygep27 = getelementptr i8, ptr %33, i64 %34
  %uglygep28 = getelementptr i8, ptr %uglygep27, i64 -28
  %35 = load i32, ptr %uglygep28, align 4
  %36 = load ptr, ptr %10, align 8
  %uglygep29 = getelementptr i8, ptr %36, i64 %34
  %uglygep30 = getelementptr i8, ptr %uglygep29, i64 -28
  store i32 %35, ptr %uglygep30, align 4
  %37 = load ptr, ptr %8, align 8
  %38 = load i32, ptr %9, align 4
  %39 = sext i32 %38 to i64
  %40 = add i64 %lsr.iv, %39
  %41 = getelementptr i32, ptr %37, i64 %40
  %42 = getelementptr i32, ptr %41, i64 -7
  %43 = load i32, ptr %42, align 4
  %44 = load ptr, ptr %10, align 8
  %45 = load i32, ptr %11, align 4
  %46 = sext i32 %45 to i64
  %47 = add i64 %lsr.iv, %46
  %48 = getelementptr i32, ptr %44, i64 %47
  %49 = getelementptr i32, ptr %48, i64 -7
  store i32 %43, ptr %49, align 4
  %50 = load ptr, ptr %8, align 8
  %uglygep33 = getelementptr i8, ptr %50, i64 %34
  %uglygep34 = getelementptr i8, ptr %uglygep33, i64 -24
  %51 = load i32, ptr %uglygep34, align 4
  %52 = load ptr, ptr %10, align 8
  %uglygep31 = getelementptr i8, ptr %52, i64 %34
  %uglygep32 = getelementptr i8, ptr %uglygep31, i64 -24
  store i32 %51, ptr %uglygep32, align 4
  %53 = load ptr, ptr %8, align 8
  %54 = load i32, ptr %9, align 4
  %55 = sext i32 %54 to i64
  %56 = add i64 %lsr.iv, %55
  %57 = getelementptr i32, ptr %53, i64 %56
  %58 = getelementptr i32, ptr %57, i64 -6
  %59 = load i32, ptr %58, align 4
  %60 = load ptr, ptr %10, align 8
  %61 = load i32, ptr %11, align 4
  %62 = sext i32 %61 to i64
  %63 = add i64 %lsr.iv, %62
  %64 = getelementptr i32, ptr %60, i64 %63
  %65 = getelementptr i32, ptr %64, i64 -6
  store i32 %59, ptr %65, align 4
  %66 = load ptr, ptr %8, align 8
  %uglygep25 = getelementptr i8, ptr %66, i64 %34
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 -20
  %67 = load i32, ptr %uglygep26, align 4
  %68 = load ptr, ptr %10, align 8
  %uglygep23 = getelementptr i8, ptr %68, i64 %34
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 -20
  store i32 %67, ptr %uglygep24, align 4
  %69 = load ptr, ptr %8, align 8
  %70 = load i32, ptr %9, align 4
  %71 = sext i32 %70 to i64
  %72 = add i64 %lsr.iv, %71
  %73 = getelementptr i32, ptr %69, i64 %72
  %74 = getelementptr i32, ptr %73, i64 -5
  %75 = load i32, ptr %74, align 4
  %76 = load ptr, ptr %10, align 8
  %77 = load i32, ptr %11, align 4
  %78 = sext i32 %77 to i64
  %79 = add i64 %lsr.iv, %78
  %80 = getelementptr i32, ptr %76, i64 %79
  %81 = getelementptr i32, ptr %80, i64 -5
  store i32 %75, ptr %81, align 4
  %82 = load ptr, ptr %8, align 8
  %uglygep21 = getelementptr i8, ptr %82, i64 %34
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 -16
  %83 = load i32, ptr %uglygep22, align 4
  %84 = load ptr, ptr %10, align 8
  %uglygep19 = getelementptr i8, ptr %84, i64 %34
  %uglygep20 = getelementptr i8, ptr %uglygep19, i64 -16
  store i32 %83, ptr %uglygep20, align 4
  %85 = load ptr, ptr %8, align 8
  %86 = load i32, ptr %9, align 4
  %87 = sext i32 %86 to i64
  %88 = add i64 %lsr.iv, %87
  %89 = getelementptr i32, ptr %85, i64 %88
  %90 = getelementptr i32, ptr %89, i64 -4
  %91 = load i32, ptr %90, align 4
  %92 = load ptr, ptr %10, align 8
  %93 = load i32, ptr %11, align 4
  %94 = sext i32 %93 to i64
  %95 = add i64 %lsr.iv, %94
  %96 = getelementptr i32, ptr %92, i64 %95
  %97 = getelementptr i32, ptr %96, i64 -4
  store i32 %91, ptr %97, align 4
  %98 = load ptr, ptr %8, align 8
  %uglygep17 = getelementptr i8, ptr %98, i64 %34
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 -12
  %99 = load i32, ptr %uglygep18, align 4
  %100 = load ptr, ptr %10, align 8
  %uglygep15 = getelementptr i8, ptr %100, i64 %34
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 -12
  store i32 %99, ptr %uglygep16, align 4
  %101 = load ptr, ptr %8, align 8
  %102 = load i32, ptr %9, align 4
  %103 = sext i32 %102 to i64
  %104 = add i64 %lsr.iv, %103
  %105 = getelementptr i32, ptr %101, i64 %104
  %106 = getelementptr i32, ptr %105, i64 -3
  %107 = load i32, ptr %106, align 4
  %108 = load ptr, ptr %10, align 8
  %109 = load i32, ptr %11, align 4
  %110 = sext i32 %109 to i64
  %111 = add i64 %lsr.iv, %110
  %112 = getelementptr i32, ptr %108, i64 %111
  %113 = getelementptr i32, ptr %112, i64 -3
  store i32 %107, ptr %113, align 4
  %114 = load ptr, ptr %8, align 8
  %uglygep13 = getelementptr i8, ptr %114, i64 %34
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 -8
  %115 = load i32, ptr %uglygep14, align 4
  %116 = load ptr, ptr %10, align 8
  %uglygep11 = getelementptr i8, ptr %116, i64 %34
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 -8
  store i32 %115, ptr %uglygep12, align 4
  %117 = load ptr, ptr %8, align 8
  %118 = load i32, ptr %9, align 4
  %119 = sext i32 %118 to i64
  %120 = add i64 %lsr.iv, %119
  %121 = getelementptr i32, ptr %117, i64 %120
  %122 = getelementptr i32, ptr %121, i64 -2
  %123 = load i32, ptr %122, align 4
  %124 = load ptr, ptr %10, align 8
  %125 = load i32, ptr %11, align 4
  %126 = sext i32 %125 to i64
  %127 = add i64 %lsr.iv, %126
  %128 = getelementptr i32, ptr %124, i64 %127
  %129 = getelementptr i32, ptr %128, i64 -2
  store i32 %123, ptr %129, align 4
  %130 = load ptr, ptr %8, align 8
  %uglygep9 = getelementptr i8, ptr %130, i64 %34
  %uglygep10 = getelementptr i8, ptr %uglygep9, i64 -4
  %131 = load i32, ptr %uglygep10, align 4
  %132 = load ptr, ptr %10, align 8
  %uglygep7 = getelementptr i8, ptr %132, i64 %34
  %uglygep8 = getelementptr i8, ptr %uglygep7, i64 -4
  store i32 %131, ptr %uglygep8, align 4
  %133 = load ptr, ptr %8, align 8
  %134 = load i32, ptr %9, align 4
  %135 = sext i32 %134 to i64
  %136 = add i64 %lsr.iv, %135
  %137 = getelementptr i32, ptr %133, i64 %136
  %138 = getelementptr i32, ptr %137, i64 -1
  %139 = load i32, ptr %138, align 4
  %140 = load ptr, ptr %10, align 8
  %141 = load i32, ptr %11, align 4
  %142 = sext i32 %141 to i64
  %143 = add i64 %lsr.iv, %142
  %144 = getelementptr i32, ptr %140, i64 %143
  %145 = getelementptr i32, ptr %144, i64 -1
  store i32 %139, ptr %145, align 4
  %146 = load ptr, ptr %8, align 8
  %uglygep6 = getelementptr i8, ptr %146, i64 %34
  %147 = load i32, ptr %uglygep6, align 4
  %148 = load ptr, ptr %10, align 8
  %uglygep = getelementptr i8, ptr %148, i64 %34
  store i32 %147, ptr %uglygep, align 4
  %149 = load ptr, ptr %8, align 8
  %150 = load i32, ptr %9, align 4
  %151 = sext i32 %150 to i64
  %152 = add nsw i64 %lsr.iv, %151
  %153 = getelementptr i32, ptr %149, i64 %152
  %154 = load i32, ptr %153, align 4
  %155 = load ptr, ptr %10, align 8
  %156 = load i32, ptr %11, align 4
  %157 = sext i32 %156 to i64
  %158 = add nsw i64 %lsr.iv, %157
  %159 = getelementptr i32, ptr %155, i64 %158
  store i32 %154, ptr %159, align 4
  %lsr.iv.next = add i64 %lsr.iv, 8
  %160 = add i64 %31, %lsr.iv.next
  %exitcond.not.7 = icmp eq i64 %160, 7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @tick_contact_csr_25_kernel_1_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.1, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1162, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.1(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 1
  %9 = getelementptr { { i32, i32 }, ptr }, ptr %7, i64 0, i32 0, i32 1
  %10 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 3, i32 1
  %11 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 3, i32 0, i32 1
  %12 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %13 = xor i64 %12, -1
  %14 = add nsw i64 %13, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv71 = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next72, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %12, %for_loop_body.prol.preheader ]
  %15 = load ptr, ptr %8, align 8
  %16 = load i32, ptr %9, align 4
  %17 = sext i32 %16 to i64
  %18 = shl nsw i64 %17, 3
  %uglygep69 = getelementptr i8, ptr %15, i64 %18
  %19 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep70 = getelementptr i8, ptr %uglygep69, i64 %19
  %20 = load i32, ptr %uglygep70, align 4
  %21 = load ptr, ptr %10, align 8
  %uglygep68 = getelementptr i8, ptr %21, i64 %19
  store i32 %20, ptr %uglygep68, align 4
  %22 = load ptr, ptr %8, align 8
  %23 = load i32, ptr %9, align 4
  %24 = sext i32 %23 to i64
  %25 = mul nsw i64 %24, 12
  %uglygep66 = getelementptr i8, ptr %22, i64 %25
  %uglygep67 = getelementptr i8, ptr %uglygep66, i64 %19
  %26 = load i32, ptr %uglygep67, align 4
  %27 = load ptr, ptr %10, align 8
  %28 = load i32, ptr %11, align 4
  %29 = sext i32 %28 to i64
  %30 = add nsw i64 %indvars.iv.prol, %29
  %31 = getelementptr i32, ptr %27, i64 %30
  store i32 %26, ptr %31, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next72 = add nsw i64 %lsr.iv71, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next72, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !8

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %12, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %32 = icmp ult i64 %14, 7
  br i1 %32, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  %33 = sub i64 0, %wide.trip.count
  %34 = add nsw i64 %indvars.iv.unr, 7
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %lsr.iv = phi i64 [ %34, %for_loop_body.preheader ], [ %lsr.iv.next, %for_loop_body ]
  %35 = load ptr, ptr %8, align 8
  %36 = load i32, ptr %9, align 4
  %37 = sext i32 %36 to i64
  %38 = shl nsw i64 %37, 3
  %uglygep50 = getelementptr i8, ptr %35, i64 %38
  %39 = shl i64 %lsr.iv, 2
  %uglygep51 = getelementptr i8, ptr %uglygep50, i64 %39
  %uglygep52 = getelementptr i8, ptr %uglygep51, i64 -28
  %40 = load i32, ptr %uglygep52, align 4
  %41 = load ptr, ptr %10, align 8
  %uglygep53 = getelementptr i8, ptr %41, i64 %39
  %uglygep54 = getelementptr i8, ptr %uglygep53, i64 -28
  store i32 %40, ptr %uglygep54, align 4
  %42 = load ptr, ptr %8, align 8
  %43 = load i32, ptr %9, align 4
  %44 = sext i32 %43 to i64
  %45 = mul nsw i64 %44, 12
  %uglygep55 = getelementptr i8, ptr %42, i64 %45
  %uglygep56 = getelementptr i8, ptr %uglygep55, i64 %39
  %uglygep57 = getelementptr i8, ptr %uglygep56, i64 -28
  %46 = load i32, ptr %uglygep57, align 4
  %47 = load ptr, ptr %10, align 8
  %48 = load i32, ptr %11, align 4
  %49 = sext i32 %48 to i64
  %50 = add i64 %lsr.iv, %49
  %51 = getelementptr i32, ptr %47, i64 %50
  %52 = getelementptr i32, ptr %51, i64 -7
  store i32 %46, ptr %52, align 4
  %53 = load ptr, ptr %8, align 8
  %54 = load i32, ptr %9, align 4
  %55 = sext i32 %54 to i64
  %56 = shl nsw i64 %55, 3
  %uglygep63 = getelementptr i8, ptr %53, i64 %56
  %uglygep64 = getelementptr i8, ptr %uglygep63, i64 %39
  %uglygep65 = getelementptr i8, ptr %uglygep64, i64 -24
  %57 = load i32, ptr %uglygep65, align 4
  %58 = load ptr, ptr %10, align 8
  %uglygep61 = getelementptr i8, ptr %58, i64 %39
  %uglygep62 = getelementptr i8, ptr %uglygep61, i64 -24
  store i32 %57, ptr %uglygep62, align 4
  %59 = load ptr, ptr %8, align 8
  %60 = load i32, ptr %9, align 4
  %61 = sext i32 %60 to i64
  %62 = mul nsw i64 %61, 12
  %uglygep58 = getelementptr i8, ptr %59, i64 %62
  %uglygep59 = getelementptr i8, ptr %uglygep58, i64 %39
  %uglygep60 = getelementptr i8, ptr %uglygep59, i64 -24
  %63 = load i32, ptr %uglygep60, align 4
  %64 = load ptr, ptr %10, align 8
  %65 = load i32, ptr %11, align 4
  %66 = sext i32 %65 to i64
  %67 = add i64 %lsr.iv, %66
  %68 = getelementptr i32, ptr %64, i64 %67
  %69 = getelementptr i32, ptr %68, i64 -6
  store i32 %63, ptr %69, align 4
  %70 = load ptr, ptr %8, align 8
  %71 = load i32, ptr %9, align 4
  %72 = sext i32 %71 to i64
  %73 = shl nsw i64 %72, 3
  %uglygep47 = getelementptr i8, ptr %70, i64 %73
  %uglygep48 = getelementptr i8, ptr %uglygep47, i64 %39
  %uglygep49 = getelementptr i8, ptr %uglygep48, i64 -20
  %74 = load i32, ptr %uglygep49, align 4
  %75 = load ptr, ptr %10, align 8
  %uglygep45 = getelementptr i8, ptr %75, i64 %39
  %uglygep46 = getelementptr i8, ptr %uglygep45, i64 -20
  store i32 %74, ptr %uglygep46, align 4
  %76 = load ptr, ptr %8, align 8
  %77 = load i32, ptr %9, align 4
  %78 = sext i32 %77 to i64
  %79 = mul nsw i64 %78, 12
  %uglygep42 = getelementptr i8, ptr %76, i64 %79
  %uglygep43 = getelementptr i8, ptr %uglygep42, i64 %39
  %uglygep44 = getelementptr i8, ptr %uglygep43, i64 -20
  %80 = load i32, ptr %uglygep44, align 4
  %81 = load ptr, ptr %10, align 8
  %82 = load i32, ptr %11, align 4
  %83 = sext i32 %82 to i64
  %84 = add i64 %lsr.iv, %83
  %85 = getelementptr i32, ptr %81, i64 %84
  %86 = getelementptr i32, ptr %85, i64 -5
  store i32 %80, ptr %86, align 4
  %87 = load ptr, ptr %8, align 8
  %88 = load i32, ptr %9, align 4
  %89 = sext i32 %88 to i64
  %90 = shl nsw i64 %89, 3
  %uglygep39 = getelementptr i8, ptr %87, i64 %90
  %uglygep40 = getelementptr i8, ptr %uglygep39, i64 %39
  %uglygep41 = getelementptr i8, ptr %uglygep40, i64 -16
  %91 = load i32, ptr %uglygep41, align 4
  %92 = load ptr, ptr %10, align 8
  %uglygep37 = getelementptr i8, ptr %92, i64 %39
  %uglygep38 = getelementptr i8, ptr %uglygep37, i64 -16
  store i32 %91, ptr %uglygep38, align 4
  %93 = load ptr, ptr %8, align 8
  %94 = load i32, ptr %9, align 4
  %95 = sext i32 %94 to i64
  %96 = mul nsw i64 %95, 12
  %uglygep34 = getelementptr i8, ptr %93, i64 %96
  %uglygep35 = getelementptr i8, ptr %uglygep34, i64 %39
  %uglygep36 = getelementptr i8, ptr %uglygep35, i64 -16
  %97 = load i32, ptr %uglygep36, align 4
  %98 = load ptr, ptr %10, align 8
  %99 = load i32, ptr %11, align 4
  %100 = sext i32 %99 to i64
  %101 = add i64 %lsr.iv, %100
  %102 = getelementptr i32, ptr %98, i64 %101
  %103 = getelementptr i32, ptr %102, i64 -4
  store i32 %97, ptr %103, align 4
  %104 = load ptr, ptr %8, align 8
  %105 = load i32, ptr %9, align 4
  %106 = sext i32 %105 to i64
  %107 = shl nsw i64 %106, 3
  %uglygep31 = getelementptr i8, ptr %104, i64 %107
  %uglygep32 = getelementptr i8, ptr %uglygep31, i64 %39
  %uglygep33 = getelementptr i8, ptr %uglygep32, i64 -12
  %108 = load i32, ptr %uglygep33, align 4
  %109 = load ptr, ptr %10, align 8
  %uglygep29 = getelementptr i8, ptr %109, i64 %39
  %uglygep30 = getelementptr i8, ptr %uglygep29, i64 -12
  store i32 %108, ptr %uglygep30, align 4
  %110 = load ptr, ptr %8, align 8
  %111 = load i32, ptr %9, align 4
  %112 = sext i32 %111 to i64
  %113 = mul nsw i64 %112, 12
  %uglygep26 = getelementptr i8, ptr %110, i64 %113
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 %39
  %uglygep28 = getelementptr i8, ptr %uglygep27, i64 -12
  %114 = load i32, ptr %uglygep28, align 4
  %115 = load ptr, ptr %10, align 8
  %116 = load i32, ptr %11, align 4
  %117 = sext i32 %116 to i64
  %118 = add i64 %lsr.iv, %117
  %119 = getelementptr i32, ptr %115, i64 %118
  %120 = getelementptr i32, ptr %119, i64 -3
  store i32 %114, ptr %120, align 4
  %121 = load ptr, ptr %8, align 8
  %122 = load i32, ptr %9, align 4
  %123 = sext i32 %122 to i64
  %124 = shl nsw i64 %123, 3
  %uglygep23 = getelementptr i8, ptr %121, i64 %124
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 %39
  %uglygep25 = getelementptr i8, ptr %uglygep24, i64 -8
  %125 = load i32, ptr %uglygep25, align 4
  %126 = load ptr, ptr %10, align 8
  %uglygep21 = getelementptr i8, ptr %126, i64 %39
  %uglygep22 = getelementptr i8, ptr %uglygep21, i64 -8
  store i32 %125, ptr %uglygep22, align 4
  %127 = load ptr, ptr %8, align 8
  %128 = load i32, ptr %9, align 4
  %129 = sext i32 %128 to i64
  %130 = mul nsw i64 %129, 12
  %uglygep18 = getelementptr i8, ptr %127, i64 %130
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 %39
  %uglygep20 = getelementptr i8, ptr %uglygep19, i64 -8
  %131 = load i32, ptr %uglygep20, align 4
  %132 = load ptr, ptr %10, align 8
  %133 = load i32, ptr %11, align 4
  %134 = sext i32 %133 to i64
  %135 = add i64 %lsr.iv, %134
  %136 = getelementptr i32, ptr %132, i64 %135
  %137 = getelementptr i32, ptr %136, i64 -2
  store i32 %131, ptr %137, align 4
  %138 = load ptr, ptr %8, align 8
  %139 = load i32, ptr %9, align 4
  %140 = sext i32 %139 to i64
  %141 = shl nsw i64 %140, 3
  %uglygep15 = getelementptr i8, ptr %138, i64 %141
  %uglygep16 = getelementptr i8, ptr %uglygep15, i64 %39
  %uglygep17 = getelementptr i8, ptr %uglygep16, i64 -4
  %142 = load i32, ptr %uglygep17, align 4
  %143 = load ptr, ptr %10, align 8
  %uglygep13 = getelementptr i8, ptr %143, i64 %39
  %uglygep14 = getelementptr i8, ptr %uglygep13, i64 -4
  store i32 %142, ptr %uglygep14, align 4
  %144 = load ptr, ptr %8, align 8
  %145 = load i32, ptr %9, align 4
  %146 = sext i32 %145 to i64
  %147 = mul nsw i64 %146, 12
  %uglygep10 = getelementptr i8, ptr %144, i64 %147
  %uglygep11 = getelementptr i8, ptr %uglygep10, i64 %39
  %uglygep12 = getelementptr i8, ptr %uglygep11, i64 -4
  %148 = load i32, ptr %uglygep12, align 4
  %149 = load ptr, ptr %10, align 8
  %150 = load i32, ptr %11, align 4
  %151 = sext i32 %150 to i64
  %152 = add i64 %lsr.iv, %151
  %153 = getelementptr i32, ptr %149, i64 %152
  %154 = getelementptr i32, ptr %153, i64 -1
  store i32 %148, ptr %154, align 4
  %155 = load ptr, ptr %8, align 8
  %156 = load i32, ptr %9, align 4
  %157 = sext i32 %156 to i64
  %158 = shl nsw i64 %157, 3
  %uglygep8 = getelementptr i8, ptr %155, i64 %158
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %39
  %159 = load i32, ptr %uglygep9, align 4
  %160 = load ptr, ptr %10, align 8
  %uglygep7 = getelementptr i8, ptr %160, i64 %39
  store i32 %159, ptr %uglygep7, align 4
  %161 = load ptr, ptr %8, align 8
  %162 = load i32, ptr %9, align 4
  %163 = sext i32 %162 to i64
  %164 = mul nsw i64 %163, 12
  %uglygep = getelementptr i8, ptr %161, i64 %164
  %uglygep6 = getelementptr i8, ptr %uglygep, i64 %39
  %165 = load i32, ptr %uglygep6, align 4
  %166 = load ptr, ptr %10, align 8
  %167 = load i32, ptr %11, align 4
  %168 = sext i32 %167 to i64
  %169 = add nsw i64 %lsr.iv, %168
  %170 = getelementptr i32, ptr %166, i64 %169
  store i32 %165, ptr %170, align 4
  %lsr.iv.next = add i64 %lsr.iv, 8
  %171 = add i64 %33, %lsr.iv.next
  %exitcond.not.7 = icmp eq i64 %171, 7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: nounwind
define void @tick_contact_csr_25_kernel_2_range_for(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.2, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 2, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1162, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 2, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #0
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body.2(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = shl i32 %2, 9
  %4 = add i32 %3, 512
  %5 = tail call i32 @llvm.smin.i32(i32 %4, i32 70)
  %6 = icmp slt i32 %3, %5
  br i1 %6, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %7 = load ptr, ptr %0, align 8
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 1, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 1, i32 0, i32 1
  %10 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 4, i32 1
  %11 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr } }, ptr %7, i64 0, i32 5, i32 1
  %12 = sext i32 %3 to i64
  %wide.trip.count = sext i32 %5 to i64
  %13 = xor i64 %12, -1
  %14 = add nsw i64 %13, %wide.trip.count
  %xtraiter = and i64 %wide.trip.count, 6
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol.preheader

for_loop_body.prol.preheader:                     ; preds = %for_loop_body.lr.ph
  br label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.prol, %for_loop_body.prol.preheader
  %lsr.iv53 = phi i64 [ %xtraiter, %for_loop_body.prol.preheader ], [ %lsr.iv.next54, %for_loop_body.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body.prol ], [ %12, %for_loop_body.prol.preheader ]
  %15 = load ptr, ptr %8, align 8
  %16 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep52 = getelementptr i8, ptr %15, i64 %16
  %17 = load i32, ptr %uglygep52, align 4
  %18 = load ptr, ptr %10, align 8
  %uglygep51 = getelementptr i8, ptr %18, i64 %16
  store i32 %17, ptr %uglygep51, align 4
  %19 = load ptr, ptr %8, align 8
  %20 = load i32, ptr %9, align 4
  %21 = sext i32 %20 to i64
  %22 = add nsw i64 %indvars.iv.prol, %21
  %23 = getelementptr i32, ptr %19, i64 %22
  %24 = load i32, ptr %23, align 4
  %25 = load ptr, ptr %11, align 8
  %uglygep50 = getelementptr i8, ptr %25, i64 %16
  store i32 %24, ptr %uglygep50, align 4
  %indvars.iv.next.prol = add nuw nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next54 = add nsw i64 %lsr.iv53, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next54, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body.prol.loopexit.loopexit, label %for_loop_body.prol, !llvm.loop !9

for_loop_body.prol.loopexit.loopexit:             ; preds = %for_loop_body.prol
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %for_loop_body.prol.loopexit.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %12, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %for_loop_body.prol.loopexit.loopexit ]
  %26 = icmp ult i64 %14, 7
  br i1 %26, label %after_for, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  %27 = sub i64 0, %wide.trip.count
  %28 = add nsw i64 %indvars.iv.unr, 7
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.preheader
  %lsr.iv = phi i64 [ %28, %for_loop_body.preheader ], [ %lsr.iv.next, %for_loop_body ]
  %29 = load ptr, ptr %8, align 8
  %30 = shl i64 %lsr.iv, 2
  %uglygep38 = getelementptr i8, ptr %29, i64 %30
  %uglygep39 = getelementptr i8, ptr %uglygep38, i64 -28
  %31 = load i32, ptr %uglygep39, align 4
  %32 = load ptr, ptr %10, align 8
  %uglygep40 = getelementptr i8, ptr %32, i64 %30
  %uglygep41 = getelementptr i8, ptr %uglygep40, i64 -28
  store i32 %31, ptr %uglygep41, align 4
  %33 = load ptr, ptr %8, align 8
  %34 = load i32, ptr %9, align 4
  %35 = sext i32 %34 to i64
  %36 = add i64 %lsr.iv, %35
  %37 = getelementptr i32, ptr %33, i64 %36
  %38 = getelementptr i32, ptr %37, i64 -7
  %39 = load i32, ptr %38, align 4
  %40 = load ptr, ptr %11, align 8
  %uglygep42 = getelementptr i8, ptr %40, i64 %30
  %uglygep43 = getelementptr i8, ptr %uglygep42, i64 -28
  store i32 %39, ptr %uglygep43, align 4
  %41 = load ptr, ptr %8, align 8
  %uglygep48 = getelementptr i8, ptr %41, i64 %30
  %uglygep49 = getelementptr i8, ptr %uglygep48, i64 -24
  %42 = load i32, ptr %uglygep49, align 4
  %43 = load ptr, ptr %10, align 8
  %uglygep46 = getelementptr i8, ptr %43, i64 %30
  %uglygep47 = getelementptr i8, ptr %uglygep46, i64 -24
  store i32 %42, ptr %uglygep47, align 4
  %44 = load ptr, ptr %8, align 8
  %45 = load i32, ptr %9, align 4
  %46 = sext i32 %45 to i64
  %47 = add i64 %lsr.iv, %46
  %48 = getelementptr i32, ptr %44, i64 %47
  %49 = getelementptr i32, ptr %48, i64 -6
  %50 = load i32, ptr %49, align 4
  %51 = load ptr, ptr %11, align 8
  %uglygep44 = getelementptr i8, ptr %51, i64 %30
  %uglygep45 = getelementptr i8, ptr %uglygep44, i64 -24
  store i32 %50, ptr %uglygep45, align 4
  %52 = load ptr, ptr %8, align 8
  %uglygep36 = getelementptr i8, ptr %52, i64 %30
  %uglygep37 = getelementptr i8, ptr %uglygep36, i64 -20
  %53 = load i32, ptr %uglygep37, align 4
  %54 = load ptr, ptr %10, align 8
  %uglygep34 = getelementptr i8, ptr %54, i64 %30
  %uglygep35 = getelementptr i8, ptr %uglygep34, i64 -20
  store i32 %53, ptr %uglygep35, align 4
  %55 = load ptr, ptr %8, align 8
  %56 = load i32, ptr %9, align 4
  %57 = sext i32 %56 to i64
  %58 = add i64 %lsr.iv, %57
  %59 = getelementptr i32, ptr %55, i64 %58
  %60 = getelementptr i32, ptr %59, i64 -5
  %61 = load i32, ptr %60, align 4
  %62 = load ptr, ptr %11, align 8
  %uglygep32 = getelementptr i8, ptr %62, i64 %30
  %uglygep33 = getelementptr i8, ptr %uglygep32, i64 -20
  store i32 %61, ptr %uglygep33, align 4
  %63 = load ptr, ptr %8, align 8
  %uglygep30 = getelementptr i8, ptr %63, i64 %30
  %uglygep31 = getelementptr i8, ptr %uglygep30, i64 -16
  %64 = load i32, ptr %uglygep31, align 4
  %65 = load ptr, ptr %10, align 8
  %uglygep28 = getelementptr i8, ptr %65, i64 %30
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 -16
  store i32 %64, ptr %uglygep29, align 4
  %66 = load ptr, ptr %8, align 8
  %67 = load i32, ptr %9, align 4
  %68 = sext i32 %67 to i64
  %69 = add i64 %lsr.iv, %68
  %70 = getelementptr i32, ptr %66, i64 %69
  %71 = getelementptr i32, ptr %70, i64 -4
  %72 = load i32, ptr %71, align 4
  %73 = load ptr, ptr %11, align 8
  %uglygep26 = getelementptr i8, ptr %73, i64 %30
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 -16
  store i32 %72, ptr %uglygep27, align 4
  %74 = load ptr, ptr %8, align 8
  %uglygep24 = getelementptr i8, ptr %74, i64 %30
  %uglygep25 = getelementptr i8, ptr %uglygep24, i64 -12
  %75 = load i32, ptr %uglygep25, align 4
  %76 = load ptr, ptr %10, align 8
  %uglygep22 = getelementptr i8, ptr %76, i64 %30
  %uglygep23 = getelementptr i8, ptr %uglygep22, i64 -12
  store i32 %75, ptr %uglygep23, align 4
  %77 = load ptr, ptr %8, align 8
  %78 = load i32, ptr %9, align 4
  %79 = sext i32 %78 to i64
  %80 = add i64 %lsr.iv, %79
  %81 = getelementptr i32, ptr %77, i64 %80
  %82 = getelementptr i32, ptr %81, i64 -3
  %83 = load i32, ptr %82, align 4
  %84 = load ptr, ptr %11, align 8
  %uglygep20 = getelementptr i8, ptr %84, i64 %30
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 -12
  store i32 %83, ptr %uglygep21, align 4
  %85 = load ptr, ptr %8, align 8
  %uglygep18 = getelementptr i8, ptr %85, i64 %30
  %uglygep19 = getelementptr i8, ptr %uglygep18, i64 -8
  %86 = load i32, ptr %uglygep19, align 4
  %87 = load ptr, ptr %10, align 8
  %uglygep16 = getelementptr i8, ptr %87, i64 %30
  %uglygep17 = getelementptr i8, ptr %uglygep16, i64 -8
  store i32 %86, ptr %uglygep17, align 4
  %88 = load ptr, ptr %8, align 8
  %89 = load i32, ptr %9, align 4
  %90 = sext i32 %89 to i64
  %91 = add i64 %lsr.iv, %90
  %92 = getelementptr i32, ptr %88, i64 %91
  %93 = getelementptr i32, ptr %92, i64 -2
  %94 = load i32, ptr %93, align 4
  %95 = load ptr, ptr %11, align 8
  %uglygep14 = getelementptr i8, ptr %95, i64 %30
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 -8
  store i32 %94, ptr %uglygep15, align 4
  %96 = load ptr, ptr %8, align 8
  %uglygep12 = getelementptr i8, ptr %96, i64 %30
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 -4
  %97 = load i32, ptr %uglygep13, align 4
  %98 = load ptr, ptr %10, align 8
  %uglygep10 = getelementptr i8, ptr %98, i64 %30
  %uglygep11 = getelementptr i8, ptr %uglygep10, i64 -4
  store i32 %97, ptr %uglygep11, align 4
  %99 = load ptr, ptr %8, align 8
  %100 = load i32, ptr %9, align 4
  %101 = sext i32 %100 to i64
  %102 = add i64 %lsr.iv, %101
  %103 = getelementptr i32, ptr %99, i64 %102
  %104 = getelementptr i32, ptr %103, i64 -1
  %105 = load i32, ptr %104, align 4
  %106 = load ptr, ptr %11, align 8
  %uglygep8 = getelementptr i8, ptr %106, i64 %30
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 -4
  store i32 %105, ptr %uglygep9, align 4
  %107 = load ptr, ptr %8, align 8
  %uglygep7 = getelementptr i8, ptr %107, i64 %30
  %108 = load i32, ptr %uglygep7, align 4
  %109 = load ptr, ptr %10, align 8
  %uglygep6 = getelementptr i8, ptr %109, i64 %30
  store i32 %108, ptr %uglygep6, align 4
  %110 = load ptr, ptr %8, align 8
  %111 = load i32, ptr %9, align 4
  %112 = sext i32 %111 to i64
  %113 = add nsw i64 %lsr.iv, %112
  %114 = getelementptr i32, ptr %110, i64 %113
  %115 = load i32, ptr %114, align 4
  %116 = load ptr, ptr %11, align 8
  %uglygep = getelementptr i8, ptr %116, i64 %30
  store i32 %115, ptr %uglygep, align 4
  %lsr.iv.next = add i64 %lsr.iv, 8
  %117 = add i64 %27, %lsr.iv.next
  %exitcond.not.7 = icmp eq i64 %117, 7
  br i1 %exitcond.not.7, label %after_for.loopexit, label %for_loop_body

after_for.loopexit:                               ; preds = %for_loop_body
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %for_loop_body.prol.loopexit, %allocs
  ret void
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_parallel_range_for_task(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #2 {
  %4 = alloca %struct.RuntimeContext.1162, align 8
  %.sroa.0.0.copyload = load ptr, ptr %0, align 8
  %.sroa.4.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 8
  %.sroa.4.0.copyload = load ptr, ptr %.sroa.4.0..sroa_idx, align 8
  %.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 16
  %.sroa.5.0.copyload = load ptr, ptr %.sroa.5.0..sroa_idx, align 8
  %.sroa.7.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 24
  %.sroa.7.0.copyload = load ptr, ptr %.sroa.7.0..sroa_idx, align 8
  %.sroa.8.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 32
  %.sroa.8.0.copyload = load i64, ptr %.sroa.8.0..sroa_idx, align 8
  %.sroa.9.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 40
  %.sroa.9.0.copyload = load i32, ptr %.sroa.9.0..sroa_idx, align 8
  %.sroa.12.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 44
  %.sroa.12.0.copyload = load i32, ptr %.sroa.12.0..sroa_idx, align 4
  %.sroa.15.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 48
  %.sroa.15.0.copyload = load i32, ptr %.sroa.15.0..sroa_idx, align 8
  %.sroa.17.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 52
  %.sroa.17.0.copyload = load i32, ptr %.sroa.17.0..sroa_idx, align 4
  %5 = alloca i8, i64 %.sroa.8.0.copyload, align 8
  %.not = icmp eq ptr %.sroa.4.0.copyload, null
  br i1 %.not, label %7, label %6

6:                                                ; preds = %3
  call void %.sroa.4.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #0
  br label %7

7:                                                ; preds = %6, %3
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %4, ptr noundef nonnull align 8 dereferenceable(32) %.sroa.0.0.copyload, i64 32, i1 false)
  %8 = getelementptr inbounds %struct.RuntimeContext.1162, ptr %4, i64 0, i32 2
  store i32 %1, ptr %8, align 8
  switch i32 %.sroa.17.0.copyload, label %.loopexit [
    i32 1, label %9
    i32 -1, label %17
  ]

9:                                                ; preds = %7
  %10 = mul nsw i32 %.sroa.15.0.copyload, %2
  %11 = add nsw i32 %10, %.sroa.9.0.copyload
  %12 = add nsw i32 %11, %.sroa.15.0.copyload
  %13 = call i32 @llvm.smin.i32(i32 %.sroa.12.0.copyload, i32 %12)
  %14 = icmp slt i32 %11, %13
  br i1 %14, label %.lr.ph.preheader, label %.loopexit

.lr.ph.preheader:                                 ; preds = %9
  br label %.lr.ph

.lr.ph:                                           ; preds = %.lr.ph, %.lr.ph.preheader
  %.02039 = phi i32 [ %15, %.lr.ph ], [ %11, %.lr.ph.preheader ]
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.02039) #0
  %15 = add nsw i32 %.02039, 1
  %16 = icmp slt i32 %15, %13
  br i1 %16, label %.lr.ph, label %.loopexit.loopexit, !llvm.loop !10

17:                                               ; preds = %7
  %18 = mul nsw i32 %.sroa.15.0.copyload, %2
  %19 = sub nsw i32 %.sroa.12.0.copyload, %18
  %20 = mul nsw i32 %19, %.sroa.15.0.copyload
  %21 = call i32 @llvm.smax.i32(i32 %.sroa.9.0.copyload, i32 %20)
  %.not25.not40 = icmp sgt i32 %19, %21
  br i1 %.not25.not40, label %.lr.ph42.preheader, label %.loopexit

.lr.ph42.preheader:                               ; preds = %17
  br label %.lr.ph42

.lr.ph42:                                         ; preds = %.lr.ph42, %.lr.ph42.preheader
  %.0.in41 = phi i32 [ %.0, %.lr.ph42 ], [ %19, %.lr.ph42.preheader ]
  %.0 = add nsw i32 %.0.in41, -1
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.0) #0
  %.not25.not = icmp sgt i32 %.0, %21
  br i1 %.not25.not, label %.lr.ph42, label %.loopexit.loopexit47, !llvm.loop !12

.loopexit.loopexit:                               ; preds = %.lr.ph
  br label %.loopexit

.loopexit.loopexit47:                             ; preds = %.lr.ph42
  br label %.loopexit

.loopexit:                                        ; preds = %.loopexit.loopexit47, %.loopexit.loopexit, %17, %9, %7
  %.not24 = icmp eq ptr %.sroa.7.0.copyload, null
  br i1 %.not24, label %23, label %22

22:                                               ; preds = %.loopexit
  call void %.sroa.7.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #0
  br label %23

23:                                               ; preds = %22, %.loopexit
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #4

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #5

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #5

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smax.i32(i32, i32) #6

attributes #0 = { nounwind }
attributes #1 = { nofree nosync nounwind }
attributes #2 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #4 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #5 = { argmemonly nocallback nofree nosync nounwind willreturn }
attributes #6 = { nocallback nofree nosync nounwind readnone speculatable willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.unroll.disable"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !11}
!11 = !{!"llvm.loop.mustprogress"}
!12 = distinct !{!12, !11}
