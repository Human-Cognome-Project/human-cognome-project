; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct.RuntimeContext.990 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }
%struct.range_task_helper_context = type { ptr, ptr, ptr, ptr, i64, i32, i32, i32, i32 }

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @geometry_source_order_5_selection_25_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %0, i64 0, i32 3
  %2 = load i32, ptr %1, align 4
  %3 = getelementptr inbounds %struct.RuntimeContext.990, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  store i32 %2, ptr %6, align 4
  ret void
}

; Function Attrs: nounwind
define void @geometry_source_order_5_selection_25_kernel_1_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.990, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = getelementptr inbounds %struct.RuntimeContext.990, ptr %0, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  %7 = load i32, ptr %6, align 4
  %8 = tail call i32 @llvm.smax.i32(i32 %7, i32 512)
  %9 = mul i32 %8, %2
  %10 = add i32 %9, %8
  %11 = tail call i32 @llvm.smin.i32(i32 %7, i32 %10)
  %12 = icmp slt i32 %9, %11
  br i1 %12, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %13 = load ptr, ptr %0, align 8
  %14 = getelementptr { { i32, i32 }, ptr }, ptr %13, i64 0, i32 1
  %15 = getelementptr { { i32, i32 }, ptr }, ptr %13, i64 0, i32 0, i32 1
  %16 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %13, i64 0, i32 1, i32 1
  %17 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %13, i64 0, i32 2, i32 1
  %18 = sext i32 %9 to i64
  %wide.trip.count30 = sext i32 %11 to i64
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_for3, %for_loop_body.lr.ph
  %indvars.iv27 = phi i64 [ %18, %for_loop_body.lr.ph ], [ %indvars.iv.next28, %after_for3 ]
  %19 = load ptr, ptr %14, align 8
  %20 = load i32, ptr %15, align 4
  %21 = sext i32 %20 to i64
  %22 = getelementptr i32, ptr %19, i64 %indvars.iv27
  %23 = load i32, ptr %22, align 4
  %24 = add nsw i64 %indvars.iv27, %21
  %25 = getelementptr i32, ptr %19, i64 %24
  %26 = load i32, ptr %25, align 4
  %27 = tail call i32 @llvm.smin.i32(i32 %23, i32 %26)
  %28 = zext i32 %27 to i64
  %29 = shl nuw i64 %28, 32
  %30 = tail call i32 @llvm.smax.i32(i32 %23, i32 %26)
  %31 = sext i32 %30 to i64
  %32 = add i64 %29, %31
  %33 = load i32, ptr %6, align 4
  %34 = icmp sgt i32 %33, 0
  br i1 %34, label %for_loop_body1.preheader, label %after_for3

for_loop_body1.preheader:                         ; preds = %for_loop_body
  %wide.trip.count = zext i32 %33 to i64
  %min.iters.check = icmp ult i32 %33, 8
  br i1 %min.iters.check, label %for_loop_body1.preheader43, label %vector.ph

vector.ph:                                        ; preds = %for_loop_body1.preheader
  %n.vec = and i64 %wide.trip.count, 4294967288
  %broadcast.splatinsert = insertelement <8 x i64> poison, i64 %32, i64 0
  %broadcast.splat = shufflevector <8 x i64> %broadcast.splatinsert, <8 x i64> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert39 = insertelement <8 x i64> poison, i64 %indvars.iv27, i64 0
  %broadcast.splat40 = shufflevector <8 x i64> %broadcast.splatinsert39, <8 x i64> poison, <8 x i32> zeroinitializer
  %35 = shl nsw i64 %21, 2
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %lsr.iv55 = phi i64 [ %lsr.iv.next, %vector.body ], [ %n.vec, %vector.ph ]
  %lsr.iv = phi ptr [ %uglygep, %vector.body ], [ %19, %vector.ph ]
  %vec.ind = phi <8 x i64> [ <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, %vector.ph ], [ %vec.ind.next, %vector.body ]
  %vec.phi = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %52, %vector.body ]
  %vec.phi36 = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %50, %vector.body ]
  %vec.phi37 = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %48, %vector.body ]
  %wide.load = load <8 x i32>, ptr %lsr.iv, align 4
  %uglygep54 = getelementptr i8, ptr %lsr.iv, i64 %35
  %wide.load38 = load <8 x i32>, ptr %uglygep54, align 4
  %36 = call <8 x i32> @llvm.smin.v8i32(<8 x i32> %wide.load, <8 x i32> %wide.load38)
  %37 = zext <8 x i32> %36 to <8 x i64>
  %38 = shl nuw <8 x i64> %37, <i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32>
  %39 = call <8 x i32> @llvm.smax.v8i32(<8 x i32> %wide.load, <8 x i32> %wide.load38)
  %40 = sext <8 x i32> %39 to <8 x i64>
  %41 = add <8 x i64> %38, %40
  %42 = icmp eq <8 x i64> %41, %broadcast.splat
  %43 = icmp slt <8 x i64> %vec.ind, %broadcast.splat40
  %44 = and <8 x i1> %43, %42
  %45 = icmp slt <8 x i64> %41, %broadcast.splat
  %46 = or <8 x i1> %45, %44
  %47 = zext <8 x i1> %46 to <8 x i32>
  %48 = add <8 x i32> %vec.phi37, %47
  %49 = zext <8 x i1> %42 to <8 x i32>
  %50 = add <8 x i32> %vec.phi36, %49
  %51 = zext <8 x i1> %44 to <8 x i32>
  %52 = add <8 x i32> %vec.phi, %51
  %vec.ind.next = add <8 x i64> %vec.ind, <i64 8, i64 8, i64 8, i64 8, i64 8, i64 8, i64 8, i64 8>
  %uglygep = getelementptr i8, ptr %lsr.iv, i64 32
  %lsr.iv.next = add nsw i64 %lsr.iv55, -8
  %53 = icmp eq i64 %lsr.iv.next, 0
  br i1 %53, label %middle.block, label %vector.body, !llvm.loop !6

middle.block:                                     ; preds = %vector.body
  %54 = call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %48)
  %55 = call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %50)
  %56 = call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %52)
  %cmp.n = icmp eq i64 %n.vec, %wide.trip.count
  br i1 %cmp.n, label %after_for3, label %for_loop_body1.preheader43

for_loop_body1.preheader43:                       ; preds = %middle.block, %for_loop_body1.preheader
  %indvars.iv.ph = phi i64 [ 0, %for_loop_body1.preheader ], [ %n.vec, %middle.block ]
  %.01319.ph = phi i32 [ 0, %for_loop_body1.preheader ], [ %56, %middle.block ]
  %.01418.ph = phi i32 [ 0, %for_loop_body1.preheader ], [ %55, %middle.block ]
  %.01517.ph = phi i32 [ 0, %for_loop_body1.preheader ], [ %54, %middle.block ]
  %57 = shl nsw i64 %21, 2
  %uglygep56 = getelementptr i8, ptr %19, i64 %57
  br label %for_loop_body1

after_for.loopexit:                               ; preds = %after_for3
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %allocs
  ret void

for_loop_body1:                                   ; preds = %for_loop_body1, %for_loop_body1.preheader43
  %indvars.iv = phi i64 [ %indvars.iv.next, %for_loop_body1 ], [ %indvars.iv.ph, %for_loop_body1.preheader43 ]
  %.01319 = phi i32 [ %77, %for_loop_body1 ], [ %.01319.ph, %for_loop_body1.preheader43 ]
  %.01418 = phi i32 [ %75, %for_loop_body1 ], [ %.01418.ph, %for_loop_body1.preheader43 ]
  %.01517 = phi i32 [ %73, %for_loop_body1 ], [ %.01517.ph, %for_loop_body1.preheader43 ]
  %58 = shl i64 %indvars.iv, 2
  %uglygep58 = getelementptr i8, ptr %19, i64 %58
  %59 = load i32, ptr %uglygep58, align 4
  %uglygep57 = getelementptr i8, ptr %uglygep56, i64 %58
  %60 = load i32, ptr %uglygep57, align 4
  %61 = tail call i32 @llvm.smin.i32(i32 %59, i32 %60)
  %62 = zext i32 %61 to i64
  %63 = shl nuw i64 %62, 32
  %64 = tail call i32 @llvm.smax.i32(i32 %59, i32 %60)
  %65 = sext i32 %64 to i64
  %66 = add i64 %63, %65
  %67 = icmp eq i64 %66, %32
  %68 = icmp slt i64 %indvars.iv, %indvars.iv27
  %69 = and i1 %68, %67
  %70 = icmp slt i64 %66, %32
  %71 = or i1 %70, %69
  %72 = zext i1 %71 to i32
  %73 = add i32 %.01517, %72
  %74 = zext i1 %67 to i32
  %75 = add i32 %.01418, %74
  %76 = zext i1 %69 to i32
  %77 = add i32 %.01319, %76
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %wide.trip.count, %indvars.iv.next
  br i1 %exitcond.not, label %after_for3.loopexit, label %for_loop_body1, !llvm.loop !9

after_for3.loopexit:                              ; preds = %for_loop_body1
  br label %after_for3

after_for3:                                       ; preds = %after_for3.loopexit, %middle.block, %for_loop_body
  %.015.lcssa = phi i32 [ 0, %for_loop_body ], [ %54, %middle.block ], [ %73, %after_for3.loopexit ]
  %.014.lcssa = phi i32 [ 0, %for_loop_body ], [ %55, %middle.block ], [ %75, %after_for3.loopexit ]
  %.013.lcssa = phi i32 [ 0, %for_loop_body ], [ %56, %middle.block ], [ %77, %after_for3.loopexit ]
  %78 = load ptr, ptr %16, align 8
  %79 = sext i32 %.015.lcssa to i64
  %80 = getelementptr i32, ptr %78, i64 %79
  %81 = trunc i64 %indvars.iv27 to i32
  store i32 %81, ptr %80, align 4
  %82 = add i32 %.014.lcssa, %.015.lcssa
  %83 = sub i32 %82, %.013.lcssa
  %84 = load ptr, ptr %17, align 8
  %85 = getelementptr i32, ptr %84, i64 %79
  store i32 %83, ptr %85, align 4
  %indvars.iv.next28 = add nsw i64 %indvars.iv27, 1
  %exitcond31.not = icmp eq i64 %indvars.iv.next28, %wide.trip.count30
  br i1 %exitcond31.not, label %after_for.loopexit, label %for_loop_body, !llvm.loop !10
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_parallel_range_for_task(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #3 {
  %4 = alloca %struct.RuntimeContext.990, align 8
  %.sroa.0.0.copyload = load ptr, ptr %0, align 8
  %.sroa.4.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 8
  %.sroa.4.0.copyload = load ptr, ptr %.sroa.4.0..sroa_idx, align 8
  %.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 16
  %.sroa.5.0.copyload = load ptr, ptr %.sroa.5.0..sroa_idx, align 8
  %.sroa.7.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 24
  %.sroa.7.0.copyload = load ptr, ptr %.sroa.7.0..sroa_idx, align 8
  %.sroa.8.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 32
  %.sroa.8.0.copyload = load i64, ptr %.sroa.8.0..sroa_idx, align 8
  %.sroa.9.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 40
  %.sroa.9.0.copyload = load i32, ptr %.sroa.9.0..sroa_idx, align 8
  %.sroa.12.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 44
  %.sroa.12.0.copyload = load i32, ptr %.sroa.12.0..sroa_idx, align 4
  %.sroa.15.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 48
  %.sroa.15.0.copyload = load i32, ptr %.sroa.15.0..sroa_idx, align 8
  %.sroa.17.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 52
  %.sroa.17.0.copyload = load i32, ptr %.sroa.17.0..sroa_idx, align 4
  %5 = alloca i8, i64 %.sroa.8.0.copyload, align 8
  %.not = icmp eq ptr %.sroa.4.0.copyload, null
  br i1 %.not, label %7, label %6

6:                                                ; preds = %3
  call void %.sroa.4.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %7

7:                                                ; preds = %6, %3
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %4, ptr noundef nonnull align 8 dereferenceable(32) %.sroa.0.0.copyload, i64 32, i1 false)
  %8 = getelementptr inbounds %struct.RuntimeContext.990, ptr %4, i64 0, i32 2
  store i32 %1, ptr %8, align 8
  switch i32 %.sroa.17.0.copyload, label %.loopexit [
    i32 1, label %9
    i32 -1, label %17
  ]

9:                                                ; preds = %7
  %10 = mul nsw i32 %.sroa.15.0.copyload, %2
  %11 = add nsw i32 %10, %.sroa.9.0.copyload
  %12 = add nsw i32 %11, %.sroa.15.0.copyload
  %13 = call i32 @llvm.smin.i32(i32 %.sroa.12.0.copyload, i32 %12)
  %14 = icmp slt i32 %11, %13
  br i1 %14, label %.lr.ph.preheader, label %.loopexit

.lr.ph.preheader:                                 ; preds = %9
  br label %.lr.ph

.lr.ph:                                           ; preds = %.lr.ph, %.lr.ph.preheader
  %.02039 = phi i32 [ %15, %.lr.ph ], [ %11, %.lr.ph.preheader ]
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.02039) #1
  %15 = add nsw i32 %.02039, 1
  %16 = icmp slt i32 %15, %13
  br i1 %16, label %.lr.ph, label %.loopexit.loopexit, !llvm.loop !11

17:                                               ; preds = %7
  %18 = mul nsw i32 %.sroa.15.0.copyload, %2
  %19 = sub nsw i32 %.sroa.12.0.copyload, %18
  %20 = mul nsw i32 %19, %.sroa.15.0.copyload
  %21 = call i32 @llvm.smax.i32(i32 %.sroa.9.0.copyload, i32 %20)
  %.not25.not40 = icmp sgt i32 %19, %21
  br i1 %.not25.not40, label %.lr.ph42.preheader, label %.loopexit

.lr.ph42.preheader:                               ; preds = %17
  br label %.lr.ph42

.lr.ph42:                                         ; preds = %.lr.ph42, %.lr.ph42.preheader
  %.0.in41 = phi i32 [ %.0, %.lr.ph42 ], [ %19, %.lr.ph42.preheader ]
  %.0 = add nsw i32 %.0.in41, -1
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.0) #1
  %.not25.not = icmp sgt i32 %.0, %21
  br i1 %.not25.not, label %.lr.ph42, label %.loopexit.loopexit47, !llvm.loop !13

.loopexit.loopexit:                               ; preds = %.lr.ph
  br label %.loopexit

.loopexit.loopexit47:                             ; preds = %.lr.ph42
  br label %.loopexit

.loopexit:                                        ; preds = %.loopexit.loopexit47, %.loopexit.loopexit, %17, %9, %7
  %.not24 = icmp eq ptr %.sroa.7.0.copyload, null
  br i1 %.not24, label %23, label %22

22:                                               ; preds = %.loopexit
  call void %.sroa.7.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %23

23:                                               ; preds = %22, %.loopexit
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #5

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smax.i32(i32, i32) #5

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #6

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #6

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare <8 x i32> @llvm.smin.v8i32(<8 x i32>, <8 x i32>) #7

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare <8 x i32> @llvm.smax.v8i32(<8 x i32>, <8 x i32>) #7

; Function Attrs: nocallback nofree nosync nounwind readnone willreturn
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #8

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { nofree nosync nounwind }
attributes #3 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #5 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #6 = { argmemonly nocallback nofree nosync nounwind willreturn }
attributes #7 = { nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #8 = { nocallback nofree nosync nounwind readnone willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7, !8}
!7 = !{!"llvm.loop.unroll.disable"}
!8 = !{!"llvm.loop.isvectorized", i32 1}
!9 = distinct !{!9, !7, !8}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !12, !7}
!12 = !{!"llvm.loop.mustprogress"}
!13 = distinct !{!13, !12, !7}
