; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%0 = type { [1048576 x %1], %2, %3 }
%1 = type { i8 }
%2 = type { [128 x i64], [128 x ptr] }
%3 = type { [4 x i32], [128 x %4] }
%4 = type { i32, i64 }
%struct.RuntimeContext.1153 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }
%struct.range_task_helper_context = type { ptr, ptr, ptr, ptr, i64, i32, i32, i32, i32 }
%struct.NodeManager = type <{ ptr, i32, i32, i32, i32, ptr, ptr, ptr, i32, [4 x i8] }>
%struct.ListManager = type { [256 x ptr], i64, i64, i32, i32, i32, ptr }
%class.anon = type { ptr, ptr, ptr, ptr }

@.str = private unnamed_addr constant [28 x i8] c"Out of pre-allocated memory\00", align 1
@.str.2 = private unnamed_addr constant [28 x i8] c"List manager out of chunks.\00", align 1

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @tick_coverage_25_2_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %0, i64 0, i32 9
  %2 = load i32, ptr %1, align 4
  %3 = getelementptr inbounds %struct.RuntimeContext.1153, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  store i32 %2, ptr %6, align 4
  %7 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %0, i64 0, i32 8, i32 1
  %8 = load ptr, ptr %7, align 8
  store i64 0, ptr %8, align 8
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %0, i64 0, i32 3, i32 1
  %10 = load ptr, ptr %9, align 8
  %11 = getelementptr i64, ptr %10, i64 2
  %12 = load i64, ptr %11, align 8
  %13 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %0, i64 0, i32 7, i32 1
  %14 = load ptr, ptr %13, align 8
  %15 = getelementptr i64, ptr %14, i64 2
  %16 = load i64, ptr %15, align 8
  %.not = icmp eq i64 %12, %16
  br i1 %.not, label %after_if, label %true_block

true_block:                                       ; preds = %entry
  store i64 1, ptr %8, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %entry
  ret void
}

; Function Attrs: nounwind
define void @tick_coverage_25_2_kernel_1_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1153, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nounwind
define internal void @function_body(ptr %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = shl i32 %2, 9
  %8 = add i32 %7, 512
  %9 = tail call i32 @llvm.smin.i32(i32 %8, i32 70)
  %10 = load ptr, ptr %0, align 8
  %11 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %10, i64 0, i32 3, i32 1
  %12 = load ptr, ptr %11, align 8
  %13 = getelementptr i64, ptr %12, i64 3
  %14 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %10, i64 0, i32 7, i32 1
  %15 = load ptr, ptr %14, align 8
  %16 = getelementptr i64, ptr %15, i64 3
  %17 = icmp slt i32 %7, %9
  br i1 %17, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %18 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %10, i64 0, i32 1, i32 1
  %19 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %10, i64 0, i32 5, i32 1
  %20 = getelementptr { { i32, i32 }, ptr }, ptr %10, i64 0, i32 1
  %21 = getelementptr { { i32, i32 }, ptr }, ptr %10, i64 0, i32 0, i32 1
  %22 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %10, i64 0, i32 4, i32 1
  %23 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %10, i64 0, i32 4, i32 0, i32 1
  %24 = getelementptr inbounds %struct.RuntimeContext.1153, ptr %0, i64 0, i32 1
  %25 = sext i32 %7 to i64
  %wide.trip.count = sext i32 %9 to i64
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if, %for_loop_body.lr.ph
  %indvars.iv = phi i64 [ %25, %for_loop_body.lr.ph ], [ %indvars.iv.next, %after_if ]
  %26 = load i64, ptr %13, align 8
  %27 = icmp sgt i64 %26, %indvars.iv
  %28 = load i64, ptr %16, align 8
  %29 = icmp sgt i64 %28, %indvars.iv
  %30 = load ptr, ptr %18, align 8
  %31 = getelementptr i32, ptr %30, i64 %indvars.iv
  %32 = load i32, ptr %31, align 4
  %33 = load ptr, ptr %19, align 8
  %34 = getelementptr i32, ptr %33, i64 %indvars.iv
  %35 = load i32, ptr %34, align 4
  %36 = icmp ne i32 %32, %35
  %37 = load ptr, ptr %20, align 8
  %38 = load i32, ptr %21, align 4
  %39 = sext i32 %38 to i64
  %40 = getelementptr i32, ptr %37, i64 %indvars.iv
  %41 = load i32, ptr %40, align 4
  %42 = load ptr, ptr %22, align 8
  %43 = load i32, ptr %23, align 4
  %44 = sext i32 %43 to i64
  %45 = getelementptr i32, ptr %42, i64 %indvars.iv
  %46 = load i32, ptr %45, align 4
  %47 = icmp ne i32 %41, %46
  %48 = or i1 %36, %47
  %49 = add nsw i64 %indvars.iv, %39
  %50 = getelementptr i32, ptr %37, i64 %49
  %51 = load i32, ptr %50, align 4
  %52 = add nsw i64 %indvars.iv, %44
  %53 = getelementptr i32, ptr %42, i64 %52
  %54 = load i32, ptr %53, align 4
  %55 = icmp ne i32 %51, %54
  %56 = or i1 %48, %55
  %57 = xor i1 %27, %29
  %58 = and i1 %27, %29
  %59 = and i1 %58, %56
  %60 = or i1 %57, %59
  br i1 %60, label %true_block, label %after_if

after_for.loopexit:                               ; preds = %after_if
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %61 = load ptr, ptr %0, align 8
  %62 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %61, i64 0, i32 8, i32 1
  %63 = load ptr, ptr %62, align 8
  %64 = atomicrmw add ptr %63, i64 1 seq_cst, align 8
  %65 = load ptr, ptr %24, align 8
  %66 = getelementptr inbounds %struct.LLVMRuntime, ptr %65, i64 0, i32 16
  %67 = load ptr, ptr %66, align 8
  %68 = load i32, ptr %67, align 4
  %.not = icmp eq i32 %68, 0
  br i1 %.not, label %after_if, label %true_block1

after_if:                                         ; preds = %Pointer_lookup_element.exit, %true_block28, %after_if24, %after_if6, %true_block, %for_loop_body
  %indvars.iv.next = add nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %indvars.iv.next, %wide.trip.count
  br i1 %exitcond.not, label %after_for.loopexit, label %for_loop_body

true_block1:                                      ; preds = %true_block
  br i1 %27, label %true_block4, label %after_if6

true_block4:                                      ; preds = %true_block1
  %69 = load i32, ptr %40, align 4
  %70 = icmp ult i32 %69, 70
  br i1 %70, label %true_block7, label %after_if9

after_if6:                                        ; preds = %Pointer_lookup_element.exit56, %true_block13, %after_if9, %true_block1
  br i1 %29, label %true_block19, label %after_if

true_block7:                                      ; preds = %true_block4
  %71 = getelementptr inbounds %struct.LLVMRuntime, ptr %65, i64 0, i32 7
  %72 = load ptr, ptr %71, align 8
  %73 = load ptr, ptr %72, align 8
  %74 = getelementptr %0, ptr %73, i64 0, i32 2, i32 1, i64 127
  %75 = lshr i32 %69, 3
  %76 = zext i32 %75 to i64
  %77 = getelementptr inbounds i8, ptr %74, i64 %76
  %78 = load i8, ptr %77, align 1
  %79 = zext i8 %78 to i32
  %80 = and i32 %69, 7
  %81 = shl nuw nsw i32 1, %80
  %82 = and i32 %81, %79
  %.not292 = icmp eq i32 %82, 0
  br i1 %.not292, label %after_if9, label %true_block10

after_if9:                                        ; preds = %Pointer_lookup_element.exit101, %true_block7, %true_block4
  %83 = load i32, ptr %50, align 4
  %84 = icmp ult i32 %83, 70
  br i1 %84, label %true_block13, label %after_if6

true_block10:                                     ; preds = %true_block7
  %85 = getelementptr inbounds ptr, ptr %72, i64 3
  %86 = load ptr, ptr %85, align 8
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %3)
  %87 = lshr i32 %69, 2
  %88 = and i32 %87, 56
  %89 = zext i32 %88 to i64
  %90 = getelementptr i8, ptr %86, i64 %89
  store volatile ptr %90, ptr %3, align 8
  %91 = getelementptr inbounds i8, ptr %90, i64 32
  %92 = load volatile ptr, ptr %91, align 8
  %93 = icmp eq ptr %92, null
  br i1 %93, label %94, label %Pointer_activate.exit140

94:                                               ; preds = %true_block10
  %.0..0..0..0..0..i102 = load volatile ptr, ptr %3, align 8
  %.0..0..0..0..0.2.i103 = load volatile ptr, ptr %3, align 8
  br label %95

95:                                               ; preds = %95, %94
  %96 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i103, i32 1 seq_cst, align 4
  %97 = icmp eq i32 %96, 1
  br i1 %97, label %95, label %mutex_lock_i32.exit.i.i.i104, !llvm.loop !6

mutex_lock_i32.exit.i.i.i104:                     ; preds = %95
  %98 = load volatile ptr, ptr %91, align 8
  %99 = icmp eq ptr %98, null
  br i1 %99, label %100, label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i139"

100:                                              ; preds = %mutex_lock_i32.exit.i.i.i104
  %101 = load ptr, ptr %24, align 8
  %102 = getelementptr inbounds %struct.LLVMRuntime, ptr %101, i64 0, i32 14
  %103 = load ptr, ptr %102, align 8
  %104 = getelementptr inbounds ptr, ptr %103, i64 24
  %105 = load ptr, ptr %104, align 8
  %106 = getelementptr inbounds %struct.NodeManager, ptr %105, i64 0, i32 4
  %107 = atomicrmw volatile add ptr %106, i32 1 seq_cst, align 4
  %108 = getelementptr inbounds %struct.NodeManager, ptr %105, i64 0, i32 5
  %109 = load ptr, ptr %108, align 8
  %110 = getelementptr inbounds %struct.ListManager, ptr %109, i64 0, i32 5
  %111 = load i32, ptr %110, align 8
  %.not.i.i.i.i.i105 = icmp slt i32 %107, %111
  br i1 %.not.i.i.i.i.i105, label %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i133, label %112

112:                                              ; preds = %100
  %113 = getelementptr inbounds %struct.NodeManager, ptr %105, i64 0, i32 7
  %114 = load ptr, ptr %113, align 8
  %115 = getelementptr inbounds %struct.ListManager, ptr %114, i64 0, i32 5
  %116 = atomicrmw volatile add ptr %115, i32 1 seq_cst, align 4
  %117 = getelementptr inbounds %struct.ListManager, ptr %114, i64 0, i32 3
  %118 = load i32, ptr %117, align 8
  %119 = ashr i32 %116, %118
  %120 = icmp ugt i32 %119, 131071
  br i1 %120, label %121, label %124

121:                                              ; preds = %112
  %122 = getelementptr inbounds %struct.ListManager, ptr %114, i64 0, i32 6
  %123 = load ptr, ptr %122, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %123, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i136

124:                                              ; preds = %112
  %125 = zext i32 %119 to i64
  %126 = lshr i64 %125, 9
  %127 = getelementptr inbounds [256 x ptr], ptr %114, i64 0, i64 %126
  %128 = load atomic i64, ptr %127 acquire, align 8
  %.not.i.i.i4.i.i.i.i.i106 = icmp eq i64 %128, 0
  br i1 %.not.i.i.i4.i.i.i.i.i106, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i109, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i108

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i108: ; preds = %124
  %129 = inttoptr i64 %128 to ptr
  %130 = and i64 %125, 511
  %131 = getelementptr inbounds ptr, ptr %129, i64 %130
  %132 = load atomic i64, ptr %131 acquire, align 8
  %.not.i.i5.i.i.i.i.i107 = icmp eq i64 %132, 0
  br i1 %.not.i.i5.i.i.i.i.i107, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i109, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i136

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i109: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i108, %124
  %133 = getelementptr inbounds %struct.ListManager, ptr %114, i64 0, i32 4
  br label %134

134:                                              ; preds = %134, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i109
  %135 = atomicrmw volatile xchg ptr %133, i32 1 seq_cst, align 4
  %136 = icmp eq i32 %135, 1
  br i1 %136, label %134, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i111, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i111:       ; preds = %134
  %137 = load atomic i64, ptr %127 acquire, align 8
  %138 = inttoptr i64 %137 to ptr
  %.not.i.i.i.i.i.i.i.i.i.i.i110 = icmp eq i64 %137, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i110, label %139, label %174

139:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i111
  %140 = getelementptr inbounds %struct.ListManager, ptr %114, i64 0, i32 6
  %141 = load ptr, ptr %140, align 8
  %142 = getelementptr inbounds %struct.LLVMRuntime, ptr %141, i64 0, i32 1
  %143 = getelementptr inbounds %struct.LLVMRuntime, ptr %141, i64 0, i32 28
  %144 = atomicrmw volatile add ptr %143, i64 4096 seq_cst, align 8
  %145 = getelementptr inbounds %struct.LLVMRuntime, ptr %141, i64 0, i32 1, i32 2
  %146 = load i64, ptr %145, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i.i.i112 = icmp eq i64 %146, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i.i.i112, label %167, label %147

147:                                              ; preds = %139
  %148 = getelementptr inbounds %struct.LLVMRuntime, ptr %141, i64 0, i32 26
  br label %149

149:                                              ; preds = %149, %147
  %150 = atomicrmw volatile xchg ptr %148, i32 1 seq_cst, align 4
  %151 = icmp eq i32 %150, 1
  br i1 %151, label %149, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i115, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i115: ; preds = %149
  %152 = load ptr, ptr %142, align 8
  %153 = ptrtoint ptr %152 to i64
  %154 = getelementptr inbounds %struct.LLVMRuntime, ptr %141, i64 0, i32 1, i32 1
  %155 = load ptr, ptr %154, align 8
  %156 = ptrtoint ptr %155 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i113 = sub i64 0, %153
  %157 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i113, 4095
  %158 = or i64 %157, 4096
  %159 = add i64 %158, %153
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i114 = icmp ugt i64 %159, %156
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i114, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i117, label %160

160:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i115
  %161 = add i64 %157, %153
  %162 = inttoptr i64 %161 to ptr
  %163 = getelementptr i8, ptr %152, i64 %157
  %164 = getelementptr inbounds i8, ptr %163, i64 4096
  store ptr %164, ptr %142, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i117

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i117: ; preds = %160, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i115
  %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i116 = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i115 ], [ %162, %160 ]
  %165 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i114, true
  %166 = atomicrmw volatile xchg ptr %148, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %141, i1 noundef zeroext %165, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i119

167:                                              ; preds = %139
  %168 = getelementptr inbounds %struct.LLVMRuntime, ptr %141, i64 0, i32 2
  %169 = load ptr, ptr %168, align 8
  %170 = getelementptr inbounds %struct.LLVMRuntime, ptr %141, i64 0, i32 6
  %171 = load ptr, ptr %170, align 8
  %172 = tail call noundef ptr %169(ptr noundef %171, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i119

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i119: ; preds = %167, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i117
  %.0.i17.i.i.i.i.i.i.i.i.i.i.i118 = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i116, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i117 ], [ %172, %167 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i.i.i118, i8 0, i64 4096, i1 false)
  %173 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i.i.i118 to i64
  store atomic i64 %173, ptr %127 release, align 8
  br label %174

174:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i119, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i111
  %.0.i.i.i.i.i.i.i.i.i.i.i120 = phi ptr [ %138, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i111 ], [ %.0.i17.i.i.i.i.i.i.i.i.i.i.i118, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i119 ]
  %175 = and i32 %119, 511
  %176 = zext i32 %175 to i64
  %177 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i.i.i120, i64 %176
  %178 = load atomic i64, ptr %177 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i.i.i121 = icmp eq i64 %178, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i.i.i121, label %179, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i130"

179:                                              ; preds = %174
  %180 = getelementptr inbounds %struct.ListManager, ptr %114, i64 0, i32 6
  %181 = load ptr, ptr %180, align 8
  %182 = getelementptr inbounds %struct.LLVMRuntime, ptr %181, i64 0, i32 1
  %183 = getelementptr inbounds %struct.ListManager, ptr %114, i64 0, i32 2
  %184 = load i64, ptr %183, align 8
  %185 = getelementptr inbounds %struct.ListManager, ptr %114, i64 0, i32 1
  %186 = load i64, ptr %185, align 8
  %187 = mul i64 %186, %184
  %188 = getelementptr inbounds %struct.LLVMRuntime, ptr %181, i64 0, i32 28
  %189 = atomicrmw volatile add ptr %188, i64 %187 seq_cst, align 8
  %190 = getelementptr inbounds %struct.LLVMRuntime, ptr %181, i64 0, i32 1, i32 2
  %191 = load i64, ptr %190, align 8
  %.not.i.i.i.i.i.i.i.i.i.i.i.i122 = icmp eq i64 %191, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i122, label %211, label %192

192:                                              ; preds = %179
  %193 = getelementptr inbounds %struct.LLVMRuntime, ptr %181, i64 0, i32 26
  br label %194

194:                                              ; preds = %194, %192
  %195 = atomicrmw volatile xchg ptr %193, i32 1 seq_cst, align 4
  %196 = icmp eq i32 %195, 1
  br i1 %196, label %194, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i125, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i125: ; preds = %194
  %197 = load ptr, ptr %182, align 8
  %198 = ptrtoint ptr %197 to i64
  %199 = getelementptr inbounds %struct.LLVMRuntime, ptr %181, i64 0, i32 1, i32 1
  %200 = load ptr, ptr %199, align 8
  %201 = ptrtoint ptr %200 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i123 = sub i64 0, %198
  %202 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i123, 4095
  %203 = add i64 %202, %187
  %204 = add i64 %203, %198
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i124 = icmp ugt i64 %204, %201
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i124, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i127, label %205

205:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i125
  %206 = add i64 %202, %198
  %207 = inttoptr i64 %206 to ptr
  %208 = getelementptr inbounds i8, ptr %197, i64 %203
  store ptr %208, ptr %182, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i127

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i127: ; preds = %205, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i125
  %.0.i.i.i.i.i.i.i.i.i.i.i.i.i126 = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i125 ], [ %207, %205 ]
  %209 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i124, true
  %210 = atomicrmw volatile xchg ptr %193, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %181, i1 noundef zeroext %209, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i129

211:                                              ; preds = %179
  %212 = getelementptr inbounds %struct.LLVMRuntime, ptr %181, i64 0, i32 2
  %213 = load ptr, ptr %212, align 8
  %214 = getelementptr inbounds %struct.LLVMRuntime, ptr %181, i64 0, i32 6
  %215 = load ptr, ptr %214, align 8
  %216 = tail call noundef ptr %213(ptr noundef %215, i64 noundef %187, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i129

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i129: ; preds = %211, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i127
  %.0.i.i.i.i.i.i.i.i.i.i.i.i128 = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i.i.i126, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i127 ], [ %216, %211 ]
  %217 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i.i.i128 to i64
  store atomic i64 %217, ptr %177 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i130"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i130": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i129, %174
  %218 = atomicrmw volatile xchg ptr %133, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i136

_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i133:   ; preds = %100
  %219 = getelementptr inbounds %struct.ListManager, ptr %109, i64 0, i32 3
  %220 = load i32, ptr %219, align 8
  %221 = ashr i32 %107, %220
  %222 = sext i32 %221 to i64
  %223 = lshr i64 %222, 9
  %224 = getelementptr inbounds [256 x ptr], ptr %109, i64 0, i64 %223
  %225 = load atomic i64, ptr %224 acquire, align 8
  %.not.i.i.i.i.i.i.i.i131 = icmp ne i64 %225, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i.i.i.i.i131)
  %226 = inttoptr i64 %225 to ptr
  %227 = and i64 %222, 511
  %228 = getelementptr inbounds ptr, ptr %226, i64 %227
  %229 = load atomic i64, ptr %228 acquire, align 8
  %230 = inttoptr i64 %229 to ptr
  %231 = getelementptr inbounds %struct.ListManager, ptr %109, i64 0, i32 1
  %232 = load i64, ptr %231, align 8
  %233 = load i32, ptr %219, align 8
  %notmask.i.i.i.i.i.i.i132 = shl nsw i32 -1, %233
  %234 = xor i32 %notmask.i.i.i.i.i.i.i132, -1
  %235 = and i32 %107, %234
  %236 = sext i32 %235 to i64
  %237 = mul i64 %232, %236
  %238 = getelementptr inbounds i8, ptr %230, i64 %237
  %239 = load i32, ptr %238, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i136

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i136: ; preds = %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i133, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i130", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i108, %121
  %.0.i.i.i.i.i134 = phi i32 [ %239, %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i133 ], [ %116, %121 ], [ %116, %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i108 ], [ %116, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i130" ]
  %240 = getelementptr inbounds %struct.NodeManager, ptr %105, i64 0, i32 7
  %241 = load ptr, ptr %240, align 8
  %242 = getelementptr inbounds %struct.ListManager, ptr %241, i64 0, i32 3
  %243 = load i32, ptr %242, align 8
  %244 = ashr i32 %.0.i.i.i.i.i134, %243
  %245 = sext i32 %244 to i64
  %246 = lshr i64 %245, 9
  %247 = getelementptr inbounds [256 x ptr], ptr %241, i64 0, i64 %246
  %248 = load atomic i64, ptr %247 acquire, align 8
  %.not.i.i.i.i.i.i.i135 = icmp eq i64 %248, 0
  br i1 %.not.i.i.i.i.i.i.i135, label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i138", label %249

249:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i136
  %250 = inttoptr i64 %248 to ptr
  %251 = and i64 %245, 511
  %252 = getelementptr inbounds ptr, ptr %250, i64 %251
  %253 = load atomic i64, ptr %252 acquire, align 8
  %254 = inttoptr i64 %253 to ptr
  br label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i138"

"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i138": ; preds = %249, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i136
  %255 = phi ptr [ %254, %249 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i136 ]
  %256 = getelementptr inbounds %struct.ListManager, ptr %241, i64 0, i32 1
  %257 = load i64, ptr %256, align 8
  %258 = load i32, ptr %242, align 8
  %notmask.i.i.i.i.i.i137 = shl nsw i32 -1, %258
  %259 = xor i32 %notmask.i.i.i.i.i.i137, -1
  %260 = and i32 %.0.i.i.i.i.i134, %259
  %261 = sext i32 %260 to i64
  %262 = mul i64 %257, %261
  %263 = getelementptr inbounds i8, ptr %255, i64 %262
  %264 = ptrtoint ptr %263 to i64
  %265 = atomicrmw volatile xchg ptr %91, i64 %264 seq_cst, align 8
  br label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i139"

"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i139": ; preds = %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i138", %mutex_lock_i32.exit.i.i.i104
  %266 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i103, i32 0 seq_cst, align 4
  br label %Pointer_activate.exit140

Pointer_activate.exit140:                         ; preds = %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i139", %true_block10
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %3)
  %267 = and i32 %87, 1073741816
  %268 = zext i32 %267 to i64
  %269 = getelementptr i8, ptr %86, i64 %268
  %270 = getelementptr inbounds i8, ptr %269, i64 32
  %271 = load ptr, ptr %270, align 8
  %272 = icmp eq ptr %271, null
  br i1 %272, label %273, label %Pointer_lookup_element.exit101

273:                                              ; preds = %Pointer_activate.exit140
  %274 = load ptr, ptr %24, align 8
  %275 = getelementptr inbounds %struct.LLVMRuntime, ptr %274, i64 0, i32 15
  %276 = load ptr, ptr %275, align 8
  %277 = getelementptr inbounds ptr, ptr %276, i64 24
  %278 = load ptr, ptr %277, align 8
  br label %Pointer_lookup_element.exit101

Pointer_lookup_element.exit101:                   ; preds = %273, %Pointer_activate.exit140
  %.0.i100 = phi ptr [ %278, %273 ], [ %271, %Pointer_activate.exit140 ]
  %279 = and i32 %69, 31
  %280 = getelementptr inbounds i8, ptr %.0.i100, i64 32
  %281 = shl nuw i32 1, %279
  %282 = atomicrmw volatile or ptr %280, i32 %281 seq_cst, align 4
  br label %after_if9

true_block13:                                     ; preds = %after_if9
  %283 = load ptr, ptr %24, align 8
  %284 = getelementptr inbounds %struct.LLVMRuntime, ptr %283, i64 0, i32 7
  %285 = load ptr, ptr %284, align 8
  %286 = load ptr, ptr %285, align 8
  %287 = getelementptr %0, ptr %286, i64 0, i32 2, i32 1, i64 127
  %288 = lshr i32 %83, 3
  %289 = zext i32 %288 to i64
  %290 = getelementptr inbounds i8, ptr %287, i64 %289
  %291 = load i8, ptr %290, align 1
  %292 = zext i8 %291 to i32
  %293 = and i32 %83, 7
  %294 = shl nuw nsw i32 1, %293
  %295 = and i32 %294, %292
  %.not291 = icmp eq i32 %295, 0
  br i1 %.not291, label %after_if6, label %true_block16

true_block16:                                     ; preds = %true_block13
  %296 = getelementptr inbounds ptr, ptr %285, i64 3
  %297 = load ptr, ptr %296, align 8
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %4)
  %298 = lshr i32 %83, 2
  %299 = and i32 %298, 56
  %300 = zext i32 %299 to i64
  %301 = getelementptr i8, ptr %297, i64 %300
  store volatile ptr %301, ptr %4, align 8
  %302 = getelementptr inbounds i8, ptr %301, i64 32
  %303 = load volatile ptr, ptr %302, align 8
  %304 = icmp eq ptr %303, null
  br i1 %304, label %305, label %Pointer_activate.exit95

305:                                              ; preds = %true_block16
  %.0..0..0..0..0..i57 = load volatile ptr, ptr %4, align 8
  %.0..0..0..0..0.2.i58 = load volatile ptr, ptr %4, align 8
  br label %306

306:                                              ; preds = %306, %305
  %307 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i58, i32 1 seq_cst, align 4
  %308 = icmp eq i32 %307, 1
  br i1 %308, label %306, label %mutex_lock_i32.exit.i.i.i59, !llvm.loop !6

mutex_lock_i32.exit.i.i.i59:                      ; preds = %306
  %309 = load volatile ptr, ptr %302, align 8
  %310 = icmp eq ptr %309, null
  br i1 %310, label %311, label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i94"

311:                                              ; preds = %mutex_lock_i32.exit.i.i.i59
  %312 = load ptr, ptr %24, align 8
  %313 = getelementptr inbounds %struct.LLVMRuntime, ptr %312, i64 0, i32 14
  %314 = load ptr, ptr %313, align 8
  %315 = getelementptr inbounds ptr, ptr %314, i64 24
  %316 = load ptr, ptr %315, align 8
  %317 = getelementptr inbounds %struct.NodeManager, ptr %316, i64 0, i32 4
  %318 = atomicrmw volatile add ptr %317, i32 1 seq_cst, align 4
  %319 = getelementptr inbounds %struct.NodeManager, ptr %316, i64 0, i32 5
  %320 = load ptr, ptr %319, align 8
  %321 = getelementptr inbounds %struct.ListManager, ptr %320, i64 0, i32 5
  %322 = load i32, ptr %321, align 8
  %.not.i.i.i.i.i60 = icmp slt i32 %318, %322
  br i1 %.not.i.i.i.i.i60, label %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i88, label %323

323:                                              ; preds = %311
  %324 = getelementptr inbounds %struct.NodeManager, ptr %316, i64 0, i32 7
  %325 = load ptr, ptr %324, align 8
  %326 = getelementptr inbounds %struct.ListManager, ptr %325, i64 0, i32 5
  %327 = atomicrmw volatile add ptr %326, i32 1 seq_cst, align 4
  %328 = getelementptr inbounds %struct.ListManager, ptr %325, i64 0, i32 3
  %329 = load i32, ptr %328, align 8
  %330 = ashr i32 %327, %329
  %331 = icmp ugt i32 %330, 131071
  br i1 %331, label %332, label %335

332:                                              ; preds = %323
  %333 = getelementptr inbounds %struct.ListManager, ptr %325, i64 0, i32 6
  %334 = load ptr, ptr %333, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %334, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i91

335:                                              ; preds = %323
  %336 = zext i32 %330 to i64
  %337 = lshr i64 %336, 9
  %338 = getelementptr inbounds [256 x ptr], ptr %325, i64 0, i64 %337
  %339 = load atomic i64, ptr %338 acquire, align 8
  %.not.i.i.i4.i.i.i.i.i61 = icmp eq i64 %339, 0
  br i1 %.not.i.i.i4.i.i.i.i.i61, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i64, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i63

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i63: ; preds = %335
  %340 = inttoptr i64 %339 to ptr
  %341 = and i64 %336, 511
  %342 = getelementptr inbounds ptr, ptr %340, i64 %341
  %343 = load atomic i64, ptr %342 acquire, align 8
  %.not.i.i5.i.i.i.i.i62 = icmp eq i64 %343, 0
  br i1 %.not.i.i5.i.i.i.i.i62, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i64, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i91

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i64: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i63, %335
  %344 = getelementptr inbounds %struct.ListManager, ptr %325, i64 0, i32 4
  br label %345

345:                                              ; preds = %345, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i64
  %346 = atomicrmw volatile xchg ptr %344, i32 1 seq_cst, align 4
  %347 = icmp eq i32 %346, 1
  br i1 %347, label %345, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i66, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i66:        ; preds = %345
  %348 = load atomic i64, ptr %338 acquire, align 8
  %349 = inttoptr i64 %348 to ptr
  %.not.i.i.i.i.i.i.i.i.i.i.i65 = icmp eq i64 %348, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i65, label %350, label %385

350:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i66
  %351 = getelementptr inbounds %struct.ListManager, ptr %325, i64 0, i32 6
  %352 = load ptr, ptr %351, align 8
  %353 = getelementptr inbounds %struct.LLVMRuntime, ptr %352, i64 0, i32 1
  %354 = getelementptr inbounds %struct.LLVMRuntime, ptr %352, i64 0, i32 28
  %355 = atomicrmw volatile add ptr %354, i64 4096 seq_cst, align 8
  %356 = getelementptr inbounds %struct.LLVMRuntime, ptr %352, i64 0, i32 1, i32 2
  %357 = load i64, ptr %356, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i.i.i67 = icmp eq i64 %357, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i.i.i67, label %378, label %358

358:                                              ; preds = %350
  %359 = getelementptr inbounds %struct.LLVMRuntime, ptr %352, i64 0, i32 26
  br label %360

360:                                              ; preds = %360, %358
  %361 = atomicrmw volatile xchg ptr %359, i32 1 seq_cst, align 4
  %362 = icmp eq i32 %361, 1
  br i1 %362, label %360, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i70, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i70: ; preds = %360
  %363 = load ptr, ptr %353, align 8
  %364 = ptrtoint ptr %363 to i64
  %365 = getelementptr inbounds %struct.LLVMRuntime, ptr %352, i64 0, i32 1, i32 1
  %366 = load ptr, ptr %365, align 8
  %367 = ptrtoint ptr %366 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i68 = sub i64 0, %364
  %368 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i68, 4095
  %369 = or i64 %368, 4096
  %370 = add i64 %369, %364
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i69 = icmp ugt i64 %370, %367
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i69, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i72, label %371

371:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i70
  %372 = add i64 %368, %364
  %373 = inttoptr i64 %372 to ptr
  %374 = getelementptr i8, ptr %363, i64 %368
  %375 = getelementptr inbounds i8, ptr %374, i64 4096
  store ptr %375, ptr %353, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i72

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i72: ; preds = %371, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i70
  %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i71 = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i70 ], [ %373, %371 ]
  %376 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i69, true
  %377 = atomicrmw volatile xchg ptr %359, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %352, i1 noundef zeroext %376, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i74

378:                                              ; preds = %350
  %379 = getelementptr inbounds %struct.LLVMRuntime, ptr %352, i64 0, i32 2
  %380 = load ptr, ptr %379, align 8
  %381 = getelementptr inbounds %struct.LLVMRuntime, ptr %352, i64 0, i32 6
  %382 = load ptr, ptr %381, align 8
  %383 = tail call noundef ptr %380(ptr noundef %382, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i74

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i74: ; preds = %378, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i72
  %.0.i17.i.i.i.i.i.i.i.i.i.i.i73 = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i71, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i72 ], [ %383, %378 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i.i.i73, i8 0, i64 4096, i1 false)
  %384 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i.i.i73 to i64
  store atomic i64 %384, ptr %338 release, align 8
  br label %385

385:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i74, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i66
  %.0.i.i.i.i.i.i.i.i.i.i.i75 = phi ptr [ %349, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i66 ], [ %.0.i17.i.i.i.i.i.i.i.i.i.i.i73, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i74 ]
  %386 = and i32 %330, 511
  %387 = zext i32 %386 to i64
  %388 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i.i.i75, i64 %387
  %389 = load atomic i64, ptr %388 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i.i.i76 = icmp eq i64 %389, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i.i.i76, label %390, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i85"

390:                                              ; preds = %385
  %391 = getelementptr inbounds %struct.ListManager, ptr %325, i64 0, i32 6
  %392 = load ptr, ptr %391, align 8
  %393 = getelementptr inbounds %struct.LLVMRuntime, ptr %392, i64 0, i32 1
  %394 = getelementptr inbounds %struct.ListManager, ptr %325, i64 0, i32 2
  %395 = load i64, ptr %394, align 8
  %396 = getelementptr inbounds %struct.ListManager, ptr %325, i64 0, i32 1
  %397 = load i64, ptr %396, align 8
  %398 = mul i64 %397, %395
  %399 = getelementptr inbounds %struct.LLVMRuntime, ptr %392, i64 0, i32 28
  %400 = atomicrmw volatile add ptr %399, i64 %398 seq_cst, align 8
  %401 = getelementptr inbounds %struct.LLVMRuntime, ptr %392, i64 0, i32 1, i32 2
  %402 = load i64, ptr %401, align 8
  %.not.i.i.i.i.i.i.i.i.i.i.i.i77 = icmp eq i64 %402, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i77, label %422, label %403

403:                                              ; preds = %390
  %404 = getelementptr inbounds %struct.LLVMRuntime, ptr %392, i64 0, i32 26
  br label %405

405:                                              ; preds = %405, %403
  %406 = atomicrmw volatile xchg ptr %404, i32 1 seq_cst, align 4
  %407 = icmp eq i32 %406, 1
  br i1 %407, label %405, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i80, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i80: ; preds = %405
  %408 = load ptr, ptr %393, align 8
  %409 = ptrtoint ptr %408 to i64
  %410 = getelementptr inbounds %struct.LLVMRuntime, ptr %392, i64 0, i32 1, i32 1
  %411 = load ptr, ptr %410, align 8
  %412 = ptrtoint ptr %411 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i78 = sub i64 0, %409
  %413 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i78, 4095
  %414 = add i64 %413, %398
  %415 = add i64 %414, %409
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i79 = icmp ugt i64 %415, %412
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i79, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i82, label %416

416:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i80
  %417 = add i64 %413, %409
  %418 = inttoptr i64 %417 to ptr
  %419 = getelementptr inbounds i8, ptr %408, i64 %414
  store ptr %419, ptr %393, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i82

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i82: ; preds = %416, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i80
  %.0.i.i.i.i.i.i.i.i.i.i.i.i.i81 = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i80 ], [ %418, %416 ]
  %420 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i79, true
  %421 = atomicrmw volatile xchg ptr %404, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %392, i1 noundef zeroext %420, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i84

422:                                              ; preds = %390
  %423 = getelementptr inbounds %struct.LLVMRuntime, ptr %392, i64 0, i32 2
  %424 = load ptr, ptr %423, align 8
  %425 = getelementptr inbounds %struct.LLVMRuntime, ptr %392, i64 0, i32 6
  %426 = load ptr, ptr %425, align 8
  %427 = tail call noundef ptr %424(ptr noundef %426, i64 noundef %398, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i84

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i84: ; preds = %422, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i82
  %.0.i.i.i.i.i.i.i.i.i.i.i.i83 = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i.i.i81, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i82 ], [ %427, %422 ]
  %428 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i.i.i83 to i64
  store atomic i64 %428, ptr %388 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i85"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i85": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i84, %385
  %429 = atomicrmw volatile xchg ptr %344, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i91

_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i88:    ; preds = %311
  %430 = getelementptr inbounds %struct.ListManager, ptr %320, i64 0, i32 3
  %431 = load i32, ptr %430, align 8
  %432 = ashr i32 %318, %431
  %433 = sext i32 %432 to i64
  %434 = lshr i64 %433, 9
  %435 = getelementptr inbounds [256 x ptr], ptr %320, i64 0, i64 %434
  %436 = load atomic i64, ptr %435 acquire, align 8
  %.not.i.i.i.i.i.i.i.i86 = icmp ne i64 %436, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i.i.i.i.i86)
  %437 = inttoptr i64 %436 to ptr
  %438 = and i64 %433, 511
  %439 = getelementptr inbounds ptr, ptr %437, i64 %438
  %440 = load atomic i64, ptr %439 acquire, align 8
  %441 = inttoptr i64 %440 to ptr
  %442 = getelementptr inbounds %struct.ListManager, ptr %320, i64 0, i32 1
  %443 = load i64, ptr %442, align 8
  %444 = load i32, ptr %430, align 8
  %notmask.i.i.i.i.i.i.i87 = shl nsw i32 -1, %444
  %445 = xor i32 %notmask.i.i.i.i.i.i.i87, -1
  %446 = and i32 %318, %445
  %447 = sext i32 %446 to i64
  %448 = mul i64 %443, %447
  %449 = getelementptr inbounds i8, ptr %441, i64 %448
  %450 = load i32, ptr %449, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i91

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i91: ; preds = %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i88, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i85", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i63, %332
  %.0.i.i.i.i.i89 = phi i32 [ %450, %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i88 ], [ %327, %332 ], [ %327, %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i63 ], [ %327, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i85" ]
  %451 = getelementptr inbounds %struct.NodeManager, ptr %316, i64 0, i32 7
  %452 = load ptr, ptr %451, align 8
  %453 = getelementptr inbounds %struct.ListManager, ptr %452, i64 0, i32 3
  %454 = load i32, ptr %453, align 8
  %455 = ashr i32 %.0.i.i.i.i.i89, %454
  %456 = sext i32 %455 to i64
  %457 = lshr i64 %456, 9
  %458 = getelementptr inbounds [256 x ptr], ptr %452, i64 0, i64 %457
  %459 = load atomic i64, ptr %458 acquire, align 8
  %.not.i.i.i.i.i.i.i90 = icmp eq i64 %459, 0
  br i1 %.not.i.i.i.i.i.i.i90, label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i93", label %460

460:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i91
  %461 = inttoptr i64 %459 to ptr
  %462 = and i64 %456, 511
  %463 = getelementptr inbounds ptr, ptr %461, i64 %462
  %464 = load atomic i64, ptr %463 acquire, align 8
  %465 = inttoptr i64 %464 to ptr
  br label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i93"

"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i93":  ; preds = %460, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i91
  %466 = phi ptr [ %465, %460 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i91 ]
  %467 = getelementptr inbounds %struct.ListManager, ptr %452, i64 0, i32 1
  %468 = load i64, ptr %467, align 8
  %469 = load i32, ptr %453, align 8
  %notmask.i.i.i.i.i.i92 = shl nsw i32 -1, %469
  %470 = xor i32 %notmask.i.i.i.i.i.i92, -1
  %471 = and i32 %.0.i.i.i.i.i89, %470
  %472 = sext i32 %471 to i64
  %473 = mul i64 %468, %472
  %474 = getelementptr inbounds i8, ptr %466, i64 %473
  %475 = ptrtoint ptr %474 to i64
  %476 = atomicrmw volatile xchg ptr %302, i64 %475 seq_cst, align 8
  br label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i94"

"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i94": ; preds = %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i93", %mutex_lock_i32.exit.i.i.i59
  %477 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i58, i32 0 seq_cst, align 4
  br label %Pointer_activate.exit95

Pointer_activate.exit95:                          ; preds = %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i94", %true_block16
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %4)
  %478 = and i32 %298, 1073741816
  %479 = zext i32 %478 to i64
  %480 = getelementptr i8, ptr %297, i64 %479
  %481 = getelementptr inbounds i8, ptr %480, i64 32
  %482 = load ptr, ptr %481, align 8
  %483 = icmp eq ptr %482, null
  br i1 %483, label %484, label %Pointer_lookup_element.exit56

484:                                              ; preds = %Pointer_activate.exit95
  %485 = load ptr, ptr %24, align 8
  %486 = getelementptr inbounds %struct.LLVMRuntime, ptr %485, i64 0, i32 15
  %487 = load ptr, ptr %486, align 8
  %488 = getelementptr inbounds ptr, ptr %487, i64 24
  %489 = load ptr, ptr %488, align 8
  br label %Pointer_lookup_element.exit56

Pointer_lookup_element.exit56:                    ; preds = %484, %Pointer_activate.exit95
  %.0.i55 = phi ptr [ %489, %484 ], [ %482, %Pointer_activate.exit95 ]
  %490 = and i32 %83, 31
  %491 = getelementptr inbounds i8, ptr %.0.i55, i64 32
  %492 = shl nuw i32 1, %490
  %493 = atomicrmw volatile or ptr %491, i32 %492 seq_cst, align 4
  br label %after_if6

true_block19:                                     ; preds = %after_if6
  %494 = load i32, ptr %45, align 4
  %495 = icmp ult i32 %494, 70
  br i1 %495, label %true_block22, label %after_if24

true_block22:                                     ; preds = %true_block19
  %496 = load ptr, ptr %24, align 8
  %497 = getelementptr inbounds %struct.LLVMRuntime, ptr %496, i64 0, i32 7
  %498 = load ptr, ptr %497, align 8
  %499 = load ptr, ptr %498, align 8
  %500 = getelementptr %0, ptr %499, i64 0, i32 2, i32 1, i64 127
  %501 = lshr i32 %494, 3
  %502 = zext i32 %501 to i64
  %503 = getelementptr inbounds i8, ptr %500, i64 %502
  %504 = load i8, ptr %503, align 1
  %505 = zext i8 %504 to i32
  %506 = and i32 %494, 7
  %507 = shl nuw nsw i32 1, %506
  %508 = and i32 %507, %505
  %.not290 = icmp eq i32 %508, 0
  br i1 %.not290, label %after_if24, label %true_block25

after_if24:                                       ; preds = %Pointer_lookup_element.exit12, %true_block22, %true_block19
  %509 = load i32, ptr %53, align 4
  %510 = icmp ult i32 %509, 70
  br i1 %510, label %true_block28, label %after_if

true_block25:                                     ; preds = %true_block22
  %511 = getelementptr inbounds ptr, ptr %498, i64 3
  %512 = load ptr, ptr %511, align 8
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %5)
  %513 = lshr i32 %494, 2
  %514 = and i32 %513, 56
  %515 = zext i32 %514 to i64
  %516 = getelementptr i8, ptr %512, i64 %515
  store volatile ptr %516, ptr %5, align 8
  %517 = getelementptr inbounds i8, ptr %516, i64 32
  %518 = load volatile ptr, ptr %517, align 8
  %519 = icmp eq ptr %518, null
  br i1 %519, label %520, label %Pointer_activate.exit51

520:                                              ; preds = %true_block25
  %.0..0..0..0..0..i13 = load volatile ptr, ptr %5, align 8
  %.0..0..0..0..0.2.i14 = load volatile ptr, ptr %5, align 8
  br label %521

521:                                              ; preds = %521, %520
  %522 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i14, i32 1 seq_cst, align 4
  %523 = icmp eq i32 %522, 1
  br i1 %523, label %521, label %mutex_lock_i32.exit.i.i.i15, !llvm.loop !6

mutex_lock_i32.exit.i.i.i15:                      ; preds = %521
  %524 = load volatile ptr, ptr %517, align 8
  %525 = icmp eq ptr %524, null
  br i1 %525, label %526, label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i50"

526:                                              ; preds = %mutex_lock_i32.exit.i.i.i15
  %527 = load ptr, ptr %24, align 8
  %528 = getelementptr inbounds %struct.LLVMRuntime, ptr %527, i64 0, i32 14
  %529 = load ptr, ptr %528, align 8
  %530 = getelementptr inbounds ptr, ptr %529, i64 24
  %531 = load ptr, ptr %530, align 8
  %532 = getelementptr inbounds %struct.NodeManager, ptr %531, i64 0, i32 4
  %533 = atomicrmw volatile add ptr %532, i32 1 seq_cst, align 4
  %534 = getelementptr inbounds %struct.NodeManager, ptr %531, i64 0, i32 5
  %535 = load ptr, ptr %534, align 8
  %536 = getelementptr inbounds %struct.ListManager, ptr %535, i64 0, i32 5
  %537 = load i32, ptr %536, align 8
  %.not.i.i.i.i.i16 = icmp slt i32 %533, %537
  br i1 %.not.i.i.i.i.i16, label %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i44, label %538

538:                                              ; preds = %526
  %539 = getelementptr inbounds %struct.NodeManager, ptr %531, i64 0, i32 7
  %540 = load ptr, ptr %539, align 8
  %541 = getelementptr inbounds %struct.ListManager, ptr %540, i64 0, i32 5
  %542 = atomicrmw volatile add ptr %541, i32 1 seq_cst, align 4
  %543 = getelementptr inbounds %struct.ListManager, ptr %540, i64 0, i32 3
  %544 = load i32, ptr %543, align 8
  %545 = ashr i32 %542, %544
  %546 = icmp ugt i32 %545, 131071
  br i1 %546, label %547, label %550

547:                                              ; preds = %538
  %548 = getelementptr inbounds %struct.ListManager, ptr %540, i64 0, i32 6
  %549 = load ptr, ptr %548, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %549, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i47

550:                                              ; preds = %538
  %551 = zext i32 %545 to i64
  %552 = lshr i64 %551, 9
  %553 = getelementptr inbounds [256 x ptr], ptr %540, i64 0, i64 %552
  %554 = load atomic i64, ptr %553 acquire, align 8
  %.not.i.i.i4.i.i.i.i.i17 = icmp eq i64 %554, 0
  br i1 %.not.i.i.i4.i.i.i.i.i17, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i20, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i19

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i19: ; preds = %550
  %555 = inttoptr i64 %554 to ptr
  %556 = and i64 %551, 511
  %557 = getelementptr inbounds ptr, ptr %555, i64 %556
  %558 = load atomic i64, ptr %557 acquire, align 8
  %.not.i.i5.i.i.i.i.i18 = icmp eq i64 %558, 0
  br i1 %.not.i.i5.i.i.i.i.i18, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i20, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i47

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i20: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i19, %550
  %559 = getelementptr inbounds %struct.ListManager, ptr %540, i64 0, i32 4
  br label %560

560:                                              ; preds = %560, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i20
  %561 = atomicrmw volatile xchg ptr %559, i32 1 seq_cst, align 4
  %562 = icmp eq i32 %561, 1
  br i1 %562, label %560, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i22, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i22:        ; preds = %560
  %563 = load atomic i64, ptr %553 acquire, align 8
  %564 = inttoptr i64 %563 to ptr
  %.not.i.i.i.i.i.i.i.i.i.i.i21 = icmp eq i64 %563, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i21, label %565, label %600

565:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i22
  %566 = getelementptr inbounds %struct.ListManager, ptr %540, i64 0, i32 6
  %567 = load ptr, ptr %566, align 8
  %568 = getelementptr inbounds %struct.LLVMRuntime, ptr %567, i64 0, i32 1
  %569 = getelementptr inbounds %struct.LLVMRuntime, ptr %567, i64 0, i32 28
  %570 = atomicrmw volatile add ptr %569, i64 4096 seq_cst, align 8
  %571 = getelementptr inbounds %struct.LLVMRuntime, ptr %567, i64 0, i32 1, i32 2
  %572 = load i64, ptr %571, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i.i.i23 = icmp eq i64 %572, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i.i.i23, label %593, label %573

573:                                              ; preds = %565
  %574 = getelementptr inbounds %struct.LLVMRuntime, ptr %567, i64 0, i32 26
  br label %575

575:                                              ; preds = %575, %573
  %576 = atomicrmw volatile xchg ptr %574, i32 1 seq_cst, align 4
  %577 = icmp eq i32 %576, 1
  br i1 %577, label %575, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i26, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i26: ; preds = %575
  %578 = load ptr, ptr %568, align 8
  %579 = ptrtoint ptr %578 to i64
  %580 = getelementptr inbounds %struct.LLVMRuntime, ptr %567, i64 0, i32 1, i32 1
  %581 = load ptr, ptr %580, align 8
  %582 = ptrtoint ptr %581 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i24 = sub i64 0, %579
  %583 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i24, 4095
  %584 = or i64 %583, 4096
  %585 = add i64 %584, %579
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i25 = icmp ugt i64 %585, %582
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i25, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i28, label %586

586:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i26
  %587 = add i64 %583, %579
  %588 = inttoptr i64 %587 to ptr
  %589 = getelementptr i8, ptr %578, i64 %583
  %590 = getelementptr inbounds i8, ptr %589, i64 4096
  store ptr %590, ptr %568, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i28

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i28: ; preds = %586, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i26
  %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i27 = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i26 ], [ %588, %586 ]
  %591 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i25, true
  %592 = atomicrmw volatile xchg ptr %574, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %567, i1 noundef zeroext %591, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i30

593:                                              ; preds = %565
  %594 = getelementptr inbounds %struct.LLVMRuntime, ptr %567, i64 0, i32 2
  %595 = load ptr, ptr %594, align 8
  %596 = getelementptr inbounds %struct.LLVMRuntime, ptr %567, i64 0, i32 6
  %597 = load ptr, ptr %596, align 8
  %598 = tail call noundef ptr %595(ptr noundef %597, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i30

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i30: ; preds = %593, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i28
  %.0.i17.i.i.i.i.i.i.i.i.i.i.i29 = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i27, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i28 ], [ %598, %593 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i.i.i29, i8 0, i64 4096, i1 false)
  %599 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i.i.i29 to i64
  store atomic i64 %599, ptr %553 release, align 8
  br label %600

600:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i30, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i22
  %.0.i.i.i.i.i.i.i.i.i.i.i31 = phi ptr [ %564, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i22 ], [ %.0.i17.i.i.i.i.i.i.i.i.i.i.i29, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i30 ]
  %601 = and i32 %545, 511
  %602 = zext i32 %601 to i64
  %603 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i.i.i31, i64 %602
  %604 = load atomic i64, ptr %603 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i.i.i32 = icmp eq i64 %604, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i.i.i32, label %605, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i41"

605:                                              ; preds = %600
  %606 = getelementptr inbounds %struct.ListManager, ptr %540, i64 0, i32 6
  %607 = load ptr, ptr %606, align 8
  %608 = getelementptr inbounds %struct.LLVMRuntime, ptr %607, i64 0, i32 1
  %609 = getelementptr inbounds %struct.ListManager, ptr %540, i64 0, i32 2
  %610 = load i64, ptr %609, align 8
  %611 = getelementptr inbounds %struct.ListManager, ptr %540, i64 0, i32 1
  %612 = load i64, ptr %611, align 8
  %613 = mul i64 %612, %610
  %614 = getelementptr inbounds %struct.LLVMRuntime, ptr %607, i64 0, i32 28
  %615 = atomicrmw volatile add ptr %614, i64 %613 seq_cst, align 8
  %616 = getelementptr inbounds %struct.LLVMRuntime, ptr %607, i64 0, i32 1, i32 2
  %617 = load i64, ptr %616, align 8
  %.not.i.i.i.i.i.i.i.i.i.i.i.i33 = icmp eq i64 %617, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i33, label %637, label %618

618:                                              ; preds = %605
  %619 = getelementptr inbounds %struct.LLVMRuntime, ptr %607, i64 0, i32 26
  br label %620

620:                                              ; preds = %620, %618
  %621 = atomicrmw volatile xchg ptr %619, i32 1 seq_cst, align 4
  %622 = icmp eq i32 %621, 1
  br i1 %622, label %620, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i36, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i36: ; preds = %620
  %623 = load ptr, ptr %608, align 8
  %624 = ptrtoint ptr %623 to i64
  %625 = getelementptr inbounds %struct.LLVMRuntime, ptr %607, i64 0, i32 1, i32 1
  %626 = load ptr, ptr %625, align 8
  %627 = ptrtoint ptr %626 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i34 = sub i64 0, %624
  %628 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i34, 4095
  %629 = add i64 %628, %613
  %630 = add i64 %629, %624
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i35 = icmp ugt i64 %630, %627
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i35, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i38, label %631

631:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i36
  %632 = add i64 %628, %624
  %633 = inttoptr i64 %632 to ptr
  %634 = getelementptr inbounds i8, ptr %623, i64 %629
  store ptr %634, ptr %608, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i38

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i38: ; preds = %631, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i36
  %.0.i.i.i.i.i.i.i.i.i.i.i.i.i37 = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i36 ], [ %633, %631 ]
  %635 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i35, true
  %636 = atomicrmw volatile xchg ptr %619, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %607, i1 noundef zeroext %635, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i40

637:                                              ; preds = %605
  %638 = getelementptr inbounds %struct.LLVMRuntime, ptr %607, i64 0, i32 2
  %639 = load ptr, ptr %638, align 8
  %640 = getelementptr inbounds %struct.LLVMRuntime, ptr %607, i64 0, i32 6
  %641 = load ptr, ptr %640, align 8
  %642 = tail call noundef ptr %639(ptr noundef %641, i64 noundef %613, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i40

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i40: ; preds = %637, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i38
  %.0.i.i.i.i.i.i.i.i.i.i.i.i39 = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i.i.i37, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i38 ], [ %642, %637 ]
  %643 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i.i.i39 to i64
  store atomic i64 %643, ptr %603 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i41"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i41": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i40, %600
  %644 = atomicrmw volatile xchg ptr %559, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i47

_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i44:    ; preds = %526
  %645 = getelementptr inbounds %struct.ListManager, ptr %535, i64 0, i32 3
  %646 = load i32, ptr %645, align 8
  %647 = ashr i32 %533, %646
  %648 = sext i32 %647 to i64
  %649 = lshr i64 %648, 9
  %650 = getelementptr inbounds [256 x ptr], ptr %535, i64 0, i64 %649
  %651 = load atomic i64, ptr %650 acquire, align 8
  %.not.i.i.i.i.i.i.i.i42 = icmp ne i64 %651, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i.i.i.i.i42)
  %652 = inttoptr i64 %651 to ptr
  %653 = and i64 %648, 511
  %654 = getelementptr inbounds ptr, ptr %652, i64 %653
  %655 = load atomic i64, ptr %654 acquire, align 8
  %656 = inttoptr i64 %655 to ptr
  %657 = getelementptr inbounds %struct.ListManager, ptr %535, i64 0, i32 1
  %658 = load i64, ptr %657, align 8
  %659 = load i32, ptr %645, align 8
  %notmask.i.i.i.i.i.i.i43 = shl nsw i32 -1, %659
  %660 = xor i32 %notmask.i.i.i.i.i.i.i43, -1
  %661 = and i32 %533, %660
  %662 = sext i32 %661 to i64
  %663 = mul i64 %658, %662
  %664 = getelementptr inbounds i8, ptr %656, i64 %663
  %665 = load i32, ptr %664, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i47

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i47: ; preds = %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i44, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i41", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i19, %547
  %.0.i.i.i.i.i45 = phi i32 [ %665, %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i44 ], [ %542, %547 ], [ %542, %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i19 ], [ %542, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i41" ]
  %666 = getelementptr inbounds %struct.NodeManager, ptr %531, i64 0, i32 7
  %667 = load ptr, ptr %666, align 8
  %668 = getelementptr inbounds %struct.ListManager, ptr %667, i64 0, i32 3
  %669 = load i32, ptr %668, align 8
  %670 = ashr i32 %.0.i.i.i.i.i45, %669
  %671 = sext i32 %670 to i64
  %672 = lshr i64 %671, 9
  %673 = getelementptr inbounds [256 x ptr], ptr %667, i64 0, i64 %672
  %674 = load atomic i64, ptr %673 acquire, align 8
  %.not.i.i.i.i.i.i.i46 = icmp eq i64 %674, 0
  br i1 %.not.i.i.i.i.i.i.i46, label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i49", label %675

675:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i47
  %676 = inttoptr i64 %674 to ptr
  %677 = and i64 %671, 511
  %678 = getelementptr inbounds ptr, ptr %676, i64 %677
  %679 = load atomic i64, ptr %678 acquire, align 8
  %680 = inttoptr i64 %679 to ptr
  br label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i49"

"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i49":  ; preds = %675, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i47
  %681 = phi ptr [ %680, %675 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i47 ]
  %682 = getelementptr inbounds %struct.ListManager, ptr %667, i64 0, i32 1
  %683 = load i64, ptr %682, align 8
  %684 = load i32, ptr %668, align 8
  %notmask.i.i.i.i.i.i48 = shl nsw i32 -1, %684
  %685 = xor i32 %notmask.i.i.i.i.i.i48, -1
  %686 = and i32 %.0.i.i.i.i.i45, %685
  %687 = sext i32 %686 to i64
  %688 = mul i64 %683, %687
  %689 = getelementptr inbounds i8, ptr %681, i64 %688
  %690 = ptrtoint ptr %689 to i64
  %691 = atomicrmw volatile xchg ptr %517, i64 %690 seq_cst, align 8
  br label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i50"

"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i50": ; preds = %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i49", %mutex_lock_i32.exit.i.i.i15
  %692 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i14, i32 0 seq_cst, align 4
  br label %Pointer_activate.exit51

Pointer_activate.exit51:                          ; preds = %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i50", %true_block25
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5)
  %693 = and i32 %513, 1073741816
  %694 = zext i32 %693 to i64
  %695 = getelementptr i8, ptr %512, i64 %694
  %696 = getelementptr inbounds i8, ptr %695, i64 32
  %697 = load ptr, ptr %696, align 8
  %698 = icmp eq ptr %697, null
  br i1 %698, label %699, label %Pointer_lookup_element.exit12

699:                                              ; preds = %Pointer_activate.exit51
  %700 = load ptr, ptr %24, align 8
  %701 = getelementptr inbounds %struct.LLVMRuntime, ptr %700, i64 0, i32 15
  %702 = load ptr, ptr %701, align 8
  %703 = getelementptr inbounds ptr, ptr %702, i64 24
  %704 = load ptr, ptr %703, align 8
  br label %Pointer_lookup_element.exit12

Pointer_lookup_element.exit12:                    ; preds = %699, %Pointer_activate.exit51
  %.0.i11 = phi ptr [ %704, %699 ], [ %697, %Pointer_activate.exit51 ]
  %705 = and i32 %494, 31
  %706 = getelementptr inbounds i8, ptr %.0.i11, i64 32
  %707 = shl nuw i32 1, %705
  %708 = atomicrmw volatile or ptr %706, i32 %707 seq_cst, align 4
  br label %after_if24

true_block28:                                     ; preds = %after_if24
  %709 = load ptr, ptr %24, align 8
  %710 = getelementptr inbounds %struct.LLVMRuntime, ptr %709, i64 0, i32 7
  %711 = load ptr, ptr %710, align 8
  %712 = load ptr, ptr %711, align 8
  %713 = getelementptr %0, ptr %712, i64 0, i32 2, i32 1, i64 127
  %714 = lshr i32 %509, 3
  %715 = zext i32 %714 to i64
  %716 = getelementptr inbounds i8, ptr %713, i64 %715
  %717 = load i8, ptr %716, align 1
  %718 = zext i8 %717 to i32
  %719 = and i32 %509, 7
  %720 = shl nuw nsw i32 1, %719
  %721 = and i32 %720, %718
  %.not289 = icmp eq i32 %721, 0
  br i1 %.not289, label %after_if, label %true_block31

true_block31:                                     ; preds = %true_block28
  %722 = getelementptr inbounds ptr, ptr %711, i64 3
  %723 = load ptr, ptr %722, align 8
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %6)
  %724 = lshr i32 %509, 2
  %725 = and i32 %724, 56
  %726 = zext i32 %725 to i64
  %727 = getelementptr i8, ptr %723, i64 %726
  store volatile ptr %727, ptr %6, align 8
  %728 = getelementptr inbounds i8, ptr %727, i64 32
  %729 = load volatile ptr, ptr %728, align 8
  %730 = icmp eq ptr %729, null
  br i1 %730, label %731, label %Pointer_activate.exit

731:                                              ; preds = %true_block31
  %.0..0..0..0..0..i = load volatile ptr, ptr %6, align 8
  %.0..0..0..0..0.2.i = load volatile ptr, ptr %6, align 8
  br label %732

732:                                              ; preds = %732, %731
  %733 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i, i32 1 seq_cst, align 4
  %734 = icmp eq i32 %733, 1
  br i1 %734, label %732, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i:                        ; preds = %732
  %735 = load volatile ptr, ptr %728, align 8
  %736 = icmp eq ptr %735, null
  br i1 %736, label %737, label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i"

737:                                              ; preds = %mutex_lock_i32.exit.i.i.i
  %738 = load ptr, ptr %24, align 8
  %739 = getelementptr inbounds %struct.LLVMRuntime, ptr %738, i64 0, i32 14
  %740 = load ptr, ptr %739, align 8
  %741 = getelementptr inbounds ptr, ptr %740, i64 24
  %742 = load ptr, ptr %741, align 8
  %743 = getelementptr inbounds %struct.NodeManager, ptr %742, i64 0, i32 4
  %744 = atomicrmw volatile add ptr %743, i32 1 seq_cst, align 4
  %745 = getelementptr inbounds %struct.NodeManager, ptr %742, i64 0, i32 5
  %746 = load ptr, ptr %745, align 8
  %747 = getelementptr inbounds %struct.ListManager, ptr %746, i64 0, i32 5
  %748 = load i32, ptr %747, align 8
  %.not.i.i.i.i.i = icmp slt i32 %744, %748
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i, label %749

749:                                              ; preds = %737
  %750 = getelementptr inbounds %struct.NodeManager, ptr %742, i64 0, i32 7
  %751 = load ptr, ptr %750, align 8
  %752 = getelementptr inbounds %struct.ListManager, ptr %751, i64 0, i32 5
  %753 = atomicrmw volatile add ptr %752, i32 1 seq_cst, align 4
  %754 = getelementptr inbounds %struct.ListManager, ptr %751, i64 0, i32 3
  %755 = load i32, ptr %754, align 8
  %756 = ashr i32 %753, %755
  %757 = icmp ugt i32 %756, 131071
  br i1 %757, label %758, label %761

758:                                              ; preds = %749
  %759 = getelementptr inbounds %struct.ListManager, ptr %751, i64 0, i32 6
  %760 = load ptr, ptr %759, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %760, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

761:                                              ; preds = %749
  %762 = zext i32 %756 to i64
  %763 = lshr i64 %762, 9
  %764 = getelementptr inbounds [256 x ptr], ptr %751, i64 0, i64 %763
  %765 = load atomic i64, ptr %764 acquire, align 8
  %.not.i.i.i4.i.i.i.i.i = icmp eq i64 %765, 0
  br i1 %.not.i.i.i4.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i:  ; preds = %761
  %766 = inttoptr i64 %765 to ptr
  %767 = and i64 %762, 511
  %768 = getelementptr inbounds ptr, ptr %766, i64 %767
  %769 = load atomic i64, ptr %768 acquire, align 8
  %.not.i.i5.i.i.i.i.i = icmp eq i64 %769, 0
  br i1 %.not.i.i5.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i, %761
  %770 = getelementptr inbounds %struct.ListManager, ptr %751, i64 0, i32 4
  br label %771

771:                                              ; preds = %771, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i
  %772 = atomicrmw volatile xchg ptr %770, i32 1 seq_cst, align 4
  %773 = icmp eq i32 %772, 1
  br i1 %773, label %771, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i:          ; preds = %771
  %774 = load atomic i64, ptr %764 acquire, align 8
  %775 = inttoptr i64 %774 to ptr
  %.not.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %774, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i, label %776, label %811

776:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i
  %777 = getelementptr inbounds %struct.ListManager, ptr %751, i64 0, i32 6
  %778 = load ptr, ptr %777, align 8
  %779 = getelementptr inbounds %struct.LLVMRuntime, ptr %778, i64 0, i32 1
  %780 = getelementptr inbounds %struct.LLVMRuntime, ptr %778, i64 0, i32 28
  %781 = atomicrmw volatile add ptr %780, i64 4096 seq_cst, align 8
  %782 = getelementptr inbounds %struct.LLVMRuntime, ptr %778, i64 0, i32 1, i32 2
  %783 = load i64, ptr %782, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %783, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i.i.i, label %804, label %784

784:                                              ; preds = %776
  %785 = getelementptr inbounds %struct.LLVMRuntime, ptr %778, i64 0, i32 26
  br label %786

786:                                              ; preds = %786, %784
  %787 = atomicrmw volatile xchg ptr %785, i32 1 seq_cst, align 4
  %788 = icmp eq i32 %787, 1
  br i1 %788, label %786, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i: ; preds = %786
  %789 = load ptr, ptr %779, align 8
  %790 = ptrtoint ptr %789 to i64
  %791 = getelementptr inbounds %struct.LLVMRuntime, ptr %778, i64 0, i32 1, i32 1
  %792 = load ptr, ptr %791, align 8
  %793 = ptrtoint ptr %792 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %790
  %794 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i, 4095
  %795 = or i64 %794, 4096
  %796 = add i64 %795, %790
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %796, %793
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i, label %797

797:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i
  %798 = add i64 %794, %790
  %799 = inttoptr i64 %798 to ptr
  %800 = getelementptr i8, ptr %789, i64 %794
  %801 = getelementptr inbounds i8, ptr %800, i64 4096
  store ptr %801, ptr %779, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i: ; preds = %797, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i ], [ %799, %797 ]
  %802 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i, true
  %803 = atomicrmw volatile xchg ptr %785, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %778, i1 noundef zeroext %802, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i

804:                                              ; preds = %776
  %805 = getelementptr inbounds %struct.LLVMRuntime, ptr %778, i64 0, i32 2
  %806 = load ptr, ptr %805, align 8
  %807 = getelementptr inbounds %struct.LLVMRuntime, ptr %778, i64 0, i32 6
  %808 = load ptr, ptr %807, align 8
  %809 = tail call noundef ptr %806(ptr noundef %808, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i: ; preds = %804, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i ], [ %809, %804 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %810 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %810, ptr %764 release, align 8
  br label %811

811:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %775, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i ]
  %812 = and i32 %756, 511
  %813 = zext i32 %812 to i64
  %814 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i.i.i, i64 %813
  %815 = load atomic i64, ptr %814 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %815, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i.i.i, label %816, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i"

816:                                              ; preds = %811
  %817 = getelementptr inbounds %struct.ListManager, ptr %751, i64 0, i32 6
  %818 = load ptr, ptr %817, align 8
  %819 = getelementptr inbounds %struct.LLVMRuntime, ptr %818, i64 0, i32 1
  %820 = getelementptr inbounds %struct.ListManager, ptr %751, i64 0, i32 2
  %821 = load i64, ptr %820, align 8
  %822 = getelementptr inbounds %struct.ListManager, ptr %751, i64 0, i32 1
  %823 = load i64, ptr %822, align 8
  %824 = mul i64 %823, %821
  %825 = getelementptr inbounds %struct.LLVMRuntime, ptr %818, i64 0, i32 28
  %826 = atomicrmw volatile add ptr %825, i64 %824 seq_cst, align 8
  %827 = getelementptr inbounds %struct.LLVMRuntime, ptr %818, i64 0, i32 1, i32 2
  %828 = load i64, ptr %827, align 8
  %.not.i.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %828, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i, label %848, label %829

829:                                              ; preds = %816
  %830 = getelementptr inbounds %struct.LLVMRuntime, ptr %818, i64 0, i32 26
  br label %831

831:                                              ; preds = %831, %829
  %832 = atomicrmw volatile xchg ptr %830, i32 1 seq_cst, align 4
  %833 = icmp eq i32 %832, 1
  br i1 %833, label %831, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i: ; preds = %831
  %834 = load ptr, ptr %819, align 8
  %835 = ptrtoint ptr %834 to i64
  %836 = getelementptr inbounds %struct.LLVMRuntime, ptr %818, i64 0, i32 1, i32 1
  %837 = load ptr, ptr %836, align 8
  %838 = ptrtoint ptr %837 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %835
  %839 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i, 4095
  %840 = add i64 %839, %824
  %841 = add i64 %840, %835
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %841, %838
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i, label %842

842:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %843 = add i64 %839, %835
  %844 = inttoptr i64 %843 to ptr
  %845 = getelementptr inbounds i8, ptr %834, i64 %840
  store ptr %845, ptr %819, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i: ; preds = %842, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %844, %842 ]
  %846 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %847 = atomicrmw volatile xchg ptr %830, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %818, i1 noundef zeroext %846, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i

848:                                              ; preds = %816
  %849 = getelementptr inbounds %struct.LLVMRuntime, ptr %818, i64 0, i32 2
  %850 = load ptr, ptr %849, align 8
  %851 = getelementptr inbounds %struct.LLVMRuntime, ptr %818, i64 0, i32 6
  %852 = load ptr, ptr %851, align 8
  %853 = tail call noundef ptr %850(ptr noundef %852, i64 noundef %824, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i: ; preds = %848, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i ], [ %853, %848 ]
  %854 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %854, ptr %814 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i, %811
  %855 = atomicrmw volatile xchg ptr %770, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i:      ; preds = %737
  %856 = getelementptr inbounds %struct.ListManager, ptr %746, i64 0, i32 3
  %857 = load i32, ptr %856, align 8
  %858 = ashr i32 %744, %857
  %859 = sext i32 %858 to i64
  %860 = lshr i64 %859, 9
  %861 = getelementptr inbounds [256 x ptr], ptr %746, i64 0, i64 %860
  %862 = load atomic i64, ptr %861 acquire, align 8
  %.not.i.i.i.i.i.i.i.i = icmp ne i64 %862, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i.i.i.i.i)
  %863 = inttoptr i64 %862 to ptr
  %864 = and i64 %859, 511
  %865 = getelementptr inbounds ptr, ptr %863, i64 %864
  %866 = load atomic i64, ptr %865 acquire, align 8
  %867 = inttoptr i64 %866 to ptr
  %868 = getelementptr inbounds %struct.ListManager, ptr %746, i64 0, i32 1
  %869 = load i64, ptr %868, align 8
  %870 = load i32, ptr %856, align 8
  %notmask.i.i.i.i.i.i.i = shl nsw i32 -1, %870
  %871 = xor i32 %notmask.i.i.i.i.i.i.i, -1
  %872 = and i32 %744, %871
  %873 = sext i32 %872 to i64
  %874 = mul i64 %869, %873
  %875 = getelementptr inbounds i8, ptr %867, i64 %874
  %876 = load i32, ptr %875, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i: ; preds = %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i, %758
  %.0.i.i.i.i.i = phi i32 [ %876, %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i ], [ %753, %758 ], [ %753, %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i ], [ %753, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i" ]
  %877 = getelementptr inbounds %struct.NodeManager, ptr %742, i64 0, i32 7
  %878 = load ptr, ptr %877, align 8
  %879 = getelementptr inbounds %struct.ListManager, ptr %878, i64 0, i32 3
  %880 = load i32, ptr %879, align 8
  %881 = ashr i32 %.0.i.i.i.i.i, %880
  %882 = sext i32 %881 to i64
  %883 = lshr i64 %882, 9
  %884 = getelementptr inbounds [256 x ptr], ptr %878, i64 0, i64 %883
  %885 = load atomic i64, ptr %884 acquire, align 8
  %.not.i.i.i.i.i.i.i = icmp eq i64 %885, 0
  br i1 %.not.i.i.i.i.i.i.i, label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i", label %886

886:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i
  %887 = inttoptr i64 %885 to ptr
  %888 = and i64 %882, 511
  %889 = getelementptr inbounds ptr, ptr %887, i64 %888
  %890 = load atomic i64, ptr %889 acquire, align 8
  %891 = inttoptr i64 %890 to ptr
  br label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i"

"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i":    ; preds = %886, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i
  %892 = phi ptr [ %891, %886 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i ]
  %893 = getelementptr inbounds %struct.ListManager, ptr %878, i64 0, i32 1
  %894 = load i64, ptr %893, align 8
  %895 = load i32, ptr %879, align 8
  %notmask.i.i.i.i.i.i = shl nsw i32 -1, %895
  %896 = xor i32 %notmask.i.i.i.i.i.i, -1
  %897 = and i32 %.0.i.i.i.i.i, %896
  %898 = sext i32 %897 to i64
  %899 = mul i64 %894, %898
  %900 = getelementptr inbounds i8, ptr %892, i64 %899
  %901 = ptrtoint ptr %900 to i64
  %902 = atomicrmw volatile xchg ptr %728, i64 %901 seq_cst, align 8
  br label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i"

"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i": ; preds = %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i", %mutex_lock_i32.exit.i.i.i
  %903 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i, i32 0 seq_cst, align 4
  br label %Pointer_activate.exit

Pointer_activate.exit:                            ; preds = %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i", %true_block31
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %6)
  %904 = and i32 %724, 1073741816
  %905 = zext i32 %904 to i64
  %906 = getelementptr i8, ptr %723, i64 %905
  %907 = getelementptr inbounds i8, ptr %906, i64 32
  %908 = load ptr, ptr %907, align 8
  %909 = icmp eq ptr %908, null
  br i1 %909, label %910, label %Pointer_lookup_element.exit

910:                                              ; preds = %Pointer_activate.exit
  %911 = load ptr, ptr %24, align 8
  %912 = getelementptr inbounds %struct.LLVMRuntime, ptr %911, i64 0, i32 15
  %913 = load ptr, ptr %912, align 8
  %914 = getelementptr inbounds ptr, ptr %913, i64 24
  %915 = load ptr, ptr %914, align 8
  br label %Pointer_lookup_element.exit

Pointer_lookup_element.exit:                      ; preds = %910, %Pointer_activate.exit
  %.0.i = phi ptr [ %915, %910 ], [ %908, %Pointer_activate.exit ]
  %916 = and i32 %509, 31
  %917 = getelementptr inbounds i8, ptr %.0.i, i64 32
  %918 = shl nuw i32 1, %916
  %919 = atomicrmw volatile or ptr %917, i32 %918 seq_cst, align 4
  br label %after_if
}

; Function Attrs: nounwind
define void @tick_coverage_25_2_kernel_2_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body.1, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.1153, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nounwind
define internal void @function_body.1(ptr %0, ptr nocapture readnone %1, i32 %2) #1 {
allocs:
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = shl i32 %2, 9
  %8 = add i32 %7, 512
  %9 = tail call i32 @llvm.smin.i32(i32 %8, i32 70)
  %10 = load ptr, ptr %0, align 8
  %11 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %10, i64 0, i32 3, i32 1
  %12 = load ptr, ptr %11, align 8
  %13 = getelementptr i64, ptr %12, i64 2
  %14 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %10, i64 0, i32 7, i32 1
  %15 = load ptr, ptr %14, align 8
  %16 = getelementptr i64, ptr %15, i64 2
  %17 = icmp slt i32 %7, %9
  br i1 %17, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %18 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %10, i64 0, i32 2, i32 1
  %19 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %10, i64 0, i32 6, i32 1
  %20 = getelementptr inbounds %struct.RuntimeContext.1153, ptr %0, i64 0, i32 1
  %21 = sext i32 %7 to i64
  %wide.trip.count = sext i32 %9 to i64
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if, %for_loop_body.lr.ph
  %indvars.iv = phi i64 [ %21, %for_loop_body.lr.ph ], [ %indvars.iv.next, %after_if ]
  %22 = load i64, ptr %13, align 8
  %23 = icmp sgt i64 %22, %indvars.iv
  %24 = load i64, ptr %16, align 8
  %25 = icmp sgt i64 %24, %indvars.iv
  %26 = xor i1 %23, %25
  %27 = and i1 %23, %25
  %28 = load ptr, ptr %18, align 8
  %29 = getelementptr i32, ptr %28, i64 %indvars.iv
  %30 = load i32, ptr %29, align 4
  %31 = load ptr, ptr %19, align 8
  %32 = getelementptr i32, ptr %31, i64 %indvars.iv
  %33 = load i32, ptr %32, align 4
  %34 = icmp ne i32 %30, %33
  %35 = and i1 %27, %34
  %36 = or i1 %26, %35
  br i1 %36, label %true_block, label %after_if

after_for.loopexit:                               ; preds = %after_if
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %allocs
  ret void

true_block:                                       ; preds = %for_loop_body
  %37 = load ptr, ptr %0, align 8
  %38 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %37, i64 0, i32 8, i32 1
  %39 = load ptr, ptr %38, align 8
  %40 = atomicrmw add ptr %39, i64 1 seq_cst, align 8
  %41 = load ptr, ptr %20, align 8
  %42 = getelementptr inbounds %struct.LLVMRuntime, ptr %41, i64 0, i32 16
  %43 = load ptr, ptr %42, align 8
  %44 = load i32, ptr %43, align 4
  %.not = icmp eq i32 %44, 0
  br i1 %.not, label %after_if, label %true_block1

after_if:                                         ; preds = %Pointer_lookup_element.exit, %true_block28, %after_if24, %after_if6, %true_block, %for_loop_body
  %indvars.iv.next = add nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %indvars.iv.next, %wide.trip.count
  br i1 %exitcond.not, label %after_for.loopexit, label %for_loop_body

true_block1:                                      ; preds = %true_block
  br i1 %23, label %true_block4, label %after_if6

true_block4:                                      ; preds = %true_block1
  %45 = load i32, ptr %29, align 4
  %46 = load ptr, ptr %0, align 8
  %47 = getelementptr { { i32, i32 }, ptr }, ptr %46, i64 0, i32 1
  %48 = load ptr, ptr %47, align 8
  %49 = getelementptr { { i32, i32 }, ptr }, ptr %46, i64 0, i32 0, i32 1
  %50 = sext i32 %45 to i64
  %51 = getelementptr i32, ptr %48, i64 %50
  %52 = load i32, ptr %51, align 4
  %53 = icmp ult i32 %52, 70
  br i1 %53, label %true_block7, label %after_if9

after_if6:                                        ; preds = %Pointer_lookup_element.exit56, %true_block13, %after_if9, %true_block1
  br i1 %25, label %true_block19, label %after_if

true_block7:                                      ; preds = %true_block4
  %54 = getelementptr inbounds %struct.LLVMRuntime, ptr %41, i64 0, i32 7
  %55 = load ptr, ptr %54, align 8
  %56 = load ptr, ptr %55, align 8
  %57 = getelementptr %0, ptr %56, i64 0, i32 2, i32 1, i64 127
  %58 = lshr i32 %52, 3
  %59 = zext i32 %58 to i64
  %60 = getelementptr inbounds i8, ptr %57, i64 %59
  %61 = load i8, ptr %60, align 1
  %62 = zext i8 %61 to i32
  %63 = and i32 %52, 7
  %64 = shl nuw nsw i32 1, %63
  %65 = and i32 %64, %62
  %.not292 = icmp eq i32 %65, 0
  br i1 %.not292, label %after_if9, label %true_block10

after_if9:                                        ; preds = %Pointer_lookup_element.exit101, %true_block7, %true_block4
  %66 = phi ptr [ %.pre, %Pointer_lookup_element.exit101 ], [ %48, %true_block7 ], [ %48, %true_block4 ]
  %67 = load i32, ptr %49, align 4
  %68 = sext i32 %67 to i64
  %69 = add nsw i64 %68, %50
  %70 = getelementptr i32, ptr %66, i64 %69
  %71 = load i32, ptr %70, align 4
  %72 = icmp ult i32 %71, 70
  br i1 %72, label %true_block13, label %after_if6

true_block10:                                     ; preds = %true_block7
  %73 = getelementptr inbounds ptr, ptr %55, i64 3
  %74 = load ptr, ptr %73, align 8
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %3)
  %75 = lshr i32 %52, 2
  %76 = and i32 %75, 56
  %77 = zext i32 %76 to i64
  %78 = getelementptr i8, ptr %74, i64 %77
  store volatile ptr %78, ptr %3, align 8
  %79 = getelementptr inbounds i8, ptr %78, i64 32
  %80 = load volatile ptr, ptr %79, align 8
  %81 = icmp eq ptr %80, null
  br i1 %81, label %82, label %Pointer_activate.exit140

82:                                               ; preds = %true_block10
  %.0..0..0..0..0..i102 = load volatile ptr, ptr %3, align 8
  %.0..0..0..0..0.2.i103 = load volatile ptr, ptr %3, align 8
  br label %83

83:                                               ; preds = %83, %82
  %84 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i103, i32 1 seq_cst, align 4
  %85 = icmp eq i32 %84, 1
  br i1 %85, label %83, label %mutex_lock_i32.exit.i.i.i104, !llvm.loop !6

mutex_lock_i32.exit.i.i.i104:                     ; preds = %83
  %86 = load volatile ptr, ptr %79, align 8
  %87 = icmp eq ptr %86, null
  br i1 %87, label %88, label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i139"

88:                                               ; preds = %mutex_lock_i32.exit.i.i.i104
  %89 = load ptr, ptr %20, align 8
  %90 = getelementptr inbounds %struct.LLVMRuntime, ptr %89, i64 0, i32 14
  %91 = load ptr, ptr %90, align 8
  %92 = getelementptr inbounds ptr, ptr %91, i64 24
  %93 = load ptr, ptr %92, align 8
  %94 = getelementptr inbounds %struct.NodeManager, ptr %93, i64 0, i32 4
  %95 = atomicrmw volatile add ptr %94, i32 1 seq_cst, align 4
  %96 = getelementptr inbounds %struct.NodeManager, ptr %93, i64 0, i32 5
  %97 = load ptr, ptr %96, align 8
  %98 = getelementptr inbounds %struct.ListManager, ptr %97, i64 0, i32 5
  %99 = load i32, ptr %98, align 8
  %.not.i.i.i.i.i105 = icmp slt i32 %95, %99
  br i1 %.not.i.i.i.i.i105, label %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i133, label %100

100:                                              ; preds = %88
  %101 = getelementptr inbounds %struct.NodeManager, ptr %93, i64 0, i32 7
  %102 = load ptr, ptr %101, align 8
  %103 = getelementptr inbounds %struct.ListManager, ptr %102, i64 0, i32 5
  %104 = atomicrmw volatile add ptr %103, i32 1 seq_cst, align 4
  %105 = getelementptr inbounds %struct.ListManager, ptr %102, i64 0, i32 3
  %106 = load i32, ptr %105, align 8
  %107 = ashr i32 %104, %106
  %108 = icmp ugt i32 %107, 131071
  br i1 %108, label %109, label %112

109:                                              ; preds = %100
  %110 = getelementptr inbounds %struct.ListManager, ptr %102, i64 0, i32 6
  %111 = load ptr, ptr %110, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %111, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i136

112:                                              ; preds = %100
  %113 = zext i32 %107 to i64
  %114 = lshr i64 %113, 9
  %115 = getelementptr inbounds [256 x ptr], ptr %102, i64 0, i64 %114
  %116 = load atomic i64, ptr %115 acquire, align 8
  %.not.i.i.i4.i.i.i.i.i106 = icmp eq i64 %116, 0
  br i1 %.not.i.i.i4.i.i.i.i.i106, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i109, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i108

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i108: ; preds = %112
  %117 = inttoptr i64 %116 to ptr
  %118 = and i64 %113, 511
  %119 = getelementptr inbounds ptr, ptr %117, i64 %118
  %120 = load atomic i64, ptr %119 acquire, align 8
  %.not.i.i5.i.i.i.i.i107 = icmp eq i64 %120, 0
  br i1 %.not.i.i5.i.i.i.i.i107, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i109, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i136

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i109: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i108, %112
  %121 = getelementptr inbounds %struct.ListManager, ptr %102, i64 0, i32 4
  br label %122

122:                                              ; preds = %122, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i109
  %123 = atomicrmw volatile xchg ptr %121, i32 1 seq_cst, align 4
  %124 = icmp eq i32 %123, 1
  br i1 %124, label %122, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i111, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i111:       ; preds = %122
  %125 = load atomic i64, ptr %115 acquire, align 8
  %126 = inttoptr i64 %125 to ptr
  %.not.i.i.i.i.i.i.i.i.i.i.i110 = icmp eq i64 %125, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i110, label %127, label %162

127:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i111
  %128 = getelementptr inbounds %struct.ListManager, ptr %102, i64 0, i32 6
  %129 = load ptr, ptr %128, align 8
  %130 = getelementptr inbounds %struct.LLVMRuntime, ptr %129, i64 0, i32 1
  %131 = getelementptr inbounds %struct.LLVMRuntime, ptr %129, i64 0, i32 28
  %132 = atomicrmw volatile add ptr %131, i64 4096 seq_cst, align 8
  %133 = getelementptr inbounds %struct.LLVMRuntime, ptr %129, i64 0, i32 1, i32 2
  %134 = load i64, ptr %133, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i.i.i112 = icmp eq i64 %134, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i.i.i112, label %155, label %135

135:                                              ; preds = %127
  %136 = getelementptr inbounds %struct.LLVMRuntime, ptr %129, i64 0, i32 26
  br label %137

137:                                              ; preds = %137, %135
  %138 = atomicrmw volatile xchg ptr %136, i32 1 seq_cst, align 4
  %139 = icmp eq i32 %138, 1
  br i1 %139, label %137, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i115, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i115: ; preds = %137
  %140 = load ptr, ptr %130, align 8
  %141 = ptrtoint ptr %140 to i64
  %142 = getelementptr inbounds %struct.LLVMRuntime, ptr %129, i64 0, i32 1, i32 1
  %143 = load ptr, ptr %142, align 8
  %144 = ptrtoint ptr %143 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i113 = sub i64 0, %141
  %145 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i113, 4095
  %146 = or i64 %145, 4096
  %147 = add i64 %146, %141
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i114 = icmp ugt i64 %147, %144
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i114, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i117, label %148

148:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i115
  %149 = add i64 %145, %141
  %150 = inttoptr i64 %149 to ptr
  %151 = getelementptr i8, ptr %140, i64 %145
  %152 = getelementptr inbounds i8, ptr %151, i64 4096
  store ptr %152, ptr %130, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i117

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i117: ; preds = %148, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i115
  %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i116 = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i115 ], [ %150, %148 ]
  %153 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i114, true
  %154 = atomicrmw volatile xchg ptr %136, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %129, i1 noundef zeroext %153, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i119

155:                                              ; preds = %127
  %156 = getelementptr inbounds %struct.LLVMRuntime, ptr %129, i64 0, i32 2
  %157 = load ptr, ptr %156, align 8
  %158 = getelementptr inbounds %struct.LLVMRuntime, ptr %129, i64 0, i32 6
  %159 = load ptr, ptr %158, align 8
  %160 = tail call noundef ptr %157(ptr noundef %159, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i119

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i119: ; preds = %155, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i117
  %.0.i17.i.i.i.i.i.i.i.i.i.i.i118 = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i116, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i117 ], [ %160, %155 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i.i.i118, i8 0, i64 4096, i1 false)
  %161 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i.i.i118 to i64
  store atomic i64 %161, ptr %115 release, align 8
  br label %162

162:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i119, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i111
  %.0.i.i.i.i.i.i.i.i.i.i.i120 = phi ptr [ %126, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i111 ], [ %.0.i17.i.i.i.i.i.i.i.i.i.i.i118, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i119 ]
  %163 = and i32 %107, 511
  %164 = zext i32 %163 to i64
  %165 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i.i.i120, i64 %164
  %166 = load atomic i64, ptr %165 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i.i.i121 = icmp eq i64 %166, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i.i.i121, label %167, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i130"

167:                                              ; preds = %162
  %168 = getelementptr inbounds %struct.ListManager, ptr %102, i64 0, i32 6
  %169 = load ptr, ptr %168, align 8
  %170 = getelementptr inbounds %struct.LLVMRuntime, ptr %169, i64 0, i32 1
  %171 = getelementptr inbounds %struct.ListManager, ptr %102, i64 0, i32 2
  %172 = load i64, ptr %171, align 8
  %173 = getelementptr inbounds %struct.ListManager, ptr %102, i64 0, i32 1
  %174 = load i64, ptr %173, align 8
  %175 = mul i64 %174, %172
  %176 = getelementptr inbounds %struct.LLVMRuntime, ptr %169, i64 0, i32 28
  %177 = atomicrmw volatile add ptr %176, i64 %175 seq_cst, align 8
  %178 = getelementptr inbounds %struct.LLVMRuntime, ptr %169, i64 0, i32 1, i32 2
  %179 = load i64, ptr %178, align 8
  %.not.i.i.i.i.i.i.i.i.i.i.i.i122 = icmp eq i64 %179, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i122, label %199, label %180

180:                                              ; preds = %167
  %181 = getelementptr inbounds %struct.LLVMRuntime, ptr %169, i64 0, i32 26
  br label %182

182:                                              ; preds = %182, %180
  %183 = atomicrmw volatile xchg ptr %181, i32 1 seq_cst, align 4
  %184 = icmp eq i32 %183, 1
  br i1 %184, label %182, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i125, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i125: ; preds = %182
  %185 = load ptr, ptr %170, align 8
  %186 = ptrtoint ptr %185 to i64
  %187 = getelementptr inbounds %struct.LLVMRuntime, ptr %169, i64 0, i32 1, i32 1
  %188 = load ptr, ptr %187, align 8
  %189 = ptrtoint ptr %188 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i123 = sub i64 0, %186
  %190 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i123, 4095
  %191 = add i64 %190, %175
  %192 = add i64 %191, %186
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i124 = icmp ugt i64 %192, %189
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i124, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i127, label %193

193:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i125
  %194 = add i64 %190, %186
  %195 = inttoptr i64 %194 to ptr
  %196 = getelementptr inbounds i8, ptr %185, i64 %191
  store ptr %196, ptr %170, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i127

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i127: ; preds = %193, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i125
  %.0.i.i.i.i.i.i.i.i.i.i.i.i.i126 = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i125 ], [ %195, %193 ]
  %197 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i124, true
  %198 = atomicrmw volatile xchg ptr %181, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %169, i1 noundef zeroext %197, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i129

199:                                              ; preds = %167
  %200 = getelementptr inbounds %struct.LLVMRuntime, ptr %169, i64 0, i32 2
  %201 = load ptr, ptr %200, align 8
  %202 = getelementptr inbounds %struct.LLVMRuntime, ptr %169, i64 0, i32 6
  %203 = load ptr, ptr %202, align 8
  %204 = tail call noundef ptr %201(ptr noundef %203, i64 noundef %175, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i129

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i129: ; preds = %199, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i127
  %.0.i.i.i.i.i.i.i.i.i.i.i.i128 = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i.i.i126, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i127 ], [ %204, %199 ]
  %205 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i.i.i128 to i64
  store atomic i64 %205, ptr %165 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i130"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i130": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i129, %162
  %206 = atomicrmw volatile xchg ptr %121, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i136

_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i133:   ; preds = %88
  %207 = getelementptr inbounds %struct.ListManager, ptr %97, i64 0, i32 3
  %208 = load i32, ptr %207, align 8
  %209 = ashr i32 %95, %208
  %210 = sext i32 %209 to i64
  %211 = lshr i64 %210, 9
  %212 = getelementptr inbounds [256 x ptr], ptr %97, i64 0, i64 %211
  %213 = load atomic i64, ptr %212 acquire, align 8
  %.not.i.i.i.i.i.i.i.i131 = icmp ne i64 %213, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i.i.i.i.i131)
  %214 = inttoptr i64 %213 to ptr
  %215 = and i64 %210, 511
  %216 = getelementptr inbounds ptr, ptr %214, i64 %215
  %217 = load atomic i64, ptr %216 acquire, align 8
  %218 = inttoptr i64 %217 to ptr
  %219 = getelementptr inbounds %struct.ListManager, ptr %97, i64 0, i32 1
  %220 = load i64, ptr %219, align 8
  %221 = load i32, ptr %207, align 8
  %notmask.i.i.i.i.i.i.i132 = shl nsw i32 -1, %221
  %222 = xor i32 %notmask.i.i.i.i.i.i.i132, -1
  %223 = and i32 %95, %222
  %224 = sext i32 %223 to i64
  %225 = mul i64 %220, %224
  %226 = getelementptr inbounds i8, ptr %218, i64 %225
  %227 = load i32, ptr %226, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i136

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i136: ; preds = %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i133, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i130", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i108, %109
  %.0.i.i.i.i.i134 = phi i32 [ %227, %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i133 ], [ %104, %109 ], [ %104, %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i108 ], [ %104, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i130" ]
  %228 = getelementptr inbounds %struct.NodeManager, ptr %93, i64 0, i32 7
  %229 = load ptr, ptr %228, align 8
  %230 = getelementptr inbounds %struct.ListManager, ptr %229, i64 0, i32 3
  %231 = load i32, ptr %230, align 8
  %232 = ashr i32 %.0.i.i.i.i.i134, %231
  %233 = sext i32 %232 to i64
  %234 = lshr i64 %233, 9
  %235 = getelementptr inbounds [256 x ptr], ptr %229, i64 0, i64 %234
  %236 = load atomic i64, ptr %235 acquire, align 8
  %.not.i.i.i.i.i.i.i135 = icmp eq i64 %236, 0
  br i1 %.not.i.i.i.i.i.i.i135, label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i138", label %237

237:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i136
  %238 = inttoptr i64 %236 to ptr
  %239 = and i64 %233, 511
  %240 = getelementptr inbounds ptr, ptr %238, i64 %239
  %241 = load atomic i64, ptr %240 acquire, align 8
  %242 = inttoptr i64 %241 to ptr
  br label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i138"

"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i138": ; preds = %237, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i136
  %243 = phi ptr [ %242, %237 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i136 ]
  %244 = getelementptr inbounds %struct.ListManager, ptr %229, i64 0, i32 1
  %245 = load i64, ptr %244, align 8
  %246 = load i32, ptr %230, align 8
  %notmask.i.i.i.i.i.i137 = shl nsw i32 -1, %246
  %247 = xor i32 %notmask.i.i.i.i.i.i137, -1
  %248 = and i32 %.0.i.i.i.i.i134, %247
  %249 = sext i32 %248 to i64
  %250 = mul i64 %245, %249
  %251 = getelementptr inbounds i8, ptr %243, i64 %250
  %252 = ptrtoint ptr %251 to i64
  %253 = atomicrmw volatile xchg ptr %79, i64 %252 seq_cst, align 8
  br label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i139"

"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i139": ; preds = %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i138", %mutex_lock_i32.exit.i.i.i104
  %254 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i103, i32 0 seq_cst, align 4
  br label %Pointer_activate.exit140

Pointer_activate.exit140:                         ; preds = %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i139", %true_block10
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %3)
  %255 = and i32 %75, 1073741816
  %256 = zext i32 %255 to i64
  %257 = getelementptr i8, ptr %74, i64 %256
  %258 = getelementptr inbounds i8, ptr %257, i64 32
  %259 = load ptr, ptr %258, align 8
  %260 = icmp eq ptr %259, null
  br i1 %260, label %261, label %Pointer_lookup_element.exit101

261:                                              ; preds = %Pointer_activate.exit140
  %262 = load ptr, ptr %20, align 8
  %263 = getelementptr inbounds %struct.LLVMRuntime, ptr %262, i64 0, i32 15
  %264 = load ptr, ptr %263, align 8
  %265 = getelementptr inbounds ptr, ptr %264, i64 24
  %266 = load ptr, ptr %265, align 8
  br label %Pointer_lookup_element.exit101

Pointer_lookup_element.exit101:                   ; preds = %261, %Pointer_activate.exit140
  %.0.i100 = phi ptr [ %266, %261 ], [ %259, %Pointer_activate.exit140 ]
  %267 = and i32 %52, 31
  %268 = getelementptr inbounds i8, ptr %.0.i100, i64 32
  %269 = shl nuw i32 1, %267
  %270 = atomicrmw volatile or ptr %268, i32 %269 seq_cst, align 4
  %.pre = load ptr, ptr %47, align 8
  br label %after_if9

true_block13:                                     ; preds = %after_if9
  %271 = load ptr, ptr %20, align 8
  %272 = getelementptr inbounds %struct.LLVMRuntime, ptr %271, i64 0, i32 7
  %273 = load ptr, ptr %272, align 8
  %274 = load ptr, ptr %273, align 8
  %275 = getelementptr %0, ptr %274, i64 0, i32 2, i32 1, i64 127
  %276 = lshr i32 %71, 3
  %277 = zext i32 %276 to i64
  %278 = getelementptr inbounds i8, ptr %275, i64 %277
  %279 = load i8, ptr %278, align 1
  %280 = zext i8 %279 to i32
  %281 = and i32 %71, 7
  %282 = shl nuw nsw i32 1, %281
  %283 = and i32 %282, %280
  %.not291 = icmp eq i32 %283, 0
  br i1 %.not291, label %after_if6, label %true_block16

true_block16:                                     ; preds = %true_block13
  %284 = getelementptr inbounds ptr, ptr %273, i64 3
  %285 = load ptr, ptr %284, align 8
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %4)
  %286 = lshr i32 %71, 2
  %287 = and i32 %286, 56
  %288 = zext i32 %287 to i64
  %289 = getelementptr i8, ptr %285, i64 %288
  store volatile ptr %289, ptr %4, align 8
  %290 = getelementptr inbounds i8, ptr %289, i64 32
  %291 = load volatile ptr, ptr %290, align 8
  %292 = icmp eq ptr %291, null
  br i1 %292, label %293, label %Pointer_activate.exit95

293:                                              ; preds = %true_block16
  %.0..0..0..0..0..i57 = load volatile ptr, ptr %4, align 8
  %.0..0..0..0..0.2.i58 = load volatile ptr, ptr %4, align 8
  br label %294

294:                                              ; preds = %294, %293
  %295 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i58, i32 1 seq_cst, align 4
  %296 = icmp eq i32 %295, 1
  br i1 %296, label %294, label %mutex_lock_i32.exit.i.i.i59, !llvm.loop !6

mutex_lock_i32.exit.i.i.i59:                      ; preds = %294
  %297 = load volatile ptr, ptr %290, align 8
  %298 = icmp eq ptr %297, null
  br i1 %298, label %299, label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i94"

299:                                              ; preds = %mutex_lock_i32.exit.i.i.i59
  %300 = load ptr, ptr %20, align 8
  %301 = getelementptr inbounds %struct.LLVMRuntime, ptr %300, i64 0, i32 14
  %302 = load ptr, ptr %301, align 8
  %303 = getelementptr inbounds ptr, ptr %302, i64 24
  %304 = load ptr, ptr %303, align 8
  %305 = getelementptr inbounds %struct.NodeManager, ptr %304, i64 0, i32 4
  %306 = atomicrmw volatile add ptr %305, i32 1 seq_cst, align 4
  %307 = getelementptr inbounds %struct.NodeManager, ptr %304, i64 0, i32 5
  %308 = load ptr, ptr %307, align 8
  %309 = getelementptr inbounds %struct.ListManager, ptr %308, i64 0, i32 5
  %310 = load i32, ptr %309, align 8
  %.not.i.i.i.i.i60 = icmp slt i32 %306, %310
  br i1 %.not.i.i.i.i.i60, label %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i88, label %311

311:                                              ; preds = %299
  %312 = getelementptr inbounds %struct.NodeManager, ptr %304, i64 0, i32 7
  %313 = load ptr, ptr %312, align 8
  %314 = getelementptr inbounds %struct.ListManager, ptr %313, i64 0, i32 5
  %315 = atomicrmw volatile add ptr %314, i32 1 seq_cst, align 4
  %316 = getelementptr inbounds %struct.ListManager, ptr %313, i64 0, i32 3
  %317 = load i32, ptr %316, align 8
  %318 = ashr i32 %315, %317
  %319 = icmp ugt i32 %318, 131071
  br i1 %319, label %320, label %323

320:                                              ; preds = %311
  %321 = getelementptr inbounds %struct.ListManager, ptr %313, i64 0, i32 6
  %322 = load ptr, ptr %321, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %322, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i91

323:                                              ; preds = %311
  %324 = zext i32 %318 to i64
  %325 = lshr i64 %324, 9
  %326 = getelementptr inbounds [256 x ptr], ptr %313, i64 0, i64 %325
  %327 = load atomic i64, ptr %326 acquire, align 8
  %.not.i.i.i4.i.i.i.i.i61 = icmp eq i64 %327, 0
  br i1 %.not.i.i.i4.i.i.i.i.i61, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i64, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i63

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i63: ; preds = %323
  %328 = inttoptr i64 %327 to ptr
  %329 = and i64 %324, 511
  %330 = getelementptr inbounds ptr, ptr %328, i64 %329
  %331 = load atomic i64, ptr %330 acquire, align 8
  %.not.i.i5.i.i.i.i.i62 = icmp eq i64 %331, 0
  br i1 %.not.i.i5.i.i.i.i.i62, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i64, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i91

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i64: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i63, %323
  %332 = getelementptr inbounds %struct.ListManager, ptr %313, i64 0, i32 4
  br label %333

333:                                              ; preds = %333, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i64
  %334 = atomicrmw volatile xchg ptr %332, i32 1 seq_cst, align 4
  %335 = icmp eq i32 %334, 1
  br i1 %335, label %333, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i66, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i66:        ; preds = %333
  %336 = load atomic i64, ptr %326 acquire, align 8
  %337 = inttoptr i64 %336 to ptr
  %.not.i.i.i.i.i.i.i.i.i.i.i65 = icmp eq i64 %336, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i65, label %338, label %373

338:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i66
  %339 = getelementptr inbounds %struct.ListManager, ptr %313, i64 0, i32 6
  %340 = load ptr, ptr %339, align 8
  %341 = getelementptr inbounds %struct.LLVMRuntime, ptr %340, i64 0, i32 1
  %342 = getelementptr inbounds %struct.LLVMRuntime, ptr %340, i64 0, i32 28
  %343 = atomicrmw volatile add ptr %342, i64 4096 seq_cst, align 8
  %344 = getelementptr inbounds %struct.LLVMRuntime, ptr %340, i64 0, i32 1, i32 2
  %345 = load i64, ptr %344, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i.i.i67 = icmp eq i64 %345, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i.i.i67, label %366, label %346

346:                                              ; preds = %338
  %347 = getelementptr inbounds %struct.LLVMRuntime, ptr %340, i64 0, i32 26
  br label %348

348:                                              ; preds = %348, %346
  %349 = atomicrmw volatile xchg ptr %347, i32 1 seq_cst, align 4
  %350 = icmp eq i32 %349, 1
  br i1 %350, label %348, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i70, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i70: ; preds = %348
  %351 = load ptr, ptr %341, align 8
  %352 = ptrtoint ptr %351 to i64
  %353 = getelementptr inbounds %struct.LLVMRuntime, ptr %340, i64 0, i32 1, i32 1
  %354 = load ptr, ptr %353, align 8
  %355 = ptrtoint ptr %354 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i68 = sub i64 0, %352
  %356 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i68, 4095
  %357 = or i64 %356, 4096
  %358 = add i64 %357, %352
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i69 = icmp ugt i64 %358, %355
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i69, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i72, label %359

359:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i70
  %360 = add i64 %356, %352
  %361 = inttoptr i64 %360 to ptr
  %362 = getelementptr i8, ptr %351, i64 %356
  %363 = getelementptr inbounds i8, ptr %362, i64 4096
  store ptr %363, ptr %341, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i72

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i72: ; preds = %359, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i70
  %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i71 = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i70 ], [ %361, %359 ]
  %364 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i69, true
  %365 = atomicrmw volatile xchg ptr %347, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %340, i1 noundef zeroext %364, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i74

366:                                              ; preds = %338
  %367 = getelementptr inbounds %struct.LLVMRuntime, ptr %340, i64 0, i32 2
  %368 = load ptr, ptr %367, align 8
  %369 = getelementptr inbounds %struct.LLVMRuntime, ptr %340, i64 0, i32 6
  %370 = load ptr, ptr %369, align 8
  %371 = tail call noundef ptr %368(ptr noundef %370, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i74

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i74: ; preds = %366, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i72
  %.0.i17.i.i.i.i.i.i.i.i.i.i.i73 = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i71, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i72 ], [ %371, %366 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i.i.i73, i8 0, i64 4096, i1 false)
  %372 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i.i.i73 to i64
  store atomic i64 %372, ptr %326 release, align 8
  br label %373

373:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i74, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i66
  %.0.i.i.i.i.i.i.i.i.i.i.i75 = phi ptr [ %337, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i66 ], [ %.0.i17.i.i.i.i.i.i.i.i.i.i.i73, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i74 ]
  %374 = and i32 %318, 511
  %375 = zext i32 %374 to i64
  %376 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i.i.i75, i64 %375
  %377 = load atomic i64, ptr %376 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i.i.i76 = icmp eq i64 %377, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i.i.i76, label %378, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i85"

378:                                              ; preds = %373
  %379 = getelementptr inbounds %struct.ListManager, ptr %313, i64 0, i32 6
  %380 = load ptr, ptr %379, align 8
  %381 = getelementptr inbounds %struct.LLVMRuntime, ptr %380, i64 0, i32 1
  %382 = getelementptr inbounds %struct.ListManager, ptr %313, i64 0, i32 2
  %383 = load i64, ptr %382, align 8
  %384 = getelementptr inbounds %struct.ListManager, ptr %313, i64 0, i32 1
  %385 = load i64, ptr %384, align 8
  %386 = mul i64 %385, %383
  %387 = getelementptr inbounds %struct.LLVMRuntime, ptr %380, i64 0, i32 28
  %388 = atomicrmw volatile add ptr %387, i64 %386 seq_cst, align 8
  %389 = getelementptr inbounds %struct.LLVMRuntime, ptr %380, i64 0, i32 1, i32 2
  %390 = load i64, ptr %389, align 8
  %.not.i.i.i.i.i.i.i.i.i.i.i.i77 = icmp eq i64 %390, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i77, label %410, label %391

391:                                              ; preds = %378
  %392 = getelementptr inbounds %struct.LLVMRuntime, ptr %380, i64 0, i32 26
  br label %393

393:                                              ; preds = %393, %391
  %394 = atomicrmw volatile xchg ptr %392, i32 1 seq_cst, align 4
  %395 = icmp eq i32 %394, 1
  br i1 %395, label %393, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i80, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i80: ; preds = %393
  %396 = load ptr, ptr %381, align 8
  %397 = ptrtoint ptr %396 to i64
  %398 = getelementptr inbounds %struct.LLVMRuntime, ptr %380, i64 0, i32 1, i32 1
  %399 = load ptr, ptr %398, align 8
  %400 = ptrtoint ptr %399 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i78 = sub i64 0, %397
  %401 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i78, 4095
  %402 = add i64 %401, %386
  %403 = add i64 %402, %397
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i79 = icmp ugt i64 %403, %400
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i79, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i82, label %404

404:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i80
  %405 = add i64 %401, %397
  %406 = inttoptr i64 %405 to ptr
  %407 = getelementptr inbounds i8, ptr %396, i64 %402
  store ptr %407, ptr %381, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i82

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i82: ; preds = %404, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i80
  %.0.i.i.i.i.i.i.i.i.i.i.i.i.i81 = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i80 ], [ %406, %404 ]
  %408 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i79, true
  %409 = atomicrmw volatile xchg ptr %392, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %380, i1 noundef zeroext %408, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i84

410:                                              ; preds = %378
  %411 = getelementptr inbounds %struct.LLVMRuntime, ptr %380, i64 0, i32 2
  %412 = load ptr, ptr %411, align 8
  %413 = getelementptr inbounds %struct.LLVMRuntime, ptr %380, i64 0, i32 6
  %414 = load ptr, ptr %413, align 8
  %415 = tail call noundef ptr %412(ptr noundef %414, i64 noundef %386, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i84

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i84: ; preds = %410, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i82
  %.0.i.i.i.i.i.i.i.i.i.i.i.i83 = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i.i.i81, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i82 ], [ %415, %410 ]
  %416 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i.i.i83 to i64
  store atomic i64 %416, ptr %376 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i85"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i85": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i84, %373
  %417 = atomicrmw volatile xchg ptr %332, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i91

_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i88:    ; preds = %299
  %418 = getelementptr inbounds %struct.ListManager, ptr %308, i64 0, i32 3
  %419 = load i32, ptr %418, align 8
  %420 = ashr i32 %306, %419
  %421 = sext i32 %420 to i64
  %422 = lshr i64 %421, 9
  %423 = getelementptr inbounds [256 x ptr], ptr %308, i64 0, i64 %422
  %424 = load atomic i64, ptr %423 acquire, align 8
  %.not.i.i.i.i.i.i.i.i86 = icmp ne i64 %424, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i.i.i.i.i86)
  %425 = inttoptr i64 %424 to ptr
  %426 = and i64 %421, 511
  %427 = getelementptr inbounds ptr, ptr %425, i64 %426
  %428 = load atomic i64, ptr %427 acquire, align 8
  %429 = inttoptr i64 %428 to ptr
  %430 = getelementptr inbounds %struct.ListManager, ptr %308, i64 0, i32 1
  %431 = load i64, ptr %430, align 8
  %432 = load i32, ptr %418, align 8
  %notmask.i.i.i.i.i.i.i87 = shl nsw i32 -1, %432
  %433 = xor i32 %notmask.i.i.i.i.i.i.i87, -1
  %434 = and i32 %306, %433
  %435 = sext i32 %434 to i64
  %436 = mul i64 %431, %435
  %437 = getelementptr inbounds i8, ptr %429, i64 %436
  %438 = load i32, ptr %437, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i91

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i91: ; preds = %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i88, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i85", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i63, %320
  %.0.i.i.i.i.i89 = phi i32 [ %438, %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i88 ], [ %315, %320 ], [ %315, %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i63 ], [ %315, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i85" ]
  %439 = getelementptr inbounds %struct.NodeManager, ptr %304, i64 0, i32 7
  %440 = load ptr, ptr %439, align 8
  %441 = getelementptr inbounds %struct.ListManager, ptr %440, i64 0, i32 3
  %442 = load i32, ptr %441, align 8
  %443 = ashr i32 %.0.i.i.i.i.i89, %442
  %444 = sext i32 %443 to i64
  %445 = lshr i64 %444, 9
  %446 = getelementptr inbounds [256 x ptr], ptr %440, i64 0, i64 %445
  %447 = load atomic i64, ptr %446 acquire, align 8
  %.not.i.i.i.i.i.i.i90 = icmp eq i64 %447, 0
  br i1 %.not.i.i.i.i.i.i.i90, label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i93", label %448

448:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i91
  %449 = inttoptr i64 %447 to ptr
  %450 = and i64 %444, 511
  %451 = getelementptr inbounds ptr, ptr %449, i64 %450
  %452 = load atomic i64, ptr %451 acquire, align 8
  %453 = inttoptr i64 %452 to ptr
  br label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i93"

"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i93":  ; preds = %448, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i91
  %454 = phi ptr [ %453, %448 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i91 ]
  %455 = getelementptr inbounds %struct.ListManager, ptr %440, i64 0, i32 1
  %456 = load i64, ptr %455, align 8
  %457 = load i32, ptr %441, align 8
  %notmask.i.i.i.i.i.i92 = shl nsw i32 -1, %457
  %458 = xor i32 %notmask.i.i.i.i.i.i92, -1
  %459 = and i32 %.0.i.i.i.i.i89, %458
  %460 = sext i32 %459 to i64
  %461 = mul i64 %456, %460
  %462 = getelementptr inbounds i8, ptr %454, i64 %461
  %463 = ptrtoint ptr %462 to i64
  %464 = atomicrmw volatile xchg ptr %290, i64 %463 seq_cst, align 8
  br label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i94"

"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i94": ; preds = %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i93", %mutex_lock_i32.exit.i.i.i59
  %465 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i58, i32 0 seq_cst, align 4
  br label %Pointer_activate.exit95

Pointer_activate.exit95:                          ; preds = %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i94", %true_block16
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %4)
  %466 = and i32 %286, 1073741816
  %467 = zext i32 %466 to i64
  %468 = getelementptr i8, ptr %285, i64 %467
  %469 = getelementptr inbounds i8, ptr %468, i64 32
  %470 = load ptr, ptr %469, align 8
  %471 = icmp eq ptr %470, null
  br i1 %471, label %472, label %Pointer_lookup_element.exit56

472:                                              ; preds = %Pointer_activate.exit95
  %473 = load ptr, ptr %20, align 8
  %474 = getelementptr inbounds %struct.LLVMRuntime, ptr %473, i64 0, i32 15
  %475 = load ptr, ptr %474, align 8
  %476 = getelementptr inbounds ptr, ptr %475, i64 24
  %477 = load ptr, ptr %476, align 8
  br label %Pointer_lookup_element.exit56

Pointer_lookup_element.exit56:                    ; preds = %472, %Pointer_activate.exit95
  %.0.i55 = phi ptr [ %477, %472 ], [ %470, %Pointer_activate.exit95 ]
  %478 = and i32 %71, 31
  %479 = getelementptr inbounds i8, ptr %.0.i55, i64 32
  %480 = shl nuw i32 1, %478
  %481 = atomicrmw volatile or ptr %479, i32 %480 seq_cst, align 4
  br label %after_if6

true_block19:                                     ; preds = %after_if6
  %482 = load i32, ptr %32, align 4
  %483 = load ptr, ptr %0, align 8
  %484 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %483, i64 0, i32 4, i32 1
  %485 = load ptr, ptr %484, align 8
  %486 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %483, i64 0, i32 4, i32 0, i32 1
  %487 = sext i32 %482 to i64
  %488 = getelementptr i32, ptr %485, i64 %487
  %489 = load i32, ptr %488, align 4
  %490 = icmp ult i32 %489, 70
  br i1 %490, label %true_block22, label %after_if24

true_block22:                                     ; preds = %true_block19
  %491 = load ptr, ptr %20, align 8
  %492 = getelementptr inbounds %struct.LLVMRuntime, ptr %491, i64 0, i32 7
  %493 = load ptr, ptr %492, align 8
  %494 = load ptr, ptr %493, align 8
  %495 = getelementptr %0, ptr %494, i64 0, i32 2, i32 1, i64 127
  %496 = lshr i32 %489, 3
  %497 = zext i32 %496 to i64
  %498 = getelementptr inbounds i8, ptr %495, i64 %497
  %499 = load i8, ptr %498, align 1
  %500 = zext i8 %499 to i32
  %501 = and i32 %489, 7
  %502 = shl nuw nsw i32 1, %501
  %503 = and i32 %502, %500
  %.not290 = icmp eq i32 %503, 0
  br i1 %.not290, label %after_if24, label %true_block25

after_if24:                                       ; preds = %Pointer_lookup_element.exit12, %true_block22, %true_block19
  %504 = phi ptr [ %.pre295, %Pointer_lookup_element.exit12 ], [ %485, %true_block22 ], [ %485, %true_block19 ]
  %505 = load i32, ptr %486, align 4
  %506 = sext i32 %505 to i64
  %507 = add nsw i64 %506, %487
  %508 = getelementptr i32, ptr %504, i64 %507
  %509 = load i32, ptr %508, align 4
  %510 = icmp ult i32 %509, 70
  br i1 %510, label %true_block28, label %after_if

true_block25:                                     ; preds = %true_block22
  %511 = getelementptr inbounds ptr, ptr %493, i64 3
  %512 = load ptr, ptr %511, align 8
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %5)
  %513 = lshr i32 %489, 2
  %514 = and i32 %513, 56
  %515 = zext i32 %514 to i64
  %516 = getelementptr i8, ptr %512, i64 %515
  store volatile ptr %516, ptr %5, align 8
  %517 = getelementptr inbounds i8, ptr %516, i64 32
  %518 = load volatile ptr, ptr %517, align 8
  %519 = icmp eq ptr %518, null
  br i1 %519, label %520, label %Pointer_activate.exit51

520:                                              ; preds = %true_block25
  %.0..0..0..0..0..i13 = load volatile ptr, ptr %5, align 8
  %.0..0..0..0..0.2.i14 = load volatile ptr, ptr %5, align 8
  br label %521

521:                                              ; preds = %521, %520
  %522 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i14, i32 1 seq_cst, align 4
  %523 = icmp eq i32 %522, 1
  br i1 %523, label %521, label %mutex_lock_i32.exit.i.i.i15, !llvm.loop !6

mutex_lock_i32.exit.i.i.i15:                      ; preds = %521
  %524 = load volatile ptr, ptr %517, align 8
  %525 = icmp eq ptr %524, null
  br i1 %525, label %526, label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i50"

526:                                              ; preds = %mutex_lock_i32.exit.i.i.i15
  %527 = load ptr, ptr %20, align 8
  %528 = getelementptr inbounds %struct.LLVMRuntime, ptr %527, i64 0, i32 14
  %529 = load ptr, ptr %528, align 8
  %530 = getelementptr inbounds ptr, ptr %529, i64 24
  %531 = load ptr, ptr %530, align 8
  %532 = getelementptr inbounds %struct.NodeManager, ptr %531, i64 0, i32 4
  %533 = atomicrmw volatile add ptr %532, i32 1 seq_cst, align 4
  %534 = getelementptr inbounds %struct.NodeManager, ptr %531, i64 0, i32 5
  %535 = load ptr, ptr %534, align 8
  %536 = getelementptr inbounds %struct.ListManager, ptr %535, i64 0, i32 5
  %537 = load i32, ptr %536, align 8
  %.not.i.i.i.i.i16 = icmp slt i32 %533, %537
  br i1 %.not.i.i.i.i.i16, label %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i44, label %538

538:                                              ; preds = %526
  %539 = getelementptr inbounds %struct.NodeManager, ptr %531, i64 0, i32 7
  %540 = load ptr, ptr %539, align 8
  %541 = getelementptr inbounds %struct.ListManager, ptr %540, i64 0, i32 5
  %542 = atomicrmw volatile add ptr %541, i32 1 seq_cst, align 4
  %543 = getelementptr inbounds %struct.ListManager, ptr %540, i64 0, i32 3
  %544 = load i32, ptr %543, align 8
  %545 = ashr i32 %542, %544
  %546 = icmp ugt i32 %545, 131071
  br i1 %546, label %547, label %550

547:                                              ; preds = %538
  %548 = getelementptr inbounds %struct.ListManager, ptr %540, i64 0, i32 6
  %549 = load ptr, ptr %548, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %549, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i47

550:                                              ; preds = %538
  %551 = zext i32 %545 to i64
  %552 = lshr i64 %551, 9
  %553 = getelementptr inbounds [256 x ptr], ptr %540, i64 0, i64 %552
  %554 = load atomic i64, ptr %553 acquire, align 8
  %.not.i.i.i4.i.i.i.i.i17 = icmp eq i64 %554, 0
  br i1 %.not.i.i.i4.i.i.i.i.i17, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i20, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i19

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i19: ; preds = %550
  %555 = inttoptr i64 %554 to ptr
  %556 = and i64 %551, 511
  %557 = getelementptr inbounds ptr, ptr %555, i64 %556
  %558 = load atomic i64, ptr %557 acquire, align 8
  %.not.i.i5.i.i.i.i.i18 = icmp eq i64 %558, 0
  br i1 %.not.i.i5.i.i.i.i.i18, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i20, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i47

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i20: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i19, %550
  %559 = getelementptr inbounds %struct.ListManager, ptr %540, i64 0, i32 4
  br label %560

560:                                              ; preds = %560, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i20
  %561 = atomicrmw volatile xchg ptr %559, i32 1 seq_cst, align 4
  %562 = icmp eq i32 %561, 1
  br i1 %562, label %560, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i22, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i22:        ; preds = %560
  %563 = load atomic i64, ptr %553 acquire, align 8
  %564 = inttoptr i64 %563 to ptr
  %.not.i.i.i.i.i.i.i.i.i.i.i21 = icmp eq i64 %563, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i21, label %565, label %600

565:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i22
  %566 = getelementptr inbounds %struct.ListManager, ptr %540, i64 0, i32 6
  %567 = load ptr, ptr %566, align 8
  %568 = getelementptr inbounds %struct.LLVMRuntime, ptr %567, i64 0, i32 1
  %569 = getelementptr inbounds %struct.LLVMRuntime, ptr %567, i64 0, i32 28
  %570 = atomicrmw volatile add ptr %569, i64 4096 seq_cst, align 8
  %571 = getelementptr inbounds %struct.LLVMRuntime, ptr %567, i64 0, i32 1, i32 2
  %572 = load i64, ptr %571, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i.i.i23 = icmp eq i64 %572, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i.i.i23, label %593, label %573

573:                                              ; preds = %565
  %574 = getelementptr inbounds %struct.LLVMRuntime, ptr %567, i64 0, i32 26
  br label %575

575:                                              ; preds = %575, %573
  %576 = atomicrmw volatile xchg ptr %574, i32 1 seq_cst, align 4
  %577 = icmp eq i32 %576, 1
  br i1 %577, label %575, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i26, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i26: ; preds = %575
  %578 = load ptr, ptr %568, align 8
  %579 = ptrtoint ptr %578 to i64
  %580 = getelementptr inbounds %struct.LLVMRuntime, ptr %567, i64 0, i32 1, i32 1
  %581 = load ptr, ptr %580, align 8
  %582 = ptrtoint ptr %581 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i24 = sub i64 0, %579
  %583 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i24, 4095
  %584 = or i64 %583, 4096
  %585 = add i64 %584, %579
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i25 = icmp ugt i64 %585, %582
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i25, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i28, label %586

586:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i26
  %587 = add i64 %583, %579
  %588 = inttoptr i64 %587 to ptr
  %589 = getelementptr i8, ptr %578, i64 %583
  %590 = getelementptr inbounds i8, ptr %589, i64 4096
  store ptr %590, ptr %568, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i28

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i28: ; preds = %586, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i26
  %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i27 = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i26 ], [ %588, %586 ]
  %591 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i25, true
  %592 = atomicrmw volatile xchg ptr %574, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %567, i1 noundef zeroext %591, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i30

593:                                              ; preds = %565
  %594 = getelementptr inbounds %struct.LLVMRuntime, ptr %567, i64 0, i32 2
  %595 = load ptr, ptr %594, align 8
  %596 = getelementptr inbounds %struct.LLVMRuntime, ptr %567, i64 0, i32 6
  %597 = load ptr, ptr %596, align 8
  %598 = tail call noundef ptr %595(ptr noundef %597, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i30

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i30: ; preds = %593, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i28
  %.0.i17.i.i.i.i.i.i.i.i.i.i.i29 = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i27, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i28 ], [ %598, %593 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i.i.i29, i8 0, i64 4096, i1 false)
  %599 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i.i.i29 to i64
  store atomic i64 %599, ptr %553 release, align 8
  br label %600

600:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i30, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i22
  %.0.i.i.i.i.i.i.i.i.i.i.i31 = phi ptr [ %564, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i22 ], [ %.0.i17.i.i.i.i.i.i.i.i.i.i.i29, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i30 ]
  %601 = and i32 %545, 511
  %602 = zext i32 %601 to i64
  %603 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i.i.i31, i64 %602
  %604 = load atomic i64, ptr %603 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i.i.i32 = icmp eq i64 %604, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i.i.i32, label %605, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i41"

605:                                              ; preds = %600
  %606 = getelementptr inbounds %struct.ListManager, ptr %540, i64 0, i32 6
  %607 = load ptr, ptr %606, align 8
  %608 = getelementptr inbounds %struct.LLVMRuntime, ptr %607, i64 0, i32 1
  %609 = getelementptr inbounds %struct.ListManager, ptr %540, i64 0, i32 2
  %610 = load i64, ptr %609, align 8
  %611 = getelementptr inbounds %struct.ListManager, ptr %540, i64 0, i32 1
  %612 = load i64, ptr %611, align 8
  %613 = mul i64 %612, %610
  %614 = getelementptr inbounds %struct.LLVMRuntime, ptr %607, i64 0, i32 28
  %615 = atomicrmw volatile add ptr %614, i64 %613 seq_cst, align 8
  %616 = getelementptr inbounds %struct.LLVMRuntime, ptr %607, i64 0, i32 1, i32 2
  %617 = load i64, ptr %616, align 8
  %.not.i.i.i.i.i.i.i.i.i.i.i.i33 = icmp eq i64 %617, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i33, label %637, label %618

618:                                              ; preds = %605
  %619 = getelementptr inbounds %struct.LLVMRuntime, ptr %607, i64 0, i32 26
  br label %620

620:                                              ; preds = %620, %618
  %621 = atomicrmw volatile xchg ptr %619, i32 1 seq_cst, align 4
  %622 = icmp eq i32 %621, 1
  br i1 %622, label %620, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i36, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i36: ; preds = %620
  %623 = load ptr, ptr %608, align 8
  %624 = ptrtoint ptr %623 to i64
  %625 = getelementptr inbounds %struct.LLVMRuntime, ptr %607, i64 0, i32 1, i32 1
  %626 = load ptr, ptr %625, align 8
  %627 = ptrtoint ptr %626 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i34 = sub i64 0, %624
  %628 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i34, 4095
  %629 = add i64 %628, %613
  %630 = add i64 %629, %624
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i35 = icmp ugt i64 %630, %627
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i35, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i38, label %631

631:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i36
  %632 = add i64 %628, %624
  %633 = inttoptr i64 %632 to ptr
  %634 = getelementptr inbounds i8, ptr %623, i64 %629
  store ptr %634, ptr %608, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i38

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i38: ; preds = %631, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i36
  %.0.i.i.i.i.i.i.i.i.i.i.i.i.i37 = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i36 ], [ %633, %631 ]
  %635 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i35, true
  %636 = atomicrmw volatile xchg ptr %619, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %607, i1 noundef zeroext %635, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i40

637:                                              ; preds = %605
  %638 = getelementptr inbounds %struct.LLVMRuntime, ptr %607, i64 0, i32 2
  %639 = load ptr, ptr %638, align 8
  %640 = getelementptr inbounds %struct.LLVMRuntime, ptr %607, i64 0, i32 6
  %641 = load ptr, ptr %640, align 8
  %642 = tail call noundef ptr %639(ptr noundef %641, i64 noundef %613, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i40

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i40: ; preds = %637, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i38
  %.0.i.i.i.i.i.i.i.i.i.i.i.i39 = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i.i.i37, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i38 ], [ %642, %637 ]
  %643 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i.i.i39 to i64
  store atomic i64 %643, ptr %603 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i41"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i41": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i40, %600
  %644 = atomicrmw volatile xchg ptr %559, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i47

_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i44:    ; preds = %526
  %645 = getelementptr inbounds %struct.ListManager, ptr %535, i64 0, i32 3
  %646 = load i32, ptr %645, align 8
  %647 = ashr i32 %533, %646
  %648 = sext i32 %647 to i64
  %649 = lshr i64 %648, 9
  %650 = getelementptr inbounds [256 x ptr], ptr %535, i64 0, i64 %649
  %651 = load atomic i64, ptr %650 acquire, align 8
  %.not.i.i.i.i.i.i.i.i42 = icmp ne i64 %651, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i.i.i.i.i42)
  %652 = inttoptr i64 %651 to ptr
  %653 = and i64 %648, 511
  %654 = getelementptr inbounds ptr, ptr %652, i64 %653
  %655 = load atomic i64, ptr %654 acquire, align 8
  %656 = inttoptr i64 %655 to ptr
  %657 = getelementptr inbounds %struct.ListManager, ptr %535, i64 0, i32 1
  %658 = load i64, ptr %657, align 8
  %659 = load i32, ptr %645, align 8
  %notmask.i.i.i.i.i.i.i43 = shl nsw i32 -1, %659
  %660 = xor i32 %notmask.i.i.i.i.i.i.i43, -1
  %661 = and i32 %533, %660
  %662 = sext i32 %661 to i64
  %663 = mul i64 %658, %662
  %664 = getelementptr inbounds i8, ptr %656, i64 %663
  %665 = load i32, ptr %664, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i47

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i47: ; preds = %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i44, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i41", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i19, %547
  %.0.i.i.i.i.i45 = phi i32 [ %665, %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i44 ], [ %542, %547 ], [ %542, %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i19 ], [ %542, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i41" ]
  %666 = getelementptr inbounds %struct.NodeManager, ptr %531, i64 0, i32 7
  %667 = load ptr, ptr %666, align 8
  %668 = getelementptr inbounds %struct.ListManager, ptr %667, i64 0, i32 3
  %669 = load i32, ptr %668, align 8
  %670 = ashr i32 %.0.i.i.i.i.i45, %669
  %671 = sext i32 %670 to i64
  %672 = lshr i64 %671, 9
  %673 = getelementptr inbounds [256 x ptr], ptr %667, i64 0, i64 %672
  %674 = load atomic i64, ptr %673 acquire, align 8
  %.not.i.i.i.i.i.i.i46 = icmp eq i64 %674, 0
  br i1 %.not.i.i.i.i.i.i.i46, label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i49", label %675

675:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i47
  %676 = inttoptr i64 %674 to ptr
  %677 = and i64 %671, 511
  %678 = getelementptr inbounds ptr, ptr %676, i64 %677
  %679 = load atomic i64, ptr %678 acquire, align 8
  %680 = inttoptr i64 %679 to ptr
  br label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i49"

"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i49":  ; preds = %675, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i47
  %681 = phi ptr [ %680, %675 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i47 ]
  %682 = getelementptr inbounds %struct.ListManager, ptr %667, i64 0, i32 1
  %683 = load i64, ptr %682, align 8
  %684 = load i32, ptr %668, align 8
  %notmask.i.i.i.i.i.i48 = shl nsw i32 -1, %684
  %685 = xor i32 %notmask.i.i.i.i.i.i48, -1
  %686 = and i32 %.0.i.i.i.i.i45, %685
  %687 = sext i32 %686 to i64
  %688 = mul i64 %683, %687
  %689 = getelementptr inbounds i8, ptr %681, i64 %688
  %690 = ptrtoint ptr %689 to i64
  %691 = atomicrmw volatile xchg ptr %517, i64 %690 seq_cst, align 8
  br label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i50"

"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i50": ; preds = %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i49", %mutex_lock_i32.exit.i.i.i15
  %692 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i14, i32 0 seq_cst, align 4
  br label %Pointer_activate.exit51

Pointer_activate.exit51:                          ; preds = %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i50", %true_block25
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5)
  %693 = and i32 %513, 1073741816
  %694 = zext i32 %693 to i64
  %695 = getelementptr i8, ptr %512, i64 %694
  %696 = getelementptr inbounds i8, ptr %695, i64 32
  %697 = load ptr, ptr %696, align 8
  %698 = icmp eq ptr %697, null
  br i1 %698, label %699, label %Pointer_lookup_element.exit12

699:                                              ; preds = %Pointer_activate.exit51
  %700 = load ptr, ptr %20, align 8
  %701 = getelementptr inbounds %struct.LLVMRuntime, ptr %700, i64 0, i32 15
  %702 = load ptr, ptr %701, align 8
  %703 = getelementptr inbounds ptr, ptr %702, i64 24
  %704 = load ptr, ptr %703, align 8
  br label %Pointer_lookup_element.exit12

Pointer_lookup_element.exit12:                    ; preds = %699, %Pointer_activate.exit51
  %.0.i11 = phi ptr [ %704, %699 ], [ %697, %Pointer_activate.exit51 ]
  %705 = and i32 %489, 31
  %706 = getelementptr inbounds i8, ptr %.0.i11, i64 32
  %707 = shl nuw i32 1, %705
  %708 = atomicrmw volatile or ptr %706, i32 %707 seq_cst, align 4
  %.pre295 = load ptr, ptr %484, align 8
  br label %after_if24

true_block28:                                     ; preds = %after_if24
  %709 = load ptr, ptr %20, align 8
  %710 = getelementptr inbounds %struct.LLVMRuntime, ptr %709, i64 0, i32 7
  %711 = load ptr, ptr %710, align 8
  %712 = load ptr, ptr %711, align 8
  %713 = getelementptr %0, ptr %712, i64 0, i32 2, i32 1, i64 127
  %714 = lshr i32 %509, 3
  %715 = zext i32 %714 to i64
  %716 = getelementptr inbounds i8, ptr %713, i64 %715
  %717 = load i8, ptr %716, align 1
  %718 = zext i8 %717 to i32
  %719 = and i32 %509, 7
  %720 = shl nuw nsw i32 1, %719
  %721 = and i32 %720, %718
  %.not289 = icmp eq i32 %721, 0
  br i1 %.not289, label %after_if, label %true_block31

true_block31:                                     ; preds = %true_block28
  %722 = getelementptr inbounds ptr, ptr %711, i64 3
  %723 = load ptr, ptr %722, align 8
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %6)
  %724 = lshr i32 %509, 2
  %725 = and i32 %724, 56
  %726 = zext i32 %725 to i64
  %727 = getelementptr i8, ptr %723, i64 %726
  store volatile ptr %727, ptr %6, align 8
  %728 = getelementptr inbounds i8, ptr %727, i64 32
  %729 = load volatile ptr, ptr %728, align 8
  %730 = icmp eq ptr %729, null
  br i1 %730, label %731, label %Pointer_activate.exit

731:                                              ; preds = %true_block31
  %.0..0..0..0..0..i = load volatile ptr, ptr %6, align 8
  %.0..0..0..0..0.2.i = load volatile ptr, ptr %6, align 8
  br label %732

732:                                              ; preds = %732, %731
  %733 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i, i32 1 seq_cst, align 4
  %734 = icmp eq i32 %733, 1
  br i1 %734, label %732, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i:                        ; preds = %732
  %735 = load volatile ptr, ptr %728, align 8
  %736 = icmp eq ptr %735, null
  br i1 %736, label %737, label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i"

737:                                              ; preds = %mutex_lock_i32.exit.i.i.i
  %738 = load ptr, ptr %20, align 8
  %739 = getelementptr inbounds %struct.LLVMRuntime, ptr %738, i64 0, i32 14
  %740 = load ptr, ptr %739, align 8
  %741 = getelementptr inbounds ptr, ptr %740, i64 24
  %742 = load ptr, ptr %741, align 8
  %743 = getelementptr inbounds %struct.NodeManager, ptr %742, i64 0, i32 4
  %744 = atomicrmw volatile add ptr %743, i32 1 seq_cst, align 4
  %745 = getelementptr inbounds %struct.NodeManager, ptr %742, i64 0, i32 5
  %746 = load ptr, ptr %745, align 8
  %747 = getelementptr inbounds %struct.ListManager, ptr %746, i64 0, i32 5
  %748 = load i32, ptr %747, align 8
  %.not.i.i.i.i.i = icmp slt i32 %744, %748
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i, label %749

749:                                              ; preds = %737
  %750 = getelementptr inbounds %struct.NodeManager, ptr %742, i64 0, i32 7
  %751 = load ptr, ptr %750, align 8
  %752 = getelementptr inbounds %struct.ListManager, ptr %751, i64 0, i32 5
  %753 = atomicrmw volatile add ptr %752, i32 1 seq_cst, align 4
  %754 = getelementptr inbounds %struct.ListManager, ptr %751, i64 0, i32 3
  %755 = load i32, ptr %754, align 8
  %756 = ashr i32 %753, %755
  %757 = icmp ugt i32 %756, 131071
  br i1 %757, label %758, label %761

758:                                              ; preds = %749
  %759 = getelementptr inbounds %struct.ListManager, ptr %751, i64 0, i32 6
  %760 = load ptr, ptr %759, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %760, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

761:                                              ; preds = %749
  %762 = zext i32 %756 to i64
  %763 = lshr i64 %762, 9
  %764 = getelementptr inbounds [256 x ptr], ptr %751, i64 0, i64 %763
  %765 = load atomic i64, ptr %764 acquire, align 8
  %.not.i.i.i4.i.i.i.i.i = icmp eq i64 %765, 0
  br i1 %.not.i.i.i4.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i:  ; preds = %761
  %766 = inttoptr i64 %765 to ptr
  %767 = and i64 %762, 511
  %768 = getelementptr inbounds ptr, ptr %766, i64 %767
  %769 = load atomic i64, ptr %768 acquire, align 8
  %.not.i.i5.i.i.i.i.i = icmp eq i64 %769, 0
  br i1 %.not.i.i5.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i, %761
  %770 = getelementptr inbounds %struct.ListManager, ptr %751, i64 0, i32 4
  br label %771

771:                                              ; preds = %771, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i
  %772 = atomicrmw volatile xchg ptr %770, i32 1 seq_cst, align 4
  %773 = icmp eq i32 %772, 1
  br i1 %773, label %771, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i:          ; preds = %771
  %774 = load atomic i64, ptr %764 acquire, align 8
  %775 = inttoptr i64 %774 to ptr
  %.not.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %774, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i, label %776, label %811

776:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i
  %777 = getelementptr inbounds %struct.ListManager, ptr %751, i64 0, i32 6
  %778 = load ptr, ptr %777, align 8
  %779 = getelementptr inbounds %struct.LLVMRuntime, ptr %778, i64 0, i32 1
  %780 = getelementptr inbounds %struct.LLVMRuntime, ptr %778, i64 0, i32 28
  %781 = atomicrmw volatile add ptr %780, i64 4096 seq_cst, align 8
  %782 = getelementptr inbounds %struct.LLVMRuntime, ptr %778, i64 0, i32 1, i32 2
  %783 = load i64, ptr %782, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %783, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i.i.i, label %804, label %784

784:                                              ; preds = %776
  %785 = getelementptr inbounds %struct.LLVMRuntime, ptr %778, i64 0, i32 26
  br label %786

786:                                              ; preds = %786, %784
  %787 = atomicrmw volatile xchg ptr %785, i32 1 seq_cst, align 4
  %788 = icmp eq i32 %787, 1
  br i1 %788, label %786, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i: ; preds = %786
  %789 = load ptr, ptr %779, align 8
  %790 = ptrtoint ptr %789 to i64
  %791 = getelementptr inbounds %struct.LLVMRuntime, ptr %778, i64 0, i32 1, i32 1
  %792 = load ptr, ptr %791, align 8
  %793 = ptrtoint ptr %792 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %790
  %794 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i, 4095
  %795 = or i64 %794, 4096
  %796 = add i64 %795, %790
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %796, %793
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i, label %797

797:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i
  %798 = add i64 %794, %790
  %799 = inttoptr i64 %798 to ptr
  %800 = getelementptr i8, ptr %789, i64 %794
  %801 = getelementptr inbounds i8, ptr %800, i64 4096
  store ptr %801, ptr %779, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i: ; preds = %797, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i ], [ %799, %797 ]
  %802 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i, true
  %803 = atomicrmw volatile xchg ptr %785, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %778, i1 noundef zeroext %802, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i

804:                                              ; preds = %776
  %805 = getelementptr inbounds %struct.LLVMRuntime, ptr %778, i64 0, i32 2
  %806 = load ptr, ptr %805, align 8
  %807 = getelementptr inbounds %struct.LLVMRuntime, ptr %778, i64 0, i32 6
  %808 = load ptr, ptr %807, align 8
  %809 = tail call noundef ptr %806(ptr noundef %808, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i: ; preds = %804, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i ], [ %809, %804 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %810 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %810, ptr %764 release, align 8
  br label %811

811:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %775, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i ]
  %812 = and i32 %756, 511
  %813 = zext i32 %812 to i64
  %814 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i.i.i, i64 %813
  %815 = load atomic i64, ptr %814 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %815, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i.i.i, label %816, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i"

816:                                              ; preds = %811
  %817 = getelementptr inbounds %struct.ListManager, ptr %751, i64 0, i32 6
  %818 = load ptr, ptr %817, align 8
  %819 = getelementptr inbounds %struct.LLVMRuntime, ptr %818, i64 0, i32 1
  %820 = getelementptr inbounds %struct.ListManager, ptr %751, i64 0, i32 2
  %821 = load i64, ptr %820, align 8
  %822 = getelementptr inbounds %struct.ListManager, ptr %751, i64 0, i32 1
  %823 = load i64, ptr %822, align 8
  %824 = mul i64 %823, %821
  %825 = getelementptr inbounds %struct.LLVMRuntime, ptr %818, i64 0, i32 28
  %826 = atomicrmw volatile add ptr %825, i64 %824 seq_cst, align 8
  %827 = getelementptr inbounds %struct.LLVMRuntime, ptr %818, i64 0, i32 1, i32 2
  %828 = load i64, ptr %827, align 8
  %.not.i.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %828, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i, label %848, label %829

829:                                              ; preds = %816
  %830 = getelementptr inbounds %struct.LLVMRuntime, ptr %818, i64 0, i32 26
  br label %831

831:                                              ; preds = %831, %829
  %832 = atomicrmw volatile xchg ptr %830, i32 1 seq_cst, align 4
  %833 = icmp eq i32 %832, 1
  br i1 %833, label %831, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i: ; preds = %831
  %834 = load ptr, ptr %819, align 8
  %835 = ptrtoint ptr %834 to i64
  %836 = getelementptr inbounds %struct.LLVMRuntime, ptr %818, i64 0, i32 1, i32 1
  %837 = load ptr, ptr %836, align 8
  %838 = ptrtoint ptr %837 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %835
  %839 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i, 4095
  %840 = add i64 %839, %824
  %841 = add i64 %840, %835
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %841, %838
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i, label %842

842:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %843 = add i64 %839, %835
  %844 = inttoptr i64 %843 to ptr
  %845 = getelementptr inbounds i8, ptr %834, i64 %840
  store ptr %845, ptr %819, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i: ; preds = %842, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %844, %842 ]
  %846 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %847 = atomicrmw volatile xchg ptr %830, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %818, i1 noundef zeroext %846, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i

848:                                              ; preds = %816
  %849 = getelementptr inbounds %struct.LLVMRuntime, ptr %818, i64 0, i32 2
  %850 = load ptr, ptr %849, align 8
  %851 = getelementptr inbounds %struct.LLVMRuntime, ptr %818, i64 0, i32 6
  %852 = load ptr, ptr %851, align 8
  %853 = tail call noundef ptr %850(ptr noundef %852, i64 noundef %824, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i: ; preds = %848, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i ], [ %853, %848 ]
  %854 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %854, ptr %814 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i, %811
  %855 = atomicrmw volatile xchg ptr %770, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i:      ; preds = %737
  %856 = getelementptr inbounds %struct.ListManager, ptr %746, i64 0, i32 3
  %857 = load i32, ptr %856, align 8
  %858 = ashr i32 %744, %857
  %859 = sext i32 %858 to i64
  %860 = lshr i64 %859, 9
  %861 = getelementptr inbounds [256 x ptr], ptr %746, i64 0, i64 %860
  %862 = load atomic i64, ptr %861 acquire, align 8
  %.not.i.i.i.i.i.i.i.i = icmp ne i64 %862, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i.i.i.i.i)
  %863 = inttoptr i64 %862 to ptr
  %864 = and i64 %859, 511
  %865 = getelementptr inbounds ptr, ptr %863, i64 %864
  %866 = load atomic i64, ptr %865 acquire, align 8
  %867 = inttoptr i64 %866 to ptr
  %868 = getelementptr inbounds %struct.ListManager, ptr %746, i64 0, i32 1
  %869 = load i64, ptr %868, align 8
  %870 = load i32, ptr %856, align 8
  %notmask.i.i.i.i.i.i.i = shl nsw i32 -1, %870
  %871 = xor i32 %notmask.i.i.i.i.i.i.i, -1
  %872 = and i32 %744, %871
  %873 = sext i32 %872 to i64
  %874 = mul i64 %869, %873
  %875 = getelementptr inbounds i8, ptr %867, i64 %874
  %876 = load i32, ptr %875, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i: ; preds = %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i, %758
  %.0.i.i.i.i.i = phi i32 [ %876, %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i ], [ %753, %758 ], [ %753, %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i ], [ %753, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i" ]
  %877 = getelementptr inbounds %struct.NodeManager, ptr %742, i64 0, i32 7
  %878 = load ptr, ptr %877, align 8
  %879 = getelementptr inbounds %struct.ListManager, ptr %878, i64 0, i32 3
  %880 = load i32, ptr %879, align 8
  %881 = ashr i32 %.0.i.i.i.i.i, %880
  %882 = sext i32 %881 to i64
  %883 = lshr i64 %882, 9
  %884 = getelementptr inbounds [256 x ptr], ptr %878, i64 0, i64 %883
  %885 = load atomic i64, ptr %884 acquire, align 8
  %.not.i.i.i.i.i.i.i = icmp eq i64 %885, 0
  br i1 %.not.i.i.i.i.i.i.i, label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i", label %886

886:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i
  %887 = inttoptr i64 %885 to ptr
  %888 = and i64 %882, 511
  %889 = getelementptr inbounds ptr, ptr %887, i64 %888
  %890 = load atomic i64, ptr %889 acquire, align 8
  %891 = inttoptr i64 %890 to ptr
  br label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i"

"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i":    ; preds = %886, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i
  %892 = phi ptr [ %891, %886 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i ]
  %893 = getelementptr inbounds %struct.ListManager, ptr %878, i64 0, i32 1
  %894 = load i64, ptr %893, align 8
  %895 = load i32, ptr %879, align 8
  %notmask.i.i.i.i.i.i = shl nsw i32 -1, %895
  %896 = xor i32 %notmask.i.i.i.i.i.i, -1
  %897 = and i32 %.0.i.i.i.i.i, %896
  %898 = sext i32 %897 to i64
  %899 = mul i64 %894, %898
  %900 = getelementptr inbounds i8, ptr %892, i64 %899
  %901 = ptrtoint ptr %900 to i64
  %902 = atomicrmw volatile xchg ptr %728, i64 %901 seq_cst, align 8
  br label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i"

"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i": ; preds = %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i", %mutex_lock_i32.exit.i.i.i
  %903 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i, i32 0 seq_cst, align 4
  br label %Pointer_activate.exit

Pointer_activate.exit:                            ; preds = %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i", %true_block31
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %6)
  %904 = and i32 %724, 1073741816
  %905 = zext i32 %904 to i64
  %906 = getelementptr i8, ptr %723, i64 %905
  %907 = getelementptr inbounds i8, ptr %906, i64 32
  %908 = load ptr, ptr %907, align 8
  %909 = icmp eq ptr %908, null
  br i1 %909, label %910, label %Pointer_lookup_element.exit

910:                                              ; preds = %Pointer_activate.exit
  %911 = load ptr, ptr %20, align 8
  %912 = getelementptr inbounds %struct.LLVMRuntime, ptr %911, i64 0, i32 15
  %913 = load ptr, ptr %912, align 8
  %914 = getelementptr inbounds ptr, ptr %913, i64 24
  %915 = load ptr, ptr %914, align 8
  br label %Pointer_lookup_element.exit

Pointer_lookup_element.exit:                      ; preds = %910, %Pointer_activate.exit
  %.0.i = phi ptr [ %915, %910 ], [ %908, %Pointer_activate.exit ]
  %916 = and i32 %509, 31
  %917 = getelementptr inbounds i8, ptr %.0.i, i64 32
  %918 = shl nuw i32 1, %916
  %919 = atomicrmw volatile or ptr %917, i32 %918 seq_cst, align 4
  br label %after_if
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_parallel_range_for_task(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #2 {
  %4 = alloca %struct.RuntimeContext.1153, align 8
  %.sroa.0.0.copyload = load ptr, ptr %0, align 8
  %.sroa.4.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 8
  %.sroa.4.0.copyload = load ptr, ptr %.sroa.4.0..sroa_idx, align 8
  %.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 16
  %.sroa.5.0.copyload = load ptr, ptr %.sroa.5.0..sroa_idx, align 8
  %.sroa.7.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 24
  %.sroa.7.0.copyload = load ptr, ptr %.sroa.7.0..sroa_idx, align 8
  %.sroa.8.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 32
  %.sroa.8.0.copyload = load i64, ptr %.sroa.8.0..sroa_idx, align 8
  %.sroa.9.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 40
  %.sroa.9.0.copyload = load i32, ptr %.sroa.9.0..sroa_idx, align 8
  %.sroa.12.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 44
  %.sroa.12.0.copyload = load i32, ptr %.sroa.12.0..sroa_idx, align 4
  %.sroa.15.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 48
  %.sroa.15.0.copyload = load i32, ptr %.sroa.15.0..sroa_idx, align 8
  %.sroa.17.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 52
  %.sroa.17.0.copyload = load i32, ptr %.sroa.17.0..sroa_idx, align 4
  %5 = alloca i8, i64 %.sroa.8.0.copyload, align 8
  %.not = icmp eq ptr %.sroa.4.0.copyload, null
  br i1 %.not, label %7, label %6

6:                                                ; preds = %3
  call void %.sroa.4.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %7

7:                                                ; preds = %6, %3
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %4, ptr noundef nonnull align 8 dereferenceable(32) %.sroa.0.0.copyload, i64 32, i1 false)
  %8 = getelementptr inbounds %struct.RuntimeContext.1153, ptr %4, i64 0, i32 2
  store i32 %1, ptr %8, align 8
  switch i32 %.sroa.17.0.copyload, label %.loopexit [
    i32 1, label %9
    i32 -1, label %17
  ]

9:                                                ; preds = %7
  %10 = mul nsw i32 %.sroa.15.0.copyload, %2
  %11 = add nsw i32 %10, %.sroa.9.0.copyload
  %12 = add nsw i32 %11, %.sroa.15.0.copyload
  %13 = call i32 @llvm.smin.i32(i32 %.sroa.12.0.copyload, i32 %12)
  %14 = icmp slt i32 %11, %13
  br i1 %14, label %.lr.ph.preheader, label %.loopexit

.lr.ph.preheader:                                 ; preds = %9
  br label %.lr.ph

.lr.ph:                                           ; preds = %.lr.ph, %.lr.ph.preheader
  %.02039 = phi i32 [ %15, %.lr.ph ], [ %11, %.lr.ph.preheader ]
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.02039) #1
  %15 = add nsw i32 %.02039, 1
  %16 = icmp slt i32 %15, %13
  br i1 %16, label %.lr.ph, label %.loopexit.loopexit, !llvm.loop !9

17:                                               ; preds = %7
  %18 = mul nsw i32 %.sroa.15.0.copyload, %2
  %19 = sub nsw i32 %.sroa.12.0.copyload, %18
  %20 = mul nsw i32 %19, %.sroa.15.0.copyload
  %21 = call i32 @llvm.smax.i32(i32 %.sroa.9.0.copyload, i32 %20)
  %.not25.not40 = icmp sgt i32 %19, %21
  br i1 %.not25.not40, label %.lr.ph42.preheader, label %.loopexit

.lr.ph42.preheader:                               ; preds = %17
  br label %.lr.ph42

.lr.ph42:                                         ; preds = %.lr.ph42, %.lr.ph42.preheader
  %.0.in41 = phi i32 [ %.0, %.lr.ph42 ], [ %19, %.lr.ph42.preheader ]
  %.0 = add nsw i32 %.0.in41, -1
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.0) #1
  %.not25.not = icmp sgt i32 %.0, %21
  br i1 %.not25.not, label %.lr.ph42, label %.loopexit.loopexit47, !llvm.loop !10

.loopexit.loopexit:                               ; preds = %.lr.ph
  br label %.loopexit

.loopexit.loopexit47:                             ; preds = %.lr.ph42
  br label %.loopexit

.loopexit:                                        ; preds = %.loopexit.loopexit47, %.loopexit.loopexit, %17, %9, %7
  %.not24 = icmp eq ptr %.sroa.7.0.copyload, null
  br i1 %.not24, label %23, label %22

22:                                               ; preds = %.loopexit
  call void %.sroa.7.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %23

23:                                               ; preds = %22, %.loopexit
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #3

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn writeonly
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #4

; Function Attrs: noinline nounwind optnone uwtable
define internal fastcc void @taichi_assert_format(ptr noundef %0, i1 noundef zeroext %1, ptr noundef %2) unnamed_addr #5 {
  %4 = alloca ptr, align 8
  %5 = alloca i8, align 1
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca ptr, align 8
  %9 = alloca %class.anon, align 8
  store ptr %0, ptr %4, align 8
  %10 = zext i1 %1 to i8
  store i8 %10, ptr %5, align 1
  store ptr %2, ptr %6, align 8
  store i32 0, ptr %7, align 4
  store ptr null, ptr %8, align 8
  %11 = load i8, ptr %5, align 1
  %12 = trunc i8 %11 to i1
  %13 = zext i1 %12 to i32
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %15, label %16

15:                                               ; preds = %3
  br label %69

16:                                               ; preds = %3
  %17 = load ptr, ptr %4, align 8
  %18 = getelementptr inbounds %struct.LLVMRuntime, ptr %17, i32 0, i32 24
  %19 = load i64, ptr %18, align 8
  %20 = icmp ne i64 %19, 0
  br i1 %20, label %69, label %21

21:                                               ; preds = %16
  %22 = load ptr, ptr %4, align 8
  %23 = getelementptr inbounds %struct.LLVMRuntime, ptr %22, i32 0, i32 23
  %24 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 0
  store ptr %4, ptr %24, align 8
  %25 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 1
  store ptr %6, ptr %25, align 8
  %26 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 2
  store ptr %7, ptr %26, align 8
  %27 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 3
  store ptr %8, ptr %27, align 8
  br label %28

28:                                               ; preds = %28, %21
  %29 = atomicrmw volatile xchg ptr %23, i32 1 seq_cst, align 4
  %30 = icmp eq i32 %29, 1
  br i1 %30, label %28, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i:                        ; preds = %28
  %31 = load ptr, ptr %9, align 8
  %32 = load ptr, ptr %31, align 8
  %33 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 24
  %34 = load i64, ptr %33, align 8
  %.not.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i, label %35, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

35:                                               ; preds = %mutex_lock_i32.exit.i.i.i
  store i64 1, ptr %33, align 8
  %36 = load ptr, ptr %9, align 8
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr inbounds %struct.LLVMRuntime, ptr %37, i64 0, i32 21
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %38, i8 0, i64 2048, i1 false)
  %39 = load ptr, ptr %9, align 8
  %40 = load ptr, ptr %39, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 21
  %42 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 1
  %43 = load ptr, ptr %42, align 8
  %44 = load ptr, ptr %43, align 8
  %45 = load i8, ptr %44, align 1
  %.not5.i.i.i.i.i = icmp eq i8 %45, 0
  br i1 %.not5.i.i.i.i.i, label %taichi_strlen.exit.thread.i.i.i.i, label %.lr.ph.i.i.i.i.i.preheader

.lr.ph.i.i.i.i.i.preheader:                       ; preds = %35
  br label %.lr.ph.i.i.i.i.i

.lr.ph.i.i.i.i.i:                                 ; preds = %.lr.ph.i.i.i.i.i, %.lr.ph.i.i.i.i.i.preheader
  %.07.i.i.i.i.i = phi ptr [ %47, %.lr.ph.i.i.i.i.i ], [ %44, %.lr.ph.i.i.i.i.i.preheader ]
  %.046.i.i.i.i.i = phi i64 [ %46, %.lr.ph.i.i.i.i.i ], [ 0, %.lr.ph.i.i.i.i.i.preheader ]
  %46 = add i64 %.046.i.i.i.i.i, 1
  %47 = getelementptr inbounds i8, ptr %.07.i.i.i.i.i, i64 1
  %48 = load i8, ptr %47, align 1
  %.not.i.i.i.i.i = icmp eq i8 %48, 0
  br i1 %.not.i.i.i.i.i, label %taichi_strlen.exit.i.i.i.i, label %.lr.ph.i.i.i.i.i, !llvm.loop !11

taichi_strlen.exit.i.i.i.i:                       ; preds = %.lr.ph.i.i.i.i.i
  %.lcssa = phi i64 [ %46, %.lr.ph.i.i.i.i.i ]
  %49 = call i64 @llvm.umin.i64(i64 %.lcssa, i64 2047)
  br label %taichi_strlen.exit.thread.i.i.i.i

taichi_strlen.exit.thread.i.i.i.i:                ; preds = %taichi_strlen.exit.i.i.i.i, %35
  %50 = phi i64 [ 0, %35 ], [ %49, %taichi_strlen.exit.i.i.i.i ]
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %41, ptr nonnull align 1 %44, i64 %50, i1 false)
  %51 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 2
  %52 = load ptr, ptr %51, align 8
  %53 = load i32, ptr %52, align 4
  %54 = icmp sgt i32 %53, 0
  br i1 %54, label %.lr.ph.i.i.i.i, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

.lr.ph.i.i.i.i:                                   ; preds = %taichi_strlen.exit.thread.i.i.i.i
  %55 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 3
  br label %56

56:                                               ; preds = %56, %.lr.ph.i.i.i.i
  %indvars.iv.i.i.i.i = phi i64 [ 0, %.lr.ph.i.i.i.i ], [ %indvars.iv.next.i.i.i.i, %56 ]
  %57 = load ptr, ptr %55, align 8
  %58 = load ptr, ptr %57, align 8
  %59 = getelementptr inbounds i64, ptr %58, i64 %indvars.iv.i.i.i.i
  %60 = load i64, ptr %59, align 8
  %61 = load ptr, ptr %9, align 8
  %62 = load ptr, ptr %61, align 8
  %63 = getelementptr inbounds %struct.LLVMRuntime, ptr %62, i64 0, i32 22, i64 %indvars.iv.i.i.i.i
  store i64 %60, ptr %63, align 8
  %indvars.iv.next.i.i.i.i = add nuw nsw i64 %indvars.iv.i.i.i.i, 1
  %64 = load ptr, ptr %51, align 8
  %65 = load i32, ptr %64, align 4
  %66 = sext i32 %65 to i64
  %67 = icmp slt i64 %indvars.iv.next.i.i.i.i, %66
  br i1 %67, label %56, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", !llvm.loop !12

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit": ; preds = %56
  br label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit": ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", %taichi_strlen.exit.thread.i.i.i.i, %mutex_lock_i32.exit.i.i.i
  %68 = atomicrmw volatile xchg ptr %23, i32 0 seq_cst, align 4
  br label %69

69:                                               ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit", %16, %15
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #6

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #7

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #7

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i64 @llvm.umin.i64(i64, i64) #8

; Function Attrs: inaccessiblememonly nocallback nofree nosync nounwind willreturn
declare void @llvm.assume(i1 noundef) #9

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smax.i32(i32, i32) #8

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #4 = { argmemonly mustprogress nocallback nofree nounwind willreturn writeonly }
attributes #5 = { noinline nounwind optnone uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #7 = { argmemonly nocallback nofree nosync nounwind willreturn }
attributes #8 = { nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #9 = { inaccessiblememonly nocallback nofree nosync nounwind willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7, !8}
!7 = !{!"llvm.loop.mustprogress"}
!8 = !{!"llvm.loop.unroll.disable"}
!9 = distinct !{!9, !7, !8}
!10 = distinct !{!10, !7, !8}
!11 = distinct !{!11, !7, !8}
!12 = distinct !{!12, !7, !8}
