; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%0 = type { ptr, [2 x i32], %struct.PhysicalCoordinates.2225 }
%1 = type { %2, %2 }
%2 = type { [4 x i64], [4 x ptr] }
%struct.RuntimeContext.2212 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }
%struct.ListManager = type { [256 x ptr], i64, i64, i32, i32, i32, ptr }
%struct.PhysicalCoordinates.2225 = type { [12 x i32] }
%struct.cpu_block_task_helper_context = type { ptr, ptr, ptr, i32, i32, i64 }
%struct.NodeManager = type <{ ptr, i32, i32, i32, i32, ptr, ptr, ptr, i32, [4 x i8] }>
%class.anon = type { ptr, ptr, ptr, ptr }

@.str = private unnamed_addr constant [28 x i8] c"Out of pre-allocated memory\00", align 1
@.str.2 = private unnamed_addr constant [28 x i8] c"List manager out of chunks.\00", align 1

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @live_hierarchy_poll_58_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 25
  %2 = load double, ptr %1, align 8
  %3 = getelementptr inbounds %struct.RuntimeContext.2212, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds i8, ptr %6, i64 8
  store double %2, ptr %7, align 8
  %8 = load ptr, ptr %context, align 8
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %8, i64 0, i32 26
  %10 = load i32, ptr %9, align 4
  %11 = load ptr, ptr %3, align 8
  %12 = getelementptr inbounds %struct.LLVMRuntime, ptr %11, i64 0, i32 16
  %13 = load ptr, ptr %12, align 8
  store i32 %10, ptr %13, align 4
  %14 = load ptr, ptr %context, align 8
  %15 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %14, i64 0, i32 27
  %16 = load double, ptr %15, align 8
  %17 = load ptr, ptr %3, align 8
  %18 = getelementptr inbounds %struct.LLVMRuntime, ptr %17, i64 0, i32 16
  %19 = load ptr, ptr %18, align 8
  %20 = getelementptr inbounds i8, ptr %19, i64 16
  store double %16, ptr %20, align 8
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @live_hierarchy_poll_58_kernel_1_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.2212, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 57
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @live_hierarchy_poll_58_kernel_2_listgen_S57pointer(ptr %context) local_unnamed_addr #1 {
.lr.ph.i:
  %.sroa.2.i = alloca { [2 x i32], %struct.PhysicalCoordinates.2225 }, align 8
  %0 = alloca %0, align 8
  %1 = getelementptr inbounds %struct.RuntimeContext.2212, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 53
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %4, i64 57
  %8 = load ptr, ptr %7, align 8
  %9 = load atomic i64, ptr %6 acquire, align 8
  %.not.i.i.i.i = icmp ne i64 %9, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i)
  %10 = inttoptr i64 %9 to ptr
  %11 = load atomic i64, ptr %10 acquire, align 8
  %12 = inttoptr i64 %11 to ptr
  %.sroa.0.0.copyload.i = load ptr, ptr %12, align 8
  %.sroa.2.0..sroa_idx.i = getelementptr inbounds i8, ptr %12, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.i, ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.0..sroa_idx.i, i64 56, i1 false)
  %getch.i = getelementptr %1, ptr %.sroa.0.0.copyload.i, i64 0, i32 1
  %13 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %.sroa.2.16.sroa_idx.i = getelementptr inbounds i8, ptr %.sroa.2.i, i64 8
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %16 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 4
  %17 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 6
  %18 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 2
  %19 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  store ptr %getch.i, ptr %0, align 8
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %0, i64 8
  store <2 x i32> <i32 0, i32 4>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %13, ptr noundef nonnull align 8 dereferenceable(48) %.sroa.2.16.sroa_idx.i, i64 48, i1 false)
  %20 = atomicrmw volatile add ptr %14, i32 1 seq_cst, align 4
  %21 = load i32, ptr %15, align 8
  %22 = ashr i32 %20, %21
  %23 = icmp ugt i32 %22, 131071
  br i1 %23, label %24, label %26

24:                                               ; preds = %.lr.ph.i
  %25 = load ptr, ptr %17, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %25, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

26:                                               ; preds = %.lr.ph.i
  %27 = zext i32 %22 to i64
  %28 = lshr i64 %27, 9
  %29 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %28
  %30 = load atomic i64, ptr %29 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %30, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %26
  %31 = inttoptr i64 %30 to ptr
  %32 = and i64 %27, 511
  %33 = getelementptr inbounds ptr, ptr %31, i64 %32
  %34 = load atomic i64, ptr %33 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %26
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %35 = atomicrmw volatile xchg ptr %16, i32 1 seq_cst, align 4
  %36 = icmp eq i32 %35, 1
  br i1 %36, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %37 = load atomic i64, ptr %29 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %37, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %39, label %73

39:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %40 = load ptr, ptr %17, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1
  %42 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 28
  %43 = atomicrmw volatile add ptr %42, i64 4096 seq_cst, align 8
  %44 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 2
  %45 = load i64, ptr %44, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %45, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %66, label %46

46:                                               ; preds = %39
  %47 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 26
  br label %48

48:                                               ; preds = %48, %46
  %49 = atomicrmw volatile xchg ptr %47, i32 1 seq_cst, align 4
  %50 = icmp eq i32 %49, 1
  br i1 %50, label %48, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %48
  %51 = load ptr, ptr %41, align 8
  %52 = ptrtoint ptr %51 to i64
  %53 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 1
  %54 = load ptr, ptr %53, align 8
  %55 = ptrtoint ptr %54 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %52
  %56 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %57 = or i64 %56, 4096
  %58 = add i64 %57, %52
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %58, %55
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %59

59:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %60 = add i64 %56, %52
  %61 = inttoptr i64 %60 to ptr
  %62 = getelementptr i8, ptr %51, i64 %56
  %63 = getelementptr inbounds i8, ptr %62, i64 4096
  store ptr %63, ptr %41, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %59, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %61, %59 ]
  %64 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %65 = atomicrmw volatile xchg ptr %47, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %40, i1 noundef zeroext %64, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

66:                                               ; preds = %39
  %67 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 2
  %68 = load ptr, ptr %67, align 8
  %69 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 6
  %70 = load ptr, ptr %69, align 8
  %71 = tail call noundef ptr %68(ptr noundef %70, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %66, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %71, %66 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %72 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %72, ptr %29 release, align 8
  br label %73

73:                                               ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %38, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %74 = and i32 %22, 511
  %75 = zext i32 %74 to i64
  %76 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %75
  %77 = load atomic i64, ptr %76 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %77, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %78, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

78:                                               ; preds = %73
  %79 = load ptr, ptr %17, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1
  %81 = load i64, ptr %18, align 8
  %82 = load i64, ptr %19, align 8
  %83 = mul i64 %82, %81
  %84 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 28
  %85 = atomicrmw volatile add ptr %84, i64 %83 seq_cst, align 8
  %86 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 2
  %87 = load i64, ptr %86, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %87, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %107, label %88

88:                                               ; preds = %78
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 26
  br label %90

90:                                               ; preds = %90, %88
  %91 = atomicrmw volatile xchg ptr %89, i32 1 seq_cst, align 4
  %92 = icmp eq i32 %91, 1
  br i1 %92, label %90, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %90
  %93 = load ptr, ptr %80, align 8
  %94 = ptrtoint ptr %93 to i64
  %95 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 1
  %96 = load ptr, ptr %95, align 8
  %97 = ptrtoint ptr %96 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %94
  %98 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %99 = add i64 %98, %83
  %100 = add i64 %99, %94
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %100, %97
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %101

101:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %102 = add i64 %98, %94
  %103 = inttoptr i64 %102 to ptr
  %104 = getelementptr inbounds i8, ptr %93, i64 %99
  store ptr %104, ptr %80, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %101, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %103, %101 ]
  %105 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %106 = atomicrmw volatile xchg ptr %89, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %79, i1 noundef zeroext %105, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

107:                                              ; preds = %78
  %108 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 2
  %109 = load ptr, ptr %108, align 8
  %110 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 6
  %111 = load ptr, ptr %110, align 8
  %112 = tail call noundef ptr %109(ptr noundef %111, i64 noundef %83, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %107, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %112, %107 ]
  %113 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %113, ptr %76 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %73
  %114 = atomicrmw volatile xchg ptr %16, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %24
  %115 = load i32, ptr %15, align 8
  %116 = ashr i32 %20, %115
  %117 = sext i32 %116 to i64
  %118 = lshr i64 %117, 9
  %119 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %118
  %120 = load atomic i64, ptr %119 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %120, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %121

121:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %122 = inttoptr i64 %120 to ptr
  %123 = and i64 %117, 511
  %124 = getelementptr inbounds ptr, ptr %122, i64 %123
  %125 = load atomic i64, ptr %124 acquire, align 8
  %126 = inttoptr i64 %125 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %121, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %127 = phi ptr [ %126, %121 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %128 = load i64, ptr %19, align 8
  %129 = load i32, ptr %15, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %129
  %130 = xor i32 %notmask.i.i.i.i, -1
  %131 = and i32 %20, %130
  %132 = sext i32 %131 to i64
  %133 = mul i64 %128, %132
  %134 = getelementptr inbounds i8, ptr %127, i64 %133
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %134, ptr nonnull align 8 %0, i64 %128, i1 false)
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @live_hierarchy_poll_58_kernel_3_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.2212, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 58
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @live_hierarchy_poll_58_kernel_4_listgen_S58bitmasked(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %0, align 8
  %1 = alloca %struct.PhysicalCoordinates.2225, align 4
  %2 = alloca %0, align 8
  %3 = getelementptr inbounds %struct.RuntimeContext.2212, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %2)
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 13
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %6, i64 57
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %10 = load i32, ptr %9, align 8
  %11 = getelementptr inbounds ptr, ptr %6, i64 58
  %12 = load ptr, ptr %11, align 8
  %13 = icmp sgt i32 %10, 0
  br i1 %13, label %.lr.ph61.i, label %element_listgen_nonroot.exit

.lr.ph61.i:                                       ; preds = %entry
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  %16 = getelementptr inbounds %0, ptr %0, i64 0, i32 1
  %17 = getelementptr inbounds %0, ptr %0, i64 0, i32 1, i64 1
  %18 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %19 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %20 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 5
  %21 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %22 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 4
  %23 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 6
  %24 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 2
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %2, i64 8
  br label %26

26:                                               ; preds = %._crit_edge.i, %.lr.ph61.i
  %.04359.i = phi i32 [ 0, %.lr.ph61.i ], [ %172, %._crit_edge.i ]
  %27 = load i32, ptr %14, align 8
  %28 = lshr i32 %.04359.i, %27
  %29 = sext i32 %28 to i64
  %30 = lshr i64 %29, 9
  %31 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %30
  %32 = load atomic i64, ptr %31 acquire, align 8
  %.not.i.i.i.i = icmp eq i64 %32, 0
  br i1 %.not.i.i.i.i, label %_ZN11ListManager3getI7ElementEERT_i.exit.i, label %33

33:                                               ; preds = %26
  %34 = inttoptr i64 %32 to ptr
  %35 = and i64 %29, 511
  %36 = getelementptr inbounds ptr, ptr %34, i64 %35
  %37 = load atomic i64, ptr %36 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit.i

_ZN11ListManager3getI7ElementEERT_i.exit.i:       ; preds = %33, %26
  %39 = phi ptr [ %38, %33 ], [ null, %26 ]
  %40 = load i64, ptr %15, align 8
  %41 = load i32, ptr %14, align 8
  %notmask.i.i.i = shl nsw i32 -1, %41
  %42 = xor i32 %notmask.i.i.i, -1
  %43 = and i32 %.04359.i, %42
  %44 = zext i32 %43 to i64
  %45 = mul i64 %40, %44
  %46 = getelementptr inbounds i8, ptr %39, i64 %45
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %0, ptr noundef nonnull align 8 dereferenceable(64) %46, i64 64, i1 false)
  %47 = load i32, ptr %16, align 8
  %48 = load i32, ptr %17, align 4
  %49 = icmp slt i32 %47, %48
  br i1 %49, label %.lr.ph58.i.preheader, label %._crit_edge.i

.lr.ph58.i.preheader:                             ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit.i
  br label %.lr.ph58.i

.lr.ph58.i:                                       ; preds = %.loopexit.i, %.lr.ph58.i.preheader
  %.04457.i = phi i32 [ %171, %.loopexit.i ], [ %47, %.lr.ph58.i.preheader ]
  call fastcc void @S57_refine_coordinates(ptr noundef nonnull %18, ptr noundef nonnull %1, i32 noundef %.04457.i) #1
  %50 = load ptr, ptr %0, align 8
  %51 = shl i32 %.04457.i, 3
  %52 = sext i32 %51 to i64
  %53 = getelementptr i8, ptr %50, i64 %52
  %54 = getelementptr inbounds i8, ptr %53, i64 32
  %55 = load ptr, ptr %54, align 8
  %.not = icmp eq ptr %55, null
  br i1 %.not, label %.loopexit.i, label %.lr.ph.i

.lr.ph.i:                                         ; preds = %.lr.ph58.i
  store ptr %55, ptr %2, align 8
  store <2 x i32> <i32 0, i32 32>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %19, ptr noundef nonnull align 4 dereferenceable(48) %1, i64 48, i1 false)
  %56 = atomicrmw volatile add ptr %20, i32 1 seq_cst, align 4
  %57 = load i32, ptr %21, align 8
  %58 = ashr i32 %56, %57
  %59 = icmp ugt i32 %58, 131071
  br i1 %59, label %60, label %62

60:                                               ; preds = %.lr.ph.i
  %61 = load ptr, ptr %23, align 8
  call fastcc void @taichi_assert_format(ptr noundef %61, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

62:                                               ; preds = %.lr.ph.i
  %63 = zext i32 %58 to i64
  %64 = lshr i64 %63, 9
  %65 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %64
  %66 = load atomic i64, ptr %65 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %66, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %62
  %67 = inttoptr i64 %66 to ptr
  %68 = and i64 %63, 511
  %69 = getelementptr inbounds ptr, ptr %67, i64 %68
  %70 = load atomic i64, ptr %69 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %70, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %62
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %71 = atomicrmw volatile xchg ptr %22, i32 1 seq_cst, align 4
  %72 = icmp eq i32 %71, 1
  br i1 %72, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %73 = load atomic i64, ptr %65 acquire, align 8
  %74 = inttoptr i64 %73 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %73, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %75, label %109

75:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %76 = load ptr, ptr %23, align 8
  %77 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1
  %78 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 28
  %79 = atomicrmw volatile add ptr %78, i64 4096 seq_cst, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 2
  %81 = load i64, ptr %80, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %81, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %102, label %82

82:                                               ; preds = %75
  %83 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 26
  br label %84

84:                                               ; preds = %84, %82
  %85 = atomicrmw volatile xchg ptr %83, i32 1 seq_cst, align 4
  %86 = icmp eq i32 %85, 1
  br i1 %86, label %84, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %84
  %87 = load ptr, ptr %77, align 8
  %88 = ptrtoint ptr %87 to i64
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 1
  %90 = load ptr, ptr %89, align 8
  %91 = ptrtoint ptr %90 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %88
  %92 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %93 = or i64 %92, 4096
  %94 = add i64 %93, %88
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %94, %91
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %95

95:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %96 = add i64 %92, %88
  %97 = inttoptr i64 %96 to ptr
  %98 = getelementptr i8, ptr %87, i64 %92
  %99 = getelementptr inbounds i8, ptr %98, i64 4096
  store ptr %99, ptr %77, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %95, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %97, %95 ]
  %100 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %101 = atomicrmw volatile xchg ptr %83, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %76, i1 noundef zeroext %100, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

102:                                              ; preds = %75
  %103 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 2
  %104 = load ptr, ptr %103, align 8
  %105 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 6
  %106 = load ptr, ptr %105, align 8
  %107 = call noundef ptr %104(ptr noundef %106, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %102, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %107, %102 ]
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %108 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %108, ptr %65 release, align 8
  br label %109

109:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %74, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %110 = and i32 %58, 511
  %111 = zext i32 %110 to i64
  %112 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %111
  %113 = load atomic i64, ptr %112 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %113, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %114, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

114:                                              ; preds = %109
  %115 = load ptr, ptr %23, align 8
  %116 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1
  %117 = load i64, ptr %24, align 8
  %118 = load i64, ptr %25, align 8
  %119 = mul i64 %118, %117
  %120 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 28
  %121 = atomicrmw volatile add ptr %120, i64 %119 seq_cst, align 8
  %122 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 2
  %123 = load i64, ptr %122, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %123, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %143, label %124

124:                                              ; preds = %114
  %125 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 26
  br label %126

126:                                              ; preds = %126, %124
  %127 = atomicrmw volatile xchg ptr %125, i32 1 seq_cst, align 4
  %128 = icmp eq i32 %127, 1
  br i1 %128, label %126, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %126
  %129 = load ptr, ptr %116, align 8
  %130 = ptrtoint ptr %129 to i64
  %131 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 1
  %132 = load ptr, ptr %131, align 8
  %133 = ptrtoint ptr %132 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %130
  %134 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %135 = add i64 %134, %119
  %136 = add i64 %135, %130
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %136, %133
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %137

137:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %138 = add i64 %134, %130
  %139 = inttoptr i64 %138 to ptr
  %140 = getelementptr inbounds i8, ptr %129, i64 %135
  store ptr %140, ptr %116, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %137, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %139, %137 ]
  %141 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %142 = atomicrmw volatile xchg ptr %125, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %115, i1 noundef zeroext %141, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

143:                                              ; preds = %114
  %144 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 2
  %145 = load ptr, ptr %144, align 8
  %146 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 6
  %147 = load ptr, ptr %146, align 8
  %148 = call noundef ptr %145(ptr noundef %147, i64 noundef %119, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %143, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %148, %143 ]
  %149 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %149, ptr %112 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %109
  %150 = atomicrmw volatile xchg ptr %22, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %60
  %151 = load i32, ptr %21, align 8
  %152 = ashr i32 %56, %151
  %153 = sext i32 %152 to i64
  %154 = lshr i64 %153, 9
  %155 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %154
  %156 = load atomic i64, ptr %155 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %156, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %157

157:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %158 = inttoptr i64 %156 to ptr
  %159 = and i64 %153, 511
  %160 = getelementptr inbounds ptr, ptr %158, i64 %159
  %161 = load atomic i64, ptr %160 acquire, align 8
  %162 = inttoptr i64 %161 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %157, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %163 = phi ptr [ %162, %157 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %164 = load i64, ptr %25, align 8
  %165 = load i32, ptr %21, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %165
  %166 = xor i32 %notmask.i.i.i.i, -1
  %167 = and i32 %56, %166
  %168 = sext i32 %167 to i64
  %169 = mul i64 %164, %168
  %170 = getelementptr inbounds i8, ptr %163, i64 %169
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %170, ptr nonnull align 8 %2, i64 %164, i1 false)
  br label %.loopexit.i, !llvm.loop !9

.loopexit.i:                                      ; preds = %_ZN11ListManager6appendEPv.exit.i, %.lr.ph58.i
  %171 = add i32 %.04457.i, 1
  %exitcond.not.i = icmp eq i32 %171, %48
  br i1 %exitcond.not.i, label %._crit_edge.i.loopexit, label %.lr.ph58.i, !llvm.loop !10

._crit_edge.i.loopexit:                           ; preds = %.loopexit.i
  br label %._crit_edge.i

._crit_edge.i:                                    ; preds = %._crit_edge.i.loopexit, %_ZN11ListManager3getI7ElementEERT_i.exit.i
  %172 = add nuw nsw i32 %.04359.i, 1
  %exitcond63.not.i = icmp eq i32 %172, %10
  br i1 %exitcond63.not.i, label %element_listgen_nonroot.exit.loopexit, label %26, !llvm.loop !11

element_listgen_nonroot.exit.loopexit:            ; preds = %._crit_edge.i
  br label %element_listgen_nonroot.exit

element_listgen_nonroot.exit:                     ; preds = %element_listgen_nonroot.exit.loopexit, %entry
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %2)
  ret void
}

; Function Attrs: nounwind
define void @live_hierarchy_poll_58_kernel_5_struct_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.cpu_block_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.RuntimeContext.2212, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 58
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds %struct.ListManager, ptr %6, i64 0, i32 5
  %8 = load i32, ptr %7, align 8
  store ptr %context, ptr %0, align 8
  %9 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  store ptr @function_body, ptr %9, align 8
  %10 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  store ptr %6, ptr %10, align 8
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  store <2 x i32> <i32 32, i32 32>, ptr %11, align 8
  %12 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  store i64 1, ptr %12, align 8
  %13 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 12
  %14 = load ptr, ptr %13, align 8
  %15 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 11
  %16 = load ptr, ptr %15, align 8
  %17 = shl nsw i32 %8, 5
  call void %14(ptr noundef %16, i32 noundef %17, i32 noundef 2, ptr noundef nonnull %0, ptr noundef nonnull @cpu_struct_for_block_helper) #1
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %0)
  ret void
}

; Function Attrs: nounwind
define internal void @function_body(ptr %0, ptr nocapture readnone %1, ptr nocapture readonly %2, i32 %3, i32 %4) #1 {
allocs:
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %8 = icmp slt i32 %3, %4
  br i1 %8, label %loop_body.lr.ph, label %func_exit

loop_body.lr.ph:                                  ; preds = %allocs
  %9 = getelementptr inbounds %struct.RuntimeContext.2212, ptr %0, i64 0, i32 1
  br label %loop_body

loop_body:                                        ; preds = %loop_body_tail, %loop_body.lr.ph
  %.0115331 = phi i32 [ %3, %loop_body.lr.ph ], [ %22, %loop_body_tail ]
  %10 = and i32 %.0115331, 31
  %11 = load i32, ptr %7, align 4
  %12 = load ptr, ptr %2, align 8
  %13 = getelementptr inbounds i8, ptr %12, i64 32
  %14 = sdiv i32 %.0115331, 8
  %15 = sext i32 %14 to i64
  %16 = getelementptr inbounds i8, ptr %13, i64 %15
  %17 = load i8, ptr %16, align 1
  %18 = zext i8 %17 to i32
  %19 = and i32 %.0115331, 7
  %20 = shl nuw nsw i32 1, %19
  %21 = and i32 %20, %18
  %.not272 = icmp eq i32 %21, 0
  br i1 %.not272, label %loop_body_tail, label %struct_for_body_body

loop_body_tail.loopexit:                          ; preds = %after_if180
  br label %loop_body_tail

loop_body_tail:                                   ; preds = %after_if82, %after_if76, %struct_for_body_body, %loop_body_tail.loopexit, %loop_body
  %22 = add nsw i32 %.0115331, 1
  %exitcond378.not = icmp eq i32 %22, %4
  br i1 %exitcond378.not, label %func_exit.loopexit, label %loop_body

func_exit.loopexit:                               ; preds = %loop_body_tail
  br label %func_exit

func_exit:                                        ; preds = %func_exit.loopexit, %allocs
  ret void

struct_for_body_body:                             ; preds = %loop_body
  %23 = shl i32 %11, 5
  %24 = or i32 %23, %10
  %25 = load ptr, ptr %0, align 8
  %26 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %25, i64 0, i32 18, i32 1
  %27 = load ptr, ptr %26, align 8
  %28 = sext i32 %24 to i64
  %29 = getelementptr i32, ptr %27, i64 %28
  %30 = load i32, ptr %29, align 4
  %31 = icmp sgt i32 %30, -1
  %32 = load ptr, ptr %9, align 8
  %33 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 16
  %34 = load ptr, ptr %33, align 8
  %35 = load i32, ptr %34, align 4
  %36 = icmp slt i32 %35, 0
  %37 = icmp eq i32 %30, %35
  %38 = or i1 %36, %37
  %39 = and i1 %31, %38
  br i1 %39, label %true_block, label %loop_body_tail

true_block:                                       ; preds = %struct_for_body_body
  %40 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 7
  %41 = load ptr, ptr %40, align 8
  %42 = getelementptr inbounds ptr, ptr %41, i64 5
  %43 = load ptr, ptr %42, align 8
  %getch.i = getelementptr %1, ptr %43, i64 0, i32 1
  %44 = shl i32 %11, 3
  %45 = and i32 %44, 1073741816
  %46 = zext i32 %45 to i64
  %47 = getelementptr i8, ptr %getch.i, i64 %46
  %48 = getelementptr inbounds i8, ptr %47, i64 32
  %49 = load ptr, ptr %48, align 8
  %50 = icmp eq ptr %49, null
  br i1 %50, label %51, label %Pointer_lookup_element.exit169

51:                                               ; preds = %true_block
  %52 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 15
  %53 = load ptr, ptr %52, align 8
  %54 = getelementptr inbounds ptr, ptr %53, i64 57
  %55 = load ptr, ptr %54, align 8
  br label %Pointer_lookup_element.exit169

Pointer_lookup_element.exit169:                   ; preds = %51, %true_block
  %.0.i168 = phi ptr [ %55, %51 ], [ %49, %true_block ]
  %56 = getelementptr inbounds i8, ptr %.0.i168, i64 32
  %57 = shl nuw i32 1, %10
  %58 = xor i32 %57, -1
  %59 = atomicrmw volatile and ptr %56, i32 %58 seq_cst, align 4
  %60 = load ptr, ptr %0, align 8
  %61 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %60, i64 0, i32 29, i32 1
  %62 = load ptr, ptr %61, align 8
  %63 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %60, i64 0, i32 29, i32 0, i32 1
  %64 = getelementptr i32, ptr %62, i64 %28
  store i32 1, ptr %64, align 4
  %65 = load ptr, ptr %61, align 8
  %66 = load i32, ptr %63, align 4
  %67 = sext i32 %66 to i64
  %68 = add nsw i64 %67, %28
  %69 = getelementptr i32, ptr %65, i64 %68
  store i32 0, ptr %69, align 4
  %70 = load ptr, ptr %0, align 8
  %71 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %70, i64 0, i32 8, i32 1
  %72 = load ptr, ptr %71, align 8
  %73 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %70, i64 0, i32 8, i32 0, i32 1
  %74 = load i32, ptr %73, align 4
  %75 = sext i32 %74 to i64
  %76 = shl nsw i64 %75, 2
  %77 = add nsw i64 %76, %28
  %78 = getelementptr double, ptr %72, i64 %77
  store double 0.000000e+00, ptr %78, align 8
  %79 = load ptr, ptr %71, align 8
  %80 = load i32, ptr %73, align 4
  %81 = sext i32 %80 to i64
  %82 = mul nsw i64 %81, 5
  %83 = add nsw i64 %82, %28
  %84 = getelementptr double, ptr %79, i64 %83
  store double 0.000000e+00, ptr %84, align 8
  %85 = load ptr, ptr %71, align 8
  %86 = load i32, ptr %73, align 4
  %87 = sext i32 %86 to i64
  %88 = mul nsw i64 %87, 6
  %89 = add nsw i64 %88, %28
  %90 = getelementptr double, ptr %85, i64 %89
  store double 0.000000e+00, ptr %90, align 8
  %91 = load ptr, ptr %71, align 8
  %92 = load i32, ptr %73, align 4
  %93 = sext i32 %92 to i64
  %94 = mul nsw i64 %93, 7
  %95 = add nsw i64 %94, %28
  %96 = getelementptr double, ptr %91, i64 %95
  store double 0.000000e+00, ptr %96, align 8
  %97 = load ptr, ptr %0, align 8
  %98 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %97, i64 0, i32 28, i32 1
  %99 = load ptr, ptr %98, align 8
  %100 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %97, i64 0, i32 28, i32 0, i32 1
  %101 = zext i32 %30 to i64
  %102 = getelementptr i64, ptr %99, i64 %101
  %103 = atomicrmw add ptr %102, i64 1 seq_cst, align 8
  %104 = load ptr, ptr %0, align 8
  %105 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %104, i64 0, i32 14, i32 1
  %106 = load ptr, ptr %105, align 8
  %107 = getelementptr i64, ptr %106, i64 1
  %108 = atomicrmw add ptr %107, i64 1 seq_cst, align 8
  %109 = load ptr, ptr %0, align 8
  %110 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %109, i64 0, i32 15, i32 1
  %111 = load ptr, ptr %110, align 8
  %112 = getelementptr i64, ptr %111, i64 7
  %113 = atomicrmw add ptr %112, i64 1 seq_cst, align 8
  %114 = load ptr, ptr %110, align 8
  %115 = getelementptr i64, ptr %114, i64 13
  %116 = atomicrmw add ptr %115, i64 1 seq_cst, align 8
  %117 = load ptr, ptr %110, align 8
  %118 = getelementptr i64, ptr %117, i64 6
  %119 = atomicrmw add ptr %118, i64 1 seq_cst, align 8
  %120 = load ptr, ptr %0, align 8
  %121 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %120, i64 0, i32 1, i32 1
  %122 = load ptr, ptr %121, align 8
  %123 = getelementptr i32, ptr %122, i64 %101
  %124 = atomicrmw or ptr %123, i32 0 seq_cst, align 4
  %125 = shl i32 %124, 2
  %126 = load ptr, ptr %0, align 8
  %127 = getelementptr { { i32, i32 }, ptr }, ptr %126, i64 0, i32 1
  %128 = load ptr, ptr %127, align 8
  %129 = getelementptr { { i32, i32 }, ptr }, ptr %126, i64 0, i32 0, i32 1
  %130 = load i32, ptr %129, align 4
  %131 = sext i32 %125 to i64
  %132 = sext i32 %130 to i64
  %133 = mul nsw i64 %132, %131
  %134 = add nsw i64 %133, %101
  %135 = getelementptr double, ptr %128, i64 %134
  %136 = load double, ptr %135, align 8
  %137 = or i32 %125, 1
  %138 = sext i32 %137 to i64
  %139 = mul nsw i64 %132, %138
  %140 = add nsw i64 %139, %101
  %141 = getelementptr double, ptr %128, i64 %140
  %142 = load double, ptr %141, align 8
  %143 = or i32 %125, 2
  %144 = sext i32 %143 to i64
  %145 = mul nsw i64 %132, %144
  %146 = add nsw i64 %145, %101
  %147 = getelementptr double, ptr %128, i64 %146
  %148 = load double, ptr %147, align 8
  %149 = or i32 %125, 3
  %150 = sext i32 %149 to i64
  %151 = mul nsw i64 %132, %150
  %152 = add nsw i64 %151, %101
  %153 = getelementptr double, ptr %128, i64 %152
  %154 = load double, ptr %153, align 8
  %155 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %126, i64 0, i32 2, i32 1
  %156 = load ptr, ptr %155, align 8
  %157 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %126, i64 0, i32 2, i32 0, i32 1
  %158 = load i32, ptr %157, align 4
  %159 = sext i32 %158 to i64
  %160 = shl nsw i64 %159, 1
  %161 = add nsw i64 %160, %101
  %162 = getelementptr i32, ptr %156, i64 %161
  %163 = load i32, ptr %162, align 4
  %.not = icmp eq i32 %163, 0
  br i1 %.not, label %false_block2, label %true_block1

true_block1:                                      ; preds = %Pointer_lookup_element.exit169
  %164 = add nsw i64 %159, %101
  %165 = getelementptr i32, ptr %156, i64 %164
  %166 = load i32, ptr %165, align 4
  %167 = load ptr, ptr %105, align 8
  %168 = getelementptr i64, ptr %167, i64 4
  %169 = load ptr, ptr %110, align 8
  %170 = getelementptr i64, ptr %169, i64 12
  %171 = icmp sgt i32 %163, 0
  br i1 %171, label %for_loop_body.lr.ph, label %after_if3

for_loop_body.lr.ph:                              ; preds = %true_block1
  %172 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %126, i64 0, i32 3, i32 1
  %wide.trip.count = zext i32 %163 to i64
  %173 = zext i32 %166 to i64
  br label %for_loop_body

false_block2:                                     ; preds = %Pointer_lookup_element.exit169
  %174 = mul nsw i64 %159, 3
  %175 = add nsw i64 %174, %101
  %176 = getelementptr i32, ptr %156, i64 %175
  %177 = load i32, ptr %176, align 4
  %178 = shl nsw i64 %159, 2
  %179 = add nsw i64 %178, %101
  %180 = getelementptr i32, ptr %156, i64 %179
  %181 = load i32, ptr %180, align 4
  %182 = load ptr, ptr %105, align 8
  %183 = getelementptr i64, ptr %182, i64 3
  %184 = load ptr, ptr %110, align 8
  %185 = getelementptr i64, ptr %184, i64 12
  %186 = icmp sgt i32 %181, 0
  br i1 %186, label %for_loop_body28.lr.ph, label %after_if3

for_loop_body28.lr.ph:                            ; preds = %false_block2
  %187 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %126, i64 0, i32 4, i32 1
  %188 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %126, i64 0, i32 7, i32 1
  %189 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %126, i64 0, i32 7, i32 0, i32 1
  %190 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %126, i64 0, i32 5, i32 1
  %191 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %126, i64 0, i32 5, i32 0, i32 1
  %wide.trip.count356 = zext i32 %181 to i64
  %192 = zext i32 %177 to i64
  br label %for_loop_body28

after_if3.loopexit:                               ; preds = %after_if46
  br label %after_if3

after_if3.loopexit465:                            ; preds = %after_if18
  br label %after_if3

after_if3:                                        ; preds = %after_if3.loopexit465, %after_if3.loopexit, %false_block2, %true_block1
  %.0112 = phi double [ 0.000000e+00, %false_block2 ], [ 0.000000e+00, %true_block1 ], [ %392, %after_if3.loopexit ], [ %302, %after_if3.loopexit465 ]
  %.0107 = phi double [ 0.000000e+00, %false_block2 ], [ 0.000000e+00, %true_block1 ], [ %spec.select122, %after_if3.loopexit ], [ %spec.select, %after_if3.loopexit465 ]
  %.0104 = phi double [ 0.000000e+00, %false_block2 ], [ 0.000000e+00, %true_block1 ], [ %385, %after_if3.loopexit ], [ %295, %after_if3.loopexit465 ]
  %.099 = phi double [ 0.000000e+00, %false_block2 ], [ 0.000000e+00, %true_block1 ], [ %.4103, %after_if3.loopexit ], [ %.2101, %after_if3.loopexit465 ]
  %.096 = phi double [ 0.000000e+00, %false_block2 ], [ 0.000000e+00, %true_block1 ], [ %388, %after_if3.loopexit ], [ %298, %after_if3.loopexit465 ]
  %.093 = phi double [ 0.000000e+00, %false_block2 ], [ 0.000000e+00, %true_block1 ], [ %.4, %after_if3.loopexit ], [ %.295, %after_if3.loopexit465 ]
  %.090 = phi double [ 0.000000e+00, %false_block2 ], [ 0.000000e+00, %true_block1 ], [ %391, %after_if3.loopexit ], [ %301, %after_if3.loopexit465 ]
  %193 = fcmp one double %.0112, %154
  %194 = fdiv double %.0104, %.0112
  %195 = fadd double %.0107, %194
  %196 = bitcast double %195 to i64
  %197 = load ptr, ptr %0, align 8
  %198 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %197, i64 0, i32 6, i32 1
  %199 = load ptr, ptr %198, align 8
  %200 = getelementptr i64, ptr %199, i64 %101
  %201 = load i64, ptr %200, align 8
  %202 = and i64 %201, %196
  %203 = bitcast i64 %202 to double
  %204 = and i64 %196, 9223372036854775807
  %205 = and i64 %196, 9218868437227405312
  %206 = icmp eq i64 %204, 0
  %207 = icmp ne i64 %205, 0
  %208 = icmp ne i64 %205, 9218868437227405312
  %209 = and i1 %207, %208
  %210 = or i1 %206, %209
  br i1 %210, label %after_if58, label %true_block56

for_loop_body:                                    ; preds = %after_if18, %for_loop_body.lr.ph
  %indvars.iv = phi i64 [ 0, %for_loop_body.lr.ph ], [ %indvars.iv.next, %after_if18 ]
  %.191280 = phi double [ 0.000000e+00, %for_loop_body.lr.ph ], [ %301, %after_if18 ]
  %.194279 = phi double [ 0.000000e+00, %for_loop_body.lr.ph ], [ %.295, %after_if18 ]
  %.197278 = phi double [ 0.000000e+00, %for_loop_body.lr.ph ], [ %298, %after_if18 ]
  %.1100277 = phi double [ 0.000000e+00, %for_loop_body.lr.ph ], [ %.2101, %after_if18 ]
  %.1105276 = phi double [ 0.000000e+00, %for_loop_body.lr.ph ], [ %295, %after_if18 ]
  %.1108275 = phi double [ 0.000000e+00, %for_loop_body.lr.ph ], [ %spec.select, %after_if18 ]
  %.1113274 = phi double [ 0.000000e+00, %for_loop_body.lr.ph ], [ %302, %after_if18 ]
  %211 = add nuw nsw i64 %173, %indvars.iv
  %212 = load ptr, ptr %172, align 8
  %tmp = trunc i64 %211 to i32
  %213 = sext i32 %tmp to i64
  %214 = getelementptr i32, ptr %212, i64 %213
  %215 = load i32, ptr %214, align 4
  %216 = load ptr, ptr %121, align 8
  %217 = sext i32 %215 to i64
  %218 = getelementptr i32, ptr %216, i64 %217
  %219 = atomicrmw or ptr %218, i32 0 seq_cst, align 4
  %220 = shl i32 %219, 2
  %221 = load ptr, ptr %127, align 8
  %222 = load i32, ptr %129, align 4
  %223 = sext i32 %220 to i64
  %224 = sext i32 %222 to i64
  %225 = mul nsw i64 %224, %223
  %226 = add nsw i64 %225, %217
  %227 = getelementptr double, ptr %221, i64 %226
  %228 = load double, ptr %227, align 8
  %229 = or i32 %220, 1
  %230 = sext i32 %229 to i64
  %231 = mul nsw i64 %230, %224
  %232 = add nsw i64 %231, %217
  %233 = getelementptr double, ptr %221, i64 %232
  %234 = load double, ptr %233, align 8
  %235 = or i32 %220, 2
  %236 = sext i32 %235 to i64
  %237 = mul nsw i64 %236, %224
  %238 = add nsw i64 %237, %217
  %239 = getelementptr double, ptr %221, i64 %238
  %240 = load double, ptr %239, align 8
  %241 = or i32 %220, 3
  %242 = sext i32 %241 to i64
  %243 = mul nsw i64 %242, %224
  %244 = add nsw i64 %243, %217
  %245 = getelementptr double, ptr %221, i64 %244
  %246 = load double, ptr %245, align 8
  %247 = atomicrmw add ptr %168, i64 1 seq_cst, align 8
  %248 = atomicrmw add ptr %170, i64 1 seq_cst, align 8
  %249 = bitcast double %228 to i64
  %250 = and i64 %249, 9223372036854775807
  %251 = and i64 %249, 9218868437227405312
  %252 = icmp eq i64 %250, 0
  %253 = icmp ne i64 %251, 0
  %254 = icmp ne i64 %251, 9218868437227405312
  %255 = and i1 %253, %254
  %256 = or i1 %252, %255
  br i1 %256, label %after_if6, label %true_block4

true_block4:                                      ; preds = %for_loop_body
  %257 = load ptr, ptr %105, align 8
  %258 = atomicrmw add ptr %257, i64 1 seq_cst, align 8
  br label %after_if6

after_if6:                                        ; preds = %true_block4, %for_loop_body
  %259 = bitcast double %234 to i64
  %260 = and i64 %259, 9223372036854775807
  %261 = and i64 %259, 9218868437227405312
  %262 = icmp eq i64 %260, 0
  %263 = icmp ne i64 %261, 0
  %264 = icmp ne i64 %261, 9218868437227405312
  %265 = and i1 %263, %264
  %266 = or i1 %262, %265
  br i1 %266, label %after_if9, label %true_block7

true_block7:                                      ; preds = %after_if6
  %267 = load ptr, ptr %105, align 8
  %268 = atomicrmw add ptr %267, i64 1 seq_cst, align 8
  br label %after_if9

after_if9:                                        ; preds = %true_block7, %after_if6
  %269 = bitcast double %240 to i64
  %270 = and i64 %269, 9223372036854775807
  %271 = and i64 %269, 9218868437227405312
  %272 = icmp eq i64 %270, 0
  %273 = icmp ne i64 %271, 0
  %274 = icmp ne i64 %271, 9218868437227405312
  %275 = and i1 %273, %274
  %276 = or i1 %272, %275
  br i1 %276, label %after_if12, label %true_block10

true_block10:                                     ; preds = %after_if9
  %277 = load ptr, ptr %105, align 8
  %278 = atomicrmw add ptr %277, i64 1 seq_cst, align 8
  br label %after_if12

after_if12:                                       ; preds = %true_block10, %after_if9
  %279 = bitcast double %246 to i64
  %280 = and i64 %279, 9223372036854775807
  %281 = and i64 %279, 9218868437227405312
  %282 = icmp eq i64 %280, 0
  %283 = icmp ne i64 %281, 0
  %284 = icmp ne i64 %281, 9218868437227405312
  %285 = and i1 %283, %284
  %286 = or i1 %282, %285
  br i1 %286, label %after_if15, label %true_block13

true_block13:                                     ; preds = %after_if12
  %287 = load ptr, ptr %105, align 8
  %288 = atomicrmw add ptr %287, i64 1 seq_cst, align 8
  br label %after_if15

after_if15:                                       ; preds = %true_block13, %after_if12
  %289 = fcmp ugt double %246, 0.000000e+00
  br i1 %289, label %after_if18, label %true_block16

true_block16:                                     ; preds = %after_if15
  %290 = load ptr, ptr %105, align 8
  %291 = atomicrmw add ptr %290, i64 1 seq_cst, align 8
  br label %after_if18

after_if18:                                       ; preds = %true_block16, %after_if15
  %292 = icmp eq i64 %indvars.iv, 0
  %spec.select = select i1 %292, double %228, double %.1108275
  %293 = fsub double %228, %spec.select
  %294 = fmul double %293, %246
  %295 = fadd double %.1105276, %294
  %.2101 = select i1 %292, double %234, double %.1100277
  %296 = fsub double %234, %.2101
  %297 = fmul double %246, %296
  %298 = fadd double %.197278, %297
  %.295 = select i1 %292, double %240, double %.194279
  %299 = fsub double %240, %.295
  %300 = fmul double %246, %299
  %301 = fadd double %.191280, %300
  %302 = fadd double %.1113274, %246
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %wide.trip.count, %indvars.iv.next
  br i1 %exitcond.not, label %after_if3.loopexit465, label %for_loop_body, !llvm.loop !12

for_loop_body28:                                  ; preds = %after_if46, %for_loop_body28.lr.ph
  %indvars.iv353 = phi i64 [ 0, %for_loop_body28.lr.ph ], [ %indvars.iv.next354, %after_if46 ]
  %.292294 = phi double [ 0.000000e+00, %for_loop_body28.lr.ph ], [ %391, %after_if46 ]
  %.3293 = phi double [ 0.000000e+00, %for_loop_body28.lr.ph ], [ %.4, %after_if46 ]
  %.298292 = phi double [ 0.000000e+00, %for_loop_body28.lr.ph ], [ %388, %after_if46 ]
  %.3102291 = phi double [ 0.000000e+00, %for_loop_body28.lr.ph ], [ %.4103, %after_if46 ]
  %.2106290 = phi double [ 0.000000e+00, %for_loop_body28.lr.ph ], [ %385, %after_if46 ]
  %.3110289 = phi double [ 0.000000e+00, %for_loop_body28.lr.ph ], [ %spec.select122, %after_if46 ]
  %.2114288 = phi double [ 0.000000e+00, %for_loop_body28.lr.ph ], [ %392, %after_if46 ]
  %303 = add nuw nsw i64 %192, %indvars.iv353
  %304 = load ptr, ptr %187, align 8
  %tmp466 = trunc i64 %303 to i32
  %305 = sext i32 %tmp466 to i64
  %306 = getelementptr i32, ptr %304, i64 %305
  %307 = load i32, ptr %306, align 4
  %308 = load ptr, ptr %188, align 8
  %309 = load i32, ptr %189, align 4
  %310 = sext i32 %309 to i64
  %311 = sext i32 %307 to i64
  %312 = getelementptr double, ptr %308, i64 %311
  %313 = load double, ptr %312, align 8
  %314 = add nsw i64 %310, %311
  %315 = getelementptr double, ptr %308, i64 %314
  %316 = load double, ptr %315, align 8
  %317 = shl nsw i64 %310, 1
  %318 = add nsw i64 %317, %311
  %319 = getelementptr double, ptr %308, i64 %318
  %320 = load double, ptr %319, align 8
  %321 = mul nsw i64 %310, 6
  %322 = add nsw i64 %321, %311
  %323 = getelementptr double, ptr %308, i64 %322
  %324 = load double, ptr %323, align 8
  %325 = load ptr, ptr %190, align 8
  %326 = load i32, ptr %191, align 4
  %327 = sext i32 %326 to i64
  %328 = getelementptr i64, ptr %325, i64 %305
  %329 = load i64, ptr %328, align 8
  %330 = uitofp i64 %329 to double
  %331 = add nsw i64 %327, %305
  %332 = getelementptr i64, ptr %325, i64 %331
  %333 = load i64, ptr %332, align 8
  %334 = uitofp i64 %333 to double
  %335 = fdiv double %330, %334
  %336 = fmul double %324, %335
  %337 = atomicrmw add ptr %183, i64 1 seq_cst, align 8
  %338 = atomicrmw add ptr %185, i64 1 seq_cst, align 8
  %339 = bitcast double %313 to i64
  %340 = and i64 %339, 9223372036854775807
  %341 = and i64 %339, 9218868437227405312
  %342 = icmp eq i64 %340, 0
  %343 = icmp ne i64 %341, 0
  %344 = icmp ne i64 %341, 9218868437227405312
  %345 = and i1 %343, %344
  %346 = or i1 %342, %345
  br i1 %346, label %after_if34, label %true_block32

true_block32:                                     ; preds = %for_loop_body28
  %347 = load ptr, ptr %105, align 8
  %348 = atomicrmw add ptr %347, i64 1 seq_cst, align 8
  br label %after_if34

after_if34:                                       ; preds = %true_block32, %for_loop_body28
  %349 = bitcast double %316 to i64
  %350 = and i64 %349, 9223372036854775807
  %351 = and i64 %349, 9218868437227405312
  %352 = icmp eq i64 %350, 0
  %353 = icmp ne i64 %351, 0
  %354 = icmp ne i64 %351, 9218868437227405312
  %355 = and i1 %353, %354
  %356 = or i1 %352, %355
  br i1 %356, label %after_if37, label %true_block35

true_block35:                                     ; preds = %after_if34
  %357 = load ptr, ptr %105, align 8
  %358 = atomicrmw add ptr %357, i64 1 seq_cst, align 8
  br label %after_if37

after_if37:                                       ; preds = %true_block35, %after_if34
  %359 = bitcast double %320 to i64
  %360 = and i64 %359, 9223372036854775807
  %361 = and i64 %359, 9218868437227405312
  %362 = icmp eq i64 %360, 0
  %363 = icmp ne i64 %361, 0
  %364 = icmp ne i64 %361, 9218868437227405312
  %365 = and i1 %363, %364
  %366 = or i1 %362, %365
  br i1 %366, label %after_if40, label %true_block38

true_block38:                                     ; preds = %after_if37
  %367 = load ptr, ptr %105, align 8
  %368 = atomicrmw add ptr %367, i64 1 seq_cst, align 8
  br label %after_if40

after_if40:                                       ; preds = %true_block38, %after_if37
  %369 = bitcast double %336 to i64
  %370 = and i64 %369, 9223372036854775807
  %371 = and i64 %369, 9218868437227405312
  %372 = icmp eq i64 %370, 0
  %373 = icmp ne i64 %371, 0
  %374 = icmp ne i64 %371, 9218868437227405312
  %375 = and i1 %373, %374
  %376 = or i1 %372, %375
  br i1 %376, label %after_if43, label %true_block41

true_block41:                                     ; preds = %after_if40
  %377 = load ptr, ptr %105, align 8
  %378 = atomicrmw add ptr %377, i64 1 seq_cst, align 8
  br label %after_if43

after_if43:                                       ; preds = %true_block41, %after_if40
  %379 = fcmp ugt double %336, 0.000000e+00
  br i1 %379, label %after_if46, label %true_block44

true_block44:                                     ; preds = %after_if43
  %380 = load ptr, ptr %105, align 8
  %381 = atomicrmw add ptr %380, i64 1 seq_cst, align 8
  br label %after_if46

after_if46:                                       ; preds = %true_block44, %after_if43
  %382 = icmp eq i64 %indvars.iv353, 0
  %spec.select122 = select i1 %382, double %313, double %.3110289
  %383 = fsub double %313, %spec.select122
  %384 = fmul double %383, %336
  %385 = fadd double %.2106290, %384
  %.4103 = select i1 %382, double %316, double %.3102291
  %386 = fsub double %316, %.4103
  %387 = fmul double %386, %336
  %388 = fadd double %.298292, %387
  %.4 = select i1 %382, double %320, double %.3293
  %389 = fsub double %320, %.4
  %390 = fmul double %389, %336
  %391 = fadd double %.292294, %390
  %392 = fadd double %.2114288, %336
  %indvars.iv.next354 = add nuw nsw i64 %indvars.iv353, 1
  %exitcond357.not = icmp eq i64 %wide.trip.count356, %indvars.iv.next354
  br i1 %exitcond357.not, label %after_if3.loopexit, label %for_loop_body28, !llvm.loop !13

true_block56:                                     ; preds = %after_if3
  %393 = load ptr, ptr %105, align 8
  %394 = atomicrmw add ptr %393, i64 1 seq_cst, align 8
  br label %after_if58

after_if58:                                       ; preds = %true_block56, %after_if3
  %395 = and i64 %202, 9223372036854775807
  %396 = and i64 %202, 9218868437227405312
  %397 = icmp eq i64 %395, 0
  %398 = icmp ne i64 %396, 0
  %399 = icmp ne i64 %396, 9218868437227405312
  %400 = and i1 %398, %399
  %401 = or i1 %397, %400
  br i1 %401, label %after_if61, label %true_block59

true_block59:                                     ; preds = %after_if58
  %402 = load ptr, ptr %105, align 8
  %403 = atomicrmw add ptr %402, i64 1 seq_cst, align 8
  br label %after_if61

after_if61:                                       ; preds = %true_block59, %after_if58
  %404 = fcmp one double %136, %203
  %405 = or i1 %193, %404
  %406 = fdiv double %.096, %.0112
  %407 = fadd double %.099, %406
  %408 = bitcast double %407 to i64
  %409 = and i64 %201, %408
  %410 = bitcast i64 %409 to double
  %411 = and i64 %408, 9223372036854775807
  %412 = and i64 %408, 9218868437227405312
  %413 = icmp eq i64 %411, 0
  %414 = icmp ne i64 %412, 0
  %415 = icmp ne i64 %412, 9218868437227405312
  %416 = and i1 %414, %415
  %417 = or i1 %413, %416
  br i1 %417, label %after_if64, label %true_block62

true_block62:                                     ; preds = %after_if61
  %418 = load ptr, ptr %105, align 8
  %419 = atomicrmw add ptr %418, i64 1 seq_cst, align 8
  br label %after_if64

after_if64:                                       ; preds = %true_block62, %after_if61
  %420 = and i64 %409, 9223372036854775807
  %421 = and i64 %409, 9218868437227405312
  %422 = icmp eq i64 %420, 0
  %423 = icmp ne i64 %421, 0
  %424 = icmp ne i64 %421, 9218868437227405312
  %425 = and i1 %423, %424
  %426 = or i1 %422, %425
  br i1 %426, label %after_if67, label %true_block65

true_block65:                                     ; preds = %after_if64
  %427 = load ptr, ptr %105, align 8
  %428 = atomicrmw add ptr %427, i64 1 seq_cst, align 8
  br label %after_if67

after_if67:                                       ; preds = %true_block65, %after_if64
  %429 = fcmp one double %142, %410
  %430 = or i1 %429, %405
  %431 = fdiv double %.090, %.0112
  %432 = fadd double %.093, %431
  %433 = bitcast double %432 to i64
  %434 = and i64 %201, %433
  %435 = bitcast i64 %434 to double
  %436 = and i64 %433, 9223372036854775807
  %437 = and i64 %433, 9218868437227405312
  %438 = icmp eq i64 %436, 0
  %439 = icmp ne i64 %437, 0
  %440 = icmp ne i64 %437, 9218868437227405312
  %441 = and i1 %439, %440
  %442 = or i1 %438, %441
  br i1 %442, label %after_if70, label %true_block68

true_block68:                                     ; preds = %after_if67
  %443 = load ptr, ptr %105, align 8
  %444 = atomicrmw add ptr %443, i64 1 seq_cst, align 8
  br label %after_if70

after_if70:                                       ; preds = %true_block68, %after_if67
  %445 = and i64 %434, 9223372036854775807
  %446 = and i64 %434, 9218868437227405312
  %447 = icmp eq i64 %445, 0
  %448 = icmp ne i64 %446, 0
  %449 = icmp ne i64 %446, 9218868437227405312
  %450 = and i1 %448, %449
  %451 = or i1 %447, %450
  br i1 %451, label %after_if73, label %true_block71

true_block71:                                     ; preds = %after_if70
  %452 = load ptr, ptr %105, align 8
  %453 = atomicrmw add ptr %452, i64 1 seq_cst, align 8
  br label %after_if73

after_if73:                                       ; preds = %true_block71, %after_if70
  %454 = fcmp one double %148, %435
  %455 = or i1 %454, %430
  %456 = bitcast double %.0112 to i64
  %457 = and i64 %456, 9223372036854775807
  %458 = and i64 %456, 9218868437227405312
  %459 = icmp eq i64 %457, 0
  %460 = icmp ne i64 %458, 0
  %461 = icmp ne i64 %458, 9218868437227405312
  %462 = and i1 %460, %461
  %463 = or i1 %459, %462
  br i1 %463, label %after_if76, label %true_block74

true_block74:                                     ; preds = %after_if73
  %464 = load ptr, ptr %105, align 8
  %465 = atomicrmw add ptr %464, i64 1 seq_cst, align 8
  br label %after_if76

after_if76:                                       ; preds = %true_block74, %after_if73
  br i1 %455, label %true_block77, label %loop_body_tail

true_block77:                                     ; preds = %after_if76
  store i32 1, ptr %69, align 4
  %466 = load ptr, ptr %0, align 8
  %467 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %466, i64 0, i32 13, i32 1
  %468 = load ptr, ptr %467, align 8
  %469 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %466, i64 0, i32 13, i32 0, i32 1
  %470 = getelementptr double, ptr %468, i64 %101
  store double %136, ptr %470, align 8
  %471 = xor i32 %125, 4
  %472 = load ptr, ptr %127, align 8
  %473 = load i32, ptr %129, align 4
  %474 = sext i32 %471 to i64
  %475 = sext i32 %473 to i64
  %476 = mul nsw i64 %475, %474
  %477 = add i64 %476, %101
  %478 = getelementptr double, ptr %472, i64 %477
  store i64 %202, ptr %478, align 8
  %479 = load ptr, ptr %71, align 8
  %480 = getelementptr double, ptr %479, i64 %28
  store i64 %202, ptr %480, align 8
  %481 = load ptr, ptr %0, align 8
  %482 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %481, i64 0, i32 16, i32 1
  %483 = load ptr, ptr %482, align 8
  %484 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %481, i64 0, i32 16, i32 0, i32 1
  %485 = load i32, ptr %484, align 4
  %486 = sext i32 %485 to i64
  %487 = mul nsw i64 %486, 3
  %488 = add nsw i64 %487, %28
  %489 = getelementptr double, ptr %483, i64 %488
  store double %136, ptr %489, align 8
  %490 = load ptr, ptr %467, align 8
  %491 = load i32, ptr %469, align 4
  %492 = sext i32 %491 to i64
  %493 = add nsw i64 %492, %101
  %494 = getelementptr double, ptr %490, i64 %493
  store double %142, ptr %494, align 8
  %495 = or i32 %471, 1
  %496 = load ptr, ptr %127, align 8
  %497 = load i32, ptr %129, align 4
  %498 = sext i32 %495 to i64
  %499 = sext i32 %497 to i64
  %500 = mul nsw i64 %499, %498
  %501 = add i64 %500, %101
  %502 = getelementptr double, ptr %496, i64 %501
  store i64 %409, ptr %502, align 8
  %503 = load ptr, ptr %71, align 8
  %504 = load i32, ptr %73, align 4
  %505 = sext i32 %504 to i64
  %506 = add nsw i64 %505, %28
  %507 = getelementptr double, ptr %503, i64 %506
  store i64 %409, ptr %507, align 8
  %508 = load ptr, ptr %482, align 8
  %509 = load i32, ptr %484, align 4
  %510 = sext i32 %509 to i64
  %511 = shl nsw i64 %510, 2
  %512 = add nsw i64 %511, %28
  %513 = getelementptr double, ptr %508, i64 %512
  store double %142, ptr %513, align 8
  %514 = load ptr, ptr %467, align 8
  %515 = load i32, ptr %469, align 4
  %516 = sext i32 %515 to i64
  %517 = shl nsw i64 %516, 1
  %518 = add nsw i64 %517, %101
  %519 = getelementptr double, ptr %514, i64 %518
  store double %148, ptr %519, align 8
  %520 = or i32 %471, 2
  %521 = load ptr, ptr %127, align 8
  %522 = load i32, ptr %129, align 4
  %523 = sext i32 %520 to i64
  %524 = sext i32 %522 to i64
  %525 = mul nsw i64 %524, %523
  %526 = add i64 %525, %101
  %527 = getelementptr double, ptr %521, i64 %526
  store i64 %434, ptr %527, align 8
  %528 = load ptr, ptr %71, align 8
  %529 = load i32, ptr %73, align 4
  %530 = sext i32 %529 to i64
  %531 = shl nsw i64 %530, 1
  %532 = add nsw i64 %531, %28
  %533 = getelementptr double, ptr %528, i64 %532
  store i64 %434, ptr %533, align 8
  %534 = load ptr, ptr %482, align 8
  %535 = load i32, ptr %484, align 4
  %536 = sext i32 %535 to i64
  %537 = mul nsw i64 %536, 5
  %538 = add nsw i64 %537, %28
  %539 = getelementptr double, ptr %534, i64 %538
  store double %148, ptr %539, align 8
  %540 = load ptr, ptr %467, align 8
  %541 = load i32, ptr %469, align 4
  %542 = sext i32 %541 to i64
  %543 = mul nsw i64 %542, 3
  %544 = add nsw i64 %543, %101
  %545 = getelementptr double, ptr %540, i64 %544
  store double %154, ptr %545, align 8
  %546 = or i32 %471, 3
  %547 = load ptr, ptr %127, align 8
  %548 = load i32, ptr %129, align 4
  %549 = sext i32 %546 to i64
  %550 = sext i32 %548 to i64
  %551 = mul nsw i64 %550, %549
  %552 = add i64 %551, %101
  %553 = getelementptr double, ptr %547, i64 %552
  store double %.0112, ptr %553, align 8
  %554 = load ptr, ptr %71, align 8
  %555 = load i32, ptr %73, align 4
  %556 = sext i32 %555 to i64
  %557 = mul nsw i64 %556, 3
  %558 = add nsw i64 %557, %28
  %559 = getelementptr double, ptr %554, i64 %558
  store double %.0112, ptr %559, align 8
  %560 = atomicrmw xor ptr %123, i32 1 seq_cst, align 4
  %561 = load ptr, ptr %98, align 8
  %562 = load i32, ptr %100, align 4
  %563 = sext i32 %562 to i64
  %564 = add nsw i64 %563, %101
  %565 = getelementptr i64, ptr %561, i64 %564
  %566 = atomicrmw add ptr %565, i64 1 seq_cst, align 8
  %567 = load ptr, ptr %105, align 8
  %568 = getelementptr i64, ptr %567, i64 2
  %569 = atomicrmw add ptr %568, i64 1 seq_cst, align 8
  %570 = load ptr, ptr %155, align 8
  %571 = getelementptr i32, ptr %570, i64 %101
  %572 = load i32, ptr %571, align 4
  %573 = icmp sgt i32 %572, -1
  br i1 %573, label %true_block80, label %after_if82

true_block80:                                     ; preds = %true_block77
  %574 = load i32, ptr %157, align 4
  %575 = sext i32 %574 to i64
  %576 = mul nsw i64 %575, 5
  %577 = zext i32 %572 to i64
  %578 = add nsw i64 %576, %577
  %579 = getelementptr i32, ptr %570, i64 %578
  %580 = load i32, ptr %579, align 4
  %581 = sdiv i32 %580, 32
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %5)
  %582 = shl nsw i32 %581, 3
  %583 = sext i32 %582 to i64
  %584 = getelementptr i8, ptr %getch.i, i64 %583
  store volatile ptr %584, ptr %5, align 8
  %585 = getelementptr inbounds i8, ptr %584, i64 32
  %586 = load volatile ptr, ptr %585, align 8
  %587 = icmp eq ptr %586, null
  br i1 %587, label %588, label %Pointer_activate.exit166

588:                                              ; preds = %true_block80
  %.0..0..0..0..0..i128 = load volatile ptr, ptr %5, align 8
  %.0..0..0..0..0.2.i129 = load volatile ptr, ptr %5, align 8
  br label %589

589:                                              ; preds = %589, %588
  %590 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i129, i32 1 seq_cst, align 4
  %591 = icmp eq i32 %590, 1
  br i1 %591, label %589, label %mutex_lock_i32.exit.i.i.i130, !llvm.loop !6

mutex_lock_i32.exit.i.i.i130:                     ; preds = %589
  %592 = load volatile ptr, ptr %585, align 8
  %593 = icmp eq ptr %592, null
  br i1 %593, label %594, label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i165"

594:                                              ; preds = %mutex_lock_i32.exit.i.i.i130
  %595 = load ptr, ptr %9, align 8
  %596 = getelementptr inbounds %struct.LLVMRuntime, ptr %595, i64 0, i32 14
  %597 = load ptr, ptr %596, align 8
  %598 = getelementptr inbounds ptr, ptr %597, i64 57
  %599 = load ptr, ptr %598, align 8
  %600 = getelementptr inbounds %struct.NodeManager, ptr %599, i64 0, i32 4
  %601 = atomicrmw volatile add ptr %600, i32 1 seq_cst, align 4
  %602 = getelementptr inbounds %struct.NodeManager, ptr %599, i64 0, i32 5
  %603 = load ptr, ptr %602, align 8
  %604 = getelementptr inbounds %struct.ListManager, ptr %603, i64 0, i32 5
  %605 = load i32, ptr %604, align 8
  %.not.i.i.i.i.i131 = icmp slt i32 %601, %605
  br i1 %.not.i.i.i.i.i131, label %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i159, label %606

606:                                              ; preds = %594
  %607 = getelementptr inbounds %struct.NodeManager, ptr %599, i64 0, i32 7
  %608 = load ptr, ptr %607, align 8
  %609 = getelementptr inbounds %struct.ListManager, ptr %608, i64 0, i32 5
  %610 = atomicrmw volatile add ptr %609, i32 1 seq_cst, align 4
  %611 = getelementptr inbounds %struct.ListManager, ptr %608, i64 0, i32 3
  %612 = load i32, ptr %611, align 8
  %613 = ashr i32 %610, %612
  %614 = icmp ugt i32 %613, 131071
  br i1 %614, label %615, label %618

615:                                              ; preds = %606
  %616 = getelementptr inbounds %struct.ListManager, ptr %608, i64 0, i32 6
  %617 = load ptr, ptr %616, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %617, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i162

618:                                              ; preds = %606
  %619 = zext i32 %613 to i64
  %620 = lshr i64 %619, 9
  %621 = getelementptr inbounds [256 x ptr], ptr %608, i64 0, i64 %620
  %622 = load atomic i64, ptr %621 acquire, align 8
  %.not.i.i.i4.i.i.i.i.i132 = icmp eq i64 %622, 0
  br i1 %.not.i.i.i4.i.i.i.i.i132, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i135, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i134

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i134: ; preds = %618
  %623 = inttoptr i64 %622 to ptr
  %624 = and i64 %619, 511
  %625 = getelementptr inbounds ptr, ptr %623, i64 %624
  %626 = load atomic i64, ptr %625 acquire, align 8
  %.not.i.i5.i.i.i.i.i133 = icmp eq i64 %626, 0
  br i1 %.not.i.i5.i.i.i.i.i133, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i135, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i162

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i135: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i134, %618
  %627 = getelementptr inbounds %struct.ListManager, ptr %608, i64 0, i32 4
  br label %628

628:                                              ; preds = %628, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i135
  %629 = atomicrmw volatile xchg ptr %627, i32 1 seq_cst, align 4
  %630 = icmp eq i32 %629, 1
  br i1 %630, label %628, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i137, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i137:       ; preds = %628
  %631 = load atomic i64, ptr %621 acquire, align 8
  %632 = inttoptr i64 %631 to ptr
  %.not.i.i.i.i.i.i.i.i.i.i.i136 = icmp eq i64 %631, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i136, label %633, label %668

633:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i137
  %634 = getelementptr inbounds %struct.ListManager, ptr %608, i64 0, i32 6
  %635 = load ptr, ptr %634, align 8
  %636 = getelementptr inbounds %struct.LLVMRuntime, ptr %635, i64 0, i32 1
  %637 = getelementptr inbounds %struct.LLVMRuntime, ptr %635, i64 0, i32 28
  %638 = atomicrmw volatile add ptr %637, i64 4096 seq_cst, align 8
  %639 = getelementptr inbounds %struct.LLVMRuntime, ptr %635, i64 0, i32 1, i32 2
  %640 = load i64, ptr %639, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i.i.i138 = icmp eq i64 %640, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i.i.i138, label %661, label %641

641:                                              ; preds = %633
  %642 = getelementptr inbounds %struct.LLVMRuntime, ptr %635, i64 0, i32 26
  br label %643

643:                                              ; preds = %643, %641
  %644 = atomicrmw volatile xchg ptr %642, i32 1 seq_cst, align 4
  %645 = icmp eq i32 %644, 1
  br i1 %645, label %643, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i141, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i141: ; preds = %643
  %646 = load ptr, ptr %636, align 8
  %647 = ptrtoint ptr %646 to i64
  %648 = getelementptr inbounds %struct.LLVMRuntime, ptr %635, i64 0, i32 1, i32 1
  %649 = load ptr, ptr %648, align 8
  %650 = ptrtoint ptr %649 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i139 = sub i64 0, %647
  %651 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i139, 4095
  %652 = or i64 %651, 4096
  %653 = add i64 %652, %647
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i140 = icmp ugt i64 %653, %650
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i140, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i143, label %654

654:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i141
  %655 = add i64 %651, %647
  %656 = inttoptr i64 %655 to ptr
  %657 = getelementptr i8, ptr %646, i64 %651
  %658 = getelementptr inbounds i8, ptr %657, i64 4096
  store ptr %658, ptr %636, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i143

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i143: ; preds = %654, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i141
  %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i142 = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i141 ], [ %656, %654 ]
  %659 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i140, true
  %660 = atomicrmw volatile xchg ptr %642, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %635, i1 noundef zeroext %659, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i145

661:                                              ; preds = %633
  %662 = getelementptr inbounds %struct.LLVMRuntime, ptr %635, i64 0, i32 2
  %663 = load ptr, ptr %662, align 8
  %664 = getelementptr inbounds %struct.LLVMRuntime, ptr %635, i64 0, i32 6
  %665 = load ptr, ptr %664, align 8
  %666 = tail call noundef ptr %663(ptr noundef %665, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i145

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i145: ; preds = %661, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i143
  %.0.i17.i.i.i.i.i.i.i.i.i.i.i144 = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i142, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i143 ], [ %666, %661 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i.i.i144, i8 0, i64 4096, i1 false)
  %667 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i.i.i144 to i64
  store atomic i64 %667, ptr %621 release, align 8
  br label %668

668:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i145, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i137
  %.0.i.i.i.i.i.i.i.i.i.i.i146 = phi ptr [ %632, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i137 ], [ %.0.i17.i.i.i.i.i.i.i.i.i.i.i144, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i145 ]
  %669 = and i32 %613, 511
  %670 = zext i32 %669 to i64
  %671 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i.i.i146, i64 %670
  %672 = load atomic i64, ptr %671 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i.i.i147 = icmp eq i64 %672, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i.i.i147, label %673, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i156"

673:                                              ; preds = %668
  %674 = getelementptr inbounds %struct.ListManager, ptr %608, i64 0, i32 6
  %675 = load ptr, ptr %674, align 8
  %676 = getelementptr inbounds %struct.LLVMRuntime, ptr %675, i64 0, i32 1
  %677 = getelementptr inbounds %struct.ListManager, ptr %608, i64 0, i32 2
  %678 = load i64, ptr %677, align 8
  %679 = getelementptr inbounds %struct.ListManager, ptr %608, i64 0, i32 1
  %680 = load i64, ptr %679, align 8
  %681 = mul i64 %680, %678
  %682 = getelementptr inbounds %struct.LLVMRuntime, ptr %675, i64 0, i32 28
  %683 = atomicrmw volatile add ptr %682, i64 %681 seq_cst, align 8
  %684 = getelementptr inbounds %struct.LLVMRuntime, ptr %675, i64 0, i32 1, i32 2
  %685 = load i64, ptr %684, align 8
  %.not.i.i.i.i.i.i.i.i.i.i.i.i148 = icmp eq i64 %685, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i148, label %705, label %686

686:                                              ; preds = %673
  %687 = getelementptr inbounds %struct.LLVMRuntime, ptr %675, i64 0, i32 26
  br label %688

688:                                              ; preds = %688, %686
  %689 = atomicrmw volatile xchg ptr %687, i32 1 seq_cst, align 4
  %690 = icmp eq i32 %689, 1
  br i1 %690, label %688, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i151, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i151: ; preds = %688
  %691 = load ptr, ptr %676, align 8
  %692 = ptrtoint ptr %691 to i64
  %693 = getelementptr inbounds %struct.LLVMRuntime, ptr %675, i64 0, i32 1, i32 1
  %694 = load ptr, ptr %693, align 8
  %695 = ptrtoint ptr %694 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i149 = sub i64 0, %692
  %696 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i149, 4095
  %697 = add i64 %696, %681
  %698 = add i64 %697, %692
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i150 = icmp ugt i64 %698, %695
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i150, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i153, label %699

699:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i151
  %700 = add i64 %696, %692
  %701 = inttoptr i64 %700 to ptr
  %702 = getelementptr inbounds i8, ptr %691, i64 %697
  store ptr %702, ptr %676, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i153

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i153: ; preds = %699, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i151
  %.0.i.i.i.i.i.i.i.i.i.i.i.i.i152 = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i151 ], [ %701, %699 ]
  %703 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i150, true
  %704 = atomicrmw volatile xchg ptr %687, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %675, i1 noundef zeroext %703, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i155

705:                                              ; preds = %673
  %706 = getelementptr inbounds %struct.LLVMRuntime, ptr %675, i64 0, i32 2
  %707 = load ptr, ptr %706, align 8
  %708 = getelementptr inbounds %struct.LLVMRuntime, ptr %675, i64 0, i32 6
  %709 = load ptr, ptr %708, align 8
  %710 = tail call noundef ptr %707(ptr noundef %709, i64 noundef %681, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i155

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i155: ; preds = %705, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i153
  %.0.i.i.i.i.i.i.i.i.i.i.i.i154 = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i.i.i152, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i153 ], [ %710, %705 ]
  %711 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i.i.i154 to i64
  store atomic i64 %711, ptr %671 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i156"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i156": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i155, %668
  %712 = atomicrmw volatile xchg ptr %627, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i162

_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i159:   ; preds = %594
  %713 = getelementptr inbounds %struct.ListManager, ptr %603, i64 0, i32 3
  %714 = load i32, ptr %713, align 8
  %715 = ashr i32 %601, %714
  %716 = sext i32 %715 to i64
  %717 = lshr i64 %716, 9
  %718 = getelementptr inbounds [256 x ptr], ptr %603, i64 0, i64 %717
  %719 = load atomic i64, ptr %718 acquire, align 8
  %.not.i.i.i.i.i.i.i.i157 = icmp ne i64 %719, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i.i.i.i.i157)
  %720 = inttoptr i64 %719 to ptr
  %721 = and i64 %716, 511
  %722 = getelementptr inbounds ptr, ptr %720, i64 %721
  %723 = load atomic i64, ptr %722 acquire, align 8
  %724 = inttoptr i64 %723 to ptr
  %725 = getelementptr inbounds %struct.ListManager, ptr %603, i64 0, i32 1
  %726 = load i64, ptr %725, align 8
  %727 = load i32, ptr %713, align 8
  %notmask.i.i.i.i.i.i.i158 = shl nsw i32 -1, %727
  %728 = xor i32 %notmask.i.i.i.i.i.i.i158, -1
  %729 = and i32 %601, %728
  %730 = sext i32 %729 to i64
  %731 = mul i64 %726, %730
  %732 = getelementptr inbounds i8, ptr %724, i64 %731
  %733 = load i32, ptr %732, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i162

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i162: ; preds = %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i159, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i156", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i134, %615
  %.0.i.i.i.i.i160 = phi i32 [ %733, %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i159 ], [ %610, %615 ], [ %610, %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i134 ], [ %610, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i156" ]
  %734 = getelementptr inbounds %struct.NodeManager, ptr %599, i64 0, i32 7
  %735 = load ptr, ptr %734, align 8
  %736 = getelementptr inbounds %struct.ListManager, ptr %735, i64 0, i32 3
  %737 = load i32, ptr %736, align 8
  %738 = ashr i32 %.0.i.i.i.i.i160, %737
  %739 = sext i32 %738 to i64
  %740 = lshr i64 %739, 9
  %741 = getelementptr inbounds [256 x ptr], ptr %735, i64 0, i64 %740
  %742 = load atomic i64, ptr %741 acquire, align 8
  %.not.i.i.i.i.i.i.i161 = icmp eq i64 %742, 0
  br i1 %.not.i.i.i.i.i.i.i161, label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i164", label %743

743:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i162
  %744 = inttoptr i64 %742 to ptr
  %745 = and i64 %739, 511
  %746 = getelementptr inbounds ptr, ptr %744, i64 %745
  %747 = load atomic i64, ptr %746 acquire, align 8
  %748 = inttoptr i64 %747 to ptr
  br label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i164"

"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i164": ; preds = %743, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i162
  %749 = phi ptr [ %748, %743 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i162 ]
  %750 = getelementptr inbounds %struct.ListManager, ptr %735, i64 0, i32 1
  %751 = load i64, ptr %750, align 8
  %752 = load i32, ptr %736, align 8
  %notmask.i.i.i.i.i.i163 = shl nsw i32 -1, %752
  %753 = xor i32 %notmask.i.i.i.i.i.i163, -1
  %754 = and i32 %.0.i.i.i.i.i160, %753
  %755 = sext i32 %754 to i64
  %756 = mul i64 %751, %755
  %757 = getelementptr inbounds i8, ptr %749, i64 %756
  %758 = ptrtoint ptr %757 to i64
  %759 = atomicrmw volatile xchg ptr %585, i64 %758 seq_cst, align 8
  br label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i165"

"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i165": ; preds = %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i164", %mutex_lock_i32.exit.i.i.i130
  %760 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i129, i32 0 seq_cst, align 4
  br label %Pointer_activate.exit166

Pointer_activate.exit166:                         ; preds = %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i165", %true_block80
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5)
  %761 = lshr i32 %580, 2
  %762 = and i32 %761, 1073741816
  %763 = zext i32 %762 to i64
  %764 = getelementptr i8, ptr %getch.i, i64 %763
  %765 = getelementptr inbounds i8, ptr %764, i64 32
  %766 = load ptr, ptr %765, align 8
  %767 = icmp eq ptr %766, null
  br i1 %767, label %768, label %Pointer_lookup_element.exit127

768:                                              ; preds = %Pointer_activate.exit166
  %769 = load ptr, ptr %9, align 8
  %770 = getelementptr inbounds %struct.LLVMRuntime, ptr %769, i64 0, i32 15
  %771 = load ptr, ptr %770, align 8
  %772 = getelementptr inbounds ptr, ptr %771, i64 57
  %773 = load ptr, ptr %772, align 8
  br label %Pointer_lookup_element.exit127

Pointer_lookup_element.exit127:                   ; preds = %768, %Pointer_activate.exit166
  %.0.i126 = phi ptr [ %773, %768 ], [ %766, %Pointer_activate.exit166 ]
  %774 = and i32 %580, 31
  %775 = getelementptr inbounds i8, ptr %.0.i126, i64 32
  %776 = shl nuw i32 1, %774
  %777 = atomicrmw volatile or ptr %775, i32 %776 seq_cst, align 4
  %.pre = load ptr, ptr %155, align 8
  br label %after_if82

after_if82:                                       ; preds = %Pointer_lookup_element.exit127, %true_block77
  %778 = phi ptr [ %570, %true_block77 ], [ %.pre, %Pointer_lookup_element.exit127 ]
  %779 = load i32, ptr %157, align 4
  %780 = sext i32 %779 to i64
  %781 = mul nsw i64 %780, 6
  %782 = add nsw i64 %781, %101
  %783 = getelementptr i32, ptr %778, i64 %782
  %784 = load i32, ptr %783, align 4
  %785 = mul nsw i64 %780, 7
  %786 = add nsw i64 %785, %101
  %787 = getelementptr i32, ptr %778, i64 %786
  %788 = load i32, ptr %787, align 4
  %789 = load ptr, ptr %105, align 8
  %790 = getelementptr i64, ptr %789, i64 6
  %791 = load ptr, ptr %110, align 8
  %792 = getelementptr i64, ptr %791, i64 10
  %793 = getelementptr i64, ptr %791, i64 15
  %794 = getelementptr i64, ptr %789, i64 8
  %795 = load ptr, ptr %9, align 8
  %796 = getelementptr inbounds %struct.LLVMRuntime, ptr %795, i64 0, i32 16
  %797 = load ptr, ptr %796, align 8
  %798 = getelementptr inbounds i8, ptr %797, i64 8
  %799 = load double, ptr %798, align 8
  %800 = fcmp one double %799, 0.000000e+00
  %801 = getelementptr i64, ptr %789, i64 9
  %802 = icmp sgt i32 %788, 0
  br i1 %802, label %for_loop_body83.lr.ph, label %loop_body_tail

for_loop_body83.lr.ph:                            ; preds = %after_if82
  %803 = load ptr, ptr %0, align 8
  %804 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %803, i64 0, i32 9, i32 1
  %805 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %803, i64 0, i32 12, i32 1
  %806 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %803, i64 0, i32 12, i32 0, i32 1
  %807 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %803, i64 0, i32 10, i32 1
  %808 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %803, i64 0, i32 10, i32 0, i32 1
  %809 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %803, i64 0, i32 7, i32 1
  %810 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %803, i64 0, i32 7, i32 0, i32 1
  %811 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %803, i64 0, i32 20, i32 1
  %812 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %803, i64 0, i32 20, i32 0, i32 1
  %813 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %803, i64 0, i32 21, i32 1
  %814 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %803, i64 0, i32 19, i32 1
  %815 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %803, i64 0, i32 19, i32 0, i32 1
  %816 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %803, i64 0, i32 22, i32 1
  %817 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %803, i64 0, i32 22, i32 0, i32 1
  %818 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %803, i64 0, i32 23, i32 1
  %wide.trip.count376 = zext i32 %788 to i64
  br label %for_loop_body83

for_loop_body83:                                  ; preds = %after_if180, %for_loop_body83.lr.ph
  %indvars.iv373 = phi i64 [ 0, %for_loop_body83.lr.ph ], [ %indvars.iv.next374, %after_if180 ]
  %819 = trunc i64 %indvars.iv373 to i32
  %820 = add i32 %784, %819
  %821 = load ptr, ptr %804, align 8
  %822 = sext i32 %820 to i64
  %823 = getelementptr i32, ptr %821, i64 %822
  %824 = load i32, ptr %823, align 4
  %825 = atomicrmw add ptr %790, i64 1 seq_cst, align 8
  %826 = atomicrmw add ptr %792, i64 1 seq_cst, align 8
  %827 = atomicrmw add ptr %793, i64 1 seq_cst, align 8
  %828 = load ptr, ptr %805, align 8
  %829 = load i32, ptr %806, align 4
  %830 = sext i32 %829 to i64
  %831 = sext i32 %824 to i64
  %832 = getelementptr i32, ptr %828, i64 %831
  %833 = load i32, ptr %832, align 4
  %834 = add nsw i64 %830, %831
  %835 = getelementptr i32, ptr %828, i64 %834
  %836 = load i32, ptr %835, align 4
  %837 = icmp slt i32 %833, %836
  br i1 %837, label %for_loop_body87.preheader, label %after_for89

for_loop_body87.preheader:                        ; preds = %for_loop_body83
  %838 = sext i32 %833 to i64
  %wide.trip.count361 = sext i32 %836 to i64
  br label %for_loop_body87

for_loop_body87:                                  ; preds = %after_if123, %for_loop_body87.preheader
  %indvars.iv358 = phi i64 [ %838, %for_loop_body87.preheader ], [ %indvars.iv.next359, %after_if123 ]
  %.077308 = phi double [ 0.000000e+00, %for_loop_body87.preheader ], [ %1135, %after_if123 ]
  %.078307 = phi double [ 0.000000e+00, %for_loop_body87.preheader ], [ %1134, %after_if123 ]
  %.079306 = phi double [ 0.000000e+00, %for_loop_body87.preheader ], [ %1133, %after_if123 ]
  %.082305 = phi double [ 0.000000e+00, %for_loop_body87.preheader ], [ %1132, %after_if123 ]
  %.083304 = phi double [ 0.000000e+00, %for_loop_body87.preheader ], [ %1131, %after_if123 ]
  %.086303 = phi double [ 0.000000e+00, %for_loop_body87.preheader ], [ %1130, %after_if123 ]
  %839 = atomicrmw add ptr %794, i64 1 seq_cst, align 8
  %840 = load ptr, ptr %807, align 8
  %841 = load i32, ptr %808, align 4
  %842 = sext i32 %841 to i64
  %843 = add nsw i64 %indvars.iv358, %842
  %844 = getelementptr i32, ptr %840, i64 %843
  %845 = load i32, ptr %844, align 4
  %846 = shl nsw i64 %842, 3
  %uglygep = getelementptr i8, ptr %840, i64 %846
  %847 = shl i64 %indvars.iv358, 2
  %uglygep467 = getelementptr i8, ptr %uglygep, i64 %847
  %848 = load i32, ptr %uglygep467, align 4
  %849 = load ptr, ptr %121, align 8
  %850 = sext i32 %845 to i64
  %851 = getelementptr i32, ptr %849, i64 %850
  %852 = atomicrmw or ptr %851, i32 0 seq_cst, align 4
  %853 = shl i32 %852, 2
  %854 = load ptr, ptr %127, align 8
  %855 = load i32, ptr %129, align 4
  %856 = sext i32 %853 to i64
  %857 = sext i32 %855 to i64
  %858 = mul nsw i64 %857, %856
  %859 = add nsw i64 %858, %850
  %860 = getelementptr double, ptr %854, i64 %859
  %861 = load double, ptr %860, align 8
  %862 = or i32 %853, 1
  %863 = sext i32 %862 to i64
  %864 = mul nsw i64 %863, %857
  %865 = add nsw i64 %864, %850
  %866 = getelementptr double, ptr %854, i64 %865
  %867 = load double, ptr %866, align 8
  %868 = or i32 %853, 2
  %869 = sext i32 %868 to i64
  %870 = mul nsw i64 %869, %857
  %871 = add nsw i64 %870, %850
  %872 = getelementptr double, ptr %854, i64 %871
  %873 = load double, ptr %872, align 8
  %874 = or i32 %853, 3
  %875 = sext i32 %874 to i64
  %876 = mul nsw i64 %875, %857
  %877 = add nsw i64 %876, %850
  %878 = getelementptr double, ptr %854, i64 %877
  %879 = load double, ptr %878, align 8
  %880 = load ptr, ptr %121, align 8
  %881 = sext i32 %848 to i64
  %882 = getelementptr i32, ptr %880, i64 %881
  %883 = atomicrmw or ptr %882, i32 0 seq_cst, align 4
  %884 = shl i32 %883, 2
  %885 = load ptr, ptr %127, align 8
  %886 = load i32, ptr %129, align 4
  %887 = sext i32 %884 to i64
  %888 = sext i32 %886 to i64
  %889 = mul nsw i64 %888, %887
  %890 = add nsw i64 %889, %881
  %891 = getelementptr double, ptr %885, i64 %890
  %892 = load double, ptr %891, align 8
  %893 = or i32 %884, 1
  %894 = sext i32 %893 to i64
  %895 = mul nsw i64 %894, %888
  %896 = add nsw i64 %895, %881
  %897 = getelementptr double, ptr %885, i64 %896
  %898 = load double, ptr %897, align 8
  %899 = or i32 %884, 2
  %900 = sext i32 %899 to i64
  %901 = mul nsw i64 %900, %888
  %902 = add nsw i64 %901, %881
  %903 = getelementptr double, ptr %885, i64 %902
  %904 = load double, ptr %903, align 8
  %905 = or i32 %884, 3
  %906 = sext i32 %905 to i64
  %907 = mul nsw i64 %906, %888
  %908 = add nsw i64 %907, %881
  %909 = getelementptr double, ptr %885, i64 %908
  %910 = load double, ptr %909, align 8
  %911 = icmp eq i32 %845, %30
  %912 = select i1 %911, double %154, double %879
  %913 = icmp eq i32 %848, %30
  %914 = select i1 %913, double %154, double %910
  %915 = load ptr, ptr %807, align 8
  %916 = load i32, ptr %808, align 4
  %917 = sext i32 %916 to i64
  %918 = mul nsw i64 %917, 12
  %uglygep468 = getelementptr i8, ptr %915, i64 %918
  %uglygep469 = getelementptr i8, ptr %uglygep468, i64 %847
  %919 = load i32, ptr %uglygep469, align 4
  %.not121 = icmp eq i32 %919, 0
  %920 = select i1 %.not121, i32 %845, i32 %848
  %921 = load ptr, ptr %155, align 8
  %922 = load i32, ptr %157, align 4
  %923 = sext i32 %922 to i64
  %924 = shl nsw i64 %923, 3
  %925 = sext i32 %920 to i64
  %926 = add nsw i64 %924, %925
  %927 = getelementptr i32, ptr %921, i64 %926
  %928 = load i32, ptr %927, align 4
  %929 = mul nsw i64 %923, 9
  %930 = add nsw i64 %929, %850
  %931 = getelementptr i32, ptr %921, i64 %930
  %932 = load i32, ptr %931, align 4
  %933 = icmp ne i32 %932, 0
  %934 = or i1 %.not121, %933
  %935 = icmp ne i32 %928, 0
  %936 = and i1 %935, %934
  %937 = and i1 %800, %936
  br i1 %937, label %true_block91, label %after_if123

after_for89.loopexit:                             ; preds = %after_if123
  br label %after_for89

after_for89:                                      ; preds = %after_for89.loopexit, %for_loop_body83
  %.086.lcssa = phi double [ 0.000000e+00, %for_loop_body83 ], [ %1130, %after_for89.loopexit ]
  %.083.lcssa = phi double [ 0.000000e+00, %for_loop_body83 ], [ %1131, %after_for89.loopexit ]
  %.082.lcssa = phi double [ 0.000000e+00, %for_loop_body83 ], [ %1132, %after_for89.loopexit ]
  %.079.lcssa = phi double [ 0.000000e+00, %for_loop_body83 ], [ %1133, %after_for89.loopexit ]
  %.078.lcssa = phi double [ 0.000000e+00, %for_loop_body83 ], [ %1134, %after_for89.loopexit ]
  %.077.lcssa = phi double [ 0.000000e+00, %for_loop_body83 ], [ %1135, %after_for89.loopexit ]
  %938 = fcmp one double %.086.lcssa, %.083.lcssa
  %939 = or i1 %193, %938
  %940 = fcmp one double %.082.lcssa, %.079.lcssa
  %941 = or i1 %939, %940
  %942 = fcmp one double %.078.lcssa, %.077.lcssa
  %943 = or i1 %941, %942
  %944 = load ptr, ptr %811, align 8
  %945 = load i32, ptr %812, align 4
  %946 = sext i32 %945 to i64
  %947 = getelementptr i32, ptr %944, i64 %831
  %948 = load i32, ptr %947, align 4
  %949 = add nsw i64 %946, %831
  %950 = getelementptr i32, ptr %944, i64 %949
  %951 = load i32, ptr %950, align 4
  %952 = icmp slt i32 %948, %951
  br i1 %952, label %for_loop_body152.preheader, label %after_for154

for_loop_body152.preheader:                       ; preds = %after_for89
  %953 = sext i32 %948 to i64
  %wide.trip.count366 = sext i32 %951 to i64
  br label %for_loop_body152

true_block91:                                     ; preds = %for_loop_body87
  %954 = select i1 %913, double %148, double %904
  %955 = select i1 %913, double %142, double %898
  %956 = select i1 %913, double %136, double %892
  %957 = select i1 %911, double %148, double %873
  %958 = select i1 %911, double %142, double %867
  %959 = select i1 %911, double %136, double %861
  %960 = fsub double %956, %959
  %961 = load ptr, ptr %809, align 8
  %962 = load i32, ptr %810, align 4
  %963 = sext i32 %962 to i64
  %964 = getelementptr double, ptr %961, i64 %831
  %965 = load double, ptr %964, align 8
  %966 = fsub double %959, %965
  %967 = select i1 %.not121, double %966, double %960
  %968 = fmul double %967, %967
  %969 = fsub double %955, %958
  %970 = add nsw i64 %963, %831
  %971 = getelementptr double, ptr %961, i64 %970
  %972 = load double, ptr %971, align 8
  %973 = fsub double %958, %972
  %974 = select i1 %.not121, double %973, double %969
  %975 = fmul double %974, %974
  %976 = fadd double %968, %975
  %977 = fsub double %954, %957
  %978 = shl nsw i64 %963, 1
  %979 = add nsw i64 %978, %831
  %980 = getelementptr double, ptr %961, i64 %979
  %981 = load double, ptr %980, align 8
  %982 = fsub double %957, %981
  %983 = select i1 %.not121, double %982, double %977
  %984 = fmul double %983, %983
  %985 = fadd double %976, %984
  %986 = fcmp ogt double %985, 0.000000e+00
  br i1 %986, label %true_block94, label %true_block121

true_block94:                                     ; preds = %true_block91
  %sqrt = tail call double @llvm.sqrt.f64(double %985)
  %987 = fdiv double 1.000000e+00, %sqrt
  %988 = mul nsw i64 %963, 6
  %989 = add nsw i64 %988, %831
  %990 = getelementptr double, ptr %961, i64 %989
  %991 = load double, ptr %990, align 8
  %992 = load ptr, ptr %0, align 8
  %993 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %992, i64 0, i32 11, i32 1
  %994 = load ptr, ptr %993, align 8
  %995 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %992, i64 0, i32 11, i32 0, i32 1
  %996 = load i32, ptr %995, align 4
  %997 = sext i32 %996 to i64
  %998 = shl i64 %indvars.iv358, 3
  %uglygep470 = getelementptr i8, ptr %994, i64 %998
  %999 = load i64, ptr %uglygep470, align 8
  %1000 = uitofp i64 %999 to double
  %1001 = add nsw i64 %indvars.iv358, %997
  %1002 = getelementptr i64, ptr %994, i64 %1001
  %1003 = load i64, ptr %1002, align 8
  %1004 = uitofp i64 %1003 to double
  %1005 = fdiv double %1000, %1004
  %1006 = fmul double %991, %1005
  %1007 = select i1 %.not121, double %912, double %914
  %1008 = load double, ptr %798, align 8
  %1009 = fmul double %1008, %1006
  %1010 = fmul double %987, %987
  %1011 = fmul double %987, %1010
  %1012 = fmul double %1007, %1011
  %1013 = fmul double %1012, %1009
  %1014 = bitcast double %985 to i64
  %1015 = and i64 %1014, 9223372036854775807
  %1016 = and i64 %1014, 9218868437227405312
  %1017 = icmp eq i64 %1015, 0
  %1018 = icmp ne i64 %1016, 0
  %1019 = icmp ne i64 %1016, 9218868437227405312
  %1020 = and i1 %1018, %1019
  %1021 = or i1 %1017, %1020
  br i1 %1021, label %after_if99, label %true_block97

true_block97:                                     ; preds = %true_block94
  %1022 = load ptr, ptr %105, align 8
  %1023 = atomicrmw add ptr %1022, i64 1 seq_cst, align 8
  br label %after_if99

after_if99:                                       ; preds = %true_block97, %true_block94
  %1024 = bitcast double %987 to i64
  %1025 = and i64 %1024, 9223372036854775807
  %1026 = and i64 %1024, 9218868437227405312
  %1027 = icmp eq i64 %1025, 0
  %1028 = icmp ne i64 %1026, 0
  %1029 = icmp ne i64 %1026, 9218868437227405312
  %1030 = and i1 %1028, %1029
  %1031 = or i1 %1027, %1030
  br i1 %1031, label %after_if102, label %true_block100

true_block100:                                    ; preds = %after_if99
  %1032 = load ptr, ptr %105, align 8
  %1033 = atomicrmw add ptr %1032, i64 1 seq_cst, align 8
  br label %after_if102

after_if102:                                      ; preds = %true_block100, %after_if99
  %1034 = bitcast double %1006 to i64
  %1035 = and i64 %1034, 9223372036854775807
  %1036 = and i64 %1034, 9218868437227405312
  %1037 = icmp eq i64 %1035, 0
  %1038 = icmp ne i64 %1036, 0
  %1039 = icmp ne i64 %1036, 9218868437227405312
  %1040 = and i1 %1038, %1039
  %1041 = or i1 %1037, %1040
  br i1 %1041, label %after_if105, label %true_block103

true_block103:                                    ; preds = %after_if102
  %1042 = load ptr, ptr %105, align 8
  %1043 = atomicrmw add ptr %1042, i64 1 seq_cst, align 8
  br label %after_if105

after_if105:                                      ; preds = %true_block103, %after_if102
  %1044 = bitcast double %1007 to i64
  %1045 = and i64 %1044, 9223372036854775807
  %1046 = and i64 %1044, 9218868437227405312
  %1047 = icmp eq i64 %1045, 0
  %1048 = icmp ne i64 %1046, 0
  %1049 = icmp ne i64 %1046, 9218868437227405312
  %1050 = and i1 %1048, %1049
  %1051 = or i1 %1047, %1050
  br i1 %1051, label %after_if108, label %true_block106

true_block106:                                    ; preds = %after_if105
  %1052 = load ptr, ptr %105, align 8
  %1053 = atomicrmw add ptr %1052, i64 1 seq_cst, align 8
  br label %after_if108

after_if108:                                      ; preds = %true_block106, %after_if105
  %1054 = bitcast double %1013 to i64
  %1055 = and i64 %1054, 9223372036854775807
  %1056 = and i64 %1054, 9218868437227405312
  %1057 = icmp eq i64 %1055, 0
  %1058 = icmp ne i64 %1056, 0
  %1059 = icmp ne i64 %1056, 9218868437227405312
  %1060 = and i1 %1058, %1059
  %1061 = or i1 %1057, %1060
  br i1 %1061, label %after_if111, label %true_block109

true_block109:                                    ; preds = %after_if108
  %1062 = load ptr, ptr %105, align 8
  %1063 = atomicrmw add ptr %1062, i64 1 seq_cst, align 8
  br label %after_if111

after_if111:                                      ; preds = %true_block109, %after_if108
  %1064 = fmul double %967, %1013
  %1065 = bitcast double %1064 to i64
  %1066 = and i64 %1065, 9223372036854775807
  %1067 = and i64 %1065, 9218868437227405312
  %1068 = icmp eq i64 %1066, 0
  %1069 = icmp ne i64 %1067, 0
  %1070 = icmp ne i64 %1067, 9218868437227405312
  %1071 = and i1 %1069, %1070
  %1072 = or i1 %1068, %1071
  br i1 %1072, label %after_if114, label %true_block112

true_block112:                                    ; preds = %after_if111
  %1073 = load ptr, ptr %105, align 8
  %1074 = atomicrmw add ptr %1073, i64 1 seq_cst, align 8
  br label %after_if114

after_if114:                                      ; preds = %true_block112, %after_if111
  %1075 = fmul double %974, %1013
  %1076 = bitcast double %1075 to i64
  %1077 = and i64 %1076, 9223372036854775807
  %1078 = and i64 %1076, 9218868437227405312
  %1079 = icmp eq i64 %1077, 0
  %1080 = icmp ne i64 %1078, 0
  %1081 = icmp ne i64 %1078, 9218868437227405312
  %1082 = and i1 %1080, %1081
  %1083 = or i1 %1079, %1082
  br i1 %1083, label %after_if117, label %true_block115

true_block115:                                    ; preds = %after_if114
  %1084 = load ptr, ptr %105, align 8
  %1085 = atomicrmw add ptr %1084, i64 1 seq_cst, align 8
  br label %after_if117

after_if117:                                      ; preds = %true_block115, %after_if114
  %1086 = fmul double %983, %1013
  %1087 = bitcast double %1086 to i64
  %1088 = and i64 %1087, 9223372036854775807
  %1089 = and i64 %1087, 9218868437227405312
  %1090 = icmp eq i64 %1088, 0
  %1091 = icmp ne i64 %1089, 0
  %1092 = icmp ne i64 %1089, 9218868437227405312
  %1093 = and i1 %1091, %1092
  %1094 = or i1 %1090, %1093
  br i1 %1094, label %true_block121, label %true_block118

true_block118:                                    ; preds = %after_if117
  %1095 = load ptr, ptr %105, align 8
  %1096 = atomicrmw add ptr %1095, i64 1 seq_cst, align 8
  br label %true_block121

true_block121:                                    ; preds = %true_block118, %after_if117, %true_block91
  %.075.ph = phi double [ %1064, %true_block118 ], [ %1064, %after_if117 ], [ 0.000000e+00, %true_block91 ]
  %.074.ph = phi double [ %1075, %true_block118 ], [ %1075, %after_if117 ], [ 0.000000e+00, %true_block91 ]
  %.073.ph = phi double [ %1086, %true_block118 ], [ %1086, %after_if117 ], [ 0.000000e+00, %true_block91 ]
  %1097 = select i1 %913, double %435, double %904
  %1098 = select i1 %913, double %410, double %898
  %1099 = select i1 %913, double %203, double %892
  %1100 = select i1 %911, double %435, double %873
  %1101 = select i1 %911, double %410, double %867
  %1102 = select i1 %911, double %203, double %861
  %1103 = fsub double %1099, %1102
  %1104 = load ptr, ptr %809, align 8
  %1105 = load i32, ptr %810, align 4
  %1106 = sext i32 %1105 to i64
  %1107 = getelementptr double, ptr %1104, i64 %831
  %1108 = load double, ptr %1107, align 8
  %1109 = fsub double %1102, %1108
  %1110 = select i1 %.not121, double %1109, double %1103
  %1111 = fmul double %1110, %1110
  %1112 = fsub double %1098, %1101
  %1113 = add nsw i64 %1106, %831
  %1114 = getelementptr double, ptr %1104, i64 %1113
  %1115 = load double, ptr %1114, align 8
  %1116 = fsub double %1101, %1115
  %1117 = select i1 %.not121, double %1116, double %1112
  %1118 = fmul double %1117, %1117
  %1119 = fadd double %1111, %1118
  %1120 = fsub double %1097, %1100
  %1121 = shl nsw i64 %1106, 1
  %1122 = add nsw i64 %1121, %831
  %1123 = getelementptr double, ptr %1104, i64 %1122
  %1124 = load double, ptr %1123, align 8
  %1125 = fsub double %1100, %1124
  %1126 = select i1 %.not121, double %1125, double %1120
  %1127 = fmul double %1126, %1126
  %1128 = fadd double %1119, %1127
  %1129 = fcmp ogt double %1128, 0.000000e+00
  br i1 %1129, label %true_block124, label %after_if123

after_if123:                                      ; preds = %true_block149, %after_if148, %true_block121, %for_loop_body87
  %.073270 = phi double [ %.073.ph, %true_block121 ], [ %.073.ph, %after_if148 ], [ %.073.ph, %true_block149 ], [ 0.000000e+00, %for_loop_body87 ]
  %.074268 = phi double [ %.074.ph, %true_block121 ], [ %.074.ph, %after_if148 ], [ %.074.ph, %true_block149 ], [ 0.000000e+00, %for_loop_body87 ]
  %.075266 = phi double [ %.075.ph, %true_block121 ], [ %.075.ph, %after_if148 ], [ %.075.ph, %true_block149 ], [ 0.000000e+00, %for_loop_body87 ]
  %.072 = phi double [ 0.000000e+00, %true_block121 ], [ %1215, %after_if148 ], [ %1215, %true_block149 ], [ 0.000000e+00, %for_loop_body87 ]
  %.071 = phi double [ 0.000000e+00, %true_block121 ], [ %1226, %after_if148 ], [ %1226, %true_block149 ], [ 0.000000e+00, %for_loop_body87 ]
  %.070 = phi double [ 0.000000e+00, %true_block121 ], [ %1237, %after_if148 ], [ %1237, %true_block149 ], [ 0.000000e+00, %for_loop_body87 ]
  %1130 = fadd double %.086303, %.075266
  %1131 = fadd double %.083304, %.072
  %1132 = fadd double %.082305, %.074268
  %1133 = fadd double %.079306, %.071
  %1134 = fadd double %.078307, %.073270
  %1135 = fadd double %.077308, %.070
  %indvars.iv.next359 = add nsw i64 %indvars.iv358, 1
  %exitcond362.not = icmp eq i64 %wide.trip.count361, %indvars.iv.next359
  br i1 %exitcond362.not, label %after_for89.loopexit, label %for_loop_body87

true_block124:                                    ; preds = %true_block121
  %1136 = select i1 %913, double %.0112, double %910
  %1137 = select i1 %911, double %.0112, double %879
  %sqrt127 = tail call double @llvm.sqrt.f64(double %1128)
  %1138 = fdiv double 1.000000e+00, %sqrt127
  %1139 = mul nsw i64 %1106, 6
  %1140 = add nsw i64 %1139, %831
  %1141 = getelementptr double, ptr %1104, i64 %1140
  %1142 = load double, ptr %1141, align 8
  %1143 = load ptr, ptr %0, align 8
  %1144 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1143, i64 0, i32 11, i32 1
  %1145 = load ptr, ptr %1144, align 8
  %1146 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %1143, i64 0, i32 11, i32 0, i32 1
  %1147 = load i32, ptr %1146, align 4
  %1148 = sext i32 %1147 to i64
  %1149 = shl i64 %indvars.iv358, 3
  %uglygep471 = getelementptr i8, ptr %1145, i64 %1149
  %1150 = load i64, ptr %uglygep471, align 8
  %1151 = uitofp i64 %1150 to double
  %1152 = add nsw i64 %indvars.iv358, %1148
  %1153 = getelementptr i64, ptr %1145, i64 %1152
  %1154 = load i64, ptr %1153, align 8
  %1155 = uitofp i64 %1154 to double
  %1156 = fdiv double %1151, %1155
  %1157 = fmul double %1142, %1156
  %1158 = select i1 %.not121, double %1137, double %1136
  %1159 = load double, ptr %798, align 8
  %1160 = fmul double %1159, %1157
  %1161 = fmul double %1138, %1138
  %1162 = fmul double %1138, %1161
  %1163 = fmul double %1158, %1162
  %1164 = fmul double %1163, %1160
  %1165 = bitcast double %1128 to i64
  %1166 = and i64 %1165, 9223372036854775807
  %1167 = and i64 %1165, 9218868437227405312
  %1168 = icmp eq i64 %1166, 0
  %1169 = icmp ne i64 %1167, 0
  %1170 = icmp ne i64 %1167, 9218868437227405312
  %1171 = and i1 %1169, %1170
  %1172 = or i1 %1168, %1171
  br i1 %1172, label %after_if130, label %true_block128

true_block128:                                    ; preds = %true_block124
  %1173 = load ptr, ptr %105, align 8
  %1174 = atomicrmw add ptr %1173, i64 1 seq_cst, align 8
  br label %after_if130

after_if130:                                      ; preds = %true_block128, %true_block124
  %1175 = bitcast double %1138 to i64
  %1176 = and i64 %1175, 9223372036854775807
  %1177 = and i64 %1175, 9218868437227405312
  %1178 = icmp eq i64 %1176, 0
  %1179 = icmp ne i64 %1177, 0
  %1180 = icmp ne i64 %1177, 9218868437227405312
  %1181 = and i1 %1179, %1180
  %1182 = or i1 %1178, %1181
  br i1 %1182, label %after_if133, label %true_block131

true_block131:                                    ; preds = %after_if130
  %1183 = load ptr, ptr %105, align 8
  %1184 = atomicrmw add ptr %1183, i64 1 seq_cst, align 8
  br label %after_if133

after_if133:                                      ; preds = %true_block131, %after_if130
  %1185 = bitcast double %1157 to i64
  %1186 = and i64 %1185, 9223372036854775807
  %1187 = and i64 %1185, 9218868437227405312
  %1188 = icmp eq i64 %1186, 0
  %1189 = icmp ne i64 %1187, 0
  %1190 = icmp ne i64 %1187, 9218868437227405312
  %1191 = and i1 %1189, %1190
  %1192 = or i1 %1188, %1191
  br i1 %1192, label %after_if136, label %true_block134

true_block134:                                    ; preds = %after_if133
  %1193 = load ptr, ptr %105, align 8
  %1194 = atomicrmw add ptr %1193, i64 1 seq_cst, align 8
  br label %after_if136

after_if136:                                      ; preds = %true_block134, %after_if133
  %1195 = bitcast double %1158 to i64
  %1196 = and i64 %1195, 9223372036854775807
  %1197 = and i64 %1195, 9218868437227405312
  %1198 = icmp eq i64 %1196, 0
  %1199 = icmp ne i64 %1197, 0
  %1200 = icmp ne i64 %1197, 9218868437227405312
  %1201 = and i1 %1199, %1200
  %1202 = or i1 %1198, %1201
  br i1 %1202, label %after_if139, label %true_block137

true_block137:                                    ; preds = %after_if136
  %1203 = load ptr, ptr %105, align 8
  %1204 = atomicrmw add ptr %1203, i64 1 seq_cst, align 8
  br label %after_if139

after_if139:                                      ; preds = %true_block137, %after_if136
  %1205 = bitcast double %1164 to i64
  %1206 = and i64 %1205, 9223372036854775807
  %1207 = and i64 %1205, 9218868437227405312
  %1208 = icmp eq i64 %1206, 0
  %1209 = icmp ne i64 %1207, 0
  %1210 = icmp ne i64 %1207, 9218868437227405312
  %1211 = and i1 %1209, %1210
  %1212 = or i1 %1208, %1211
  br i1 %1212, label %after_if142, label %true_block140

true_block140:                                    ; preds = %after_if139
  %1213 = load ptr, ptr %105, align 8
  %1214 = atomicrmw add ptr %1213, i64 1 seq_cst, align 8
  br label %after_if142

after_if142:                                      ; preds = %true_block140, %after_if139
  %1215 = fmul double %1110, %1164
  %1216 = bitcast double %1215 to i64
  %1217 = and i64 %1216, 9223372036854775807
  %1218 = and i64 %1216, 9218868437227405312
  %1219 = icmp eq i64 %1217, 0
  %1220 = icmp ne i64 %1218, 0
  %1221 = icmp ne i64 %1218, 9218868437227405312
  %1222 = and i1 %1220, %1221
  %1223 = or i1 %1219, %1222
  br i1 %1223, label %after_if145, label %true_block143

true_block143:                                    ; preds = %after_if142
  %1224 = load ptr, ptr %105, align 8
  %1225 = atomicrmw add ptr %1224, i64 1 seq_cst, align 8
  br label %after_if145

after_if145:                                      ; preds = %true_block143, %after_if142
  %1226 = fmul double %1117, %1164
  %1227 = bitcast double %1226 to i64
  %1228 = and i64 %1227, 9223372036854775807
  %1229 = and i64 %1227, 9218868437227405312
  %1230 = icmp eq i64 %1228, 0
  %1231 = icmp ne i64 %1229, 0
  %1232 = icmp ne i64 %1229, 9218868437227405312
  %1233 = and i1 %1231, %1232
  %1234 = or i1 %1230, %1233
  br i1 %1234, label %after_if148, label %true_block146

true_block146:                                    ; preds = %after_if145
  %1235 = load ptr, ptr %105, align 8
  %1236 = atomicrmw add ptr %1235, i64 1 seq_cst, align 8
  br label %after_if148

after_if148:                                      ; preds = %true_block146, %after_if145
  %1237 = fmul double %1126, %1164
  %1238 = bitcast double %1237 to i64
  %1239 = and i64 %1238, 9223372036854775807
  %1240 = and i64 %1238, 9218868437227405312
  %1241 = icmp eq i64 %1239, 0
  %1242 = icmp ne i64 %1240, 0
  %1243 = icmp ne i64 %1240, 9218868437227405312
  %1244 = and i1 %1242, %1243
  %1245 = or i1 %1241, %1244
  br i1 %1245, label %after_if123, label %true_block149

true_block149:                                    ; preds = %after_if148
  %1246 = load ptr, ptr %105, align 8
  %1247 = atomicrmw add ptr %1246, i64 1 seq_cst, align 8
  br label %after_if123

for_loop_body152:                                 ; preds = %for_loop_body152, %for_loop_body152.preheader
  %indvars.iv363 = phi i64 [ %953, %for_loop_body152.preheader ], [ %indvars.iv.next364, %for_loop_body152 ]
  %.1318 = phi double [ %.077.lcssa, %for_loop_body152.preheader ], [ %1319, %for_loop_body152 ]
  %.180317 = phi double [ %.079.lcssa, %for_loop_body152.preheader ], [ %1317, %for_loop_body152 ]
  %.184316 = phi double [ %.083.lcssa, %for_loop_body152.preheader ], [ %1315, %for_loop_body152 ]
  %1248 = atomicrmw add ptr %801, i64 1 seq_cst, align 8
  %1249 = load ptr, ptr %813, align 8
  %1250 = shl i64 %indvars.iv363, 2
  %uglygep472 = getelementptr i8, ptr %1249, i64 %1250
  %1251 = load i32, ptr %uglygep472, align 4
  %1252 = load ptr, ptr %814, align 8
  %1253 = load i32, ptr %815, align 4
  %1254 = sext i32 %1253 to i64
  %1255 = sext i32 %1251 to i64
  %1256 = getelementptr i32, ptr %1252, i64 %1255
  %1257 = load i32, ptr %1256, align 4
  %1258 = add nsw i64 %1254, %1255
  %1259 = getelementptr i32, ptr %1252, i64 %1258
  %1260 = load i32, ptr %1259, align 4
  %1261 = load ptr, ptr %809, align 8
  %1262 = load i32, ptr %810, align 4
  %1263 = sext i32 %1262 to i64
  %1264 = sext i32 %1260 to i64
  %1265 = getelementptr double, ptr %1261, i64 %1264
  %1266 = load double, ptr %1265, align 8
  %1267 = sext i32 %1257 to i64
  %1268 = getelementptr double, ptr %1261, i64 %1267
  %1269 = load double, ptr %1268, align 8
  %1270 = fsub double %1266, %1269
  %1271 = add nsw i64 %1263, %1264
  %1272 = getelementptr double, ptr %1261, i64 %1271
  %1273 = load double, ptr %1272, align 8
  %1274 = add nsw i64 %1263, %1267
  %1275 = getelementptr double, ptr %1261, i64 %1274
  %1276 = load double, ptr %1275, align 8
  %1277 = fsub double %1273, %1276
  %1278 = shl nsw i64 %1263, 1
  %1279 = add nsw i64 %1278, %1264
  %1280 = getelementptr double, ptr %1261, i64 %1279
  %1281 = load double, ptr %1280, align 8
  %1282 = add nsw i64 %1278, %1267
  %1283 = getelementptr double, ptr %1261, i64 %1282
  %1284 = load double, ptr %1283, align 8
  %1285 = fsub double %1281, %1284
  %1286 = mul nsw i64 %1263, 7
  %1287 = add nsw i64 %1286, %1267
  %1288 = getelementptr double, ptr %1261, i64 %1287
  %1289 = load double, ptr %1288, align 8
  %1290 = add nsw i64 %1286, %1264
  %1291 = getelementptr double, ptr %1261, i64 %1290
  %1292 = load double, ptr %1291, align 8
  %1293 = fmul double %1270, %1270
  %1294 = fmul double %1277, %1277
  %1295 = fadd double %1293, %1294
  %1296 = fmul double %1285, %1285
  %1297 = fadd double %1295, %1296
  %1298 = fcmp ogt double %1297, 0.000000e+00
  %.0.i124 = select i1 %1298, double 1.000000e+00, double 0.000000e+00
  %1299 = fsub double 1.000000e+00, %.0.i124
  %1300 = fadd double %1297, %1299
  %sqrt156 = tail call double @llvm.sqrt.f64(double %1300)
  %1301 = fdiv double 1.000000e+00, %sqrt156
  %1302 = fmul double %1300, %1301
  %1303 = fadd double %1289, %1292
  %1304 = fsub double %1303, %1302
  %1305 = tail call double @llvm.maxnum.f64(double %1304, double 0.000000e+00)
  %1306 = load ptr, ptr %9, align 8
  %1307 = getelementptr inbounds %struct.LLVMRuntime, ptr %1306, i64 0, i32 16
  %1308 = load ptr, ptr %1307, align 8
  %1309 = getelementptr inbounds i8, ptr %1308, i64 16
  %1310 = load double, ptr %1309, align 8
  %1311 = fmul double %.0.i124, %1301
  %1312 = fneg double %1310
  %1313 = fmul double %1305, %1312
  %neg = fmul double %1311, %1313
  %1314 = fmul double %1270, %neg
  %1315 = fadd double %.184316, %1314
  %1316 = fmul double %1277, %neg
  %1317 = fadd double %.180317, %1316
  %1318 = fmul double %1285, %neg
  %1319 = fadd double %.1318, %1318
  %indvars.iv.next364 = add nsw i64 %indvars.iv363, 1
  %exitcond367.not = icmp eq i64 %wide.trip.count366, %indvars.iv.next364
  br i1 %exitcond367.not, label %after_for154.loopexit, label %for_loop_body152, !llvm.loop !14

after_for154.loopexit:                            ; preds = %for_loop_body152
  br label %after_for154

after_for154:                                     ; preds = %after_for154.loopexit, %after_for89
  %.184.lcssa = phi double [ %.083.lcssa, %after_for89 ], [ %1315, %after_for154.loopexit ]
  %.180.lcssa = phi double [ %.079.lcssa, %after_for89 ], [ %1317, %after_for154.loopexit ]
  %.1.lcssa = phi double [ %.077.lcssa, %after_for89 ], [ %1319, %after_for154.loopexit ]
  %1320 = load ptr, ptr %816, align 8
  %1321 = load i32, ptr %817, align 4
  %1322 = sext i32 %1321 to i64
  %1323 = getelementptr i32, ptr %1320, i64 %831
  %1324 = load i32, ptr %1323, align 4
  %1325 = add nsw i64 %1322, %831
  %1326 = getelementptr i32, ptr %1320, i64 %1325
  %1327 = load i32, ptr %1326, align 4
  %1328 = icmp slt i32 %1324, %1327
  br i1 %1328, label %for_loop_body157.preheader, label %after_for159

for_loop_body157.preheader:                       ; preds = %after_for154
  %1329 = sext i32 %1324 to i64
  %wide.trip.count371 = sext i32 %1327 to i64
  br label %for_loop_body157

for_loop_body157:                                 ; preds = %for_loop_body157, %for_loop_body157.preheader
  %indvars.iv368 = phi i64 [ %1329, %for_loop_body157.preheader ], [ %indvars.iv.next369, %for_loop_body157 ]
  %.2325 = phi double [ %.1.lcssa, %for_loop_body157.preheader ], [ %1401, %for_loop_body157 ]
  %.281324 = phi double [ %.180.lcssa, %for_loop_body157.preheader ], [ %1399, %for_loop_body157 ]
  %.285323 = phi double [ %.184.lcssa, %for_loop_body157.preheader ], [ %1397, %for_loop_body157 ]
  %1330 = atomicrmw add ptr %801, i64 1 seq_cst, align 8
  %1331 = load ptr, ptr %818, align 8
  %1332 = shl i64 %indvars.iv368, 2
  %uglygep473 = getelementptr i8, ptr %1331, i64 %1332
  %1333 = load i32, ptr %uglygep473, align 4
  %1334 = load ptr, ptr %814, align 8
  %1335 = load i32, ptr %815, align 4
  %1336 = sext i32 %1335 to i64
  %1337 = sext i32 %1333 to i64
  %1338 = getelementptr i32, ptr %1334, i64 %1337
  %1339 = load i32, ptr %1338, align 4
  %1340 = add nsw i64 %1336, %1337
  %1341 = getelementptr i32, ptr %1334, i64 %1340
  %1342 = load i32, ptr %1341, align 4
  %1343 = load ptr, ptr %809, align 8
  %1344 = load i32, ptr %810, align 4
  %1345 = sext i32 %1344 to i64
  %1346 = sext i32 %1342 to i64
  %1347 = getelementptr double, ptr %1343, i64 %1346
  %1348 = load double, ptr %1347, align 8
  %1349 = sext i32 %1339 to i64
  %1350 = getelementptr double, ptr %1343, i64 %1349
  %1351 = load double, ptr %1350, align 8
  %1352 = fsub double %1348, %1351
  %1353 = add nsw i64 %1345, %1346
  %1354 = getelementptr double, ptr %1343, i64 %1353
  %1355 = load double, ptr %1354, align 8
  %1356 = add nsw i64 %1345, %1349
  %1357 = getelementptr double, ptr %1343, i64 %1356
  %1358 = load double, ptr %1357, align 8
  %1359 = fsub double %1355, %1358
  %1360 = shl nsw i64 %1345, 1
  %1361 = add nsw i64 %1360, %1346
  %1362 = getelementptr double, ptr %1343, i64 %1361
  %1363 = load double, ptr %1362, align 8
  %1364 = add nsw i64 %1360, %1349
  %1365 = getelementptr double, ptr %1343, i64 %1364
  %1366 = load double, ptr %1365, align 8
  %1367 = fsub double %1363, %1366
  %1368 = mul nsw i64 %1345, 7
  %1369 = add nsw i64 %1368, %1349
  %1370 = getelementptr double, ptr %1343, i64 %1369
  %1371 = load double, ptr %1370, align 8
  %1372 = add nsw i64 %1368, %1346
  %1373 = getelementptr double, ptr %1343, i64 %1372
  %1374 = load double, ptr %1373, align 8
  %1375 = fmul double %1352, %1352
  %1376 = fmul double %1359, %1359
  %1377 = fadd double %1375, %1376
  %1378 = fmul double %1367, %1367
  %1379 = fadd double %1377, %1378
  %1380 = fcmp ogt double %1379, 0.000000e+00
  %.0.i123 = select i1 %1380, double 1.000000e+00, double 0.000000e+00
  %1381 = fsub double 1.000000e+00, %.0.i123
  %1382 = fadd double %1379, %1381
  %sqrt161 = tail call double @llvm.sqrt.f64(double %1382)
  %1383 = fdiv double 1.000000e+00, %sqrt161
  %1384 = fmul double %1382, %1383
  %1385 = fadd double %1371, %1374
  %1386 = fsub double %1385, %1384
  %1387 = tail call double @llvm.maxnum.f64(double %1386, double 0.000000e+00)
  %1388 = load ptr, ptr %9, align 8
  %1389 = getelementptr inbounds %struct.LLVMRuntime, ptr %1388, i64 0, i32 16
  %1390 = load ptr, ptr %1389, align 8
  %1391 = getelementptr inbounds i8, ptr %1390, i64 16
  %1392 = load double, ptr %1391, align 8
  %1393 = fmul double %.0.i123, %1383
  %1394 = fneg double %1392
  %1395 = fmul double %1387, %1394
  %neg162 = fmul double %1393, %1395
  %1396 = fmul double %1352, %neg162
  %1397 = fsub double %.285323, %1396
  %1398 = fmul double %1359, %neg162
  %1399 = fsub double %.281324, %1398
  %1400 = fmul double %1367, %neg162
  %1401 = fsub double %.2325, %1400
  %indvars.iv.next369 = add nsw i64 %indvars.iv368, 1
  %exitcond372.not = icmp eq i64 %wide.trip.count371, %indvars.iv.next369
  br i1 %exitcond372.not, label %after_for159.loopexit, label %for_loop_body157, !llvm.loop !15

after_for159.loopexit:                            ; preds = %for_loop_body157
  br label %after_for159

after_for159:                                     ; preds = %after_for159.loopexit, %after_for154
  %.285.lcssa = phi double [ %.184.lcssa, %after_for154 ], [ %1397, %after_for159.loopexit ]
  %.281.lcssa = phi double [ %.180.lcssa, %after_for154 ], [ %1399, %after_for159.loopexit ]
  %.2.lcssa = phi double [ %.1.lcssa, %after_for154 ], [ %1401, %after_for159.loopexit ]
  %1402 = bitcast double %.285.lcssa to i64
  %1403 = and i64 %1402, 9223372036854775807
  %1404 = and i64 %1402, 9218868437227405312
  %1405 = icmp eq i64 %1403, 0
  %1406 = icmp ne i64 %1404, 0
  %1407 = icmp ne i64 %1404, 9218868437227405312
  %1408 = and i1 %1406, %1407
  %1409 = or i1 %1405, %1408
  br i1 %1409, label %after_if168, label %true_block166

true_block166:                                    ; preds = %after_for159
  %1410 = load ptr, ptr %105, align 8
  %1411 = atomicrmw add ptr %1410, i64 1 seq_cst, align 8
  br label %after_if168

after_if168:                                      ; preds = %true_block166, %after_for159
  %1412 = load ptr, ptr %809, align 8
  %1413 = load i32, ptr %810, align 4
  %1414 = sext i32 %1413 to i64
  %1415 = shl nsw i64 %1414, 3
  %1416 = add nsw i64 %1415, %831
  %1417 = getelementptr double, ptr %1412, i64 %1416
  %1418 = load double, ptr %1417, align 8
  %1419 = fcmp one double %.285.lcssa, %1418
  %1420 = bitcast double %.281.lcssa to i64
  %1421 = and i64 %1420, 9223372036854775807
  %1422 = and i64 %1420, 9218868437227405312
  %1423 = icmp eq i64 %1421, 0
  %1424 = icmp ne i64 %1422, 0
  %1425 = icmp ne i64 %1422, 9218868437227405312
  %1426 = and i1 %1424, %1425
  %1427 = or i1 %1423, %1426
  br i1 %1427, label %after_if171, label %true_block169

true_block169:                                    ; preds = %after_if168
  %1428 = load ptr, ptr %105, align 8
  %1429 = atomicrmw add ptr %1428, i64 1 seq_cst, align 8
  %.pre379 = load ptr, ptr %809, align 8
  %.pre380 = load i32, ptr %810, align 4
  %.pre383 = sext i32 %.pre380 to i64
  br label %after_if171

after_if171:                                      ; preds = %true_block169, %after_if168
  %.pre-phi = phi i64 [ %1414, %after_if168 ], [ %.pre383, %true_block169 ]
  %1430 = phi ptr [ %1412, %after_if168 ], [ %.pre379, %true_block169 ]
  %1431 = mul nsw i64 %.pre-phi, 9
  %1432 = add nsw i64 %1431, %831
  %1433 = getelementptr double, ptr %1430, i64 %1432
  %1434 = load double, ptr %1433, align 8
  %1435 = fcmp one double %.281.lcssa, %1434
  %1436 = or i1 %1419, %1435
  %1437 = bitcast double %.2.lcssa to i64
  %1438 = and i64 %1437, 9223372036854775807
  %1439 = and i64 %1437, 9218868437227405312
  %1440 = icmp eq i64 %1438, 0
  %1441 = icmp ne i64 %1439, 0
  %1442 = icmp ne i64 %1439, 9218868437227405312
  %1443 = and i1 %1441, %1442
  %1444 = or i1 %1440, %1443
  br i1 %1444, label %after_if174, label %true_block172

true_block172:                                    ; preds = %after_if171
  %1445 = load ptr, ptr %105, align 8
  %1446 = atomicrmw add ptr %1445, i64 1 seq_cst, align 8
  %.pre381 = load ptr, ptr %809, align 8
  %.pre382 = load i32, ptr %810, align 4
  %.pre384 = sext i32 %.pre382 to i64
  br label %after_if174

after_if174:                                      ; preds = %true_block172, %after_if171
  %.pre-phi385 = phi i64 [ %.pre-phi, %after_if171 ], [ %.pre384, %true_block172 ]
  %1447 = phi ptr [ %1430, %after_if171 ], [ %.pre381, %true_block172 ]
  %1448 = mul nsw i64 %.pre-phi385, 10
  %1449 = add nsw i64 %1448, %831
  %1450 = getelementptr double, ptr %1447, i64 %1449
  %1451 = load double, ptr %1450, align 8
  %1452 = fcmp one double %.2.lcssa, %1451
  %1453 = or i1 %1436, %1452
  %1454 = xor i1 %943, true
  %1455 = and i1 %1453, %1454
  br i1 %1455, label %true_block175, label %after_if177

true_block175:                                    ; preds = %after_if174
  %1456 = load ptr, ptr %105, align 8
  %1457 = getelementptr i64, ptr %1456, i64 7
  %1458 = atomicrmw add ptr %1457, i64 1 seq_cst, align 8
  br label %after_if177

after_if177:                                      ; preds = %true_block175, %after_if174
  %1459 = or i1 %943, %1453
  br i1 %1459, label %true_block178, label %after_if180

true_block178:                                    ; preds = %after_if177
  %1460 = sdiv i32 %824, 32
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %6)
  %1461 = shl nsw i32 %1460, 3
  %1462 = sext i32 %1461 to i64
  %1463 = getelementptr i8, ptr %43, i64 %1462
  store volatile ptr %1463, ptr %6, align 8
  %1464 = getelementptr inbounds i8, ptr %1463, i64 32
  %1465 = load volatile ptr, ptr %1464, align 8
  %1466 = icmp eq ptr %1465, null
  br i1 %1466, label %1467, label %Pointer_activate.exit

1467:                                             ; preds = %true_block178
  %.0..0..0..0..0..i = load volatile ptr, ptr %6, align 8
  %.0..0..0..0..0.2.i = load volatile ptr, ptr %6, align 8
  br label %1468

1468:                                             ; preds = %1468, %1467
  %1469 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i, i32 1 seq_cst, align 4
  %1470 = icmp eq i32 %1469, 1
  br i1 %1470, label %1468, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i:                        ; preds = %1468
  %1471 = load volatile ptr, ptr %1464, align 8
  %1472 = icmp eq ptr %1471, null
  br i1 %1472, label %1473, label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i"

1473:                                             ; preds = %mutex_lock_i32.exit.i.i.i
  %1474 = load ptr, ptr %9, align 8
  %1475 = getelementptr inbounds %struct.LLVMRuntime, ptr %1474, i64 0, i32 14
  %1476 = load ptr, ptr %1475, align 8
  %1477 = getelementptr inbounds ptr, ptr %1476, i64 54
  %1478 = load ptr, ptr %1477, align 8
  %1479 = getelementptr inbounds %struct.NodeManager, ptr %1478, i64 0, i32 4
  %1480 = atomicrmw volatile add ptr %1479, i32 1 seq_cst, align 4
  %1481 = getelementptr inbounds %struct.NodeManager, ptr %1478, i64 0, i32 5
  %1482 = load ptr, ptr %1481, align 8
  %1483 = getelementptr inbounds %struct.ListManager, ptr %1482, i64 0, i32 5
  %1484 = load i32, ptr %1483, align 8
  %.not.i.i.i.i.i = icmp slt i32 %1480, %1484
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i, label %1485

1485:                                             ; preds = %1473
  %1486 = getelementptr inbounds %struct.NodeManager, ptr %1478, i64 0, i32 7
  %1487 = load ptr, ptr %1486, align 8
  %1488 = getelementptr inbounds %struct.ListManager, ptr %1487, i64 0, i32 5
  %1489 = atomicrmw volatile add ptr %1488, i32 1 seq_cst, align 4
  %1490 = getelementptr inbounds %struct.ListManager, ptr %1487, i64 0, i32 3
  %1491 = load i32, ptr %1490, align 8
  %1492 = ashr i32 %1489, %1491
  %1493 = icmp ugt i32 %1492, 131071
  br i1 %1493, label %1494, label %1497

1494:                                             ; preds = %1485
  %1495 = getelementptr inbounds %struct.ListManager, ptr %1487, i64 0, i32 6
  %1496 = load ptr, ptr %1495, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %1496, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

1497:                                             ; preds = %1485
  %1498 = zext i32 %1492 to i64
  %1499 = lshr i64 %1498, 9
  %1500 = getelementptr inbounds [256 x ptr], ptr %1487, i64 0, i64 %1499
  %1501 = load atomic i64, ptr %1500 acquire, align 8
  %.not.i.i.i4.i.i.i.i.i = icmp eq i64 %1501, 0
  br i1 %.not.i.i.i4.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i:  ; preds = %1497
  %1502 = inttoptr i64 %1501 to ptr
  %1503 = and i64 %1498, 511
  %1504 = getelementptr inbounds ptr, ptr %1502, i64 %1503
  %1505 = load atomic i64, ptr %1504 acquire, align 8
  %.not.i.i5.i.i.i.i.i = icmp eq i64 %1505, 0
  br i1 %.not.i.i5.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i, %1497
  %1506 = getelementptr inbounds %struct.ListManager, ptr %1487, i64 0, i32 4
  br label %1507

1507:                                             ; preds = %1507, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i
  %1508 = atomicrmw volatile xchg ptr %1506, i32 1 seq_cst, align 4
  %1509 = icmp eq i32 %1508, 1
  br i1 %1509, label %1507, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i:          ; preds = %1507
  %1510 = load atomic i64, ptr %1500 acquire, align 8
  %1511 = inttoptr i64 %1510 to ptr
  %.not.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %1510, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i, label %1512, label %1547

1512:                                             ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i
  %1513 = getelementptr inbounds %struct.ListManager, ptr %1487, i64 0, i32 6
  %1514 = load ptr, ptr %1513, align 8
  %1515 = getelementptr inbounds %struct.LLVMRuntime, ptr %1514, i64 0, i32 1
  %1516 = getelementptr inbounds %struct.LLVMRuntime, ptr %1514, i64 0, i32 28
  %1517 = atomicrmw volatile add ptr %1516, i64 4096 seq_cst, align 8
  %1518 = getelementptr inbounds %struct.LLVMRuntime, ptr %1514, i64 0, i32 1, i32 2
  %1519 = load i64, ptr %1518, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %1519, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i.i.i, label %1540, label %1520

1520:                                             ; preds = %1512
  %1521 = getelementptr inbounds %struct.LLVMRuntime, ptr %1514, i64 0, i32 26
  br label %1522

1522:                                             ; preds = %1522, %1520
  %1523 = atomicrmw volatile xchg ptr %1521, i32 1 seq_cst, align 4
  %1524 = icmp eq i32 %1523, 1
  br i1 %1524, label %1522, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i: ; preds = %1522
  %1525 = load ptr, ptr %1515, align 8
  %1526 = ptrtoint ptr %1525 to i64
  %1527 = getelementptr inbounds %struct.LLVMRuntime, ptr %1514, i64 0, i32 1, i32 1
  %1528 = load ptr, ptr %1527, align 8
  %1529 = ptrtoint ptr %1528 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %1526
  %1530 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i, 4095
  %1531 = or i64 %1530, 4096
  %1532 = add i64 %1531, %1526
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %1532, %1529
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i, label %1533

1533:                                             ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i
  %1534 = add i64 %1530, %1526
  %1535 = inttoptr i64 %1534 to ptr
  %1536 = getelementptr i8, ptr %1525, i64 %1530
  %1537 = getelementptr inbounds i8, ptr %1536, i64 4096
  store ptr %1537, ptr %1515, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i: ; preds = %1533, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i ], [ %1535, %1533 ]
  %1538 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i, true
  %1539 = atomicrmw volatile xchg ptr %1521, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %1514, i1 noundef zeroext %1538, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i

1540:                                             ; preds = %1512
  %1541 = getelementptr inbounds %struct.LLVMRuntime, ptr %1514, i64 0, i32 2
  %1542 = load ptr, ptr %1541, align 8
  %1543 = getelementptr inbounds %struct.LLVMRuntime, ptr %1514, i64 0, i32 6
  %1544 = load ptr, ptr %1543, align 8
  %1545 = tail call noundef ptr %1542(ptr noundef %1544, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i: ; preds = %1540, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i ], [ %1545, %1540 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %1546 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %1546, ptr %1500 release, align 8
  br label %1547

1547:                                             ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %1511, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i ]
  %1548 = and i32 %1492, 511
  %1549 = zext i32 %1548 to i64
  %1550 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i.i.i, i64 %1549
  %1551 = load atomic i64, ptr %1550 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %1551, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i.i.i, label %1552, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i"

1552:                                             ; preds = %1547
  %1553 = getelementptr inbounds %struct.ListManager, ptr %1487, i64 0, i32 6
  %1554 = load ptr, ptr %1553, align 8
  %1555 = getelementptr inbounds %struct.LLVMRuntime, ptr %1554, i64 0, i32 1
  %1556 = getelementptr inbounds %struct.ListManager, ptr %1487, i64 0, i32 2
  %1557 = load i64, ptr %1556, align 8
  %1558 = getelementptr inbounds %struct.ListManager, ptr %1487, i64 0, i32 1
  %1559 = load i64, ptr %1558, align 8
  %1560 = mul i64 %1559, %1557
  %1561 = getelementptr inbounds %struct.LLVMRuntime, ptr %1554, i64 0, i32 28
  %1562 = atomicrmw volatile add ptr %1561, i64 %1560 seq_cst, align 8
  %1563 = getelementptr inbounds %struct.LLVMRuntime, ptr %1554, i64 0, i32 1, i32 2
  %1564 = load i64, ptr %1563, align 8
  %.not.i.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %1564, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i, label %1584, label %1565

1565:                                             ; preds = %1552
  %1566 = getelementptr inbounds %struct.LLVMRuntime, ptr %1554, i64 0, i32 26
  br label %1567

1567:                                             ; preds = %1567, %1565
  %1568 = atomicrmw volatile xchg ptr %1566, i32 1 seq_cst, align 4
  %1569 = icmp eq i32 %1568, 1
  br i1 %1569, label %1567, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i: ; preds = %1567
  %1570 = load ptr, ptr %1555, align 8
  %1571 = ptrtoint ptr %1570 to i64
  %1572 = getelementptr inbounds %struct.LLVMRuntime, ptr %1554, i64 0, i32 1, i32 1
  %1573 = load ptr, ptr %1572, align 8
  %1574 = ptrtoint ptr %1573 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %1571
  %1575 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i, 4095
  %1576 = add i64 %1575, %1560
  %1577 = add i64 %1576, %1571
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %1577, %1574
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i, label %1578

1578:                                             ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %1579 = add i64 %1575, %1571
  %1580 = inttoptr i64 %1579 to ptr
  %1581 = getelementptr inbounds i8, ptr %1570, i64 %1576
  store ptr %1581, ptr %1555, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i: ; preds = %1578, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %1580, %1578 ]
  %1582 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %1583 = atomicrmw volatile xchg ptr %1566, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %1554, i1 noundef zeroext %1582, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i

1584:                                             ; preds = %1552
  %1585 = getelementptr inbounds %struct.LLVMRuntime, ptr %1554, i64 0, i32 2
  %1586 = load ptr, ptr %1585, align 8
  %1587 = getelementptr inbounds %struct.LLVMRuntime, ptr %1554, i64 0, i32 6
  %1588 = load ptr, ptr %1587, align 8
  %1589 = tail call noundef ptr %1586(ptr noundef %1588, i64 noundef %1560, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i: ; preds = %1584, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i ], [ %1589, %1584 ]
  %1590 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %1590, ptr %1550 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i, %1547
  %1591 = atomicrmw volatile xchg ptr %1506, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i:      ; preds = %1473
  %1592 = getelementptr inbounds %struct.ListManager, ptr %1482, i64 0, i32 3
  %1593 = load i32, ptr %1592, align 8
  %1594 = ashr i32 %1480, %1593
  %1595 = sext i32 %1594 to i64
  %1596 = lshr i64 %1595, 9
  %1597 = getelementptr inbounds [256 x ptr], ptr %1482, i64 0, i64 %1596
  %1598 = load atomic i64, ptr %1597 acquire, align 8
  %.not.i.i.i.i.i.i.i.i = icmp ne i64 %1598, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i.i.i.i.i)
  %1599 = inttoptr i64 %1598 to ptr
  %1600 = and i64 %1595, 511
  %1601 = getelementptr inbounds ptr, ptr %1599, i64 %1600
  %1602 = load atomic i64, ptr %1601 acquire, align 8
  %1603 = inttoptr i64 %1602 to ptr
  %1604 = getelementptr inbounds %struct.ListManager, ptr %1482, i64 0, i32 1
  %1605 = load i64, ptr %1604, align 8
  %1606 = load i32, ptr %1592, align 8
  %notmask.i.i.i.i.i.i.i = shl nsw i32 -1, %1606
  %1607 = xor i32 %notmask.i.i.i.i.i.i.i, -1
  %1608 = and i32 %1480, %1607
  %1609 = sext i32 %1608 to i64
  %1610 = mul i64 %1605, %1609
  %1611 = getelementptr inbounds i8, ptr %1603, i64 %1610
  %1612 = load i32, ptr %1611, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i: ; preds = %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i, %1494
  %.0.i.i.i.i.i = phi i32 [ %1612, %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i ], [ %1489, %1494 ], [ %1489, %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i ], [ %1489, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i" ]
  %1613 = getelementptr inbounds %struct.NodeManager, ptr %1478, i64 0, i32 7
  %1614 = load ptr, ptr %1613, align 8
  %1615 = getelementptr inbounds %struct.ListManager, ptr %1614, i64 0, i32 3
  %1616 = load i32, ptr %1615, align 8
  %1617 = ashr i32 %.0.i.i.i.i.i, %1616
  %1618 = sext i32 %1617 to i64
  %1619 = lshr i64 %1618, 9
  %1620 = getelementptr inbounds [256 x ptr], ptr %1614, i64 0, i64 %1619
  %1621 = load atomic i64, ptr %1620 acquire, align 8
  %.not.i.i.i.i.i.i.i = icmp eq i64 %1621, 0
  br i1 %.not.i.i.i.i.i.i.i, label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i", label %1622

1622:                                             ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i
  %1623 = inttoptr i64 %1621 to ptr
  %1624 = and i64 %1618, 511
  %1625 = getelementptr inbounds ptr, ptr %1623, i64 %1624
  %1626 = load atomic i64, ptr %1625 acquire, align 8
  %1627 = inttoptr i64 %1626 to ptr
  br label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i"

"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i":    ; preds = %1622, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i
  %1628 = phi ptr [ %1627, %1622 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i ]
  %1629 = getelementptr inbounds %struct.ListManager, ptr %1614, i64 0, i32 1
  %1630 = load i64, ptr %1629, align 8
  %1631 = load i32, ptr %1615, align 8
  %notmask.i.i.i.i.i.i = shl nsw i32 -1, %1631
  %1632 = xor i32 %notmask.i.i.i.i.i.i, -1
  %1633 = and i32 %.0.i.i.i.i.i, %1632
  %1634 = sext i32 %1633 to i64
  %1635 = mul i64 %1630, %1634
  %1636 = getelementptr inbounds i8, ptr %1628, i64 %1635
  %1637 = ptrtoint ptr %1636 to i64
  %1638 = atomicrmw volatile xchg ptr %1464, i64 %1637 seq_cst, align 8
  br label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i"

"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i": ; preds = %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i", %mutex_lock_i32.exit.i.i.i
  %1639 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i, i32 0 seq_cst, align 4
  br label %Pointer_activate.exit

Pointer_activate.exit:                            ; preds = %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i", %true_block178
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %6)
  %1640 = lshr i32 %824, 2
  %1641 = and i32 %1640, 1073741816
  %1642 = zext i32 %1641 to i64
  %1643 = getelementptr i8, ptr %43, i64 %1642
  %1644 = getelementptr inbounds i8, ptr %1643, i64 32
  %1645 = load ptr, ptr %1644, align 8
  %1646 = icmp eq ptr %1645, null
  br i1 %1646, label %1647, label %Pointer_lookup_element.exit

1647:                                             ; preds = %Pointer_activate.exit
  %1648 = load ptr, ptr %9, align 8
  %1649 = getelementptr inbounds %struct.LLVMRuntime, ptr %1648, i64 0, i32 15
  %1650 = load ptr, ptr %1649, align 8
  %1651 = getelementptr inbounds ptr, ptr %1650, i64 54
  %1652 = load ptr, ptr %1651, align 8
  br label %Pointer_lookup_element.exit

Pointer_lookup_element.exit:                      ; preds = %1647, %Pointer_activate.exit
  %.0.i = phi ptr [ %1652, %1647 ], [ %1645, %Pointer_activate.exit ]
  %1653 = and i32 %824, 31
  %1654 = getelementptr inbounds i8, ptr %.0.i, i64 32
  %1655 = shl nuw i32 1, %1653
  %1656 = atomicrmw volatile or ptr %1654, i32 %1655 seq_cst, align 4
  br label %after_if180

after_if180:                                      ; preds = %Pointer_lookup_element.exit, %after_if177
  %indvars.iv.next374 = add nuw nsw i64 %indvars.iv373, 1
  %exitcond377.not = icmp eq i64 %indvars.iv.next374, %wide.trip.count376
  br i1 %exitcond377.not, label %loop_body_tail.loopexit, label %for_loop_body83
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.sqrt.f64(double) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.maxnum.f64(double, double) #2

; Function Attrs: argmemonly mustprogress nofree norecurse nosync nounwind willreturn
define internal fastcc void @S57_refine_coordinates(ptr nocapture readonly %0, ptr nocapture writeonly %1, i32 %2) unnamed_addr #3 {
entry:
  %3 = and i32 %2, 3
  %4 = load i32, ptr %0, align 4
  %5 = shl i32 %4, 2
  %6 = or i32 %5, %3
  store i32 %6, ptr %1, align 4
  %7 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 1
  %8 = load i32, ptr %7, align 4
  %9 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 1
  store i32 %8, ptr %9, align 4
  %10 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 2
  %11 = load i32, ptr %10, align 4
  %12 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 2
  store i32 %11, ptr %12, align 4
  %13 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 3
  %14 = load i32, ptr %13, align 4
  %15 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 3
  store i32 %14, ptr %15, align 4
  %16 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 4
  %17 = load i32, ptr %16, align 4
  %18 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 4
  store i32 %17, ptr %18, align 4
  %19 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 5
  %20 = load i32, ptr %19, align 4
  %21 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 5
  store i32 %20, ptr %21, align 4
  %22 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 6
  %23 = load i32, ptr %22, align 4
  %24 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 6
  store i32 %23, ptr %24, align 4
  %25 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 7
  %26 = load i32, ptr %25, align 4
  %27 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 7
  store i32 %26, ptr %27, align 4
  %28 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 8
  %29 = load i32, ptr %28, align 4
  %30 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 8
  store i32 %29, ptr %30, align 4
  %31 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 9
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 9
  store i32 %32, ptr %33, align 4
  %34 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 10
  %35 = load i32, ptr %34, align 4
  %36 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 10
  store i32 %35, ptr %36, align 4
  %37 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 11
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 11
  store i32 %38, ptr %39, align 4
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #4

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn writeonly
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #5

; Function Attrs: noinline nounwind optnone uwtable
define internal fastcc void @taichi_assert_format(ptr noundef %0, i1 noundef zeroext %1, ptr noundef %2) unnamed_addr #6 {
  %4 = alloca ptr, align 8
  %5 = alloca i8, align 1
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca ptr, align 8
  %9 = alloca %class.anon, align 8
  store ptr %0, ptr %4, align 8
  %10 = zext i1 %1 to i8
  store i8 %10, ptr %5, align 1
  store ptr %2, ptr %6, align 8
  store i32 0, ptr %7, align 4
  store ptr null, ptr %8, align 8
  %11 = load i8, ptr %5, align 1
  %12 = trunc i8 %11 to i1
  %13 = zext i1 %12 to i32
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %15, label %16

15:                                               ; preds = %3
  br label %69

16:                                               ; preds = %3
  %17 = load ptr, ptr %4, align 8
  %18 = getelementptr inbounds %struct.LLVMRuntime, ptr %17, i32 0, i32 24
  %19 = load i64, ptr %18, align 8
  %20 = icmp ne i64 %19, 0
  br i1 %20, label %69, label %21

21:                                               ; preds = %16
  %22 = load ptr, ptr %4, align 8
  %23 = getelementptr inbounds %struct.LLVMRuntime, ptr %22, i32 0, i32 23
  %24 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 0
  store ptr %4, ptr %24, align 8
  %25 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 1
  store ptr %6, ptr %25, align 8
  %26 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 2
  store ptr %7, ptr %26, align 8
  %27 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 3
  store ptr %8, ptr %27, align 8
  br label %28

28:                                               ; preds = %28, %21
  %29 = atomicrmw volatile xchg ptr %23, i32 1 seq_cst, align 4
  %30 = icmp eq i32 %29, 1
  br i1 %30, label %28, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i:                        ; preds = %28
  %31 = load ptr, ptr %9, align 8
  %32 = load ptr, ptr %31, align 8
  %33 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 24
  %34 = load i64, ptr %33, align 8
  %.not.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i, label %35, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

35:                                               ; preds = %mutex_lock_i32.exit.i.i.i
  store i64 1, ptr %33, align 8
  %36 = load ptr, ptr %9, align 8
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr inbounds %struct.LLVMRuntime, ptr %37, i64 0, i32 21
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %38, i8 0, i64 2048, i1 false)
  %39 = load ptr, ptr %9, align 8
  %40 = load ptr, ptr %39, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 21
  %42 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 1
  %43 = load ptr, ptr %42, align 8
  %44 = load ptr, ptr %43, align 8
  %45 = load i8, ptr %44, align 1
  %.not5.i.i.i.i.i = icmp eq i8 %45, 0
  br i1 %.not5.i.i.i.i.i, label %taichi_strlen.exit.thread.i.i.i.i, label %.lr.ph.i.i.i.i.i.preheader

.lr.ph.i.i.i.i.i.preheader:                       ; preds = %35
  br label %.lr.ph.i.i.i.i.i

.lr.ph.i.i.i.i.i:                                 ; preds = %.lr.ph.i.i.i.i.i, %.lr.ph.i.i.i.i.i.preheader
  %.07.i.i.i.i.i = phi ptr [ %47, %.lr.ph.i.i.i.i.i ], [ %44, %.lr.ph.i.i.i.i.i.preheader ]
  %.046.i.i.i.i.i = phi i64 [ %46, %.lr.ph.i.i.i.i.i ], [ 0, %.lr.ph.i.i.i.i.i.preheader ]
  %46 = add i64 %.046.i.i.i.i.i, 1
  %47 = getelementptr inbounds i8, ptr %.07.i.i.i.i.i, i64 1
  %48 = load i8, ptr %47, align 1
  %.not.i.i.i.i.i = icmp eq i8 %48, 0
  br i1 %.not.i.i.i.i.i, label %taichi_strlen.exit.i.i.i.i, label %.lr.ph.i.i.i.i.i, !llvm.loop !16

taichi_strlen.exit.i.i.i.i:                       ; preds = %.lr.ph.i.i.i.i.i
  %.lcssa = phi i64 [ %46, %.lr.ph.i.i.i.i.i ]
  %49 = call i64 @llvm.umin.i64(i64 %.lcssa, i64 2047)
  br label %taichi_strlen.exit.thread.i.i.i.i

taichi_strlen.exit.thread.i.i.i.i:                ; preds = %taichi_strlen.exit.i.i.i.i, %35
  %50 = phi i64 [ 0, %35 ], [ %49, %taichi_strlen.exit.i.i.i.i ]
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %41, ptr nonnull align 1 %44, i64 %50, i1 false)
  %51 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 2
  %52 = load ptr, ptr %51, align 8
  %53 = load i32, ptr %52, align 4
  %54 = icmp sgt i32 %53, 0
  br i1 %54, label %.lr.ph.i.i.i.i, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

.lr.ph.i.i.i.i:                                   ; preds = %taichi_strlen.exit.thread.i.i.i.i
  %55 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 3
  br label %56

56:                                               ; preds = %56, %.lr.ph.i.i.i.i
  %indvars.iv.i.i.i.i = phi i64 [ 0, %.lr.ph.i.i.i.i ], [ %indvars.iv.next.i.i.i.i, %56 ]
  %57 = load ptr, ptr %55, align 8
  %58 = load ptr, ptr %57, align 8
  %59 = getelementptr inbounds i64, ptr %58, i64 %indvars.iv.i.i.i.i
  %60 = load i64, ptr %59, align 8
  %61 = load ptr, ptr %9, align 8
  %62 = load ptr, ptr %61, align 8
  %63 = getelementptr inbounds %struct.LLVMRuntime, ptr %62, i64 0, i32 22, i64 %indvars.iv.i.i.i.i
  store i64 %60, ptr %63, align 8
  %indvars.iv.next.i.i.i.i = add nuw nsw i64 %indvars.iv.i.i.i.i, 1
  %64 = load ptr, ptr %51, align 8
  %65 = load i32, ptr %64, align 4
  %66 = sext i32 %65 to i64
  %67 = icmp slt i64 %indvars.iv.next.i.i.i.i, %66
  br i1 %67, label %56, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", !llvm.loop !17

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit": ; preds = %56
  br label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit": ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", %taichi_strlen.exit.thread.i.i.i.i, %mutex_lock_i32.exit.i.i.i
  %68 = atomicrmw volatile xchg ptr %23, i32 0 seq_cst, align 4
  br label %69

69:                                               ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit", %16, %15
  ret void
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_struct_for_block_helper(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #7 {
_ZN11ListManager3getI7ElementEERT_i.exit:
  %3 = alloca %struct.RuntimeContext.2212, align 8
  %4 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 4
  %5 = load i32, ptr %4, align 4
  %6 = sdiv i32 %2, %5
  %7 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  %8 = load i32, ptr %7, align 8
  %9 = sdiv i32 %8, %5
  %10 = srem i32 %2, %5
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  %12 = load ptr, ptr %11, align 8
  %13 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %14 = load i32, ptr %13, align 8
  %15 = ashr i32 %6, %14
  %16 = sext i32 %15 to i64
  %17 = lshr i64 %16, 9
  %18 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %17
  %19 = load atomic i64, ptr %18 acquire, align 8
  %.not.i.i.i = icmp ne i64 %19, 0
  tail call void @llvm.assume(i1 %.not.i.i.i)
  %20 = inttoptr i64 %19 to ptr
  %21 = and i64 %16, 511
  %22 = getelementptr inbounds ptr, ptr %20, i64 %21
  %23 = load atomic i64, ptr %22 acquire, align 8
  %24 = inttoptr i64 %23 to ptr
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %26 = load i64, ptr %25, align 8
  %27 = load i32, ptr %13, align 8
  %notmask.i.i = shl nsw i32 -1, %27
  %28 = xor i32 %notmask.i.i, -1
  %29 = and i32 %6, %28
  %30 = sext i32 %29 to i64
  %31 = mul i64 %26, %30
  %32 = getelementptr inbounds i8, ptr %24, i64 %31
  %33 = getelementptr inbounds %0, ptr %32, i64 0, i32 1
  %34 = load i32, ptr %33, align 8
  %35 = mul nsw i32 %10, %9
  %36 = add nsw i32 %34, %35
  %37 = add nsw i32 %10, 1
  %38 = mul nsw i32 %37, %9
  %39 = add nsw i32 %34, %38
  %40 = getelementptr inbounds %0, ptr %32, i64 0, i32 1, i64 1
  %41 = load i32, ptr %40, align 4
  %42 = tail call i32 @llvm.smin.i32(i32 %41, i32 %39)
  %43 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  %44 = load i64, ptr %43, align 8
  %45 = alloca i8, i64 %44, align 8
  %46 = load ptr, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %3, ptr noundef nonnull align 8 dereferenceable(32) %46, i64 32, i1 false)
  %47 = getelementptr inbounds %struct.RuntimeContext.2212, ptr %3, i64 0, i32 2
  store i32 %1, ptr %47, align 8
  %48 = icmp slt i32 %36, %42
  br i1 %48, label %49, label %75

49:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit
  %50 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = load ptr, ptr %11, align 8
  %53 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 3
  %54 = load i32, ptr %53, align 8
  %55 = ashr i32 %6, %54
  %56 = sext i32 %55 to i64
  %57 = lshr i64 %56, 9
  %58 = getelementptr inbounds [256 x ptr], ptr %52, i64 0, i64 %57
  %59 = load atomic i64, ptr %58 acquire, align 8
  %.not.i.i.i24 = icmp eq i64 %59, 0
  br i1 %.not.i.i.i24, label %_ZN11ListManager3getI7ElementEERT_i.exit26, label %60

60:                                               ; preds = %49
  %61 = inttoptr i64 %59 to ptr
  %62 = and i64 %56, 511
  %63 = getelementptr inbounds ptr, ptr %61, i64 %62
  %64 = load atomic i64, ptr %63 acquire, align 8
  %65 = inttoptr i64 %64 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit26

_ZN11ListManager3getI7ElementEERT_i.exit26:       ; preds = %60, %49
  %66 = phi ptr [ %65, %60 ], [ null, %49 ]
  %67 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 1
  %68 = load i64, ptr %67, align 8
  %69 = load i32, ptr %53, align 8
  %notmask.i.i25 = shl nsw i32 -1, %69
  %70 = xor i32 %notmask.i.i25, -1
  %71 = and i32 %6, %70
  %72 = sext i32 %71 to i64
  %73 = mul i64 %68, %72
  %74 = getelementptr inbounds i8, ptr %66, i64 %73
  call void %51(ptr noundef nonnull %3, ptr noundef nonnull %45, ptr noundef nonnull %74, i32 noundef %36, i32 noundef %42) #1
  br label %75

75:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit26, %_ZN11ListManager3getI7ElementEERT_i.exit
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i64 @llvm.umin.i64(i64, i64) #8

; Function Attrs: inaccessiblememonly nocallback nofree nosync nounwind willreturn
declare void @llvm.assume(i1 noundef) #9

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #8

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #10

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #10

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #3 = { argmemonly mustprogress nofree norecurse nosync nounwind willreturn }
attributes #4 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #5 = { argmemonly mustprogress nocallback nofree nounwind willreturn writeonly }
attributes #6 = { noinline nounwind optnone uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #9 = { inaccessiblememonly nocallback nofree nosync nounwind willreturn }
attributes #10 = { argmemonly nocallback nofree nosync nounwind willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7, !8}
!7 = !{!"llvm.loop.mustprogress"}
!8 = !{!"llvm.loop.unroll.disable"}
!9 = distinct !{!9, !7, !8}
!10 = distinct !{!10, !7, !8}
!11 = distinct !{!11, !7, !8}
!12 = distinct !{!12, !8}
!13 = distinct !{!13, !8}
!14 = distinct !{!14, !8}
!15 = distinct !{!15, !8}
!16 = distinct !{!16, !7, !8}
!17 = distinct !{!17, !7, !8}
