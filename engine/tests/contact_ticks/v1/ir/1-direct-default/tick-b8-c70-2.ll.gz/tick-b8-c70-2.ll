; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%0 = type { ptr, [2 x i32], %struct.PhysicalCoordinates.712 }
%struct.RuntimeContext.699 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }
%struct.ListManager = type { [256 x ptr], i64, i64, i32, i32, i32, ptr }
%struct.PhysicalCoordinates.712 = type { [12 x i32] }
%struct.cpu_block_task_helper_context = type { ptr, ptr, ptr, i32, i32, i64 }
%class.anon = type { ptr, ptr, ptr, ptr }

@.str = private unnamed_addr constant [28 x i8] c"Out of pre-allocated memory\00", align 1
@.str.2 = private unnamed_addr constant [28 x i8] c"List manager out of chunks.\00", align 1

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @field_contact_25_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %0, i64 0, i32 3
  %2 = load double, ptr %1, align 8
  %3 = getelementptr inbounds %struct.RuntimeContext.699, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  store double %2, ptr %6, align 8
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @field_contact_25_kernel_1_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.699, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 24
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @field_contact_25_kernel_2_listgen_S24pointer(ptr %context) local_unnamed_addr #1 {
.lr.ph.i:
  %.sroa.2.i = alloca { [2 x i32], %struct.PhysicalCoordinates.712 }, align 8
  %0 = alloca %0, align 8
  %1 = getelementptr inbounds %struct.RuntimeContext.699, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 23
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %4, i64 24
  %8 = load ptr, ptr %7, align 8
  %9 = load atomic i64, ptr %6 acquire, align 8
  %.not.i.i.i.i = icmp ne i64 %9, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i)
  %10 = inttoptr i64 %9 to ptr
  %11 = load atomic i64, ptr %10 acquire, align 8
  %12 = inttoptr i64 %11 to ptr
  %.sroa.0.0.copyload.i = load ptr, ptr %12, align 8
  %.sroa.2.0..sroa_idx.i = getelementptr inbounds i8, ptr %12, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.i, ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.0..sroa_idx.i, i64 56, i1 false)
  %13 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %.sroa.2.16.sroa_idx.i = getelementptr inbounds i8, ptr %.sroa.2.i, i64 8
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %16 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 4
  %17 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 6
  %18 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 2
  %19 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  store ptr %.sroa.0.0.copyload.i, ptr %0, align 8
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %0, i64 8
  store <2 x i32> <i32 0, i32 4>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %13, ptr noundef nonnull align 8 dereferenceable(48) %.sroa.2.16.sroa_idx.i, i64 48, i1 false)
  %20 = atomicrmw volatile add ptr %14, i32 1 seq_cst, align 4
  %21 = load i32, ptr %15, align 8
  %22 = ashr i32 %20, %21
  %23 = icmp ugt i32 %22, 131071
  br i1 %23, label %24, label %26

24:                                               ; preds = %.lr.ph.i
  %25 = load ptr, ptr %17, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %25, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

26:                                               ; preds = %.lr.ph.i
  %27 = zext i32 %22 to i64
  %28 = lshr i64 %27, 9
  %29 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %28
  %30 = load atomic i64, ptr %29 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %30, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %26
  %31 = inttoptr i64 %30 to ptr
  %32 = and i64 %27, 511
  %33 = getelementptr inbounds ptr, ptr %31, i64 %32
  %34 = load atomic i64, ptr %33 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %26
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %35 = atomicrmw volatile xchg ptr %16, i32 1 seq_cst, align 4
  %36 = icmp eq i32 %35, 1
  br i1 %36, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %37 = load atomic i64, ptr %29 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %37, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %39, label %73

39:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %40 = load ptr, ptr %17, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1
  %42 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 28
  %43 = atomicrmw volatile add ptr %42, i64 4096 seq_cst, align 8
  %44 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 2
  %45 = load i64, ptr %44, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %45, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %66, label %46

46:                                               ; preds = %39
  %47 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 26
  br label %48

48:                                               ; preds = %48, %46
  %49 = atomicrmw volatile xchg ptr %47, i32 1 seq_cst, align 4
  %50 = icmp eq i32 %49, 1
  br i1 %50, label %48, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %48
  %51 = load ptr, ptr %41, align 8
  %52 = ptrtoint ptr %51 to i64
  %53 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 1
  %54 = load ptr, ptr %53, align 8
  %55 = ptrtoint ptr %54 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %52
  %56 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %57 = or i64 %56, 4096
  %58 = add i64 %57, %52
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %58, %55
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %59

59:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %60 = add i64 %56, %52
  %61 = inttoptr i64 %60 to ptr
  %62 = getelementptr i8, ptr %51, i64 %56
  %63 = getelementptr inbounds i8, ptr %62, i64 4096
  store ptr %63, ptr %41, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %59, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %61, %59 ]
  %64 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %65 = atomicrmw volatile xchg ptr %47, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %40, i1 noundef zeroext %64, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

66:                                               ; preds = %39
  %67 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 2
  %68 = load ptr, ptr %67, align 8
  %69 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 6
  %70 = load ptr, ptr %69, align 8
  %71 = tail call noundef ptr %68(ptr noundef %70, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %66, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %71, %66 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %72 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %72, ptr %29 release, align 8
  br label %73

73:                                               ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %38, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %74 = and i32 %22, 511
  %75 = zext i32 %74 to i64
  %76 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %75
  %77 = load atomic i64, ptr %76 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %77, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %78, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

78:                                               ; preds = %73
  %79 = load ptr, ptr %17, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1
  %81 = load i64, ptr %18, align 8
  %82 = load i64, ptr %19, align 8
  %83 = mul i64 %82, %81
  %84 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 28
  %85 = atomicrmw volatile add ptr %84, i64 %83 seq_cst, align 8
  %86 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 2
  %87 = load i64, ptr %86, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %87, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %107, label %88

88:                                               ; preds = %78
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 26
  br label %90

90:                                               ; preds = %90, %88
  %91 = atomicrmw volatile xchg ptr %89, i32 1 seq_cst, align 4
  %92 = icmp eq i32 %91, 1
  br i1 %92, label %90, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %90
  %93 = load ptr, ptr %80, align 8
  %94 = ptrtoint ptr %93 to i64
  %95 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 1
  %96 = load ptr, ptr %95, align 8
  %97 = ptrtoint ptr %96 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %94
  %98 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %99 = add i64 %98, %83
  %100 = add i64 %99, %94
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %100, %97
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %101

101:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %102 = add i64 %98, %94
  %103 = inttoptr i64 %102 to ptr
  %104 = getelementptr inbounds i8, ptr %93, i64 %99
  store ptr %104, ptr %80, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %101, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %103, %101 ]
  %105 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %106 = atomicrmw volatile xchg ptr %89, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %79, i1 noundef zeroext %105, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

107:                                              ; preds = %78
  %108 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 2
  %109 = load ptr, ptr %108, align 8
  %110 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 6
  %111 = load ptr, ptr %110, align 8
  %112 = tail call noundef ptr %109(ptr noundef %111, i64 noundef %83, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %107, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %112, %107 ]
  %113 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %113, ptr %76 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %73
  %114 = atomicrmw volatile xchg ptr %16, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %24
  %115 = load i32, ptr %15, align 8
  %116 = ashr i32 %20, %115
  %117 = sext i32 %116 to i64
  %118 = lshr i64 %117, 9
  %119 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %118
  %120 = load atomic i64, ptr %119 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %120, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %121

121:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %122 = inttoptr i64 %120 to ptr
  %123 = and i64 %117, 511
  %124 = getelementptr inbounds ptr, ptr %122, i64 %123
  %125 = load atomic i64, ptr %124 acquire, align 8
  %126 = inttoptr i64 %125 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %121, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %127 = phi ptr [ %126, %121 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %128 = load i64, ptr %19, align 8
  %129 = load i32, ptr %15, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %129
  %130 = xor i32 %notmask.i.i.i.i, -1
  %131 = and i32 %20, %130
  %132 = sext i32 %131 to i64
  %133 = mul i64 %128, %132
  %134 = getelementptr inbounds i8, ptr %127, i64 %133
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %134, ptr nonnull align 8 %0, i64 %128, i1 false)
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @field_contact_25_kernel_3_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.699, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 25
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @field_contact_25_kernel_4_listgen_S25bitmasked(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %0, align 8
  %1 = alloca %struct.PhysicalCoordinates.712, align 4
  %2 = alloca %0, align 8
  %3 = getelementptr inbounds %struct.RuntimeContext.699, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %2)
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 13
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %6, i64 24
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %10 = load i32, ptr %9, align 8
  %11 = getelementptr inbounds ptr, ptr %6, i64 25
  %12 = load ptr, ptr %11, align 8
  %13 = icmp sgt i32 %10, 0
  br i1 %13, label %.lr.ph61.i, label %element_listgen_nonroot.exit

.lr.ph61.i:                                       ; preds = %entry
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  %16 = getelementptr inbounds %0, ptr %0, i64 0, i32 1
  %17 = getelementptr inbounds %0, ptr %0, i64 0, i32 1, i64 1
  %18 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %19 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %20 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 5
  %21 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %22 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 4
  %23 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 6
  %24 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 2
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %2, i64 8
  br label %26

26:                                               ; preds = %._crit_edge.i, %.lr.ph61.i
  %.04359.i = phi i32 [ 0, %.lr.ph61.i ], [ %172, %._crit_edge.i ]
  %27 = load i32, ptr %14, align 8
  %28 = lshr i32 %.04359.i, %27
  %29 = sext i32 %28 to i64
  %30 = lshr i64 %29, 9
  %31 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %30
  %32 = load atomic i64, ptr %31 acquire, align 8
  %.not.i.i.i.i = icmp eq i64 %32, 0
  br i1 %.not.i.i.i.i, label %_ZN11ListManager3getI7ElementEERT_i.exit.i, label %33

33:                                               ; preds = %26
  %34 = inttoptr i64 %32 to ptr
  %35 = and i64 %29, 511
  %36 = getelementptr inbounds ptr, ptr %34, i64 %35
  %37 = load atomic i64, ptr %36 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit.i

_ZN11ListManager3getI7ElementEERT_i.exit.i:       ; preds = %33, %26
  %39 = phi ptr [ %38, %33 ], [ null, %26 ]
  %40 = load i64, ptr %15, align 8
  %41 = load i32, ptr %14, align 8
  %notmask.i.i.i = shl nsw i32 -1, %41
  %42 = xor i32 %notmask.i.i.i, -1
  %43 = and i32 %.04359.i, %42
  %44 = zext i32 %43 to i64
  %45 = mul i64 %40, %44
  %46 = getelementptr inbounds i8, ptr %39, i64 %45
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %0, ptr noundef nonnull align 8 dereferenceable(64) %46, i64 64, i1 false)
  %47 = load i32, ptr %16, align 8
  %48 = load i32, ptr %17, align 4
  %49 = icmp slt i32 %47, %48
  br i1 %49, label %.lr.ph58.i.preheader, label %._crit_edge.i

.lr.ph58.i.preheader:                             ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit.i
  br label %.lr.ph58.i

.lr.ph58.i:                                       ; preds = %.loopexit.i, %.lr.ph58.i.preheader
  %.04457.i = phi i32 [ %171, %.loopexit.i ], [ %47, %.lr.ph58.i.preheader ]
  call fastcc void @S24_refine_coordinates(ptr noundef nonnull %18, ptr noundef nonnull %1, i32 noundef %.04457.i) #1
  %50 = load ptr, ptr %0, align 8
  %51 = shl i32 %.04457.i, 3
  %52 = sext i32 %51 to i64
  %53 = getelementptr i8, ptr %50, i64 %52
  %54 = getelementptr inbounds i8, ptr %53, i64 32
  %55 = load ptr, ptr %54, align 8
  %.not = icmp eq ptr %55, null
  br i1 %.not, label %.loopexit.i, label %.lr.ph.i

.lr.ph.i:                                         ; preds = %.lr.ph58.i
  store ptr %55, ptr %2, align 8
  store <2 x i32> <i32 0, i32 32>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %19, ptr noundef nonnull align 4 dereferenceable(48) %1, i64 48, i1 false)
  %56 = atomicrmw volatile add ptr %20, i32 1 seq_cst, align 4
  %57 = load i32, ptr %21, align 8
  %58 = ashr i32 %56, %57
  %59 = icmp ugt i32 %58, 131071
  br i1 %59, label %60, label %62

60:                                               ; preds = %.lr.ph.i
  %61 = load ptr, ptr %23, align 8
  call fastcc void @taichi_assert_format(ptr noundef %61, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

62:                                               ; preds = %.lr.ph.i
  %63 = zext i32 %58 to i64
  %64 = lshr i64 %63, 9
  %65 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %64
  %66 = load atomic i64, ptr %65 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %66, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %62
  %67 = inttoptr i64 %66 to ptr
  %68 = and i64 %63, 511
  %69 = getelementptr inbounds ptr, ptr %67, i64 %68
  %70 = load atomic i64, ptr %69 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %70, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %62
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %71 = atomicrmw volatile xchg ptr %22, i32 1 seq_cst, align 4
  %72 = icmp eq i32 %71, 1
  br i1 %72, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %73 = load atomic i64, ptr %65 acquire, align 8
  %74 = inttoptr i64 %73 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %73, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %75, label %109

75:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %76 = load ptr, ptr %23, align 8
  %77 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1
  %78 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 28
  %79 = atomicrmw volatile add ptr %78, i64 4096 seq_cst, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 2
  %81 = load i64, ptr %80, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %81, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %102, label %82

82:                                               ; preds = %75
  %83 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 26
  br label %84

84:                                               ; preds = %84, %82
  %85 = atomicrmw volatile xchg ptr %83, i32 1 seq_cst, align 4
  %86 = icmp eq i32 %85, 1
  br i1 %86, label %84, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %84
  %87 = load ptr, ptr %77, align 8
  %88 = ptrtoint ptr %87 to i64
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 1
  %90 = load ptr, ptr %89, align 8
  %91 = ptrtoint ptr %90 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %88
  %92 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %93 = or i64 %92, 4096
  %94 = add i64 %93, %88
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %94, %91
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %95

95:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %96 = add i64 %92, %88
  %97 = inttoptr i64 %96 to ptr
  %98 = getelementptr i8, ptr %87, i64 %92
  %99 = getelementptr inbounds i8, ptr %98, i64 4096
  store ptr %99, ptr %77, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %95, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %97, %95 ]
  %100 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %101 = atomicrmw volatile xchg ptr %83, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %76, i1 noundef zeroext %100, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

102:                                              ; preds = %75
  %103 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 2
  %104 = load ptr, ptr %103, align 8
  %105 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 6
  %106 = load ptr, ptr %105, align 8
  %107 = call noundef ptr %104(ptr noundef %106, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %102, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %107, %102 ]
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %108 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %108, ptr %65 release, align 8
  br label %109

109:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %74, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %110 = and i32 %58, 511
  %111 = zext i32 %110 to i64
  %112 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %111
  %113 = load atomic i64, ptr %112 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %113, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %114, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

114:                                              ; preds = %109
  %115 = load ptr, ptr %23, align 8
  %116 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1
  %117 = load i64, ptr %24, align 8
  %118 = load i64, ptr %25, align 8
  %119 = mul i64 %118, %117
  %120 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 28
  %121 = atomicrmw volatile add ptr %120, i64 %119 seq_cst, align 8
  %122 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 2
  %123 = load i64, ptr %122, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %123, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %143, label %124

124:                                              ; preds = %114
  %125 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 26
  br label %126

126:                                              ; preds = %126, %124
  %127 = atomicrmw volatile xchg ptr %125, i32 1 seq_cst, align 4
  %128 = icmp eq i32 %127, 1
  br i1 %128, label %126, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %126
  %129 = load ptr, ptr %116, align 8
  %130 = ptrtoint ptr %129 to i64
  %131 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 1
  %132 = load ptr, ptr %131, align 8
  %133 = ptrtoint ptr %132 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %130
  %134 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %135 = add i64 %134, %119
  %136 = add i64 %135, %130
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %136, %133
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %137

137:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %138 = add i64 %134, %130
  %139 = inttoptr i64 %138 to ptr
  %140 = getelementptr inbounds i8, ptr %129, i64 %135
  store ptr %140, ptr %116, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %137, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %139, %137 ]
  %141 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %142 = atomicrmw volatile xchg ptr %125, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %115, i1 noundef zeroext %141, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

143:                                              ; preds = %114
  %144 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 2
  %145 = load ptr, ptr %144, align 8
  %146 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 6
  %147 = load ptr, ptr %146, align 8
  %148 = call noundef ptr %145(ptr noundef %147, i64 noundef %119, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %143, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %148, %143 ]
  %149 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %149, ptr %112 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %109
  %150 = atomicrmw volatile xchg ptr %22, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %60
  %151 = load i32, ptr %21, align 8
  %152 = ashr i32 %56, %151
  %153 = sext i32 %152 to i64
  %154 = lshr i64 %153, 9
  %155 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %154
  %156 = load atomic i64, ptr %155 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %156, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %157

157:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %158 = inttoptr i64 %156 to ptr
  %159 = and i64 %153, 511
  %160 = getelementptr inbounds ptr, ptr %158, i64 %159
  %161 = load atomic i64, ptr %160 acquire, align 8
  %162 = inttoptr i64 %161 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %157, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %163 = phi ptr [ %162, %157 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %164 = load i64, ptr %25, align 8
  %165 = load i32, ptr %21, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %165
  %166 = xor i32 %notmask.i.i.i.i, -1
  %167 = and i32 %56, %166
  %168 = sext i32 %167 to i64
  %169 = mul i64 %164, %168
  %170 = getelementptr inbounds i8, ptr %163, i64 %169
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %170, ptr nonnull align 8 %2, i64 %164, i1 false)
  br label %.loopexit.i, !llvm.loop !8

.loopexit.i:                                      ; preds = %_ZN11ListManager6appendEPv.exit.i, %.lr.ph58.i
  %171 = add i32 %.04457.i, 1
  %exitcond.not.i = icmp eq i32 %171, %48
  br i1 %exitcond.not.i, label %._crit_edge.i.loopexit, label %.lr.ph58.i, !llvm.loop !9

._crit_edge.i.loopexit:                           ; preds = %.loopexit.i
  br label %._crit_edge.i

._crit_edge.i:                                    ; preds = %._crit_edge.i.loopexit, %_ZN11ListManager3getI7ElementEERT_i.exit.i
  %172 = add nuw nsw i32 %.04359.i, 1
  %exitcond63.not.i = icmp eq i32 %172, %10
  br i1 %exitcond63.not.i, label %element_listgen_nonroot.exit.loopexit, label %26, !llvm.loop !10

element_listgen_nonroot.exit.loopexit:            ; preds = %._crit_edge.i
  br label %element_listgen_nonroot.exit

element_listgen_nonroot.exit:                     ; preds = %element_listgen_nonroot.exit.loopexit, %entry
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %2)
  ret void
}

; Function Attrs: nounwind
define void @field_contact_25_kernel_5_struct_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.cpu_block_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.RuntimeContext.699, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 25
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds %struct.ListManager, ptr %6, i64 0, i32 5
  %8 = load i32, ptr %7, align 8
  store ptr %context, ptr %0, align 8
  %9 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  store ptr @function_body, ptr %9, align 8
  %10 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  store ptr %6, ptr %10, align 8
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  store <2 x i32> <i32 32, i32 8>, ptr %11, align 8
  %12 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  store i64 1, ptr %12, align 8
  %13 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 12
  %14 = load ptr, ptr %13, align 8
  %15 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 11
  %16 = load ptr, ptr %15, align 8
  %17 = shl nsw i32 %8, 3
  call void %14(ptr noundef %16, i32 noundef %17, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_struct_for_block_helper) #1
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nounwind
define internal void @function_body(ptr %0, ptr nocapture readnone %1, ptr nocapture readonly %2, i32 %3, i32 %4) #2 {
allocs:
  %5 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %6 = icmp slt i32 %3, %4
  br i1 %6, label %loop_body.lr.ph, label %func_exit

loop_body.lr.ph:                                  ; preds = %allocs
  %7 = getelementptr inbounds %struct.RuntimeContext.699, ptr %0, i64 0, i32 1
  br label %loop_body

loop_body:                                        ; preds = %loop_body_tail, %loop_body.lr.ph
  %.01135 = phi i32 [ %3, %loop_body.lr.ph ], [ %18, %loop_body_tail ]
  %8 = load ptr, ptr %2, align 8
  %9 = getelementptr inbounds i8, ptr %8, i64 32
  %10 = sdiv i32 %.01135, 8
  %11 = sext i32 %10 to i64
  %12 = getelementptr inbounds i8, ptr %9, i64 %11
  %13 = load i8, ptr %12, align 1
  %14 = zext i8 %13 to i32
  %15 = and i32 %.01135, 7
  %16 = shl nuw nsw i32 1, %15
  %17 = and i32 %16, %14
  %.not = icmp eq i32 %17, 0
  br i1 %.not, label %loop_body_tail, label %struct_for_body_body

loop_body_tail.loopexit:                          ; preds = %after_if32.1
  br label %loop_body_tail

loop_body_tail:                                   ; preds = %for_loop_body13.prol.loopexit, %after_for, %loop_body_tail.loopexit, %loop_body
  %18 = add nsw i32 %.01135, 1
  %exitcond42.not = icmp eq i32 %18, %4
  br i1 %exitcond42.not, label %func_exit.loopexit, label %loop_body

func_exit.loopexit:                               ; preds = %loop_body_tail
  br label %func_exit

func_exit:                                        ; preds = %func_exit.loopexit, %allocs
  ret void

struct_for_body_body:                             ; preds = %loop_body
  %19 = load i32, ptr %5, align 4
  %20 = shl i32 %19, 5
  %21 = and i32 %.01135, 31
  %22 = or i32 %20, %21
  %23 = load ptr, ptr %0, align 8
  %24 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %23, i64 0, i32 6, i32 1
  %25 = load ptr, ptr %24, align 8
  %26 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %23, i64 0, i32 6, i32 0, i32 1
  %27 = load i32, ptr %26, align 4
  %28 = sext i32 %27 to i64
  %29 = sext i32 %22 to i64
  %30 = getelementptr i32, ptr %25, i64 %29
  %31 = load i32, ptr %30, align 4
  %32 = add nsw i64 %28, %29
  %33 = getelementptr i32, ptr %25, i64 %32
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %23, i64 0, i32 5, i32 1
  %36 = load ptr, ptr %35, align 8
  %37 = getelementptr i64, ptr %36, i64 3
  %38 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %23, i64 0, i32 1, i32 1
  %39 = load ptr, ptr %38, align 8
  %40 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %23, i64 0, i32 1, i32 0, i32 1
  %41 = load i32, ptr %40, align 4
  %42 = sext i32 %41 to i64
  %43 = shl nsw i64 %42, 3
  %44 = add nsw i64 %43, %29
  %45 = getelementptr double, ptr %39, i64 %44
  %46 = mul nsw i64 %42, 9
  %47 = add nsw i64 %46, %29
  %48 = getelementptr double, ptr %39, i64 %47
  %49 = mul nsw i64 %42, 10
  %50 = add nsw i64 %49, %29
  %51 = getelementptr double, ptr %39, i64 %50
  %52 = icmp slt i32 %31, %34
  br i1 %52, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %struct_for_body_body
  %53 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %23, i64 0, i32 7, i32 1
  %54 = getelementptr { { i32, i32 }, ptr }, ptr %23, i64 0, i32 1
  %55 = getelementptr { { i32, i32 }, ptr }, ptr %23, i64 0, i32 0, i32 1
  %56 = sext i32 %31 to i64
  %wide.trip.count = sext i32 %34 to i64
  %57 = sub nsw i64 %wide.trip.count, %56
  %58 = xor i64 %56, -1
  %xtraiter = and i64 %57, 1
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.prol.loopexit, label %for_loop_body.prol

for_loop_body.prol:                               ; preds = %for_loop_body.lr.ph
  %59 = load ptr, ptr %53, align 8
  %60 = getelementptr i32, ptr %59, i64 %56
  %61 = load i32, ptr %60, align 4
  %62 = load ptr, ptr %54, align 8
  %63 = load i32, ptr %55, align 4
  %64 = sext i32 %63 to i64
  %65 = sext i32 %61 to i64
  %66 = getelementptr i32, ptr %62, i64 %65
  %67 = load i32, ptr %66, align 4
  %68 = add nsw i64 %64, %65
  %69 = getelementptr i32, ptr %62, i64 %68
  %70 = load i32, ptr %69, align 4
  %71 = atomicrmw add ptr %37, i64 1 seq_cst, align 8
  %72 = load ptr, ptr %38, align 8
  %73 = load i32, ptr %40, align 4
  %74 = sext i32 %73 to i64
  %75 = sext i32 %70 to i64
  %76 = getelementptr double, ptr %72, i64 %75
  %77 = load double, ptr %76, align 8
  %78 = sext i32 %67 to i64
  %79 = getelementptr double, ptr %72, i64 %78
  %80 = load double, ptr %79, align 8
  %81 = fsub double %77, %80
  %82 = add nsw i64 %74, %75
  %83 = getelementptr double, ptr %72, i64 %82
  %84 = load double, ptr %83, align 8
  %85 = add nsw i64 %74, %78
  %86 = getelementptr double, ptr %72, i64 %85
  %87 = load double, ptr %86, align 8
  %88 = fsub double %84, %87
  %89 = shl nsw i64 %74, 1
  %90 = add nsw i64 %89, %75
  %91 = getelementptr double, ptr %72, i64 %90
  %92 = load double, ptr %91, align 8
  %93 = add nsw i64 %89, %78
  %94 = getelementptr double, ptr %72, i64 %93
  %95 = load double, ptr %94, align 8
  %96 = fsub double %92, %95
  %97 = mul nsw i64 %74, 7
  %98 = add nsw i64 %97, %78
  %99 = getelementptr double, ptr %72, i64 %98
  %100 = load double, ptr %99, align 8
  %101 = add nsw i64 %97, %75
  %102 = getelementptr double, ptr %72, i64 %101
  %103 = load double, ptr %102, align 8
  %104 = fmul double %81, %81
  %105 = fmul double %88, %88
  %106 = fadd double %104, %105
  %107 = fmul double %96, %96
  %108 = fadd double %106, %107
  %109 = fcmp ogt double %108, 0.000000e+00
  %.0.i12.prol = select i1 %109, double 1.000000e+00, double 0.000000e+00
  %110 = fsub double 1.000000e+00, %.0.i12.prol
  %111 = fadd double %108, %110
  %sqrt.prol = tail call double @llvm.sqrt.f64(double %111)
  %112 = fdiv double 1.000000e+00, %sqrt.prol
  %113 = fmul double %111, %112
  %114 = fadd double %100, %103
  %115 = fsub double %114, %113
  %116 = tail call double @llvm.maxnum.f64(double %115, double 0.000000e+00)
  %117 = bitcast double %108 to i64
  %118 = and i64 %117, 9223372036854775807
  %119 = and i64 %117, 9218868437227405312
  %120 = icmp eq i64 %118, 0
  %121 = icmp ne i64 %119, 0
  %122 = icmp ne i64 %119, 9218868437227405312
  %123 = and i1 %121, %122
  %124 = or i1 %120, %123
  br i1 %124, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %for_loop_body.prol
  %125 = load ptr, ptr %35, align 8
  %126 = getelementptr i64, ptr %125, i64 19
  %127 = atomicrmw add ptr %126, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %for_loop_body.prol
  %128 = bitcast double %112 to i64
  %129 = and i64 %128, 9223372036854775807
  %130 = and i64 %128, 9218868437227405312
  %131 = icmp eq i64 %129, 0
  %132 = icmp ne i64 %130, 0
  %133 = icmp ne i64 %130, 9218868437227405312
  %134 = and i1 %132, %133
  %135 = or i1 %131, %134
  br i1 %135, label %after_if3.prol, label %true_block1.prol

true_block1.prol:                                 ; preds = %after_if.prol
  %136 = load ptr, ptr %35, align 8
  %137 = getelementptr i64, ptr %136, i64 19
  %138 = atomicrmw add ptr %137, i64 1 seq_cst, align 8
  br label %after_if3.prol

after_if3.prol:                                   ; preds = %true_block1.prol, %after_if.prol
  %139 = bitcast double %113 to i64
  %140 = and i64 %139, 9223372036854775807
  %141 = and i64 %139, 9218868437227405312
  %142 = icmp eq i64 %140, 0
  %143 = icmp ne i64 %141, 0
  %144 = icmp ne i64 %141, 9218868437227405312
  %145 = and i1 %143, %144
  %146 = or i1 %142, %145
  br i1 %146, label %after_if6.prol, label %true_block4.prol

true_block4.prol:                                 ; preds = %after_if3.prol
  %147 = load ptr, ptr %35, align 8
  %148 = getelementptr i64, ptr %147, i64 19
  %149 = atomicrmw add ptr %148, i64 1 seq_cst, align 8
  br label %after_if6.prol

after_if6.prol:                                   ; preds = %true_block4.prol, %after_if3.prol
  %150 = bitcast double %114 to i64
  %151 = and i64 %150, 9223372036854775807
  %152 = and i64 %150, 9218868437227405312
  %153 = icmp eq i64 %151, 0
  %154 = icmp ne i64 %152, 0
  %155 = icmp ne i64 %152, 9218868437227405312
  %156 = and i1 %154, %155
  %157 = or i1 %153, %156
  br i1 %157, label %after_if9.prol, label %true_block7.prol

true_block7.prol:                                 ; preds = %after_if6.prol
  %158 = load ptr, ptr %35, align 8
  %159 = getelementptr i64, ptr %158, i64 19
  %160 = atomicrmw add ptr %159, i64 1 seq_cst, align 8
  br label %after_if9.prol

after_if9.prol:                                   ; preds = %true_block7.prol, %after_if6.prol
  %161 = bitcast double %116 to i64
  %162 = and i64 %161, 9223372036854775807
  %163 = and i64 %161, 9218868437227405312
  %164 = icmp eq i64 %162, 0
  %165 = icmp ne i64 %163, 0
  %166 = icmp ne i64 %163, 9218868437227405312
  %167 = and i1 %165, %166
  %168 = or i1 %164, %167
  br i1 %168, label %after_if12.prol, label %true_block10.prol

true_block10.prol:                                ; preds = %after_if9.prol
  %169 = load ptr, ptr %35, align 8
  %170 = getelementptr i64, ptr %169, i64 19
  %171 = atomicrmw add ptr %170, i64 1 seq_cst, align 8
  br label %after_if12.prol

after_if12.prol:                                  ; preds = %true_block10.prol, %after_if9.prol
  %172 = load ptr, ptr %7, align 8
  %173 = getelementptr inbounds %struct.LLVMRuntime, ptr %172, i64 0, i32 16
  %174 = load ptr, ptr %173, align 8
  %175 = load double, ptr %174, align 8
  %176 = fmul double %.0.i12.prol, %112
  %177 = fneg double %175
  %178 = fmul double %116, %177
  %neg.prol = fmul double %176, %178
  %179 = fmul double %81, %neg.prol
  %180 = load double, ptr %45, align 8
  %181 = fadd double %180, %179
  store double %181, ptr %45, align 8
  %182 = fmul double %88, %neg.prol
  %183 = load double, ptr %48, align 8
  %184 = fadd double %183, %182
  store double %184, ptr %48, align 8
  %185 = fmul double %96, %neg.prol
  %186 = load double, ptr %51, align 8
  %187 = fadd double %185, %186
  store double %187, ptr %51, align 8
  %indvars.iv.next.prol = add nsw i64 %56, 1
  br label %for_loop_body.prol.loopexit

for_loop_body.prol.loopexit:                      ; preds = %after_if12.prol, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ %56, %for_loop_body.lr.ph ], [ %indvars.iv.next.prol, %after_if12.prol ]
  %188 = sub nsw i64 0, %wide.trip.count
  %189 = icmp eq i64 %58, %188
  br i1 %189, label %after_for.loopexit, label %for_loop_body.preheader

for_loop_body.preheader:                          ; preds = %for_loop_body.prol.loopexit
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_if12.1, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %indvars.iv.next.1, %after_if12.1 ], [ %indvars.iv.unr, %for_loop_body.preheader ]
  %190 = load ptr, ptr %53, align 8
  %191 = shl i64 %indvars.iv, 2
  %uglygep = getelementptr i8, ptr %190, i64 %191
  %192 = load i32, ptr %uglygep, align 4
  %193 = load ptr, ptr %54, align 8
  %194 = load i32, ptr %55, align 4
  %195 = sext i32 %194 to i64
  %196 = sext i32 %192 to i64
  %197 = getelementptr i32, ptr %193, i64 %196
  %198 = load i32, ptr %197, align 4
  %199 = add nsw i64 %195, %196
  %200 = getelementptr i32, ptr %193, i64 %199
  %201 = load i32, ptr %200, align 4
  %202 = atomicrmw add ptr %37, i64 1 seq_cst, align 8
  %203 = load ptr, ptr %38, align 8
  %204 = load i32, ptr %40, align 4
  %205 = sext i32 %204 to i64
  %206 = sext i32 %201 to i64
  %207 = getelementptr double, ptr %203, i64 %206
  %208 = load double, ptr %207, align 8
  %209 = sext i32 %198 to i64
  %210 = getelementptr double, ptr %203, i64 %209
  %211 = load double, ptr %210, align 8
  %212 = fsub double %208, %211
  %213 = add nsw i64 %205, %206
  %214 = getelementptr double, ptr %203, i64 %213
  %215 = load double, ptr %214, align 8
  %216 = add nsw i64 %205, %209
  %217 = getelementptr double, ptr %203, i64 %216
  %218 = load double, ptr %217, align 8
  %219 = fsub double %215, %218
  %220 = shl nsw i64 %205, 1
  %221 = add nsw i64 %220, %206
  %222 = getelementptr double, ptr %203, i64 %221
  %223 = load double, ptr %222, align 8
  %224 = add nsw i64 %220, %209
  %225 = getelementptr double, ptr %203, i64 %224
  %226 = load double, ptr %225, align 8
  %227 = fsub double %223, %226
  %228 = mul nsw i64 %205, 7
  %229 = add nsw i64 %228, %209
  %230 = getelementptr double, ptr %203, i64 %229
  %231 = load double, ptr %230, align 8
  %232 = add nsw i64 %228, %206
  %233 = getelementptr double, ptr %203, i64 %232
  %234 = load double, ptr %233, align 8
  %235 = fmul double %212, %212
  %236 = fmul double %219, %219
  %237 = fadd double %235, %236
  %238 = fmul double %227, %227
  %239 = fadd double %237, %238
  %240 = fcmp ogt double %239, 0.000000e+00
  %.0.i12 = select i1 %240, double 1.000000e+00, double 0.000000e+00
  %241 = fsub double 1.000000e+00, %.0.i12
  %242 = fadd double %239, %241
  %sqrt = tail call double @llvm.sqrt.f64(double %242)
  %243 = fdiv double 1.000000e+00, %sqrt
  %244 = fmul double %242, %243
  %245 = fadd double %231, %234
  %246 = fsub double %245, %244
  %247 = tail call double @llvm.maxnum.f64(double %246, double 0.000000e+00)
  %248 = bitcast double %239 to i64
  %249 = and i64 %248, 9223372036854775807
  %250 = and i64 %248, 9218868437227405312
  %251 = icmp eq i64 %249, 0
  %252 = icmp ne i64 %250, 0
  %253 = icmp ne i64 %250, 9218868437227405312
  %254 = and i1 %252, %253
  %255 = or i1 %251, %254
  br i1 %255, label %after_if, label %true_block

after_for.loopexit.loopexit:                      ; preds = %after_if12.1
  br label %after_for.loopexit

after_for.loopexit:                               ; preds = %after_for.loopexit.loopexit, %for_loop_body.prol.loopexit
  %.pre = load ptr, ptr %0, align 8
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %struct_for_body_body
  %256 = phi ptr [ %.pre, %after_for.loopexit ], [ %23, %struct_for_body_body ]
  %257 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %256, i64 0, i32 8, i32 1
  %258 = load ptr, ptr %257, align 8
  %259 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %256, i64 0, i32 8, i32 0, i32 1
  %260 = load i32, ptr %259, align 4
  %261 = sext i32 %260 to i64
  %262 = getelementptr i32, ptr %258, i64 %29
  %263 = load i32, ptr %262, align 4
  %264 = add nsw i64 %261, %29
  %265 = getelementptr i32, ptr %258, i64 %264
  %266 = load i32, ptr %265, align 4
  %267 = icmp slt i32 %263, %266
  br i1 %267, label %for_loop_body13.lr.ph, label %loop_body_tail

for_loop_body13.lr.ph:                            ; preds = %after_for
  %268 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, i32, double, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %256, i64 0, i32 9, i32 1
  %269 = getelementptr { { i32, i32 }, ptr }, ptr %23, i64 0, i32 1
  %270 = getelementptr { { i32, i32 }, ptr }, ptr %23, i64 0, i32 0, i32 1
  %271 = sext i32 %263 to i64
  %wide.trip.count40 = sext i32 %266 to i64
  %272 = sub nsw i64 %wide.trip.count40, %271
  %273 = xor i64 %271, -1
  %xtraiter43 = and i64 %272, 1
  %lcmp.mod44.not = icmp eq i64 %xtraiter43, 0
  br i1 %lcmp.mod44.not, label %for_loop_body13.prol.loopexit, label %for_loop_body13.prol

for_loop_body13.prol:                             ; preds = %for_loop_body13.lr.ph
  %274 = load ptr, ptr %268, align 8
  %275 = getelementptr i32, ptr %274, i64 %271
  %276 = load i32, ptr %275, align 4
  %277 = load ptr, ptr %269, align 8
  %278 = load i32, ptr %270, align 4
  %279 = sext i32 %278 to i64
  %280 = sext i32 %276 to i64
  %281 = getelementptr i32, ptr %277, i64 %280
  %282 = load i32, ptr %281, align 4
  %283 = add nsw i64 %279, %280
  %284 = getelementptr i32, ptr %277, i64 %283
  %285 = load i32, ptr %284, align 4
  %286 = atomicrmw add ptr %37, i64 1 seq_cst, align 8
  %287 = load ptr, ptr %38, align 8
  %288 = load i32, ptr %40, align 4
  %289 = sext i32 %288 to i64
  %290 = sext i32 %285 to i64
  %291 = getelementptr double, ptr %287, i64 %290
  %292 = load double, ptr %291, align 8
  %293 = sext i32 %282 to i64
  %294 = getelementptr double, ptr %287, i64 %293
  %295 = load double, ptr %294, align 8
  %296 = fsub double %292, %295
  %297 = add nsw i64 %289, %290
  %298 = getelementptr double, ptr %287, i64 %297
  %299 = load double, ptr %298, align 8
  %300 = add nsw i64 %289, %293
  %301 = getelementptr double, ptr %287, i64 %300
  %302 = load double, ptr %301, align 8
  %303 = fsub double %299, %302
  %304 = shl nsw i64 %289, 1
  %305 = add nsw i64 %304, %290
  %306 = getelementptr double, ptr %287, i64 %305
  %307 = load double, ptr %306, align 8
  %308 = add nsw i64 %304, %293
  %309 = getelementptr double, ptr %287, i64 %308
  %310 = load double, ptr %309, align 8
  %311 = fsub double %307, %310
  %312 = mul nsw i64 %289, 7
  %313 = add nsw i64 %312, %293
  %314 = getelementptr double, ptr %287, i64 %313
  %315 = load double, ptr %314, align 8
  %316 = add nsw i64 %312, %290
  %317 = getelementptr double, ptr %287, i64 %316
  %318 = load double, ptr %317, align 8
  %319 = fmul double %296, %296
  %320 = fmul double %303, %303
  %321 = fadd double %319, %320
  %322 = fmul double %311, %311
  %323 = fadd double %321, %322
  %324 = fcmp ogt double %323, 0.000000e+00
  %.0.i.prol = select i1 %324, double 1.000000e+00, double 0.000000e+00
  %325 = fsub double 1.000000e+00, %.0.i.prol
  %326 = fadd double %323, %325
  %sqrt17.prol = tail call double @llvm.sqrt.f64(double %326)
  %327 = fdiv double 1.000000e+00, %sqrt17.prol
  %328 = fmul double %326, %327
  %329 = fadd double %315, %318
  %330 = fsub double %329, %328
  %331 = tail call double @llvm.maxnum.f64(double %330, double 0.000000e+00)
  %332 = bitcast double %323 to i64
  %333 = and i64 %332, 9223372036854775807
  %334 = and i64 %332, 9218868437227405312
  %335 = icmp eq i64 %333, 0
  %336 = icmp ne i64 %334, 0
  %337 = icmp ne i64 %334, 9218868437227405312
  %338 = and i1 %336, %337
  %339 = or i1 %335, %338
  br i1 %339, label %after_if20.prol, label %true_block18.prol

true_block18.prol:                                ; preds = %for_loop_body13.prol
  %340 = load ptr, ptr %35, align 8
  %341 = getelementptr i64, ptr %340, i64 19
  %342 = atomicrmw add ptr %341, i64 1 seq_cst, align 8
  br label %after_if20.prol

after_if20.prol:                                  ; preds = %true_block18.prol, %for_loop_body13.prol
  %343 = bitcast double %327 to i64
  %344 = and i64 %343, 9223372036854775807
  %345 = and i64 %343, 9218868437227405312
  %346 = icmp eq i64 %344, 0
  %347 = icmp ne i64 %345, 0
  %348 = icmp ne i64 %345, 9218868437227405312
  %349 = and i1 %347, %348
  %350 = or i1 %346, %349
  br i1 %350, label %after_if23.prol, label %true_block21.prol

true_block21.prol:                                ; preds = %after_if20.prol
  %351 = load ptr, ptr %35, align 8
  %352 = getelementptr i64, ptr %351, i64 19
  %353 = atomicrmw add ptr %352, i64 1 seq_cst, align 8
  br label %after_if23.prol

after_if23.prol:                                  ; preds = %true_block21.prol, %after_if20.prol
  %354 = bitcast double %328 to i64
  %355 = and i64 %354, 9223372036854775807
  %356 = and i64 %354, 9218868437227405312
  %357 = icmp eq i64 %355, 0
  %358 = icmp ne i64 %356, 0
  %359 = icmp ne i64 %356, 9218868437227405312
  %360 = and i1 %358, %359
  %361 = or i1 %357, %360
  br i1 %361, label %after_if26.prol, label %true_block24.prol

true_block24.prol:                                ; preds = %after_if23.prol
  %362 = load ptr, ptr %35, align 8
  %363 = getelementptr i64, ptr %362, i64 19
  %364 = atomicrmw add ptr %363, i64 1 seq_cst, align 8
  br label %after_if26.prol

after_if26.prol:                                  ; preds = %true_block24.prol, %after_if23.prol
  %365 = bitcast double %329 to i64
  %366 = and i64 %365, 9223372036854775807
  %367 = and i64 %365, 9218868437227405312
  %368 = icmp eq i64 %366, 0
  %369 = icmp ne i64 %367, 0
  %370 = icmp ne i64 %367, 9218868437227405312
  %371 = and i1 %369, %370
  %372 = or i1 %368, %371
  br i1 %372, label %after_if29.prol, label %true_block27.prol

true_block27.prol:                                ; preds = %after_if26.prol
  %373 = load ptr, ptr %35, align 8
  %374 = getelementptr i64, ptr %373, i64 19
  %375 = atomicrmw add ptr %374, i64 1 seq_cst, align 8
  br label %after_if29.prol

after_if29.prol:                                  ; preds = %true_block27.prol, %after_if26.prol
  %376 = bitcast double %331 to i64
  %377 = and i64 %376, 9223372036854775807
  %378 = and i64 %376, 9218868437227405312
  %379 = icmp eq i64 %377, 0
  %380 = icmp ne i64 %378, 0
  %381 = icmp ne i64 %378, 9218868437227405312
  %382 = and i1 %380, %381
  %383 = or i1 %379, %382
  br i1 %383, label %after_if32.prol, label %true_block30.prol

true_block30.prol:                                ; preds = %after_if29.prol
  %384 = load ptr, ptr %35, align 8
  %385 = getelementptr i64, ptr %384, i64 19
  %386 = atomicrmw add ptr %385, i64 1 seq_cst, align 8
  br label %after_if32.prol

after_if32.prol:                                  ; preds = %true_block30.prol, %after_if29.prol
  %387 = load ptr, ptr %7, align 8
  %388 = getelementptr inbounds %struct.LLVMRuntime, ptr %387, i64 0, i32 16
  %389 = load ptr, ptr %388, align 8
  %390 = load double, ptr %389, align 8
  %391 = fmul double %.0.i.prol, %327
  %392 = fneg double %390
  %393 = fmul double %331, %392
  %neg33.prol = fmul double %391, %393
  %394 = load double, ptr %45, align 8
  %395 = fmul double %296, %neg33.prol
  %396 = fsub double %394, %395
  store double %396, ptr %45, align 8
  %397 = load double, ptr %48, align 8
  %398 = fmul double %303, %neg33.prol
  %399 = fsub double %397, %398
  store double %399, ptr %48, align 8
  %400 = load double, ptr %51, align 8
  %401 = fmul double %311, %neg33.prol
  %402 = fsub double %400, %401
  store double %402, ptr %51, align 8
  %indvars.iv.next38.prol = add nsw i64 %271, 1
  br label %for_loop_body13.prol.loopexit

for_loop_body13.prol.loopexit:                    ; preds = %after_if32.prol, %for_loop_body13.lr.ph
  %indvars.iv37.unr = phi i64 [ %271, %for_loop_body13.lr.ph ], [ %indvars.iv.next38.prol, %after_if32.prol ]
  %403 = sub nsw i64 0, %wide.trip.count40
  %404 = icmp eq i64 %273, %403
  br i1 %404, label %loop_body_tail, label %for_loop_body13.preheader

for_loop_body13.preheader:                        ; preds = %for_loop_body13.prol.loopexit
  br label %for_loop_body13

true_block:                                       ; preds = %for_loop_body
  %405 = load ptr, ptr %35, align 8
  %406 = getelementptr i64, ptr %405, i64 19
  %407 = atomicrmw add ptr %406, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body
  %408 = bitcast double %243 to i64
  %409 = and i64 %408, 9223372036854775807
  %410 = and i64 %408, 9218868437227405312
  %411 = icmp eq i64 %409, 0
  %412 = icmp ne i64 %410, 0
  %413 = icmp ne i64 %410, 9218868437227405312
  %414 = and i1 %412, %413
  %415 = or i1 %411, %414
  br i1 %415, label %after_if3, label %true_block1

true_block1:                                      ; preds = %after_if
  %416 = load ptr, ptr %35, align 8
  %417 = getelementptr i64, ptr %416, i64 19
  %418 = atomicrmw add ptr %417, i64 1 seq_cst, align 8
  br label %after_if3

after_if3:                                        ; preds = %true_block1, %after_if
  %419 = bitcast double %244 to i64
  %420 = and i64 %419, 9223372036854775807
  %421 = and i64 %419, 9218868437227405312
  %422 = icmp eq i64 %420, 0
  %423 = icmp ne i64 %421, 0
  %424 = icmp ne i64 %421, 9218868437227405312
  %425 = and i1 %423, %424
  %426 = or i1 %422, %425
  br i1 %426, label %after_if6, label %true_block4

true_block4:                                      ; preds = %after_if3
  %427 = load ptr, ptr %35, align 8
  %428 = getelementptr i64, ptr %427, i64 19
  %429 = atomicrmw add ptr %428, i64 1 seq_cst, align 8
  br label %after_if6

after_if6:                                        ; preds = %true_block4, %after_if3
  %430 = bitcast double %245 to i64
  %431 = and i64 %430, 9223372036854775807
  %432 = and i64 %430, 9218868437227405312
  %433 = icmp eq i64 %431, 0
  %434 = icmp ne i64 %432, 0
  %435 = icmp ne i64 %432, 9218868437227405312
  %436 = and i1 %434, %435
  %437 = or i1 %433, %436
  br i1 %437, label %after_if9, label %true_block7

true_block7:                                      ; preds = %after_if6
  %438 = load ptr, ptr %35, align 8
  %439 = getelementptr i64, ptr %438, i64 19
  %440 = atomicrmw add ptr %439, i64 1 seq_cst, align 8
  br label %after_if9

after_if9:                                        ; preds = %true_block7, %after_if6
  %441 = bitcast double %247 to i64
  %442 = and i64 %441, 9223372036854775807
  %443 = and i64 %441, 9218868437227405312
  %444 = icmp eq i64 %442, 0
  %445 = icmp ne i64 %443, 0
  %446 = icmp ne i64 %443, 9218868437227405312
  %447 = and i1 %445, %446
  %448 = or i1 %444, %447
  br i1 %448, label %after_if12, label %true_block10

true_block10:                                     ; preds = %after_if9
  %449 = load ptr, ptr %35, align 8
  %450 = getelementptr i64, ptr %449, i64 19
  %451 = atomicrmw add ptr %450, i64 1 seq_cst, align 8
  br label %after_if12

after_if12:                                       ; preds = %true_block10, %after_if9
  %452 = load ptr, ptr %7, align 8
  %453 = getelementptr inbounds %struct.LLVMRuntime, ptr %452, i64 0, i32 16
  %454 = load ptr, ptr %453, align 8
  %455 = load double, ptr %454, align 8
  %456 = fmul double %.0.i12, %243
  %457 = fneg double %455
  %458 = fmul double %247, %457
  %neg = fmul double %456, %458
  %459 = fmul double %212, %neg
  %460 = load double, ptr %45, align 8
  %461 = fadd double %460, %459
  store double %461, ptr %45, align 8
  %462 = fmul double %219, %neg
  %463 = load double, ptr %48, align 8
  %464 = fadd double %463, %462
  store double %464, ptr %48, align 8
  %465 = fmul double %227, %neg
  %466 = load double, ptr %51, align 8
  %467 = fadd double %465, %466
  store double %467, ptr %51, align 8
  %468 = load ptr, ptr %53, align 8
  %uglygep45 = getelementptr i8, ptr %468, i64 4
  %uglygep46 = getelementptr i8, ptr %uglygep45, i64 %191
  %469 = load i32, ptr %uglygep46, align 4
  %470 = load ptr, ptr %54, align 8
  %471 = load i32, ptr %55, align 4
  %472 = sext i32 %471 to i64
  %473 = sext i32 %469 to i64
  %474 = getelementptr i32, ptr %470, i64 %473
  %475 = load i32, ptr %474, align 4
  %476 = add nsw i64 %472, %473
  %477 = getelementptr i32, ptr %470, i64 %476
  %478 = load i32, ptr %477, align 4
  %479 = atomicrmw add ptr %37, i64 1 seq_cst, align 8
  %480 = load ptr, ptr %38, align 8
  %481 = load i32, ptr %40, align 4
  %482 = sext i32 %481 to i64
  %483 = sext i32 %478 to i64
  %484 = getelementptr double, ptr %480, i64 %483
  %485 = load double, ptr %484, align 8
  %486 = sext i32 %475 to i64
  %487 = getelementptr double, ptr %480, i64 %486
  %488 = load double, ptr %487, align 8
  %489 = fsub double %485, %488
  %490 = add nsw i64 %482, %483
  %491 = getelementptr double, ptr %480, i64 %490
  %492 = load double, ptr %491, align 8
  %493 = add nsw i64 %482, %486
  %494 = getelementptr double, ptr %480, i64 %493
  %495 = load double, ptr %494, align 8
  %496 = fsub double %492, %495
  %497 = shl nsw i64 %482, 1
  %498 = add nsw i64 %497, %483
  %499 = getelementptr double, ptr %480, i64 %498
  %500 = load double, ptr %499, align 8
  %501 = add nsw i64 %497, %486
  %502 = getelementptr double, ptr %480, i64 %501
  %503 = load double, ptr %502, align 8
  %504 = fsub double %500, %503
  %505 = mul nsw i64 %482, 7
  %506 = add nsw i64 %505, %486
  %507 = getelementptr double, ptr %480, i64 %506
  %508 = load double, ptr %507, align 8
  %509 = add nsw i64 %505, %483
  %510 = getelementptr double, ptr %480, i64 %509
  %511 = load double, ptr %510, align 8
  %512 = fmul double %489, %489
  %513 = fmul double %496, %496
  %514 = fadd double %512, %513
  %515 = fmul double %504, %504
  %516 = fadd double %514, %515
  %517 = fcmp ogt double %516, 0.000000e+00
  %.0.i12.1 = select i1 %517, double 1.000000e+00, double 0.000000e+00
  %518 = fsub double 1.000000e+00, %.0.i12.1
  %519 = fadd double %516, %518
  %sqrt.1 = tail call double @llvm.sqrt.f64(double %519)
  %520 = fdiv double 1.000000e+00, %sqrt.1
  %521 = fmul double %519, %520
  %522 = fadd double %508, %511
  %523 = fsub double %522, %521
  %524 = tail call double @llvm.maxnum.f64(double %523, double 0.000000e+00)
  %525 = bitcast double %516 to i64
  %526 = and i64 %525, 9223372036854775807
  %527 = and i64 %525, 9218868437227405312
  %528 = icmp eq i64 %526, 0
  %529 = icmp ne i64 %527, 0
  %530 = icmp ne i64 %527, 9218868437227405312
  %531 = and i1 %529, %530
  %532 = or i1 %528, %531
  br i1 %532, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %after_if12
  %533 = load ptr, ptr %35, align 8
  %534 = getelementptr i64, ptr %533, i64 19
  %535 = atomicrmw add ptr %534, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %after_if12
  %536 = bitcast double %520 to i64
  %537 = and i64 %536, 9223372036854775807
  %538 = and i64 %536, 9218868437227405312
  %539 = icmp eq i64 %537, 0
  %540 = icmp ne i64 %538, 0
  %541 = icmp ne i64 %538, 9218868437227405312
  %542 = and i1 %540, %541
  %543 = or i1 %539, %542
  br i1 %543, label %after_if3.1, label %true_block1.1

true_block1.1:                                    ; preds = %after_if.1
  %544 = load ptr, ptr %35, align 8
  %545 = getelementptr i64, ptr %544, i64 19
  %546 = atomicrmw add ptr %545, i64 1 seq_cst, align 8
  br label %after_if3.1

after_if3.1:                                      ; preds = %true_block1.1, %after_if.1
  %547 = bitcast double %521 to i64
  %548 = and i64 %547, 9223372036854775807
  %549 = and i64 %547, 9218868437227405312
  %550 = icmp eq i64 %548, 0
  %551 = icmp ne i64 %549, 0
  %552 = icmp ne i64 %549, 9218868437227405312
  %553 = and i1 %551, %552
  %554 = or i1 %550, %553
  br i1 %554, label %after_if6.1, label %true_block4.1

true_block4.1:                                    ; preds = %after_if3.1
  %555 = load ptr, ptr %35, align 8
  %556 = getelementptr i64, ptr %555, i64 19
  %557 = atomicrmw add ptr %556, i64 1 seq_cst, align 8
  br label %after_if6.1

after_if6.1:                                      ; preds = %true_block4.1, %after_if3.1
  %558 = bitcast double %522 to i64
  %559 = and i64 %558, 9223372036854775807
  %560 = and i64 %558, 9218868437227405312
  %561 = icmp eq i64 %559, 0
  %562 = icmp ne i64 %560, 0
  %563 = icmp ne i64 %560, 9218868437227405312
  %564 = and i1 %562, %563
  %565 = or i1 %561, %564
  br i1 %565, label %after_if9.1, label %true_block7.1

true_block7.1:                                    ; preds = %after_if6.1
  %566 = load ptr, ptr %35, align 8
  %567 = getelementptr i64, ptr %566, i64 19
  %568 = atomicrmw add ptr %567, i64 1 seq_cst, align 8
  br label %after_if9.1

after_if9.1:                                      ; preds = %true_block7.1, %after_if6.1
  %569 = bitcast double %524 to i64
  %570 = and i64 %569, 9223372036854775807
  %571 = and i64 %569, 9218868437227405312
  %572 = icmp eq i64 %570, 0
  %573 = icmp ne i64 %571, 0
  %574 = icmp ne i64 %571, 9218868437227405312
  %575 = and i1 %573, %574
  %576 = or i1 %572, %575
  br i1 %576, label %after_if12.1, label %true_block10.1

true_block10.1:                                   ; preds = %after_if9.1
  %577 = load ptr, ptr %35, align 8
  %578 = getelementptr i64, ptr %577, i64 19
  %579 = atomicrmw add ptr %578, i64 1 seq_cst, align 8
  br label %after_if12.1

after_if12.1:                                     ; preds = %true_block10.1, %after_if9.1
  %580 = load ptr, ptr %7, align 8
  %581 = getelementptr inbounds %struct.LLVMRuntime, ptr %580, i64 0, i32 16
  %582 = load ptr, ptr %581, align 8
  %583 = load double, ptr %582, align 8
  %584 = fmul double %.0.i12.1, %520
  %585 = fneg double %583
  %586 = fmul double %524, %585
  %neg.1 = fmul double %584, %586
  %587 = fmul double %489, %neg.1
  %588 = load double, ptr %45, align 8
  %589 = fadd double %588, %587
  store double %589, ptr %45, align 8
  %590 = fmul double %496, %neg.1
  %591 = load double, ptr %48, align 8
  %592 = fadd double %591, %590
  store double %592, ptr %48, align 8
  %593 = fmul double %504, %neg.1
  %594 = load double, ptr %51, align 8
  %595 = fadd double %593, %594
  store double %595, ptr %51, align 8
  %indvars.iv.next.1 = add nsw i64 %indvars.iv, 2
  %exitcond.not.1 = icmp eq i64 %wide.trip.count, %indvars.iv.next.1
  br i1 %exitcond.not.1, label %after_for.loopexit.loopexit, label %for_loop_body

for_loop_body13:                                  ; preds = %after_if32.1, %for_loop_body13.preheader
  %indvars.iv37 = phi i64 [ %indvars.iv.next38.1, %after_if32.1 ], [ %indvars.iv37.unr, %for_loop_body13.preheader ]
  %596 = load ptr, ptr %268, align 8
  %597 = shl i64 %indvars.iv37, 2
  %uglygep47 = getelementptr i8, ptr %596, i64 %597
  %598 = load i32, ptr %uglygep47, align 4
  %599 = load ptr, ptr %269, align 8
  %600 = load i32, ptr %270, align 4
  %601 = sext i32 %600 to i64
  %602 = sext i32 %598 to i64
  %603 = getelementptr i32, ptr %599, i64 %602
  %604 = load i32, ptr %603, align 4
  %605 = add nsw i64 %601, %602
  %606 = getelementptr i32, ptr %599, i64 %605
  %607 = load i32, ptr %606, align 4
  %608 = atomicrmw add ptr %37, i64 1 seq_cst, align 8
  %609 = load ptr, ptr %38, align 8
  %610 = load i32, ptr %40, align 4
  %611 = sext i32 %610 to i64
  %612 = sext i32 %607 to i64
  %613 = getelementptr double, ptr %609, i64 %612
  %614 = load double, ptr %613, align 8
  %615 = sext i32 %604 to i64
  %616 = getelementptr double, ptr %609, i64 %615
  %617 = load double, ptr %616, align 8
  %618 = fsub double %614, %617
  %619 = add nsw i64 %611, %612
  %620 = getelementptr double, ptr %609, i64 %619
  %621 = load double, ptr %620, align 8
  %622 = add nsw i64 %611, %615
  %623 = getelementptr double, ptr %609, i64 %622
  %624 = load double, ptr %623, align 8
  %625 = fsub double %621, %624
  %626 = shl nsw i64 %611, 1
  %627 = add nsw i64 %626, %612
  %628 = getelementptr double, ptr %609, i64 %627
  %629 = load double, ptr %628, align 8
  %630 = add nsw i64 %626, %615
  %631 = getelementptr double, ptr %609, i64 %630
  %632 = load double, ptr %631, align 8
  %633 = fsub double %629, %632
  %634 = mul nsw i64 %611, 7
  %635 = add nsw i64 %634, %615
  %636 = getelementptr double, ptr %609, i64 %635
  %637 = load double, ptr %636, align 8
  %638 = add nsw i64 %634, %612
  %639 = getelementptr double, ptr %609, i64 %638
  %640 = load double, ptr %639, align 8
  %641 = fmul double %618, %618
  %642 = fmul double %625, %625
  %643 = fadd double %641, %642
  %644 = fmul double %633, %633
  %645 = fadd double %643, %644
  %646 = fcmp ogt double %645, 0.000000e+00
  %.0.i = select i1 %646, double 1.000000e+00, double 0.000000e+00
  %647 = fsub double 1.000000e+00, %.0.i
  %648 = fadd double %645, %647
  %sqrt17 = tail call double @llvm.sqrt.f64(double %648)
  %649 = fdiv double 1.000000e+00, %sqrt17
  %650 = fmul double %648, %649
  %651 = fadd double %637, %640
  %652 = fsub double %651, %650
  %653 = tail call double @llvm.maxnum.f64(double %652, double 0.000000e+00)
  %654 = bitcast double %645 to i64
  %655 = and i64 %654, 9223372036854775807
  %656 = and i64 %654, 9218868437227405312
  %657 = icmp eq i64 %655, 0
  %658 = icmp ne i64 %656, 0
  %659 = icmp ne i64 %656, 9218868437227405312
  %660 = and i1 %658, %659
  %661 = or i1 %657, %660
  br i1 %661, label %after_if20, label %true_block18

true_block18:                                     ; preds = %for_loop_body13
  %662 = load ptr, ptr %35, align 8
  %663 = getelementptr i64, ptr %662, i64 19
  %664 = atomicrmw add ptr %663, i64 1 seq_cst, align 8
  br label %after_if20

after_if20:                                       ; preds = %true_block18, %for_loop_body13
  %665 = bitcast double %649 to i64
  %666 = and i64 %665, 9223372036854775807
  %667 = and i64 %665, 9218868437227405312
  %668 = icmp eq i64 %666, 0
  %669 = icmp ne i64 %667, 0
  %670 = icmp ne i64 %667, 9218868437227405312
  %671 = and i1 %669, %670
  %672 = or i1 %668, %671
  br i1 %672, label %after_if23, label %true_block21

true_block21:                                     ; preds = %after_if20
  %673 = load ptr, ptr %35, align 8
  %674 = getelementptr i64, ptr %673, i64 19
  %675 = atomicrmw add ptr %674, i64 1 seq_cst, align 8
  br label %after_if23

after_if23:                                       ; preds = %true_block21, %after_if20
  %676 = bitcast double %650 to i64
  %677 = and i64 %676, 9223372036854775807
  %678 = and i64 %676, 9218868437227405312
  %679 = icmp eq i64 %677, 0
  %680 = icmp ne i64 %678, 0
  %681 = icmp ne i64 %678, 9218868437227405312
  %682 = and i1 %680, %681
  %683 = or i1 %679, %682
  br i1 %683, label %after_if26, label %true_block24

true_block24:                                     ; preds = %after_if23
  %684 = load ptr, ptr %35, align 8
  %685 = getelementptr i64, ptr %684, i64 19
  %686 = atomicrmw add ptr %685, i64 1 seq_cst, align 8
  br label %after_if26

after_if26:                                       ; preds = %true_block24, %after_if23
  %687 = bitcast double %651 to i64
  %688 = and i64 %687, 9223372036854775807
  %689 = and i64 %687, 9218868437227405312
  %690 = icmp eq i64 %688, 0
  %691 = icmp ne i64 %689, 0
  %692 = icmp ne i64 %689, 9218868437227405312
  %693 = and i1 %691, %692
  %694 = or i1 %690, %693
  br i1 %694, label %after_if29, label %true_block27

true_block27:                                     ; preds = %after_if26
  %695 = load ptr, ptr %35, align 8
  %696 = getelementptr i64, ptr %695, i64 19
  %697 = atomicrmw add ptr %696, i64 1 seq_cst, align 8
  br label %after_if29

after_if29:                                       ; preds = %true_block27, %after_if26
  %698 = bitcast double %653 to i64
  %699 = and i64 %698, 9223372036854775807
  %700 = and i64 %698, 9218868437227405312
  %701 = icmp eq i64 %699, 0
  %702 = icmp ne i64 %700, 0
  %703 = icmp ne i64 %700, 9218868437227405312
  %704 = and i1 %702, %703
  %705 = or i1 %701, %704
  br i1 %705, label %after_if32, label %true_block30

true_block30:                                     ; preds = %after_if29
  %706 = load ptr, ptr %35, align 8
  %707 = getelementptr i64, ptr %706, i64 19
  %708 = atomicrmw add ptr %707, i64 1 seq_cst, align 8
  br label %after_if32

after_if32:                                       ; preds = %true_block30, %after_if29
  %709 = load ptr, ptr %7, align 8
  %710 = getelementptr inbounds %struct.LLVMRuntime, ptr %709, i64 0, i32 16
  %711 = load ptr, ptr %710, align 8
  %712 = load double, ptr %711, align 8
  %713 = fmul double %.0.i, %649
  %714 = fneg double %712
  %715 = fmul double %653, %714
  %neg33 = fmul double %713, %715
  %716 = load double, ptr %45, align 8
  %717 = fmul double %618, %neg33
  %718 = fsub double %716, %717
  store double %718, ptr %45, align 8
  %719 = load double, ptr %48, align 8
  %720 = fmul double %625, %neg33
  %721 = fsub double %719, %720
  store double %721, ptr %48, align 8
  %722 = load double, ptr %51, align 8
  %723 = fmul double %633, %neg33
  %724 = fsub double %722, %723
  store double %724, ptr %51, align 8
  %725 = load ptr, ptr %268, align 8
  %uglygep48 = getelementptr i8, ptr %725, i64 4
  %uglygep49 = getelementptr i8, ptr %uglygep48, i64 %597
  %726 = load i32, ptr %uglygep49, align 4
  %727 = load ptr, ptr %269, align 8
  %728 = load i32, ptr %270, align 4
  %729 = sext i32 %728 to i64
  %730 = sext i32 %726 to i64
  %731 = getelementptr i32, ptr %727, i64 %730
  %732 = load i32, ptr %731, align 4
  %733 = add nsw i64 %729, %730
  %734 = getelementptr i32, ptr %727, i64 %733
  %735 = load i32, ptr %734, align 4
  %736 = atomicrmw add ptr %37, i64 1 seq_cst, align 8
  %737 = load ptr, ptr %38, align 8
  %738 = load i32, ptr %40, align 4
  %739 = sext i32 %738 to i64
  %740 = sext i32 %735 to i64
  %741 = getelementptr double, ptr %737, i64 %740
  %742 = load double, ptr %741, align 8
  %743 = sext i32 %732 to i64
  %744 = getelementptr double, ptr %737, i64 %743
  %745 = load double, ptr %744, align 8
  %746 = fsub double %742, %745
  %747 = add nsw i64 %739, %740
  %748 = getelementptr double, ptr %737, i64 %747
  %749 = load double, ptr %748, align 8
  %750 = add nsw i64 %739, %743
  %751 = getelementptr double, ptr %737, i64 %750
  %752 = load double, ptr %751, align 8
  %753 = fsub double %749, %752
  %754 = shl nsw i64 %739, 1
  %755 = add nsw i64 %754, %740
  %756 = getelementptr double, ptr %737, i64 %755
  %757 = load double, ptr %756, align 8
  %758 = add nsw i64 %754, %743
  %759 = getelementptr double, ptr %737, i64 %758
  %760 = load double, ptr %759, align 8
  %761 = fsub double %757, %760
  %762 = mul nsw i64 %739, 7
  %763 = add nsw i64 %762, %743
  %764 = getelementptr double, ptr %737, i64 %763
  %765 = load double, ptr %764, align 8
  %766 = add nsw i64 %762, %740
  %767 = getelementptr double, ptr %737, i64 %766
  %768 = load double, ptr %767, align 8
  %769 = fmul double %746, %746
  %770 = fmul double %753, %753
  %771 = fadd double %769, %770
  %772 = fmul double %761, %761
  %773 = fadd double %771, %772
  %774 = fcmp ogt double %773, 0.000000e+00
  %.0.i.1 = select i1 %774, double 1.000000e+00, double 0.000000e+00
  %775 = fsub double 1.000000e+00, %.0.i.1
  %776 = fadd double %773, %775
  %sqrt17.1 = tail call double @llvm.sqrt.f64(double %776)
  %777 = fdiv double 1.000000e+00, %sqrt17.1
  %778 = fmul double %776, %777
  %779 = fadd double %765, %768
  %780 = fsub double %779, %778
  %781 = tail call double @llvm.maxnum.f64(double %780, double 0.000000e+00)
  %782 = bitcast double %773 to i64
  %783 = and i64 %782, 9223372036854775807
  %784 = and i64 %782, 9218868437227405312
  %785 = icmp eq i64 %783, 0
  %786 = icmp ne i64 %784, 0
  %787 = icmp ne i64 %784, 9218868437227405312
  %788 = and i1 %786, %787
  %789 = or i1 %785, %788
  br i1 %789, label %after_if20.1, label %true_block18.1

true_block18.1:                                   ; preds = %after_if32
  %790 = load ptr, ptr %35, align 8
  %791 = getelementptr i64, ptr %790, i64 19
  %792 = atomicrmw add ptr %791, i64 1 seq_cst, align 8
  br label %after_if20.1

after_if20.1:                                     ; preds = %true_block18.1, %after_if32
  %793 = bitcast double %777 to i64
  %794 = and i64 %793, 9223372036854775807
  %795 = and i64 %793, 9218868437227405312
  %796 = icmp eq i64 %794, 0
  %797 = icmp ne i64 %795, 0
  %798 = icmp ne i64 %795, 9218868437227405312
  %799 = and i1 %797, %798
  %800 = or i1 %796, %799
  br i1 %800, label %after_if23.1, label %true_block21.1

true_block21.1:                                   ; preds = %after_if20.1
  %801 = load ptr, ptr %35, align 8
  %802 = getelementptr i64, ptr %801, i64 19
  %803 = atomicrmw add ptr %802, i64 1 seq_cst, align 8
  br label %after_if23.1

after_if23.1:                                     ; preds = %true_block21.1, %after_if20.1
  %804 = bitcast double %778 to i64
  %805 = and i64 %804, 9223372036854775807
  %806 = and i64 %804, 9218868437227405312
  %807 = icmp eq i64 %805, 0
  %808 = icmp ne i64 %806, 0
  %809 = icmp ne i64 %806, 9218868437227405312
  %810 = and i1 %808, %809
  %811 = or i1 %807, %810
  br i1 %811, label %after_if26.1, label %true_block24.1

true_block24.1:                                   ; preds = %after_if23.1
  %812 = load ptr, ptr %35, align 8
  %813 = getelementptr i64, ptr %812, i64 19
  %814 = atomicrmw add ptr %813, i64 1 seq_cst, align 8
  br label %after_if26.1

after_if26.1:                                     ; preds = %true_block24.1, %after_if23.1
  %815 = bitcast double %779 to i64
  %816 = and i64 %815, 9223372036854775807
  %817 = and i64 %815, 9218868437227405312
  %818 = icmp eq i64 %816, 0
  %819 = icmp ne i64 %817, 0
  %820 = icmp ne i64 %817, 9218868437227405312
  %821 = and i1 %819, %820
  %822 = or i1 %818, %821
  br i1 %822, label %after_if29.1, label %true_block27.1

true_block27.1:                                   ; preds = %after_if26.1
  %823 = load ptr, ptr %35, align 8
  %824 = getelementptr i64, ptr %823, i64 19
  %825 = atomicrmw add ptr %824, i64 1 seq_cst, align 8
  br label %after_if29.1

after_if29.1:                                     ; preds = %true_block27.1, %after_if26.1
  %826 = bitcast double %781 to i64
  %827 = and i64 %826, 9223372036854775807
  %828 = and i64 %826, 9218868437227405312
  %829 = icmp eq i64 %827, 0
  %830 = icmp ne i64 %828, 0
  %831 = icmp ne i64 %828, 9218868437227405312
  %832 = and i1 %830, %831
  %833 = or i1 %829, %832
  br i1 %833, label %after_if32.1, label %true_block30.1

true_block30.1:                                   ; preds = %after_if29.1
  %834 = load ptr, ptr %35, align 8
  %835 = getelementptr i64, ptr %834, i64 19
  %836 = atomicrmw add ptr %835, i64 1 seq_cst, align 8
  br label %after_if32.1

after_if32.1:                                     ; preds = %true_block30.1, %after_if29.1
  %837 = load ptr, ptr %7, align 8
  %838 = getelementptr inbounds %struct.LLVMRuntime, ptr %837, i64 0, i32 16
  %839 = load ptr, ptr %838, align 8
  %840 = load double, ptr %839, align 8
  %841 = fmul double %.0.i.1, %777
  %842 = fneg double %840
  %843 = fmul double %781, %842
  %neg33.1 = fmul double %841, %843
  %844 = load double, ptr %45, align 8
  %845 = fmul double %746, %neg33.1
  %846 = fsub double %844, %845
  store double %846, ptr %45, align 8
  %847 = load double, ptr %48, align 8
  %848 = fmul double %753, %neg33.1
  %849 = fsub double %847, %848
  store double %849, ptr %48, align 8
  %850 = load double, ptr %51, align 8
  %851 = fmul double %761, %neg33.1
  %852 = fsub double %850, %851
  store double %852, ptr %51, align 8
  %indvars.iv.next38.1 = add nsw i64 %indvars.iv37, 2
  %exitcond41.not.1 = icmp eq i64 %wide.trip.count40, %indvars.iv.next38.1
  br i1 %exitcond41.not.1, label %loop_body_tail.loopexit, label %for_loop_body13
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.sqrt.f64(double) #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.maxnum.f64(double, double) #3

; Function Attrs: argmemonly mustprogress nofree norecurse nosync nounwind willreturn
define internal fastcc void @S24_refine_coordinates(ptr nocapture readonly %0, ptr nocapture writeonly %1, i32 %2) unnamed_addr #4 {
entry:
  %3 = and i32 %2, 3
  %4 = load i32, ptr %0, align 4
  %5 = shl i32 %4, 2
  %6 = or i32 %5, %3
  store i32 %6, ptr %1, align 4
  %7 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 1
  %8 = load i32, ptr %7, align 4
  %9 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 1
  store i32 %8, ptr %9, align 4
  %10 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 2
  %11 = load i32, ptr %10, align 4
  %12 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 2
  store i32 %11, ptr %12, align 4
  %13 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 3
  %14 = load i32, ptr %13, align 4
  %15 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 3
  store i32 %14, ptr %15, align 4
  %16 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 4
  %17 = load i32, ptr %16, align 4
  %18 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 4
  store i32 %17, ptr %18, align 4
  %19 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 5
  %20 = load i32, ptr %19, align 4
  %21 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 5
  store i32 %20, ptr %21, align 4
  %22 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 6
  %23 = load i32, ptr %22, align 4
  %24 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 6
  store i32 %23, ptr %24, align 4
  %25 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 7
  %26 = load i32, ptr %25, align 4
  %27 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 7
  store i32 %26, ptr %27, align 4
  %28 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 8
  %29 = load i32, ptr %28, align 4
  %30 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 8
  store i32 %29, ptr %30, align 4
  %31 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 9
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 9
  store i32 %32, ptr %33, align 4
  %34 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 10
  %35 = load i32, ptr %34, align 4
  %36 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 10
  store i32 %35, ptr %36, align 4
  %37 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 11
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 11
  store i32 %38, ptr %39, align 4
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #5

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn writeonly
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #6

; Function Attrs: noinline nounwind optnone uwtable
define internal fastcc void @taichi_assert_format(ptr noundef %0, i1 noundef zeroext %1, ptr noundef %2) unnamed_addr #7 {
  %4 = alloca ptr, align 8
  %5 = alloca i8, align 1
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca ptr, align 8
  %9 = alloca %class.anon, align 8
  store ptr %0, ptr %4, align 8
  %10 = zext i1 %1 to i8
  store i8 %10, ptr %5, align 1
  store ptr %2, ptr %6, align 8
  store i32 0, ptr %7, align 4
  store ptr null, ptr %8, align 8
  %11 = load i8, ptr %5, align 1
  %12 = trunc i8 %11 to i1
  %13 = zext i1 %12 to i32
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %15, label %16

15:                                               ; preds = %3
  br label %69

16:                                               ; preds = %3
  %17 = load ptr, ptr %4, align 8
  %18 = getelementptr inbounds %struct.LLVMRuntime, ptr %17, i32 0, i32 24
  %19 = load i64, ptr %18, align 8
  %20 = icmp ne i64 %19, 0
  br i1 %20, label %69, label %21

21:                                               ; preds = %16
  %22 = load ptr, ptr %4, align 8
  %23 = getelementptr inbounds %struct.LLVMRuntime, ptr %22, i32 0, i32 23
  %24 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 0
  store ptr %4, ptr %24, align 8
  %25 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 1
  store ptr %6, ptr %25, align 8
  %26 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 2
  store ptr %7, ptr %26, align 8
  %27 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 3
  store ptr %8, ptr %27, align 8
  br label %28

28:                                               ; preds = %28, %21
  %29 = atomicrmw volatile xchg ptr %23, i32 1 seq_cst, align 4
  %30 = icmp eq i32 %29, 1
  br i1 %30, label %28, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i:                        ; preds = %28
  %31 = load ptr, ptr %9, align 8
  %32 = load ptr, ptr %31, align 8
  %33 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 24
  %34 = load i64, ptr %33, align 8
  %.not.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i, label %35, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

35:                                               ; preds = %mutex_lock_i32.exit.i.i.i
  store i64 1, ptr %33, align 8
  %36 = load ptr, ptr %9, align 8
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr inbounds %struct.LLVMRuntime, ptr %37, i64 0, i32 21
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %38, i8 0, i64 2048, i1 false)
  %39 = load ptr, ptr %9, align 8
  %40 = load ptr, ptr %39, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 21
  %42 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 1
  %43 = load ptr, ptr %42, align 8
  %44 = load ptr, ptr %43, align 8
  %45 = load i8, ptr %44, align 1
  %.not5.i.i.i.i.i = icmp eq i8 %45, 0
  br i1 %.not5.i.i.i.i.i, label %taichi_strlen.exit.thread.i.i.i.i, label %.lr.ph.i.i.i.i.i.preheader

.lr.ph.i.i.i.i.i.preheader:                       ; preds = %35
  br label %.lr.ph.i.i.i.i.i

.lr.ph.i.i.i.i.i:                                 ; preds = %.lr.ph.i.i.i.i.i, %.lr.ph.i.i.i.i.i.preheader
  %.07.i.i.i.i.i = phi ptr [ %47, %.lr.ph.i.i.i.i.i ], [ %44, %.lr.ph.i.i.i.i.i.preheader ]
  %.046.i.i.i.i.i = phi i64 [ %46, %.lr.ph.i.i.i.i.i ], [ 0, %.lr.ph.i.i.i.i.i.preheader ]
  %46 = add i64 %.046.i.i.i.i.i, 1
  %47 = getelementptr inbounds i8, ptr %.07.i.i.i.i.i, i64 1
  %48 = load i8, ptr %47, align 1
  %.not.i.i.i.i.i = icmp eq i8 %48, 0
  br i1 %.not.i.i.i.i.i, label %taichi_strlen.exit.i.i.i.i, label %.lr.ph.i.i.i.i.i, !llvm.loop !11

taichi_strlen.exit.i.i.i.i:                       ; preds = %.lr.ph.i.i.i.i.i
  %.lcssa = phi i64 [ %46, %.lr.ph.i.i.i.i.i ]
  %49 = call i64 @llvm.umin.i64(i64 %.lcssa, i64 2047)
  br label %taichi_strlen.exit.thread.i.i.i.i

taichi_strlen.exit.thread.i.i.i.i:                ; preds = %taichi_strlen.exit.i.i.i.i, %35
  %50 = phi i64 [ 0, %35 ], [ %49, %taichi_strlen.exit.i.i.i.i ]
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %41, ptr nonnull align 1 %44, i64 %50, i1 false)
  %51 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 2
  %52 = load ptr, ptr %51, align 8
  %53 = load i32, ptr %52, align 4
  %54 = icmp sgt i32 %53, 0
  br i1 %54, label %.lr.ph.i.i.i.i, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

.lr.ph.i.i.i.i:                                   ; preds = %taichi_strlen.exit.thread.i.i.i.i
  %55 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 3
  br label %56

56:                                               ; preds = %56, %.lr.ph.i.i.i.i
  %indvars.iv.i.i.i.i = phi i64 [ 0, %.lr.ph.i.i.i.i ], [ %indvars.iv.next.i.i.i.i, %56 ]
  %57 = load ptr, ptr %55, align 8
  %58 = load ptr, ptr %57, align 8
  %59 = getelementptr inbounds i64, ptr %58, i64 %indvars.iv.i.i.i.i
  %60 = load i64, ptr %59, align 8
  %61 = load ptr, ptr %9, align 8
  %62 = load ptr, ptr %61, align 8
  %63 = getelementptr inbounds %struct.LLVMRuntime, ptr %62, i64 0, i32 22, i64 %indvars.iv.i.i.i.i
  store i64 %60, ptr %63, align 8
  %indvars.iv.next.i.i.i.i = add nuw nsw i64 %indvars.iv.i.i.i.i, 1
  %64 = load ptr, ptr %51, align 8
  %65 = load i32, ptr %64, align 4
  %66 = sext i32 %65 to i64
  %67 = icmp slt i64 %indvars.iv.next.i.i.i.i, %66
  br i1 %67, label %56, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", !llvm.loop !12

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit": ; preds = %56
  br label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit": ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", %taichi_strlen.exit.thread.i.i.i.i, %mutex_lock_i32.exit.i.i.i
  %68 = atomicrmw volatile xchg ptr %23, i32 0 seq_cst, align 4
  br label %69

69:                                               ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit", %16, %15
  ret void
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_struct_for_block_helper(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #8 {
_ZN11ListManager3getI7ElementEERT_i.exit:
  %3 = alloca %struct.RuntimeContext.699, align 8
  %4 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 4
  %5 = load i32, ptr %4, align 4
  %6 = sdiv i32 %2, %5
  %7 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  %8 = load i32, ptr %7, align 8
  %9 = sdiv i32 %8, %5
  %10 = srem i32 %2, %5
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  %12 = load ptr, ptr %11, align 8
  %13 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %14 = load i32, ptr %13, align 8
  %15 = ashr i32 %6, %14
  %16 = sext i32 %15 to i64
  %17 = lshr i64 %16, 9
  %18 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %17
  %19 = load atomic i64, ptr %18 acquire, align 8
  %.not.i.i.i = icmp ne i64 %19, 0
  tail call void @llvm.assume(i1 %.not.i.i.i)
  %20 = inttoptr i64 %19 to ptr
  %21 = and i64 %16, 511
  %22 = getelementptr inbounds ptr, ptr %20, i64 %21
  %23 = load atomic i64, ptr %22 acquire, align 8
  %24 = inttoptr i64 %23 to ptr
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %26 = load i64, ptr %25, align 8
  %27 = load i32, ptr %13, align 8
  %notmask.i.i = shl nsw i32 -1, %27
  %28 = xor i32 %notmask.i.i, -1
  %29 = and i32 %6, %28
  %30 = sext i32 %29 to i64
  %31 = mul i64 %26, %30
  %32 = getelementptr inbounds i8, ptr %24, i64 %31
  %33 = getelementptr inbounds %0, ptr %32, i64 0, i32 1
  %34 = load i32, ptr %33, align 8
  %35 = mul nsw i32 %10, %9
  %36 = add nsw i32 %34, %35
  %37 = add nsw i32 %10, 1
  %38 = mul nsw i32 %37, %9
  %39 = add nsw i32 %34, %38
  %40 = getelementptr inbounds %0, ptr %32, i64 0, i32 1, i64 1
  %41 = load i32, ptr %40, align 4
  %42 = tail call i32 @llvm.smin.i32(i32 %41, i32 %39)
  %43 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  %44 = load i64, ptr %43, align 8
  %45 = alloca i8, i64 %44, align 8
  %46 = load ptr, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %3, ptr noundef nonnull align 8 dereferenceable(32) %46, i64 32, i1 false)
  %47 = getelementptr inbounds %struct.RuntimeContext.699, ptr %3, i64 0, i32 2
  store i32 %1, ptr %47, align 8
  %48 = icmp slt i32 %36, %42
  br i1 %48, label %49, label %75

49:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit
  %50 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = load ptr, ptr %11, align 8
  %53 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 3
  %54 = load i32, ptr %53, align 8
  %55 = ashr i32 %6, %54
  %56 = sext i32 %55 to i64
  %57 = lshr i64 %56, 9
  %58 = getelementptr inbounds [256 x ptr], ptr %52, i64 0, i64 %57
  %59 = load atomic i64, ptr %58 acquire, align 8
  %.not.i.i.i24 = icmp eq i64 %59, 0
  br i1 %.not.i.i.i24, label %_ZN11ListManager3getI7ElementEERT_i.exit26, label %60

60:                                               ; preds = %49
  %61 = inttoptr i64 %59 to ptr
  %62 = and i64 %56, 511
  %63 = getelementptr inbounds ptr, ptr %61, i64 %62
  %64 = load atomic i64, ptr %63 acquire, align 8
  %65 = inttoptr i64 %64 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit26

_ZN11ListManager3getI7ElementEERT_i.exit26:       ; preds = %60, %49
  %66 = phi ptr [ %65, %60 ], [ null, %49 ]
  %67 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 1
  %68 = load i64, ptr %67, align 8
  %69 = load i32, ptr %53, align 8
  %notmask.i.i25 = shl nsw i32 -1, %69
  %70 = xor i32 %notmask.i.i25, -1
  %71 = and i32 %6, %70
  %72 = sext i32 %71 to i64
  %73 = mul i64 %68, %72
  %74 = getelementptr inbounds i8, ptr %66, i64 %73
  call void %51(ptr noundef nonnull %3, ptr noundef nonnull %45, ptr noundef nonnull %74, i32 noundef %36, i32 noundef %42) #1
  br label %75

75:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit26, %_ZN11ListManager3getI7ElementEERT_i.exit
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i64 @llvm.umin.i64(i64, i64) #9

; Function Attrs: inaccessiblememonly nocallback nofree nosync nounwind willreturn
declare void @llvm.assume(i1 noundef) #10

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #9

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #11

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #11

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { nofree nounwind }
attributes #3 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #4 = { argmemonly mustprogress nofree norecurse nosync nounwind willreturn }
attributes #5 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #6 = { argmemonly mustprogress nocallback nofree nounwind willreturn writeonly }
attributes #7 = { noinline nounwind optnone uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #10 = { inaccessiblememonly nocallback nofree nosync nounwind willreturn }
attributes #11 = { argmemonly nocallback nofree nosync nounwind willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
