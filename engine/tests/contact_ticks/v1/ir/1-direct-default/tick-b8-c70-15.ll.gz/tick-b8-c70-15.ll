; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct.RuntimeContext.990 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }
%struct.range_task_helper_context = type { ptr, ptr, ptr, ptr, i64, i32, i32, i32, i32 }

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @geometry_source_order_5_selection_25_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %0, i64 0, i32 3
  %2 = load i32, ptr %1, align 4
  %3 = getelementptr inbounds %struct.RuntimeContext.990, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  store i32 %2, ptr %6, align 4
  ret void
}

; Function Attrs: nounwind
define void @geometry_source_order_5_selection_25_kernel_1_range_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.range_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 1
  %2 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 4
  store ptr %context, ptr %0, align 8
  store ptr null, ptr %1, align 8
  store i64 1, ptr %2, align 8
  %3 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 2
  store ptr @function_body, ptr %3, align 8
  %4 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 3
  store ptr null, ptr %4, align 8
  %5 = getelementptr inbounds %struct.range_task_helper_context, ptr %0, i64 0, i32 5
  store <4 x i32> <i32 0, i32 1, i32 1, i32 1>, ptr %5, align 8
  %6 = getelementptr inbounds %struct.RuntimeContext.990, ptr %context, i64 0, i32 1
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 12
  %9 = load ptr, ptr %8, align 8
  %10 = getelementptr inbounds %struct.LLVMRuntime, ptr %7, i64 0, i32 11
  %11 = load ptr, ptr %10, align 8
  call void %9(ptr noundef %11, i32 noundef 1, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_parallel_range_for_task) #1
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree nosync nounwind
define internal void @function_body(ptr nocapture readonly %0, ptr nocapture readnone %1, i32 %2) #2 {
allocs:
  %3 = getelementptr inbounds %struct.RuntimeContext.990, ptr %0, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  %7 = load i32, ptr %6, align 4
  %8 = tail call i32 @llvm.smax.i32(i32 %7, i32 512)
  %9 = mul i32 %8, %2
  %10 = add i32 %9, %8
  %11 = tail call i32 @llvm.smin.i32(i32 %7, i32 %10)
  %12 = icmp slt i32 %9, %11
  br i1 %12, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %allocs
  %13 = load ptr, ptr %0, align 8
  %14 = getelementptr { { i32, i32 }, ptr }, ptr %13, i64 0, i32 1
  %15 = getelementptr { { i32, i32 }, ptr }, ptr %13, i64 0, i32 0, i32 1
  %16 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %13, i64 0, i32 1, i32 1
  %17 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %13, i64 0, i32 2, i32 1
  %18 = sext i32 %9 to i64
  %wide.trip.count30 = sext i32 %11 to i64
  br label %for_loop_body

for_loop_body:                                    ; preds = %after_for3, %for_loop_body.lr.ph
  %indvars.iv27 = phi i64 [ %18, %for_loop_body.lr.ph ], [ %indvars.iv.next28, %after_for3 ]
  %19 = load ptr, ptr %14, align 8
  %20 = load i32, ptr %15, align 4
  %21 = sext i32 %20 to i64
  %22 = getelementptr i32, ptr %19, i64 %indvars.iv27
  %23 = load i32, ptr %22, align 4
  %24 = add nsw i64 %indvars.iv27, %21
  %25 = getelementptr i32, ptr %19, i64 %24
  %26 = load i32, ptr %25, align 4
  %27 = tail call i32 @llvm.smin.i32(i32 %23, i32 %26)
  %28 = zext i32 %27 to i64
  %29 = shl nuw i64 %28, 32
  %30 = tail call i32 @llvm.smax.i32(i32 %23, i32 %26)
  %31 = sext i32 %30 to i64
  %32 = add i64 %29, %31
  %33 = load i32, ptr %6, align 4
  %34 = icmp sgt i32 %33, 0
  br i1 %34, label %for_loop_body1.preheader, label %after_for3

for_loop_body1.preheader:                         ; preds = %for_loop_body
  %wide.trip.count = zext i32 %33 to i64
  %min.iters.check = icmp ult i32 %33, 8
  br i1 %min.iters.check, label %for_loop_body1.preheader43, label %vector.ph

vector.ph:                                        ; preds = %for_loop_body1.preheader
  %n.vec = and i64 %wide.trip.count, 4294967288
  %broadcast.splatinsert = insertelement <8 x i64> poison, i64 %32, i64 0
  %broadcast.splat = shufflevector <8 x i64> %broadcast.splatinsert, <8 x i64> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert39 = insertelement <8 x i64> poison, i64 %indvars.iv27, i64 0
  %broadcast.splat40 = shufflevector <8 x i64> %broadcast.splatinsert39, <8 x i64> poison, <8 x i32> zeroinitializer
  %35 = add nsw i64 %n.vec, -8
  %36 = lshr exact i64 %35, 3
  %37 = add nuw nsw i64 %36, 1
  %xtraiter = and i64 %37, 7
  %38 = icmp ult i64 %35, 56
  br i1 %38, label %middle.block.unr-lcssa, label %vector.ph.new

vector.ph.new:                                    ; preds = %vector.ph
  %unroll_iter = and i64 %37, 4611686018427387896
  %uglygep = getelementptr i8, ptr %19, i64 224
  %39 = shl nsw i64 %21, 2
  %uglygep76 = getelementptr i8, ptr %uglygep, i64 %39
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph.new
  %lsr.iv = phi i64 [ %lsr.iv.next, %vector.body ], [ %unroll_iter, %vector.ph.new ]
  %index = phi i64 [ 0, %vector.ph.new ], [ %index.next.7, %vector.body ]
  %vec.ind = phi <8 x i64> [ <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, %vector.ph.new ], [ %vec.ind.next.7, %vector.body ]
  %vec.phi = phi <8 x i32> [ zeroinitializer, %vector.ph.new ], [ %176, %vector.body ]
  %vec.phi36 = phi <8 x i32> [ zeroinitializer, %vector.ph.new ], [ %174, %vector.body ]
  %vec.phi37 = phi <8 x i32> [ zeroinitializer, %vector.ph.new ], [ %172, %vector.body ]
  %40 = shl i64 %index, 2
  %uglygep74 = getelementptr i8, ptr %uglygep, i64 %40
  %uglygep75 = getelementptr i8, ptr %uglygep74, i64 -224
  %wide.load = load <8 x i32>, ptr %uglygep75, align 4
  %uglygep90 = getelementptr i8, ptr %uglygep76, i64 %40
  %uglygep91 = getelementptr i8, ptr %uglygep90, i64 -224
  %wide.load38 = load <8 x i32>, ptr %uglygep91, align 4
  %41 = call <8 x i32> @llvm.smin.v8i32(<8 x i32> %wide.load, <8 x i32> %wide.load38)
  %42 = zext <8 x i32> %41 to <8 x i64>
  %43 = shl nuw <8 x i64> %42, <i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32>
  %44 = call <8 x i32> @llvm.smax.v8i32(<8 x i32> %wide.load, <8 x i32> %wide.load38)
  %45 = sext <8 x i32> %44 to <8 x i64>
  %46 = add <8 x i64> %43, %45
  %47 = icmp eq <8 x i64> %46, %broadcast.splat
  %48 = icmp slt <8 x i64> %vec.ind, %broadcast.splat40
  %49 = and <8 x i1> %48, %47
  %50 = icmp slt <8 x i64> %46, %broadcast.splat
  %51 = or <8 x i1> %50, %49
  %52 = zext <8 x i1> %51 to <8 x i32>
  %53 = add <8 x i32> %vec.phi37, %52
  %54 = zext <8 x i1> %47 to <8 x i32>
  %55 = add <8 x i32> %vec.phi36, %54
  %56 = zext <8 x i1> %49 to <8 x i32>
  %57 = add <8 x i32> %vec.phi, %56
  %vec.ind.next = add <8 x i64> %vec.ind, <i64 8, i64 8, i64 8, i64 8, i64 8, i64 8, i64 8, i64 8>
  %uglygep72 = getelementptr i8, ptr %uglygep74, i64 -192
  %wide.load.1 = load <8 x i32>, ptr %uglygep72, align 4
  %uglygep88 = getelementptr i8, ptr %uglygep90, i64 -192
  %wide.load38.1 = load <8 x i32>, ptr %uglygep88, align 4
  %58 = call <8 x i32> @llvm.smin.v8i32(<8 x i32> %wide.load.1, <8 x i32> %wide.load38.1)
  %59 = zext <8 x i32> %58 to <8 x i64>
  %60 = shl nuw <8 x i64> %59, <i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32>
  %61 = call <8 x i32> @llvm.smax.v8i32(<8 x i32> %wide.load.1, <8 x i32> %wide.load38.1)
  %62 = sext <8 x i32> %61 to <8 x i64>
  %63 = add <8 x i64> %60, %62
  %64 = icmp eq <8 x i64> %63, %broadcast.splat
  %65 = icmp slt <8 x i64> %vec.ind.next, %broadcast.splat40
  %66 = and <8 x i1> %65, %64
  %67 = icmp slt <8 x i64> %63, %broadcast.splat
  %68 = or <8 x i1> %67, %66
  %69 = zext <8 x i1> %68 to <8 x i32>
  %70 = add <8 x i32> %53, %69
  %71 = zext <8 x i1> %64 to <8 x i32>
  %72 = add <8 x i32> %55, %71
  %73 = zext <8 x i1> %66 to <8 x i32>
  %74 = add <8 x i32> %57, %73
  %vec.ind.next.1 = add <8 x i64> %vec.ind, <i64 16, i64 16, i64 16, i64 16, i64 16, i64 16, i64 16, i64 16>
  %uglygep70 = getelementptr i8, ptr %uglygep74, i64 -160
  %wide.load.2 = load <8 x i32>, ptr %uglygep70, align 4
  %uglygep86 = getelementptr i8, ptr %uglygep90, i64 -160
  %wide.load38.2 = load <8 x i32>, ptr %uglygep86, align 4
  %75 = call <8 x i32> @llvm.smin.v8i32(<8 x i32> %wide.load.2, <8 x i32> %wide.load38.2)
  %76 = zext <8 x i32> %75 to <8 x i64>
  %77 = shl nuw <8 x i64> %76, <i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32>
  %78 = call <8 x i32> @llvm.smax.v8i32(<8 x i32> %wide.load.2, <8 x i32> %wide.load38.2)
  %79 = sext <8 x i32> %78 to <8 x i64>
  %80 = add <8 x i64> %77, %79
  %81 = icmp eq <8 x i64> %80, %broadcast.splat
  %82 = icmp slt <8 x i64> %vec.ind.next.1, %broadcast.splat40
  %83 = and <8 x i1> %82, %81
  %84 = icmp slt <8 x i64> %80, %broadcast.splat
  %85 = or <8 x i1> %84, %83
  %86 = zext <8 x i1> %85 to <8 x i32>
  %87 = add <8 x i32> %70, %86
  %88 = zext <8 x i1> %81 to <8 x i32>
  %89 = add <8 x i32> %72, %88
  %90 = zext <8 x i1> %83 to <8 x i32>
  %91 = add <8 x i32> %74, %90
  %vec.ind.next.2 = add <8 x i64> %vec.ind, <i64 24, i64 24, i64 24, i64 24, i64 24, i64 24, i64 24, i64 24>
  %uglygep68 = getelementptr i8, ptr %uglygep74, i64 -128
  %wide.load.3 = load <8 x i32>, ptr %uglygep68, align 4
  %uglygep84 = getelementptr i8, ptr %uglygep90, i64 -128
  %wide.load38.3 = load <8 x i32>, ptr %uglygep84, align 4
  %92 = call <8 x i32> @llvm.smin.v8i32(<8 x i32> %wide.load.3, <8 x i32> %wide.load38.3)
  %93 = zext <8 x i32> %92 to <8 x i64>
  %94 = shl nuw <8 x i64> %93, <i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32>
  %95 = call <8 x i32> @llvm.smax.v8i32(<8 x i32> %wide.load.3, <8 x i32> %wide.load38.3)
  %96 = sext <8 x i32> %95 to <8 x i64>
  %97 = add <8 x i64> %94, %96
  %98 = icmp eq <8 x i64> %97, %broadcast.splat
  %99 = icmp slt <8 x i64> %vec.ind.next.2, %broadcast.splat40
  %100 = and <8 x i1> %99, %98
  %101 = icmp slt <8 x i64> %97, %broadcast.splat
  %102 = or <8 x i1> %101, %100
  %103 = zext <8 x i1> %102 to <8 x i32>
  %104 = add <8 x i32> %87, %103
  %105 = zext <8 x i1> %98 to <8 x i32>
  %106 = add <8 x i32> %89, %105
  %107 = zext <8 x i1> %100 to <8 x i32>
  %108 = add <8 x i32> %91, %107
  %vec.ind.next.3 = add <8 x i64> %vec.ind, <i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32>
  %uglygep66 = getelementptr i8, ptr %uglygep74, i64 -96
  %wide.load.4 = load <8 x i32>, ptr %uglygep66, align 4
  %uglygep82 = getelementptr i8, ptr %uglygep90, i64 -96
  %wide.load38.4 = load <8 x i32>, ptr %uglygep82, align 4
  %109 = call <8 x i32> @llvm.smin.v8i32(<8 x i32> %wide.load.4, <8 x i32> %wide.load38.4)
  %110 = zext <8 x i32> %109 to <8 x i64>
  %111 = shl nuw <8 x i64> %110, <i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32>
  %112 = call <8 x i32> @llvm.smax.v8i32(<8 x i32> %wide.load.4, <8 x i32> %wide.load38.4)
  %113 = sext <8 x i32> %112 to <8 x i64>
  %114 = add <8 x i64> %111, %113
  %115 = icmp eq <8 x i64> %114, %broadcast.splat
  %116 = icmp slt <8 x i64> %vec.ind.next.3, %broadcast.splat40
  %117 = and <8 x i1> %116, %115
  %118 = icmp slt <8 x i64> %114, %broadcast.splat
  %119 = or <8 x i1> %118, %117
  %120 = zext <8 x i1> %119 to <8 x i32>
  %121 = add <8 x i32> %104, %120
  %122 = zext <8 x i1> %115 to <8 x i32>
  %123 = add <8 x i32> %106, %122
  %124 = zext <8 x i1> %117 to <8 x i32>
  %125 = add <8 x i32> %108, %124
  %vec.ind.next.4 = add <8 x i64> %vec.ind, <i64 40, i64 40, i64 40, i64 40, i64 40, i64 40, i64 40, i64 40>
  %uglygep64 = getelementptr i8, ptr %uglygep74, i64 -64
  %wide.load.5 = load <8 x i32>, ptr %uglygep64, align 4
  %uglygep80 = getelementptr i8, ptr %uglygep90, i64 -64
  %wide.load38.5 = load <8 x i32>, ptr %uglygep80, align 4
  %126 = call <8 x i32> @llvm.smin.v8i32(<8 x i32> %wide.load.5, <8 x i32> %wide.load38.5)
  %127 = zext <8 x i32> %126 to <8 x i64>
  %128 = shl nuw <8 x i64> %127, <i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32>
  %129 = call <8 x i32> @llvm.smax.v8i32(<8 x i32> %wide.load.5, <8 x i32> %wide.load38.5)
  %130 = sext <8 x i32> %129 to <8 x i64>
  %131 = add <8 x i64> %128, %130
  %132 = icmp eq <8 x i64> %131, %broadcast.splat
  %133 = icmp slt <8 x i64> %vec.ind.next.4, %broadcast.splat40
  %134 = and <8 x i1> %133, %132
  %135 = icmp slt <8 x i64> %131, %broadcast.splat
  %136 = or <8 x i1> %135, %134
  %137 = zext <8 x i1> %136 to <8 x i32>
  %138 = add <8 x i32> %121, %137
  %139 = zext <8 x i1> %132 to <8 x i32>
  %140 = add <8 x i32> %123, %139
  %141 = zext <8 x i1> %134 to <8 x i32>
  %142 = add <8 x i32> %125, %141
  %vec.ind.next.5 = add <8 x i64> %vec.ind, <i64 48, i64 48, i64 48, i64 48, i64 48, i64 48, i64 48, i64 48>
  %uglygep62 = getelementptr i8, ptr %uglygep74, i64 -32
  %wide.load.6 = load <8 x i32>, ptr %uglygep62, align 4
  %uglygep78 = getelementptr i8, ptr %uglygep90, i64 -32
  %wide.load38.6 = load <8 x i32>, ptr %uglygep78, align 4
  %143 = call <8 x i32> @llvm.smin.v8i32(<8 x i32> %wide.load.6, <8 x i32> %wide.load38.6)
  %144 = zext <8 x i32> %143 to <8 x i64>
  %145 = shl nuw <8 x i64> %144, <i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32>
  %146 = call <8 x i32> @llvm.smax.v8i32(<8 x i32> %wide.load.6, <8 x i32> %wide.load38.6)
  %147 = sext <8 x i32> %146 to <8 x i64>
  %148 = add <8 x i64> %145, %147
  %149 = icmp eq <8 x i64> %148, %broadcast.splat
  %150 = icmp slt <8 x i64> %vec.ind.next.5, %broadcast.splat40
  %151 = and <8 x i1> %150, %149
  %152 = icmp slt <8 x i64> %148, %broadcast.splat
  %153 = or <8 x i1> %152, %151
  %154 = zext <8 x i1> %153 to <8 x i32>
  %155 = add <8 x i32> %138, %154
  %156 = zext <8 x i1> %149 to <8 x i32>
  %157 = add <8 x i32> %140, %156
  %158 = zext <8 x i1> %151 to <8 x i32>
  %159 = add <8 x i32> %142, %158
  %vec.ind.next.6 = add <8 x i64> %vec.ind, <i64 56, i64 56, i64 56, i64 56, i64 56, i64 56, i64 56, i64 56>
  %wide.load.7 = load <8 x i32>, ptr %uglygep74, align 4
  %wide.load38.7 = load <8 x i32>, ptr %uglygep90, align 4
  %160 = call <8 x i32> @llvm.smin.v8i32(<8 x i32> %wide.load.7, <8 x i32> %wide.load38.7)
  %161 = zext <8 x i32> %160 to <8 x i64>
  %162 = shl nuw <8 x i64> %161, <i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32>
  %163 = call <8 x i32> @llvm.smax.v8i32(<8 x i32> %wide.load.7, <8 x i32> %wide.load38.7)
  %164 = sext <8 x i32> %163 to <8 x i64>
  %165 = add <8 x i64> %162, %164
  %166 = icmp eq <8 x i64> %165, %broadcast.splat
  %167 = icmp slt <8 x i64> %vec.ind.next.6, %broadcast.splat40
  %168 = and <8 x i1> %167, %166
  %169 = icmp slt <8 x i64> %165, %broadcast.splat
  %170 = or <8 x i1> %169, %168
  %171 = zext <8 x i1> %170 to <8 x i32>
  %172 = add <8 x i32> %155, %171
  %173 = zext <8 x i1> %166 to <8 x i32>
  %174 = add <8 x i32> %157, %173
  %175 = zext <8 x i1> %168 to <8 x i32>
  %176 = add <8 x i32> %159, %175
  %index.next.7 = add i64 %index, 64
  %vec.ind.next.7 = add <8 x i64> %vec.ind, <i64 64, i64 64, i64 64, i64 64, i64 64, i64 64, i64 64, i64 64>
  %lsr.iv.next = add i64 %lsr.iv, -8
  %niter.ncmp.7 = icmp eq i64 %lsr.iv.next, 0
  br i1 %niter.ncmp.7, label %middle.block.unr-lcssa.loopexit, label %vector.body, !llvm.loop !6

middle.block.unr-lcssa.loopexit:                  ; preds = %vector.body
  br label %middle.block.unr-lcssa

middle.block.unr-lcssa:                           ; preds = %middle.block.unr-lcssa.loopexit, %vector.ph
  %.lcssa45.ph = phi <8 x i32> [ undef, %vector.ph ], [ %172, %middle.block.unr-lcssa.loopexit ]
  %.lcssa44.ph = phi <8 x i32> [ undef, %vector.ph ], [ %174, %middle.block.unr-lcssa.loopexit ]
  %.lcssa.ph = phi <8 x i32> [ undef, %vector.ph ], [ %176, %middle.block.unr-lcssa.loopexit ]
  %index.unr = phi i64 [ 0, %vector.ph ], [ %index.next.7, %middle.block.unr-lcssa.loopexit ]
  %vec.ind.unr = phi <8 x i64> [ <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, %vector.ph ], [ %vec.ind.next.7, %middle.block.unr-lcssa.loopexit ]
  %vec.phi.unr = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %176, %middle.block.unr-lcssa.loopexit ]
  %vec.phi36.unr = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %174, %middle.block.unr-lcssa.loopexit ]
  %vec.phi37.unr = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %172, %middle.block.unr-lcssa.loopexit ]
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %middle.block, label %vector.body.epil.preheader

vector.body.epil.preheader:                       ; preds = %middle.block.unr-lcssa
  %177 = add i64 %index.unr, %21
  %178 = shl i64 %177, 2
  %uglygep92 = getelementptr i8, ptr %19, i64 %178
  %179 = shl i64 %index.unr, 2
  %uglygep96 = getelementptr i8, ptr %19, i64 %179
  %180 = shl nuw nsw i64 %xtraiter, 5
  br label %vector.body.epil

vector.body.epil:                                 ; preds = %vector.body.epil, %vector.body.epil.preheader
  %lsr.iv93 = phi i64 [ 0, %vector.body.epil.preheader ], [ %lsr.iv.next94, %vector.body.epil ]
  %vec.ind.epil = phi <8 x i64> [ %vec.ind.next.epil, %vector.body.epil ], [ %vec.ind.unr, %vector.body.epil.preheader ]
  %vec.phi.epil = phi <8 x i32> [ %197, %vector.body.epil ], [ %vec.phi.unr, %vector.body.epil.preheader ]
  %vec.phi36.epil = phi <8 x i32> [ %195, %vector.body.epil ], [ %vec.phi36.unr, %vector.body.epil.preheader ]
  %vec.phi37.epil = phi <8 x i32> [ %193, %vector.body.epil ], [ %vec.phi37.unr, %vector.body.epil.preheader ]
  %uglygep97 = getelementptr i8, ptr %uglygep96, i64 %lsr.iv93
  %wide.load.epil = load <8 x i32>, ptr %uglygep97, align 4
  %uglygep95 = getelementptr i8, ptr %uglygep92, i64 %lsr.iv93
  %wide.load38.epil = load <8 x i32>, ptr %uglygep95, align 4
  %181 = call <8 x i32> @llvm.smin.v8i32(<8 x i32> %wide.load.epil, <8 x i32> %wide.load38.epil)
  %182 = zext <8 x i32> %181 to <8 x i64>
  %183 = shl nuw <8 x i64> %182, <i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32, i64 32>
  %184 = call <8 x i32> @llvm.smax.v8i32(<8 x i32> %wide.load.epil, <8 x i32> %wide.load38.epil)
  %185 = sext <8 x i32> %184 to <8 x i64>
  %186 = add <8 x i64> %183, %185
  %187 = icmp eq <8 x i64> %186, %broadcast.splat
  %188 = icmp slt <8 x i64> %vec.ind.epil, %broadcast.splat40
  %189 = and <8 x i1> %188, %187
  %190 = icmp slt <8 x i64> %186, %broadcast.splat
  %191 = or <8 x i1> %190, %189
  %192 = zext <8 x i1> %191 to <8 x i32>
  %193 = add <8 x i32> %vec.phi37.epil, %192
  %194 = zext <8 x i1> %187 to <8 x i32>
  %195 = add <8 x i32> %vec.phi36.epil, %194
  %196 = zext <8 x i1> %189 to <8 x i32>
  %197 = add <8 x i32> %vec.phi.epil, %196
  %vec.ind.next.epil = add <8 x i64> %vec.ind.epil, <i64 8, i64 8, i64 8, i64 8, i64 8, i64 8, i64 8, i64 8>
  %lsr.iv.next94 = add nuw nsw i64 %lsr.iv93, 32
  %epil.iter.cmp.not = icmp eq i64 %180, %lsr.iv.next94
  br i1 %epil.iter.cmp.not, label %middle.block.loopexit, label %vector.body.epil, !llvm.loop !8

middle.block.loopexit:                            ; preds = %vector.body.epil
  br label %middle.block

middle.block:                                     ; preds = %middle.block.loopexit, %middle.block.unr-lcssa
  %.lcssa45 = phi <8 x i32> [ %.lcssa45.ph, %middle.block.unr-lcssa ], [ %193, %middle.block.loopexit ]
  %.lcssa44 = phi <8 x i32> [ %.lcssa44.ph, %middle.block.unr-lcssa ], [ %195, %middle.block.loopexit ]
  %.lcssa = phi <8 x i32> [ %.lcssa.ph, %middle.block.unr-lcssa ], [ %197, %middle.block.loopexit ]
  %198 = call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %.lcssa45)
  %199 = call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %.lcssa44)
  %200 = call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %.lcssa)
  %cmp.n = icmp eq i64 %n.vec, %wide.trip.count
  br i1 %cmp.n, label %after_for3, label %for_loop_body1.preheader43

for_loop_body1.preheader43:                       ; preds = %middle.block, %for_loop_body1.preheader
  %indvars.iv.ph = phi i64 [ 0, %for_loop_body1.preheader ], [ %n.vec, %middle.block ]
  %.01319.ph = phi i32 [ 0, %for_loop_body1.preheader ], [ %200, %middle.block ]
  %.01418.ph = phi i32 [ 0, %for_loop_body1.preheader ], [ %199, %middle.block ]
  %.01517.ph = phi i32 [ 0, %for_loop_body1.preheader ], [ %198, %middle.block ]
  %201 = shl nsw i64 %21, 2
  %uglygep98 = getelementptr i8, ptr %19, i64 %201
  br label %for_loop_body1

after_for.loopexit:                               ; preds = %after_for3
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %allocs
  ret void

for_loop_body1:                                   ; preds = %for_loop_body1, %for_loop_body1.preheader43
  %indvars.iv = phi i64 [ %indvars.iv.next, %for_loop_body1 ], [ %indvars.iv.ph, %for_loop_body1.preheader43 ]
  %.01319 = phi i32 [ %221, %for_loop_body1 ], [ %.01319.ph, %for_loop_body1.preheader43 ]
  %.01418 = phi i32 [ %219, %for_loop_body1 ], [ %.01418.ph, %for_loop_body1.preheader43 ]
  %.01517 = phi i32 [ %217, %for_loop_body1 ], [ %.01517.ph, %for_loop_body1.preheader43 ]
  %202 = shl i64 %indvars.iv, 2
  %uglygep100 = getelementptr i8, ptr %19, i64 %202
  %203 = load i32, ptr %uglygep100, align 4
  %uglygep99 = getelementptr i8, ptr %uglygep98, i64 %202
  %204 = load i32, ptr %uglygep99, align 4
  %205 = tail call i32 @llvm.smin.i32(i32 %203, i32 %204)
  %206 = zext i32 %205 to i64
  %207 = shl nuw i64 %206, 32
  %208 = tail call i32 @llvm.smax.i32(i32 %203, i32 %204)
  %209 = sext i32 %208 to i64
  %210 = add i64 %207, %209
  %211 = icmp eq i64 %210, %32
  %212 = icmp slt i64 %indvars.iv, %indvars.iv27
  %213 = and i1 %212, %211
  %214 = icmp slt i64 %210, %32
  %215 = or i1 %214, %213
  %216 = zext i1 %215 to i32
  %217 = add i32 %.01517, %216
  %218 = zext i1 %211 to i32
  %219 = add i32 %.01418, %218
  %220 = zext i1 %213 to i32
  %221 = add i32 %.01319, %220
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %wide.trip.count, %indvars.iv.next
  br i1 %exitcond.not, label %after_for3.loopexit, label %for_loop_body1, !llvm.loop !10

after_for3.loopexit:                              ; preds = %for_loop_body1
  br label %after_for3

after_for3:                                       ; preds = %after_for3.loopexit, %middle.block, %for_loop_body
  %.015.lcssa = phi i32 [ 0, %for_loop_body ], [ %198, %middle.block ], [ %217, %after_for3.loopexit ]
  %.014.lcssa = phi i32 [ 0, %for_loop_body ], [ %199, %middle.block ], [ %219, %after_for3.loopexit ]
  %.013.lcssa = phi i32 [ 0, %for_loop_body ], [ %200, %middle.block ], [ %221, %after_for3.loopexit ]
  %222 = load ptr, ptr %16, align 8
  %223 = sext i32 %.015.lcssa to i64
  %224 = getelementptr i32, ptr %222, i64 %223
  %225 = trunc i64 %indvars.iv27 to i32
  store i32 %225, ptr %224, align 4
  %226 = add i32 %.014.lcssa, %.015.lcssa
  %227 = sub i32 %226, %.013.lcssa
  %228 = load ptr, ptr %17, align 8
  %229 = getelementptr i32, ptr %228, i64 %223
  store i32 %227, ptr %229, align 4
  %indvars.iv.next28 = add nsw i64 %indvars.iv27, 1
  %exitcond31.not = icmp eq i64 %indvars.iv.next28, %wide.trip.count30
  br i1 %exitcond31.not, label %after_for.loopexit, label %for_loop_body
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_parallel_range_for_task(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #3 {
  %4 = alloca %struct.RuntimeContext.990, align 8
  %.sroa.0.0.copyload = load ptr, ptr %0, align 8
  %.sroa.4.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 8
  %.sroa.4.0.copyload = load ptr, ptr %.sroa.4.0..sroa_idx, align 8
  %.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 16
  %.sroa.5.0.copyload = load ptr, ptr %.sroa.5.0..sroa_idx, align 8
  %.sroa.7.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 24
  %.sroa.7.0.copyload = load ptr, ptr %.sroa.7.0..sroa_idx, align 8
  %.sroa.8.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 32
  %.sroa.8.0.copyload = load i64, ptr %.sroa.8.0..sroa_idx, align 8
  %.sroa.9.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 40
  %.sroa.9.0.copyload = load i32, ptr %.sroa.9.0..sroa_idx, align 8
  %.sroa.12.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 44
  %.sroa.12.0.copyload = load i32, ptr %.sroa.12.0..sroa_idx, align 4
  %.sroa.15.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 48
  %.sroa.15.0.copyload = load i32, ptr %.sroa.15.0..sroa_idx, align 8
  %.sroa.17.0..sroa_idx = getelementptr inbounds i8, ptr %0, i64 52
  %.sroa.17.0.copyload = load i32, ptr %.sroa.17.0..sroa_idx, align 4
  %5 = alloca i8, i64 %.sroa.8.0.copyload, align 8
  %.not = icmp eq ptr %.sroa.4.0.copyload, null
  br i1 %.not, label %7, label %6

6:                                                ; preds = %3
  call void %.sroa.4.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %7

7:                                                ; preds = %6, %3
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %4, ptr noundef nonnull align 8 dereferenceable(32) %.sroa.0.0.copyload, i64 32, i1 false)
  %8 = getelementptr inbounds %struct.RuntimeContext.990, ptr %4, i64 0, i32 2
  store i32 %1, ptr %8, align 8
  switch i32 %.sroa.17.0.copyload, label %.loopexit [
    i32 1, label %9
    i32 -1, label %17
  ]

9:                                                ; preds = %7
  %10 = mul nsw i32 %.sroa.15.0.copyload, %2
  %11 = add nsw i32 %10, %.sroa.9.0.copyload
  %12 = add nsw i32 %11, %.sroa.15.0.copyload
  %13 = call i32 @llvm.smin.i32(i32 %.sroa.12.0.copyload, i32 %12)
  %14 = icmp slt i32 %11, %13
  br i1 %14, label %.lr.ph.preheader, label %.loopexit

.lr.ph.preheader:                                 ; preds = %9
  br label %.lr.ph

.lr.ph:                                           ; preds = %.lr.ph, %.lr.ph.preheader
  %.02039 = phi i32 [ %15, %.lr.ph ], [ %11, %.lr.ph.preheader ]
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.02039) #1
  %15 = add nsw i32 %.02039, 1
  %16 = icmp slt i32 %15, %13
  br i1 %16, label %.lr.ph, label %.loopexit.loopexit, !llvm.loop !12

17:                                               ; preds = %7
  %18 = mul nsw i32 %.sroa.15.0.copyload, %2
  %19 = sub nsw i32 %.sroa.12.0.copyload, %18
  %20 = mul nsw i32 %19, %.sroa.15.0.copyload
  %21 = call i32 @llvm.smax.i32(i32 %.sroa.9.0.copyload, i32 %20)
  %.not25.not40 = icmp sgt i32 %19, %21
  br i1 %.not25.not40, label %.lr.ph42.preheader, label %.loopexit

.lr.ph42.preheader:                               ; preds = %17
  br label %.lr.ph42

.lr.ph42:                                         ; preds = %.lr.ph42, %.lr.ph42.preheader
  %.0.in41 = phi i32 [ %.0, %.lr.ph42 ], [ %19, %.lr.ph42.preheader ]
  %.0 = add nsw i32 %.0.in41, -1
  call void %.sroa.5.0.copyload(ptr noundef nonnull %4, ptr noundef nonnull %5, i32 noundef %.0) #1
  %.not25.not = icmp sgt i32 %.0, %21
  br i1 %.not25.not, label %.lr.ph42, label %.loopexit.loopexit47, !llvm.loop !14

.loopexit.loopexit:                               ; preds = %.lr.ph
  br label %.loopexit

.loopexit.loopexit47:                             ; preds = %.lr.ph42
  br label %.loopexit

.loopexit:                                        ; preds = %.loopexit.loopexit47, %.loopexit.loopexit, %17, %9, %7
  %.not24 = icmp eq ptr %.sroa.7.0.copyload, null
  br i1 %.not24, label %23, label %22

22:                                               ; preds = %.loopexit
  call void %.sroa.7.0.copyload(ptr noundef %.sroa.0.0.copyload, ptr noundef nonnull %5) #1
  br label %23

23:                                               ; preds = %22, %.loopexit
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #5

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smax.i32(i32, i32) #5

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #6

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #6

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare <8 x i32> @llvm.smin.v8i32(<8 x i32>, <8 x i32>) #7

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare <8 x i32> @llvm.smax.v8i32(<8 x i32>, <8 x i32>) #7

; Function Attrs: nocallback nofree nosync nounwind readnone willreturn
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #8

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { nofree nosync nounwind }
attributes #3 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #5 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #6 = { argmemonly nocallback nofree nosync nounwind willreturn }
attributes #7 = { nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #8 = { nocallback nofree nosync nounwind readnone willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.isvectorized", i32 1}
!8 = distinct !{!8, !9}
!9 = !{!"llvm.loop.unroll.disable"}
!10 = distinct !{!10, !11, !7}
!11 = !{!"llvm.loop.unroll.runtime.disable"}
!12 = distinct !{!12, !13}
!13 = !{!"llvm.loop.mustprogress"}
!14 = distinct !{!14, !13}
