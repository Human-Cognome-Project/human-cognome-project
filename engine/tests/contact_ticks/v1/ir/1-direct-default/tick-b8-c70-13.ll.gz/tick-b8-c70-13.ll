; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind
define void @live_hierarchy_control_28_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 24
  %2 = load i32, ptr %1, align 4
  %3 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 26
  %4 = load i32, ptr %3, align 4
  %5 = icmp eq i32 %4, 0
  br i1 %5, label %true_block, label %for_loop_test.preheader

for_loop_test.preheader:                          ; preds = %entry
  %6 = icmp sgt i32 %2, 0
  br i1 %6, label %for_loop_body.lr.ph, label %after_if

for_loop_body.lr.ph:                              ; preds = %for_loop_test.preheader
  %7 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 2, i32 1
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 2, i32 0, i32 1
  %9 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 29, i32 1
  %10 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 29, i32 0, i32 1
  %11 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 8, i32 1
  %12 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 8, i32 0, i32 1
  %13 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 13, i32 1
  %14 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 13, i32 0, i32 1
  %15 = getelementptr { { i32, i32 }, ptr }, ptr %0, i64 0, i32 1
  %16 = getelementptr { { i32, i32 }, ptr }, ptr %0, i64 0, i32 0, i32 1
  %17 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 16, i32 1
  %18 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 16, i32 0, i32 1
  %wide.trip.count = zext i32 %2 to i64
  %xtraiter = and i64 %wide.trip.count, 1
  %19 = icmp eq i32 %2, 1
  br i1 %19, label %after_if.loopexit.unr-lcssa, label %for_loop_body.lr.ph.new

for_loop_body.lr.ph.new:                          ; preds = %for_loop_body.lr.ph
  %20 = lshr i64 %wide.trip.count, 1
  %21 = mul nsw i64 %20, -2
  br label %for_loop_body

true_block:                                       ; preds = %entry
  %22 = getelementptr { { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, i32, double, i32, double, { { i32, i32 }, ptr }, { { i32, i32 }, ptr } }, ptr %0, i64 0, i32 14, i32 1
  %23 = load ptr, ptr %22, align 8
  store i64 0, ptr %23, align 8
  %24 = load ptr, ptr %22, align 8
  %25 = getelementptr i64, ptr %24, i64 1
  store i64 0, ptr %25, align 8
  %26 = load ptr, ptr %22, align 8
  %27 = getelementptr i64, ptr %26, i64 2
  store i64 0, ptr %27, align 8
  %28 = load ptr, ptr %22, align 8
  %29 = getelementptr i64, ptr %28, i64 3
  store i64 0, ptr %29, align 8
  %30 = load ptr, ptr %22, align 8
  %31 = getelementptr i64, ptr %30, i64 4
  store i64 0, ptr %31, align 8
  %32 = load ptr, ptr %22, align 8
  %33 = getelementptr i64, ptr %32, i64 5
  store i64 0, ptr %33, align 8
  %34 = load ptr, ptr %22, align 8
  %35 = getelementptr i64, ptr %34, i64 6
  store i64 0, ptr %35, align 8
  %36 = load ptr, ptr %22, align 8
  %37 = getelementptr i64, ptr %36, i64 7
  store i64 0, ptr %37, align 8
  %38 = load ptr, ptr %22, align 8
  %39 = getelementptr i64, ptr %38, i64 8
  store i64 0, ptr %39, align 8
  %40 = load ptr, ptr %22, align 8
  %41 = getelementptr i64, ptr %40, i64 9
  store i64 0, ptr %41, align 8
  br label %after_if

after_if.loopexit.unr-lcssa.loopexit:             ; preds = %for_loop_body
  %42 = add i64 %lsr.iv.next, -1
  br label %after_if.loopexit.unr-lcssa

after_if.loopexit.unr-lcssa:                      ; preds = %after_if.loopexit.unr-lcssa.loopexit, %for_loop_body.lr.ph
  %indvars.iv.unr = phi i64 [ 0, %for_loop_body.lr.ph ], [ %42, %after_if.loopexit.unr-lcssa.loopexit ]
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %after_if, label %for_loop_body.epil

for_loop_body.epil:                               ; preds = %after_if.loopexit.unr-lcssa
  %43 = load ptr, ptr %7, align 8
  %44 = load i32, ptr %8, align 4
  %45 = sext i32 %44 to i64
  %46 = mul nsw i64 %45, 5
  %47 = add nsw i64 %46, %indvars.iv.unr
  %48 = getelementptr i32, ptr %43, i64 %47
  %49 = load i32, ptr %48, align 4
  %50 = load ptr, ptr %9, align 8
  %51 = sext i32 %49 to i64
  %52 = getelementptr i32, ptr %50, i64 %51
  store i32 0, ptr %52, align 4
  %53 = load ptr, ptr %9, align 8
  %54 = load i32, ptr %10, align 4
  %55 = sext i32 %54 to i64
  %56 = add nsw i64 %55, %51
  %57 = getelementptr i32, ptr %53, i64 %56
  store i32 0, ptr %57, align 4
  %58 = load ptr, ptr %11, align 8
  %59 = load i32, ptr %12, align 4
  %60 = sext i32 %59 to i64
  %61 = shl nsw i64 %60, 2
  %62 = add nsw i64 %61, %51
  %63 = getelementptr double, ptr %58, i64 %62
  store double 0.000000e+00, ptr %63, align 8
  %64 = load ptr, ptr %11, align 8
  %65 = load i32, ptr %12, align 4
  %66 = sext i32 %65 to i64
  %67 = mul nsw i64 %66, 5
  %68 = add nsw i64 %67, %51
  %69 = getelementptr double, ptr %64, i64 %68
  store double 0.000000e+00, ptr %69, align 8
  %70 = load ptr, ptr %11, align 8
  %71 = load i32, ptr %12, align 4
  %72 = sext i32 %71 to i64
  %73 = mul nsw i64 %72, 6
  %74 = add nsw i64 %73, %51
  %75 = getelementptr double, ptr %70, i64 %74
  store double 0.000000e+00, ptr %75, align 8
  %76 = load ptr, ptr %11, align 8
  %77 = load i32, ptr %12, align 4
  %78 = sext i32 %77 to i64
  %79 = mul nsw i64 %78, 7
  %80 = add nsw i64 %79, %51
  %81 = getelementptr double, ptr %76, i64 %80
  store double 0.000000e+00, ptr %81, align 8
  %82 = load ptr, ptr %11, align 8
  %83 = getelementptr double, ptr %82, i64 %51
  %84 = load double, ptr %83, align 8
  %85 = load ptr, ptr %13, align 8
  %86 = getelementptr double, ptr %85, i64 %indvars.iv.unr
  store double %84, ptr %86, align 8
  %87 = load ptr, ptr %15, align 8
  %88 = getelementptr double, ptr %87, i64 %indvars.iv.unr
  %89 = load double, ptr %88, align 8
  store double %89, ptr %83, align 8
  %90 = load ptr, ptr %17, align 8
  %91 = load i32, ptr %18, align 4
  %92 = sext i32 %91 to i64
  %93 = mul nsw i64 %92, 3
  %94 = add nsw i64 %93, %51
  %95 = getelementptr double, ptr %90, i64 %94
  store double %84, ptr %95, align 8
  %96 = load ptr, ptr %17, align 8
  %97 = getelementptr double, ptr %96, i64 %51
  store double 0.000000e+00, ptr %97, align 8
  %98 = load ptr, ptr %11, align 8
  %99 = load i32, ptr %12, align 4
  %100 = sext i32 %99 to i64
  %101 = add nsw i64 %100, %51
  %102 = getelementptr double, ptr %98, i64 %101
  %103 = load double, ptr %102, align 8
  %104 = load ptr, ptr %13, align 8
  %105 = load i32, ptr %14, align 4
  %106 = sext i32 %105 to i64
  %107 = add nsw i64 %indvars.iv.unr, %106
  %108 = getelementptr double, ptr %104, i64 %107
  store double %103, ptr %108, align 8
  %109 = load ptr, ptr %15, align 8
  %110 = load i32, ptr %16, align 4
  %111 = sext i32 %110 to i64
  %112 = add nsw i64 %indvars.iv.unr, %111
  %113 = getelementptr double, ptr %109, i64 %112
  %114 = load double, ptr %113, align 8
  store double %114, ptr %102, align 8
  %115 = load ptr, ptr %17, align 8
  %116 = load i32, ptr %18, align 4
  %117 = sext i32 %116 to i64
  %118 = shl nsw i64 %117, 2
  %119 = add nsw i64 %118, %51
  %120 = getelementptr double, ptr %115, i64 %119
  store double %103, ptr %120, align 8
  %121 = load ptr, ptr %17, align 8
  %122 = load i32, ptr %18, align 4
  %123 = sext i32 %122 to i64
  %124 = add nsw i64 %123, %51
  %125 = getelementptr double, ptr %121, i64 %124
  store double 0.000000e+00, ptr %125, align 8
  %126 = load ptr, ptr %11, align 8
  %127 = load i32, ptr %12, align 4
  %128 = sext i32 %127 to i64
  %129 = shl nsw i64 %128, 1
  %130 = add nsw i64 %129, %51
  %131 = getelementptr double, ptr %126, i64 %130
  %132 = load double, ptr %131, align 8
  %133 = load ptr, ptr %13, align 8
  %134 = load i32, ptr %14, align 4
  %135 = sext i32 %134 to i64
  %136 = shl nsw i64 %135, 1
  %137 = add nsw i64 %136, %indvars.iv.unr
  %138 = getelementptr double, ptr %133, i64 %137
  store double %132, ptr %138, align 8
  %139 = load ptr, ptr %15, align 8
  %140 = load i32, ptr %16, align 4
  %141 = sext i32 %140 to i64
  %142 = shl nsw i64 %141, 1
  %143 = add nsw i64 %142, %indvars.iv.unr
  %144 = getelementptr double, ptr %139, i64 %143
  %145 = load double, ptr %144, align 8
  store double %145, ptr %131, align 8
  %146 = load ptr, ptr %17, align 8
  %147 = load i32, ptr %18, align 4
  %148 = sext i32 %147 to i64
  %149 = mul nsw i64 %148, 5
  %150 = add nsw i64 %149, %51
  %151 = getelementptr double, ptr %146, i64 %150
  store double %132, ptr %151, align 8
  %152 = load ptr, ptr %17, align 8
  %153 = load i32, ptr %18, align 4
  %154 = sext i32 %153 to i64
  %155 = shl nsw i64 %154, 1
  %156 = add nsw i64 %155, %51
  %157 = getelementptr double, ptr %152, i64 %156
  store double 0.000000e+00, ptr %157, align 8
  %158 = load ptr, ptr %11, align 8
  %159 = load i32, ptr %12, align 4
  %160 = sext i32 %159 to i64
  %161 = mul nsw i64 %160, 3
  %162 = add nsw i64 %161, %51
  %163 = getelementptr double, ptr %158, i64 %162
  %164 = load double, ptr %163, align 8
  %165 = load ptr, ptr %13, align 8
  %166 = load i32, ptr %14, align 4
  %167 = sext i32 %166 to i64
  %168 = mul nsw i64 %167, 3
  %169 = add nsw i64 %168, %indvars.iv.unr
  %170 = getelementptr double, ptr %165, i64 %169
  store double %164, ptr %170, align 8
  %171 = load ptr, ptr %15, align 8
  %172 = load i32, ptr %16, align 4
  %173 = sext i32 %172 to i64
  %174 = mul nsw i64 %173, 3
  %175 = add nsw i64 %174, %indvars.iv.unr
  %176 = getelementptr double, ptr %171, i64 %175
  %177 = load double, ptr %176, align 8
  store double %177, ptr %163, align 8
  br label %after_if

after_if:                                         ; preds = %for_loop_body.epil, %after_if.loopexit.unr-lcssa, %true_block, %for_loop_test.preheader
  ret void

for_loop_body:                                    ; preds = %for_loop_body, %for_loop_body.lr.ph.new
  %lsr.iv = phi i64 [ %lsr.iv.next, %for_loop_body ], [ 1, %for_loop_body.lr.ph.new ]
  %178 = load ptr, ptr %7, align 8
  %179 = load i32, ptr %8, align 4
  %180 = sext i32 %179 to i64
  %181 = mul nsw i64 %180, 20
  %uglygep32 = getelementptr i8, ptr %178, i64 %181
  %182 = shl i64 %lsr.iv, 2
  %uglygep33 = getelementptr i8, ptr %uglygep32, i64 %182
  %uglygep34 = getelementptr i8, ptr %uglygep33, i64 -4
  %183 = load i32, ptr %uglygep34, align 4
  %184 = load ptr, ptr %9, align 8
  %185 = sext i32 %183 to i64
  %186 = getelementptr i32, ptr %184, i64 %185
  store i32 0, ptr %186, align 4
  %187 = load ptr, ptr %9, align 8
  %188 = load i32, ptr %10, align 4
  %189 = sext i32 %188 to i64
  %190 = add nsw i64 %189, %185
  %191 = getelementptr i32, ptr %187, i64 %190
  store i32 0, ptr %191, align 4
  %192 = load ptr, ptr %11, align 8
  %193 = load i32, ptr %12, align 4
  %194 = sext i32 %193 to i64
  %195 = shl nsw i64 %194, 2
  %196 = add nsw i64 %195, %185
  %197 = getelementptr double, ptr %192, i64 %196
  store double 0.000000e+00, ptr %197, align 8
  %198 = load ptr, ptr %11, align 8
  %199 = load i32, ptr %12, align 4
  %200 = sext i32 %199 to i64
  %201 = mul nsw i64 %200, 5
  %202 = add nsw i64 %201, %185
  %203 = getelementptr double, ptr %198, i64 %202
  store double 0.000000e+00, ptr %203, align 8
  %204 = load ptr, ptr %11, align 8
  %205 = load i32, ptr %12, align 4
  %206 = sext i32 %205 to i64
  %207 = mul nsw i64 %206, 6
  %208 = add nsw i64 %207, %185
  %209 = getelementptr double, ptr %204, i64 %208
  store double 0.000000e+00, ptr %209, align 8
  %210 = load ptr, ptr %11, align 8
  %211 = load i32, ptr %12, align 4
  %212 = sext i32 %211 to i64
  %213 = mul nsw i64 %212, 7
  %214 = add nsw i64 %213, %185
  %215 = getelementptr double, ptr %210, i64 %214
  store double 0.000000e+00, ptr %215, align 8
  %216 = load ptr, ptr %11, align 8
  %217 = getelementptr double, ptr %216, i64 %185
  %218 = load double, ptr %217, align 8
  %219 = load ptr, ptr %13, align 8
  %220 = shl i64 %lsr.iv, 3
  %uglygep30 = getelementptr i8, ptr %219, i64 %220
  %uglygep31 = getelementptr i8, ptr %uglygep30, i64 -8
  store double %218, ptr %uglygep31, align 8
  %221 = load ptr, ptr %15, align 8
  %uglygep28 = getelementptr i8, ptr %221, i64 %220
  %uglygep29 = getelementptr i8, ptr %uglygep28, i64 -8
  %222 = load double, ptr %uglygep29, align 8
  store double %222, ptr %217, align 8
  %223 = load ptr, ptr %17, align 8
  %224 = load i32, ptr %18, align 4
  %225 = sext i32 %224 to i64
  %226 = mul nsw i64 %225, 3
  %227 = add nsw i64 %226, %185
  %228 = getelementptr double, ptr %223, i64 %227
  store double %218, ptr %228, align 8
  %229 = load ptr, ptr %17, align 8
  %230 = getelementptr double, ptr %229, i64 %185
  store double 0.000000e+00, ptr %230, align 8
  %231 = load ptr, ptr %11, align 8
  %232 = load i32, ptr %12, align 4
  %233 = sext i32 %232 to i64
  %234 = add nsw i64 %233, %185
  %235 = getelementptr double, ptr %231, i64 %234
  %236 = load double, ptr %235, align 8
  %237 = load ptr, ptr %13, align 8
  %238 = load i32, ptr %14, align 4
  %239 = sext i32 %238 to i64
  %240 = add i64 %lsr.iv, %239
  %241 = getelementptr double, ptr %237, i64 %240
  %242 = getelementptr double, ptr %241, i64 -1
  store double %236, ptr %242, align 8
  %243 = load ptr, ptr %15, align 8
  %244 = load i32, ptr %16, align 4
  %245 = sext i32 %244 to i64
  %246 = add i64 %lsr.iv, %245
  %247 = getelementptr double, ptr %243, i64 %246
  %248 = getelementptr double, ptr %247, i64 -1
  %249 = load double, ptr %248, align 8
  store double %249, ptr %235, align 8
  %250 = load ptr, ptr %17, align 8
  %251 = load i32, ptr %18, align 4
  %252 = sext i32 %251 to i64
  %253 = shl nsw i64 %252, 2
  %254 = add nsw i64 %253, %185
  %255 = getelementptr double, ptr %250, i64 %254
  store double %236, ptr %255, align 8
  %256 = load ptr, ptr %17, align 8
  %257 = load i32, ptr %18, align 4
  %258 = sext i32 %257 to i64
  %259 = add nsw i64 %258, %185
  %260 = getelementptr double, ptr %256, i64 %259
  store double 0.000000e+00, ptr %260, align 8
  %261 = load ptr, ptr %11, align 8
  %262 = load i32, ptr %12, align 4
  %263 = sext i32 %262 to i64
  %264 = shl nsw i64 %263, 1
  %265 = add nsw i64 %264, %185
  %266 = getelementptr double, ptr %261, i64 %265
  %267 = load double, ptr %266, align 8
  %268 = load ptr, ptr %13, align 8
  %269 = load i32, ptr %14, align 4
  %270 = sext i32 %269 to i64
  %271 = shl nsw i64 %270, 4
  %uglygep25 = getelementptr i8, ptr %268, i64 %271
  %uglygep26 = getelementptr i8, ptr %uglygep25, i64 %220
  %uglygep27 = getelementptr i8, ptr %uglygep26, i64 -8
  store double %267, ptr %uglygep27, align 8
  %272 = load ptr, ptr %15, align 8
  %273 = load i32, ptr %16, align 4
  %274 = sext i32 %273 to i64
  %275 = shl nsw i64 %274, 4
  %uglygep22 = getelementptr i8, ptr %272, i64 %275
  %uglygep23 = getelementptr i8, ptr %uglygep22, i64 %220
  %uglygep24 = getelementptr i8, ptr %uglygep23, i64 -8
  %276 = load double, ptr %uglygep24, align 8
  store double %276, ptr %266, align 8
  %277 = load ptr, ptr %17, align 8
  %278 = load i32, ptr %18, align 4
  %279 = sext i32 %278 to i64
  %280 = mul nsw i64 %279, 5
  %281 = add nsw i64 %280, %185
  %282 = getelementptr double, ptr %277, i64 %281
  store double %267, ptr %282, align 8
  %283 = load ptr, ptr %17, align 8
  %284 = load i32, ptr %18, align 4
  %285 = sext i32 %284 to i64
  %286 = shl nsw i64 %285, 1
  %287 = add nsw i64 %286, %185
  %288 = getelementptr double, ptr %283, i64 %287
  store double 0.000000e+00, ptr %288, align 8
  %289 = load ptr, ptr %11, align 8
  %290 = load i32, ptr %12, align 4
  %291 = sext i32 %290 to i64
  %292 = mul nsw i64 %291, 3
  %293 = add nsw i64 %292, %185
  %294 = getelementptr double, ptr %289, i64 %293
  %295 = load double, ptr %294, align 8
  %296 = load ptr, ptr %13, align 8
  %297 = load i32, ptr %14, align 4
  %298 = sext i32 %297 to i64
  %299 = mul nsw i64 %298, 24
  %uglygep19 = getelementptr i8, ptr %296, i64 %299
  %uglygep20 = getelementptr i8, ptr %uglygep19, i64 %220
  %uglygep21 = getelementptr i8, ptr %uglygep20, i64 -8
  store double %295, ptr %uglygep21, align 8
  %300 = load ptr, ptr %15, align 8
  %301 = load i32, ptr %16, align 4
  %302 = sext i32 %301 to i64
  %303 = mul nsw i64 %302, 24
  %uglygep16 = getelementptr i8, ptr %300, i64 %303
  %uglygep17 = getelementptr i8, ptr %uglygep16, i64 %220
  %uglygep18 = getelementptr i8, ptr %uglygep17, i64 -8
  %304 = load double, ptr %uglygep18, align 8
  store double %304, ptr %294, align 8
  %305 = load ptr, ptr %7, align 8
  %306 = load i32, ptr %8, align 4
  %307 = sext i32 %306 to i64
  %308 = mul nsw i64 %307, 20
  %uglygep = getelementptr i8, ptr %305, i64 %308
  %uglygep5 = getelementptr i8, ptr %uglygep, i64 %182
  %309 = load i32, ptr %uglygep5, align 4
  %310 = load ptr, ptr %9, align 8
  %311 = sext i32 %309 to i64
  %312 = getelementptr i32, ptr %310, i64 %311
  store i32 0, ptr %312, align 4
  %313 = load ptr, ptr %9, align 8
  %314 = load i32, ptr %10, align 4
  %315 = sext i32 %314 to i64
  %316 = add nsw i64 %315, %311
  %317 = getelementptr i32, ptr %313, i64 %316
  store i32 0, ptr %317, align 4
  %318 = load ptr, ptr %11, align 8
  %319 = load i32, ptr %12, align 4
  %320 = sext i32 %319 to i64
  %321 = shl nsw i64 %320, 2
  %322 = add nsw i64 %321, %311
  %323 = getelementptr double, ptr %318, i64 %322
  store double 0.000000e+00, ptr %323, align 8
  %324 = load ptr, ptr %11, align 8
  %325 = load i32, ptr %12, align 4
  %326 = sext i32 %325 to i64
  %327 = mul nsw i64 %326, 5
  %328 = add nsw i64 %327, %311
  %329 = getelementptr double, ptr %324, i64 %328
  store double 0.000000e+00, ptr %329, align 8
  %330 = load ptr, ptr %11, align 8
  %331 = load i32, ptr %12, align 4
  %332 = sext i32 %331 to i64
  %333 = mul nsw i64 %332, 6
  %334 = add nsw i64 %333, %311
  %335 = getelementptr double, ptr %330, i64 %334
  store double 0.000000e+00, ptr %335, align 8
  %336 = load ptr, ptr %11, align 8
  %337 = load i32, ptr %12, align 4
  %338 = sext i32 %337 to i64
  %339 = mul nsw i64 %338, 7
  %340 = add nsw i64 %339, %311
  %341 = getelementptr double, ptr %336, i64 %340
  store double 0.000000e+00, ptr %341, align 8
  %342 = load ptr, ptr %11, align 8
  %343 = getelementptr double, ptr %342, i64 %311
  %344 = load double, ptr %343, align 8
  %345 = load ptr, ptr %13, align 8
  %uglygep6 = getelementptr i8, ptr %345, i64 %220
  store double %344, ptr %uglygep6, align 8
  %346 = load ptr, ptr %15, align 8
  %uglygep7 = getelementptr i8, ptr %346, i64 %220
  %347 = load double, ptr %uglygep7, align 8
  store double %347, ptr %343, align 8
  %348 = load ptr, ptr %17, align 8
  %349 = load i32, ptr %18, align 4
  %350 = sext i32 %349 to i64
  %351 = mul nsw i64 %350, 3
  %352 = add nsw i64 %351, %311
  %353 = getelementptr double, ptr %348, i64 %352
  store double %344, ptr %353, align 8
  %354 = load ptr, ptr %17, align 8
  %355 = getelementptr double, ptr %354, i64 %311
  store double 0.000000e+00, ptr %355, align 8
  %356 = load ptr, ptr %11, align 8
  %357 = load i32, ptr %12, align 4
  %358 = sext i32 %357 to i64
  %359 = add nsw i64 %358, %311
  %360 = getelementptr double, ptr %356, i64 %359
  %361 = load double, ptr %360, align 8
  %362 = load ptr, ptr %13, align 8
  %363 = load i32, ptr %14, align 4
  %364 = sext i32 %363 to i64
  %365 = add nsw i64 %lsr.iv, %364
  %366 = getelementptr double, ptr %362, i64 %365
  store double %361, ptr %366, align 8
  %367 = load ptr, ptr %15, align 8
  %368 = load i32, ptr %16, align 4
  %369 = sext i32 %368 to i64
  %370 = add nsw i64 %lsr.iv, %369
  %371 = getelementptr double, ptr %367, i64 %370
  %372 = load double, ptr %371, align 8
  store double %372, ptr %360, align 8
  %373 = load ptr, ptr %17, align 8
  %374 = load i32, ptr %18, align 4
  %375 = sext i32 %374 to i64
  %376 = shl nsw i64 %375, 2
  %377 = add nsw i64 %376, %311
  %378 = getelementptr double, ptr %373, i64 %377
  store double %361, ptr %378, align 8
  %379 = load ptr, ptr %17, align 8
  %380 = load i32, ptr %18, align 4
  %381 = sext i32 %380 to i64
  %382 = add nsw i64 %381, %311
  %383 = getelementptr double, ptr %379, i64 %382
  store double 0.000000e+00, ptr %383, align 8
  %384 = load ptr, ptr %11, align 8
  %385 = load i32, ptr %12, align 4
  %386 = sext i32 %385 to i64
  %387 = shl nsw i64 %386, 1
  %388 = add nsw i64 %387, %311
  %389 = getelementptr double, ptr %384, i64 %388
  %390 = load double, ptr %389, align 8
  %391 = load ptr, ptr %13, align 8
  %392 = load i32, ptr %14, align 4
  %393 = sext i32 %392 to i64
  %394 = shl nsw i64 %393, 4
  %uglygep8 = getelementptr i8, ptr %391, i64 %394
  %uglygep9 = getelementptr i8, ptr %uglygep8, i64 %220
  store double %390, ptr %uglygep9, align 8
  %395 = load ptr, ptr %15, align 8
  %396 = load i32, ptr %16, align 4
  %397 = sext i32 %396 to i64
  %398 = shl nsw i64 %397, 4
  %uglygep10 = getelementptr i8, ptr %395, i64 %398
  %uglygep11 = getelementptr i8, ptr %uglygep10, i64 %220
  %399 = load double, ptr %uglygep11, align 8
  store double %399, ptr %389, align 8
  %400 = load ptr, ptr %17, align 8
  %401 = load i32, ptr %18, align 4
  %402 = sext i32 %401 to i64
  %403 = mul nsw i64 %402, 5
  %404 = add nsw i64 %403, %311
  %405 = getelementptr double, ptr %400, i64 %404
  store double %390, ptr %405, align 8
  %406 = load ptr, ptr %17, align 8
  %407 = load i32, ptr %18, align 4
  %408 = sext i32 %407 to i64
  %409 = shl nsw i64 %408, 1
  %410 = add nsw i64 %409, %311
  %411 = getelementptr double, ptr %406, i64 %410
  store double 0.000000e+00, ptr %411, align 8
  %412 = load ptr, ptr %11, align 8
  %413 = load i32, ptr %12, align 4
  %414 = sext i32 %413 to i64
  %415 = mul nsw i64 %414, 3
  %416 = add nsw i64 %415, %311
  %417 = getelementptr double, ptr %412, i64 %416
  %418 = load double, ptr %417, align 8
  %419 = load ptr, ptr %13, align 8
  %420 = load i32, ptr %14, align 4
  %421 = sext i32 %420 to i64
  %422 = mul nsw i64 %421, 24
  %uglygep12 = getelementptr i8, ptr %419, i64 %422
  %uglygep13 = getelementptr i8, ptr %uglygep12, i64 %220
  store double %418, ptr %uglygep13, align 8
  %423 = load ptr, ptr %15, align 8
  %424 = load i32, ptr %16, align 4
  %425 = sext i32 %424 to i64
  %426 = mul nsw i64 %425, 24
  %uglygep14 = getelementptr i8, ptr %423, i64 %426
  %uglygep15 = getelementptr i8, ptr %uglygep14, i64 %220
  %427 = load double, ptr %uglygep15, align 8
  store double %427, ptr %417, align 8
  %lsr.iv.next = add nuw i64 %lsr.iv, 2
  %428 = add i64 %21, %lsr.iv.next
  %niter.ncmp.1 = icmp eq i64 %428, 1
  br i1 %niter.ncmp.1, label %after_if.loopexit.unr-lcssa.loopexit, label %for_loop_body
}

attributes #0 = { nofree norecurse nosync nounwind }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
