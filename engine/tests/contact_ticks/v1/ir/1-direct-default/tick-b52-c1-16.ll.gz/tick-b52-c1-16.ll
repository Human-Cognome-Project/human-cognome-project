; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree nosync nounwind
define void @geometry_discover_35_selection_55_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %0, i64 0, i32 8
  %2 = load i32, ptr %1, align 4
  %3 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %0, i64 0, i32 7, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = load i64, ptr %4, align 8
  %6 = trunc i64 %5 to i32
  %7 = icmp sgt i32 %6, 0
  br i1 %7, label %for_loop_body.lr.ph, label %after_for

for_loop_body.lr.ph:                              ; preds = %entry
  %8 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %0, i64 0, i32 2, i32 1
  %9 = getelementptr { { i32, i32 }, ptr }, ptr %0, i64 0, i32 1
  %10 = getelementptr { { i32, i32 }, ptr }, ptr %0, i64 0, i32 0, i32 1
  %11 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %0, i64 0, i32 3, i32 1
  %12 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %0, i64 0, i32 1, i32 1
  %13 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %0, i64 0, i32 1, i32 0, i32 1
  %14 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %0, i64 0, i32 5, i32 1
  %15 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %0, i64 0, i32 5, i32 0, i32 1
  %16 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %0, i64 0, i32 4, i32 1
  %17 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32 }, ptr }, i32 }, ptr %0, i64 0, i32 6, i32 1
  %sext73 = shl i64 %5, 32
  %18 = ashr exact i64 %sext73, 32
  %wide.trip.count71 = and i64 %5, 4294967295
  br label %for_loop_body

for_loop_body:                                    ; preds = %for_loop_test.loopexit, %for_loop_body.lr.ph
  %indvars.iv68 = phi i64 [ 0, %for_loop_body.lr.ph ], [ %indvars.iv.next69, %for_loop_test.loopexit ]
  %indvars.iv62 = phi i64 [ 1, %for_loop_body.lr.ph ], [ %indvars.iv.next63, %for_loop_test.loopexit ]
  %.02758 = phi i32 [ 0, %for_loop_body.lr.ph ], [ %.1.lcssa, %for_loop_test.loopexit ]
  %indvars.iv.next69 = add nuw nsw i64 %indvars.iv68, 1
  %19 = load ptr, ptr %8, align 8
  %20 = getelementptr i32, ptr %19, i64 %indvars.iv68
  %21 = load i32, ptr %20, align 4
  %22 = load ptr, ptr %9, align 8
  %23 = load i32, ptr %10, align 4
  %24 = sext i32 %23 to i64
  %25 = sext i32 %21 to i64
  %26 = getelementptr double, ptr %22, i64 %25
  %27 = add nsw i64 %24, %25
  %28 = getelementptr double, ptr %22, i64 %27
  %29 = shl nsw i64 %24, 1
  %30 = add nsw i64 %29, %25
  %31 = getelementptr double, ptr %22, i64 %30
  %32 = mul nsw i64 %24, 7
  %33 = add nsw i64 %32, %25
  %34 = getelementptr double, ptr %22, i64 %33
  %35 = icmp slt i64 %indvars.iv.next69, %18
  br i1 %35, label %for_loop_body1.lr.ph, label %for_loop_test.loopexit

for_loop_body1.lr.ph:                             ; preds = %for_loop_body
  %36 = shl nsw i64 %25, 32
  br label %for_loop_body1

after_for.loopexit:                               ; preds = %for_loop_test.loopexit
  br label %after_for

after_for:                                        ; preds = %after_for.loopexit, %entry
  %.027.lcssa = phi i32 [ 0, %entry ], [ %.1.lcssa, %after_for.loopexit ]
  %.not = icmp eq i32 %.027.lcssa, %2
  br i1 %.not, label %after_if38, label %true_block36

for_loop_test.loopexit.loopexit:                  ; preds = %after_if19
  br label %for_loop_test.loopexit

for_loop_test.loopexit:                           ; preds = %for_loop_test.loopexit.loopexit, %for_loop_body
  %.1.lcssa = phi i32 [ %.02758, %for_loop_body ], [ %.02238, %for_loop_test.loopexit.loopexit ]
  %indvars.iv.next63 = add nuw nsw i64 %indvars.iv62, 1
  %exitcond72.not = icmp eq i64 %indvars.iv.next69, %wide.trip.count71
  br i1 %exitcond72.not, label %after_for.loopexit, label %for_loop_body

for_loop_body1:                                   ; preds = %after_if19, %for_loop_body1.lr.ph
  %indvars.iv64 = phi i64 [ %indvars.iv62, %for_loop_body1.lr.ph ], [ %indvars.iv.next65, %after_if19 ]
  %.156 = phi i32 [ %.02758, %for_loop_body1.lr.ph ], [ %.02238, %after_if19 ]
  %37 = load ptr, ptr %8, align 8
  %38 = getelementptr i32, ptr %37, i64 %indvars.iv64
  %39 = load i32, ptr %38, align 4
  %40 = load ptr, ptr %9, align 8
  %41 = load i32, ptr %10, align 4
  %42 = sext i32 %41 to i64
  %43 = sext i32 %39 to i64
  %44 = getelementptr double, ptr %40, i64 %43
  %45 = load double, ptr %44, align 8
  %46 = load double, ptr %26, align 8
  %47 = fsub double %45, %46
  %48 = add nsw i64 %42, %43
  %49 = getelementptr double, ptr %40, i64 %48
  %50 = load double, ptr %49, align 8
  %51 = load double, ptr %28, align 8
  %52 = fsub double %50, %51
  %53 = shl nsw i64 %42, 1
  %54 = add nsw i64 %53, %43
  %55 = getelementptr double, ptr %40, i64 %54
  %56 = load double, ptr %55, align 8
  %57 = load double, ptr %31, align 8
  %58 = fsub double %56, %57
  %59 = load double, ptr %34, align 8
  %60 = mul nsw i64 %42, 7
  %61 = add nsw i64 %60, %43
  %62 = getelementptr double, ptr %40, i64 %61
  %63 = load double, ptr %62, align 8
  %64 = fmul double %47, %47
  %65 = fmul double %52, %52
  %66 = fadd double %64, %65
  %67 = fmul double %58, %58
  %68 = fadd double %66, %67
  %69 = fcmp ogt double %68, 0.000000e+00
  %70 = select i1 %69, double 0.000000e+00, double 1.000000e+00
  %71 = fadd double %68, %70
  %sqrt = tail call double @llvm.sqrt.f64(double %71)
  %72 = fdiv double 1.000000e+00, %sqrt
  %73 = fmul double %71, %72
  %74 = fadd double %59, %63
  %75 = fsub double %74, %73
  %76 = tail call double @llvm.maxnum.f64(double %75, double 0.000000e+00)
  %77 = bitcast double %68 to i64
  %78 = and i64 %77, 9223372036854775807
  %79 = and i64 %77, 9218868437227405312
  %80 = icmp eq i64 %78, 0
  %81 = icmp ne i64 %79, 0
  %82 = icmp ne i64 %79, 9218868437227405312
  %83 = and i1 %81, %82
  %84 = or i1 %80, %83
  br i1 %84, label %after_if, label %true_block

true_block:                                       ; preds = %for_loop_body1
  %85 = load ptr, ptr %3, align 8
  %86 = getelementptr i64, ptr %85, i64 5
  %87 = load i64, ptr %86, align 8
  %88 = or i64 %87, 1
  store i64 %88, ptr %86, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %for_loop_body1
  %89 = bitcast double %74 to i64
  %90 = and i64 %89, 9223372036854775807
  %91 = and i64 %89, 9218868437227405312
  %92 = icmp eq i64 %90, 0
  %93 = icmp ne i64 %91, 0
  %94 = icmp ne i64 %91, 9218868437227405312
  %95 = and i1 %93, %94
  %96 = or i1 %92, %95
  br i1 %96, label %after_if7, label %true_block5

true_block5:                                      ; preds = %after_if
  %97 = load ptr, ptr %3, align 8
  %98 = getelementptr i64, ptr %97, i64 5
  %99 = load i64, ptr %98, align 8
  %100 = or i64 %99, 1
  store i64 %100, ptr %98, align 8
  br label %after_if7

after_if7:                                        ; preds = %true_block5, %after_if
  %101 = bitcast double %73 to i64
  %102 = and i64 %101, 9223372036854775807
  %103 = and i64 %101, 9218868437227405312
  %104 = icmp eq i64 %102, 0
  %105 = icmp ne i64 %103, 0
  %106 = icmp ne i64 %103, 9218868437227405312
  %107 = and i1 %105, %106
  %108 = or i1 %104, %107
  br i1 %108, label %after_if10, label %true_block8

true_block8:                                      ; preds = %after_if7
  %109 = load ptr, ptr %3, align 8
  %110 = getelementptr i64, ptr %109, i64 5
  %111 = load i64, ptr %110, align 8
  %112 = or i64 %111, 1
  store i64 %112, ptr %110, align 8
  br label %after_if10

after_if10:                                       ; preds = %true_block8, %after_if7
  %113 = fcmp ogt double %76, 0.000000e+00
  %114 = fcmp oeq double %68, 0.000000e+00
  %115 = fcmp ogt double %74, 0.000000e+00
  %116 = and i1 %114, %115
  %117 = or i1 %116, %113
  %118 = icmp slt i32 %.156, %2
  br i1 %118, label %true_block11, label %after_if13

true_block11:                                     ; preds = %after_if10
  %119 = load ptr, ptr %11, align 8
  %120 = sext i32 %.156 to i64
  %121 = getelementptr i32, ptr %119, i64 %120
  %122 = load i32, ptr %121, align 4
  %123 = add i64 %36, %43
  %124 = load ptr, ptr %12, align 8
  %125 = load i32, ptr %13, align 4
  %126 = sext i32 %125 to i64
  %127 = sext i32 %122 to i64
  %128 = getelementptr i32, ptr %124, i64 %127
  %129 = load i32, ptr %128, align 4
  %130 = add nsw i64 %126, %127
  %131 = getelementptr i32, ptr %124, i64 %130
  %132 = load i32, ptr %131, align 4
  %133 = tail call i32 @llvm.smin.i32(i32 %129, i32 %132)
  %134 = zext i32 %133 to i64
  %135 = shl nuw i64 %134, 32
  %136 = tail call i32 @llvm.smax.i32(i32 %129, i32 %132)
  %137 = sext i32 %136 to i64
  %138 = add i64 %135, %137
  %139 = icmp eq i64 %138, %123
  br i1 %139, label %true_block17.thread, label %after_if13

after_if13:                                       ; preds = %true_block11, %after_if10
  br i1 %117, label %true_block17, label %after_if19

true_block17:                                     ; preds = %after_if13
  %140 = load ptr, ptr %3, align 8
  %141 = getelementptr i64, ptr %140, i64 3
  %142 = load i64, ptr %141, align 8
  %143 = icmp slt i64 %142, 1
  br i1 %143, label %false_block24, label %true_block30.thread

true_block30.thread:                              ; preds = %true_block17
  %144 = add nuw i64 %142, 1
  store i64 %144, ptr %141, align 8
  br label %after_if19.sink.split

true_block17.thread:                              ; preds = %true_block11
  %145 = load ptr, ptr %16, align 8
  %146 = getelementptr i32, ptr %145, i64 %120
  %147 = load i32, ptr %146, align 4
  %148 = load ptr, ptr %3, align 8
  %149 = getelementptr i64, ptr %148, i64 3
  %150 = load i64, ptr %149, align 8
  %151 = icmp slt i64 %150, 1
  br i1 %151, label %true_block23, label %after_if22

after_if19.sink.split:                            ; preds = %after_if32, %true_block30, %true_block30.thread
  %.sink89 = phi i64 [ 4, %true_block30.thread ], [ 7, %true_block30 ], [ 7, %after_if32 ]
  %.02238.ph = phi i32 [ %.156, %true_block30.thread ], [ %.0223743, %true_block30 ], [ %.0223743, %after_if32 ]
  %152 = load ptr, ptr %3, align 8
  %153 = getelementptr i64, ptr %152, i64 %.sink89
  %154 = load i64, ptr %153, align 8
  %155 = add i64 %154, 1
  store i64 %155, ptr %153, align 8
  br label %after_if19

after_if19:                                       ; preds = %after_if32, %true_block30, %after_if19.sink.split, %after_if13
  %.02238 = phi i32 [ %.0223743, %after_if32 ], [ %.156, %after_if13 ], [ %.0223743, %true_block30 ], [ %.02238.ph, %after_if19.sink.split ]
  %indvars.iv.next65 = add nuw nsw i64 %indvars.iv64, 1
  %lftr.wideiv106 = trunc i64 %indvars.iv.next65 to i32
  %exitcond = icmp eq i32 %lftr.wideiv106, %6
  br i1 %exitcond, label %for_loop_test.loopexit.loopexit, label %for_loop_body1

after_if22.loopexit:                              ; preds = %for_loop_body26
  br label %after_if22

after_if22:                                       ; preds = %for_loop_body26.prol.loopexit.after_if22_crit_edge, %after_if25.after_if22_crit_edge, %after_if22.loopexit, %true_block17.thread
  %156 = phi i64 [ %150, %true_block17.thread ], [ %174, %after_if25.after_if22_crit_edge ], [ %174, %for_loop_body26.prol.loopexit.after_if22_crit_edge ], [ %174, %after_if22.loopexit ]
  %157 = phi ptr [ %149, %true_block17.thread ], [ %173, %after_if25.after_if22_crit_edge ], [ %173, %for_loop_body26.prol.loopexit.after_if22_crit_edge ], [ %173, %after_if22.loopexit ]
  %158 = phi i1 [ true, %true_block17.thread ], [ %172, %after_if25.after_if22_crit_edge ], [ %172, %for_loop_body26.prol.loopexit.after_if22_crit_edge ], [ %172, %after_if22.loopexit ]
  %.0223743 = phi i32 [ %147, %true_block17.thread ], [ %.022374253, %after_if25.after_if22_crit_edge ], [ %.022374253, %for_loop_body26.prol.loopexit.after_if22_crit_edge ], [ %.022374253, %after_if22.loopexit ]
  %159 = add i64 %156, 1
  store i64 %159, ptr %157, align 8
  br i1 %117, label %true_block30, label %after_if32

true_block23:                                     ; preds = %true_block17.thread
  %160 = load ptr, ptr %14, align 8
  %sext31 = shl i64 %150, 32
  %161 = ashr exact i64 %sext31, 32
  %162 = getelementptr i32, ptr %160, i64 %161
  store i32 %129, ptr %162, align 4
  %163 = load ptr, ptr %12, align 8
  %164 = load i32, ptr %13, align 4
  %165 = sext i32 %164 to i64
  %166 = add nsw i64 %165, %127
  %167 = getelementptr i32, ptr %163, i64 %166
  %168 = load i32, ptr %167, align 4
  br label %after_if25

false_block24:                                    ; preds = %true_block17
  %169 = load ptr, ptr %14, align 8
  %sext = shl i64 %142, 32
  %170 = ashr exact i64 %sext, 32
  %171 = getelementptr i32, ptr %169, i64 %170
  store i32 %21, ptr %171, align 4
  br label %after_if25

after_if25:                                       ; preds = %false_block24, %true_block23
  %.sink85 = phi i64 [ %170, %false_block24 ], [ %161, %true_block23 ]
  %.sink81 = phi i32 [ %39, %false_block24 ], [ %168, %true_block23 ]
  %.022374253 = phi i32 [ %.156, %false_block24 ], [ %147, %true_block23 ]
  %.023364452 = phi i32 [ -1, %false_block24 ], [ %122, %true_block23 ]
  %.024354549 = phi i32 [ 0, %false_block24 ], [ 1, %true_block23 ]
  %172 = phi i1 [ false, %false_block24 ], [ true, %true_block23 ]
  %173 = phi ptr [ %141, %false_block24 ], [ %149, %true_block23 ]
  %174 = phi i64 [ %142, %false_block24 ], [ %150, %true_block23 ]
  %175 = load ptr, ptr %14, align 8
  %176 = load i32, ptr %15, align 4
  %177 = sext i32 %176 to i64
  %178 = add nsw i64 %.sink85, %177
  %179 = getelementptr i32, ptr %175, i64 %178
  store i32 %.sink81, ptr %179, align 4
  %180 = trunc i64 %174 to i32
  %181 = select i1 %117, i32 2, i32 0
  %182 = or i32 %.024354549, %181
  %183 = load ptr, ptr %14, align 8
  %184 = load i32, ptr %15, align 4
  %185 = sext i32 %184 to i64
  %186 = shl nsw i64 %185, 1
  %187 = add nsw i64 %186, %.sink85
  %188 = getelementptr i32, ptr %183, i64 %187
  store i32 %182, ptr %188, align 4
  %189 = load ptr, ptr %14, align 8
  %190 = load i32, ptr %15, align 4
  %191 = sext i32 %190 to i64
  %192 = mul nsw i64 %191, 3
  %193 = add nsw i64 %192, %.sink85
  %194 = getelementptr i32, ptr %189, i64 %193
  store i32 %.023364452, ptr %194, align 4
  %195 = icmp slt i32 %.156, %.022374253
  br i1 %195, label %for_loop_body26.preheader, label %after_if25.after_if22_crit_edge

after_if25.after_if22_crit_edge:                  ; preds = %after_if25
  br label %after_if22

for_loop_body26.preheader:                        ; preds = %after_if25
  %196 = sext i32 %.156 to i64
  %wide.trip.count = sext i32 %.022374253 to i64
  %197 = sub nsw i64 %wide.trip.count, %196
  %198 = xor i64 %196, -1
  %199 = add nsw i64 %198, %wide.trip.count
  %xtraiter = and i64 %197, 7
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body26.prol.loopexit, label %for_loop_body26.prol.preheader

for_loop_body26.prol.preheader:                   ; preds = %for_loop_body26.preheader
  br label %for_loop_body26.prol

for_loop_body26.prol:                             ; preds = %for_loop_body26.prol, %for_loop_body26.prol.preheader
  %lsr.iv = phi i64 [ %xtraiter, %for_loop_body26.prol.preheader ], [ %lsr.iv.next, %for_loop_body26.prol ]
  %indvars.iv.prol = phi i64 [ %indvars.iv.next.prol, %for_loop_body26.prol ], [ %196, %for_loop_body26.prol.preheader ]
  %200 = load ptr, ptr %11, align 8
  %201 = shl nsw i64 %indvars.iv.prol, 2
  %uglygep = getelementptr i8, ptr %200, i64 %201
  %202 = load i32, ptr %uglygep, align 4
  %203 = load ptr, ptr %17, align 8
  %204 = sext i32 %202 to i64
  %205 = getelementptr i32, ptr %203, i64 %204
  store i32 %180, ptr %205, align 4
  %indvars.iv.next.prol = add nsw i64 %indvars.iv.prol, 1
  %lsr.iv.next = add nsw i64 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i64 %lsr.iv.next, 0
  br i1 %prol.iter.cmp.not, label %for_loop_body26.prol.loopexit.loopexit, label %for_loop_body26.prol, !llvm.loop !6

for_loop_body26.prol.loopexit.loopexit:           ; preds = %for_loop_body26.prol
  br label %for_loop_body26.prol.loopexit

for_loop_body26.prol.loopexit:                    ; preds = %for_loop_body26.prol.loopexit.loopexit, %for_loop_body26.preheader
  %indvars.iv.unr = phi i64 [ %196, %for_loop_body26.preheader ], [ %indvars.iv.next.prol, %for_loop_body26.prol.loopexit.loopexit ]
  %206 = icmp ult i64 %199, 7
  br i1 %206, label %for_loop_body26.prol.loopexit.after_if22_crit_edge, label %for_loop_body26.preheader90

for_loop_body26.prol.loopexit.after_if22_crit_edge: ; preds = %for_loop_body26.prol.loopexit
  br label %after_if22

for_loop_body26.preheader90:                      ; preds = %for_loop_body26.prol.loopexit
  br label %for_loop_body26

for_loop_body26:                                  ; preds = %for_loop_body26, %for_loop_body26.preheader90
  %indvars.iv = phi i64 [ %indvars.iv.next.7, %for_loop_body26 ], [ %indvars.iv.unr, %for_loop_body26.preheader90 ]
  %207 = load ptr, ptr %11, align 8
  %208 = shl i64 %indvars.iv, 2
  %uglygep103 = getelementptr i8, ptr %207, i64 %208
  %209 = load i32, ptr %uglygep103, align 4
  %210 = load ptr, ptr %17, align 8
  %211 = sext i32 %209 to i64
  %212 = getelementptr i32, ptr %210, i64 %211
  store i32 %180, ptr %212, align 4
  %213 = load ptr, ptr %11, align 8
  %uglygep104 = getelementptr i8, ptr %213, i64 4
  %uglygep105 = getelementptr i8, ptr %uglygep104, i64 %208
  %214 = load i32, ptr %uglygep105, align 4
  %215 = load ptr, ptr %17, align 8
  %216 = sext i32 %214 to i64
  %217 = getelementptr i32, ptr %215, i64 %216
  store i32 %180, ptr %217, align 4
  %218 = load ptr, ptr %11, align 8
  %uglygep101 = getelementptr i8, ptr %218, i64 8
  %uglygep102 = getelementptr i8, ptr %uglygep101, i64 %208
  %219 = load i32, ptr %uglygep102, align 4
  %220 = load ptr, ptr %17, align 8
  %221 = sext i32 %219 to i64
  %222 = getelementptr i32, ptr %220, i64 %221
  store i32 %180, ptr %222, align 4
  %223 = load ptr, ptr %11, align 8
  %uglygep99 = getelementptr i8, ptr %223, i64 12
  %uglygep100 = getelementptr i8, ptr %uglygep99, i64 %208
  %224 = load i32, ptr %uglygep100, align 4
  %225 = load ptr, ptr %17, align 8
  %226 = sext i32 %224 to i64
  %227 = getelementptr i32, ptr %225, i64 %226
  store i32 %180, ptr %227, align 4
  %228 = load ptr, ptr %11, align 8
  %uglygep97 = getelementptr i8, ptr %228, i64 16
  %uglygep98 = getelementptr i8, ptr %uglygep97, i64 %208
  %229 = load i32, ptr %uglygep98, align 4
  %230 = load ptr, ptr %17, align 8
  %231 = sext i32 %229 to i64
  %232 = getelementptr i32, ptr %230, i64 %231
  store i32 %180, ptr %232, align 4
  %233 = load ptr, ptr %11, align 8
  %uglygep95 = getelementptr i8, ptr %233, i64 20
  %uglygep96 = getelementptr i8, ptr %uglygep95, i64 %208
  %234 = load i32, ptr %uglygep96, align 4
  %235 = load ptr, ptr %17, align 8
  %236 = sext i32 %234 to i64
  %237 = getelementptr i32, ptr %235, i64 %236
  store i32 %180, ptr %237, align 4
  %238 = load ptr, ptr %11, align 8
  %uglygep93 = getelementptr i8, ptr %238, i64 24
  %uglygep94 = getelementptr i8, ptr %uglygep93, i64 %208
  %239 = load i32, ptr %uglygep94, align 4
  %240 = load ptr, ptr %17, align 8
  %241 = sext i32 %239 to i64
  %242 = getelementptr i32, ptr %240, i64 %241
  store i32 %180, ptr %242, align 4
  %243 = load ptr, ptr %11, align 8
  %uglygep91 = getelementptr i8, ptr %243, i64 28
  %uglygep92 = getelementptr i8, ptr %uglygep91, i64 %208
  %244 = load i32, ptr %uglygep92, align 4
  %245 = load ptr, ptr %17, align 8
  %246 = sext i32 %244 to i64
  %247 = getelementptr i32, ptr %245, i64 %246
  store i32 %180, ptr %247, align 4
  %indvars.iv.next.7 = add nsw i64 %indvars.iv, 8
  %exitcond.not.7 = icmp eq i64 %wide.trip.count, %indvars.iv.next.7
  br i1 %exitcond.not.7, label %after_if22.loopexit, label %for_loop_body26

true_block30:                                     ; preds = %after_if22
  %248 = load ptr, ptr %3, align 8
  %249 = getelementptr i64, ptr %248, i64 4
  %250 = load i64, ptr %249, align 8
  %251 = add i64 %250, 1
  store i64 %251, ptr %249, align 8
  br i1 %158, label %after_if19.sink.split, label %after_if19

after_if32:                                       ; preds = %after_if22
  br i1 %158, label %after_if19.sink.split, label %after_if19

true_block36:                                     ; preds = %after_for
  %252 = load ptr, ptr %3, align 8
  %253 = getelementptr i64, ptr %252, i64 5
  %254 = load i64, ptr %253, align 8
  %255 = or i64 %254, 1
  store i64 %255, ptr %253, align 8
  br label %after_if38

after_if38:                                       ; preds = %true_block36, %after_for
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.sqrt.f64(double) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare double @llvm.maxnum.f64(double, double) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smax.i32(i32, i32) #1

attributes #0 = { nofree nosync nounwind }
attributes #1 = { mustprogress nocallback nofree nosync nounwind readnone speculatable willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.unroll.disable"}
