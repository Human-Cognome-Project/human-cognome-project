; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%0 = type { ptr, [2 x i32], %struct.PhysicalCoordinates.842 }
%1 = type { %2, %2 }
%2 = type { [4 x i64], [4 x ptr] }
%struct.RuntimeContext.829 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }
%struct.ListManager = type { [256 x ptr], i64, i64, i32, i32, i32, ptr }
%struct.PhysicalCoordinates.842 = type { [12 x i32] }
%struct.cpu_block_task_helper_context = type { ptr, ptr, ptr, i32, i32, i64 }
%struct.NodeManager = type <{ ptr, i32, i32, i32, i32, ptr, ptr, ptr, i32, [4 x i8] }>
%class.anon = type { ptr, ptr, ptr, ptr }

@.str = private unnamed_addr constant [28 x i8] c"Out of pre-allocated memory\00", align 1
@.str.2 = private unnamed_addr constant [28 x i8] c"List manager out of chunks.\00", align 1

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @activity_propagate_25_kernel_0_serial(ptr nocapture readonly %context) local_unnamed_addr #0 {
entry:
  %0 = load ptr, ptr %context, align 8
  %1 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, double, { { i32 }, ptr } }, ptr %0, i64 0, i32 9
  %2 = load double, ptr %1, align 8
  %3 = getelementptr inbounds %struct.RuntimeContext.829, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 16
  %6 = load ptr, ptr %5, align 8
  store double %2, ptr %6, align 8
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @activity_propagate_25_kernel_1_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.829, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 27
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @activity_propagate_25_kernel_2_listgen_S27pointer(ptr %context) local_unnamed_addr #1 {
.lr.ph.i:
  %.sroa.2.i = alloca { [2 x i32], %struct.PhysicalCoordinates.842 }, align 8
  %0 = alloca %0, align 8
  %1 = getelementptr inbounds %struct.RuntimeContext.829, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 23
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %4, i64 27
  %8 = load ptr, ptr %7, align 8
  %9 = load atomic i64, ptr %6 acquire, align 8
  %.not.i.i.i.i = icmp ne i64 %9, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i)
  %10 = inttoptr i64 %9 to ptr
  %11 = load atomic i64, ptr %10 acquire, align 8
  %12 = inttoptr i64 %11 to ptr
  %.sroa.0.0.copyload.i = load ptr, ptr %12, align 8
  %.sroa.2.0..sroa_idx.i = getelementptr inbounds i8, ptr %12, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.i, ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.0..sroa_idx.i, i64 56, i1 false)
  %getch.i = getelementptr %1, ptr %.sroa.0.0.copyload.i, i64 0, i32 1
  %13 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %.sroa.2.16.sroa_idx.i = getelementptr inbounds i8, ptr %.sroa.2.i, i64 8
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %16 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 4
  %17 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 6
  %18 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 2
  %19 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  store ptr %getch.i, ptr %0, align 8
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %0, i64 8
  store <2 x i32> <i32 0, i32 4>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %13, ptr noundef nonnull align 8 dereferenceable(48) %.sroa.2.16.sroa_idx.i, i64 48, i1 false)
  %20 = atomicrmw volatile add ptr %14, i32 1 seq_cst, align 4
  %21 = load i32, ptr %15, align 8
  %22 = ashr i32 %20, %21
  %23 = icmp ugt i32 %22, 131071
  br i1 %23, label %24, label %26

24:                                               ; preds = %.lr.ph.i
  %25 = load ptr, ptr %17, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %25, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

26:                                               ; preds = %.lr.ph.i
  %27 = zext i32 %22 to i64
  %28 = lshr i64 %27, 9
  %29 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %28
  %30 = load atomic i64, ptr %29 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %30, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %26
  %31 = inttoptr i64 %30 to ptr
  %32 = and i64 %27, 511
  %33 = getelementptr inbounds ptr, ptr %31, i64 %32
  %34 = load atomic i64, ptr %33 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %26
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %35 = atomicrmw volatile xchg ptr %16, i32 1 seq_cst, align 4
  %36 = icmp eq i32 %35, 1
  br i1 %36, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %37 = load atomic i64, ptr %29 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %37, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %39, label %73

39:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %40 = load ptr, ptr %17, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1
  %42 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 28
  %43 = atomicrmw volatile add ptr %42, i64 4096 seq_cst, align 8
  %44 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 2
  %45 = load i64, ptr %44, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %45, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %66, label %46

46:                                               ; preds = %39
  %47 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 26
  br label %48

48:                                               ; preds = %48, %46
  %49 = atomicrmw volatile xchg ptr %47, i32 1 seq_cst, align 4
  %50 = icmp eq i32 %49, 1
  br i1 %50, label %48, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %48
  %51 = load ptr, ptr %41, align 8
  %52 = ptrtoint ptr %51 to i64
  %53 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 1
  %54 = load ptr, ptr %53, align 8
  %55 = ptrtoint ptr %54 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %52
  %56 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %57 = or i64 %56, 4096
  %58 = add i64 %57, %52
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %58, %55
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %59

59:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %60 = add i64 %56, %52
  %61 = inttoptr i64 %60 to ptr
  %62 = getelementptr i8, ptr %51, i64 %56
  %63 = getelementptr inbounds i8, ptr %62, i64 4096
  store ptr %63, ptr %41, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %59, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %61, %59 ]
  %64 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %65 = atomicrmw volatile xchg ptr %47, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %40, i1 noundef zeroext %64, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

66:                                               ; preds = %39
  %67 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 2
  %68 = load ptr, ptr %67, align 8
  %69 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 6
  %70 = load ptr, ptr %69, align 8
  %71 = tail call noundef ptr %68(ptr noundef %70, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %66, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %71, %66 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %72 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %72, ptr %29 release, align 8
  br label %73

73:                                               ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %38, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %74 = and i32 %22, 511
  %75 = zext i32 %74 to i64
  %76 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %75
  %77 = load atomic i64, ptr %76 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %77, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %78, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

78:                                               ; preds = %73
  %79 = load ptr, ptr %17, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1
  %81 = load i64, ptr %18, align 8
  %82 = load i64, ptr %19, align 8
  %83 = mul i64 %82, %81
  %84 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 28
  %85 = atomicrmw volatile add ptr %84, i64 %83 seq_cst, align 8
  %86 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 2
  %87 = load i64, ptr %86, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %87, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %107, label %88

88:                                               ; preds = %78
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 26
  br label %90

90:                                               ; preds = %90, %88
  %91 = atomicrmw volatile xchg ptr %89, i32 1 seq_cst, align 4
  %92 = icmp eq i32 %91, 1
  br i1 %92, label %90, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %90
  %93 = load ptr, ptr %80, align 8
  %94 = ptrtoint ptr %93 to i64
  %95 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 1
  %96 = load ptr, ptr %95, align 8
  %97 = ptrtoint ptr %96 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %94
  %98 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %99 = add i64 %98, %83
  %100 = add i64 %99, %94
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %100, %97
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %101

101:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %102 = add i64 %98, %94
  %103 = inttoptr i64 %102 to ptr
  %104 = getelementptr inbounds i8, ptr %93, i64 %99
  store ptr %104, ptr %80, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %101, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %103, %101 ]
  %105 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %106 = atomicrmw volatile xchg ptr %89, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %79, i1 noundef zeroext %105, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

107:                                              ; preds = %78
  %108 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 2
  %109 = load ptr, ptr %108, align 8
  %110 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 6
  %111 = load ptr, ptr %110, align 8
  %112 = tail call noundef ptr %109(ptr noundef %111, i64 noundef %83, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %107, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %112, %107 ]
  %113 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %113, ptr %76 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %73
  %114 = atomicrmw volatile xchg ptr %16, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %24
  %115 = load i32, ptr %15, align 8
  %116 = ashr i32 %20, %115
  %117 = sext i32 %116 to i64
  %118 = lshr i64 %117, 9
  %119 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %118
  %120 = load atomic i64, ptr %119 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %120, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %121

121:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %122 = inttoptr i64 %120 to ptr
  %123 = and i64 %117, 511
  %124 = getelementptr inbounds ptr, ptr %122, i64 %123
  %125 = load atomic i64, ptr %124 acquire, align 8
  %126 = inttoptr i64 %125 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %121, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %127 = phi ptr [ %126, %121 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %128 = load i64, ptr %19, align 8
  %129 = load i32, ptr %15, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %129
  %130 = xor i32 %notmask.i.i.i.i, -1
  %131 = and i32 %20, %130
  %132 = sext i32 %131 to i64
  %133 = mul i64 %128, %132
  %134 = getelementptr inbounds i8, ptr %127, i64 %133
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %134, ptr nonnull align 8 %0, i64 %128, i1 false)
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @activity_propagate_25_kernel_3_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.829, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 28
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @activity_propagate_25_kernel_4_listgen_S28bitmasked(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %0, align 8
  %1 = alloca %struct.PhysicalCoordinates.842, align 4
  %2 = alloca %0, align 8
  %3 = getelementptr inbounds %struct.RuntimeContext.829, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %2)
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 13
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %6, i64 27
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %10 = load i32, ptr %9, align 8
  %11 = getelementptr inbounds ptr, ptr %6, i64 28
  %12 = load ptr, ptr %11, align 8
  %13 = icmp sgt i32 %10, 0
  br i1 %13, label %.lr.ph61.i, label %element_listgen_nonroot.exit

.lr.ph61.i:                                       ; preds = %entry
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  %16 = getelementptr inbounds %0, ptr %0, i64 0, i32 1
  %17 = getelementptr inbounds %0, ptr %0, i64 0, i32 1, i64 1
  %18 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %19 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %20 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 5
  %21 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %22 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 4
  %23 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 6
  %24 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 2
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %2, i64 8
  br label %26

26:                                               ; preds = %._crit_edge.i, %.lr.ph61.i
  %.04359.i = phi i32 [ 0, %.lr.ph61.i ], [ %172, %._crit_edge.i ]
  %27 = load i32, ptr %14, align 8
  %28 = lshr i32 %.04359.i, %27
  %29 = sext i32 %28 to i64
  %30 = lshr i64 %29, 9
  %31 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %30
  %32 = load atomic i64, ptr %31 acquire, align 8
  %.not.i.i.i.i = icmp eq i64 %32, 0
  br i1 %.not.i.i.i.i, label %_ZN11ListManager3getI7ElementEERT_i.exit.i, label %33

33:                                               ; preds = %26
  %34 = inttoptr i64 %32 to ptr
  %35 = and i64 %29, 511
  %36 = getelementptr inbounds ptr, ptr %34, i64 %35
  %37 = load atomic i64, ptr %36 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit.i

_ZN11ListManager3getI7ElementEERT_i.exit.i:       ; preds = %33, %26
  %39 = phi ptr [ %38, %33 ], [ null, %26 ]
  %40 = load i64, ptr %15, align 8
  %41 = load i32, ptr %14, align 8
  %notmask.i.i.i = shl nsw i32 -1, %41
  %42 = xor i32 %notmask.i.i.i, -1
  %43 = and i32 %.04359.i, %42
  %44 = zext i32 %43 to i64
  %45 = mul i64 %40, %44
  %46 = getelementptr inbounds i8, ptr %39, i64 %45
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %0, ptr noundef nonnull align 8 dereferenceable(64) %46, i64 64, i1 false)
  %47 = load i32, ptr %16, align 8
  %48 = load i32, ptr %17, align 4
  %49 = icmp slt i32 %47, %48
  br i1 %49, label %.lr.ph58.i.preheader, label %._crit_edge.i

.lr.ph58.i.preheader:                             ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit.i
  br label %.lr.ph58.i

.lr.ph58.i:                                       ; preds = %.loopexit.i, %.lr.ph58.i.preheader
  %.04457.i = phi i32 [ %171, %.loopexit.i ], [ %47, %.lr.ph58.i.preheader ]
  call fastcc void @S27_refine_coordinates(ptr noundef nonnull %18, ptr noundef nonnull %1, i32 noundef %.04457.i) #1
  %50 = load ptr, ptr %0, align 8
  %51 = shl i32 %.04457.i, 3
  %52 = sext i32 %51 to i64
  %53 = getelementptr i8, ptr %50, i64 %52
  %54 = getelementptr inbounds i8, ptr %53, i64 32
  %55 = load ptr, ptr %54, align 8
  %.not = icmp eq ptr %55, null
  br i1 %.not, label %.loopexit.i, label %.lr.ph.i

.lr.ph.i:                                         ; preds = %.lr.ph58.i
  store ptr %55, ptr %2, align 8
  store <2 x i32> <i32 0, i32 32>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %19, ptr noundef nonnull align 4 dereferenceable(48) %1, i64 48, i1 false)
  %56 = atomicrmw volatile add ptr %20, i32 1 seq_cst, align 4
  %57 = load i32, ptr %21, align 8
  %58 = ashr i32 %56, %57
  %59 = icmp ugt i32 %58, 131071
  br i1 %59, label %60, label %62

60:                                               ; preds = %.lr.ph.i
  %61 = load ptr, ptr %23, align 8
  call fastcc void @taichi_assert_format(ptr noundef %61, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

62:                                               ; preds = %.lr.ph.i
  %63 = zext i32 %58 to i64
  %64 = lshr i64 %63, 9
  %65 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %64
  %66 = load atomic i64, ptr %65 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %66, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %62
  %67 = inttoptr i64 %66 to ptr
  %68 = and i64 %63, 511
  %69 = getelementptr inbounds ptr, ptr %67, i64 %68
  %70 = load atomic i64, ptr %69 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %70, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %62
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %71 = atomicrmw volatile xchg ptr %22, i32 1 seq_cst, align 4
  %72 = icmp eq i32 %71, 1
  br i1 %72, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %73 = load atomic i64, ptr %65 acquire, align 8
  %74 = inttoptr i64 %73 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %73, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %75, label %109

75:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %76 = load ptr, ptr %23, align 8
  %77 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1
  %78 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 28
  %79 = atomicrmw volatile add ptr %78, i64 4096 seq_cst, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 2
  %81 = load i64, ptr %80, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %81, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %102, label %82

82:                                               ; preds = %75
  %83 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 26
  br label %84

84:                                               ; preds = %84, %82
  %85 = atomicrmw volatile xchg ptr %83, i32 1 seq_cst, align 4
  %86 = icmp eq i32 %85, 1
  br i1 %86, label %84, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %84
  %87 = load ptr, ptr %77, align 8
  %88 = ptrtoint ptr %87 to i64
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 1
  %90 = load ptr, ptr %89, align 8
  %91 = ptrtoint ptr %90 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %88
  %92 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %93 = or i64 %92, 4096
  %94 = add i64 %93, %88
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %94, %91
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %95

95:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %96 = add i64 %92, %88
  %97 = inttoptr i64 %96 to ptr
  %98 = getelementptr i8, ptr %87, i64 %92
  %99 = getelementptr inbounds i8, ptr %98, i64 4096
  store ptr %99, ptr %77, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %95, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %97, %95 ]
  %100 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %101 = atomicrmw volatile xchg ptr %83, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %76, i1 noundef zeroext %100, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

102:                                              ; preds = %75
  %103 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 2
  %104 = load ptr, ptr %103, align 8
  %105 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 6
  %106 = load ptr, ptr %105, align 8
  %107 = call noundef ptr %104(ptr noundef %106, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %102, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %107, %102 ]
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %108 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %108, ptr %65 release, align 8
  br label %109

109:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %74, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %110 = and i32 %58, 511
  %111 = zext i32 %110 to i64
  %112 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %111
  %113 = load atomic i64, ptr %112 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %113, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %114, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

114:                                              ; preds = %109
  %115 = load ptr, ptr %23, align 8
  %116 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1
  %117 = load i64, ptr %24, align 8
  %118 = load i64, ptr %25, align 8
  %119 = mul i64 %118, %117
  %120 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 28
  %121 = atomicrmw volatile add ptr %120, i64 %119 seq_cst, align 8
  %122 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 2
  %123 = load i64, ptr %122, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %123, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %143, label %124

124:                                              ; preds = %114
  %125 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 26
  br label %126

126:                                              ; preds = %126, %124
  %127 = atomicrmw volatile xchg ptr %125, i32 1 seq_cst, align 4
  %128 = icmp eq i32 %127, 1
  br i1 %128, label %126, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %126
  %129 = load ptr, ptr %116, align 8
  %130 = ptrtoint ptr %129 to i64
  %131 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 1
  %132 = load ptr, ptr %131, align 8
  %133 = ptrtoint ptr %132 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %130
  %134 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %135 = add i64 %134, %119
  %136 = add i64 %135, %130
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %136, %133
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %137

137:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %138 = add i64 %134, %130
  %139 = inttoptr i64 %138 to ptr
  %140 = getelementptr inbounds i8, ptr %129, i64 %135
  store ptr %140, ptr %116, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %137, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %139, %137 ]
  %141 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %142 = atomicrmw volatile xchg ptr %125, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %115, i1 noundef zeroext %141, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

143:                                              ; preds = %114
  %144 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 2
  %145 = load ptr, ptr %144, align 8
  %146 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 6
  %147 = load ptr, ptr %146, align 8
  %148 = call noundef ptr %145(ptr noundef %147, i64 noundef %119, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %143, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %148, %143 ]
  %149 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %149, ptr %112 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %109
  %150 = atomicrmw volatile xchg ptr %22, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %60
  %151 = load i32, ptr %21, align 8
  %152 = ashr i32 %56, %151
  %153 = sext i32 %152 to i64
  %154 = lshr i64 %153, 9
  %155 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %154
  %156 = load atomic i64, ptr %155 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %156, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %157

157:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %158 = inttoptr i64 %156 to ptr
  %159 = and i64 %153, 511
  %160 = getelementptr inbounds ptr, ptr %158, i64 %159
  %161 = load atomic i64, ptr %160 acquire, align 8
  %162 = inttoptr i64 %161 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %157, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %163 = phi ptr [ %162, %157 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %164 = load i64, ptr %25, align 8
  %165 = load i32, ptr %21, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %165
  %166 = xor i32 %notmask.i.i.i.i, -1
  %167 = and i32 %56, %166
  %168 = sext i32 %167 to i64
  %169 = mul i64 %164, %168
  %170 = getelementptr inbounds i8, ptr %163, i64 %169
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %170, ptr nonnull align 8 %2, i64 %164, i1 false)
  br label %.loopexit.i, !llvm.loop !8

.loopexit.i:                                      ; preds = %_ZN11ListManager6appendEPv.exit.i, %.lr.ph58.i
  %171 = add i32 %.04457.i, 1
  %exitcond.not.i = icmp eq i32 %171, %48
  br i1 %exitcond.not.i, label %._crit_edge.i.loopexit, label %.lr.ph58.i, !llvm.loop !9

._crit_edge.i.loopexit:                           ; preds = %.loopexit.i
  br label %._crit_edge.i

._crit_edge.i:                                    ; preds = %._crit_edge.i.loopexit, %_ZN11ListManager3getI7ElementEERT_i.exit.i
  %172 = add nuw nsw i32 %.04359.i, 1
  %exitcond63.not.i = icmp eq i32 %172, %10
  br i1 %exitcond63.not.i, label %element_listgen_nonroot.exit.loopexit, label %26, !llvm.loop !10

element_listgen_nonroot.exit.loopexit:            ; preds = %._crit_edge.i
  br label %element_listgen_nonroot.exit

element_listgen_nonroot.exit:                     ; preds = %element_listgen_nonroot.exit.loopexit, %entry
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %2)
  ret void
}

; Function Attrs: nounwind
define void @activity_propagate_25_kernel_5_struct_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.cpu_block_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.RuntimeContext.829, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 28
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds %struct.ListManager, ptr %6, i64 0, i32 5
  %8 = load i32, ptr %7, align 8
  store ptr %context, ptr %0, align 8
  %9 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  store ptr @function_body, ptr %9, align 8
  %10 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  store ptr %6, ptr %10, align 8
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  store <2 x i32> <i32 32, i32 8>, ptr %11, align 8
  %12 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  store i64 1, ptr %12, align 8
  %13 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 12
  %14 = load ptr, ptr %13, align 8
  %15 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 11
  %16 = load ptr, ptr %15, align 8
  %17 = shl nsw i32 %8, 3
  call void %14(ptr noundef %16, i32 noundef %17, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_struct_for_block_helper) #1
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %0)
  ret void
}

; Function Attrs: nounwind
define internal void @function_body(ptr %0, ptr nocapture readnone %1, ptr nocapture readonly %2, i32 %3, i32 %4) #1 {
allocs:
  %5 = alloca ptr, align 8
  %6 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %7 = icmp slt i32 %3, %4
  br i1 %7, label %loop_body.lr.ph, label %func_exit

loop_body.lr.ph:                                  ; preds = %allocs
  %8 = getelementptr inbounds %struct.RuntimeContext.829, ptr %0, i64 0, i32 1
  br label %loop_body

loop_body:                                        ; preds = %loop_body_tail, %loop_body.lr.ph
  %.0779 = phi i32 [ %3, %loop_body.lr.ph ], [ %23, %loop_body_tail ]
  %9 = and i32 %.0779, 31
  %10 = load i32, ptr %6, align 4
  %11 = shl i32 %10, 5
  %12 = or i32 %11, %9
  %13 = load ptr, ptr %2, align 8
  %14 = getelementptr inbounds i8, ptr %13, i64 32
  %15 = sdiv i32 %.0779, 8
  %16 = sext i32 %15 to i64
  %17 = getelementptr inbounds i8, ptr %14, i64 %16
  %18 = load i8, ptr %17, align 1
  %19 = zext i8 %18 to i32
  %20 = and i32 %.0779, 7
  %21 = shl nuw nsw i32 1, %20
  %22 = and i32 %21, %19
  %.not77 = icmp eq i32 %22, 0
  br i1 %.not77, label %loop_body_tail, label %struct_for_body_body

loop_body_tail.loopexit:                          ; preds = %for_loop_body.us
  br label %loop_body_tail

loop_body_tail.loopexit90:                        ; preds = %after_if3
  br label %loop_body_tail

loop_body_tail:                                   ; preds = %for_loop_body.us.prol.loopexit, %true_block, %Pointer_lookup_element.exit10, %loop_body_tail.loopexit90, %loop_body_tail.loopexit, %loop_body
  %23 = add nsw i32 %.0779, 1
  %exitcond85.not = icmp eq i32 %23, %4
  br i1 %exitcond85.not, label %func_exit.loopexit, label %loop_body

func_exit.loopexit:                               ; preds = %loop_body_tail
  br label %func_exit

func_exit:                                        ; preds = %func_exit.loopexit, %allocs
  ret void

struct_for_body_body:                             ; preds = %loop_body
  %24 = load ptr, ptr %8, align 8
  %25 = getelementptr inbounds %struct.LLVMRuntime, ptr %24, i64 0, i32 7
  %26 = load ptr, ptr %25, align 8
  %27 = getelementptr inbounds ptr, ptr %26, i64 3
  %28 = load ptr, ptr %27, align 8
  %getch.i = getelementptr %1, ptr %28, i64 0, i32 1
  %29 = shl i32 %10, 3
  %30 = and i32 %29, 1073741816
  %31 = zext i32 %30 to i64
  %32 = getelementptr i8, ptr %getch.i, i64 %31
  %33 = getelementptr inbounds i8, ptr %32, i64 32
  %34 = load ptr, ptr %33, align 8
  %35 = icmp eq ptr %34, null
  br i1 %35, label %36, label %Pointer_lookup_element.exit10

36:                                               ; preds = %struct_for_body_body
  %37 = getelementptr inbounds %struct.LLVMRuntime, ptr %24, i64 0, i32 15
  %38 = load ptr, ptr %37, align 8
  %39 = getelementptr inbounds ptr, ptr %38, i64 27
  %40 = load ptr, ptr %39, align 8
  br label %Pointer_lookup_element.exit10

Pointer_lookup_element.exit10:                    ; preds = %36, %struct_for_body_body
  %.0.i9 = phi ptr [ %40, %36 ], [ %34, %struct_for_body_body ]
  %41 = getelementptr inbounds i8, ptr %.0.i9, i64 32
  %42 = shl nuw i32 1, %9
  %43 = xor i32 %42, -1
  %44 = atomicrmw volatile and ptr %41, i32 %43 seq_cst, align 4
  %45 = load ptr, ptr %0, align 8
  %46 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, double, { { i32 }, ptr } }, ptr %45, i64 0, i32 4, i32 1
  %47 = load ptr, ptr %46, align 8
  %48 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, double, { { i32 }, ptr } }, ptr %45, i64 0, i32 4, i32 0, i32 1
  %49 = load i32, ptr %48, align 4
  %50 = sext i32 %49 to i64
  %51 = sext i32 %12 to i64
  %52 = add nsw i64 %50, %51
  %53 = getelementptr i32, ptr %47, i64 %52
  %54 = load i32, ptr %53, align 4
  %.not = icmp eq i32 %54, 0
  br i1 %.not, label %loop_body_tail, label %true_block

true_block:                                       ; preds = %Pointer_lookup_element.exit10
  %55 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, double, { { i32 }, ptr } }, ptr %45, i64 0, i32 7, i32 1
  %56 = load ptr, ptr %55, align 8
  %57 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, double, { { i32 }, ptr } }, ptr %45, i64 0, i32 7, i32 0, i32 1
  %58 = load i32, ptr %57, align 4
  %59 = sext i32 %58 to i64
  %60 = getelementptr i32, ptr %56, i64 %51
  %61 = load i32, ptr %60, align 4
  %62 = add nsw i64 %59, %51
  %63 = getelementptr i32, ptr %56, i64 %62
  %64 = load i32, ptr %63, align 4
  %65 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, double, { { i32 }, ptr } }, ptr %45, i64 0, i32 6, i32 1
  %66 = load ptr, ptr %65, align 8
  %67 = getelementptr i64, ptr %66, i64 15
  %68 = add i32 %12, 1024
  %69 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, double, { { i32 }, ptr } }, ptr %45, i64 0, i32 10, i32 1
  %70 = load ptr, ptr %69, align 8
  %71 = sext i32 %68 to i64
  %72 = getelementptr i64, ptr %70, i64 %71
  %73 = icmp sgt i32 %64, %61
  br i1 %73, label %for_loop_body.lr.ph, label %loop_body_tail

for_loop_body.lr.ph:                              ; preds = %true_block
  %74 = load ptr, ptr %8, align 8
  %75 = getelementptr inbounds %struct.LLVMRuntime, ptr %74, i64 0, i32 16
  %76 = load ptr, ptr %75, align 8
  %77 = load double, ptr %76, align 8
  %.fr80 = freeze double %77
  %78 = fcmp ueq double %.fr80, 0.000000e+00
  %79 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, double, { { i32 }, ptr } }, ptr %45, i64 0, i32 8, i32 1
  %80 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, double, { { i32 }, ptr } }, ptr %45, i64 0, i32 2, i32 1
  br i1 %78, label %for_loop_body.us.preheader, label %for_loop_body.preheader

for_loop_body.us.preheader:                       ; preds = %for_loop_body.lr.ph
  %81 = sub i32 %64, %61
  %82 = xor i32 %61, -1
  %83 = add i32 %64, %82
  %xtraiter = and i32 %81, 7
  %lcmp.mod.not = icmp eq i32 %xtraiter, 0
  br i1 %lcmp.mod.not, label %for_loop_body.us.prol.loopexit, label %for_loop_body.us.prol.preheader

for_loop_body.us.prol.preheader:                  ; preds = %for_loop_body.us.preheader
  %84 = mul nsw i32 %xtraiter, -1
  br label %for_loop_body.us.prol

for_loop_body.us.prol:                            ; preds = %for_loop_body.us.prol, %for_loop_body.us.prol.preheader
  %lsr.iv = phi i32 [ 0, %for_loop_body.us.prol.preheader ], [ %lsr.iv.next, %for_loop_body.us.prol ]
  %85 = atomicrmw add ptr %67, i64 1 seq_cst, align 8
  %86 = load ptr, ptr %65, align 8
  %87 = getelementptr i64, ptr %86, i64 16
  %88 = atomicrmw add ptr %87, i64 1 seq_cst, align 8
  %lsr.iv.next = add nsw i32 %lsr.iv, -1
  %prol.iter.cmp.not = icmp eq i32 %84, %lsr.iv.next
  br i1 %prol.iter.cmp.not, label %for_loop_body.us.prol.loopexit.loopexit, label %for_loop_body.us.prol, !llvm.loop !11

for_loop_body.us.prol.loopexit.loopexit:          ; preds = %for_loop_body.us.prol
  %89 = sub i32 %61, %84
  br label %for_loop_body.us.prol.loopexit

for_loop_body.us.prol.loopexit:                   ; preds = %for_loop_body.us.prol.loopexit.loopexit, %for_loop_body.us.preheader
  %.078.us.unr = phi i32 [ %61, %for_loop_body.us.preheader ], [ %89, %for_loop_body.us.prol.loopexit.loopexit ]
  %90 = icmp ult i32 %83, 7
  br i1 %90, label %loop_body_tail, label %for_loop_body.us.preheader89

for_loop_body.us.preheader89:                     ; preds = %for_loop_body.us.prol.loopexit
  %91 = sub i32 %64, %.078.us.unr
  br label %for_loop_body.us

for_loop_body.preheader:                          ; preds = %for_loop_body.lr.ph
  %92 = sext i32 %61 to i64
  %wide.trip.count = sext i32 %64 to i64
  br label %for_loop_body

for_loop_body.us:                                 ; preds = %for_loop_body.us, %for_loop_body.us.preheader89
  %lsr.iv91 = phi i32 [ %91, %for_loop_body.us.preheader89 ], [ %lsr.iv.next92, %for_loop_body.us ]
  %93 = atomicrmw add ptr %67, i64 1 seq_cst, align 8
  %94 = load ptr, ptr %65, align 8
  %95 = getelementptr i64, ptr %94, i64 16
  %96 = atomicrmw add ptr %95, i64 1 seq_cst, align 8
  %97 = atomicrmw add ptr %67, i64 1 seq_cst, align 8
  %98 = load ptr, ptr %65, align 8
  %99 = getelementptr i64, ptr %98, i64 16
  %100 = atomicrmw add ptr %99, i64 1 seq_cst, align 8
  %101 = atomicrmw add ptr %67, i64 1 seq_cst, align 8
  %102 = load ptr, ptr %65, align 8
  %103 = getelementptr i64, ptr %102, i64 16
  %104 = atomicrmw add ptr %103, i64 1 seq_cst, align 8
  %105 = atomicrmw add ptr %67, i64 1 seq_cst, align 8
  %106 = load ptr, ptr %65, align 8
  %107 = getelementptr i64, ptr %106, i64 16
  %108 = atomicrmw add ptr %107, i64 1 seq_cst, align 8
  %109 = atomicrmw add ptr %67, i64 1 seq_cst, align 8
  %110 = load ptr, ptr %65, align 8
  %111 = getelementptr i64, ptr %110, i64 16
  %112 = atomicrmw add ptr %111, i64 1 seq_cst, align 8
  %113 = atomicrmw add ptr %67, i64 1 seq_cst, align 8
  %114 = load ptr, ptr %65, align 8
  %115 = getelementptr i64, ptr %114, i64 16
  %116 = atomicrmw add ptr %115, i64 1 seq_cst, align 8
  %117 = atomicrmw add ptr %67, i64 1 seq_cst, align 8
  %118 = load ptr, ptr %65, align 8
  %119 = getelementptr i64, ptr %118, i64 16
  %120 = atomicrmw add ptr %119, i64 1 seq_cst, align 8
  %121 = atomicrmw add ptr %67, i64 1 seq_cst, align 8
  %122 = load ptr, ptr %65, align 8
  %123 = getelementptr i64, ptr %122, i64 16
  %124 = atomicrmw add ptr %123, i64 1 seq_cst, align 8
  %lsr.iv.next92 = add i32 %lsr.iv91, -8
  %exitcond.not.7 = icmp eq i32 %lsr.iv.next92, 0
  br i1 %exitcond.not.7, label %loop_body_tail.loopexit, label %for_loop_body.us

for_loop_body:                                    ; preds = %after_if3, %for_loop_body.preheader
  %indvars.iv = phi i64 [ %92, %for_loop_body.preheader ], [ %indvars.iv.next, %after_if3 ]
  %125 = load ptr, ptr %79, align 8
  %126 = getelementptr i32, ptr %125, i64 %indvars.iv
  %127 = load i32, ptr %126, align 4
  %128 = load ptr, ptr %80, align 8
  %129 = sext i32 %127 to i64
  %130 = getelementptr i32, ptr %128, i64 %129
  %131 = load i32, ptr %130, align 4
  %132 = atomicrmw add ptr %67, i64 1 seq_cst, align 8
  %133 = load i64, ptr %72, align 8
  %.not81 = icmp eq i64 %133, 0
  %134 = load ptr, ptr %65, align 8
  br i1 %.not81, label %false_block2, label %true_block1

true_block1:                                      ; preds = %for_loop_body
  %135 = getelementptr i64, ptr %134, i64 10
  %136 = atomicrmw add ptr %135, i64 1 seq_cst, align 8
  %137 = load ptr, ptr %0, align 8
  %138 = getelementptr { { i32, i32 }, ptr }, ptr %137, i64 0, i32 1
  %139 = load ptr, ptr %138, align 8
  %140 = getelementptr { { i32, i32 }, ptr }, ptr %137, i64 0, i32 0, i32 1
  %141 = load i32, ptr %140, align 4
  %142 = sext i32 %141 to i64
  %143 = sext i32 %131 to i64
  %144 = getelementptr double, ptr %139, i64 %143
  %145 = load double, ptr %144, align 8
  %146 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, double, { { i32 }, ptr } }, ptr %137, i64 0, i32 1, i32 1
  %147 = load ptr, ptr %146, align 8
  %148 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, double, { { i32 }, ptr } }, ptr %137, i64 0, i32 1, i32 0, i32 1
  %149 = load i32, ptr %148, align 4
  %150 = sext i32 %149 to i64
  %151 = getelementptr double, ptr %147, i64 %51
  %152 = load double, ptr %151, align 8
  %153 = fsub double %152, %145
  %154 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, double, { { i32 }, ptr } }, ptr %137, i64 0, i32 5, i32 1
  %155 = load ptr, ptr %154, align 8
  %156 = getelementptr { { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr }, double, { { i32 }, ptr } }, ptr %137, i64 0, i32 5, i32 0, i32 1
  %157 = load i32, ptr %156, align 4
  %158 = sext i32 %157 to i64
  %159 = mul nsw i64 %158, 3
  %160 = add nsw i64 %159, %51
  %161 = getelementptr double, ptr %155, i64 %160
  %162 = load double, ptr %161, align 8
  %163 = fsub double %162, %145
  %164 = fcmp one double %153, %163
  %165 = add nsw i64 %142, %143
  %166 = getelementptr double, ptr %139, i64 %165
  %167 = load double, ptr %166, align 8
  %168 = add nsw i64 %150, %51
  %169 = getelementptr double, ptr %147, i64 %168
  %170 = load double, ptr %169, align 8
  %171 = fsub double %170, %167
  %172 = shl nsw i64 %158, 2
  %173 = add nsw i64 %172, %51
  %174 = getelementptr double, ptr %155, i64 %173
  %175 = load double, ptr %174, align 8
  %176 = fsub double %175, %167
  %177 = fcmp one double %171, %176
  %178 = or i1 %164, %177
  %179 = shl nsw i64 %142, 1
  %180 = add nsw i64 %179, %143
  %181 = getelementptr double, ptr %139, i64 %180
  %182 = load double, ptr %181, align 8
  %183 = shl nsw i64 %150, 1
  %184 = add nsw i64 %183, %51
  %185 = getelementptr double, ptr %147, i64 %184
  %186 = load double, ptr %185, align 8
  %187 = fsub double %186, %182
  %188 = mul nsw i64 %158, 5
  %189 = add nsw i64 %188, %51
  %190 = getelementptr double, ptr %155, i64 %189
  %191 = load double, ptr %190, align 8
  %192 = fsub double %191, %182
  %193 = fcmp one double %187, %192
  %194 = or i1 %178, %193
  br i1 %194, label %true_block4, label %false_block5

false_block2:                                     ; preds = %for_loop_body
  %195 = getelementptr i64, ptr %134, i64 16
  %196 = atomicrmw add ptr %195, i64 1 seq_cst, align 8
  br label %after_if3

after_if3:                                        ; preds = %false_block5, %Pointer_lookup_element.exit, %false_block2
  %indvars.iv.next = add nsw i64 %indvars.iv, 1
  %exitcond84.not = icmp eq i64 %indvars.iv.next, %wide.trip.count
  br i1 %exitcond84.not, label %loop_body_tail.loopexit90, label %for_loop_body

true_block4:                                      ; preds = %true_block1
  %197 = sdiv i32 %131, 32
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %5)
  %198 = shl nsw i32 %197, 3
  %199 = sext i32 %198 to i64
  %200 = getelementptr i8, ptr %28, i64 %199
  store volatile ptr %200, ptr %5, align 8
  %201 = getelementptr inbounds i8, ptr %200, i64 32
  %202 = load volatile ptr, ptr %201, align 8
  %203 = icmp eq ptr %202, null
  br i1 %203, label %204, label %Pointer_activate.exit

204:                                              ; preds = %true_block4
  %.0..0..0..0..0..i = load volatile ptr, ptr %5, align 8
  %.0..0..0..0..0.2.i = load volatile ptr, ptr %5, align 8
  br label %205

205:                                              ; preds = %205, %204
  %206 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i, i32 1 seq_cst, align 4
  %207 = icmp eq i32 %206, 1
  br i1 %207, label %205, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i:                        ; preds = %205
  %208 = load volatile ptr, ptr %201, align 8
  %209 = icmp eq ptr %208, null
  br i1 %209, label %210, label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i"

210:                                              ; preds = %mutex_lock_i32.exit.i.i.i
  %211 = load ptr, ptr %8, align 8
  %212 = getelementptr inbounds %struct.LLVMRuntime, ptr %211, i64 0, i32 14
  %213 = load ptr, ptr %212, align 8
  %214 = getelementptr inbounds ptr, ptr %213, i64 24
  %215 = load ptr, ptr %214, align 8
  %216 = getelementptr inbounds %struct.NodeManager, ptr %215, i64 0, i32 4
  %217 = atomicrmw volatile add ptr %216, i32 1 seq_cst, align 4
  %218 = getelementptr inbounds %struct.NodeManager, ptr %215, i64 0, i32 5
  %219 = load ptr, ptr %218, align 8
  %220 = getelementptr inbounds %struct.ListManager, ptr %219, i64 0, i32 5
  %221 = load i32, ptr %220, align 8
  %.not.i.i.i.i.i = icmp slt i32 %217, %221
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i, label %222

222:                                              ; preds = %210
  %223 = getelementptr inbounds %struct.NodeManager, ptr %215, i64 0, i32 7
  %224 = load ptr, ptr %223, align 8
  %225 = getelementptr inbounds %struct.ListManager, ptr %224, i64 0, i32 5
  %226 = atomicrmw volatile add ptr %225, i32 1 seq_cst, align 4
  %227 = getelementptr inbounds %struct.ListManager, ptr %224, i64 0, i32 3
  %228 = load i32, ptr %227, align 8
  %229 = ashr i32 %226, %228
  %230 = icmp ugt i32 %229, 131071
  br i1 %230, label %231, label %234

231:                                              ; preds = %222
  %232 = getelementptr inbounds %struct.ListManager, ptr %224, i64 0, i32 6
  %233 = load ptr, ptr %232, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %233, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

234:                                              ; preds = %222
  %235 = zext i32 %229 to i64
  %236 = lshr i64 %235, 9
  %237 = getelementptr inbounds [256 x ptr], ptr %224, i64 0, i64 %236
  %238 = load atomic i64, ptr %237 acquire, align 8
  %.not.i.i.i4.i.i.i.i.i = icmp eq i64 %238, 0
  br i1 %.not.i.i.i4.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i:  ; preds = %234
  %239 = inttoptr i64 %238 to ptr
  %240 = and i64 %235, 511
  %241 = getelementptr inbounds ptr, ptr %239, i64 %240
  %242 = load atomic i64, ptr %241 acquire, align 8
  %.not.i.i5.i.i.i.i.i = icmp eq i64 %242, 0
  br i1 %.not.i.i5.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i, %234
  %243 = getelementptr inbounds %struct.ListManager, ptr %224, i64 0, i32 4
  br label %244

244:                                              ; preds = %244, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.i.i
  %245 = atomicrmw volatile xchg ptr %243, i32 1 seq_cst, align 4
  %246 = icmp eq i32 %245, 1
  br i1 %246, label %244, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i:          ; preds = %244
  %247 = load atomic i64, ptr %237 acquire, align 8
  %248 = inttoptr i64 %247 to ptr
  %.not.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %247, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i, label %249, label %284

249:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i
  %250 = getelementptr inbounds %struct.ListManager, ptr %224, i64 0, i32 6
  %251 = load ptr, ptr %250, align 8
  %252 = getelementptr inbounds %struct.LLVMRuntime, ptr %251, i64 0, i32 1
  %253 = getelementptr inbounds %struct.LLVMRuntime, ptr %251, i64 0, i32 28
  %254 = atomicrmw volatile add ptr %253, i64 4096 seq_cst, align 8
  %255 = getelementptr inbounds %struct.LLVMRuntime, ptr %251, i64 0, i32 1, i32 2
  %256 = load i64, ptr %255, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %256, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i.i.i, label %277, label %257

257:                                              ; preds = %249
  %258 = getelementptr inbounds %struct.LLVMRuntime, ptr %251, i64 0, i32 26
  br label %259

259:                                              ; preds = %259, %257
  %260 = atomicrmw volatile xchg ptr %258, i32 1 seq_cst, align 4
  %261 = icmp eq i32 %260, 1
  br i1 %261, label %259, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i: ; preds = %259
  %262 = load ptr, ptr %252, align 8
  %263 = ptrtoint ptr %262 to i64
  %264 = getelementptr inbounds %struct.LLVMRuntime, ptr %251, i64 0, i32 1, i32 1
  %265 = load ptr, ptr %264, align 8
  %266 = ptrtoint ptr %265 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %263
  %267 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i.i.i, 4095
  %268 = or i64 %267, 4096
  %269 = add i64 %268, %263
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %269, %266
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i, label %270

270:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i
  %271 = add i64 %267, %263
  %272 = inttoptr i64 %271 to ptr
  %273 = getelementptr i8, ptr %262, i64 %267
  %274 = getelementptr inbounds i8, ptr %273, i64 4096
  store ptr %274, ptr %252, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i: ; preds = %270, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i.i.i ], [ %272, %270 ]
  %275 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i.i.i, true
  %276 = atomicrmw volatile xchg ptr %258, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %251, i1 noundef zeroext %275, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i

277:                                              ; preds = %249
  %278 = getelementptr inbounds %struct.LLVMRuntime, ptr %251, i64 0, i32 2
  %279 = load ptr, ptr %278, align 8
  %280 = getelementptr inbounds %struct.LLVMRuntime, ptr %251, i64 0, i32 6
  %281 = load ptr, ptr %280, align 8
  %282 = tail call noundef ptr %279(ptr noundef %281, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i: ; preds = %277, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i.i.i ], [ %282, %277 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %283 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %283, ptr %237 release, align 8
  br label %284

284:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %248, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i.i.i ]
  %285 = and i32 %229, 511
  %286 = zext i32 %285 to i64
  %287 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i.i.i, i64 %286
  %288 = load atomic i64, ptr %287 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %288, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i.i.i, label %289, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i"

289:                                              ; preds = %284
  %290 = getelementptr inbounds %struct.ListManager, ptr %224, i64 0, i32 6
  %291 = load ptr, ptr %290, align 8
  %292 = getelementptr inbounds %struct.LLVMRuntime, ptr %291, i64 0, i32 1
  %293 = getelementptr inbounds %struct.ListManager, ptr %224, i64 0, i32 2
  %294 = load i64, ptr %293, align 8
  %295 = getelementptr inbounds %struct.ListManager, ptr %224, i64 0, i32 1
  %296 = load i64, ptr %295, align 8
  %297 = mul i64 %296, %294
  %298 = getelementptr inbounds %struct.LLVMRuntime, ptr %291, i64 0, i32 28
  %299 = atomicrmw volatile add ptr %298, i64 %297 seq_cst, align 8
  %300 = getelementptr inbounds %struct.LLVMRuntime, ptr %291, i64 0, i32 1, i32 2
  %301 = load i64, ptr %300, align 8
  %.not.i.i.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %301, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i, label %321, label %302

302:                                              ; preds = %289
  %303 = getelementptr inbounds %struct.LLVMRuntime, ptr %291, i64 0, i32 26
  br label %304

304:                                              ; preds = %304, %302
  %305 = atomicrmw volatile xchg ptr %303, i32 1 seq_cst, align 4
  %306 = icmp eq i32 %305, 1
  br i1 %306, label %304, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i: ; preds = %304
  %307 = load ptr, ptr %292, align 8
  %308 = ptrtoint ptr %307 to i64
  %309 = getelementptr inbounds %struct.LLVMRuntime, ptr %291, i64 0, i32 1, i32 1
  %310 = load ptr, ptr %309, align 8
  %311 = ptrtoint ptr %310 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %308
  %312 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i.i.i, 4095
  %313 = add i64 %312, %297
  %314 = add i64 %313, %308
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %314, %311
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i, label %315

315:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %316 = add i64 %312, %308
  %317 = inttoptr i64 %316 to ptr
  %318 = getelementptr inbounds i8, ptr %307, i64 %313
  store ptr %318, ptr %292, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i: ; preds = %315, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %317, %315 ]
  %319 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %320 = atomicrmw volatile xchg ptr %303, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %291, i1 noundef zeroext %319, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i

321:                                              ; preds = %289
  %322 = getelementptr inbounds %struct.LLVMRuntime, ptr %291, i64 0, i32 2
  %323 = load ptr, ptr %322, align 8
  %324 = getelementptr inbounds %struct.LLVMRuntime, ptr %291, i64 0, i32 6
  %325 = load ptr, ptr %324, align 8
  %326 = tail call noundef ptr %323(ptr noundef %325, i64 noundef %297, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i: ; preds = %321, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i.i.i ], [ %326, %321 ]
  %327 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %327, ptr %287 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i.i.i, %284
  %328 = atomicrmw volatile xchg ptr %243, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i:      ; preds = %210
  %329 = getelementptr inbounds %struct.ListManager, ptr %219, i64 0, i32 3
  %330 = load i32, ptr %329, align 8
  %331 = ashr i32 %217, %330
  %332 = sext i32 %331 to i64
  %333 = lshr i64 %332, 9
  %334 = getelementptr inbounds [256 x ptr], ptr %219, i64 0, i64 %333
  %335 = load atomic i64, ptr %334 acquire, align 8
  %.not.i.i.i.i.i.i.i.i = icmp ne i64 %335, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i.i.i.i.i)
  %336 = inttoptr i64 %335 to ptr
  %337 = and i64 %332, 511
  %338 = getelementptr inbounds ptr, ptr %336, i64 %337
  %339 = load atomic i64, ptr %338 acquire, align 8
  %340 = inttoptr i64 %339 to ptr
  %341 = getelementptr inbounds %struct.ListManager, ptr %219, i64 0, i32 1
  %342 = load i64, ptr %341, align 8
  %343 = load i32, ptr %329, align 8
  %notmask.i.i.i.i.i.i.i = shl nsw i32 -1, %343
  %344 = xor i32 %notmask.i.i.i.i.i.i.i, -1
  %345 = and i32 %217, %344
  %346 = sext i32 %345 to i64
  %347 = mul i64 %342, %346
  %348 = getelementptr inbounds i8, ptr %340, i64 %347
  %349 = load i32, ptr %348, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i: ; preds = %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i, %231
  %.0.i.i.i.i.i = phi i32 [ %349, %_ZN11ListManager3getIiEERT_i.exit.i.i.i.i.i ], [ %226, %231 ], [ %226, %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i.i.i ], [ %226, %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i.i.i" ]
  %350 = getelementptr inbounds %struct.NodeManager, ptr %215, i64 0, i32 7
  %351 = load ptr, ptr %350, align 8
  %352 = getelementptr inbounds %struct.ListManager, ptr %351, i64 0, i32 3
  %353 = load i32, ptr %352, align 8
  %354 = ashr i32 %.0.i.i.i.i.i, %353
  %355 = sext i32 %354 to i64
  %356 = lshr i64 %355, 9
  %357 = getelementptr inbounds [256 x ptr], ptr %351, i64 0, i64 %356
  %358 = load atomic i64, ptr %357 acquire, align 8
  %.not.i.i.i.i.i.i.i = icmp eq i64 %358, 0
  br i1 %.not.i.i.i.i.i.i.i, label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i", label %359

359:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i
  %360 = inttoptr i64 %358 to ptr
  %361 = and i64 %355, 511
  %362 = getelementptr inbounds ptr, ptr %360, i64 %361
  %363 = load atomic i64, ptr %362 acquire, align 8
  %364 = inttoptr i64 %363 to ptr
  br label %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i"

"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i":    ; preds = %359, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i
  %365 = phi ptr [ %364, %359 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i.i.i ]
  %366 = getelementptr inbounds %struct.ListManager, ptr %351, i64 0, i32 1
  %367 = load i64, ptr %366, align 8
  %368 = load i32, ptr %352, align 8
  %notmask.i.i.i.i.i.i = shl nsw i32 -1, %368
  %369 = xor i32 %notmask.i.i.i.i.i.i, -1
  %370 = and i32 %.0.i.i.i.i.i, %369
  %371 = sext i32 %370 to i64
  %372 = mul i64 %367, %371
  %373 = getelementptr inbounds i8, ptr %365, i64 %372
  %374 = ptrtoint ptr %373 to i64
  %375 = atomicrmw volatile xchg ptr %201, i64 %374 seq_cst, align 8
  br label %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i"

"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i": ; preds = %"_ZZ16Pointer_activateENK3$_5clEv.exit.i.i.i", %mutex_lock_i32.exit.i.i.i
  %376 = atomicrmw volatile xchg ptr %.0..0..0..0..0.2.i, i32 0 seq_cst, align 4
  br label %Pointer_activate.exit

Pointer_activate.exit:                            ; preds = %"_Z11locked_taskIZ16Pointer_activateE3$_5Z16Pointer_activateE3$_6EvPvRKT_RKT0_.exit.i", %true_block4
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %5)
  %377 = lshr i32 %131, 2
  %378 = and i32 %377, 1073741816
  %379 = zext i32 %378 to i64
  %380 = getelementptr i8, ptr %28, i64 %379
  %381 = getelementptr inbounds i8, ptr %380, i64 32
  %382 = load ptr, ptr %381, align 8
  %383 = icmp eq ptr %382, null
  br i1 %383, label %384, label %Pointer_lookup_element.exit

384:                                              ; preds = %Pointer_activate.exit
  %385 = load ptr, ptr %8, align 8
  %386 = getelementptr inbounds %struct.LLVMRuntime, ptr %385, i64 0, i32 15
  %387 = load ptr, ptr %386, align 8
  %388 = getelementptr inbounds ptr, ptr %387, i64 24
  %389 = load ptr, ptr %388, align 8
  br label %Pointer_lookup_element.exit

Pointer_lookup_element.exit:                      ; preds = %384, %Pointer_activate.exit
  %.0.i = phi ptr [ %389, %384 ], [ %382, %Pointer_activate.exit ]
  %390 = and i32 %131, 31
  %391 = getelementptr inbounds i8, ptr %.0.i, i64 32
  %392 = shl nuw i32 1, %390
  %393 = atomicrmw volatile or ptr %391, i32 %392 seq_cst, align 4
  br label %after_if3

false_block5:                                     ; preds = %true_block1
  %394 = load ptr, ptr %65, align 8
  %395 = getelementptr i64, ptr %394, i64 9
  %396 = atomicrmw add ptr %395, i64 1 seq_cst, align 8
  br label %after_if3
}

; Function Attrs: argmemonly mustprogress nofree norecurse nosync nounwind willreturn
define internal fastcc void @S27_refine_coordinates(ptr nocapture readonly %0, ptr nocapture writeonly %1, i32 %2) unnamed_addr #2 {
entry:
  %3 = and i32 %2, 3
  %4 = load i32, ptr %0, align 4
  %5 = shl i32 %4, 2
  %6 = or i32 %5, %3
  store i32 %6, ptr %1, align 4
  %7 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 1
  %8 = load i32, ptr %7, align 4
  %9 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 1
  store i32 %8, ptr %9, align 4
  %10 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 2
  %11 = load i32, ptr %10, align 4
  %12 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 2
  store i32 %11, ptr %12, align 4
  %13 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 3
  %14 = load i32, ptr %13, align 4
  %15 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 3
  store i32 %14, ptr %15, align 4
  %16 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 4
  %17 = load i32, ptr %16, align 4
  %18 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 4
  store i32 %17, ptr %18, align 4
  %19 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 5
  %20 = load i32, ptr %19, align 4
  %21 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 5
  store i32 %20, ptr %21, align 4
  %22 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 6
  %23 = load i32, ptr %22, align 4
  %24 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 6
  store i32 %23, ptr %24, align 4
  %25 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 7
  %26 = load i32, ptr %25, align 4
  %27 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 7
  store i32 %26, ptr %27, align 4
  %28 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 8
  %29 = load i32, ptr %28, align 4
  %30 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 8
  store i32 %29, ptr %30, align 4
  %31 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 9
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 9
  store i32 %32, ptr %33, align 4
  %34 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 10
  %35 = load i32, ptr %34, align 4
  %36 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 10
  store i32 %35, ptr %36, align 4
  %37 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 11
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 11
  store i32 %38, ptr %39, align 4
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #3

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn writeonly
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #4

; Function Attrs: noinline nounwind optnone uwtable
define internal fastcc void @taichi_assert_format(ptr noundef %0, i1 noundef zeroext %1, ptr noundef %2) unnamed_addr #5 {
  %4 = alloca ptr, align 8
  %5 = alloca i8, align 1
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca ptr, align 8
  %9 = alloca %class.anon, align 8
  store ptr %0, ptr %4, align 8
  %10 = zext i1 %1 to i8
  store i8 %10, ptr %5, align 1
  store ptr %2, ptr %6, align 8
  store i32 0, ptr %7, align 4
  store ptr null, ptr %8, align 8
  %11 = load i8, ptr %5, align 1
  %12 = trunc i8 %11 to i1
  %13 = zext i1 %12 to i32
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %15, label %16

15:                                               ; preds = %3
  br label %69

16:                                               ; preds = %3
  %17 = load ptr, ptr %4, align 8
  %18 = getelementptr inbounds %struct.LLVMRuntime, ptr %17, i32 0, i32 24
  %19 = load i64, ptr %18, align 8
  %20 = icmp ne i64 %19, 0
  br i1 %20, label %69, label %21

21:                                               ; preds = %16
  %22 = load ptr, ptr %4, align 8
  %23 = getelementptr inbounds %struct.LLVMRuntime, ptr %22, i32 0, i32 23
  %24 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 0
  store ptr %4, ptr %24, align 8
  %25 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 1
  store ptr %6, ptr %25, align 8
  %26 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 2
  store ptr %7, ptr %26, align 8
  %27 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 3
  store ptr %8, ptr %27, align 8
  br label %28

28:                                               ; preds = %28, %21
  %29 = atomicrmw volatile xchg ptr %23, i32 1 seq_cst, align 4
  %30 = icmp eq i32 %29, 1
  br i1 %30, label %28, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i:                        ; preds = %28
  %31 = load ptr, ptr %9, align 8
  %32 = load ptr, ptr %31, align 8
  %33 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 24
  %34 = load i64, ptr %33, align 8
  %.not.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i, label %35, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

35:                                               ; preds = %mutex_lock_i32.exit.i.i.i
  store i64 1, ptr %33, align 8
  %36 = load ptr, ptr %9, align 8
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr inbounds %struct.LLVMRuntime, ptr %37, i64 0, i32 21
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %38, i8 0, i64 2048, i1 false)
  %39 = load ptr, ptr %9, align 8
  %40 = load ptr, ptr %39, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 21
  %42 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 1
  %43 = load ptr, ptr %42, align 8
  %44 = load ptr, ptr %43, align 8
  %45 = load i8, ptr %44, align 1
  %.not5.i.i.i.i.i = icmp eq i8 %45, 0
  br i1 %.not5.i.i.i.i.i, label %taichi_strlen.exit.thread.i.i.i.i, label %.lr.ph.i.i.i.i.i.preheader

.lr.ph.i.i.i.i.i.preheader:                       ; preds = %35
  br label %.lr.ph.i.i.i.i.i

.lr.ph.i.i.i.i.i:                                 ; preds = %.lr.ph.i.i.i.i.i, %.lr.ph.i.i.i.i.i.preheader
  %.07.i.i.i.i.i = phi ptr [ %47, %.lr.ph.i.i.i.i.i ], [ %44, %.lr.ph.i.i.i.i.i.preheader ]
  %.046.i.i.i.i.i = phi i64 [ %46, %.lr.ph.i.i.i.i.i ], [ 0, %.lr.ph.i.i.i.i.i.preheader ]
  %46 = add i64 %.046.i.i.i.i.i, 1
  %47 = getelementptr inbounds i8, ptr %.07.i.i.i.i.i, i64 1
  %48 = load i8, ptr %47, align 1
  %.not.i.i.i.i.i = icmp eq i8 %48, 0
  br i1 %.not.i.i.i.i.i, label %taichi_strlen.exit.i.i.i.i, label %.lr.ph.i.i.i.i.i, !llvm.loop !13

taichi_strlen.exit.i.i.i.i:                       ; preds = %.lr.ph.i.i.i.i.i
  %.lcssa = phi i64 [ %46, %.lr.ph.i.i.i.i.i ]
  %49 = call i64 @llvm.umin.i64(i64 %.lcssa, i64 2047)
  br label %taichi_strlen.exit.thread.i.i.i.i

taichi_strlen.exit.thread.i.i.i.i:                ; preds = %taichi_strlen.exit.i.i.i.i, %35
  %50 = phi i64 [ 0, %35 ], [ %49, %taichi_strlen.exit.i.i.i.i ]
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %41, ptr nonnull align 1 %44, i64 %50, i1 false)
  %51 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 2
  %52 = load ptr, ptr %51, align 8
  %53 = load i32, ptr %52, align 4
  %54 = icmp sgt i32 %53, 0
  br i1 %54, label %.lr.ph.i.i.i.i, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

.lr.ph.i.i.i.i:                                   ; preds = %taichi_strlen.exit.thread.i.i.i.i
  %55 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 3
  br label %56

56:                                               ; preds = %56, %.lr.ph.i.i.i.i
  %indvars.iv.i.i.i.i = phi i64 [ 0, %.lr.ph.i.i.i.i ], [ %indvars.iv.next.i.i.i.i, %56 ]
  %57 = load ptr, ptr %55, align 8
  %58 = load ptr, ptr %57, align 8
  %59 = getelementptr inbounds i64, ptr %58, i64 %indvars.iv.i.i.i.i
  %60 = load i64, ptr %59, align 8
  %61 = load ptr, ptr %9, align 8
  %62 = load ptr, ptr %61, align 8
  %63 = getelementptr inbounds %struct.LLVMRuntime, ptr %62, i64 0, i32 22, i64 %indvars.iv.i.i.i.i
  store i64 %60, ptr %63, align 8
  %indvars.iv.next.i.i.i.i = add nuw nsw i64 %indvars.iv.i.i.i.i, 1
  %64 = load ptr, ptr %51, align 8
  %65 = load i32, ptr %64, align 4
  %66 = sext i32 %65 to i64
  %67 = icmp slt i64 %indvars.iv.next.i.i.i.i, %66
  br i1 %67, label %56, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", !llvm.loop !14

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit": ; preds = %56
  br label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit": ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", %taichi_strlen.exit.thread.i.i.i.i, %mutex_lock_i32.exit.i.i.i
  %68 = atomicrmw volatile xchg ptr %23, i32 0 seq_cst, align 4
  br label %69

69:                                               ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit", %16, %15
  ret void
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_struct_for_block_helper(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #6 {
_ZN11ListManager3getI7ElementEERT_i.exit:
  %3 = alloca %struct.RuntimeContext.829, align 8
  %4 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 4
  %5 = load i32, ptr %4, align 4
  %6 = sdiv i32 %2, %5
  %7 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  %8 = load i32, ptr %7, align 8
  %9 = sdiv i32 %8, %5
  %10 = srem i32 %2, %5
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  %12 = load ptr, ptr %11, align 8
  %13 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %14 = load i32, ptr %13, align 8
  %15 = ashr i32 %6, %14
  %16 = sext i32 %15 to i64
  %17 = lshr i64 %16, 9
  %18 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %17
  %19 = load atomic i64, ptr %18 acquire, align 8
  %.not.i.i.i = icmp ne i64 %19, 0
  tail call void @llvm.assume(i1 %.not.i.i.i)
  %20 = inttoptr i64 %19 to ptr
  %21 = and i64 %16, 511
  %22 = getelementptr inbounds ptr, ptr %20, i64 %21
  %23 = load atomic i64, ptr %22 acquire, align 8
  %24 = inttoptr i64 %23 to ptr
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %26 = load i64, ptr %25, align 8
  %27 = load i32, ptr %13, align 8
  %notmask.i.i = shl nsw i32 -1, %27
  %28 = xor i32 %notmask.i.i, -1
  %29 = and i32 %6, %28
  %30 = sext i32 %29 to i64
  %31 = mul i64 %26, %30
  %32 = getelementptr inbounds i8, ptr %24, i64 %31
  %33 = getelementptr inbounds %0, ptr %32, i64 0, i32 1
  %34 = load i32, ptr %33, align 8
  %35 = mul nsw i32 %10, %9
  %36 = add nsw i32 %34, %35
  %37 = add nsw i32 %10, 1
  %38 = mul nsw i32 %37, %9
  %39 = add nsw i32 %34, %38
  %40 = getelementptr inbounds %0, ptr %32, i64 0, i32 1, i64 1
  %41 = load i32, ptr %40, align 4
  %42 = tail call i32 @llvm.smin.i32(i32 %41, i32 %39)
  %43 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  %44 = load i64, ptr %43, align 8
  %45 = alloca i8, i64 %44, align 8
  %46 = load ptr, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %3, ptr noundef nonnull align 8 dereferenceable(32) %46, i64 32, i1 false)
  %47 = getelementptr inbounds %struct.RuntimeContext.829, ptr %3, i64 0, i32 2
  store i32 %1, ptr %47, align 8
  %48 = icmp slt i32 %36, %42
  br i1 %48, label %49, label %75

49:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit
  %50 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = load ptr, ptr %11, align 8
  %53 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 3
  %54 = load i32, ptr %53, align 8
  %55 = ashr i32 %6, %54
  %56 = sext i32 %55 to i64
  %57 = lshr i64 %56, 9
  %58 = getelementptr inbounds [256 x ptr], ptr %52, i64 0, i64 %57
  %59 = load atomic i64, ptr %58 acquire, align 8
  %.not.i.i.i24 = icmp eq i64 %59, 0
  br i1 %.not.i.i.i24, label %_ZN11ListManager3getI7ElementEERT_i.exit26, label %60

60:                                               ; preds = %49
  %61 = inttoptr i64 %59 to ptr
  %62 = and i64 %56, 511
  %63 = getelementptr inbounds ptr, ptr %61, i64 %62
  %64 = load atomic i64, ptr %63 acquire, align 8
  %65 = inttoptr i64 %64 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit26

_ZN11ListManager3getI7ElementEERT_i.exit26:       ; preds = %60, %49
  %66 = phi ptr [ %65, %60 ], [ null, %49 ]
  %67 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 1
  %68 = load i64, ptr %67, align 8
  %69 = load i32, ptr %53, align 8
  %notmask.i.i25 = shl nsw i32 -1, %69
  %70 = xor i32 %notmask.i.i25, -1
  %71 = and i32 %6, %70
  %72 = sext i32 %71 to i64
  %73 = mul i64 %68, %72
  %74 = getelementptr inbounds i8, ptr %66, i64 %73
  call void %51(ptr noundef nonnull %3, ptr noundef nonnull %45, ptr noundef nonnull %74, i32 noundef %36, i32 noundef %42) #1
  br label %75

75:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit26, %_ZN11ListManager3getI7ElementEERT_i.exit
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i64 @llvm.umin.i64(i64, i64) #7

; Function Attrs: inaccessiblememonly nocallback nofree nosync nounwind willreturn
declare void @llvm.assume(i1 noundef) #8

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #7

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #9

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #9

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { argmemonly mustprogress nofree norecurse nosync nounwind willreturn }
attributes #3 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #4 = { argmemonly mustprogress nocallback nofree nounwind willreturn writeonly }
attributes #5 = { noinline nounwind optnone uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #8 = { inaccessiblememonly nocallback nofree nosync nounwind willreturn }
attributes #9 = { argmemonly nocallback nofree nosync nounwind willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !12}
!12 = !{!"llvm.loop.unroll.disable"}
!13 = distinct !{!13, !7}
!14 = distinct !{!14, !7}
