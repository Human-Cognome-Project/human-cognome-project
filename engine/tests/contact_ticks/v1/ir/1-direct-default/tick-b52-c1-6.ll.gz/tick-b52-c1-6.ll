; ModuleID = 'kernel'
source_filename = "kernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%0 = type { ptr, [2 x i32], %struct.PhysicalCoordinates.2038 }
%1 = type { %2, %2 }
%2 = type { [4 x i64], [4 x ptr] }
%struct.RuntimeContext.2041 = type { ptr, ptr, i32, ptr }
%struct.LLVMRuntime = type { %struct.PreallocatedMemoryChunk, %struct.PreallocatedMemoryChunk, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, [2048 x i8], [32 x i64], i32, i64, ptr, i32, i32, i64 }
%struct.PreallocatedMemoryChunk = type { ptr, ptr, i64 }
%struct.ListManager = type { [256 x ptr], i64, i64, i32, i32, i32, ptr }
%struct.PhysicalCoordinates.2038 = type { [12 x i32] }
%struct.cpu_block_task_helper_context = type { ptr, ptr, ptr, i32, i32, i64 }
%class.anon = type { ptr, ptr, ptr, ptr }

@.str = private unnamed_addr constant [28 x i8] c"Out of pre-allocated memory\00", align 1
@.str.2 = private unnamed_addr constant [28 x i8] c"List manager out of chunks.\00", align 1

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @field_publish_centroids_55_kernel_0_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.2041, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 57
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @field_publish_centroids_55_kernel_1_listgen_S57pointer(ptr %context) local_unnamed_addr #1 {
.lr.ph.i:
  %.sroa.2.i = alloca { [2 x i32], %struct.PhysicalCoordinates.2038 }, align 8
  %0 = alloca %0, align 8
  %1 = getelementptr inbounds %struct.RuntimeContext.2041, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  call void @llvm.lifetime.start.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 53
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %4, i64 57
  %8 = load ptr, ptr %7, align 8
  %9 = load atomic i64, ptr %6 acquire, align 8
  %.not.i.i.i.i = icmp ne i64 %9, 0
  tail call void @llvm.assume(i1 %.not.i.i.i.i)
  %10 = inttoptr i64 %9 to ptr
  %11 = load atomic i64, ptr %10 acquire, align 8
  %12 = inttoptr i64 %11 to ptr
  %.sroa.0.0.copyload.i = load ptr, ptr %12, align 8
  %.sroa.2.0..sroa_idx.i = getelementptr inbounds i8, ptr %12, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.i, ptr noundef nonnull align 8 dereferenceable(56) %.sroa.2.0..sroa_idx.i, i64 56, i1 false)
  %getch.i = getelementptr %1, ptr %.sroa.0.0.copyload.i, i64 0, i32 1
  %13 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %.sroa.2.16.sroa_idx.i = getelementptr inbounds i8, ptr %.sroa.2.i, i64 8
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %16 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 4
  %17 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 6
  %18 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 2
  %19 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  store ptr %getch.i, ptr %0, align 8
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %0, i64 8
  store <2 x i32> <i32 0, i32 4>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %13, ptr noundef nonnull align 8 dereferenceable(48) %.sroa.2.16.sroa_idx.i, i64 48, i1 false)
  %20 = atomicrmw volatile add ptr %14, i32 1 seq_cst, align 4
  %21 = load i32, ptr %15, align 8
  %22 = ashr i32 %20, %21
  %23 = icmp ugt i32 %22, 131071
  br i1 %23, label %24, label %26

24:                                               ; preds = %.lr.ph.i
  %25 = load ptr, ptr %17, align 8
  tail call fastcc void @taichi_assert_format(ptr noundef %25, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

26:                                               ; preds = %.lr.ph.i
  %27 = zext i32 %22 to i64
  %28 = lshr i64 %27, 9
  %29 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %28
  %30 = load atomic i64, ptr %29 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %30, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %26
  %31 = inttoptr i64 %30 to ptr
  %32 = and i64 %27, 511
  %33 = getelementptr inbounds ptr, ptr %31, i64 %32
  %34 = load atomic i64, ptr %33 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %26
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %35 = atomicrmw volatile xchg ptr %16, i32 1 seq_cst, align 4
  %36 = icmp eq i32 %35, 1
  br i1 %36, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %37 = load atomic i64, ptr %29 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %37, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %39, label %73

39:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %40 = load ptr, ptr %17, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1
  %42 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 28
  %43 = atomicrmw volatile add ptr %42, i64 4096 seq_cst, align 8
  %44 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 2
  %45 = load i64, ptr %44, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %45, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %66, label %46

46:                                               ; preds = %39
  %47 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 26
  br label %48

48:                                               ; preds = %48, %46
  %49 = atomicrmw volatile xchg ptr %47, i32 1 seq_cst, align 4
  %50 = icmp eq i32 %49, 1
  br i1 %50, label %48, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %48
  %51 = load ptr, ptr %41, align 8
  %52 = ptrtoint ptr %51 to i64
  %53 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 1, i32 1
  %54 = load ptr, ptr %53, align 8
  %55 = ptrtoint ptr %54 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %52
  %56 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %57 = or i64 %56, 4096
  %58 = add i64 %57, %52
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %58, %55
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %59

59:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %60 = add i64 %56, %52
  %61 = inttoptr i64 %60 to ptr
  %62 = getelementptr i8, ptr %51, i64 %56
  %63 = getelementptr inbounds i8, ptr %62, i64 4096
  store ptr %63, ptr %41, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %59, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %61, %59 ]
  %64 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %65 = atomicrmw volatile xchg ptr %47, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %40, i1 noundef zeroext %64, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

66:                                               ; preds = %39
  %67 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 2
  %68 = load ptr, ptr %67, align 8
  %69 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 6
  %70 = load ptr, ptr %69, align 8
  %71 = tail call noundef ptr %68(ptr noundef %70, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %66, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %71, %66 ]
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %72 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %72, ptr %29 release, align 8
  br label %73

73:                                               ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %38, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %74 = and i32 %22, 511
  %75 = zext i32 %74 to i64
  %76 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %75
  %77 = load atomic i64, ptr %76 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %77, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %78, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

78:                                               ; preds = %73
  %79 = load ptr, ptr %17, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1
  %81 = load i64, ptr %18, align 8
  %82 = load i64, ptr %19, align 8
  %83 = mul i64 %82, %81
  %84 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 28
  %85 = atomicrmw volatile add ptr %84, i64 %83 seq_cst, align 8
  %86 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 2
  %87 = load i64, ptr %86, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %87, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %107, label %88

88:                                               ; preds = %78
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 26
  br label %90

90:                                               ; preds = %90, %88
  %91 = atomicrmw volatile xchg ptr %89, i32 1 seq_cst, align 4
  %92 = icmp eq i32 %91, 1
  br i1 %92, label %90, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %90
  %93 = load ptr, ptr %80, align 8
  %94 = ptrtoint ptr %93 to i64
  %95 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 1, i32 1
  %96 = load ptr, ptr %95, align 8
  %97 = ptrtoint ptr %96 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %94
  %98 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %99 = add i64 %98, %83
  %100 = add i64 %99, %94
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %100, %97
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %101

101:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %102 = add i64 %98, %94
  %103 = inttoptr i64 %102 to ptr
  %104 = getelementptr inbounds i8, ptr %93, i64 %99
  store ptr %104, ptr %80, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %101, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %103, %101 ]
  %105 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %106 = atomicrmw volatile xchg ptr %89, i32 0 seq_cst, align 4
  tail call fastcc void @taichi_assert_format(ptr noundef nonnull %79, i1 noundef zeroext %105, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

107:                                              ; preds = %78
  %108 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 2
  %109 = load ptr, ptr %108, align 8
  %110 = getelementptr inbounds %struct.LLVMRuntime, ptr %79, i64 0, i32 6
  %111 = load ptr, ptr %110, align 8
  %112 = tail call noundef ptr %109(ptr noundef %111, i64 noundef %83, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %107, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %112, %107 ]
  %113 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %113, ptr %76 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %73
  %114 = atomicrmw volatile xchg ptr %16, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %24
  %115 = load i32, ptr %15, align 8
  %116 = ashr i32 %20, %115
  %117 = sext i32 %116 to i64
  %118 = lshr i64 %117, 9
  %119 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %118
  %120 = load atomic i64, ptr %119 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %120, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %121

121:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %122 = inttoptr i64 %120 to ptr
  %123 = and i64 %117, 511
  %124 = getelementptr inbounds ptr, ptr %122, i64 %123
  %125 = load atomic i64, ptr %124 acquire, align 8
  %126 = inttoptr i64 %125 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %121, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %127 = phi ptr [ %126, %121 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %128 = load i64, ptr %19, align 8
  %129 = load i32, ptr %15, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %129
  %130 = xor i32 %notmask.i.i.i.i, -1
  %131 = and i32 %20, %130
  %132 = sext i32 %131 to i64
  %133 = mul i64 %128, %132
  %134 = getelementptr inbounds i8, ptr %127, i64 %133
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %134, ptr nonnull align 8 %0, i64 %128, i1 false)
  call void @llvm.lifetime.end.p0(i64 56, ptr nonnull %.sroa.2.i)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define void @field_publish_centroids_55_kernel_2_serial(ptr %context) local_unnamed_addr #0 {
entry:
  %0 = getelementptr inbounds %struct.RuntimeContext.2041, ptr %context, i64 0, i32 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds %struct.LLVMRuntime, ptr %1, i64 0, i32 13
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds ptr, ptr %3, i64 58
  %5 = load ptr, ptr %4, align 8
  %6 = getelementptr inbounds %struct.ListManager, ptr %5, i64 0, i32 5
  store i32 0, ptr %6, align 8
  ret void
}

; Function Attrs: nounwind
define void @field_publish_centroids_55_kernel_3_listgen_S58bitmasked(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %0, align 8
  %1 = alloca %struct.PhysicalCoordinates.2038, align 4
  %2 = alloca %0, align 8
  %3 = getelementptr inbounds %struct.RuntimeContext.2041, ptr %context, i64 0, i32 1
  %4 = load ptr, ptr %3, align 8
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %2)
  %5 = getelementptr inbounds %struct.LLVMRuntime, ptr %4, i64 0, i32 13
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds ptr, ptr %6, i64 57
  %8 = load ptr, ptr %7, align 8
  %9 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 5
  %10 = load i32, ptr %9, align 8
  %11 = getelementptr inbounds ptr, ptr %6, i64 58
  %12 = load ptr, ptr %11, align 8
  %13 = icmp sgt i32 %10, 0
  br i1 %13, label %.lr.ph61.i, label %element_listgen_nonroot.exit

.lr.ph61.i:                                       ; preds = %entry
  %14 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 3
  %15 = getelementptr inbounds %struct.ListManager, ptr %8, i64 0, i32 1
  %16 = getelementptr inbounds %0, ptr %0, i64 0, i32 1
  %17 = getelementptr inbounds %0, ptr %0, i64 0, i32 1, i64 1
  %18 = getelementptr inbounds %0, ptr %0, i64 0, i32 2
  %19 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %20 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 5
  %21 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %22 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 4
  %23 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 6
  %24 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 2
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %.8.sroa_idx10 = getelementptr inbounds i8, ptr %2, i64 8
  br label %26

26:                                               ; preds = %._crit_edge.i, %.lr.ph61.i
  %.04359.i = phi i32 [ 0, %.lr.ph61.i ], [ %172, %._crit_edge.i ]
  %27 = load i32, ptr %14, align 8
  %28 = lshr i32 %.04359.i, %27
  %29 = sext i32 %28 to i64
  %30 = lshr i64 %29, 9
  %31 = getelementptr inbounds [256 x ptr], ptr %8, i64 0, i64 %30
  %32 = load atomic i64, ptr %31 acquire, align 8
  %.not.i.i.i.i = icmp eq i64 %32, 0
  br i1 %.not.i.i.i.i, label %_ZN11ListManager3getI7ElementEERT_i.exit.i, label %33

33:                                               ; preds = %26
  %34 = inttoptr i64 %32 to ptr
  %35 = and i64 %29, 511
  %36 = getelementptr inbounds ptr, ptr %34, i64 %35
  %37 = load atomic i64, ptr %36 acquire, align 8
  %38 = inttoptr i64 %37 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit.i

_ZN11ListManager3getI7ElementEERT_i.exit.i:       ; preds = %33, %26
  %39 = phi ptr [ %38, %33 ], [ null, %26 ]
  %40 = load i64, ptr %15, align 8
  %41 = load i32, ptr %14, align 8
  %notmask.i.i.i = shl nsw i32 -1, %41
  %42 = xor i32 %notmask.i.i.i, -1
  %43 = and i32 %.04359.i, %42
  %44 = zext i32 %43 to i64
  %45 = mul i64 %40, %44
  %46 = getelementptr inbounds i8, ptr %39, i64 %45
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %0, ptr noundef nonnull align 8 dereferenceable(64) %46, i64 64, i1 false)
  %47 = load i32, ptr %16, align 8
  %48 = load i32, ptr %17, align 4
  %49 = icmp slt i32 %47, %48
  br i1 %49, label %.lr.ph58.i.preheader, label %._crit_edge.i

.lr.ph58.i.preheader:                             ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit.i
  br label %.lr.ph58.i

.lr.ph58.i:                                       ; preds = %.loopexit.i, %.lr.ph58.i.preheader
  %.04457.i = phi i32 [ %171, %.loopexit.i ], [ %47, %.lr.ph58.i.preheader ]
  call fastcc void @S57_refine_coordinates(ptr noundef nonnull %18, ptr noundef nonnull %1, i32 noundef %.04457.i) #1
  %50 = load ptr, ptr %0, align 8
  %51 = shl i32 %.04457.i, 3
  %52 = sext i32 %51 to i64
  %53 = getelementptr i8, ptr %50, i64 %52
  %54 = getelementptr inbounds i8, ptr %53, i64 32
  %55 = load ptr, ptr %54, align 8
  %.not = icmp eq ptr %55, null
  br i1 %.not, label %.loopexit.i, label %.lr.ph.i

.lr.ph.i:                                         ; preds = %.lr.ph58.i
  store ptr %55, ptr %2, align 8
  store <2 x i32> <i32 0, i32 32>, ptr %.8.sroa_idx10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %19, ptr noundef nonnull align 4 dereferenceable(48) %1, i64 48, i1 false)
  %56 = atomicrmw volatile add ptr %20, i32 1 seq_cst, align 4
  %57 = load i32, ptr %21, align 8
  %58 = ashr i32 %56, %57
  %59 = icmp ugt i32 %58, 131071
  br i1 %59, label %60, label %62

60:                                               ; preds = %.lr.ph.i
  %61 = load ptr, ptr %23, align 8
  call fastcc void @taichi_assert_format(ptr noundef %61, i1 noundef zeroext false, ptr noundef nonnull @.str.2)
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

62:                                               ; preds = %.lr.ph.i
  %63 = zext i32 %58 to i64
  %64 = lshr i64 %63, 9
  %65 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %64
  %66 = load atomic i64, ptr %65 acquire, align 8
  %.not.i.i.i.i.i.i = icmp eq i64 %66, 0
  br i1 %.not.i.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i:      ; preds = %62
  %67 = inttoptr i64 %66 to ptr
  %68 = and i64 %63, 511
  %69 = getelementptr inbounds ptr, ptr %67, i64 %68
  %70 = load atomic i64, ptr %69 acquire, align 8
  %.not.i.i.i.i.i = icmp eq i64 %70, 0
  br i1 %.not.i.i.i.i.i, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader, label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader: ; preds = %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %62
  br label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i

_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i: ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i.preheader
  %71 = atomicrmw volatile xchg ptr %22, i32 1 seq_cst, align 4
  %72 = icmp eq i32 %71, 1
  br i1 %72, label %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i:              ; preds = %_ZN11ListManager9get_chunkEi.exit.thread.i.i.i.i.i
  %73 = load atomic i64, ptr %65 acquire, align 8
  %74 = inttoptr i64 %73 to ptr
  %.not.i.i.i.i.i.i.i.i.i = icmp eq i64 %73, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i, label %75, label %109

75:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %76 = load ptr, ptr %23, align 8
  %77 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1
  %78 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 28
  %79 = atomicrmw volatile add ptr %78, i64 4096 seq_cst, align 8
  %80 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 2
  %81 = load i64, ptr %80, align 8
  %.not.i11.i.i.i.i.i.i.i.i.i = icmp eq i64 %81, 0
  br i1 %.not.i11.i.i.i.i.i.i.i.i.i, label %102, label %82

82:                                               ; preds = %75
  %83 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 26
  br label %84

84:                                               ; preds = %84, %82
  %85 = atomicrmw volatile xchg ptr %83, i32 1 seq_cst, align 4
  %86 = icmp eq i32 %85, 1
  br i1 %86, label %84, label %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i: ; preds = %84
  %87 = load ptr, ptr %77, align 8
  %88 = ptrtoint ptr %87 to i64
  %89 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 1, i32 1
  %90 = load ptr, ptr %89, align 8
  %91 = ptrtoint ptr %90 to i64
  %notlhs.i.i12.i.i.i.i.i.i.i.i.i = sub i64 0, %88
  %92 = and i64 %notlhs.i.i12.i.i.i.i.i.i.i.i.i, 4095
  %93 = or i64 %92, 4096
  %94 = add i64 %93, %88
  %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i = icmp ugt i64 %94, %91
  br i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i, label %95

95:                                               ; preds = %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %96 = add i64 %92, %88
  %97 = inttoptr i64 %96 to ptr
  %98 = getelementptr i8, ptr %87, i64 %92
  %99 = getelementptr inbounds i8, ptr %98, i64 4096
  store ptr %99, ptr %77, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i: ; preds = %95, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i
  %.0.i.i15.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i14.i.i.i.i.i.i.i.i.i ], [ %97, %95 ]
  %100 = xor i1 %.not.i.i.i.i.i.i13.i.i.i.i.i.i.i.i.i, true
  %101 = atomicrmw volatile xchg ptr %83, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %76, i1 noundef zeroext %100, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

102:                                              ; preds = %75
  %103 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 2
  %104 = load ptr, ptr %103, align 8
  %105 = getelementptr inbounds %struct.LLVMRuntime, ptr %76, i64 0, i32 6
  %106 = load ptr, ptr %105, align 8
  %107 = call noundef ptr %104(ptr noundef %106, i64 noundef 4096, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i: ; preds = %102, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i
  %.0.i17.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i15.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i16.i.i.i.i.i.i.i.i.i ], [ %107, %102 ]
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.0.i17.i.i.i.i.i.i.i.i.i, i8 0, i64 4096, i1 false)
  %108 = ptrtoint ptr %.0.i17.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %108, ptr %65 release, align 8
  br label %109

109:                                              ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i = phi ptr [ %74, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i ], [ %.0.i17.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit18.i.i.i.i.i.i.i.i.i ]
  %110 = and i32 %58, 511
  %111 = zext i32 %110 to i64
  %112 = getelementptr inbounds ptr, ptr %.0.i.i.i.i.i.i.i.i.i, i64 %111
  %113 = load atomic i64, ptr %112 acquire, align 8
  %.not10.i.i.i.i.i.i.i.i.i = icmp eq i64 %113, 0
  br i1 %.not10.i.i.i.i.i.i.i.i.i, label %114, label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

114:                                              ; preds = %109
  %115 = load ptr, ptr %23, align 8
  %116 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1
  %117 = load i64, ptr %24, align 8
  %118 = load i64, ptr %25, align 8
  %119 = mul i64 %118, %117
  %120 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 28
  %121 = atomicrmw volatile add ptr %120, i64 %119 seq_cst, align 8
  %122 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 2
  %123 = load i64, ptr %122, align 8
  %.not.i.i.i.i.i.i.i.i.i.i = icmp eq i64 %123, 0
  br i1 %.not.i.i.i.i.i.i.i.i.i.i, label %143, label %124

124:                                              ; preds = %114
  %125 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 26
  br label %126

126:                                              ; preds = %126, %124
  %127 = atomicrmw volatile xchg ptr %125, i32 1 seq_cst, align 4
  %128 = icmp eq i32 %127, 1
  br i1 %128, label %126, label %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i:  ; preds = %126
  %129 = load ptr, ptr %116, align 8
  %130 = ptrtoint ptr %129 to i64
  %131 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 1, i32 1
  %132 = load ptr, ptr %131, align 8
  %133 = ptrtoint ptr %132 to i64
  %notlhs.i.i.i.i.i.i.i.i.i.i.i = sub i64 0, %130
  %134 = and i64 %notlhs.i.i.i.i.i.i.i.i.i.i.i, 4095
  %135 = add i64 %134, %119
  %136 = add i64 %135, %130
  %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ugt i64 %136, %133
  br i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i, label %137

137:                                              ; preds = %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %138 = add i64 %134, %130
  %139 = inttoptr i64 %138 to ptr
  %140 = getelementptr inbounds i8, ptr %129, i64 %135
  store ptr %140, ptr %116, align 8
  br label %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i: ; preds = %137, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i.i = phi ptr [ null, %mutex_lock_i32.exit.i.i.i.i.i.i.i.i.i.i.i.i.i.i ], [ %139, %137 ]
  %141 = xor i1 %.not.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i, true
  %142 = atomicrmw volatile xchg ptr %125, i32 0 seq_cst, align 4
  call fastcc void @taichi_assert_format(ptr noundef nonnull %115, i1 noundef zeroext %141, ptr noundef nonnull @.str)
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

143:                                              ; preds = %114
  %144 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 2
  %145 = load ptr, ptr %144, align 8
  %146 = getelementptr inbounds %struct.LLVMRuntime, ptr %115, i64 0, i32 6
  %147 = load ptr, ptr %146, align 8
  %148 = call noundef ptr %145(ptr noundef %147, i64 noundef %119, i64 noundef 4096) #1
  br label %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i

_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i: ; preds = %143, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i
  %.0.i.i.i.i.i.i.i.i.i.i = phi ptr [ %.0.i.i.i.i.i.i.i.i.i.i.i, %_ZN11LLVMRuntime29allocate_from_reserved_memoryER23PreallocatedMemoryChunkmm.exit.i.i.i.i.i.i.i.i.i.i ], [ %148, %143 ]
  %149 = ptrtoint ptr %.0.i.i.i.i.i.i.i.i.i.i to i64
  store atomic i64 %149, ptr %112 release, align 8
  br label %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i"

"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i": ; preds = %_ZN11LLVMRuntime16allocate_alignedER23PreallocatedMemoryChunkmmb.exit.i.i.i.i.i.i.i.i.i, %109
  %150 = atomicrmw volatile xchg ptr %22, i32 0 seq_cst, align 4
  br label %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i

_ZN11ListManager19reserve_new_elementEv.exit.i.i.i: ; preds = %"_Z11locked_taskIZN11ListManager11touch_chunkEiE3$_8EvPvRKT_.exit.i.i.i.i.i", %_ZN11ListManager9get_chunkEi.exit.i.i.i.i.i, %60
  %151 = load i32, ptr %21, align 8
  %152 = ashr i32 %56, %151
  %153 = sext i32 %152 to i64
  %154 = lshr i64 %153, 9
  %155 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %154
  %156 = load atomic i64, ptr %155 acquire, align 8
  %.not.i.i1.i.i.i = icmp eq i64 %156, 0
  br i1 %.not.i.i1.i.i.i, label %_ZN11ListManager6appendEPv.exit.i, label %157

157:                                              ; preds = %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %158 = inttoptr i64 %156 to ptr
  %159 = and i64 %153, 511
  %160 = getelementptr inbounds ptr, ptr %158, i64 %159
  %161 = load atomic i64, ptr %160 acquire, align 8
  %162 = inttoptr i64 %161 to ptr
  br label %_ZN11ListManager6appendEPv.exit.i

_ZN11ListManager6appendEPv.exit.i:                ; preds = %157, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i
  %163 = phi ptr [ %162, %157 ], [ null, %_ZN11ListManager19reserve_new_elementEv.exit.i.i.i ]
  %164 = load i64, ptr %25, align 8
  %165 = load i32, ptr %21, align 8
  %notmask.i.i.i.i = shl nsw i32 -1, %165
  %166 = xor i32 %notmask.i.i.i.i, -1
  %167 = and i32 %56, %166
  %168 = sext i32 %167 to i64
  %169 = mul i64 %164, %168
  %170 = getelementptr inbounds i8, ptr %163, i64 %169
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %170, ptr nonnull align 8 %2, i64 %164, i1 false)
  br label %.loopexit.i, !llvm.loop !8

.loopexit.i:                                      ; preds = %_ZN11ListManager6appendEPv.exit.i, %.lr.ph58.i
  %171 = add i32 %.04457.i, 1
  %exitcond.not.i = icmp eq i32 %171, %48
  br i1 %exitcond.not.i, label %._crit_edge.i.loopexit, label %.lr.ph58.i, !llvm.loop !9

._crit_edge.i.loopexit:                           ; preds = %.loopexit.i
  br label %._crit_edge.i

._crit_edge.i:                                    ; preds = %._crit_edge.i.loopexit, %_ZN11ListManager3getI7ElementEERT_i.exit.i
  %172 = add nuw nsw i32 %.04359.i, 1
  %exitcond63.not.i = icmp eq i32 %172, %10
  br i1 %exitcond63.not.i, label %element_listgen_nonroot.exit.loopexit, label %26, !llvm.loop !10

element_listgen_nonroot.exit.loopexit:            ; preds = %._crit_edge.i
  br label %element_listgen_nonroot.exit

element_listgen_nonroot.exit:                     ; preds = %element_listgen_nonroot.exit.loopexit, %entry
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %0)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %1)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %2)
  ret void
}

; Function Attrs: nounwind
define void @field_publish_centroids_55_kernel_4_struct_for(ptr %context) local_unnamed_addr #1 {
entry:
  %0 = alloca %struct.cpu_block_task_helper_context, align 8
  call void @llvm.lifetime.start.p0(i64 40, ptr nonnull %0)
  %1 = getelementptr inbounds %struct.RuntimeContext.2041, ptr %context, i64 0, i32 1
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 13
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr inbounds ptr, ptr %4, i64 58
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr inbounds %struct.ListManager, ptr %6, i64 0, i32 5
  %8 = load i32, ptr %7, align 8
  store ptr %context, ptr %0, align 8
  %9 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  store ptr @function_body, ptr %9, align 8
  %10 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  store ptr %6, ptr %10, align 8
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  store <2 x i32> <i32 32, i32 8>, ptr %11, align 8
  %12 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  store i64 1, ptr %12, align 8
  %13 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 12
  %14 = load ptr, ptr %13, align 8
  %15 = getelementptr inbounds %struct.LLVMRuntime, ptr %2, i64 0, i32 11
  %16 = load ptr, ptr %15, align 8
  %17 = shl nsw i32 %8, 3
  call void %14(ptr noundef %16, i32 noundef %17, i32 noundef 1, ptr noundef nonnull %0, ptr noundef nonnull @cpu_struct_for_block_helper) #1
  call void @llvm.lifetime.end.p0(i64 40, ptr nonnull %0)
  ret void
}

; Function Attrs: nofree norecurse nounwind
define internal void @function_body(ptr %0, ptr nocapture readnone %1, ptr nocapture readonly %2, i32 %3, i32 %4) #2 {
allocs:
  %5 = getelementptr inbounds %0, ptr %2, i64 0, i32 2
  %6 = icmp sgt i32 %4, %3
  br i1 %6, label %loop_body.preheader, label %func_exit

loop_body.preheader:                              ; preds = %allocs
  %7 = sub i32 %4, %3
  %8 = xor i32 %3, -1
  %xtraiter = and i32 %7, 1
  %lcmp.mod.not = icmp eq i32 %xtraiter, 0
  br i1 %lcmp.mod.not, label %loop_body.prol.loopexit, label %loop_body.prol

loop_body.prol:                                   ; preds = %loop_body.preheader
  %9 = load ptr, ptr %2, align 8
  %10 = getelementptr inbounds i8, ptr %9, i64 32
  %11 = sdiv i32 %3, 8
  %12 = sext i32 %11 to i64
  %13 = getelementptr inbounds i8, ptr %10, i64 %12
  %14 = load i8, ptr %13, align 1
  %15 = zext i8 %14 to i32
  %16 = and i32 %3, 7
  %17 = shl nuw nsw i32 1, %16
  %18 = and i32 %17, %15
  %.not.prol = icmp eq i32 %18, 0
  br i1 %.not.prol, label %loop_body_tail.prol, label %struct_for_body_body.prol

struct_for_body_body.prol:                        ; preds = %loop_body.prol
  %19 = load i32, ptr %5, align 4
  %20 = shl i32 %19, 5
  %21 = and i32 %3, 31
  %22 = or i32 %20, %21
  %23 = load ptr, ptr %0, align 8
  %24 = getelementptr { { { i32, i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %23, i64 0, i32 2, i32 1
  %25 = load ptr, ptr %24, align 8
  %26 = getelementptr { { { i32, i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %23, i64 0, i32 2, i32 0, i32 1
  %27 = load i32, ptr %26, align 4
  %28 = sext i32 %27 to i64
  %29 = sext i32 %22 to i64
  %30 = add nsw i64 %28, %29
  %31 = getelementptr i32, ptr %25, i64 %30
  store i32 0, ptr %31, align 4
  %32 = load ptr, ptr %0, align 8
  %33 = getelementptr { { { i32, i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %32, i64 0, i32 4, i32 1
  %34 = load ptr, ptr %33, align 8
  %35 = getelementptr i64, ptr %34, i64 7
  %36 = atomicrmw add ptr %35, i64 1 seq_cst, align 8
  %37 = load ptr, ptr %0, align 8
  %38 = getelementptr { { i32, i32 }, ptr }, ptr %37, i64 0, i32 1
  %39 = load ptr, ptr %38, align 8
  %40 = getelementptr { { i32, i32 }, ptr }, ptr %37, i64 0, i32 0, i32 1
  %41 = load i32, ptr %40, align 4
  %42 = sext i32 %41 to i64
  %43 = mul nsw i64 %42, 7
  %44 = add nsw i64 %43, %29
  %45 = getelementptr double, ptr %39, i64 %44
  %46 = load double, ptr %45, align 8
  %47 = getelementptr double, ptr %39, i64 %29
  %48 = load double, ptr %47, align 8
  %49 = shl nsw i64 %42, 2
  %50 = add nsw i64 %49, %29
  %51 = getelementptr double, ptr %39, i64 %50
  %52 = load double, ptr %51, align 8
  %53 = getelementptr { { { i32, i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %37, i64 0, i32 3, i32 1
  %54 = load ptr, ptr %53, align 8
  %55 = getelementptr { { { i32, i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %37, i64 0, i32 3, i32 0, i32 1
  %56 = getelementptr double, ptr %54, i64 %29
  %57 = load double, ptr %56, align 8
  %58 = fcmp ogt double %46, 0.000000e+00
  %59 = select i1 %58, double %46, double 1.000000e+00
  %60 = fdiv double %52, %59
  %61 = fadd double %60, %57
  %62 = select i1 %58, double %61, double 0.000000e+00
  %63 = bitcast double %62 to i64
  %64 = and i64 %63, 9218868437227405312
  %65 = icmp ne i64 %64, 9218868437227405312
  %66 = select i1 %65, double %62, double 0.000000e+00
  %67 = bitcast double %66 to i64
  %68 = and i64 %67, 9218868437227405312
  %69 = icmp ne i64 %68, 9218868437227405312
  %70 = and i1 %65, %69
  %71 = select i1 %70, double %66, double 0.000000e+00
  %72 = and i64 %63, 9223372036854775807
  %73 = icmp eq i64 %72, 0
  %74 = icmp ne i64 %64, 0
  %75 = and i1 %74, %65
  %76 = or i1 %73, %75
  br i1 %76, label %after_if.prol, label %true_block.prol

true_block.prol:                                  ; preds = %struct_for_body_body.prol
  %77 = load ptr, ptr %33, align 8
  %78 = getelementptr i64, ptr %77, i64 19
  %79 = atomicrmw add ptr %78, i64 1 seq_cst, align 8
  br label %after_if.prol

after_if.prol:                                    ; preds = %true_block.prol, %struct_for_body_body.prol
  %80 = bitcast double %46 to i64
  %81 = and i64 %80, 9223372036854775807
  %82 = and i64 %80, 9218868437227405312
  %83 = icmp eq i64 %81, 0
  %84 = icmp ne i64 %82, 0
  %85 = icmp ne i64 %82, 9218868437227405312
  %86 = and i1 %84, %85
  %87 = or i1 %83, %86
  br i1 %87, label %after_if3.prol, label %true_block1.prol

true_block1.prol:                                 ; preds = %after_if.prol
  %88 = load ptr, ptr %33, align 8
  %89 = getelementptr i64, ptr %88, i64 19
  %90 = atomicrmw add ptr %89, i64 1 seq_cst, align 8
  br label %after_if3.prol

after_if3.prol:                                   ; preds = %true_block1.prol, %after_if.prol
  %91 = load ptr, ptr %53, align 8
  %92 = load i32, ptr %55, align 4
  %93 = sext i32 %92 to i64
  %94 = mul nsw i64 %93, 3
  %95 = add nsw i64 %94, %29
  %96 = getelementptr double, ptr %91, i64 %95
  store double %48, ptr %96, align 8
  store double 0.000000e+00, ptr %56, align 8
  %97 = fcmp one double %71, %48
  store double %71, ptr %47, align 8
  %98 = load ptr, ptr %38, align 8
  %99 = load i32, ptr %40, align 4
  %100 = sext i32 %99 to i64
  %101 = add nsw i64 %100, %29
  %102 = getelementptr double, ptr %98, i64 %101
  %103 = load double, ptr %102, align 8
  %104 = mul nsw i64 %100, 5
  %105 = add nsw i64 %104, %29
  %106 = getelementptr double, ptr %98, i64 %105
  %107 = load double, ptr %106, align 8
  %108 = load ptr, ptr %53, align 8
  %109 = load i32, ptr %55, align 4
  %110 = sext i32 %109 to i64
  %111 = add nsw i64 %110, %29
  %112 = getelementptr double, ptr %108, i64 %111
  %113 = load double, ptr %112, align 8
  %114 = fdiv double %107, %59
  %115 = fadd double %114, %113
  %116 = select i1 %58, double %115, double 0.000000e+00
  %117 = bitcast double %116 to i64
  %118 = and i64 %117, 9218868437227405312
  %119 = icmp ne i64 %118, 9218868437227405312
  %120 = select i1 %119, double %116, double 0.000000e+00
  %121 = bitcast double %120 to i64
  %122 = and i64 %121, 9218868437227405312
  %123 = icmp ne i64 %122, 9218868437227405312
  %124 = and i1 %119, %123
  %125 = select i1 %124, double %120, double 0.000000e+00
  %126 = and i64 %117, 9223372036854775807
  %127 = icmp eq i64 %126, 0
  %128 = icmp ne i64 %118, 0
  %129 = and i1 %128, %119
  %130 = or i1 %127, %129
  br i1 %130, label %after_if6.prol, label %true_block4.prol

true_block4.prol:                                 ; preds = %after_if3.prol
  %131 = load ptr, ptr %33, align 8
  %132 = getelementptr i64, ptr %131, i64 19
  %133 = atomicrmw add ptr %132, i64 1 seq_cst, align 8
  br label %after_if6.prol

after_if6.prol:                                   ; preds = %true_block4.prol, %after_if3.prol
  br i1 %87, label %after_if9.prol, label %true_block7.prol

true_block7.prol:                                 ; preds = %after_if6.prol
  %134 = load ptr, ptr %33, align 8
  %135 = getelementptr i64, ptr %134, i64 19
  %136 = atomicrmw add ptr %135, i64 1 seq_cst, align 8
  br label %after_if9.prol

after_if9.prol:                                   ; preds = %true_block7.prol, %after_if6.prol
  %137 = load ptr, ptr %53, align 8
  %138 = load i32, ptr %55, align 4
  %139 = sext i32 %138 to i64
  %140 = shl nsw i64 %139, 2
  %141 = add nsw i64 %140, %29
  %142 = getelementptr double, ptr %137, i64 %141
  store double %103, ptr %142, align 8
  store double 0.000000e+00, ptr %112, align 8
  %143 = fcmp one double %125, %103
  %144 = or i1 %97, %143
  store double %125, ptr %102, align 8
  %145 = load ptr, ptr %38, align 8
  %146 = load i32, ptr %40, align 4
  %147 = sext i32 %146 to i64
  %148 = shl nsw i64 %147, 1
  %149 = add nsw i64 %148, %29
  %150 = getelementptr double, ptr %145, i64 %149
  %151 = load double, ptr %150, align 8
  %152 = mul nsw i64 %147, 6
  %153 = add nsw i64 %152, %29
  %154 = getelementptr double, ptr %145, i64 %153
  %155 = load double, ptr %154, align 8
  %156 = load ptr, ptr %53, align 8
  %157 = load i32, ptr %55, align 4
  %158 = sext i32 %157 to i64
  %159 = shl nsw i64 %158, 1
  %160 = add nsw i64 %159, %29
  %161 = getelementptr double, ptr %156, i64 %160
  %162 = load double, ptr %161, align 8
  %163 = fdiv double %155, %59
  %164 = fadd double %163, %162
  %165 = select i1 %58, double %164, double 0.000000e+00
  %166 = bitcast double %165 to i64
  %167 = and i64 %166, 9218868437227405312
  %168 = icmp ne i64 %167, 9218868437227405312
  %169 = select i1 %168, double %165, double 0.000000e+00
  %170 = bitcast double %169 to i64
  %171 = and i64 %170, 9218868437227405312
  %172 = icmp ne i64 %171, 9218868437227405312
  %173 = and i1 %168, %172
  %174 = select i1 %173, double %169, double 0.000000e+00
  %175 = and i64 %166, 9223372036854775807
  %176 = icmp eq i64 %175, 0
  %177 = icmp ne i64 %167, 0
  %178 = and i1 %177, %168
  %179 = or i1 %176, %178
  br i1 %179, label %after_if12.prol, label %true_block10.prol

true_block10.prol:                                ; preds = %after_if9.prol
  %180 = load ptr, ptr %33, align 8
  %181 = getelementptr i64, ptr %180, i64 19
  %182 = atomicrmw add ptr %181, i64 1 seq_cst, align 8
  br label %after_if12.prol

after_if12.prol:                                  ; preds = %true_block10.prol, %after_if9.prol
  br i1 %87, label %after_if15.prol, label %true_block13.prol

true_block13.prol:                                ; preds = %after_if12.prol
  %183 = load ptr, ptr %33, align 8
  %184 = getelementptr i64, ptr %183, i64 19
  %185 = atomicrmw add ptr %184, i64 1 seq_cst, align 8
  br label %after_if15.prol

after_if15.prol:                                  ; preds = %true_block13.prol, %after_if12.prol
  %186 = load ptr, ptr %53, align 8
  %187 = load i32, ptr %55, align 4
  %188 = sext i32 %187 to i64
  %189 = mul nsw i64 %188, 5
  %190 = add nsw i64 %189, %29
  %191 = getelementptr double, ptr %186, i64 %190
  store double %151, ptr %191, align 8
  store double 0.000000e+00, ptr %161, align 8
  %192 = fcmp one double %174, %151
  %193 = or i1 %144, %192
  store double %174, ptr %150, align 8
  br i1 %193, label %true_block16.prol, label %after_if18.prol

true_block16.prol:                                ; preds = %after_if15.prol
  store i32 1, ptr %31, align 4
  br label %after_if18.prol

after_if18.prol:                                  ; preds = %true_block16.prol, %after_if15.prol
  %194 = load ptr, ptr %38, align 8
  %195 = load i32, ptr %40, align 4
  %196 = sext i32 %195 to i64
  %197 = mul nsw i64 %196, 3
  %198 = add nsw i64 %197, %29
  %199 = getelementptr double, ptr %194, i64 %198
  store double %46, ptr %199, align 8
  br label %loop_body_tail.prol

loop_body_tail.prol:                              ; preds = %after_if18.prol, %loop_body.prol
  %200 = add nsw i32 %3, 1
  br label %loop_body.prol.loopexit

loop_body.prol.loopexit:                          ; preds = %loop_body_tail.prol, %loop_body.preheader
  %.024.unr = phi i32 [ %3, %loop_body.preheader ], [ %200, %loop_body_tail.prol ]
  %201 = sub i32 0, %4
  %202 = icmp eq i32 %8, %201
  br i1 %202, label %func_exit, label %loop_body.preheader25

loop_body.preheader25:                            ; preds = %loop_body.prol.loopexit
  br label %loop_body

loop_body:                                        ; preds = %loop_body_tail.1, %loop_body.preheader25
  %.024 = phi i32 [ %405, %loop_body_tail.1 ], [ %.024.unr, %loop_body.preheader25 ]
  %203 = load ptr, ptr %2, align 8
  %204 = getelementptr inbounds i8, ptr %203, i64 32
  %205 = sdiv i32 %.024, 8
  %206 = sext i32 %205 to i64
  %207 = getelementptr inbounds i8, ptr %204, i64 %206
  %208 = load i8, ptr %207, align 1
  %209 = zext i8 %208 to i32
  %210 = and i32 %.024, 7
  %211 = shl nuw nsw i32 1, %210
  %212 = and i32 %211, %209
  %.not = icmp eq i32 %212, 0
  br i1 %.not, label %loop_body_tail, label %struct_for_body_body

loop_body_tail:                                   ; preds = %after_if18, %loop_body
  %213 = add i32 %.024, 1
  %214 = load ptr, ptr %2, align 8
  %215 = getelementptr inbounds i8, ptr %214, i64 32
  %216 = sdiv i32 %213, 8
  %217 = sext i32 %216 to i64
  %218 = getelementptr inbounds i8, ptr %215, i64 %217
  %219 = load i8, ptr %218, align 1
  %220 = zext i8 %219 to i32
  %221 = and i32 %213, 7
  %222 = shl nuw nsw i32 1, %221
  %223 = and i32 %222, %220
  %.not.1 = icmp eq i32 %223, 0
  br i1 %.not.1, label %loop_body_tail.1, label %struct_for_body_body.1

struct_for_body_body.1:                           ; preds = %loop_body_tail
  %224 = load i32, ptr %5, align 4
  %225 = shl i32 %224, 5
  %226 = and i32 %213, 31
  %227 = or i32 %225, %226
  %228 = load ptr, ptr %0, align 8
  %229 = getelementptr { { { i32, i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %228, i64 0, i32 2, i32 1
  %230 = load ptr, ptr %229, align 8
  %231 = getelementptr { { { i32, i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %228, i64 0, i32 2, i32 0, i32 1
  %232 = load i32, ptr %231, align 4
  %233 = sext i32 %232 to i64
  %234 = sext i32 %227 to i64
  %235 = add nsw i64 %233, %234
  %236 = getelementptr i32, ptr %230, i64 %235
  store i32 0, ptr %236, align 4
  %237 = load ptr, ptr %0, align 8
  %238 = getelementptr { { { i32, i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %237, i64 0, i32 4, i32 1
  %239 = load ptr, ptr %238, align 8
  %240 = getelementptr i64, ptr %239, i64 7
  %241 = atomicrmw add ptr %240, i64 1 seq_cst, align 8
  %242 = load ptr, ptr %0, align 8
  %243 = getelementptr { { i32, i32 }, ptr }, ptr %242, i64 0, i32 1
  %244 = load ptr, ptr %243, align 8
  %245 = getelementptr { { i32, i32 }, ptr }, ptr %242, i64 0, i32 0, i32 1
  %246 = load i32, ptr %245, align 4
  %247 = sext i32 %246 to i64
  %248 = mul nsw i64 %247, 7
  %249 = add nsw i64 %248, %234
  %250 = getelementptr double, ptr %244, i64 %249
  %251 = load double, ptr %250, align 8
  %252 = getelementptr double, ptr %244, i64 %234
  %253 = load double, ptr %252, align 8
  %254 = shl nsw i64 %247, 2
  %255 = add nsw i64 %254, %234
  %256 = getelementptr double, ptr %244, i64 %255
  %257 = load double, ptr %256, align 8
  %258 = getelementptr { { { i32, i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %242, i64 0, i32 3, i32 1
  %259 = load ptr, ptr %258, align 8
  %260 = getelementptr { { { i32, i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %242, i64 0, i32 3, i32 0, i32 1
  %261 = getelementptr double, ptr %259, i64 %234
  %262 = load double, ptr %261, align 8
  %263 = fcmp ogt double %251, 0.000000e+00
  %264 = select i1 %263, double %251, double 1.000000e+00
  %265 = fdiv double %257, %264
  %266 = fadd double %265, %262
  %267 = select i1 %263, double %266, double 0.000000e+00
  %268 = bitcast double %267 to i64
  %269 = and i64 %268, 9218868437227405312
  %270 = icmp ne i64 %269, 9218868437227405312
  %271 = select i1 %270, double %267, double 0.000000e+00
  %272 = bitcast double %271 to i64
  %273 = and i64 %272, 9218868437227405312
  %274 = icmp ne i64 %273, 9218868437227405312
  %275 = and i1 %270, %274
  %276 = select i1 %275, double %271, double 0.000000e+00
  %277 = and i64 %268, 9223372036854775807
  %278 = icmp eq i64 %277, 0
  %279 = icmp ne i64 %269, 0
  %280 = and i1 %279, %270
  %281 = or i1 %278, %280
  br i1 %281, label %after_if.1, label %true_block.1

true_block.1:                                     ; preds = %struct_for_body_body.1
  %282 = load ptr, ptr %238, align 8
  %283 = getelementptr i64, ptr %282, i64 19
  %284 = atomicrmw add ptr %283, i64 1 seq_cst, align 8
  br label %after_if.1

after_if.1:                                       ; preds = %true_block.1, %struct_for_body_body.1
  %285 = bitcast double %251 to i64
  %286 = and i64 %285, 9223372036854775807
  %287 = and i64 %285, 9218868437227405312
  %288 = icmp eq i64 %286, 0
  %289 = icmp ne i64 %287, 0
  %290 = icmp ne i64 %287, 9218868437227405312
  %291 = and i1 %289, %290
  %292 = or i1 %288, %291
  br i1 %292, label %after_if3.1, label %true_block1.1

true_block1.1:                                    ; preds = %after_if.1
  %293 = load ptr, ptr %238, align 8
  %294 = getelementptr i64, ptr %293, i64 19
  %295 = atomicrmw add ptr %294, i64 1 seq_cst, align 8
  br label %after_if3.1

after_if3.1:                                      ; preds = %true_block1.1, %after_if.1
  %296 = load ptr, ptr %258, align 8
  %297 = load i32, ptr %260, align 4
  %298 = sext i32 %297 to i64
  %299 = mul nsw i64 %298, 3
  %300 = add nsw i64 %299, %234
  %301 = getelementptr double, ptr %296, i64 %300
  store double %253, ptr %301, align 8
  store double 0.000000e+00, ptr %261, align 8
  %302 = fcmp one double %276, %253
  store double %276, ptr %252, align 8
  %303 = load ptr, ptr %243, align 8
  %304 = load i32, ptr %245, align 4
  %305 = sext i32 %304 to i64
  %306 = add nsw i64 %305, %234
  %307 = getelementptr double, ptr %303, i64 %306
  %308 = load double, ptr %307, align 8
  %309 = mul nsw i64 %305, 5
  %310 = add nsw i64 %309, %234
  %311 = getelementptr double, ptr %303, i64 %310
  %312 = load double, ptr %311, align 8
  %313 = load ptr, ptr %258, align 8
  %314 = load i32, ptr %260, align 4
  %315 = sext i32 %314 to i64
  %316 = add nsw i64 %315, %234
  %317 = getelementptr double, ptr %313, i64 %316
  %318 = load double, ptr %317, align 8
  %319 = fdiv double %312, %264
  %320 = fadd double %319, %318
  %321 = select i1 %263, double %320, double 0.000000e+00
  %322 = bitcast double %321 to i64
  %323 = and i64 %322, 9218868437227405312
  %324 = icmp ne i64 %323, 9218868437227405312
  %325 = select i1 %324, double %321, double 0.000000e+00
  %326 = bitcast double %325 to i64
  %327 = and i64 %326, 9218868437227405312
  %328 = icmp ne i64 %327, 9218868437227405312
  %329 = and i1 %324, %328
  %330 = select i1 %329, double %325, double 0.000000e+00
  %331 = and i64 %322, 9223372036854775807
  %332 = icmp eq i64 %331, 0
  %333 = icmp ne i64 %323, 0
  %334 = and i1 %333, %324
  %335 = or i1 %332, %334
  br i1 %335, label %after_if6.1, label %true_block4.1

true_block4.1:                                    ; preds = %after_if3.1
  %336 = load ptr, ptr %238, align 8
  %337 = getelementptr i64, ptr %336, i64 19
  %338 = atomicrmw add ptr %337, i64 1 seq_cst, align 8
  br label %after_if6.1

after_if6.1:                                      ; preds = %true_block4.1, %after_if3.1
  br i1 %292, label %after_if9.1, label %true_block7.1

true_block7.1:                                    ; preds = %after_if6.1
  %339 = load ptr, ptr %238, align 8
  %340 = getelementptr i64, ptr %339, i64 19
  %341 = atomicrmw add ptr %340, i64 1 seq_cst, align 8
  br label %after_if9.1

after_if9.1:                                      ; preds = %true_block7.1, %after_if6.1
  %342 = load ptr, ptr %258, align 8
  %343 = load i32, ptr %260, align 4
  %344 = sext i32 %343 to i64
  %345 = shl nsw i64 %344, 2
  %346 = add nsw i64 %345, %234
  %347 = getelementptr double, ptr %342, i64 %346
  store double %308, ptr %347, align 8
  store double 0.000000e+00, ptr %317, align 8
  %348 = fcmp one double %330, %308
  %349 = or i1 %302, %348
  store double %330, ptr %307, align 8
  %350 = load ptr, ptr %243, align 8
  %351 = load i32, ptr %245, align 4
  %352 = sext i32 %351 to i64
  %353 = shl nsw i64 %352, 1
  %354 = add nsw i64 %353, %234
  %355 = getelementptr double, ptr %350, i64 %354
  %356 = load double, ptr %355, align 8
  %357 = mul nsw i64 %352, 6
  %358 = add nsw i64 %357, %234
  %359 = getelementptr double, ptr %350, i64 %358
  %360 = load double, ptr %359, align 8
  %361 = load ptr, ptr %258, align 8
  %362 = load i32, ptr %260, align 4
  %363 = sext i32 %362 to i64
  %364 = shl nsw i64 %363, 1
  %365 = add nsw i64 %364, %234
  %366 = getelementptr double, ptr %361, i64 %365
  %367 = load double, ptr %366, align 8
  %368 = fdiv double %360, %264
  %369 = fadd double %368, %367
  %370 = select i1 %263, double %369, double 0.000000e+00
  %371 = bitcast double %370 to i64
  %372 = and i64 %371, 9218868437227405312
  %373 = icmp ne i64 %372, 9218868437227405312
  %374 = select i1 %373, double %370, double 0.000000e+00
  %375 = bitcast double %374 to i64
  %376 = and i64 %375, 9218868437227405312
  %377 = icmp ne i64 %376, 9218868437227405312
  %378 = and i1 %373, %377
  %379 = select i1 %378, double %374, double 0.000000e+00
  %380 = and i64 %371, 9223372036854775807
  %381 = icmp eq i64 %380, 0
  %382 = icmp ne i64 %372, 0
  %383 = and i1 %382, %373
  %384 = or i1 %381, %383
  br i1 %384, label %after_if12.1, label %true_block10.1

true_block10.1:                                   ; preds = %after_if9.1
  %385 = load ptr, ptr %238, align 8
  %386 = getelementptr i64, ptr %385, i64 19
  %387 = atomicrmw add ptr %386, i64 1 seq_cst, align 8
  br label %after_if12.1

after_if12.1:                                     ; preds = %true_block10.1, %after_if9.1
  br i1 %292, label %after_if15.1, label %true_block13.1

true_block13.1:                                   ; preds = %after_if12.1
  %388 = load ptr, ptr %238, align 8
  %389 = getelementptr i64, ptr %388, i64 19
  %390 = atomicrmw add ptr %389, i64 1 seq_cst, align 8
  br label %after_if15.1

after_if15.1:                                     ; preds = %true_block13.1, %after_if12.1
  %391 = load ptr, ptr %258, align 8
  %392 = load i32, ptr %260, align 4
  %393 = sext i32 %392 to i64
  %394 = mul nsw i64 %393, 5
  %395 = add nsw i64 %394, %234
  %396 = getelementptr double, ptr %391, i64 %395
  store double %356, ptr %396, align 8
  store double 0.000000e+00, ptr %366, align 8
  %397 = fcmp one double %379, %356
  %398 = or i1 %349, %397
  store double %379, ptr %355, align 8
  br i1 %398, label %true_block16.1, label %after_if18.1

true_block16.1:                                   ; preds = %after_if15.1
  store i32 1, ptr %236, align 4
  br label %after_if18.1

after_if18.1:                                     ; preds = %true_block16.1, %after_if15.1
  %399 = load ptr, ptr %243, align 8
  %400 = load i32, ptr %245, align 4
  %401 = sext i32 %400 to i64
  %402 = mul nsw i64 %401, 3
  %403 = add nsw i64 %402, %234
  %404 = getelementptr double, ptr %399, i64 %403
  store double %251, ptr %404, align 8
  br label %loop_body_tail.1

loop_body_tail.1:                                 ; preds = %after_if18.1, %loop_body_tail
  %405 = add i32 %213, 1
  %exitcond.not.1 = icmp eq i32 %405, %4
  br i1 %exitcond.not.1, label %func_exit.loopexit, label %loop_body

func_exit.loopexit:                               ; preds = %loop_body_tail.1
  br label %func_exit

func_exit:                                        ; preds = %func_exit.loopexit, %loop_body.prol.loopexit, %allocs
  ret void

struct_for_body_body:                             ; preds = %loop_body
  %406 = load i32, ptr %5, align 4
  %407 = shl i32 %406, 5
  %408 = and i32 %.024, 31
  %409 = or i32 %407, %408
  %410 = load ptr, ptr %0, align 8
  %411 = getelementptr { { { i32, i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %410, i64 0, i32 2, i32 1
  %412 = load ptr, ptr %411, align 8
  %413 = getelementptr { { { i32, i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %410, i64 0, i32 2, i32 0, i32 1
  %414 = load i32, ptr %413, align 4
  %415 = sext i32 %414 to i64
  %416 = sext i32 %409 to i64
  %417 = add nsw i64 %415, %416
  %418 = getelementptr i32, ptr %412, i64 %417
  store i32 0, ptr %418, align 4
  %419 = load ptr, ptr %0, align 8
  %420 = getelementptr { { { i32, i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %419, i64 0, i32 4, i32 1
  %421 = load ptr, ptr %420, align 8
  %422 = getelementptr i64, ptr %421, i64 7
  %423 = atomicrmw add ptr %422, i64 1 seq_cst, align 8
  %424 = load ptr, ptr %0, align 8
  %425 = getelementptr { { i32, i32 }, ptr }, ptr %424, i64 0, i32 1
  %426 = load ptr, ptr %425, align 8
  %427 = getelementptr { { i32, i32 }, ptr }, ptr %424, i64 0, i32 0, i32 1
  %428 = load i32, ptr %427, align 4
  %429 = sext i32 %428 to i64
  %430 = mul nsw i64 %429, 7
  %431 = add nsw i64 %430, %416
  %432 = getelementptr double, ptr %426, i64 %431
  %433 = load double, ptr %432, align 8
  %434 = getelementptr double, ptr %426, i64 %416
  %435 = load double, ptr %434, align 8
  %436 = shl nsw i64 %429, 2
  %437 = add nsw i64 %436, %416
  %438 = getelementptr double, ptr %426, i64 %437
  %439 = load double, ptr %438, align 8
  %440 = getelementptr { { { i32, i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %424, i64 0, i32 3, i32 1
  %441 = load ptr, ptr %440, align 8
  %442 = getelementptr { { { i32, i32 }, ptr }, i32, { { i32, i32 }, ptr }, { { i32, i32 }, ptr }, { { i32 }, ptr } }, ptr %424, i64 0, i32 3, i32 0, i32 1
  %443 = getelementptr double, ptr %441, i64 %416
  %444 = load double, ptr %443, align 8
  %445 = fcmp ogt double %433, 0.000000e+00
  %446 = select i1 %445, double %433, double 1.000000e+00
  %447 = fdiv double %439, %446
  %448 = fadd double %447, %444
  %449 = select i1 %445, double %448, double 0.000000e+00
  %450 = bitcast double %449 to i64
  %451 = and i64 %450, 9218868437227405312
  %452 = icmp ne i64 %451, 9218868437227405312
  %453 = select i1 %452, double %449, double 0.000000e+00
  %454 = bitcast double %453 to i64
  %455 = and i64 %454, 9218868437227405312
  %456 = icmp ne i64 %455, 9218868437227405312
  %457 = and i1 %452, %456
  %458 = select i1 %457, double %453, double 0.000000e+00
  %459 = and i64 %450, 9223372036854775807
  %460 = icmp eq i64 %459, 0
  %461 = icmp ne i64 %451, 0
  %462 = and i1 %461, %452
  %463 = or i1 %460, %462
  br i1 %463, label %after_if, label %true_block

true_block:                                       ; preds = %struct_for_body_body
  %464 = load ptr, ptr %420, align 8
  %465 = getelementptr i64, ptr %464, i64 19
  %466 = atomicrmw add ptr %465, i64 1 seq_cst, align 8
  br label %after_if

after_if:                                         ; preds = %true_block, %struct_for_body_body
  %467 = bitcast double %433 to i64
  %468 = and i64 %467, 9223372036854775807
  %469 = and i64 %467, 9218868437227405312
  %470 = icmp eq i64 %468, 0
  %471 = icmp ne i64 %469, 0
  %472 = icmp ne i64 %469, 9218868437227405312
  %473 = and i1 %471, %472
  %474 = or i1 %470, %473
  br i1 %474, label %after_if3, label %true_block1

true_block1:                                      ; preds = %after_if
  %475 = load ptr, ptr %420, align 8
  %476 = getelementptr i64, ptr %475, i64 19
  %477 = atomicrmw add ptr %476, i64 1 seq_cst, align 8
  br label %after_if3

after_if3:                                        ; preds = %true_block1, %after_if
  %478 = load ptr, ptr %440, align 8
  %479 = load i32, ptr %442, align 4
  %480 = sext i32 %479 to i64
  %481 = mul nsw i64 %480, 3
  %482 = add nsw i64 %481, %416
  %483 = getelementptr double, ptr %478, i64 %482
  store double %435, ptr %483, align 8
  store double 0.000000e+00, ptr %443, align 8
  %484 = fcmp one double %458, %435
  store double %458, ptr %434, align 8
  %485 = load ptr, ptr %425, align 8
  %486 = load i32, ptr %427, align 4
  %487 = sext i32 %486 to i64
  %488 = add nsw i64 %487, %416
  %489 = getelementptr double, ptr %485, i64 %488
  %490 = load double, ptr %489, align 8
  %491 = mul nsw i64 %487, 5
  %492 = add nsw i64 %491, %416
  %493 = getelementptr double, ptr %485, i64 %492
  %494 = load double, ptr %493, align 8
  %495 = load ptr, ptr %440, align 8
  %496 = load i32, ptr %442, align 4
  %497 = sext i32 %496 to i64
  %498 = add nsw i64 %497, %416
  %499 = getelementptr double, ptr %495, i64 %498
  %500 = load double, ptr %499, align 8
  %501 = fdiv double %494, %446
  %502 = fadd double %501, %500
  %503 = select i1 %445, double %502, double 0.000000e+00
  %504 = bitcast double %503 to i64
  %505 = and i64 %504, 9218868437227405312
  %506 = icmp ne i64 %505, 9218868437227405312
  %507 = select i1 %506, double %503, double 0.000000e+00
  %508 = bitcast double %507 to i64
  %509 = and i64 %508, 9218868437227405312
  %510 = icmp ne i64 %509, 9218868437227405312
  %511 = and i1 %506, %510
  %512 = select i1 %511, double %507, double 0.000000e+00
  %513 = and i64 %504, 9223372036854775807
  %514 = icmp eq i64 %513, 0
  %515 = icmp ne i64 %505, 0
  %516 = and i1 %515, %506
  %517 = or i1 %514, %516
  br i1 %517, label %after_if6, label %true_block4

true_block4:                                      ; preds = %after_if3
  %518 = load ptr, ptr %420, align 8
  %519 = getelementptr i64, ptr %518, i64 19
  %520 = atomicrmw add ptr %519, i64 1 seq_cst, align 8
  br label %after_if6

after_if6:                                        ; preds = %true_block4, %after_if3
  br i1 %474, label %after_if9, label %true_block7

true_block7:                                      ; preds = %after_if6
  %521 = load ptr, ptr %420, align 8
  %522 = getelementptr i64, ptr %521, i64 19
  %523 = atomicrmw add ptr %522, i64 1 seq_cst, align 8
  br label %after_if9

after_if9:                                        ; preds = %true_block7, %after_if6
  %524 = load ptr, ptr %440, align 8
  %525 = load i32, ptr %442, align 4
  %526 = sext i32 %525 to i64
  %527 = shl nsw i64 %526, 2
  %528 = add nsw i64 %527, %416
  %529 = getelementptr double, ptr %524, i64 %528
  store double %490, ptr %529, align 8
  store double 0.000000e+00, ptr %499, align 8
  %530 = fcmp one double %512, %490
  %531 = or i1 %484, %530
  store double %512, ptr %489, align 8
  %532 = load ptr, ptr %425, align 8
  %533 = load i32, ptr %427, align 4
  %534 = sext i32 %533 to i64
  %535 = shl nsw i64 %534, 1
  %536 = add nsw i64 %535, %416
  %537 = getelementptr double, ptr %532, i64 %536
  %538 = load double, ptr %537, align 8
  %539 = mul nsw i64 %534, 6
  %540 = add nsw i64 %539, %416
  %541 = getelementptr double, ptr %532, i64 %540
  %542 = load double, ptr %541, align 8
  %543 = load ptr, ptr %440, align 8
  %544 = load i32, ptr %442, align 4
  %545 = sext i32 %544 to i64
  %546 = shl nsw i64 %545, 1
  %547 = add nsw i64 %546, %416
  %548 = getelementptr double, ptr %543, i64 %547
  %549 = load double, ptr %548, align 8
  %550 = fdiv double %542, %446
  %551 = fadd double %550, %549
  %552 = select i1 %445, double %551, double 0.000000e+00
  %553 = bitcast double %552 to i64
  %554 = and i64 %553, 9218868437227405312
  %555 = icmp ne i64 %554, 9218868437227405312
  %556 = select i1 %555, double %552, double 0.000000e+00
  %557 = bitcast double %556 to i64
  %558 = and i64 %557, 9218868437227405312
  %559 = icmp ne i64 %558, 9218868437227405312
  %560 = and i1 %555, %559
  %561 = select i1 %560, double %556, double 0.000000e+00
  %562 = and i64 %553, 9223372036854775807
  %563 = icmp eq i64 %562, 0
  %564 = icmp ne i64 %554, 0
  %565 = and i1 %564, %555
  %566 = or i1 %563, %565
  br i1 %566, label %after_if12, label %true_block10

true_block10:                                     ; preds = %after_if9
  %567 = load ptr, ptr %420, align 8
  %568 = getelementptr i64, ptr %567, i64 19
  %569 = atomicrmw add ptr %568, i64 1 seq_cst, align 8
  br label %after_if12

after_if12:                                       ; preds = %true_block10, %after_if9
  br i1 %474, label %after_if15, label %true_block13

true_block13:                                     ; preds = %after_if12
  %570 = load ptr, ptr %420, align 8
  %571 = getelementptr i64, ptr %570, i64 19
  %572 = atomicrmw add ptr %571, i64 1 seq_cst, align 8
  br label %after_if15

after_if15:                                       ; preds = %true_block13, %after_if12
  %573 = load ptr, ptr %440, align 8
  %574 = load i32, ptr %442, align 4
  %575 = sext i32 %574 to i64
  %576 = mul nsw i64 %575, 5
  %577 = add nsw i64 %576, %416
  %578 = getelementptr double, ptr %573, i64 %577
  store double %538, ptr %578, align 8
  store double 0.000000e+00, ptr %548, align 8
  %579 = fcmp one double %561, %538
  %580 = or i1 %531, %579
  store double %561, ptr %537, align 8
  br i1 %580, label %true_block16, label %after_if18

true_block16:                                     ; preds = %after_if15
  store i32 1, ptr %418, align 4
  br label %after_if18

after_if18:                                       ; preds = %true_block16, %after_if15
  %581 = load ptr, ptr %425, align 8
  %582 = load i32, ptr %427, align 4
  %583 = sext i32 %582 to i64
  %584 = mul nsw i64 %583, 3
  %585 = add nsw i64 %584, %416
  %586 = getelementptr double, ptr %581, i64 %585
  store double %433, ptr %586, align 8
  br label %loop_body_tail
}

; Function Attrs: argmemonly mustprogress nofree norecurse nosync nounwind willreturn
define internal fastcc void @S57_refine_coordinates(ptr nocapture readonly %0, ptr nocapture writeonly %1, i32 %2) unnamed_addr #3 {
entry:
  %3 = and i32 %2, 3
  %4 = load i32, ptr %0, align 4
  %5 = shl i32 %4, 2
  %6 = or i32 %5, %3
  store i32 %6, ptr %1, align 4
  %7 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 1
  %8 = load i32, ptr %7, align 4
  %9 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 1
  store i32 %8, ptr %9, align 4
  %10 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 2
  %11 = load i32, ptr %10, align 4
  %12 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 2
  store i32 %11, ptr %12, align 4
  %13 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 3
  %14 = load i32, ptr %13, align 4
  %15 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 3
  store i32 %14, ptr %15, align 4
  %16 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 4
  %17 = load i32, ptr %16, align 4
  %18 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 4
  store i32 %17, ptr %18, align 4
  %19 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 5
  %20 = load i32, ptr %19, align 4
  %21 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 5
  store i32 %20, ptr %21, align 4
  %22 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 6
  %23 = load i32, ptr %22, align 4
  %24 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 6
  store i32 %23, ptr %24, align 4
  %25 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 7
  %26 = load i32, ptr %25, align 4
  %27 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 7
  store i32 %26, ptr %27, align 4
  %28 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 8
  %29 = load i32, ptr %28, align 4
  %30 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 8
  store i32 %29, ptr %30, align 4
  %31 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 9
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 9
  store i32 %32, ptr %33, align 4
  %34 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 10
  %35 = load i32, ptr %34, align 4
  %36 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 10
  store i32 %35, ptr %36, align 4
  %37 = getelementptr inbounds [12 x i32], ptr %0, i64 0, i64 11
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr inbounds [12 x i32], ptr %1, i64 0, i64 11
  store i32 %38, ptr %39, align 4
  ret void
}

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #4

; Function Attrs: argmemonly mustprogress nocallback nofree nounwind willreturn writeonly
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #5

; Function Attrs: noinline nounwind optnone uwtable
define internal fastcc void @taichi_assert_format(ptr noundef %0, i1 noundef zeroext %1, ptr noundef %2) unnamed_addr #6 {
  %4 = alloca ptr, align 8
  %5 = alloca i8, align 1
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca ptr, align 8
  %9 = alloca %class.anon, align 8
  store ptr %0, ptr %4, align 8
  %10 = zext i1 %1 to i8
  store i8 %10, ptr %5, align 1
  store ptr %2, ptr %6, align 8
  store i32 0, ptr %7, align 4
  store ptr null, ptr %8, align 8
  %11 = load i8, ptr %5, align 1
  %12 = trunc i8 %11 to i1
  %13 = zext i1 %12 to i32
  %14 = icmp ne i32 %13, 0
  br i1 %14, label %15, label %16

15:                                               ; preds = %3
  br label %69

16:                                               ; preds = %3
  %17 = load ptr, ptr %4, align 8
  %18 = getelementptr inbounds %struct.LLVMRuntime, ptr %17, i32 0, i32 24
  %19 = load i64, ptr %18, align 8
  %20 = icmp ne i64 %19, 0
  br i1 %20, label %69, label %21

21:                                               ; preds = %16
  %22 = load ptr, ptr %4, align 8
  %23 = getelementptr inbounds %struct.LLVMRuntime, ptr %22, i32 0, i32 23
  %24 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 0
  store ptr %4, ptr %24, align 8
  %25 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 1
  store ptr %6, ptr %25, align 8
  %26 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 2
  store ptr %7, ptr %26, align 8
  %27 = getelementptr inbounds %class.anon, ptr %9, i32 0, i32 3
  store ptr %8, ptr %27, align 8
  br label %28

28:                                               ; preds = %28, %21
  %29 = atomicrmw volatile xchg ptr %23, i32 1 seq_cst, align 4
  %30 = icmp eq i32 %29, 1
  br i1 %30, label %28, label %mutex_lock_i32.exit.i.i.i, !llvm.loop !6

mutex_lock_i32.exit.i.i.i:                        ; preds = %28
  %31 = load ptr, ptr %9, align 8
  %32 = load ptr, ptr %31, align 8
  %33 = getelementptr inbounds %struct.LLVMRuntime, ptr %32, i64 0, i32 24
  %34 = load i64, ptr %33, align 8
  %.not.i.i.i.i = icmp eq i64 %34, 0
  br i1 %.not.i.i.i.i, label %35, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

35:                                               ; preds = %mutex_lock_i32.exit.i.i.i
  store i64 1, ptr %33, align 8
  %36 = load ptr, ptr %9, align 8
  %37 = load ptr, ptr %36, align 8
  %38 = getelementptr inbounds %struct.LLVMRuntime, ptr %37, i64 0, i32 21
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %38, i8 0, i64 2048, i1 false)
  %39 = load ptr, ptr %9, align 8
  %40 = load ptr, ptr %39, align 8
  %41 = getelementptr inbounds %struct.LLVMRuntime, ptr %40, i64 0, i32 21
  %42 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 1
  %43 = load ptr, ptr %42, align 8
  %44 = load ptr, ptr %43, align 8
  %45 = load i8, ptr %44, align 1
  %.not5.i.i.i.i.i = icmp eq i8 %45, 0
  br i1 %.not5.i.i.i.i.i, label %taichi_strlen.exit.thread.i.i.i.i, label %.lr.ph.i.i.i.i.i.preheader

.lr.ph.i.i.i.i.i.preheader:                       ; preds = %35
  br label %.lr.ph.i.i.i.i.i

.lr.ph.i.i.i.i.i:                                 ; preds = %.lr.ph.i.i.i.i.i, %.lr.ph.i.i.i.i.i.preheader
  %.07.i.i.i.i.i = phi ptr [ %47, %.lr.ph.i.i.i.i.i ], [ %44, %.lr.ph.i.i.i.i.i.preheader ]
  %.046.i.i.i.i.i = phi i64 [ %46, %.lr.ph.i.i.i.i.i ], [ 0, %.lr.ph.i.i.i.i.i.preheader ]
  %46 = add i64 %.046.i.i.i.i.i, 1
  %47 = getelementptr inbounds i8, ptr %.07.i.i.i.i.i, i64 1
  %48 = load i8, ptr %47, align 1
  %.not.i.i.i.i.i = icmp eq i8 %48, 0
  br i1 %.not.i.i.i.i.i, label %taichi_strlen.exit.i.i.i.i, label %.lr.ph.i.i.i.i.i, !llvm.loop !11

taichi_strlen.exit.i.i.i.i:                       ; preds = %.lr.ph.i.i.i.i.i
  %.lcssa = phi i64 [ %46, %.lr.ph.i.i.i.i.i ]
  %49 = call i64 @llvm.umin.i64(i64 %.lcssa, i64 2047)
  br label %taichi_strlen.exit.thread.i.i.i.i

taichi_strlen.exit.thread.i.i.i.i:                ; preds = %taichi_strlen.exit.i.i.i.i, %35
  %50 = phi i64 [ 0, %35 ], [ %49, %taichi_strlen.exit.i.i.i.i ]
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %41, ptr nonnull align 1 %44, i64 %50, i1 false)
  %51 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 2
  %52 = load ptr, ptr %51, align 8
  %53 = load i32, ptr %52, align 4
  %54 = icmp sgt i32 %53, 0
  br i1 %54, label %.lr.ph.i.i.i.i, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

.lr.ph.i.i.i.i:                                   ; preds = %taichi_strlen.exit.thread.i.i.i.i
  %55 = getelementptr inbounds %class.anon, ptr %9, i64 0, i32 3
  br label %56

56:                                               ; preds = %56, %.lr.ph.i.i.i.i
  %indvars.iv.i.i.i.i = phi i64 [ 0, %.lr.ph.i.i.i.i ], [ %indvars.iv.next.i.i.i.i, %56 ]
  %57 = load ptr, ptr %55, align 8
  %58 = load ptr, ptr %57, align 8
  %59 = getelementptr inbounds i64, ptr %58, i64 %indvars.iv.i.i.i.i
  %60 = load i64, ptr %59, align 8
  %61 = load ptr, ptr %9, align 8
  %62 = load ptr, ptr %61, align 8
  %63 = getelementptr inbounds %struct.LLVMRuntime, ptr %62, i64 0, i32 22, i64 %indvars.iv.i.i.i.i
  store i64 %60, ptr %63, align 8
  %indvars.iv.next.i.i.i.i = add nuw nsw i64 %indvars.iv.i.i.i.i, 1
  %64 = load ptr, ptr %51, align 8
  %65 = load i32, ptr %64, align 4
  %66 = sext i32 %65 to i64
  %67 = icmp slt i64 %indvars.iv.next.i.i.i.i, %66
  br i1 %67, label %56, label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", !llvm.loop !12

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit": ; preds = %56
  br label %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit"

"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit": ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit.loopexit", %taichi_strlen.exit.thread.i.i.i.i, %mutex_lock_i32.exit.i.i.i
  %68 = atomicrmw volatile xchg ptr %23, i32 0 seq_cst, align 4
  br label %69

69:                                               ; preds = %"_Z11locked_taskIZ20taichi_assert_formatE3$_0EvPvRKT_.exit", %16, %15
  ret void
}

; Function Attrs: alwaysinline mustprogress nounwind uwtable
define internal void @cpu_struct_for_block_helper(ptr nocapture noundef readonly %0, i32 noundef %1, i32 noundef %2) #7 {
_ZN11ListManager3getI7ElementEERT_i.exit:
  %3 = alloca %struct.RuntimeContext.2041, align 8
  %4 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 4
  %5 = load i32, ptr %4, align 4
  %6 = sdiv i32 %2, %5
  %7 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 3
  %8 = load i32, ptr %7, align 8
  %9 = sdiv i32 %8, %5
  %10 = srem i32 %2, %5
  %11 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 2
  %12 = load ptr, ptr %11, align 8
  %13 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 3
  %14 = load i32, ptr %13, align 8
  %15 = ashr i32 %6, %14
  %16 = sext i32 %15 to i64
  %17 = lshr i64 %16, 9
  %18 = getelementptr inbounds [256 x ptr], ptr %12, i64 0, i64 %17
  %19 = load atomic i64, ptr %18 acquire, align 8
  %.not.i.i.i = icmp ne i64 %19, 0
  tail call void @llvm.assume(i1 %.not.i.i.i)
  %20 = inttoptr i64 %19 to ptr
  %21 = and i64 %16, 511
  %22 = getelementptr inbounds ptr, ptr %20, i64 %21
  %23 = load atomic i64, ptr %22 acquire, align 8
  %24 = inttoptr i64 %23 to ptr
  %25 = getelementptr inbounds %struct.ListManager, ptr %12, i64 0, i32 1
  %26 = load i64, ptr %25, align 8
  %27 = load i32, ptr %13, align 8
  %notmask.i.i = shl nsw i32 -1, %27
  %28 = xor i32 %notmask.i.i, -1
  %29 = and i32 %6, %28
  %30 = sext i32 %29 to i64
  %31 = mul i64 %26, %30
  %32 = getelementptr inbounds i8, ptr %24, i64 %31
  %33 = getelementptr inbounds %0, ptr %32, i64 0, i32 1
  %34 = load i32, ptr %33, align 8
  %35 = mul nsw i32 %10, %9
  %36 = add nsw i32 %34, %35
  %37 = add nsw i32 %10, 1
  %38 = mul nsw i32 %37, %9
  %39 = add nsw i32 %34, %38
  %40 = getelementptr inbounds %0, ptr %32, i64 0, i32 1, i64 1
  %41 = load i32, ptr %40, align 4
  %42 = tail call i32 @llvm.smin.i32(i32 %41, i32 %39)
  %43 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 5
  %44 = load i64, ptr %43, align 8
  %45 = alloca i8, i64 %44, align 8
  %46 = load ptr, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %3, ptr noundef nonnull align 8 dereferenceable(32) %46, i64 32, i1 false)
  %47 = getelementptr inbounds %struct.RuntimeContext.2041, ptr %3, i64 0, i32 2
  store i32 %1, ptr %47, align 8
  %48 = icmp slt i32 %36, %42
  br i1 %48, label %49, label %75

49:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit
  %50 = getelementptr inbounds %struct.cpu_block_task_helper_context, ptr %0, i64 0, i32 1
  %51 = load ptr, ptr %50, align 8
  %52 = load ptr, ptr %11, align 8
  %53 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 3
  %54 = load i32, ptr %53, align 8
  %55 = ashr i32 %6, %54
  %56 = sext i32 %55 to i64
  %57 = lshr i64 %56, 9
  %58 = getelementptr inbounds [256 x ptr], ptr %52, i64 0, i64 %57
  %59 = load atomic i64, ptr %58 acquire, align 8
  %.not.i.i.i24 = icmp eq i64 %59, 0
  br i1 %.not.i.i.i24, label %_ZN11ListManager3getI7ElementEERT_i.exit26, label %60

60:                                               ; preds = %49
  %61 = inttoptr i64 %59 to ptr
  %62 = and i64 %56, 511
  %63 = getelementptr inbounds ptr, ptr %61, i64 %62
  %64 = load atomic i64, ptr %63 acquire, align 8
  %65 = inttoptr i64 %64 to ptr
  br label %_ZN11ListManager3getI7ElementEERT_i.exit26

_ZN11ListManager3getI7ElementEERT_i.exit26:       ; preds = %60, %49
  %66 = phi ptr [ %65, %60 ], [ null, %49 ]
  %67 = getelementptr inbounds %struct.ListManager, ptr %52, i64 0, i32 1
  %68 = load i64, ptr %67, align 8
  %69 = load i32, ptr %53, align 8
  %notmask.i.i25 = shl nsw i32 -1, %69
  %70 = xor i32 %notmask.i.i25, -1
  %71 = and i32 %6, %70
  %72 = sext i32 %71 to i64
  %73 = mul i64 %68, %72
  %74 = getelementptr inbounds i8, ptr %66, i64 %73
  call void %51(ptr noundef nonnull %3, ptr noundef nonnull %45, ptr noundef nonnull %74, i32 noundef %36, i32 noundef %42) #1
  br label %75

75:                                               ; preds = %_ZN11ListManager3getI7ElementEERT_i.exit26, %_ZN11ListManager3getI7ElementEERT_i.exit
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i64 @llvm.umin.i64(i64, i64) #8

; Function Attrs: inaccessiblememonly nocallback nofree nosync nounwind willreturn
declare void @llvm.assume(i1 noundef) #9

; Function Attrs: nocallback nofree nosync nounwind readnone speculatable willreturn
declare i32 @llvm.smin.i32(i32, i32) #8

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #10

; Function Attrs: argmemonly nocallback nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #10

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn }
attributes #1 = { nounwind }
attributes #2 = { nofree norecurse nounwind }
attributes #3 = { argmemonly mustprogress nofree norecurse nosync nounwind willreturn }
attributes #4 = { argmemonly mustprogress nocallback nofree nounwind willreturn }
attributes #5 = { argmemonly mustprogress nocallback nofree nounwind willreturn writeonly }
attributes #6 = { noinline nounwind optnone uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline mustprogress nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { nocallback nofree nosync nounwind readnone speculatable willreturn }
attributes #9 = { inaccessiblememonly nocallback nofree nosync nounwind willreturn }
attributes #10 = { argmemonly nocallback nofree nosync nounwind willreturn }

!llvm.ident = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5}

!0 = !{!"Debian clang version 15.0.6"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 7, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 2}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
