#!/usr/bin/env bash
set -euo pipefail
cd /workspace/human-cognome-project
source /workspace/.hcp-setup/env.sh
source engine/build/engine-env.sh
hcp_b1_evidence=${1:?evidence directory}
hcp_b1_source=${2:?tested source}
test "$(git rev-parse HEAD)" = "$hcp_b1_source"
mkdir -p "$hcp_b1_evidence/matrix"
for workers in 1 2; do
  for path in bulk direct; do
    for shape in default no-unroll; do
      config="$workers-$path-$shape"
      out="$hcp_b1_evidence/matrix/$config"
      mkdir -p "$out/original" "$out/selection" "$out/contact-ticks"
      args=(--threads "$workers")
      if [ "$path" = direct ]; then args+=(--direct); fi
      if [ "$shape" = no-unroll ]; then args+=(--compiler-no-unroll); fi
      printf '%s start %s\n' "$(date -u +%FT%TZ)" "$config" >> "$hcp_b1_evidence/matrix-progress.txt"
      HCP_C3_IR_DIR="$out/original" engine/build/live_hierarchy_test "${args[@]}" --case ir > "$out/original/collection.txt" 2>&1
      engine/build/live_hierarchy_test "${args[@]}" --audit-ir "$out/original" > "$out/original/audit.txt" 2>&1
      for module in "$out/original/"*.ll; do
        cmp "$module" <(gzip -dc "engine/tests/live_hierarchy/refresh-v1/ir/$config/$(basename "$module").gz")
        sha256sum "$module" >> "$out/original-byte-identical.sha256"
      done
      HCP_B1_IR_DIR="$out/selection" engine/build/live_hierarchy_test "${args[@]}" --case selection_ir > "$out/selection/collection.txt" 2>&1
      for module in "$out/selection/"*.ll; do
        cmp "$module" <(gzip -dc "engine/tests/native_selection/v1/ir/$config/$(basename "$module").gz")
        sha256sum "$module" >> "$out/selection-byte-identical.sha256"
      done
      HCP_B1_TICK_IR_DIR="$out/contact-ticks" engine/build/live_hierarchy_test "${args[@]}" --case contact_tick_ir > "$out/contact-ticks/collection.txt" 2>&1
      test "$(find "$out/contact-ticks" -name '*.ll' | wc -l)" = 68
      for module in "$out/original/"*.ll "$out/selection/"*.ll "$out/contact-ticks/"*.ll; do
        /workspace/.hcp-setup/sysroot/usr/lib/llvm-15/bin/opt -passes=verify -disable-output "$module"
      done
      if [ "$shape" = no-unroll ]; then
        for family in hierarchy refresh selection contact_tick; do
          case_args=()
          if [ "$family" != hierarchy ]; then case_args=(--case "$family"); fi
          engine/build/live_hierarchy_test "${args[@]}" "${case_args[@]}" > "$out/$family.txt" 2>&1
          rg -q 'live_hierarchy_matrix,case_failures=0 PASS' "$out/$family.txt"
        done
      fi
      printf '%s passed %s\n' "$(date -u +%FT%TZ)" "$config" >> "$hcp_b1_evidence/matrix-progress.txt"
    done
  done
done
printf '%s matrix complete\n' "$(date -u +%FT%TZ)" >> "$hcp_b1_evidence/matrix-progress.txt"
