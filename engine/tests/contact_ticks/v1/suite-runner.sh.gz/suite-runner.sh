#!/usr/bin/env bash
set -euo pipefail
cd /workspace/human-cognome-project
source /workspace/.hcp-setup/env.sh
hcp_b1_evidence=${1:?evidence directory}
hcp_b1_source=${2:?tested source}
test "$(git rev-parse HEAD)" = "$hcp_b1_source"
mkdir -p "$hcp_b1_evidence/ctest"
ctest --test-dir engine/build -N > "$hcp_b1_evidence/ctest/inventory.txt"
rg -q 'Total Tests: 109' "$hcp_b1_evidence/ctest/inventory.txt"
sha256sum engine/build/live_hierarchy_test engine/build/warm_active_integration engine/build/taichi-runtime/runtime_x64.bc > "$hcp_b1_evidence/binaries.sha256"
/workspace/.hcp-setup/sysroot/usr/lib/llvm-15/bin/clang++ --version > "$hcp_b1_evidence/toolchain.txt"
/workspace/.hcp-setup/sysroot/usr/lib/llvm-15/bin/llvm-config --version >> "$hcp_b1_evidence/toolchain.txt"
/workspace/.hcp-setup/sysroot/usr/lib/llvm-15/bin/llc --version >> "$hcp_b1_evidence/toolchain.txt"
cmake -LA -N engine/build > "$hcp_b1_evidence/cmake.txt"
cp /proc/cpuinfo "$hcp_b1_evidence/cpuinfo.txt"
printf '%s CPU suite start\n' "$(date -u +%FT%TZ)" >> "$hcp_b1_evidence/suite-progress.txt"
unset TI_LIB_DIR
if ctest --test-dir engine/build -j2 --output-on-failure --output-log "$hcp_b1_evidence/ctest/console.txt" --output-junit "$hcp_b1_evidence/ctest/results.xml" > "$hcp_b1_evidence/ctest/progress.txt" 2>&1; then
  cp engine/build/Testing/Temporary/LastTest.log "$hcp_b1_evidence/ctest/LastTest.log"
else
  cp engine/build/Testing/Temporary/LastTest.log "$hcp_b1_evidence/ctest/LastTest.log"
  exit 1
fi
printf '%s CPU suite passed\n' "$(date -u +%FT%TZ)" >> "$hcp_b1_evidence/suite-progress.txt"
source engine/build/engine-env.sh
engine/build/engine_devices --cpu-only > "$hcp_b1_evidence/backend.txt" 2>&1
bash engine/scripts/run_warm_active_acceptance.sh engine/build hcp-linguistics-validation hcp_c3_core_20261027231537_16221 hcp_c3_ling_20261027231537_16221 > "$hcp_b1_evidence/integration.txt" 2>&1
printf '%s integration passed\n' "$(date -u +%FT%TZ)" >> "$hcp_b1_evidence/suite-progress.txt"
