# PhysX 5 / O3DE Mapping for HCP Engine Operations
**Date:** 2026-05-11  
**Scope:** Inference-side PhysX readiness scouting. Resolution-side is substantially built; this report focuses on what's available, what fits, and where gaps exist for the inference engine.  
**Reads first:** `hcp-engine/docs/physx5-reference.md` and `o3de-physx-wrapping.md` — those cover the resolution-side foundations in detail. This document layers the inference-side analysis on top.

---

## Summary: Biggest Wins / Biggest Gaps

### Biggest wins (non-obvious fits already available)

1. **Phase group reassignment IS envelope activation.** Switching an envelope in or out of the active join set is a CUDA memcpy of ~800 bytes (200 PxU32 phase values) + `raiseFlags(eUPDATE_PHASE)`. Not a buffer rebuild. This means live envelope prominence re-weighting during inference is essentially free. The `physx-phase2-tiered-consultation.md` confirms the partial-update mechanism works.

2. **The `velocity.w` channel is free per-particle storage.** PhysX's PBD particles expose `PxVec4* velocities` where `.w` is confirmed unused by the SDK. This is one float per particle, already in GPU memory, readable in CUDA kernels — zero allocation cost. Maps directly to continuous spin/charge parameters (truth confidence, polarity magnitude, relational weight) without a separate buffer.

3. **`PxNeighborhoodIterator` is the join traversal primitive.** For any particle, the iterator over its spatial neighbors is computed as a byproduct of the broadphase — no extra cost. In `onAdvance()` CUDA kernels, iterating the neighborhood of each particle *is* iterating the active interstice for that locus. Inference-side "find data by interstice" maps directly to neighborhood iteration. Already proven in bond force injection work.

4. **`onAdvance()` CUDA callback is the force field engine.** PhysX 5.1.1 removed the old `PxForceField` class entirely. The replacement is better: a CUDA kernel launched on the simulation stream with direct device pointer access to all particle data. This means arbitrary charge propagation, relational gradients, and directional force fields are all custom CUDA, with no performance gap versus a native implementation.

5. **Von Mises stress scalar is a quality/confidence score.** For inference candidate paths modeled as soft bodies (`PxSoftBody`), `eTET_STRESSCOEFF` gives a per-tetrahedron scalar: zero = perfect fit, non-zero = residual tension. This is directly usable as an inference confidence metric without any additional instrumentation.

### Biggest gaps (need custom work)

1. **No native 5-state particle history.** PhysX tracks presence and activity (invMass > 0 = active) but has no "was-active vs never-been-active" distinction. The third axis of the LIVE/DIE/TRUE model requires either 3 phase group bits (bits [17-19], GPU-visible) or a host-side enum array. This must be designed explicitly — it won't emerge from PhysX defaults.

2. **No native force field.** Inference-side charge propagation and force-dynamic chains need custom CUDA in `onAdvance()`. The primitives are there (velocity buffers, neighborhood iterator, CUDA stream) but the propagation model is custom code. Non-trivial for directional / graph-topological propagation where the graph edges aren't spatial.

3. **Particle-particle contact has no callback.** `PxSimulationEventCallback::onContact` fires for rigid body pairs only. For action-molecule firing (particle X touches particle Y, fire state transition), the detection loop must be written into `onPostSolve()` CUDA kernel + device flag → host readback → next-frame dispatch. One-step latency on all action triggers.

4. **Deep container nesting has a cost cliff.** Each truth-scope container ideally = separate PxScene (clean phase namespace isolation). Each scene costs ~80MB GPU RAM. 4-5 containers = fine on 8GB. 10+ levels of nesting = GPU memory wall. Containers above depth ~4 need virtual isolation via phase group namespace partitioning (not separate scenes), which exhausts the 20-bit namespace at ~5 bits per nesting level.

5. **Relational graph topology is invisible to PhysX.** The engine knows spatial proximity, not semantic edge structure. For inference paths that follow relation edges rather than spatial proximity, the edge weights must be injected as a custom GPU buffer and the traversal written as a CUDA kernel. PhysX provides the execution substrate (CUDA stream, callback hooks, GPU memory management) but contributes nothing to the relational graph itself.

---

## Operation Class Analysis

### 1. Parallel Structured-Join Evaluation

*Multi-way joins across simultaneously-active envelope arrays. The central HCP operation.*

| Aspect | PhysX Mechanism | Detail |
|--------|----------------|--------|
| Per-envelope array | `PxPBDParticleSystem` + `PxParticleBuffer` | One PBD system per active envelope or envelope constellation; each has its own particle buffer |
| Join key / locus anchor | Spatial position (X, Y, Z) in PBD grid | Particles at same spatial location interact = join happens; Z-axis encodes token identity, providing fine join discrimination |
| Multi-way join | Multiple buffers in one scene | Phase group flags (`eSelfCollide`) control which groups interact; different groups = zero broadphase pairs = no join. Activating a join = assigning the relevant groups |
| Join predicate filter | `PxParticlePhaseFlags` (20-bit group + 4 flags) | Full 20-bit namespace with separate PxScene per major operation space; exact-equality group matching is the filter |
| Parallel execution | Single `simulate()` call | All joins in all active systems computed in one GPU dispatch; broadphase is GPU-accelerated (`PxBroadPhaseType::eGPU`) |
| Prominence re-weighting | Phase group reassignment (~800-byte CUDA memcpy) | Activating/deactivating an envelope in a join = reassigning phase IDs for its particle set. Microsecond operation. |
| Join result readback | `onPostSolve()` callback or post-`fetchResults()` host read | Result is which particle pairs made contact; host assembles the intersection |

**O3DE exposure:** NOT wrapped. All PBD particle system management is raw SDK via the Gem's `GetNativePointer()` pattern on the O3DE-managed PxScene.

**Verdict: Use raw SDK (from Gem).** The infrastructure is already present and proven. The key design insight is that envelope intersection is not a special operation — it's the default physics behavior when particles from multiple envelopes share a phase group and are spatially co-located.

**Non-obvious win:** Phase group reassignment as envelope activation means the inference engine can adjust envelope constellation in real time between simulate() calls with negligible cost. There's no "reload" step. The system continuously operates on whatever envelopes are currently marked active via their phase groups.

---

### 2. Broadphase Filtering / Spatial Queries

*Resolution-side already uses this heavily; documenting inference-side extensions.*

| Operation | PhysX Mechanism | O3DE Exposure |
|-----------|----------------|---------------|
| Particle proximity detection | PBD 3D spatial hash (`setGridSizeX/Y/Z`) | NOT wrapped — raw PBD |
| Particle neighbor iteration | `PxNeighborhoodIterator` in `onAdvance()` callback | NOT wrapped — CUDA kernel |
| Rigid body raycasting | `PxSceneQuerySystem::raycast()` | Partially wrapped via AzPhysics::SceneInterface |
| Rigid body overlap test | `PxSceneQueryExt::overlapAny/Multiple()` | Partially wrapped |
| Rigid body sweep | `PxSceneQuerySystem::sweep()` | Partially wrapped |
| Custom spatial query tree | `PxCustomSceneQuerySystem` + `PxCustomSceneQuerySystemAdapter` | NOT wrapped |
| AABB broadphase (standalone) | `PxCreateBroadPhase()` + `PxCreateAABBManager()` | NOT wrapped |
| Scene query update mode | `setUpdateMode(eDYNAMIC_TREE_INCREMENTAL/DEFERRED)` | NOT wrapped |

**Gap:** `raycast()`, `sweep()`, and `overlap()` operate on rigid bodies/shapes only — NOT PBD particles. For particle-space range queries (e.g., "find all particles within R of this locus"), you must either: (a) use the neighborhood iterator inside `onAdvance()`, or (b) use `PxCustomSceneQuerySystem` to build a secondary spatial index over particle positions. Option (a) is already in use and is the right path for inference-side traversal. Option (b) is available if a persistent queryable index over particle positions is needed outside the simulation step.

**Non-obvious win:** `PxCustomSceneQuerySystem` (extensions/`PxCustomSceneQuerySystem.h`) allows replacing the scene's built-in BVH query system with a custom implementation. If inference-side queries need a different spatial structure (e.g., semantic proximity space rather than Euclidean), this is the hook.

**Verdict: Use raw SDK + existing neighborhood iterator infrastructure. PxCustomSceneQuerySystem flagged for potential use if non-Euclidean query space becomes needed.**

---

### 3. Particle State with Attached Binary Properties (5-State LIVE/DIE/TRUE)

*Five states: absent / present+will-be-active / present+is-active / present+was-active / present+never-been-active.*

| State | PhysX Mechanism | Notes |
|-------|----------------|-------|
| **absent** | Not allocated in buffer, OR particle ID past `setNbActiveParticles()` boundary | Particles can't truly be removed from PBD buffers (no resize). "Absent" = beyond the active count boundary |
| **present + will-be-active** | `invMass = 0` in active region + host flag | Static in position, not participating in dynamics. "Gestating" state |
| **present + is-active** | `invMass > 0`, in active buffer region | Full participation in dynamics |
| **present + was-active** | `invMass = 0`, moved to dead zone, OR promoted to `PxRigidDynamic` | Particle "fired then stopped." For word-level tokens, promotion to rigid body is the canonical "was-active" form |
| **present + never-been-active** | Phase group bit flag (3 bits: [17-19]) OR host-side enum | **Critical gap.** This state is NOT representable in PhysX natively. Must be tracked externally. The distinction from was-active (falsified claim vs. ceased true claim) has downstream consequence for inference — same surface appearance, different semantics |

**Per-particle data channels available:**
- `phases` (PxU32): 20-bit group + 4 flags. **Use bits [17-19] for 3-bit activity history if GPU-visible history is needed.**
- `positionInvMass.w` (PxReal): invMass. Binary active/inactive axis.
- `velocities.w` (PxReal): **confirmed unused by SDK** — available for continuous state parameter (e.g., charge magnitude).
- No user data channel exists in the PBD API.

**O3DE exposure:** invMass setting and particle count management: NOT wrapped. Phase group flags: NOT wrapped.

**Verdict: Wrap thinly in Gem.** The 3 active-region states (will-be-active, is-active, was-active) map to existing PhysX primitives. The critical fifth state (never-been-active / falsified) requires either: (a) 3 bits in the phase group [17-19] — GPU-visible but consumes precision from the type namespace — or (b) a host-side `uint8_t` parallel array. Recommend option (b) for the LIVE/DIE particle history; use phase group bits for the TRUE truth-state attachment since that participates in inference joins.

**Non-obvious win:** Encoding TRUE's 5-state directly in phase bits means inference CUDA kernels can filter by truth state without host-side array lookups. For example, "find all particles where truth was-active (truth changed)" = broadphase query against a specific phase group range. Zero additional data transfer.

---

### 4. Force-Field Propagation / Charge Dynamics

*Inference-side: force-dynamic chains, charge propagation along relational edges, mitigation.*

| Mechanism | PhysX Primitive | Suitability |
|-----------|----------------|-------------|
| **Custom CUDA force kernel** | `onAdvance()` callback on `PxParticleSystemCallback` | **Primary path.** Direct device-pointer access to velocity buffers + neighborhood iterator. Write arbitrary charge propagation as CUDA. |
| Per-step iteration | `onSolve()` on `PxCustomParticleSystemSolverCallback` (eCUSTOM solver) | Called per solver iteration — allows charge to evolve within a single timestep. Higher fidelity than onAdvance() alone. |
| Cohesion / adhesion field | `PxPBDMaterial::cohesion`, `adhesion`, `adhesionRadiusScale` | Approximates uniform attractive/repulsive charge field for same-material particles. No directional control. Free (no CUDA needed). |
| Viscosity gradient | `PxPBDMaterial::viscosity` | Resistance-to-relative-motion — approximates charge mitigation (field weakening with propagation distance). |
| Wind vector | `PxPBDParticleSystem::setWind(PxVec3)` | Global directional force field. Too coarse for semantic use, but could model a systematic "inference direction" bias in a space. |
| Spring forces | `PxParticleSpring` (stiffness, damping) | Explicit pair-wise force channels. Stiffness = relational force strength. Works for graph-edge-explicit charge paths. |
| Rigid body drive | `PxD6Joint` position/velocity drive | For rigid-body-level force dynamics (word-cluster propagation) |
| Direct impulse | `PxRigidBody::addForce()` with `eIMPULSE` | For action-molecule firing at rigid body level |

**Confirmed gap:** `PxForceField` as a named class does not exist in PhysX 5.1.1. It was present in PhysX 3.x era and removed. The canonical replacement is the `onAdvance()` CUDA callback, which is architecturally superior (no fixed field shapes, full GPU-native propagation).

**O3DE exposure:** `addForce()` on rigid bodies is wrapped. PBD material parameters, onAdvance callback, CUDA kernels: NOT wrapped.

**Verdict: Need custom CUDA kernel for inference-side charge propagation.** PBD material adhesion/cohesion parameters cover simple uniform charge fields at zero cost. Directional propagation along semantic graph edges (the primary inference-side operation) is custom CUDA using the neighborhood iterator + a companion GPU buffer holding relational edge weights. This is expected and the SDK provides all the hooks needed.

**Non-obvious gap:** The relational graph (which particles are connected and by what weight) is **semantically defined, not spatially defined**. PhysX's broadphase finds spatial neighbors, not semantic neighbors. For inference over the relational structure (following the NSM prime operator graph), the graph topology must be materialized as a GPU-side adjacency/weight structure and traversed in the CUDA kernel — PhysX doesn't contribute to the traversal itself, only to the execution substrate. This is the fundamental inference-side design challenge.

---

### 5. Constraint Solving / Pass-Fail Branching

*Parallel candidate interpretation paths: some survive (constraints satisfied), some collapse.*

| Mechanism | PhysX Primitive | HCP Use |
|-----------|----------------|---------|
| Parallel candidate paths | Separate `PxParticleBuffer` per candidate (same scene) or separate `PxPBDParticleSystem` per candidate | Phase group isolation ensures candidates don't interfere with each other |
| Constraint as survival condition | `PxParticleSpring` stiffness + `onPostSolve()` convergence check | High stiffness = hard constraint; candidate converges (low velocity) = passes; diverges = fails |
| Hard constraint with break detection | `PxConstraint::setFlag(eBROKEN)` + `getForce()` | Constraint-break = explicit fail event. Works for rigid-body-level candidates |
| Convergence = pass | `PxSoftBody::isSleeping()` + Von Mises stress | Sleep = satisfied; stress score = confidence. For FEM-modeled candidates |
| Branch surviving check | `onPostSolve()` velocity magnitude per particle group | Candidates below velocity threshold have converged; above threshold are still unresolved |
| Winner selection | Host-side post-`fetchResults()` comparison | O(K) CPU decision over K surviving candidates. Non-GPU. Fine at expected K values |
| Constraint force monitoring | `PxConstraint::getForce(linear, angular)` | For rigid bond-based candidates: zero force = equilibrium = pass |
| D6 joint as bounded constraint | `PxD6Joint` with `setLinearLimit()` | Range-limited motion: outside range = violation, candidate fails |

**O3DE exposure:** D6Joint, fixed joint, spherical joint: wrapped. PxConstraint raw, PxSoftBody, spring stiffness, velocity monitoring in callbacks: NOT wrapped.

**Verdict: Use raw SDK. Phase-gated tier model already implements this pattern.** The same mechanism described for vocabulary tier resolution (separate phase groups, phase group reassignment for advancement) is the inference branching substrate. Candidate paths = distinct phase groups; survival = phase group persists after convergence check; collapse = phase group reassigned to dead zone.

**Non-obvious win:** For highly parallel branching (100+ candidates), the phase group budget is 20 bits per scene. With 4 bits reserved for branch identity, 16 concurrent branches per scene with full 16-bit type namespace. For more branches: use separate PBD systems within one scene (each system has its own particle set, all in the same phase namespace — but separate solver work units). This is the trade-off between concurrency count and per-branch type expressiveness.

---

### 6. Nested Scope Containers

*Arbitrarily-nested truth-scopes: fiction, hypotheticals, beliefs-about-beliefs, PBDs.*

| Nesting Depth | Recommended Mechanism | Cost | Isolation |
|--------------|----------------------|------|-----------|
| Depth 1-4 (outer scopes) | Separate `PxScene` per scope | ~80MB GPU RAM per scene | Full: independent phase namespace, gravity, broadphase config |
| Depth 5-10 (mid nesting) | Phase group namespace partitioning within shared scene | ~0 MB additional RAM; ~5 bits per nesting level | Virtual: same broadphase, no cross-scope interaction IF groups are correctly partitioned |
| Depth 10+ (deep fiction, dreams-within-dreams) | Host-side scope stack + no physics isolation | 0 MB | Host-only: scope tracking in CPU data structures, physics not involved |

**PhysX primitives for scope containers:**

| Primitive | Scope Use |
|-----------|-----------|
| `PxPhysics::createScene()` | Creates isolated simulation context. One scene per outer container. |
| `PxAggregate` | Groups actors for broadphase optimization. NOT a coordinate isolation mechanism — all aggregates share the parent scene. Useful for clustering all actors within a container scope for efficient broadphase. |
| `PxArticulationReducedCoordinate` | Kinematic chain with nested local coordinate frames. Useful for structured hierarchical containment (known fixed depth, parent-child frame relationships). NOT suitable for arbitrary-depth dynamic nesting. |
| `PxScene::shiftOrigin()` | Repositions entire scene reference frame. Can be used to "re-anchor" a scene to a new reference point when a container scope changes its reference frame. Global operation — affects all actors. |
| Phase group namespace partitioning | Within one scene: bits [16-19] = scope ID (16 scopes), bits [0-15] = type. Different scope IDs = zero broadphase pairs = full isolation at zero memory cost. |

**O3DE exposure:** Creating additional PxScene instances requires raw `PxPhysics::createScene()`. O3DE's SceneInterface manages one primary scene per "simulation world" — the HCP Gem already demonstrates the two-scene pattern (`m_pxScene` + `m_charWordScene` in `HCPParticlePipeline.h`). Extension to N scenes for N container scopes follows the same pattern.

**Verdict: Wrap thinly in Gem. Separate scene per outer container scope is the right architecture; phase group partitioning for mid-depth virtual scoping. Need a scope registry in the Gem: container scope ID → PxScene handle (or phase group range for virtual scopes).**

**Critical design question (flag for Patrick):** At what depth does the container model switch from separate-scene to virtual-scope? The ~80MB per scene cost is the constraint. On 8GB VRAM: 4 outer container scenes = 320MB overhead (acceptable). 10 = 800MB (approaching uncomfortable). The decision sets the depth limit for "real" physics isolation vs. virtual isolation.

---

### 7. Per-Particle Relational Parameters (Spin / Attached Property)

*A property attached to a particle that shapes its interactions without changing particle identity.*

**Available per-particle GPU data channels:**

| Channel | Width | Currently Used | Available for Spin |
|---------|-------|---------------|-------------------|
| `phases` bits [0-19] | 20 bits | Type encoding (class, tier, state) | Bits [17-19] available: 3-bit spin enum (8 values) if type namespace can afford it |
| `positionInvMass.w` | float32 | invMass (0 = static, >0 = dynamic) | Not available — semantically reserved |
| `velocities.w` | float32 | **Confirmed unused by SDK** | **Free: one continuous spin parameter per particle** |
| No user data channel | — | N/A | N/A — confirmed in `PxParticleBuffer.h` |

**Recommended spin storage pattern (from physx-superposition-response Q4, extended):**

| Spin type | Storage | Access |
|-----------|---------|--------|
| Binary grammatical role / polarity (NOT flag) | Phase bit [17] | GPU-visible, collision filtering |
| 3-value truth attachment (TRUE.is-active / was-active / never-active) | Phase bits [18-19] | GPU-visible |
| Continuous charge magnitude / confidence | `velocity.w` (free channel) | GPU-visible in CUDA kernels |
| Rich relational metadata (argument structure, PBD perspective ID, scope attachment) | Host-side `std::vector<SpinData>` + companion device buffer | CPU-accessible; GPU-accessible via device copy |
| Relational edge weights (for graph-traversal propagation) | Separate `float*` device buffer, one per particle | GPU-accessible in CUDA force kernels |

**O3DE exposure:** Phase array management and velocity buffer access: NOT wrapped. All raw SDK.

**Verdict: Wrap thinly in Gem.** The `velocity.w` free channel is the highest-value quick win — no allocation, GPU-visible, use it for the primary continuous relational parameter. Phase bits [17-19] for binary/ternary spin states that must participate in collision filtering (e.g., truth polarity affecting whether particles interact). Companion device buffer for full relational parameter sets.

**Non-obvious win:** Since `velocity.w` has no physics meaning to PhysX (the solver treats it as an ignored fourth component of velocity), it persists correctly through every solve step without being overwritten. It can carry a relational parameter set at simulation start and read it back intact after `fetchResults()`. Zero maintenance cost.

---

### 8. State-Transition Triggering (Action Molecule Firing)

*Sub-routine invocation: action primes take substantive arguments, transition state S₁→S₂ at a temporal anchor.*

| Trigger Mechanism | PhysX Primitive | Particle or Rigid | Latency |
|-------------------|----------------|-------------------|---------|
| Spatial proximity detection | `PxNeighborhoodIterator` in `onPostSolve()` CUDA kernel | Particles | Same-step |
| Convergence-triggered transition | Velocity below threshold → device flag → host readback | Particles | One step |
| Shape contact (rigid) | `PxSimulationEventCallback::onContact` | Rigid bodies | Same-step (callback) |
| Sleep event (rigid) | `PxSimulationEventCallback::onSleep` | Rigid bodies | Same-step |
| Constraint break event | `PxSimulationEventCallback::onConstraintBreak` | Rigid body joints | Same-step |
| Kinematic target drive | `PxRigidBody::setKinematicTarget()` | Rigid bodies | Continuous |
| Explicit velocity change | `onAdvance()` CUDA kernel: modify velocity buffer | Particles | Same-step |

**Confirmed gap:** `onContact` callbacks fire for rigid body shape pairs ONLY — NOT for PBD particle pairs. For particle-level action triggers, the detection must happen inside a CUDA kernel launched from `onPostSolve()`, with the trigger condition stored as a device flag, read back by the host after `fetchResults()`, and the resulting state transition dispatched on the next frame.

**Action molecule firing pipeline (particle level):**
```
Frame N:
  onPostSolve() CUDA kernel:
    → check proximity + phase group compatibility (action particle + argument particles)
    → if satisfied: write flag to device trigger buffer
  
fetchResults():
  → host reads trigger buffer (copyDToH)
  → host identifies: which action prime fired, which argument particle IDs
  
Frame N+1:
  onAdvance() CUDA kernel:
    → propagate state transition to affected particle group
    → update phase group bits (activity history)
    → modify velocity.w spin parameter
```

**One-step latency note:** For NSM molecule-level operations (acting at word/phrase scale), one-step latency is imperceptible and architecturally fine. For sub-word operations or very dense action cascades, the one-step delay compounds. If this matters, `PxCustomParticleSystemSolverCallback::onSolve()` is called per solver iteration within a single step — action firing can happen mid-solve at the cost of more complex state management.

**Temporal anchor integration:** The temporal primes (NOW, BEFORE, AFTER) as coordinate frame anchors are not directly representable in PhysX's time model (PhysX knows `dt`, not semantic time). The temporal anchor is a **host-side scheduler** that dispatches action CUDA kernels at the correct simulation step. The physics engine handles the propagation; the host handles when to trigger it. This is a clean separation.

**O3DE exposure:** `onContact`, `onSleep`, `onWake` on rigid bodies: wrapped via `PhysX::SceneSimulationEventCallback`. Particle-level trigger detection in CUDA kernels: NOT wrapped.

**Verdict: Need custom CUDA kernel for particle-level triggers; thin Gem wrapper for the host-side dispatch scheduler.**

---

## O3DE Gem Architecture Summary

| PhysX Feature | O3DE Status | HCP Access Method |
|--------------|-------------|-------------------|
| PxPBDParticleSystem, PxParticleBuffer | NOT wrapped | Raw SDK via `GetNativePointer()` pattern on PxScene |
| PxScene (additional scenes) | NOT wrapped | `PxPhysics::createScene()` directly, same CUDA context |
| PxParticleSystemCallback (onAdvance, onPostSolve) | NOT wrapped | Register directly on PxPBDParticleSystem |
| PxCustomParticleSystemSolverCallback | NOT wrapped | Set solver type to eCUSTOM, register callback |
| PxSoftBody, PxFEMSoftBodyMaterial | NOT wrapped | Raw SDK |
| PxAggregate | NOT wrapped | Raw SDK |
| PxCudaContextManager | NOT wrapped (O3DE may have one; reuse via GetNativePointer) | Reuse O3DE's or create own |
| PxD6Joint, PxFixedJoint, PxSphericalJoint | Wrapped | O3DE joint components or raw via GetNativePointer |
| PxRigidDynamic (addForce, sleep) | Wrapped | O3DE RigidBody API or raw |
| PxScene spatial queries (raycast/sweep/overlap) | Partially wrapped | AzPhysics::SceneInterface for rigid queries; raw for custom |
| PxCustomSceneQuerySystem | NOT wrapped | Raw SDK extension |
| PxSimulationEventCallback (onContact, onSleep) | Wrapped | PhysX::SceneSimulationEventCallback |
| CUDA kernel launch | NOT wrapped (inherently) | PxScopedCudaLock + cudaLaunchKernel on provided CUstream |

**Bottom line (unchanged from prior analysis):** O3DE wraps game-physics rigid body mechanics well. Everything the HCP engine needs (particles, soft bodies, GPU kernels, custom callbacks, additional scenes) is below the O3DE layer. The Gem reaches directly into PhysX raw SDK, which is explicitly supported and already working in the resolution-side code.

---

## External O3DE Gem Repos

A quick search found no community O3DE Gems providing extended PBD particle tooling, custom GPU physics kernels, or non-Euclidean spatial query extensions. The NVIDIA PhysX ecosystem for O3DE is production game physics (ragdolls, cloth, vehicles) — not scientific simulation extensions. The HCP Gem is in novel territory and the custom kernel path is not supplementable from community sources.

---

---

## Addendum 2026-05-11: Join and Filter Mechanisms — Deep Scan

*Priority request from opus/team-lead: go deeper on advanced join and filter capabilities specifically. What does PhysX expose that we'd otherwise build from scratch?*

---

### The Hard Architectural Fact First

PhysX has two completely separate filter stacks — one for particles, one for rigid bodies — and they do not share primitives. This determines what's available at each LoD level.

| Interaction type | Filter mechanism | Where it runs | Predicate power |
|-----------------|-----------------|---------------|-----------------|
| Particle ↔ particle | Phase group exact-match **only** | GPU, inside spatial hash | Group equality. Nothing else. |
| Particle system ↔ rigid body | `PxFilterData` (128 bits) + filter shader | CPU, per new broadphase pair | Arbitrary bitfield function |
| Rigid ↔ rigid | `PxFilterData` + filter shader + callback | CPU, per new pair | Full actor pointer access |
| Scene query (rigid only) | `PxQueryFilterCallback` pre/post | CPU, per candidate | Shape + actor access; two-stage |
| BVH subtree (rigid queries) | `PxCustomSceneQuerySystemAdapter::processPruner()` | CPU, per pruner tree | Skip entire subtrees |

For particle-level join work (which is most of what we do), phase groups are the whole toolkit. For rigid-body-level work (word/phrase/entity LoD), a rich multi-stage filter stack is available.

---

### The Complete Filter Toolkit

#### A. Phase Groups — GPU-Native Join Discriminator (Particles)

Already documented, but the precise semantics for join design:

- `eParticlePhaseGroupMask` = bits [0-19], 20-bit group ID. **Exact equality** between two particles' group IDs is the join predicate. No partial matching, no range, no bitfield AND — equality only.
- `eParticlePhaseSelfCollide` (bit 20): particle interacts with same-group particles. Off = particle never joins with anyone (isolated).
- Different group IDs = **zero broadphase work** — the spatial hash doesn't even generate a candidate pair. True prune, not filter.
- `createPhase(material, flags)` returns a new phase ID and associates a `PxPBDMaterial` with it. **The material IS the join behavior**: cohesion, adhesion, friction, viscosity control how particles in that phase interact with each other when they do match. Different phases = different join strengths.

**Join design implication:** To encode a k-way join predicate over particles, you must encode it as group membership. The predicate "particles A and B should join" = "assign them the same phase group." Predicates that can't be reduced to group identity (e.g., "join if A's token type is in set X and B's token type is in set Y") require either: (a) pre-computing the result and assigning groups accordingly, or (b) doing it in a CUDA kernel in `onAdvance()` with velocity modification rather than using the broadphase join.

**What the 20 bits buy:** 1,048,576 distinct join classes per scene. With separate scenes per major operation space, each space has a fresh 1M namespace. The phase-gated tier model uses ~4 bits for tier identity, leaving 16 bits (65,536 values) for type encoding within each tier.

#### B. `PxFilterData` — 128-Bit Join Predicate Per Actor (Rigid Bodies)

Each rigid body has a `PxFilterData` set via `shape->setSimulationFilterData(PxFilterData(w0, w1, w2, w3))`: four `PxU32` = 128 bits of fully user-defined join predicate data.

Each `PxParticleSystem` also has `setSimulationFilterData(PxFilterData)` — this governs particle system ↔ rigid body interactions, not particle↔particle.

The `PxFilterData` is available in every filter shader invocation for both actors in the pair. No constraints on how you use the 128 bits — they're fully opaque to PhysX.

**For HCP at rigid-body LoD:** word token → rigid body; the `PxFilterData` words encode: namespace/PoS bits, scope ID, truth-state, relational role, and any join-relevant properties. The filter shader evaluates these for every new broadphase pair and decides whether and how they interact.

#### C. `PxSimulationFilterShader` — The Join Predicate Function (Rigid Bodies)

```cpp
typedef PxFilterFlags (*PxSimulationFilterShader)(
    PxFilterObjectAttributes attributes0, PxFilterData filterData0,   // actor 0
    PxFilterObjectAttributes attributes1, PxFilterData filterData1,   // actor 1
    PxPairFlags& pairFlags,
    const void* constantBlock, PxU32 constantBlockSize);              // global context
```

This function is called **once per new broadphase pair** and its result is cached until the pair's bounding volumes separate OR `resetFiltering()` is called. It is:
- Stateless (must not access external mutable state)
- Fast (called for every new pair; keep it tight)
- CPU-side (not GPU), but called in parallel across filter tasks

Output `PxFilterFlags`:
- `eKILL` — discard the pair permanently (until overlap status changes)
- `eSUPPRESS` — ignore until bounding volume overlap ends or filterData changes
- `eCALLBACK` — invoke the per-pair stateful callback (below)
- `eNOTIFY` — track pair, notify callback when lost

Output `PxPairFlags` (for accepted pairs): controls contact resolution, force reporting, which callbacks fire, CCD, etc.

**`attributes0`/`attributes1`**: encode actor type (`ePARTICLESYSTEM`, `eRIGID_DYNAMIC`, `eARTICULATION`, `eSOFTBODY`, etc.) + kinematic/trigger flags. The filter shader can branch on actor type — e.g., handle particle system ↔ rigid differently from rigid ↔ rigid.

#### D. `constantBlock` — Global Join Context, Swappable Between Steps

The most non-obvious mechanism in the filter system:

```cpp
// At scene creation (PxSceneDesc):
sceneDesc.filterShaderData     = &myJoinContext;  // ptr to any struct
sceneDesc.filterShaderDataSize = sizeof(myJoinContext);

// At runtime, between simulate() calls:
scene->setFilterShaderData(&newJoinContext, sizeof(newJoinContext));
// Then force re-evaluation of relevant pairs:
scene->resetFiltering(actor);   // per-actor re-filter
```

The `constantBlock` pointer is passed to **every filter shader call in the scene**. All concurrent pair evaluations in one simulate() step share the same block. It is:
- Read-only during simulation (must not be modified while simulate() is running)
- Swappable between simulate() calls via `setFilterShaderData()`
- Arbitrarily large (no documented size limit; practical limit is cache performance per call)
- Accessible as a typed struct inside the shader: `const MyContext* ctx = static_cast<const MyContext*>(constantBlock)`

**For HCP inference passes:** `constantBlock` is the current inference context — the active PBD constellation, query parameters, or predicate set that all rigid-body pairs are evaluated against simultaneously. Change the context block between steps = change what all pairs "mean." Call `resetFiltering(actor)` on actors whose relationships need re-evaluation.

This provides a global parallel predicate swap at rigid-body LoD. One simulate() pass = all pairs evaluated against the same context. Next pass = different context.

#### E. `PxSimulationFilterCallback` — Stateful Per-Pair Join Logic

For pairs that return `eCALLBACK` from the filter shader:

```cpp
class PxSimulationFilterCallback {
    PxFilterFlags pairFound(PxU32 pairID,
        PxFilterObjectAttributes attr0, PxFilterData fd0, const PxActor* a0, const PxShape* s0,
        PxFilterObjectAttributes attr1, PxFilterData fd1, const PxActor* a1, const PxShape* s1,
        PxPairFlags& pairFlags);
    void pairLost(PxU32 pairID, ...);
    bool statusChange(PxU32& pairID, PxPairFlags& pairFlags, PxFilterFlags& filterFlags);
};
```

Full actor and shape pointers — can read any actor property to make the decision. `statusChange()` is called once per simulate() step for tracked pairs, allowing dynamic re-evaluation each step.

**For HCP:** Use `eCALLBACK` for pairs where the join decision depends on properties not encodable in 128-bit `PxFilterData`. The callback has access to full actor state. The `pairLost()` notification when bounding volumes separate maps to "join dissolved" in inference.

#### F. `PxQueryFilterCallback` — Two-Stage Scene Query Filtering

For raycast/sweep/overlap queries against rigid bodies:

```cpp
class PxQueryFilterCallback {
    PxQueryHitType::Enum preFilter(
        const PxFilterData& filterData, const PxShape* shape,
        const PxRigidActor* actor, PxHitFlags& queryFlags);   // before exact test
    PxQueryHitType::Enum postFilter(
        const PxFilterData& filterData, const PxQueryHit& hit,
        const PxShape* shape, const PxRigidActor* actor);      // after exact test
};
```

Return `eNONE` (skip), `eTOUCH` (record), or `eBLOCK` (record + stop traversal) per candidate.

- `preFilter`: runs before the expensive exact intersection test — use for cheap predicate checks (type bitmask, scope check)
- `postFilter`: runs after exact test — use for predicates that need actual hit geometry (distance, normal, barycentric)
- `eANY_HIT` flag on the query: abort traversal as soon as one hit is found — "exists join" semantics at minimal cost
- `eNO_BLOCK` flag: all hits are eTOUCH (collect all, not just nearest)

**For HCP queries:** `preFilter` = apply type/scope predicate before doing GJK/SAT work. `postFilter` = apply distance/quality thresholds after. The pair `(preFilter, postFilter)` is a two-stage join filter that minimizes both broadphase work and narrowphase work.

#### G. `PxCustomSceneQuerySystemAdapter::processPruner()` — Hierarchical Subtree Filter

```cpp
virtual bool processPruner(PxU32 prunerIndex, const PxQueryThreadContext* context,
                            const PxQueryFilterData& filterData,
                            PxQueryFilterCallback* filterCall) const = 0;
// Return false to skip this entire BVH pruner (all actors in it)
```

With `PxCreateCustomSceneQuerySystem(... usesTreeOfPruners=true)`, the pruners themselves are organized in a BVH tree. `processPruner()` can skip an entire subtree of actors by returning `false`.

**For HCP:** partition rigid actors across pruners by envelope membership or scope. A query for envelope A skips pruners B, C, D entirely — the BVH subtree elimination is O(log N) instead of O(N). This is hierarchical join filtering. Each pruner = one envelope's actor set; queries that don't involve that envelope never touch it.

#### H. `PxImmediateMode::PxGenerateContacts` — One-Shot Batch Join

```cpp
PxGenerateContacts(
    const PxGeometry* const* geom0, const PxGeometry* const* geom1,
    const PxTransform* pose0, const PxTransform* pose1,
    const PxReal* contactDistance,
    PxU32 nbPairs,
    PxContactRecorder& contactRecorder,
    ...);
```

Takes two arrays of geometry + transforms (one pair per element), returns all contact points via callback. No PxScene needed, no persistent simulation state, no simulate() call.

**What this is:** a pure batch join evaluation kernel. Give it N geometry pairs, it returns which ones intersect and where. Stateless, synchronous, CPU-callable.

**For HCP:** one-shot intersection tests for rigid-body-level joins that don't need ongoing simulation — e.g., checking which phrase-pattern actors overlap with which word actors for a specific resolution pass, without adding them to the persistent scene. Result is available immediately, no wait for simulate().

---

### Soft-Match / Similarity-with-Divergence Joins

The brief specifically asks about this. The honest answer:

**PhysX has no named "soft-match" or "similarity join" primitive.** What it has is spatial proximity, which can be made to encode semantic similarity if the encoding is designed that way.

The existing Z-axis encoding (token identity = Z position) is exact-match: particles at the same Z interact, others don't. To make it a soft-match:

- **Set `particleContactOffset` > `Z_SCALE/2`**: particles at *adjacent* Z levels will also generate contact pairs. The contact force falls off with separation distance (less overlap = weaker interaction). This is soft-match with a distance-based strength falloff. At `contactOffset = 1.5 × Z_SCALE`, three Z-adjacent tokens all interact with falling strength. The "most similar" token (exact Z) gets the strongest interaction; "nearby" tokens get weaker ones.

- **The divergence IS the residual motion**: a particle that softly matches (contactOffset interaction but not exact) will not settle to zero velocity — it will have residual motion proportional to the mismatch. `onPostSolve()` velocity magnitude = divergence signal. Low velocity = high similarity. Non-zero residual = the similarity-with-divergence that Patrick's framing points at.

- **PBD material parameters as similarity gradient**: `adhesionRadiusScale` on `PxPBDMaterial` defines a distance at which adhesion (attraction) begins — beyond the contact offset. Particles within that radius are attracted with falling strength. This creates a smooth similarity gradient in the spatial neighborhood, not a hard match/no-match boundary.

**What we'd have to build from scratch:** Any similarity metric that isn't Euclidean spatial proximity. If semantic similarity needs to be expressed as a join predicate and it can't be mapped to a spatial encoding, the CUDA kernel in `onAdvance()` is where it lives — compute pairwise similarity from a pre-built embedding table, modify velocities based on score. That's custom code. PhysX contributes the CUDA execution context and the neighborhood iterator (first-pass spatial prune), but not the similarity computation itself.

**The good news:** For token-to-token matching as implemented (Z-axis encodes identity), the spatial encoding is exact-match and that's appropriate. Soft-match at the join level is more relevant for phrase-structure matching (does this word cluster "approximately match" this phrase pattern?). At that level, FEM soft bodies with Von Mises stress are the soft-match mechanism — the stress scalar IS the match quality.

---

### Parallel Candidate-Set Narrowing — What's Built In

The brief asks: does PhysX support parallel candidate-set narrowing in a single GPU pass?

**Yes, natively.** The solver itself IS parallel constraint narrowing:

1. All active particle pairs (candidates) are evaluated simultaneously in one GPU dispatch
2. The PBD constraint solver iterates: candidates that satisfy constraints converge (velocity → 0), those that don't maintain or increase velocity
3. `onPostSolve()`: read velocity per candidate — check convergence in parallel on GPU
4. Phase group reassignment: demote failed candidates to dead-zone group between steps
5. Next simulate(): only remaining candidates (live phase groups) participate

This maps directly to "join these arrays, filter by this predicate, return only the survivors, do it in parallel" — except the "predicate" is physical constraint satisfaction, not an arbitrary boolean test.

For **non-physical predicates** (e.g., "only keep candidates where token type is in set X") applied to the same candidate set: combine with phase group assignment. Assign the initial candidate set to a phase group only if they pass a pre-filter (CPU-side, before simulate()). Only pre-screened candidates enter the simulation. The GPU then does constraint narrowing on the pre-screened set.

**The combined pattern:** CPU pre-filter (phase group assignment) → GPU parallel constraint solve (simulator) → CPU post-filter (readback survivors) = full three-stage parallel candidate narrowing pipeline. The GPU stage is the expensive constraint work; the CPU stages are cheap bitmask/type checks.

---

### Join / Filter Toolkit Summary

| Mechanism | Predicate type | Layer | Cost model | HCP use |
|-----------|---------------|-------|-----------|---------|
| Phase group exact-match | Group equality | GPU, broadphase | Zero for non-matching (pruned) | Particle LoD: envelope activation, tier gating |
| PBD material cohesion/adhesion | Distance-based strength gradient | GPU, PBD solver | Included in solve | Soft join strength between same-phase particles |
| contactOffset > Z_SCALE/2 | Approximate Z-match (fuzzy identity) | GPU, broadphase+solve | Proportional to matches | Soft-match joins at character/token level |
| `PxFilterData` (128-bit) + filter shader | Arbitrary bitfield function | CPU, per new pair | Once per new pair, cached | Rigid LoD: type/namespace/scope join predicate |
| `constantBlock` (global context, swappable) | Global predicate context across all pairs | CPU, filter shader | Swap cost = `setFilterShaderData` | Per-inference-pass join context |
| `PxSimulationFilterCallback` | Arbitrary (full actor access) | CPU, per new pair | Slower; use for complex cases | Stateful join decisions at rigid LoD |
| `PxQueryFilterCallback` (pre/post) | Pre: type check; Post: geometry/distance | CPU, per query candidate | Two-stage cost amortization | Scene query filtering for rigid actors |
| `PxCustomSceneQuerySystemAdapter` | Entire BVH subtree skip | CPU, per pruner | O(log N) per query | Envelope-scoped queries on rigid actor sets |
| `PxImmediateMode::PxGenerateContacts` | Any convex geometry pair | CPU, one-shot | No scene overhead | Offline/one-shot batch join tests |
| FEM Von Mises stress | Match quality scalar | GPU, FEM solver | FEM overhead | Soft-match quality at phrase/entity LoD |
| CUDA kernel in `onAdvance()` | Arbitrary (full particle data access) | GPU, per step | Custom code, no built-in cost | Semantic predicates not expressible spatially |

---

---

## Addendum 2: Non-Euclidean Re-Scan

*Patrick's framing: headers describe typical use, not mathematical capability. We are using semantic axes as spatial coordinates and that's a baseline assumption, not a future branch. What changes when you look at each mechanism as pure math operating on user-defined coordinate spaces?*

---

### The Foundational Reframe

The existing Z-axis-encodes-token-identity is already non-Euclidean spatial encoding. The re-scan is about extending this pattern systematically across all three axes and across the rigid body layer. Everything below follows from that.

The PBD spatial hash computes, mathematically: **for each pair of entries in the system, do they share the same cell or adjacent cells in N-dimensional discrete coordinate space?** The documented framing calls those cells "positions in 3D physical space." The mathematical operation doesn't care. Cell membership is determined by `floor(coordinate / contactDistance)` on each axis. Two particles interact iff their cell indices differ by ≤ 1 on each axis. That's the operation. What the coordinates mean is our choice.

---

### Mechanism 1: PBD Spatial Hash — Per-Axis Selectivity Control

**What it actually computes:**
Grid cell size = `particleContactDistance` (confirmed in `PxParticleGpu.h:116-123`) — cubic cells, same size on all axes. `gridSizeX/Y/Z` sets the number of cells on each axis, which sets total domain extent = `gridSize × contactDistance`. Selectivity per axis = `encodingScale / contactDistance` ratio. Higher ratio = finer discrimination. Lower ratio = more permissive.

**The key mechanism:** Since `contactDistance` is a single scalar, per-axis selectivity is controlled by choosing different encoding scales on each axis. This is already done for Z (Z_SCALE=10 relative to contactDistance=3 → exact-match discrimination between adjacent ASCII values). The same pattern generalizes:

| Axis | Encoding | Scale vs. contactDistance | Join behavior |
|------|----------|--------------------------|---------------|
| Z | Token identity | High (e.g., 10×) | Exact match — different tokens never share a cell |
| Y | Semantic type class | High (e.g., 50×) | Type discrimination — nouns don't interact with verbs |
| X | Structural position | Low (e.g., 0.5×) | Loose — particles at positions 0–5 all interact freely |

Three independent semantic dimensions in one simulate() call. The join predicate is: "same identity AND same type AND approximately same structural position." Tune each axis's scale relative to contactDistance to set how strict each dimension's match is.

**Soft-match via scale**: set `encodingScale ≈ contactDistance` on an axis → particles at adjacent semantic values interact, with strength falling off as distance increases. The broadphase generates pairs; contact force = similarity gradient. Residual velocity after solve = divergence signal. **This is the similarity-with-divergence working space operating at the physics level.** No custom code — just encoding design.

**Domain capacity constraint (non-obvious):** For word-level encoding (1.4M vocabulary entries), with Z_SCALE=10 and contactDistance=3, the Z domain requires `gridSizeZ ≥ ⌈1.4M × 10 / 3⌉ ≈ 4.7M cells` — impractical in one system. This is why the switching yard architecture (multiple scenes, each covering a semantic partition of the vocabulary) is architecturally necessary, not just an optimization. Each scene handles one partition of the semantic space. This is confirmed, not new; but now the reason is explicit.

**Verdict: Use raw SDK + intentional per-axis encoding design. No new code — this is parameter design.** The simulation domain configuration IS the join predicate design.

---

### Mechanism 2: `setGridSizeX/Y/Z` — Independent Semantic Resolution Per Axis

**What it actually computes:** Sets the number of cells on each axis, which sets the total domain extent in world-units for that axis. Doesn't change cell size (that's contactDistance, global). Does determine how many distinct semantic values can coexist in the simulation.

**Non-Euclidean use:** Different axes need different capacities for different semantic dimensions:
- Z (token identity): high capacity needed — many distinct tokens. Large gridSizeZ.
- Y (type class): low capacity — ~16–32 distinct type classes. Small gridSizeY.
- X (structural position): medium capacity — depends on longest structure being matched.

Setting `gridSizeY = 32` and Y_SCALE = 50 means the type class dimension has 32 bins of width 50 units each, covering 32 distinct type classes with exact discrimination. Setting `gridSizeX = 200` and X_SCALE = 1 means structural position has 200 positions with coarse (non-discriminating) matching.

**Verdict: This IS the semantic dimension capacity planner.** Match gridSize to number of distinct values needed per semantic axis. Already in use for Z; needs design for X and Y.

---

### Mechanism 3: Broadphase Algorithm Selection — Distribution Sensitivity

**What the algorithms actually compute:**

| Algorithm | What it does | Distribution assumption | Best semantic fit |
|-----------|-------------|------------------------|-------------------|
| eSAP (Sweep and Prune) | Sort-based interval overlap detection | Benefits from temporal coherence (small incremental changes) | Stable semantic constellations where coordinates rarely change. Good for long-running inference sessions where the semantic layout is stable. |
| eMBP (Multi-Box Pruning) | User-defined regions (AABB boxes) | No assumption; user defines the clustering | **Semantic namespaces as explicit regions.** Define regions = semantic neighborhoods. Objects outside all regions are invisible to the broadphase entirely. |
| eABP/ePABP (Adaptive) | Automatically adapts region boundaries | Handles uneven distributions well | Semantic distributions where clustering isn't known ahead of time; adaptive to vocabulary loading patterns. |
| eGPU (GPU sweep + ABP-style) | GPU-accelerated; handles high-object-count spikes | GPU-local; no coherence requirement | **Particle LoD.** Already selected. The right choice for high-volume particle operations where distribution is controlled by our encoding design. |

**Non-obvious win for eMBP:** `PxScene::addBroadPhaseRegion(PxBroadPhaseRegion{bounds, userData})` adds a semantic scope at runtime. Objects whose position (semantic coordinate) doesn't overlap any region are **not in the broadphase at all** — cheaper than filter shader rejection (which still generates pairs). Removing a semantic scope from the query = calling `removeBroadPhaseRegion()`. Objects in the removed scope are immediately invisible.

For HCP at rigid body LoD: eMBP regions = active envelope neighborhoods. The query "what's in the current envelope constellation" = "which regions are currently active." Objects outside active regions don't participate in any joins. This is envelope scoping at broadphase level, cheaper than any filter layer.

**Verdict for rigid body LoD: eMBP with semantic-namespace regions.** For particle LoD: eGPU (already correct).

---

### Mechanism 4: `PxCustomSceneQuerySystem` — Semantic Envelope Routing (Not "If Needed" — Now)

**What it actually computes:** A multi-pruner BVH system where:
1. `getPrunerIndex(actor, shape)` routes each actor to a specific pruner when it's added to the scene
2. Each pruner is an independent BVH over its assigned actors
3. `processPruner(prunerIndex, filterData, filterCall)` controls per-query which pruners are visited
4. With `usesTreeOfPruners=true`: the pruners themselves live in a BVH — O(log N) pruner selection

**The BVH operates on actor positions expressed as AABBs.** The BVH doesn't know or care that the coordinates are semantic. It builds an efficient tree over whatever coordinate space the actors occupy. `overlap(box)` in semantic space = "find all actors in this semantic coordinate range." This is not a workaround — it's exactly what the math computes.

**Semantic routing design:**
- Each envelope = one pruner (`addPruner()`)
- Actor placement: `getPrunerIndex()` returns the actor's envelope's pruner index based on the actor's semantic type/scope properties
- Per-query envelope filtering: `processPruner()` returns false for envelopes not in the current inference context = skip entire BVH tree for that envelope. O(log N) cost per query regardless of envelope population.

**Non-obvious capability:** With `usesTreeOfPruners=true`, the pruner BVH is over the pruner AABBs in semantic space. A query for semantic range [A, B] first finds which pruner AABBs overlap [A, B] — O(log N) pruner selection — then within matching pruners finds which actor AABBs overlap — O(log M) per pruner. Full query cost: O(log N × log M) rather than O(N × M). This is hierarchical semantic range query.

**Verdict: This is the semantic envelope routing layer for rigid body LoD. Implement now, not conditionally.**

---

### Mechanism 5: PxContactModifyCallback — Per-Active-Relation Semantic Gradient (No CUDA Required)

**What it actually computes:** For every active contact pair (two rigid bodies currently overlapping in coordinate space), per simulate() step:
```cpp
PxContactSet contacts = pair.contacts;
contacts.setTargetVelocity(i, PxVec3(vx, vy, vz));  // desired relative velocity at contact point
contacts.setSeparation(i, s);                          // adjust separation distance
contacts.setNormal(i, PxVec3(nx, ny, nz));             // redirect contact force direction
contacts.setMaxImpulse(i, impulse);                    // cap force magnitude
```

`setTargetVelocity` sets the desired rate of relative motion at the contact point. In semantic coordinate space: "I want these two entities to approach each other on axis Y at rate v_y while staying fixed on axis Z." The constraint solver will apply force to achieve this target velocity. The magnitude of force is limited by `setMaxImpulse`.

**For HCP:** every active contact pair IS an active semantic join (two entities currently in each other's semantic neighborhood). `onContactModify` is "for each active relation, run this semantic operation" — CPU-side, per step, per relation. No CUDA required. The target velocity IS the semantic gradient for that relation.

**Specific semantic operations expressible through contact modification:**

| Operation | Contact modify call | Semantic meaning |
|-----------|--------------------|-----------------| 
| Attract on relation axis | `setTargetVelocity({0, -v, 0})` | "Pull these entities toward same Y coordinate (same type/role)" |
| Repel on identity axis | `setTargetVelocity({0, 0, v})` | "Push apart on Z — these entities should differentiate" |
| Hold at current separation | `setTargetVelocity({0, 0, 0})` | "Maintain current semantic distance — stable relation" |
| Cap relation strength | `setMaxImpulse(w)` | "This relation has limited force — can be overridden by stronger constraints" |
| Redirect force | `setNormal(n)` | "The semantic gradient for this pair runs in direction n" |

Contact modification is CPU-side and called for all active pairs each step. For rigid body LoD (word/phrase scale, where the number of active pairs is bounded), this is sufficient. For particle LoD, the `onAdvance()` CUDA callback is needed.

**Verdict: `PxContactModifyCallback` is "for each active relation, run this semantic operation" at rigid body LoD. Use it. No custom CUDA needed for this layer.**

---

### Mechanism 6: `eCUSTOM` Solver + `onSolve` — Iterative Semantic Constraint Participation

**What it actually computes:** `PxCustomParticleSystemSolverCallback::onSolve(gpu, dt, stream)` is called once per solver iteration (not just once per step). With N solver iterations configured, `onSolve` is called N times. Each call injects forces that are then resolved by the next iteration alongside the PBD constraints.

**The difference from `onAdvance()`:** Forces injected in `onAdvance()` are applied once, before the solve. The PBD solve then runs without further custom input. Forces injected in `onSolve` are co-iterated with the PBD solver — if the solver adjusts particle positions, the next `onSolve` call sees updated positions and can respond. This is iterative semantic force co-evolution.

For semantic constraint satisfaction: if the semantic operation has dependencies that should respond to intermediate constraint states (e.g., "resolve closest match first, then resolve second closest in the context of the first resolution"), `onSolve` participates in the same iterative loop. `onAdvance()` is a one-shot push; `onSolve` is an iterated participant.

**Verdict: Use `onSolve` (eCUSTOM solver) for semantic operations that need to co-evolve with the PBD constraint loop. `onAdvance()` for one-shot force injection. Both are CUDA; `onSolve` is the iterative variant.**

---

### Mechanism 7: `PxD6Joint` — Multi-Dimensional Selective Semantic Constraint

**What it actually computes:** For each of 6 DOFs (3 linear: X, Y, Z; 3 angular: twist, swing1, swing2):
- `eLOCKED`: equality constraint — force this DOF to zero relative motion
- `eFREE`: no constraint — full freedom on this DOF
- `eLIMITED`: range constraint — allow this DOF within bounds

In semantic coordinate space, these are:
- **LOCKED on Z**: "these entities must share the same Z coordinate (identity)" = exact identity match constraint
- **FREE on X**: "they can be at any relative X position" = structural position is unconstrained for this pair
- **LIMITED on Y**: "their Y coordinates (type class) must be within ±k of each other" = fuzzy type match
- **Drive on Y**: "pull these entities to the same Y coordinate over time" = type-convergence force

The drive parameters (stiffness, damping, targetPosition/Velocity) turn the joint into a semantic spring: `stiffness` = how hard to enforce the constraint, `targetPosition` = desired semantic coordinate value, `damping` = resistance to oscillation around the target.

**For NSM prime constraints:** The action prime constraint "DO(agent, patient) must have agent and patient as arguments" becomes:
- Lock Z of agent-particle and patient-particle to their respective predicate values
- Free X (structural position within clause is flexible)  
- Limited Y (their type classes must be compatible: agent must be [+animate], patient must be [+concrete])

This is a multi-dimensional semantic constraint naturally expressed as a D6 joint configuration. No custom code.

**Verdict: `PxD6Joint` is the semantic multi-axis constraint primitive for rigid body LoD. Per-axis lock/free/limit is per-semantic-dimension selectivity. Use it for relational constraints between typed entities.**

---

### What Changes from the Previous Analysis

| Previous conclusion | Revised conclusion |
|--------------------|--------------------|
| "PhysX has no similarity join primitive" | The spatial hash IS a similarity join when encoding is designed for it. Selectivity = `encodingScale / contactDistance` ratio per axis. Already deployed on Z. Extend to X and Y. |
| "PxCustomSceneQuerySystem: flag for possible future use if non-Euclidean needed" | Non-Euclidean is baseline. Implement now as semantic envelope routing layer. One pruner per envelope; `processPruner()` for per-query scope filter. |
| "eMBP: alternative broadphase, similar to others" | eMBP is the semantic scoping broadphase for rigid body LoD. Regions = semantic namespaces. Objects outside active regions are invisible (cheaper than filter rejection). Add/remove regions at runtime to scope inference passes. |
| "setGridSizeX/Y/Z: tune grid for GPU efficiency" | These are the semantic dimension capacity parameters. Each axis needs a gridSize matched to the number of distinct semantic values it encodes. Design choice, not tuning. |
| "PxContactModifyCallback: documented for physics, noted" | This is "for each active semantic join, run this gradient operation" at rigid body LoD. `setTargetVelocity` = desired rate of semantic change. No CUDA required for this layer. |
| "onAdvance() for custom kernels" | Two variants: `onAdvance()` = one-shot force injection once per step. `onSolve()` (eCUSTOM) = iterative participation in constraint solve. Use `onSolve` when semantic forces need to co-evolve with PBD constraints. |
| "Semantic similarity join not spatial = build from scratch" | Remap: encode semantic similarity as spatial proximity. Soft-match join = `contactOffset > Z_SCALE/2` on the identity axis. Available immediately, no new code. Custom CUDA needed only for similarity metrics that cannot be embedded spatially. |

---

---

## Addendum 3 — Source-Level Scan: What the Inline Code Reveals

**Date:** 2026-05-11  
**Trigger:** Patrick's note: "PhysX gems describe what they are used for in headers. In some cases it may be worth looking at the actual function code for comparable structures."  
**Method:** The SDK ships as binary-only. Two sources of "actual function code" were accessible:  
1. Inline implementations in the public headers (`PX_CUDA_CALLABLE`, `PX_FORCE_INLINE` functions — compiled into both host and device code)  
2. `HCPParticlePipeline.cpp` — the HCP gem's own PhysX integration, which reveals what's currently wired and what isn't

The headers are more than documentation: the inline functions ARE the code that executes in CUDA kernels. Patrick's point holds — the docstring says "physics," the implementation says "structured comparison."

---

### Finding 1: `PxNeighborhoodIterator` — the actual join traversal loop

From `PxParticleGpu.h` (PX_CUDA_CALLABLE inline, runs on GPU):

```cpp
PX_CUDA_CALLABLE PxU32 getNextIndex()
{
    PxU32 result = *mCollisionIndex;
    mCollisionIndex += mMaxParticles;
    return result;
}
```

The `mCollisionIndex` array is **column-major**: for particle `i`, neighbors are at positions `[i], [i + maxParticles], [i + 2*maxParticles], ...`. Each call to `getNextIndex()` reads the current neighbor's sorted particle index and steps the pointer by `mMaxParticles` to the next neighbor slot.

**What this means structurally:**

- The neighbor list is a 2D array `[neighborSlot][particleId]` stored row-major, accessed column-wise per particle
- For a CUDA thread processing particle `i`, iterations through neighbors are strided — the access pattern is deliberately designed for **one thread per particle** reading across rows
- Neighbor count for particle `i` is `mParticleSelfCollisionCount[i]`  
- Neighbor indices returned are in **sorted space** (hash-sorted particle IDs); convert to original with `mSortedToUnsortedMapping[neighborId]`

**For HCP:** The `onAdvance()` callback kernel pattern is:
```cuda
__global__ void hcpJoinKernel(PxGpuParticleSystem* sys) {
    PxU32 sortedId = blockIdx.x * blockDim.x + threadIdx.x;
    if (sortedId >= sys->mCommonData.mNumParticles) return;
    
    PxU32 origId = sys->mSortedToUnsortedMapping[sortedId];
    PxU32 neighborCount = sys->mParticleSelfCollisionCount[sortedId];
    
    PxNeighborhoodIterator it = sys->getIterator(sortedId);
    for (PxU32 n = 0; n < neighborCount; ++n) {
        PxU32 neighborSortedId = it.getNextIndex();
        PxU32 neighborOrigId = sys->mSortedToUnsortedMapping[neighborSortedId];
        // → this is the join: (origId, neighborOrigId) is one active relation
        // Read: sys->mSortedVelocities[sortedId].w  (free channel)
        //        sys->mSortedVelocities[neighborSortedId].w
        // Write: accumulate forces / signals
    }
}
```

---

### Finding 2: Phase group join predicate — confirmed actual bitmask code

From `PxParticleGpu.h` (compiled into both host and device, used by the PhysX broadphase kernel):

```cpp
PX_CUDA_CALLABLE inline PxU32 PxGetGroup(PxU32 phase)        { return phase & 0x000FFFFF; }
PX_CUDA_CALLABLE inline bool  PxGetSelfCollide(PxU32 phase)  { return (phase & (1 << 20)) != 0; }
PX_CUDA_CALLABLE inline bool  PxGetFluid(PxU32 phase)        { return (phase & (1 << 22)) != 0; }
PX_CUDA_CALLABLE inline bool  PxGetSelfCollideFilter(PxU32 phase) { return (phase & (1 << 21)) != 0; }
```

Full interaction predicate (inferred from the inline code + bit layout in `PxParticleSystemFlag.h`):

```
interact(A, B) = (PxGetGroup(A.phase) == PxGetGroup(B.phase))
                AND PxGetSelfCollide(A.phase)
                AND PxGetSelfCollide(B.phase)
```

This is a 32-bit AND + equality comparison. Cost: ~2 GPU instructions per candidate pair in the broadphase. The spatial hash prunes candidate pairs to the same cell (or adjacent cells within `contactDistance`). The phase check runs AFTER spatial proximity is confirmed — so the join predicate cost is paid only for geometrically-proximate particle pairs.

**What this means architecturally:**

- The join is a 2-level filter: spatial proximity (GPU hash) gates which pairs are even considered; phase equality decides which of those pairs actually interact
- Setting `eParticlePhaseSelfCollide = 0` makes a particle **invisible as a join target** for ALL other particles, regardless of group — a particle that emits no interaction. Useful for "observer" particles that read the semantic space without injecting forces
- `eParticlePhaseSelfCollideFilter` (bit 21): ignores pairs whose positions are within rest-pose radius. For HCP: can be used to suppress self-interaction when rest positions are set to a particle's own semantic coordinate (prevents a particle from being its own join partner)
- `eParticlePhaseFluid` (bit 22): activates fluid density constraints. In semantic encoding: fluid constraint = pressure term proportional to local density. Dense neighborhoods → pressure → particles redistribute. This is a **density-based re-weighting** of semantic neighborhoods — high-density clusters get "pressure" to spread; sparse regions have no competing force

---

### Finding 3: `PxsParticleMaterialData` — what's actually GPU-accessible in CUDA

The full `PxPBDMaterial` API has 9+ parameters (friction, damping, adhesion, viscosity, cohesion, surfaceTension, vorticityConfinement, lift, drag). But the GPU-side struct (accessible in CUDA kernels via `mParticleMaterials[materialIndex]`) is:

```cpp
struct PxsParticleMaterialData  // 5 floats = 20 bytes
{
    PxReal friction;              // inter-particle sliding resistance
    PxReal damping;               // velocity decay per step
    PxReal adhesion;              // inter-particle attraction (negative = repulsion)
    PxReal gravityScale;          // multiplier on scene gravity for this material
    PxReal adhesionRadiusScale;   // radius within which adhesion acts
};
```

**Corrects earlier analysis:** cohesion, viscosity, surfaceTension, vorticityConfinement are **NOT** accessible in CUDA kernels. These parameters affect the PBD position-correction step but are not in the GPU-readable material struct.

**Implication for HCP:**

| Parameter | HCP semantic mapping | Accessible in CUDA? |
|---|---|---|
| `friction` | Resistance to semantic drift (semantic inertia between joined particles) | ✓ Yes |
| `damping` | Rate of convergence to equilibrium state | ✓ Yes |
| `adhesion` | Base attraction strength between co-phase particles | ✓ Yes |
| `gravityScale` | Class-specific "weight" toward a semantic attractor | ✓ Yes |
| `adhesionRadiusScale` | Soft-match radius relative to contact distance | ✓ Yes |
| `cohesion` | Fluid self-cohesion (same-group clustering pressure) | ✗ Only in PBD position correction |
| `viscosity` | Resistance to velocity change (semantic drag) | ✗ Only in PBD position correction |

For custom CUDA kernels launched from `onAdvance()`: only the 5 `PxsParticleMaterialData` fields are available. If you need cohesion-like behavior in your custom kernel, you must compute it yourself from neighborhood density and inject it as a velocity delta, rather than reading it from material data.

---

### Finding 4: `onSolve` iterative callbacks — correction

**Previous analysis said:** "onSolve() (eCUSTOM) = iterative participation in constraint solve. Use onSolve when semantic forces need to co-evolve with PBD constraints."

**Correction from source:** `PxCustomParticleSystemSolverCallback::onSolve` is registered only on `PxCustomParticleSystem`, which is created via `PxPhysics::createCustomParticleSystem()`. The header explicitly says:

> **"Feature under development, only for internal usage."**

`PxCustomParticleSystem` is not part of the stable public API in 5.1.1. The `eCUSTOM` solver type is listed in `PxParticleSolverType.h` ("Can be used e.g. for molecular dynamics simulations") but the class that registers the callback is internal-only.

**Consequence for HCP:** For `PxPBDParticleSystem` (what HCP uses), the callback path is `PxParticleSystemCallback` with three points:

| Callback | Timing | Buffer state | Use for HCP |
|---|---|---|---|
| `onBegin` | After dirty upload to GPU, BEFORE spatial sort | Unsorted buffers only | Modify positions/velocities/phases before the hash runs. Re-position particles to change who becomes neighbors THIS step. |
| `onAdvance` | During simulation step | Sorted buffers + neighborhood | The main CUDA callback. Inject forces, read neighbor list, accumulate join results. ONE call per step, not per iteration. |
| `onPostSolve` | After integration completes | Sorted buffers, integration done | Read final state. Flag state transitions. No force injection (step is done). |

The iterative per-constraint-iteration injection (co-evolving with PBD position correction) is not available for PBD without using the internal eCUSTOM system. For HCP: `onAdvance` forces are injected once as velocity deltas, then PBD runs its own constraint iterations. The forces don't co-evolve with the iterations.

**Workaround for iterative behavior:** Run multiple small timesteps (`simulate(dt/N)` N times per logical step) instead of one large step. Forces re-inject each sub-step. More expensive but gives N-fold finer interaction with constraint resolution.

---

### Finding 5: `PxGpuMirroredPointer` — host readback without sync

`PxParticleSystemCallback` receives:
```cpp
const PxGpuMirroredPointer<PxGpuParticleSystem>& gpuParticleSystem
```

This carries both a device pointer (`mDevicePtr`) and a host pointer (`mHostPtr`). The host pointer can be read on the CPU in `onPostSolve` without an explicit CUDA sync — the data is already mirrored to host memory at that callback point.

**For HCP:** `onPostSolve` is the natural readback point for:
- Bond detection: read `mUnsortedPositions_InvMass` on host to find final particle clusters
- Convergence detection: check velocity magnitudes without a blocking `cudaMemcpy`  
- State transition triggers: check per-particle flags (written to velocity.w by the CUDA kernel) from host

This removes the "host readback requires blocking cudaMemcpy" cost for per-step result polling.

---

### Finding 6: `PxParticleVolume` — partition-within-buffer semantic bookkeeping

```cpp
struct PxParticleVolume {
    PxBounds3 bound;              // current AABB of the particle subset
    PxU32 particleIndicesOffset;  // index of first particle in this volume
    PxU32 numParticles;           // particle count
};
```

Volumes are contiguous slices within a single `PxParticleBuffer`. PhysX tracks and updates the bounds of each volume automatically every step. This is a **free per-partition bookkeeping** mechanism.

**For HCP:** 
- One `PxParticleBuffer` holds all particles for a phase pass
- Multiple `PxParticleVolume` slices mark semantic sub-groups within that buffer (e.g., verb particles, noun particles, closed-class particles)
- After simulation, `volume.bound` gives the current spatial extent of each semantic group without scanning all particles — the bounds update is free (computed by the GPU)
- Useful for adaptive re-encoding decisions: if a semantic group's bound has collapsed (low radius), the group has converged; if it has expanded, the group is diffusing

---

### Finding 7: `PxParticleRigidBuffer` — semantic cluster as shape-matching rigid

`PxParticleRigidBuffer` (a `PxParticleBuffer` subclass) defines particles that form "rigids" via shape-matching. Each rigid has:
- `rigidOffsets` — start index per rigid in the particle list
- `rigidCoefficients` — stiffness (0 = fully flexible, 1 = rigid)
- `rigidTranslations` / `rigidRotations` — world-space pose of each rigid's center
- `rigidLocalPositions` — each particle's offset from the rigid center
- `rigidLocalNormals` — local normal + SDF value in w

The GPU kernel maintains the rigid's shape by driving each particle toward `translation + rotate(localPosition)`. Stiffness = how aggressively it corrects.

**For HCP semantic use (non-obvious):**

Shape-matching is not "physical rigidity" — it's **relational position maintenance**. A rigid cluster of semantic particles maintains their relative arrangement (relative to the cluster's center of mass) while the cluster as a whole can translate/rotate freely in semantic space.

Map: a **lexical cluster** (e.g., all inflected forms of "run") as a particle rigid. The cluster maintains internal cohesion (run-runs-ran-running stay in their relative positions) while the whole cluster's position in semantic space shifts in response to context. Stiffness coefficient = morphological cohesion strength. `rigidTranslations` = cluster centroid, directly readable from GPU without scanning all particles.

This is cheaper than explicit spring constraints for cluster maintenance — shape-matching is a single O(N_rigid) pass vs spring solving which iterates.

---

### Finding 8: Spring partitioning — general conflict-free parallel constraint solver

`PxParticleClothPreProcessor::partitionSprings` takes an arbitrary graph of constraints and partitions them into independent sets (no two constraints in the same set share a particle). Within a partition, all constraints can be solved in parallel without data races.

The output structure shows the algorithm's intent clearly:
```cpp
struct PxPartitionedParticleCloth {
    PxU32* accumulatedSpringsPerPartitions;  // count per partition
    PxU32* remapOutput;       // for each spring, index of next copy in next partition
    PxParticleSpring* orderedSprings;         // springs reordered by partition
    PxU32 nbPartitions;
    // ...
};
```

This is a **graph coloring** result: each "color" = one partition; edges of the same color don't share vertices.

**For HCP:** This preprocessor is not limited to cloth. Any semantic constraint graph (e.g., "these tokens must resolve before those tokens" dependency ordering, or "these semantic pairs must be co-evaluated") can be partitioned this way. Run the preprocessor on the semantic graph once (or when the graph topology changes). Then in each solve step, execute partition by partition — within a partition, all constraint evaluations are parallel; between partitions, they're sequential.

The partitioner itself runs on CPU as a preprocessing step. Cost: one-time or on-topology-change only.

---

### Finding 9: Current `HCPParticlePipeline.cpp` state — what's wired and what isn't

The current implementation (`Gem/Source/HCPParticlePipeline.cpp`):

```cpp
// All particles placed at (i, 0, 0) — 1D sequence
hostPos[i] = PxVec4(static_cast<float>(i), 0.0f, 0.0f, 1.0f);
// velocity.w = 0 (free channel, never written by SDK)
hostVel[i] = PxVec4(0.0f, 0.0f, 0.0f, 0.0f);
// Single shared phase — all particles in the same group
hostPhase[i] = phase;  // same for all i
```

What this actually runs:
- The spatial hash IS running, but the result is trivial — particles at positions (0,0,0), (1,0,0), (2,0,0) ... with contactOffset=1.5 produce exactly the expected adjacent-pair results. No semantic structure is being computed.
- Single phase group = all particles in the same join set = every particle within contactDistance is a potential join partner. Phase groups aren't being used to express semantic class isolation.
- `velocity.w` is confirmed free (SDK writes the velocity buffer as `(vx, vy, vz, 0.0f)` — confirmed from `PxParticleBuffer::getVelocities()` doc: "velocities packed as PxVec4(vel.x, vel.y, vel.z, 0.0f)")
- `Reassemble()` is a placeholder — returns empty vector

The spatial hash, phase groups, multi-axis encoding, material differentiation, volume bookkeeping — none of these are wired in the current code. The infrastructure is correct (proper scene creation, CUDA context, buffer management), but the semantic encoding layer is not yet built.

**What needs to be added to the pipeline (in order):**
1. Multi-axis coordinate assignment (x=semantic axis 1, y=axis 2, z=identity/similarity)
2. Phase group assignment by semantic class (different groups for verbs/nouns/closed-class/etc.)
3. Per-class material assignment (different cohesion/damping per semantic register)
4. `onAdvance()` callback registration with custom CUDA kernel for force injection
5. `velocity.w` as a free per-particle float for continuous parameters (confidence, polarity)
6. `PxParticleVolume` slices per semantic group for free bound tracking

---

### Summary Table: What Changes from Addendum 2 Analysis

| Addendum 2 conclusion | Addendum 3 correction |
|---|---|
| "`onSolve()` (eCUSTOM) for iterative force co-evolution" | eCUSTOM is internal-only in 5.1.1. For PBD, only `onAdvance()` (one-shot per step) is available. Iterative behavior = multiple sub-step calls. |
| "Material parameters are per-semantic-class force knobs in CUDA" | Only 5 params (friction, damping, adhesion, gravityScale, adhesionRadiusScale) are in `PxsParticleMaterialData`. Cohesion, viscosity, surfaceTension are NOT in the CUDA-accessible struct — they run in PBD position correction only. |
| "Neighbor list: standard dense array" | Column-major stride: `collisionIndex[particleId + slot * maxParticles]`. One thread per particle; iteration is strided. Important for CUDA kernel layout. |
| "Phase group = join predicate" | Confirmed at the bit level: `PxGetGroup(phase) = phase & 0x000FFFFF`. The full predicate: group equality AND both particles have eSelfCollide set. Zero instruction overhead beyond the spatial hash. |
| "onBegin/onAdvance/onPostSolve timing: after dirty upload / during step / after step" | Confirmed AND refined: `onBegin` is called BEFORE the spatial sort/hash pass — can reposition particles to change neighborhood relationships before the hash runs. Critical for pre-step semantic reconfiguration. |
| "Readback requires blocking cudaMemcpy" | `PxGpuMirroredPointer` provides host-accessible mirror in `onPostSolve` — no explicit sync needed for per-step state polling. |
| "Current pipeline uses spatial hash for bond detection" | Current pipeline places all particles at (i,0,0) with single phase. Hash runs but produces trivial adjacent-pair results. No semantic encoding is currently wired. |

---

---

---

## Addendum 4 — Prime/Molecule Framing + Articulation Tree

**Date:** 2026-05-11  
**Trigger:** Patrick's architectural key (via team-lead): particle ↔ prime; rigid body ↔ molecule; force between them = explication relationship. Molecule = emergent equilibrium of prime force composition. Explications = nested rigid bodies.

This addendum does not contradict earlier sections — it reframes several verdicts and adds the articulation tree as the missing structural primitive for nested explications.

---

### The Framing Key

| PhysX construct | HCP concept |
|---|---|
| **Particle (PxPBDParticleSystem)** | **NSM prime** — the ~65 irreducible operators (substantives, action class, mental predicates, logical gates, temporal anchors, etc.) |
| **Rigid body (PxRigidDynamic/Static)** | **Molecule** — an explicated concept built from primes, or a surface-form token under see-it-mint-it |
| **Force from particle to rigid body** | **Explication relationship** — a prime contributing to/shaping/modifying a molecule |
| **PBD convergence to equilibrium** | **Explication settling** — primes compose their forces; the rigid body that emerges at equilibrium IS the molecule's definition |
| **Articulation link** | **Sub-molecule** — a node in the explication tree |
| **Articulation tree (PxArticulationReducedCoordinate)** | **Nested explication** — the full tree of a molecule's decomposition, primes at the leaves |
| **PxScene** | **Truth-scope container** — separate scene per outer container (PBD, fiction, hypothetical) |
| **PxAggregate** | **Envelope cluster** — related molecules sharing one broadphase entry |

---

### Why Earlier Verdicts Change

#### "Minimal particle-level filter machinery is a gap"

Not a gap. Primes are **operators**, not relational entities. A prime doesn't need to know which molecules it relates to — it applies its force to whatever it touches (same-group particles, or nearby rigid bodies it's embedded in). Group equality at the particle level is enough to say "this is a prime of class X" (e.g., eX = substantive group, action-class group, etc.). The 20-bit group ID is more than sufficient for 65 prime classes.

The relational richness (128-bit predicate fields, multi-layer filter shader, `PxQueryFilterCallback`) belongs at the **rigid body LoD** because molecules ARE relational entities — they have PBD-encoded semantic positions, they need to be queried by class, they need to be filtered by namespace. The machinery is calibrated to where it's needed.

#### "Particle → rigid body promotion"

Previously described as: "a particle transitions to a rigid body when it earns one." 

Corrected framing: this is **prime force composition settling into a molecule**. You load the primes that define a molecule (particles), let them run under PBD (mutual forces, constraints), and the equilibrium state IS the molecule. The rigid body is not "promoted to" — it emerges. You then capture the equilibrium state as the rigid body's initial pose and start treating it as a single actor.

This means "rigid body promotion" is not a discrete event with a trigger — it's the outcome of a convergence pass. The convergence detection mechanisms (Von Mises stress threshold, velocity magnitude falling below sleep threshold) are the natural exit criteria.

#### "State transition triggering" (Section 8 of original digest)

Previously framed as: particle X touches particle Y → callback → state machine transition.

Corrected framing: an **action prime fires** = a force perturbation applied to a molecule. `PxRigidBody::addForce()` (already wrapped in O3DE) applied to the molecule's rigid body shifts its equilibrium. The solver re-settles the molecule to state S₂. The "state transition" is the difference between the original equilibrium and the new one — not a callback event.

This means the callback pattern for action prime firing is:
1. Prime particle enters proximity of molecule (detected in `onPostSolve` or neighborhood iterator)  
2. Apply `PxRigidBody::addForce(primeForce, eACCELERATION)` to the molecule rigid body
3. Scene simulates — molecule re-settles to new equilibrium
4. Read new equilibrium → this is state S₂

For molecules modeled as FEM soft bodies: `eTET_STRESSCOEFF` = how far from equilibrium. Low stress = prime forces have settled the molecule into a clean definition. High stress = primes still in tension = poorly explicated / ambiguous molecule.

---

### Nested Explications → `PxArticulationReducedCoordinate`

Patrick: "The explications inherently form nested rigid bodies."

A molecule's explication = a tree:
- Root = the molecule itself  
- Internal nodes = sub-molecules (already-settled rigid bodies pulled in whole)
- Leaves = prime particles

PhysX's `PxArticulationReducedCoordinate` is a **tree of rigid bodies connected by joints**, solved with reduced-coordinate kinematics. Each link in the tree is a `PxArticulationLink` (inherits `PxRigidBody`), connected to its parent by a `PxArticulationJointReducedCoordinate`.

**Why reduced coordinate specifically:**
- The solver keeps track of joint DOFs explicitly (not just forces on independent bodies)
- Force propagation respects the tree hierarchy — a force on the root propagates correctly to all links; a force on a leaf propagates up with inertia scaling
- "Reduced coordinate" = the system's state is the joint angles/positions, not individual link poses independently. This is mathematically cleaner for tree structures than a flat set of constraints.

**Joint axes available** (from `PxArticulationAxis` enum):
- `eTWIST (0)` — rotation about X
- `eSWING1 (1)` — rotation about Y  
- `eSWING2 (2)` — rotation about Z
- `eX (3)` — linear along X
- `eY (4)` — linear along Y
- `eZ (5)` — linear along Z

Per-axis motion: `eLOCKED / eLIMITED / eFREE`.  
Joint types: `eFIX / ePRISMATIC / eREVOLUTE / eSPHERICAL / eREVOLUTE_UNWRAPPED`.

**Per-joint drives** (`PxArticulationDrive`):
```cpp
struct PxArticulationDrive {
    PxReal stiffness;   // spring constant driving toward target position
    PxReal damping;     // damping
    PxReal maxForce;    // force cap
    PxArticulationDriveType::Enum driveType;  // eFORCE | eACCELERATION | eTARGET | eVELOCITY
};
```

`setDriveTarget(axis, targetPosition)` — drives this joint toward a target position.  
`setDriveVelocity(axis, targetVelocity)` — drives toward a target velocity.

**For HCP:** Each joint in the explication tree represents a **semantic relation** between a sub-molecule and its parent. The joint type encodes the relationship class (e.g., `ePRISMATIC` for a monotonic scalar relation; `eSPHERICAL` for a multi-DOF free relation). Drive parameters encode how "tightly" the child is bound to the parent's semantic position.

A specific example: the molecule "quickly" (adverb) explicated as:
- Root link = "quickly" molecule (the whole)
- Child link 1 = "manner" sub-molecule (how-link)
- Child link 2 = "speed" sub-molecule (degree-link)
- Leaf particles = VERY, FAST (primes)

The articulation maintains the tree structure under simulation. Forces on the root propagate to all links; forces on leaf primes propagate upward.

**Per-link `PxFilterData`:**  
Each `PxArticulationLink` (as a `PxRigidBody`) has its own `PxFilterData` (128 bits). So sub-molecules within an articulation tree are individually queryable and filterable. You can query "give me all links in any articulation tree that have POS=VERB in word0" — this reaches into the internal structure of molecule definitions.

---

### Container Scale Split (Correction of Section 6)

Earlier analysis said: "deep container nesting has a cost cliff. Each PxScene costs ~80MB GPU RAM. Depth ~4-5 on 8GB = the wall."

**Corrected framing:** This applies only to **outer truth-scope containers** (PBDs, fiction frames, hypotheticals, beliefs-about-beliefs). These are genuinely separate semantic universes that need isolated phase namespaces, separate broadphase, and independent simulation.

**Inner molecule nesting** (explication sub-structures) does NOT use separate PxScenes — it uses articulation trees within a shared scene:

| Container type | Implementation | Cost | Depth limit |
|---|---|---|---|
| Outer truth-scope (PBD, fiction, hypothetical) | Separate `PxScene` | ~80MB GPU RAM each | ~4-5 on 8GB VRAM |
| Inner molecule nesting (explication trees) | `PxArticulationReducedCoordinate` within scene | ~KB per link | Essentially unbounded (thousands of links per scene) |

The depth cliff from the original analysis applies ONLY to outer containers. Molecule nesting depth is limited by memory per link (small) and solver iteration count (set once per articulation), not by scene overhead.

**Practical consequence:**  
A scene modeling a single PBD (outer container) can contain hundreds of articulation trees (explication trees for every molecule in that PBD's vocabulary). Within each tree, arbitrary nesting depth. The 80MB-per-scene wall is not the limiting factor for explication depth.

---

### `PxAggregate` — Envelope of Related Molecules

`PxAggregate` groups actors into a single broadphase entry. From the header:
```
A PxAggregate is a collection of PxActors which will exist as a single entry in the
broad-phase structures. Benefits:
1) reduces broadphase pollution (spatially coherent actors → one entry)
2) reduces broadphase memory usage
3) filtering optimized if self-collisions within aggregate are not needed
```

The `PxAggregateFilterHint` functions are `PX_CUDA_CALLABLE` — the type/self-collision hint is evaluated at GPU broadphase level.

**For HCP:** An **envelope** (in Patrick's formulation: a structured contextual container with a locus of identity) maps to a `PxAggregate`:
- All molecule rigid bodies that belong to one active envelope → one aggregate
- The aggregate appears as one broadphase entry → queries scoped to that envelope cost one broadphase test instead of N (one per molecule)
- `getSelfCollision() = false` → molecules within the same envelope don't interact with each other; only cross-envelope interactions happen. This is correct: within an envelope, molecules are co-defined; they don't need to "detect" each other
- Adding/removing a molecule to/from an active envelope = `addActor()` / `removeActor()` on the aggregate

When an activity envelope is the union of multiple participant envelopes (Patrick's framing: activity envelope = compiled intersection of all involved loci's envelopes), this is modeling several aggregates whose members interact across aggregate boundaries. The cross-aggregate interaction is where the broadphase does non-trivial work; within-aggregate is skipped.

---

### `PxArticulationReducedCoordinate` vs Flat Rigid Bodies — When to Use Each

| Use case | Structure | Reason |
|---|---|---|
| A molecule with no sub-structure | Single `PxRigidDynamic` | No hierarchy to track |
| A molecule with 2-3 fixed sub-parts | `PxArticulation` with `eFIX` joints | Tree is fixed at definition time; solver handles force propagation |
| A molecule with flexible semantic range (e.g., "fast" spanning a range of speeds) | `PxArticulation` with `eLIMITED` translational joint on the degree-link | Joint limits define the semantic range; drive target = current exemplar |
| A primes-only composition (new molecule being explicated from scratch) | `PxPBDParticleSystem` + particles settling to equilibrium | Let PBD settle; capture equilibrium as rigid body definition |
| Related molecules in one envelope | `PxAggregate` containing their rigid bodies | One broadphase entry; shared filtering hint |
| Nested explication tree (molecule that references other molecules) | `PxArticulationReducedCoordinate` | Reduced coordinate solver handles force propagation through hierarchy correctly |

---

### Articulation Tendons — Spanning Constraint for Long-Range Semantic Coherence

`PxArticulationSpatialTendon` and `PxArticulationFixedTendon` apply spring forces based on the **aggregate geometric length** across multiple links in an articulation tree. A spatial tendon spans from a root link to one or more leaf links, with a spring that pulls toward a target length.

**For HCP:** This is a **long-range coherence constraint** within an explication tree. For example:
- A tendon from the root molecule to a leaf prime = "this prime must remain within semantic reach of the molecule root"
- If the explication drifts (primes separate too far from each other in semantic space), the tendon applies corrective force
- Stiffness = how tightly the explication is constrained; damping = how quickly drift is corrected

Without tendons, forces propagate locally through the joint hierarchy. With tendons, non-adjacent parts of the explication tree can maintain direct geometric relationships — useful for molecules that have long-range structural constraints in their definitions (e.g., a relative clause that must remain semantically adjacent to its head noun regardless of tree depth between them).

---

### Summary: What These Framings Change

| Prior conclusion | Corrected/extended |
|---|---|
| "Minimal particle filter machinery is a gap at particle LoD" | Not a gap. Primes are operators, not relational entities. 20-bit group ID = correct granularity for 65 prime classes. |
| "Rich rigid body filter machinery is an alternative to consider" | It's where molecule relational work correctly lives. Not an alternative — a different LoD for a different kind of entity. |
| "Particle → rigid body promotion is an event triggered by a threshold" | It's explication settling. PBD convergence IS the explication act. Capture the equilibrium state as the rigid body. |
| "State transition triggering needs a contact callback + state machine" | Action prime = force perturbation to molecule rigid body. `addForce()` → re-settle → new equilibrium = S₂. No state machine needed; physics is the state machine. |
| "FEM Von Mises stress = a quality metric to consider" | It's the explication equilibrium meter. High stress = primes still in tension = molecule not yet settled = definition incomplete or ambiguous. |
| "Deep nesting hits 80MB/scene wall at depth ~4-5" | Only outer truth-scope containers need separate scenes. Inner explication nesting uses articulation trees (KB per link, essentially unbounded depth within one scene). |
| "PxAggregate: one option for broadphase optimization" | PxAggregate = an envelope boundary. Related molecules in one active envelope = one broadphase entry. Cross-envelope interaction = where broadphase does real work. |
| "`PxArticulationReducedCoordinate`: listed as available" | Primary structure for nested explications. Reduced-coordinate solver handles force propagation through the explication tree correctly. Each link has its own PxFilterData. |

---

---

## Addendum 5 — Dimensional Ceiling & Superposition Axis Verification (2026-05-11)

*Half-page verification of Q1 (dimension ceiling on particles) and Q2 (eTWIST/eSWING for superposition). No design decisions — structural fit and gotchas only.*

---

### Q1 — Semantic Dimension Ceiling

**What's actually on-particle and whether the solver owns it:**

| Channel | Size | Solver ownership | Safe for semantics? |
|---|---|---|---|
| `position.xyz` | 3 floats | Solver writes on every step | YES — these ARE the semantic coordinates; spatial hash runs on them (semantic neighbors → broadphase neighbors) |
| `position.w` (invMass) | 1 float | SDK uses for kinematic gating | RISKY — better used for existence encoding (see BE prime); don't co-opt for arbitrary semantics |
| `velocity.xyz` | 3 floats | **SDK owns** — pre-integration: `pos_pred = pos + v*dt`; post-solve: `v = (pos_corrected - pos_old)/dt` | **UNSAFE** — PBD corrupts these on every step |
| `velocity.w` | 1 float | SDK writes `0.0f` per `getVelocities()` docs | **FREE** — confirmed in `PxParticleGpu.h`: `PxVec4(vel.x, vel.y, vel.z, 0.0f)` |
| `phase[0:19]` | 20 bits | SDK uses for group join predicate | YES as discrete class ID (up to 1M distinct groups); not continuous |
| `phase[20:22]` | 3 booleans | SDK uses selfCollide / filter / fluid | Usable as behavioral flags; some are semantically meaningful anyway |

**Practical ceiling on particles: 3 continuous (position) + 1 float (velocity.w) + 20-bit discrete (phase group) + 3 boolean (phase flags).** Velocity vec3 is off limits. No more continuous dimensions are available at particle LoD without custom solver work.

**Rigid body additional dims (if the molecule is a kinematic rigid body with no colliders):**

- Quaternion (4 floats): For a kinematic body used as a pure semantic carrier (no collision shapes, `eKINEMATIC` flag), the solver does not enforce unit norm — user sets transform directly via `setKinematicTarget()`. All 4 components are effectively free if orientation has no physical meaning. Caveat: any code path that reads orientation as a real rotation will get garbage. Acceptable if the body is a semantic node, not a geometric one.
- Articulation joint angles: 6 independent axes per link (`eTWIST`, `eSWING1`, `eSWING2`, `eX`, `eY`, `eZ`), each readable in CUDA via `copyArticulationData(deviceBuf, ..., eJOINT_POSITION, n, copyEvent)`. **6 additional continuous dims per parent-child connection in the explication tree.** This is the practical high-bandwidth channel for molecule-internal state.

---

### Q2 — eSWING1/eSWING2 Independence & Superposition Axis

**Are eSWING1/eSWING2 independent or do they share a cone limit?**

Independent. `PxConeLimitedConstraint` (the cone geometry structure) lives in `PxParticleSystem.h` — it applies to soft-body/particle *attachments*, not articulation joints. Articulation joints have per-axis `PxArticulationLimit` (lower/upper bound) set via `setLimitParams(axis, limit)`. eSWING1 at ±π/4 and eSWING2 at ±π/2 on the same joint is fully valid with no shared cone coupling.

**Can a joint be `eLIMITED` on one axis and `eFREE` on others?**

Yes. `setMotion()` is per-axis and independent. Example: `setMotion(eTWIST, eLIMITED)` with `setMotion(eSWING1, eFREE)` and `setMotion(eX, eLOCKED)` on the same joint is supported. Each axis is its own degree of freedom in the reduced-coordinate solver.

**eTARGET drive: does it lock or oscillate?**

`PxArticulationDriveType::eTARGET` applies very high internal stiffness to track target angle. The joint remains in the physics simulation (not bypassed), so oscillation is possible if underdamped. With `damping >= 2 * sqrt(stiffness * effective_inertia)` (critical damping), it converges cleanly. The PhysX docs describe it as "almost kinematic." For 8 superposition states at π/4 increments encoded on `eTWIST`:

- Set `eTWIST` to `eLIMITED`, bounds `[0, 7π/4]` (or `-π` to `π` with state mapping)
- Set drive `driveType = eTARGET`, stiffness = high, damping = critically damped
- `setJointVelocity(eTWIST, 0)` + `setJointPosition(eTWIST, targetAngle)` to snap without settle lag
- **Gotcha:** eTARGET convergence speed depends on link inertia. Lightweight semantic links converge fast; if inertia is zero or near-zero, the solver may exhibit instability. Set a non-zero mass even for semantic-only links.

**Reading joint angles in CUDA kernels:**

Not a direct pointer from particle callbacks. Two-step access pattern:
1. `scene.copyArticulationData(deviceBuf, offsets, PxArticulationGpuDataType::eJOINT_POSITION, numArticulations, copyEvent)` — async device→device copy into your buffer
2. CUDA kernel reads `deviceBuf[artIdx * numJointsPerArticulation + jointIdx]`

This can be issued before `scene.simulate()` starts (so the buffer is populated for the previous frame) or between sub-steps. Not available as a live pointer in `onAdvance` — must schedule the copy explicitly. For `onAdvance` same-frame use: issue the copy at end of previous frame, kernel in `onAdvance` reads last-frame joint state.

---

### Summary table

| Question | Answer | Gotcha |
|---|---|---|
| Velocity vec3 co-opt | Unsafe — solver owns all 3 components | PBD pre-integration + post-solve both overwrite |
| velocity.w | 1 free float confirmed | SDK writes `0.0f`, not used |
| Kinematic rigid quat | 4 floats free if no geometric use | Any rotation-reading code will get garbage |
| Articulation joint angles | 6 per joint, fully independent | Not live pointer; schedule `copyArticulationData` explicitly |
| eSWING1 / eSWING2 cone | Independent — no shared cone in articulation | `PxConeLimitedConstraint` is particle-attachment only |
| Mixed axis motion modes | Supported per-axis on same joint | — |
| eTARGET lock vs oscillate | Converges cleanly if critically damped | Near-zero link mass → solver instability |

---

---

## Addendum 4 Correction — Outer Truth-Scope Containers Are Data-Layer, Not Engine-Layer (2026-05-11)

*Correction to Addendum 4's PxScene / container depth framing. Patrick: "they are less onerous than you think. that is a first step Postgres data source decision, the engine needs to know little about it."*

**What Addendum 4 said (incorrect):**
> Outer truth-scope containers (fiction, hypotheticals, PBDs, beliefs-about-beliefs) require separate PxScenes. ~80MB each, depth wall at 4-5 on 8GB GPU RAM.

**Corrected picture:**

Outer truth-scope containers are handled at the **envelope / data-source layer in Postgres**. Container activation = swap the active envelope + attach a truth-state stamp to relational parameters. The engine processes whatever envelope is currently active; it has no "fiction mode" any more than it has a "thinking about Tuesday mode." Nesting depth = depth of the envelope stack, which is cheap.

| Scope | Layer | Mechanism | Cost |
|---|---|---|---|
| Outer truth-scope (fiction, hypotheticals, PBD frames, beliefs-about-beliefs) | **Postgres / data layer** | Envelope stack push + truth-state stamp on relational params | Cheap — data selection |
| Inner molecule nesting (explication sub-structures) | **Engine layer** | `PxArticulationReducedCoordinate` within scene | KB per link, unbounded depth within scene |
| Compute isolation (parallel inference passes, resolution vs inference) | **Engine layer** | Separate `PxScene` instances | ~80MB each — real cost, real reason to limit |

**What this changes for prime/molecule encoding:**
- The truth-state of the current context is a relational parameter (phase bit / `velocity.w` / `PxFilterData` slot) on particles or rigid bodies in the active envelope. No separate scene needed.
- TRUE's 5-state architecture is the truth-state stamp — attaches to molecules within whatever envelope is currently active. "True in fiction but not in reality" = a truth-state value on a molecule in the fiction envelope, not a scene separation.
- The container primitive (see `project_prime_physics_roles.md`) is the same primitive at all scales — what changes is the layer. Outer scopes = Postgres envelope-stack push. Inner = articulation joint.

**Addendum 4 mapping table corrected row:**

| PhysX | HCP — Prior | HCP — Corrected |
|---|---|---|
| PxScene | Outer truth-scope container | **Compute isolation only** — parallel inference, distinct sim contexts. NOT semantic isolation. |

Everything else in Addendum 4 stands.

---

## Note — Mental Predicate Layer Assignment Correction (2026-05-12)

*Supersedes the Q3 weigh-in message (not written to file) that assigned the entire mental-predicate class to molecule layer as "envelope scope flags."*

**Corrected picture:** Mental predicates have **particle-layer quark encoding** — 2 bits (class flag + experience-line sub-bit) — with specific predicate identity at molecule layer. This is consistent with the Addendum 4 framing table which already correctly lists mental predicates as NSM primes = particles.

**The experience-line split (2026-05-12):**

| Group | Predicates | Character |
|---|---|---|
| Mental / theoretical | THINK, WANT, KNOW | Cognitive only, no sensory channel, temporally flexible |
| Physical / experiential | FEEL, SEE, HEAR | Sensory, bound to body/world contact event, temporally anchored to experience NOW |

**Quark-layer encoding when the class is wired:**
- Bit N (TBD): MENTAL_PREDICATE class flag — set on any mental-predicate quark
- Bit N-1 (TBD): experience-line sub-bit — clear = mental/theoretical, set = physical/experiential
- Specific predicate identity (which of the 6) → molecule layer (`HCPMoleculeProps.h` when that file is created)

**Why particle-layer for the class flag:** the experience-line distinction governs broadphase bonding rules — physical predicates require a BODY-substantive in broadphase neighborhood; mental predicates do not. That constraint must be evaluable at particle LoD. Specific predicate identity (THINK vs KNOW vs WANT, etc.) does not affect broadphase bonding and belongs at molecule layer.

**Force-binding connections for later (not design decisions):**
- Experience-line ↔ I/Not-I warrant: FEEL/SEE/HEAR carry strong direct I-phase warrant; THINK/WANT/KNOW carry weaker/tentative warrant and can run in Not-I (modeling another mind's thought). Will drive force-binding strength differences at molecule layer.
- Experience-line ↔ 5-state TRUE: theoretical predicates can occupy any 5-state position. Physical predicates constrain more tightly to is-active / was-active — you cannot physically FEEL something that never fired.

---

## Prior Documents (do not re-read unless needed)

The following prior documents cover the resolution-side foundations in full detail. This report builds on top of them:

- `hcp-engine/docs/physx5-reference.md` — complete PBD, FEM, rigid body, scene, constraint, GPU API catalog
- `hcp-engine/docs/o3de-physx-wrapping.md` — wrapped vs raw matrix, access patterns, CMake linking
- `hcp-engine/docs/physx-answers-for-engine.md` — bond injection, rigid body promotion, FEM setup, convergence detection
- `hcp-engine/docs/physx-phase2-response.md` — separate scenes per space, switching yard, concurrent streams, particle promotion
- `hcp-engine/docs/physx-superposition-response.md` — all-particle architecture, per-particle data channels (Q4), performance rationale
- `hcp-engine/docs/physx-phase2-tiered-consultation.md` — phase-gated tier model, phase group reassignment mechanics
