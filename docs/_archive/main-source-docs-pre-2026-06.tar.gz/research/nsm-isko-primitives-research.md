# NSM Semantic Primitives — ISKO Encyclopedia Research

**Source**: Hjorland, Birger. "Semantic primitives." ISKO Encyclopedia of Knowledge Organization,
eds. Birger Hjorland and Claudio Gnoli. https://www.isko.org/cyclo/primitives.htm
(Version 1.0, published 2025-08-27; also published in JASIST, https://doi.org/10.1002/asi.70011)

**Fetched**: 2026-04-13

---

## 1. Article Summary

This ISKO encyclopedia article by Birger Hjorland (Copenhagen) is a comprehensive review of semantic
primitives and compositionality across linguistics, cognitive science, philosophy, and knowledge
organization. It is explicitly an ARIST-style critical review, not an endorsement of NSM — Hjorland
argues ultimately for a historicist/pragmatic position skeptical of universal, fixed primitive sets.

The article covers: (1) the NSM framework of Wierzbicka and Goddard in detail, including the canonical
65-prime table; (2) the theoretical landscape of empiricism, rationalism, historicism, and pragmatism as
they bear on primitives; (3) atomism vs. holism as the central philosophical tension; (4) the periodic
table analogy and Hjorland's critique of it; (5) information science applications including facet
analysis, thesauri, and upper ontologies; (6) collected arguments against the primitive approach.

The author's own conclusion is that semantic decomposition is theory-dependent, domain-specific, and
cannot be done from a "view from nowhere." He endorses Kuhn's paradigm model: concepts are individuated
by theories, not by absolute primitives. This is a useful corrective perspective but does not invalidate
NSM for our purposes — NSM is explicitly a linguistic/cognitive project (not a KOS design project), and
Hjorland's critique is strongest against attempts to build universal classification systems on NSM primes.

---

## 2. Canonical Prime List — Wierzbicka's 65 Semantic Primes

Source: Table 1 in the article, "adapted from Levisen and Waters 2017, 12 and Goddard and Wierzbicka 2014."

This list has been stable since approximately 2014 (grew from 14 in 1972 to 65 today).

| Category | Primes |
|----------|--------|
| **Substantives** | I~me, you, someone, people, something/thing, body |
| **Relational substantives** | kind, part |
| **Determiners** | this, the same, other~else~another |
| **Quantifiers** | one, two, some, all, much/many, little/few |
| **Evaluators** | good, bad |
| **Descriptors** | big, small |
| **Mental predicates** | think, know, want, don't want, feel, see, hear |
| **Speech** | say, words, true |
| **Actions, events, movement** | do, happen, move |
| **Existence, possession** | be (somewhere), there is, be (someone/something), (is) mine |
| **Life and death** | live, die |
| **Time** | when/time, now, before, after, a long time, a short time, for some time, moment |
| **Space** | where/place, here, above, below, far, near, side, inside, touch (contact) |
| **Logical concepts** | not, maybe, can, because, if |
| **Intensifier, augmentor** | very, more |
| **Similarity** | like/as/way |

**Count**: 65 primes across 16 categories. The article notes Wierzbicka (2021) confirms stability
since 2014.

**Key formal semantics challenge** (endnote 12, citing Matthewson 2003): "There may not be a single
proposed semantic primitive which fails to strike formal semanticists as extremely complex. Thus, it
is difficult for us to accept the NSM claim that primitives such as I, YOU, SOMEONE, THIS, THINK, and
WANT are 'simple words' and that they are 'intuitively comprehensible and self-explanatory'." This is
Hjorland's cited criticism, not ours — for HCP, treating these as foundational particles is exactly
correct; the primitives are cognitively irreducible even if formally complex.

**Wierzbicka's five theoretical claims** about primes (reconstructed from article):
- (a) Primes are undefinable concepts
- (b) All other concepts are derived from primes (any concept reducible to these "kernels")
- (c) Primes are universal in all human languages
- (d) Analogy with chemical elements is appropriate
- (e) Primes are innate in human beings

---

## 3. Key Theoretical Positions

### 3.1 Atomism vs. Holism (Section 4.5)

The central philosophical tension is between **atomism** (parts have meaning independent of wholes)
and **holism** (meaning is determined by the entire system of relations).

**Atomism / compositionality assumption** (Pagin 1997): "Compositionality seems to imply that the
meaning of a complex expression is determined locally, by nothing else than what is internal to it,
i.e. the meaning of its parts and its mode of composition. So the parts must have a meaning prior to
the complex expression itself."

**Meaning holism** (Jackman 2020): "The label 'meaning holism' is generally applied to views that
treat the meanings of all of the words in a language as interdependent. Meaning holism is typically
contrasted with atomism about meaning (where each word's meaning is independent of every other word's
meaning), and molecularism about meaning (where a word's meaning is tied to the meanings of some
comparatively small subset of other words)."

**Wittgenstein's trajectory**: Early Wittgenstein (Tractatus) was the foundational atomist — every
proposition has a unique final analysis into elementary propositions, elementary propositions are
mutually independent, names refer to items devoid of complexity. Late Wittgenstein rejected all of
this in favor of language games and use-based meaning. This shift is philosophically important for HCP.

**Kuhn's paradigm holism**: The meaning of a term is relative to the paradigm in which it functions.
The astronomical terms "star" and "planet" meant different things in Ptolemaic vs. Copernican
frameworks — ontology drives concept-meaning, not the reverse. Applied to children (Gopnik et al.
1996): "Rather than reflecting some fixed set of semantic primitives, children's understanding of words
changes in parallel with their changing theoretical understanding of the world."

**Logical atomism tenets** (Wittgenstein Tractatus, as summarized by Proops 2022):
1. Every proposition has a unique final analysis revealing it as truth-function of elementary propositions
2. Elementary propositions assert existence of atomic states of affairs
3. Elementary propositions are mutually independent
4. Elementary propositions are immediate combinations of semantically simple symbols ("names")
5. Names refer to items wholly devoid of complexity ("objects")
6. Atomic states of affairs are combinations of these objects

HCP relevance: We are building with claim (5) — NSM primes ARE the "objects" — but we do NOT
require (3). Our molecules are not mutually independent; they share particles and create phase
overlaps. This is the ToM architecture.

### 3.2 The Periodic Table Analogy (Section 4.6)

**Wierzbicka's claim** (2006): Semantic primitives are "like chemical elements discovered by Mendeleev
are elementary building blocks of all chemical substances."

**Other supporters**: Baker (2001) "The Atoms of Language"; Zwicky (1973, 1980).

**Hjorland's structural critique** — where the analogy holds:
- Both consist of concepts and conceptual relations
- Both aim at a finite, closed set of irreducible elements
- Both claim everything else is composed from these elements
- Chemical notation is compositional (H2O = explicit composition)

**Where the analogy breaks down** (Hjorland's critique):

1. **Epistemic foundation**: Chemical elements are defined by physical/chemical theory grounded in
   world-knowledge. Wierzbicka claims her primes are purely linguistic and separable from encyclopedic
   knowledge. But: "Wierzbicka's analogy to the periodic table strengthens rather than weakens the
   case that semantic analysis must rest on an extensive base of world knowledge, cultural context, and
   theory-laden interpretation. Thus, her attempt to isolate 'pure linguistic meaning' from
   encyclopedic knowledge seems problematic — even internally inconsistent." (Endnote 25)

2. **Discovery method**: Chemical elements cannot be discovered "through linguistic, psychological, or
   sociological methods; and they are certainly not accessible via introspection, intuition, or formal
   logic alone." Wierzbicka's method relies on introspection and cross-linguistic comparison.

3. **Theory-dependence**: The periodic system "emerged from within the field of chemistry itself" —
   the classificationists were the scientists. "The lesson from the periodic system is that the very
   definition of chemical elements is theory-dependent and historically situated — and so are any
   attempts to classify them."

4. **Language universality vs. physical universality**: Chemical elements are universal across all
   human semiotic systems; NSM primes are claimed universal across natural languages but not
   demonstrated in formal or scientific semiotic systems.

5. **Reclassification vulnerability** (Rast 2023): "Since decompositions depend on world-level
   theories, they may ultimately be mistaken if those underlying theories are revised or refuted."
   Chemical element definitions have been revised repeatedly (ancient 4 elements → modern 118).

**HCP response to this critique**: We are not trying to build a Wierzbicka-style linguistic primitive
system. We are building a physics simulation. The periodic table analogy is even MORE apt for HCP than
for NSM: we are explicitly treating primes as particle types in a field, where "compounds" are stable
configurations (molecules) in that field. We embrace the theory-dependence — our theory is NSM itself,
and we know its foundations can evolve. The 65-prime set is our working hypothesis, not eternal truth.

### 3.3 Empiricism (Section 4.1)

Empiricism grounds primitives in perceptual experience. Miller and Johnson-Laird (1976) tried to
derive primitives from perception: [table] = OBJECT + CONNECTED + RIGID + TOP + FLAT FACE +
HORIZONTAL + VERTICAL. Failed: "even words for straightforward objects such as tables had elements of
meaning which were not perceptually based" and "much of the lexicon is based on primitive concepts
that are not perceptual."

**Implication**: Even if semantic primitives exist, they cannot be grounded purely in perception.
Something more abstract is required — which is why NSM's logical/relational primes (NOT, BECAUSE, IF,
CAN, MAYBE) are necessary alongside the substantive ones.

### 3.4 Rationalism (Section 4.2)

Rationalism grounds primitives in innate cognitive structures and logical axioms. Fodor's extreme
position: "virtually all lexical concepts are innate" — described as "really is an extreme outlier."
Laurence and Margolis (2024) take a more moderate position: primitives are "innate psychological
structures involved in concept acquisition, rather than as primitives in an absolute or metaphysical
sense." They accept some of Wierzbicka's primes but do not endorse a specific inventory.

Critique: "No one agrees what these components are, and no one has been able to find them" (Aitchison
2012). "We conclude, therefore, that atomic globules do not exist in the mind" (Aitchison 2012).

Rationalism shares weakness with empiricism: both are individual epistemologies that do not recognize
social/cultural shaping of the mind.

### 3.5 Historicism and Pragmatism (Sections 4.3, 4.4)

Historicism: primitives are relative to historical/disciplinary contexts. Thomas Kuhn's paradigm
theory is the key example. Different paradigms carve reality differently → different concept-sets.

Pragmatism (Peirce): "any attempt to formalize the entire meaning of a body of knowledge as
impossible. An irreducible dimension of the meaning of any term... is constituted by the effects that
an agent situated in the world would experience in relevant situations and the sum total of such
effects can never be known in advance."

**Blumczynski (2016)** — the most articulate critic from a historicist position. Four differences
from NSM:
1. NSM postulates a FINITE set; Blumczynski's is open and flexible
2. NSM seeks reductive explications exhausting semantic content; Blumczynski holds words are
   context-dependent and "any attempts of decontextualized semantic explications" are invalid
3. NSM claims language-independence (perfect translation across languages); Blumczynski's primitives
   are "inevitably bound to the English language"
4. NSM uses primitives as terms (stripping natural polysemy); Blumczynski keeps them as concepts
   "prone to interpersonal and contextual variation"

---

## 4. Compositionality Principles (Section 3)

### 4.1 The Principle of Compositionality

Goldberg (2016): "A principle of compositionality is generally understood to entail that the meaning
of every expression in a language must be a function of the meaning of its immediate constituents and
the syntactic rules used to combine them."

**Costello and Keane (2000) — four reasons compositionality matters**:
1. Allows communication between people with different knowledge (shared word-meanings suffice)
2. Provides the generative nature of language (infinite expressions from finite words)
3. Explains language learning (once you know words, you understand any combination)
4. Determines information access in comprehension (same word → same information in any context)

**Pelletier (1994) survey**: Approximately 318 arguments raised AGAINST compositionality in the
literature; only 3-4 arguments offered IN FAVOR.

**LLM evidence** (Nefdt and Potts 2024): "Modern large language models seem to induce partial
compositional analysis just from training on large quantities of text... these models seem, at least
in some instances, to arrive at process compositional analyses, and this may explain how they are able
to successfully generalize to novel expressions." This is strong support for the claim that
compositionality is real even if not fully universal.

### 4.2 Componential Analysis (Section 3.2)

Geeraerts (2005): "Componential analysis is an approach that describes word meanings as a combination
of elementary meaning components called semantic features or semantic components. The set of basic
features is supposed to be finite."

The inverse of decomposition is **conceptual combination**. In bibliographic classification these
are called **analysis** and **synthesis** — together forming "analytico-synthetic classification."

**Kinship terms example** (Henning 2020) — classic demo of componential efficiency:

| Word | Semantemes |
|------|-----------|
| Father | male + parent |
| Mother | female + parent |
| Son | male + offspring |
| Daughter | female + offspring |
| Brother | male + sibling |
| Sister | female + sibling |

Six terms analyzed with five semantemes. The same six terms can also be encoded with three abstract
components: sex (male/female), generation (numeric: -1, 0, +1), lineage (direct/colineal/ablineal).
This illustrates how a small set of orthogonal dimensions can encode a large relational vocabulary.

**Geeraerts's assessment**: "There is widespread agreement in linguistics about the usefulness of
componential analysis as a descriptive and heuristic tool, but the associated epistemological view
that there is a primitive set of basic features is generally treated with much more caution."

### 4.3 Semantic Factoring

Sowa (2003): "Semantic factoring is the process of analyzing some or all of the categories of an
ontology into a collection of primitives."

Soergel (1985) example — [ship] decomposed:
```
[ship] = [vehicle] : [water transport]
       = [means] : [transportation] : [mobile] : [water]
```
"Carrying this process to the end leads to elementary concepts that cannot be factored further."
The practical question: how far do you carry it? Is [water] itself a primitive? (It decomposes
to H2O, but that is encyclopedic knowledge, not semantic knowledge.)

**ISO 25964-1:2011** (thesaurus standard) acknowledges the decision of when to apply semantic
factoring is "often difficult and subjective" — no formal criteria exist.

---

## 5. Information Science Applications (Section 5)

### 5.1 Facet Analysis and Semantic Factoring (Section 5.1)

Ranganathan's PMEST model — five fundamental categories claimed necessary and sufficient:
- **Personality**: distinguishing characteristic of a subject
- **Matter**: physical material of which a subject is composed
- **Energy**: any action that occurs with respect to the subject
- **Space**: geographic component
- **Time**: period associated with a subject

The analytico-synthetic methodology:
- **Analysis**: breaking each subject into basic concepts
- **Synthesis**: combining relevant units to describe subject matter

**Meccano analogy** (Raghavan 2019): Ranganathan found inspiration "in observing a Meccano toy set
composed of a few basic components that could be combined to construct various toys." A few basic
components → unlimited constructions. This is exactly our HCP molecules model.

**Historical context**: Faceted classification (FC) as "modern classification theory" within LIS.
Vickery (1960) noted 13 facets, Broughton expanded further — showing pragmatic growth away from
Ranganathan's fixed 5.

**Three open questions in facet analysis** (article's formulation):
1. How far should semantic factoring go? When is a concept "basic enough"? No principled answer.
2. Does semantic holism (Kuhn) limit analytico-synthetic classification? If concepts change meaning
   by context, decomposition is unstable.
3. Is facet analysis neutral, or does it embed theoretical bias? (e.g., does a biomedical facet
   structure privilege the reductionist biomedical model over biopsychosocial models?)

### 5.2 Szostak's "Basic Concepts" (Section 5.2)

Szostak (2011) advocates decomposing complex concepts into "basic concepts" for a universal
classification system. His claim: basic concepts "can be understood in a similar way across disciplines
and cultures." Interdisciplinary communication would be enhanced if scholars had access to a
classification "not grounded in particular disciplines or cultures."

**Hjorland's critique** (four points):
1. Intelligibility is not a function of simplicity — it depends on the learner's prior knowledge
   (Riemer 2006). "Basic-level categories vary across individuals and cultures" (Hajibayova 2013).
2. His cladistic bird/fish classification is empirically wrong (birds are a valid clade; his
   system puts them in "Hypothesized Species" — demonstrably incorrect per cladistics).
3. Precision standards are inconsistent — he argues against excessive precision in one paper but
   for it in another.
4. His argument structure is backward: rather than grounding his system in a specific theory of
   concepts, he tries to show that none of five concept theories contradicts his position.

**Key insight**: Only the classical theory of concepts (necessary and sufficient features: [bachelor]
= [unmarried] + [man]) unequivocally supports compositionality in the strong universal sense Szostak
assumes. The "theory theory of concepts" (which Hjorland endorses) strongly challenges it.

### 5.3 Thesauri and Sparck Jones (Section 5.3)

Sparck Jones (1992): The thesaurus "has been envisaged as having a similar function in NLP, that of
providing semantic primitives... A thesaurus was seen as providing a set of general-purpose,
domain-independent semantic primitives allowing the specification, or at least an indication, of the
essential semantic concepts expressed by, or relating to, a text, and hence allowing sense
determination."

In practice, thesaurus primitives = Roget's ~1000 thematic headings (e.g., "SOFTNESS" = class 324).
Wilks and Tait (2006) noted the tension: Sparck Jones used statistical/empirical methods to find
emergent primitives but also imposed Roget's a priori structure.

Sparck Jones eventually abandoned the notion of semantic primitives. Her final position: "while you
can't make a language processor without semantic primitives somewhere, you choose your semantic
primitive cloth, and tailor it, to suit your processor climate." — which Hjorland reads as pragmatist.

### 5.4 Upper Ontologies (Section 5.4)

UMLS: 730,000+ concepts → 134 semantic types → 15 high-level groupings (McCray et al. 2001):
Activities and Behaviors, Anatomy, Chemicals and Drugs, Concepts and Ideas, Devices, Disorders,
Genes and Molecular Sequences, Geographic Areas, Living Beings, Objects, Occupations, Organizations,
Phenomena, Physiology, Procedures.

**Kausch (2024)**: "The use of a top-level ontology composed of semantic primitives could not only
aid in interoperability, but also contribute to the long-term preservation of knowledge organization
systems." Explicitly cites Wierzbicka.

**Hjorland's warning**: "Wierzbicka's 65 semantic primitives are qualitatively different from the
concepts employed in well-known upper ontologies such as those by Sowa, Cyc, or the Suggested Upper
Merged Ontology (SUMO)." The NSM project is a linguistic project about universal natural language
meanings; upper ontologies are formal engineering artifacts. These are different things.

---

## 6. Critiques and Failure Modes (Section 4.7 + throughout)

### 6.1 Goodman's Relativity of Primitives

Goodman (1951): "It is not because a term is indefinable that it is chosen as primitive; rather, it
is because a term has been chosen as primitive for a system that it is indefinable in that system. No
term is absolutely indefinable... There is no absolute primitive, and no one correct selection of
primitives."

Primitives are STIPULATED, not DISCOVERED. They are defined by their role within a specific
theoretical or formal framework. Wierzbicka's response: Goodman's relativism only applies to
artificial languages, not to natural languages. Hjorland's response: this rebuttal does not apply to
KOS (knowledge organization systems), which are by nature artificial.

**For HCP**: We accept Goodman's point — our 65 primes are stipulated within the NSM framework. This
is a feature, not a bug. The stipulation is grounded in decades of cross-linguistic empirical work.

### 6.2 Compositionality Failure for Complex Compounds

Weiskopf (n.d.): "New compound concepts ('pet fish' is given as an example) often involve emergent
properties not derivable from those theories in isolation." A "pet fish" is neither a typical pet nor
a typical fish — the compound creates properties that do not follow from the components.

This is the **conceptual combination problem**: emergent properties in compounds that violate strict
decompositionality. The classic example: a "small elephant" is a large animal. Size predicates don't
compose predictably across domains.

**For HCP**: Emergence is a DESIRED property in our simulation, not a failure. When prime-particles
interact in a phase space, emergent stable configurations are exactly what molecules ARE. The
"pet fish" problem is interesting — it means our DAG cannot be a simple intersection of prime-sets;
the topology of prime-configuration matters, not just prime membership.

### 6.3 Inadequacy of the [sugar] Example

The article quotes Wierzbicka's approach and then tests it: "Take the example of the ordinary concept
[sugar]. As neither [mouth] nor [sweet] is included among the 65 primes, one would need to define
sugar using only the approved primitives — for example, [a kind of thing], [this thing is small],
[people can do something with this thing], [when people eat it, they feel something good]. Such a
definition appears inadequate."

This critique is about the SPAN problem: the 65 primes may not span the full semantic space needed
for practical knowledge organization. Wierzbicka's primes are optimized for universal cross-linguistic
concepts, not for domain-specific classification or information retrieval.

**For HCP**: We have ~2,700 molecular concepts that act as intermediate nodes. We are NOT trying to
define [sugar] in 65-prime terms directly. The molecule [sweet] is an intermediate concept. The
DAG allows up to 4 levels of nesting. This is Goddard's design constraint, which we're honoring.

### 6.4 Linguistic/Encyclopedic Knowledge Boundary

Wierzbicka claims: "The meaning of a word is not the same as what people know or believe about the
thing or situation that the word refers to. Semantics is not encyclopedic knowledge." This distinction
is her foundational methodological claim.

Hjorland's critique: The distinction is increasingly untenable. Scientific knowledge reshapes
everyday meanings; the interpenetration of language and evolving knowledge systems undermines the
claim that linguistic meaning forms a stable, autonomous system.

### 6.5 Circularity Risk

Hjorland does not discuss circularity explicitly, but the article implies it through the Goodman
critique. A system of mutual definitions (where A is defined in terms of B, and B in terms of A)
cannot have a ground level. Wierzbicka's primes are the proposed ground — undefinable, hence
non-circular. But if the primes are not truly self-evident (as Matthewson 2003 argues), then the
supposed ground is itself problematic.

**For HCP**: The acyclicity constraint (no circularity in the decomposition DAG) is a hard
architectural constraint from Goddard. This is the correct engineering response to this failure mode.

---

## 7. Cross-References and Related ISKO Pages

The main article links to these ISKO encyclopedia pages:

| URL | Topic |
|-----|-------|
| https://www.isko.org/cyclo/facet_analysis | Facet Analysis — the ISKO encyclopedia's own detailed article on Ranganathan's PMEST and British CRG tradition |
| https://www.isko.org/cyclo/kos | Knowledge Organization Systems (KOS) |
| https://www.isko.org/cyclo/thesaurus | Thesauri |
| https://www.isko.org/cyclo/ontologies | Ontologies |
| https://www.isko.org/cyclo/ranganathan | S. R. Ranganathan biography |
| https://www.isko.org/cyclo/logical_division | Logical Division (Aristotle's genus/differentia) |
| https://www.isko.org/cyclo/ideal_language | Ideal Language (Leibniz, Wilkins) |
| https://www.isko.org/cyclo/ir | Information Retrieval |
| https://www.isko.org/cyclo/folk | Folk Classification |
| https://www.isko.org/cyclo/domain_analysis | Domain Analysis |
| https://www.isko.org/cyclo/ddc | Dewey Decimal Classification |
| https://www.isko.org/cyclo/bc2 | Bliss Bibliographic Classification 2nd ed. |
| https://www.isko.org/cyclo/phenomenon | Phenomenon (Szostak's classification basis) |

**Key papers cited** (accessible/relevant):
- Goddard (1998): "Bad arguments against semantic primitives" — directly defends NSM against the
  objections raised. *Theoretical Linguistics* 24(2-3), 129-156.
  https://doi.org/10.1515/thli.1998.24.2-3.129
- Goddard and Wierzbicka (2014): *Words and Meanings* — Oxford UP. The canonical source for the
  current 65-prime table.
- Wierzbicka (2021): "'Semantic primitives', fifty years later" — Russian Journal of Linguistics
  25(2), 317-342. https://doi.org/10.22363/2687-0088-2021-25-2-317-342. Confirms list stability.
- Levisen and Waters (2017): *Cultural Keywords in Discourse* — John Benjamins. Source for Table 1.
- Goodman (1951): *The Structure of Appearance* — Harvard UP. The "no absolute primitive" argument.
- Nefdt and Potts (2024): "Compositionality" in MIT Open Encyclopedia of Cognitive Science.
  https://doi.org/10.21428/e2759450.494deacd. LLM/AI perspective on compositionality.
- Kausch (2024): "Nuclear semiotics and knowledge organization: Five design heuristics for semantic
  primitives." *Advances in Knowledge Organization* 20, 385-391. Directly about using NSM primes in KOS.

**ISKO Facet Analysis article** (https://www.isko.org/cyclo/facet_analysis.htm) key additional
content:
- Ranganathan's PMEST formula in detail: Personality, Matter, Energy, Space, Time
- Connection to Aristotle's five predicables: genus, species, difference, property, accident
- Vickery's definition: "The essence of facet analysis is the sorting of terms in a given field of
  knowledge into homogeneous, mutually exclusive facets, each derived from single characteristic of
  division."
- BC2 as the most theoretically advanced faceted system
- Key weakness: "its lack of empirical basis and its speculative ordering of knowledge without basis
  in the development or influence of theories and socio-historical studies"

---

## 8. Implications for HCP Concept Space

### 8.1 The 65 Primes as Particle Types — Validation and Caveats

The ISKO article provides the canonical list and confirms its stability since 2014. The 16 categories
are structurally important for HCP particle physics: they suggest natural groupings with different
physical behavior:

- **Substantive primes** (I, YOU, SOMEONE, PEOPLE, SOMETHING, BODY): These are the "matter" particles —
  entities that anchor perspectives and ToM phases. PEOPLE/SOMEONE are Fermionic in character (they
  individuate); SOMETHING/BODY are more Bosonic (they generalize).
- **Relational substantives** (KIND, PART): Structural particles — they define taxonomic and
  mereological bonds between molecules. KIND is the hypernymy relation; PART is the meronymy relation.
- **Determiners** (THIS, SAME, OTHER): Reference-fixing particles — they resolve binding and identity.
- **Quantifiers** (ONE, TWO, SOME, ALL, MUCH/MANY, LITTLE/FEW): Cardinality particles — they modify
  the "density" of a concept-field.
- **Evaluators** (GOOD, BAD): Value particles — they introduce normative phase variance.
- **Logical concepts** (NOT, MAYBE, CAN, BECAUSE, IF): Operator particles — they modify the
  combinatorial rules themselves. NOT is particularly interesting as an inversion operator; MAYBE
  introduces epistemic probability amplitude.
- **Mental predicates** (THINK, KNOW, WANT, DON'T WANT, FEEL, SEE, HEAR): ToM particles — these
  are the ones that carry Theory of Mind variance. Every THINK or KNOW is implicitly quantified over
  a perspective (whose THINK?). These create the phase separation between subjective viewpoints.
- **Time** (8 primes): Temporal frame particles — they define the aspect/tense of a concept.
- **Space** (9 primes): Spatial relation particles — they define topological structure.

### 8.2 The Atomism/Holism Tension in PBD Space

The Pagin formulation is the HCP design assumption: "parts must have a meaning prior to the complex
expression itself." In our simulation, primes have stable particle types regardless of what molecule
they compose. A NOT particle in the molecule [unhappy] is the same particle type as a NOT particle
in [impossible]. This is strong atomism.

The Kuhnian holism challenge is real but manageable: our molecules are defined NSM-style with
explications that EMBED the relevant theoretical context. A molecule like [democracy] in our database
carries its NSM explication, which encodes the relevant conceptual context. We are not claiming
primes are theory-free; we are claiming the NSM explication framework provides the theory that
grounds each decomposition.

### 8.3 The Periodic Table Analogy — Embrace It Fully

Hjorland's critique of the analogy is primarily directed at Wierzbicka's inconsistency (she claims
linguistic purity but invokes a physical/scientific analogy). For HCP, the analogy is
METHODOLOGICALLY APPROPRIATE because:

1. We explicitly embrace theory-dependence. Our "elements" are defined by the NSM theory.
2. We build a physics simulation — the analogy to chemistry is not metaphorical but structural.
3. Chemical elements have different valences, charges, and bonding behaviors. Our primes should have
   analogous differential physics: THINK bonds differently than HAPPEN; I creates a phase-center
   that SOMETHING does not.
4. The periodic table has rows and columns with predictable patterns. Our 16 categories may have
   analogous structural regularities. The Mental predicates row predicts ToM behavior. The Logical
   concepts row predicts operator/modifier behavior.
5. Rast's warning — "decompositions may be wrong if underlying theory turns out to be false" — is
   our versioning constraint. The HCP molecular database is versioned and updatable. If NSM revises
   its list from 65 to 67, or reclassifies a prime, that propagates through database migrations.

### 8.4 The Compositionality Constraints for HCP Molecular Design

From the ISKO article and the NSM framework, three hard constraints emerge for our decomposition DAG:

1. **No circularity** (from Goodman's argument and Goddard's design): The DAG must be acyclic. Any
   definition that eventually refers back to itself collapses into an infinite regress. Engineering:
   store as a DAG with topological ordering; reject cycles at insertion time.

2. **Lexicalization** (from the ISKO article's Section 1 discussion): "When [concepts] are [in a
   language], the concepts are said to be lexicalized." Molecules should correspond to real word
   meanings — not arbitrary combinations of primes. The 2,700 molecules are already lexicalized
   (they came from natural language dictionaries and NSM explications). New molecules should be
   grounded in attested word meanings, not invented.

3. **Necessity** (implicit in componential analysis critique): Only decompose when primes alone aren't
   enough. Over-decomposition (carrying analysis too far) is a recognized failure mode in facet
   analysis and thesaurus construction. ISO 25964-1:2011 explicitly acknowledges this. For HCP:
   when a word is already a prime, it stays prime — no decomposition. When a word needs more than
   4 levels to be expressed in primes alone, it needs intermediate molecules.

### 8.5 Theory of Mind Phase Variance — NSM Support

The article implicitly supports HCP's ToM architecture. The Mental predicates category (THINK, KNOW,
WANT, DON'T WANT, FEEL, SEE, HEAR) + the Substantive primes (I, YOU, SOMEONE, PEOPLE) create a
natural foundation for perspective-indexed propositions.

Every NSM explication implicitly carries a perspective frame. The explication for [angry]:
"X felt something bad because X thought: 'this person did something bad'... X thought about it,
wanted to do something bad to this person..." The THINK here is X's think, not the reader's think.
This is exactly the HCP ToM phase — every molecule carries an implied phase statement ("whose
perspective").

WE as a construct: "WE constructs emerge from overlapping ToM phases" — this is consistent with the
NSM prime PEOPLE and the quantifier WE (which is not itself a prime, but composed from I + SOMEONE +
SAME). WE-space is a shared overlap region in the concept field.

### 8.6 Emergence and the "Pet Fish" Problem

Weiskopf's emergent properties objection is actually architecturally interesting for HCP. If compound
concepts have emergent properties not derivable from prime-intersection alone, then the TOPOLOGY of
prime-configuration matters — not just which primes are present but HOW they are bonded. In chemistry
terms: the same atoms in different molecular geometries produce different compounds (isomers).

For HCP: two molecules that share the same prime set but different bonding structure (different DAG
topology) are different molecules. This is already our design — we store the full explication, not
just a prime membership set. The explication encodes the syntactic structure of combination
(BECAUSE, IF, WHEN clauses = structural connectors between prime-nodes).

### 8.7 Broadphase Pruning and the Holism Problem

The holism objection (meaning changes by context) maps to our broadphase architecture. In full
holism, every concept-meaning would require loading the entire conceptual universe. In our design:
broadphase pruning makes inactive particles free — we load concepts generously but only activate
relevant ones. This is a computational middle path between strict atomism (all meanings fixed
independently) and full holism (load everything). Envelope-based loading is the implementation.

### 8.8 The Three-Level Hierarchy and Mereology

The article's opening semiotic triangle (ontological / conceptual / linguistic levels) maps cleanly
onto HCP's three-layer hierarchy:

- **Ontological level** → Physical reality (primes as fundamental forces/properties of cognition)
- **Conceptual level** → Concept space (molecules as stable configurations in prime-field)
- **Linguistic level** → Text stream (tokens as lexicalized manifestations of concepts)

The LMDB/Postgres/disk three-layer cache architecture is an engineering parallel: primes in VRAM,
molecules in LMDB hot cache, full explication DAG in Postgres.

---

## 9. Appendix: Historical Precedents for Concept Composition Systems

From the article — relevant historical systems:

**Ramon Llull (1305-1308)**: Ars Magna — disks inscribed with primitive concepts, combined by
rotating the disks. First mechanical system for concept combination. Described as the first AI system
based on primes.

**Leibniz (1679)**: Universal Characteristic — represented primitive concepts by prime numbers,
compound concepts by products of primes. All A is B is verified if number(A) is divisible by
number(B). Example: PLANT=17, DECIDUOUS=29, DECIDUOUS-PLANT=493. VINE=1,192,567, BROAD-LEAFED-
PLANT=20,213 — "All vines are broad-leafed plants" is true because 1,192,567 is divisible by 20,213.
This is a precursor to our molecular integer-ID space.

**Wilkins (1668)**: Essay Towards a Real Character — artificial language that is "very close in
nature to a faceted classification." The comment from an anonymous ISKO reviewer: "his examples are
very similar to those in the figure from Henning [the kinship semantemes table]."

**Roget (1852)**: Thesaurus — 1,000 thematic headings as practical vocabulary primitives for IR.
Sparck Jones's work showed the tension between empirical emergence and a priori structure in using
thesaurus heads as primitives.

---

*Research compiled by Claude Sonnet 4.6 for the HCP project, 2026-04-13.*
*Source: https://www.isko.org/cyclo/primitives.htm (fetched and read in full)*
*Secondary source: https://www.isko.org/cyclo/facet_analysis.htm (fetched and read)*
