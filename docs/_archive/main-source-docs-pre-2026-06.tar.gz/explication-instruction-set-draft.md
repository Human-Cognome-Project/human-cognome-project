# Local-model explication generation — instruction-set draft

Working notes for the autonomous-week setup (Ministral or Gemma running
unattended against `source_english`, generating NSM explications, writing back
to `source_english.explications`).

This is a **draft** — assemble into final instruction text once the
infrastructure (model, driver, prompt scaffolding) is in place.

---

## 1. Format

- **Lettered or numbered propositions**, one per line
- **Indentation marks parent-child structural nesting** — sub-propositions belong to their parent. Indentation is a pivot marker, NOT formatting.
- **Pure prime-only language at the leaves**; molecule references resolve via the token_id namespace (no `[m]` markers needed because namespace disambiguates structurally)
- **Free variables (X, Y)** for argument positions in verb formulas
- Each line is one self-contained NSM proposition

## 2. Prime list

- **65 canonical primes** (Goddard/Wierzbicka NSM-65)
- 2 of those are countability-superposition pairs — same prime, different surface form by host-noun count:
  - `MUCH` (mass-noun: "much water") / `MANY` (count-noun: "many things")
  - `LITTLE` (mass-noun) / `FEW` (count-noun)
- Reference: `nsm-minimal/gwriter/primes.py` from NSM-DALIA package (categorized list of 67 — drop count of `MUCH/MANY` and `LITTLE/FEW` to one each gives 65)
- hcp_core has 65 `nsm_prime` tokens already namespaced — these ARE the prime list

## 3. Molecule references

- Refer to molecules by token_id from hcp_core (`AA.AC.AA.AB.Ca` for hand, etc.)
- Implicit structural references in source NSM text (e.g., "two other parts of body" = arms) get **resolved by a separate post-pass**, not by the LLM. Model emits canonical surface text; structural resolution is a later step.
- Cross-molecule references form a DAG. Track them in `explication_molecule_refs(explication_id, ref_token_id, ref_type)`.

## 4. Storage shape

```
explications:
  explication_id      bigserial PK
  entry_id            FK -> source_english.entries
  sense_id            FK -> source_english.senses (nullable; explication may be entry-level)
  source_label        text  -- 'Goddard 2009', 'Ministral 2026-04-29', etc.
  status              text  -- pending / generated / validated / needs_review / rejected
  model               text  -- model id if LLM-generated
  generated_at        timestamptz
  validation_notes    text

explication_propositions:
  prop_id             bigserial PK
  explication_id      FK
  parent_prop_id      FK self  -- NULL = top-level; non-NULL = sub-proposition (indented child)
  ordinal             text     -- 'a', 'b', 'c' or '(a)', '1.', etc.
  depth               smallint -- redundant with parent walk but cheap
  text                text     -- canonical surface form
  structured          jsonb    -- parsed prime/mol-ref tree, populated by separate pass

explication_molecule_refs:
  ref_id              bigserial PK
  explication_id      FK
  ref_token_id        text     -- the molecule referenced (hcp_core tokens.token_id)
  resolution_kind     text     -- 'explicit' (named in canonical text)
                                -- 'implicit' (structurally inferred, e.g. "two other parts")
                                -- 'pending' (LLM emitted prose, post-pass to resolve)
```

## 5. Validation — cheap automated checks

1. **Prime-set check** — every content word at the leaf level should resolve to:
   - A prime in the 65-prime list, OR
   - A known molecule (hcp_core.tokens lookup), OR
   - Function words / structure markers ("if", "when", "this", etc. — also primes)
2. **Length sanity** — explications typically 4–12 propositions; outliers flagged for review
3. **No self-reference** — the explication of X should not mention X recursively (cycles fail).
4. **Empty / parse failure** — empty result, malformed indentation, or model error → status='needs_review'

## 6. Goddard explication patterns (narrative arcs)

These are observed structural shapes from gold-standard explications. Use as
templates / guidance for the LLM, not as hard rules.

- **Body part (hands)**:
  intro structural position → containing-part relation → capability of motion → capability with people doing/touching → consequence
- **Living kind (children)**:
  intro kind → temporal boundary (life-cycle) → physical scale → capability bound → consequence/dependence
- **Substance (water)**:
  intro kind → distribution in places → use with body parts (mouth/hands) → behavior properties → preference/desire
- **Being (God)**:
  intro kind → distinction from other kinds → temporal scope (always) → causal role (everything exists because) → existence-self-causation

The LLM should **identify which arc fits** the entry being explicated, then
fill in the propositions accordingly. Arc selection is a useful prompt input
(provide the entry's POS + sense gloss + sample source text; let model pick).

## 7. Test/validation gold standards

Seed `explications` with these as `source_label` known references:

| word | source | propositions |
|---|---|---|
| God | NSM-DALIA def_God (canonical.js) | 9 |
| hands | Goddard 2009 [A] | 7 |
| hands (alt) | NSM-DALIA def_hands | 7 (slightly different framing) |
| water | NSM-DALIA def_water | 6 |
| children | Goddard 2009 [B] | 6 |
| (verb) go | Goddard *Semantic Analysis* p.204 | 5 (with X variable) |

These let the autonomous run grade itself: when the model regenerates "hands",
compare to the two existing hand explications and score similarity (prime-set
overlap, proposition count, structural arc match).

## 8. No-go (model should not emit)

- English idioms not decomposed: "kind of", "sort of", "in fact", "more or less"
- Regional spelling variants ("color"/"colour"): emit the lemma only
- Latin/scientific names: use the English gloss
- Explanations that loop back on the headword being defined
- Multi-paragraph prose: must be lettered propositions only
- "It's like saying X" — meta-prose; emit primes directly

## 9. Resume / crash recovery

- Driver script processes one entry at a time
- Each entry's explication generation is one transaction
- `status` column lets the driver pick up where it left off (`WHERE status IS NULL`)
- Per-row commit; same pattern as `drain_english.py`

## 10. Architectural alignment (Patrick 2026-04-28)

**Everything works in molecular space.** Primes are depth-0 molecules. No
prime-vs-molecule branch in operations; both are looked up the same way.

Current `hcp_core` token registry breakdown (~2,780 total, fits Wierzbicka's
projected 2,700 working vocabulary):

| tier | count | role |
|---|---|---|
| `nsm_prime` | 65 | indivisible atoms |
| `nsm_aa`   | 65 | molecular wrappers around primes (call primes in molecule space) |
| `nsm_ab`   | 302 | tier-1 universal foundational molecules (body parts, basic objects/actions) |
| `nsm_ac`   | 2,352 | tier-2 language-specific & compound molecules |

**Replace `universal/standard` binary with `languages text[]` column:**
- `NULL` = universal across all languages
- `['en']` = English-specific
- `['es','pt']` = shared by multiple languages
- `['en-AU']` = regional within a language
- Cross-shard equivalence (gato/cat/chat → Felis-catus molecule) by token_id reference, not by language tag

## 11. Known data-quality issues to fix during the autonomous pass

- **Polysemy collapse**: same surface form, different molecule, fused into one entry. Examples:
  - `arms` = limb plural AND weapons (currently one entry, weapons definition wins)
  - `limb` = body part AND tree branch (one entry, both senses jammed in)
  - Each sense should become its own token_id with disjoint explication
- **Tier duplication**: same molecule listed at `nsm_ab` AND `nsm_ac` (e.g., `arm`, `hand`). Decide canonical tier per molecule; merge metadata; deprecate the duplicate or keep one tier as the namespace authority.
- **Definition prose contamination**: many existing definitions read as English prose ("An arm or leg. One_of several long parts_of...") — these need conversion to canonical NSM lettered/indented propositions.

The autonomous LLM run should mark entries with these issues for human review
rather than silently rewriting. Use `notes` column to flag ('polysemy_collapse',
'tier_duplicate', 'prose_definition').

## 12. Open questions (resolve before autonomous run)

- **Which model**: Ministral 8B (current, instruction-tuned, ~16 GB VRAM) vs Gemma 3 (newer, smaller variants available)? Performance vs throughput tradeoff.
- **Prompt template**: zero-shot vs few-shot with the gold standards in-context? Few-shot likely better; gold examples from §7.
- **Batch order**: by frequency (common words first), by POS group (all nouns, then verbs), or by entry_id? Common-words-first feeds the molecule library faster (later entries can reference earlier ones).
- **Validation rigor**: full automated grading vs flag-and-spot-check? For an unattended week, mark all questionable, let Patrick triage on return.
- **Cross-shard resolution**: when explication needs `Felis catus` (Latin) but it's not in `source_english`, mark as pending and skip — handle in a later cross-shard pass.

---

**Status:** draft. Will be assembled into the actual prompt scaffolding once
infrastructure decisions are made. Update as Goddard examples and edge cases
accumulate.
