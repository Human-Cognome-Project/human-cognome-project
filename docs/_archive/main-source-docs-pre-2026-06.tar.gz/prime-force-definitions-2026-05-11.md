# Prime Force Definitions — Sketch Pass 1
**Date:** 2026-05-11  
**Status:** First-pass sketch. One representative per architectural role. Force aggregation deliberately deferred to testing.  
**Reading first:** `memory/project_prime_physics_roles.md` and `memory/nsm_particle_architecture.md` for the operator stack context.

Each entry: **name — role — axis — force type — PhysX encoding suggestion**

---

## 1. TIME / WHEN  
**Architectural role:** Axis prime (temporal substrate)

**Axis:** TIME is the axis itself — a dedicated coordinate dimension for temporal location. In position encoding: `position.z` (or a named semantic axis).

**Force:** TIME exerts no propulsive force. As an axis anchor particle: invMass=0 (immovable), fixed at epoch z=0.0. Other particles' z-coordinates measure temporal distance from TIME.  
WHEN (when used as query/selector): a mobile particle placed at the target time-coordinate that applies a weak attractive force on temporally-proximate content particles.

**PhysX encoding:**  
- TIME → kinematic rigid body at semantic origin, invMass=0. Phase group = TEMPORAL_AXIS_GROUP.  
- WHEN → particle placed at query z-coordinate, adhesion force = query strength. Phase group = TEMPORAL_CURSOR_GROUP (interacts with TEMPORAL_AXIS_GROUP particles).  
- Grid encoding: the z-axis grid (gridSizeZ, particleContactDistance on z) defines temporal resolution. One grid cell = one resolvable temporal unit.

---

## 2. WHERE / PLACE  
**Architectural role:** Axis prime (spatial substrate)

**Axis:** PLACE is the 3D spatial coordinate system. In PhysX: directly = position.x, position.y (z is time; or a separate dimension mapping if using 4D encoding).

**Force:** Like TIME — no propulsive force. PLACE = the reference frame definition.  
WHERE (query form): particle placed at target spatial coordinates, applies proximity attraction.

**PhysX encoding:**  
- PLACE → the grid itself. The spatial hash over x,y (and z if time is encoded elsewhere) IS the PLACE axis. No special particle needed for the axis — it's the coordinate system.  
- WHERE → particle at target (x,y) with phase group = SPATIAL_CURSOR_GROUP. Adhesion to spatially-proximate content particles.

**Note:** TIME and PLACE together define the 4D (or nD) semantic coordinate system. Everything else locates on this substrate.

---

## 3. NOW  
**Architectural role:** Sliding cursor on the time axis

**Axis:** Time (z-coordinate)

**Force:** Weak attractive force on all "present-active" particles toward NOW's current z-position. NOW moves forward as the temporal model advances. Particles that track NOW = currently present; particles that fall behind = past.

**PhysX encoding:**  
- Particle at current z=`now_z`. Phase group = TEMPORAL_CURSOR_GROUP.  
- Material adhesion (radially) on z-axis = presentness strength.  
- In custom CUDA kernel (`onAdvance`): for each particle in the temporal-content group, compute z-distance to NOW. Particles within contactDistance = "present-active," applying force toward now_z. Particles outside = no NOW-attraction, drifting to past-z.  
- NOW's z-coordinate is updated by the host between steps via `raiseFlags(eUPDATE_POSITION)`.

---

## 4. HERE  
**Architectural role:** Sliding cursor on the spatial axes

**Axis:** Spatial (x, y)

**Force:** Attractive toward HERE's (x,y) position on particles in the spatial-reference group. Defines the spatial reference frame for near/far, above/below, inside/outside.

**PhysX encoding:**  
- Particle at current (x,y) = reference spatial position. Phase group = SPATIAL_CURSOR_GROUP.  
- Material adhesion on spatial proximity.  
- HERE updated per step as the contextual reference point shifts.

---

## 5. ONE  
**Architectural role:** Point selector on the quantity axis

**Axis:** Quantity axis (a dedicated encoding dimension for cardinality — one of the non-spatial encoding axes)

**Force:** Collapsing selector force. ONE induces a winner-take-all dynamic on a set of candidate particles: strong repulsion between candidates (prevents two from occupying the same quantity=1 position simultaneously), combined with attraction of exactly one candidate to the quantity=1 coordinate.  
Mechanically: exclusive competition. The first candidate to reach quantity=1 "wins" — the mutual repulsion with other candidates prevents a second winner.

**PhysX encoding:**  
- ONE particle in proximity to a set of candidate particles (same phase group).  
- Material: strong self-collision (eParticlePhaseSelfCollide + high cohesion for the winner, repulsion for others).  
- velocity.w on candidate particles encodes cardinality score (0.0 = not selected, 1.0 = selected).  
- CUDA kernel in `onAdvance`: particles near ONE's position on the quantity axis compete; winner assigned w=1.0, others w=0.0.  
- The settled equilibrium at w=1.0 on one particle IS the "exactly one" selection.

---

## 6. VERY  
**Architectural role:** Intensity scaling operator

**Axis:** No fixed axis — VERY acts on the axis of the prime it modifies (reads the target's force vector and scales it)

**Force:** Additive amplification. If the adjacent target prime exerts force +F on axis A, VERY injects an additional force +kF on the same axis A (same direction, same position). Net: target axis sees (1+k)×F.

**PhysX encoding:**  
- VERY particle placed adjacent (in broadphase proximity) to its target prime particle. Phase group = INTENSIFIER_GROUP.  
- velocity.w = k (scaling factor, default k=1.0 → doubles the force when applied).  
- Custom CUDA kernel: for each INTENSIFIER_GROUP particle, find its target (nearest particle in the modified-prime group), read target's current force vector, compute kF, inject as additional force on the target's axis.  
- Chain: VERY VERY BIG → two VERY particles adjacent to BIG. **FLAG: multiplicative (k²) or additive (2k)? Defer to testing.**

**Structural note:** VERY and NOT share the same mechanism (read adjacent force, multiply by w). VERY.w = k > 1.0; NOT.w = -1.0 (see §7). Same kernel code path.

---

## 7. NOT  
**Architectural role:** Polarity flip (unary logical gate)

**Axis:** No fixed axis — NOT acts on the axis of the modified prime (same mechanism as VERY)

**Force:** Inverts the sign of the adjacent prime's force on that axis. If target exerts +F on axis A, NOT injects −F on axis A (opposite direction). Net: the force flips polarity.

**PhysX encoding:**  
- NOT particle adjacent to its target. Phase group = NEGATOR_GROUP.  
- velocity.w = -1.0 (polarity sign).  
- Same CUDA kernel as VERY: read target force, multiply by w=-1.0, inject.  
- NOT BIG → force on size-axis flips from +F (big-direction) to -F (small-direction). Effectively: "not big" = pulled toward the SMALL end of the size axis.

**Structural note:** "NOT GOOD" ≠ "BAD." NOT GOOD = -F on the valence axis. BAD = its own force at the BAD pole of the valence axis. The magnitudes and anchoring differ. NOT flips; BAD has its own position.

**FLAG: NOT VERY BIG vs VERY NOT BIG** — ordering of adjacent intensifier and negator matters. How is parse order preserved in the spatial layout? Particles closest to the target apply first? **Defer to testing.**

---

## 8. I  
**Architectural role:** Focal substantive — locus anchor, ego position, rotation axis of the envelope constellation

**Axis:** The I particle defines the ORIGIN of the perspective field for a given PBD. All other particles' positions are relative to I's frame.

**Force:** I provides the gravitational center of the perspective field — a weak attractive force toward I that keeps the constellation cohesive. I itself is immovable (very high mass / kinematic).

**PhysX encoding:**  
- Kinematic rigid body at the PBD's reference-frame origin. Mass = very large (or kinematic = physics bypassed).  
- Phase group = IDENTITY_ANCHOR_GROUP. Every particle in the PBD scope has residual gravitational attraction toward I (gravityScale parameter on all materials = toward I's position).  
- All molecules in the PBD attach as articulation links under I as the root. I IS the articulation root for the PBD's explication forest.  
- Per-PBD isolation: each PBD has exactly one I particle. Different PBDs = different scenes OR different articulation roots in the same scene with separate phase namespaces.

**Note:** I, YOU, SOMEONE are all focal substantives with the same structure — each is a distinct locus anchor (different particle ID or different articulation root). Cross-PBD interaction (communication, theory-of-mind) = force applied between I's rigid body and another PBD's anchor.

---

## 9. KIND  
**Architectural role:** Relational substantive — categorical grouping relation

**Axis:** KIND does not have a single semantic axis — KIND IS the phase grouping mechanism. Each distinct KIND = a distinct phase group ID.

**Force:** Cohesion within a KIND group. Particles of the same KIND (same phase group) attract each other (eParticlePhaseSelfCollide=true, cohesion > 0). Particles of different KINDs = different phase groups = no direct interaction (no cross-KIND force).

**PhysX encoding:**  
- Each KIND-X instantiates as: phase group ID = KIND_X_GROUP_ID (a specific 20-bit value).  
- All particles of KIND-X get that group ID. Material cohesion parameter = KIND-cohesion strength (how tightly members of this KIND cluster).  
- KIND prime particle itself = a "type anchor" particle at the canonical center of KIND-X's cluster. Other members are attracted toward this anchor.  
- KINDs form naturally-sized clusters whose radius in semantic space encodes category breadth. A wide KIND cluster = broad/fuzzy category; tight cluster = narrow/specific category.

**Note:** `eParticlePhaseFluid=true` on KIND groups enables fluid density constraints — the pressure from a dense KIND-cluster spreading out encodes "category saturation." A very large KIND group gets pressure forcing members to spread, naturally encoding category differentiation.

---

## 10. DO  
**Architectural role:** Action class — state modifier, subroutine call

**Axis:** DO acts on the STATE TRANSITION vector of the target molecule — the direction from the molecule's current equilibrium (S₁) to the intended state (S₂). The axis is molecule-specific.

**Force:** A directed perturbation force applied to the target molecule's rigid body. `addForce(transitionVector)` where transitionVector = the direction and magnitude of the state transition.

**PhysX encoding:**  
- DO = a prime particle that, when in broadphase proximity to a molecule's rigid body, fires its transition force.  
- Phase group = ACTION_CLASS_GROUP. DO particles interact with molecule rigid bodies (cross-LoD: particle→rigid).  
- Force vector: direction = target molecule's state-transition axis (molecule-specific, stored in the molecule's FilterData or companion buffer); magnitude = DO particle's velocity.w (action intensity).  
- Temporal anchor: DO fires when NOW reaches DO's time-coordinate (DO particle's z-position on the temporal axis). Before NOW arrives at z=DO_z: force magnitude = 0 (not yet fired). At z=NOW_z ≈ DO_z: force fires. After: DO particle retires (invMass → ∞) or persists for ongoing action.  
- State transition = PBD solver re-settling the molecule rigid body under the new force. The new equilibrium IS state S₂.

**FLAG: DO's force direction is molecule-specific. Where does the S₁→S₂ vector live? Options: FilterData.word2/3 encoding, companion GPU buffer indexed by molecule rigid body ID, or articulation joint drive target. Defer to testing.**

---

## 11. THINK  
**Architectural role:** Mental predicate — channel spin marker, envelope definer. Specifically on the **mental/theoretical side** of the experience line (see below).

**Experience-line split (2026-05-12 update):**  
The mental-predicate class bisects into two structurally distinct groups. THINK is the representative of one side:

| Group | Predicates | Character |
|---|---|---|
| **Mental / theoretical** | THINK, WANT, KNOW | Cognitive only — no sensory channel required. Can run in ToM models. Temporally flexible — can refer to past, present, or future. Constructed/held experiences. |
| **Physical / experiential** | FEEL, SEE, HEAR | Sensory — require an embodied body with sensory channels. Bound to the body/world contact event. Temporally anchored to the experience-event's NOW. Direct experiences. |

These are the same architectural cut from three angles: mental/physical, theoretical/experiential, temporally-flexible/temporally-anchored. All three coincide.

**Quark-layer encoding (planned):** MENTAL_PREDICATE class flag (1 bit) + experience-line sub-bit (0 = mental/theoretical, 1 = physical/experiential). Specific predicate identity (which of THINK/WANT/KNOW or FEEL/SEE/HEAR) defers to molecule layer.

**Axis:** CHANNEL axis — the distinction between internal-assertion (inside the THINK envelope) and external-assertion (outside it).

**Force:** THINK is primarily an envelope-opening signal, not a propulsive force. THINK triggers a phase group reassignment for particles inside its scope, separating them into the THINKING_ENVELOPE group (no direct interaction with particles outside the scope).

**Connections to other quarks (force-binding hints):**  
- **I/Not-I warrant**: THINK carries weaker / different epistemic warrant than physical predicates. FEEL/SEE/HEAR = direct sensory contact = strong I-phase warrant. THINK = constructed internal state = tentative, more loosely coupled to I-phase; can run in Not-I (modeling what someone else thinks). Warrant difference will drive force-binding strength differences at molecule layer.  
- **5-state TRUE coupling**: THINK can occupy any of the 5 TRUE states (will-be-active for anticipated thoughts, is-active for current, was-active for recalled, never-been-active for abandoned/falsified). Physical predicates (FEEL/SEE/HEAR) have tighter coupling — you cannot physically FEEL something that never happened, though you can THINK about it. The TRUE state space for experiential predicates is constrained to is-active / was-active in most natural constructions.  
- **BODY requirement**: Physical predicates require a BODY-substantive with sensory channels. THINK can operate on any ToM-bearing entity, embodied or not. This affects bonding rules at molecule layer.

**PhysX encoding:**  
- THINK particle = phase boundary marker. When active (in proximity to content particles), triggers their reassignment to THINK_ENVELOPE_GROUP.  
- Channel spin in velocity.w: +1.0 = out-spin (expressor is the source of thought content — most THINK uses), -1.0 = in-spin.  
- Envelope containment: THINK's content particles form their own phase-isolated cluster. The THINK particle itself is at the envelope boundary.  
- Scope closure: when a content particle is no longer within THINK's contactDistance, it exits the THINKING_ENVELOPE (phase reassignment back to base group).  
- THINK envelope depth = one `PxArticulationReducedCoordinate` level in the explication tree. "I THINK [I KNOW [X]]" = two nested articulation levels under the I anchor.  
- Experience-line difference: physical predicates (FEEL/SEE/HEAR) have the same envelope-opening structure but with additional body-contact constraint (BODY-substantive particle must be present in broadphase neighborhood for the predicate to activate). This is the main mechanical distinction between the two sides at particle layer.

---

## 12. TRUE  
**Architectural role:** Speech / truth attachment — 5-state attached binary particle

**Axis:** TRUTH axis — a continuous dimension from fully-false (−1.0) to fully-true (+1.0) with 5 named positions.

**5 states:**  
| State | Meaning | velocity.w encoding | Phase bits [17:19] |
|---|---|---|---|
| Absent | No truth claim made | — (no TRUE particle) | 0b000 |
| Will-fire | Predicted/asserted will be true | +0.25 | 0b001 |
| Is-active | Currently true | +1.0 | 0b010 |
| Was-active | Was true, no longer is | −0.5 | 0b011 |
| Never-been-active | Tested and false | −1.0 | 0b100 |

**Force:**  
- Is-active (+1.0): strong attractive force toward the "realized" region of the proposition's axis. The proposition is grounded.  
- Never-been-active (−1.0): repulsive force from the realized region. The proposition is repelled from realization.  
- Was-active (−0.5): attenuated attraction with a past-temporal marker. Was grounded, no longer.  
- Absent: no force — proposition is unexamined.

**PhysX encoding:**  
- TRUE particle attached to the proposition particle via a `PxParticleSpring` (length ≈ 0, moderate stiffness = attachment).  
- velocity.w = truth state float (as above table).  
- Phase bits [17:19] = coarser GPU-readable truth state for broadphase decisions (can 5 states fit in 3 bits: yes, exactly).  
- Truth state transitions (e.g., is-active → was-active) = update velocity.w + update phase bits in `onBegin` callback.  
- TRUE within a THINK envelope: the THINK envelope's phase isolation means truth-forces inside the envelope don't propagate to outside. Correct behavior: what I THINK is TRUE may differ from what IS TRUE in the outer scope.

**Note:** Same 5-state architecture as LIVE/DIE (Patrick: confirmed in `project_prime_physics_roles.md`). Same encoding, different semantic domain.

---

## 13. THE_SAME  
**Architectural role:** Determiner — identity assertion

**Axis:** IDENTITY axis — encodes whether two entities are the same entity viewed from different perspectives, or are genuinely distinct.

**Force:** Hard equality constraint. THE_SAME creates a zero-length spring between two particles/molecules, pulling them to identical positions on all relevant axes. If the constraint cannot be satisfied (the entities are structurally incompatible), the spring is under tension — the identity claim is disputed.

**PhysX encoding:**  
- `PxParticleSpring` between particles A and B: length=0, stiffness = identity-assertion strength, damping = convergence speed.  
- For rigid bodies: `PxConstraint` enforcing zero relative displacement (or near-zero).  
- Residual spring length at equilibrium = degree of identity. Zero = fully identical in this respect. Non-zero = approximation or partial match.  
- THE_SAME has a direction softly: A is drawn to B (or B to A). The "reference" entity is the anchor (heavier mass / lower invMass); the "compared" entity is drawn toward it.  
- THE_SAME vs LIKE: THE_SAME stiffness is very high (near identity). LIKE would have lower stiffness (partial similarity, allows residual distance). Same constraint structure, different stiffness value.

---

## 14. BECAUSE  
**Architectural role:** Binary directional logical gate — causal bond

**Axis:** CAUSATION axis — a directed force from cause (B) to effect (A). "A BECAUSE B" = B causes A.

**Force:** One-way directed force: B exerts a force on A toward A's "effect position"; A does NOT exert a return force on B. Asymmetric by construction.

**PhysX encoding:**  
- In CUDA kernel (`onAdvance`): for each CAUSAL_BOND pair (A, B), compute `forceOnA = causalStrength * normalize(B.pos - A.effectPos)`. Apply `A.velocity += forceOnA * dt / A.mass`. Do NOT apply to B.  
- The asymmetry is enforced by the kernel — no symmetric reaction.  
- Alternatively: `PxArticulationJointReducedCoordinate` with `ePRISMATIC` on eZ, `eLIMITED` to one-way (only pushes B toward A's effect position, doesn't pull back). Drive stiffness = causal strength.  
- BECAUSE as a particle bond: CAUSAL_BOND_GROUP. A and B are both in this group, but the CUDA kernel enforces the asymmetry.  
- Multi-hop chains (A BECAUSE B BECAUSE C): **FLAG — does causal force propagate transitively (C ultimately affects A), or does each BECAUSE apply independently? Defer to testing.**

---

## 15. BE  
**Architectural role:** Superstate — existence gate

**Axis:** EXISTENCE axis — binary gate: BE=on means X exists and has queryable properties; BE=off means X doesn't exist (no properties are valid).

**Force:** Localization and existence force. BE=on: pins X to its existence position with a strong adhesive force (X is "realized" in the semantic space). BE=off: X's invMass is set to ∞ (removed from active simulation — no forces, no interactions, not in broadphase).

**PhysX encoding:**  
- BE state stored in `invMass`:  
  - `invMass = small positive value` (normal mass) = X exists, full physics.  
  - `invMass = 0` (very heavy, kinematic-like) = X exists but immovable (necessary existence / definitional).  
  - `invMass = ∞` (removed from active buffer) = X does not exist.  
- Temporal trajectory: existence is time-indexed on the time axis. The BE particle's z-position encodes existence onset. Creation event = transition to finite invMass at z=T_create. Destruction = invMass → ∞ at z=T_destroy.  
- BE as a gating constraint on properties: particles encoding X's properties (size, valence, etc.) have their interactions enabled only when X's invMass is finite. Custom CUDA kernel: if X.invMass == ∞, skip all neighborhood iterations for X.  
- THERE IS (existential form of BE) = same encoding, no locational constraint (X exists but its spatial/temporal position is unspecified).

---

## Flagged Questions for Testing Phase

*Not design decisions — observations that surface while defining primes.*

1. **VERY VERY BIG / stacking intensifiers**: Two VERY particles adjacent to BIG. Does the force compound multiplicatively (k²F) or additively (2kF)? The model is ambiguous until we test equilibrium behavior.

2. **Order of NOT and VERY**: NOT VERY BIG vs VERY NOT BIG produce different semantic results. In the spatial encoding, which particle applies first? Is it the one closer to the target in the broadphase, or is parse order preserved by a sequential-z position encoding?

3. **DO's force direction**: DO fires on the target molecule's state-transition axis, but this axis is molecule-specific. Where does the S₁→S₂ vector live? FilterData encoding, companion buffer, or articulation joint drive target?

4. **BECAUSE in chains**: Multi-hop causality (A BECAUSE B BECAUSE C). Does causal force propagate transitively (C ultimately affects A), or does each BECAUSE apply independently with no transitivity? Related: does BECAUSE force compose with IF (conditional) in chains?

5. **TRUE across THINK scope**: Inside a THINK envelope, what is the interaction between the envelope's truth scope and TRUE particles that exist outside it? "I think what John believes is true" has layered truth contexts.

6. **I and YOU across PBD boundary**: I and YOU are focal substantives in different PBDs. Communication (SAY → WORDS → channel) = forces across the I/YOU boundary. What is the force model for cross-PBD interaction at the prime level?
