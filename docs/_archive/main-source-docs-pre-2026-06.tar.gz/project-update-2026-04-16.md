# Project Update from Patrick

_2026-04-16_

Further development of document storage and higher order tokenization is on pause while core work moves to NSM concept modeling.

The current engine is capable of storing documents in a format conducive to later inference and reproduce those documents on demand. Current reproduction is above 98% accuracy with only minor issues in spacing and capitalization of some elements. 99% of words are stored at the highest level word construct token_IDs. Phrase, idiom and entity level constructs exist in the database shards but are not currently assigned to resolution chambers.

All data enters the system as 4 byte codepoint streams, regardless of source content. Assembly through letter constructs and word hierarchies is managed via physics based superposition resolution chambers. All languages and file formats can theoretically enter via the same mechanism and be constructed into meaning units as needed. This is done to establish word particles within the system for smooth transition to NSM Concept Spaces and derivation and generation of NSM structures.

Token_ID namespace is intentionally vast and easily expandable if the current limits prove too constrained. This allows the HCP to adopt a see it and mint it philosophy for anything recognized as a surface form of a word or concept. With the exception of authorial quirks in compound words and other strictly idiosyncratic use cases that have no significant concept effect, every form or conjugation of every word, including misspellings, is included in the dbs as a distinct entry with links to core meanings and conceptual structures.

Codepoint level recognition beds resolve all established unicode and private endpoints to permit content and language recognition. All resolution mechanisms above that level are focused on english based, serial ingestion of md and txt based files with an accompanying json metadata resolver.

All elements are modularized. Contributors adding other language shards will be able to add path discriminators at appropriate resolution levels. Languages using Latin Extended character sets can be inserted at the spelling level. Other space delineated languages will be able to fork insertion immediately following that operation. Non-space delineated languages will require development of an alternative resolution chamber feed mechanism.

Ingestion can be optimized for both batch and stream processing. Batch processing would compile a complete resolution candidate list from multiple document manifests before invoking resolution cycles. Stream processing expands on the cyclical resolution functions and assumes constant insertion of candidate terms into persistently rotating on-demand resolution chambers.

A number of idiom, phrase and Proper Entity level entries are available in the English, document and metadata database shards but resolution cycles have not been drafted for those elements. Proper entries will require linking to dramatis or other reference lists to create holistic constructs encompassing all analyzed elements of the Entity.

Current GUI workstation is nominal and useful for viewing purposes only. Workstation functions should be updated to allow ingestion via GUI. Any contributors approaching this area should consult regarding data feeds to the main storage areas. This discussion is required to incorporate 3rd party ingestion of documents of any kind.

Md and txt files were chosen for initial ingestion based on Gutenberg format and ease of extraction. Additional document types should focus on extraction of content including any font or other diacritical notation, independent of file type. File type is only relevant during ingestion or final production, it is irrelevant for content consumption.

Core development efforts will be moving to establishing the basic mechanics of concept space based on NSM modeling of the current English data. The elements addressed above will not be revisited until story level constructs are evaluated in concept space.
