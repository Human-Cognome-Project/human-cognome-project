# Architecture snapshot — 2026-04-13

This is a session-scoped handoff doc capturing decisions made on 2026-04-13.
A specialist should fold the relevant pieces into the permanent docs
(`status.md`, `engine-quickref.md`, `data-pipeline-status-*.md`, `decisions/`)
and then delete this file. Topics are grouped so the merge is mechanical.

---

## 1. Mental model: what each storage layer owes

This was the single most-corrected item in the session. The roles must be kept
distinct in any doc that touches storage.

### Postgres = source of truth
- Holds the structured token natively in 5 part columns (`a_ns, a_p2, a_p3, a_p4, a_p5`).
  The flat `token_id` is a generated convenience column, not the canonical form.
- `pbm_starters`: one row per `(doc_id, token)` with positions as `INTEGER[]`.
  Postgres stores int arrays compactly (~4 bytes/element); no per-position row
  overhead, no encoded text payloads.
- `pbm_documents.all_caps_positions INTEGER[]`: the only cap delta worth storing.
  FIRST_CAP is positional (TokenIdsToText already capitalizes after `. ? ! \n`)
  and Label tokens carry their intrinsic cap in `entries.word`. Author-emphatic
  ALL_CAPS is the only override that isn't derivable.
- Possessives → future work (`POSS`, `POSS_PL` morpheme bits not yet revisited).

### LMDB = ephemeral working surface for the engine
- LMDB owes the engine **only what makes lookups fast**. Shape it for the engine,
  not for symmetry with Postgres.
- Per-entry payload is just: padded spelling (chars at PBD positions, leading
  nulls inert via Z=0) + a 4-byte INT back-reference (`entries.id`).
- No structured token_id parts in LMDB. No morphology. No relational shape.
- Bed assignment / null-padding is iterated from the broadphase scan — for each
  spelling, ask broadphase which widths it might land in, write one entry per width.
- LMDB rebuilds from Postgres on demand; eviction is fine.

### Recording flow (engine → Postgres)
1. Engine resolves a manifest item against an LMDB candidate, producing
   `(manifest_position, lmdb_back_ref)` pairs.
2. Writer collects unique back-refs and batch-fetches `entries.id, a_ns…a_p5`
   from `hcp_english.entries` via `WHERE id = ANY($1)`.
3. Per token, upsert one row into `pbm_starters` with the 5 parts and an
   `INTEGER[]` of the positions where it landed.
4. ALL_CAPS positions go to `pbm_documents.all_caps_positions`.

---

## 2. Broadphase = free pruning

PhysX broadphase prunes inactive particles in O(1) at the bucket level — no
narrow-phase iteration, no force/contact memory. Activation is the gate, not
loading. Implications for the engine:

- LMDB load decisions don't need to be conservative. Load freely, activate
  selectively. Over-loading costs ephemeral disk; under-loading costs latency.
- Optimization frame is "pack the GPU budget with useful work, let broadphase
  do the pruning." Not "minimize what enters the bed."

---

## 3. Optimization hooks (deferred — do not implement now)

### Bed packing
- Length stacking — pad shorter words with leading nulls so a length-N bed
  holds words of width ≤ N. Inert nulls prune at zero cost via Z=0.
- First-letter stacking — load multiple letter-buckets together; broadphase
  prunes via Z mismatch on the first non-null particle.
- Both are the same broadphase-prune pattern at different axes. The finicky
  bit is broadphase tuning, not the data shape.

### Multi-doc batch resolve
- Today: one doc per socket call → one PBD pass.
- Hook: tokenize/extract runs for N docs, lay them out on X-axis lanes in shared
  scenes, single resolution pass, manifests carry doc-tag, recording phase splits.
- Cost frame: analysis ≈ largest single doc (scene-bound, not doc-count-bound).
  Recording is the only doc-axis cost — disk I/O bound. SSD/NVMe makes it
  effectively free; spinning disk queues but stays manageable.
- Refactor lives at the ingest entry point.

### LMDB shape simplification
- Drop structured token_id parts from LMDB entries. Keep spelling + INT back-ref
  to `entries.id`. Save bytes, simplify lookup, and stop confusing LMDB's role.

### Storage refactor at LMDB level
- Mirror the Postgres-side cleanup at the LMDB-side layout. Today the LMDB
  encoding evolved alongside an older flat-token model; revisit once the
  recording-side simplifications are stable.

### Possessives
- Possessive handling is not yet right. Should not be encoded as a morpheme
  bit on the base token; should be revisited as part of a focused pass.

---

## 4. What landed this session

### Code changes
- `HCPPbmReader.cpp` — workstation viewer fix. Was running an older binary
  with `SELECT FROM tokens` (renamed to `entries` in commit 8d05d1f). Removed
  morph-bit reconstruction (`ApplyMorphBits`, `variantMap`) — every form is
  now its own token, no surface re-inflection at read time. Now reads
  `pbm_starters.positions` directly as `INTEGER[]` and pulls
  `pbm_documents.all_caps_positions` for the only meaningful cap flag.
- `HCPPbmWriter.cpp` — `StorePositions` rewritten. One row per `(doc, token)`;
  positions written as `INTEGER[]`. Writes only `ALL_CAPS` overlay; FIRST_CAP
  and morpheme bits dropped.
- `HCPVocabBed.cpp` — `ScanManifestToPBM` no longer emits FIRST_CAP or any
  morpheme bits. Only `ALL_CAPS` ends up in the morpheme positions map.
  (The `morphBits` field on `ResolutionResult` is still produced upstream;
  it's a candidate for full removal in a follow-up.)
- `HCPDocumentQuery.cpp` — `DeleteDocument` comment refreshed for the new
  cascading tables.

### Migrations
- **048** — first attempt at normalizing positions into a row-per-position
  table. Wrong direction: Postgres tuple overhead (~24-byte header + 16-byte
  index entry) far exceeded the savings from dropping base-50 encoding.
  Database grew from 39 MB → 101 MB on the 9-doc dataset.
  **This file is now superseded by 049** and should be marked or removed.
- **049** — correct shape: positions as `INTEGER[]` on `pbm_starters`,
  `all_caps_positions INTEGER[]` on `pbm_documents`. Truncates and reingests.

### Stress-test ingest
9 documents (Yellow Wallpaper + 8 of the Gutenberg top-12) ingested cleanly.
Var rates 0.15–0.31% with one outlier (Moby Dick 0.59% — nautical/whaling
vocabulary). Reconstruction is intact end-to-end — reported issues are
nominal whitespace/cap nudges, no meaning drift.

| Doc | Slots | Starters | Vars | Var % |
|-----|------:|---------:|-----:|------:|
| Yellow Wallpaper | 11,577 | 2,216 | 34 | 0.29 |
| Alice in Wonderland | 39,816 | 3,927 | 89 | 0.22 |
| Jekyll & Hyde | 36,294 | 5,418 | 70 | 0.19 |
| Frankenstein | 92,963 | 8,967 | 141 | 0.15 |
| Wuthering Heights | 152,058 | 11,669 | 381 | 0.25 |
| Pride & Prejudice | 162,166 | 8,717 | 315 | 0.19 |
| Crime & Punishment | 264,092 | 12,025 | 394 | 0.15 |
| Moby Dick | 268,162 | 22,437 | 1,573 | 0.59 |
| The Great Gatsby | 67,764 | 7,817 | 209 | 0.31 |

---

## 5a. Modules worth factoring out

The kernel decomposition (2026-03-01) broke up `HCPWriteKernel` cleanly. Same
treatment is warranted for these files — contributors (new-language shards in
particular) will otherwise need to navigate monoliths to find extension points.

- **`HCPVocabBed.cpp` — 4,250 lines.** Holds `VocabBed`, `BedManager`,
  `ResolvePass`, `ScanManifestToPBM`, plus inflection strip, variant normalize,
  hyphen split, morpheme decomposition, dependency resolution. Natural split:
  bed mechanics (VocabBed, BedManager, ResolvePass) → one module;
  morphological/variant helpers (strip, normalize, hyphen, decomp) → another;
  manifest scan + bond accounting (ScanManifestToPBM) → a third.
- **`HCPEnvelopeManager.cpp` — 1,373 lines.** Envelope definition loading,
  warm assembly, LMDB writes, windowing. Splits: definition loading vs.
  query execution vs. LMDB writer.
- **`HCPSocketServer.cpp` — 968 lines.** One big `if (strcmp(action, ...))` chain
  per action. Natural split: one file per action group (document ops, physics
  ops, envelope ops, metadata ops) with a small dispatcher. Makes adding actions
  additive rather than central-file churn.
- **`HCPEngineSystemComponent.cpp` — 978 lines.** Owns every kernel + lifecycle
  + socket wiring. Core enough that monolithic is defensible, but kernel
  ownership could move into a small composition root while lifecycle stays
  in the component.
- **`HCPTokenizer.cpp` — 968 lines.** Contains `TokenIdsToText` (reconstruction)
  alongside the ingest-side tokenizer. Reconstruction is not really tokenization;
  factor the text-reassembly path into its own module.
- **`HCPWordSuperpositionTrial.cpp` — 978 lines.** Phase 2 trial mechanics plus
  a lot of glue; worth a pass once the VocabBed factoring above is done (some
  responsibilities will migrate).

## 5. Cruft / kibble flagged for cleanup

A specialist should sweep these. None are blockers; they cause confusion for
agents reading the codebase.

### Code
- `HCPSqliteBackend.cpp` — defines its own `pbm_positions(id, doc_id, token_id, positions TEXT)`
  schema for the SQLite distribution dump. Diverged from the Postgres runtime.
  Distribution format needs a coordinated update once the Postgres shape settles.
- `HCPVocabBed.h` — `MorphBits` enum and bit-field machinery is largely dead
  for storage purposes. Resolution pipeline still uses some of it (e.g.,
  inflection strip + variant normalize set bits transiently). Audit candidates
  for full removal once we're sure none feed live behavior.
- `HCPPbmReader.cpp` — comment block still references "morpheme/cap overlays"
  as if they're load-bearing for reconstruction. Update once the rest of the
  morph removal is done.
- All `r.morphBits = …` / `r.firstCap = …` propagation in `HCPVocabBed.cpp`
  (multiple sites). Most of it can probably be deleted; needs a careful pass
  to confirm none of it informs the resolver.

### Docs
- `docs/status.md` — last updated 2026-04-08. Section "Pending Architecture —
  Label Phase" still describes the morph-bit reconstruction model. Needs a
  rewrite reflecting "every form is its own token, positions as INTEGER[],
  ALL_CAPS-only cap storage".
- `docs/engine-quickref.md` — references morph reconstruction in the recording
  flow.
- `docs/data-pipeline-status-2026-04-07.md` — also from before this pass.
- `MEMORY.md` (auto-memory) — the "Morphological Normalization (2026-02-28)"
  section needs to be amended: the storage half (writing morph bits per
  position) is gone; the resolution half (strip + try-base-via-PBD) is still
  live.
- `db/migrations/041_pbm_morpheme_positions.sql`,
  `db/migrations/048_position_normalization.sql`,
  `db/migrations/README_position_history.md` — should note that they're
  superseded by 049.

### Migrations on disk
- 048 is on disk and applied. The 049 migration cleans it up but the file
  itself remains and would re-run if anyone replays migrations from scratch.
  Mark as no-op / superseded, or remove with a README note.

---

## 6. Open questions for the maintainer

These came up during the session and were noted as future work but not decided.

- **Multi-doc batch ingest entry point** — when to refactor the socket API
  to accept a doc batch in one call.
- **LMDB shape simplification** — when to drop structured token_id parts from
  LMDB entries (currently still encoded for engine convenience).
- **Possessives** — needs a focused design pass; should not be a morpheme bit.
- **SQLite distribution format** — needs to track the runtime Postgres shape;
  out of step today.
- **Entity matching** — connecting PBM documents to author/work entities
  (raised earlier in the session, deferred — separate piece of work).
